"""
argon_slide_supervisor_graph.py — Argon Tarafından Yönetilen Slayt Düzeltme LangGraph Alt Grafiği.

Akış:
  prepare_slide
    → render_draft
    → argon_supervisor
    → decision_router
Router:
  - accept_draft    → final_checks → save_draft_result
  - replace_visual  → retrieve_visual_candidates → apply_visual → render_draft
  - retrieve_more   → retrieve_evidence → revise_slide → render_draft
  - revise_text     → revise_slide → render_draft
  - review_required → save_review_item

Döngü ve Bütçe Kuralları:
- max_corrections (varsayılan: 2) replace_visual, retrieve_more ve revise_text tarafından ortak tüketilir.
- Döngüde geri dönmek sayacı sıfırlamaz; her düzeltme correction_count'u artırır.
- Reddedilen adaylar rejected_candidate_ids listesinde tutulur ve tekrar denenmez.
- Düzeltme bütçesi dolduğunda otomatik kabul YASAKTIR; review_required durumuna geçilir.
- accept_draft insan onayı DEĞİLDİR; expert_review_status review_required kalır.
"""

from __future__ import annotations

import base64
import uuid
import sqlite3
import datetime
import hashlib
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from bookgraph.safety import file_hash, fingerprint, assert_clinical_invariants
from bookgraph.llm import _assert_argon_identity
from bookgraph import usage
from phoenix_tracer import trace_model_call

from slide_supervisor_schema import (
    SlideSpec,
    SlideSupervisorState,
    SupervisorDecision,
    SupervisorActionRecord,
    SearchRequest,
    RevisionInstructions,
    CandidateVisual,
    SourcePassage,
    ClinicalClaim,
    SlideCard,
)
from retina_visual_resolver import RetinaVisualResolver

log = logging.getLogger("argon_slide_supervisor")


def render_slide_spec_to_png(
    spec: SlideSpec,
    out_path: Path,
    *,
    force_com: bool = False,
) -> Tuple[bool, Optional[str]]:
    """
    SlideSpec'i 1920x1080 piksel yüksek çözünürlüklü PNG olarak render eder.
    PowerPoint COM mevcutsa COM ile, aksi takdirde yerel PIL tuval motoru ile üretir.
    Dönen değer: (başarılı_mı, sha256_hash)
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # This renderer is a preview, never a rendering of the published PPTX.
    if force_com:
        return False, None

    # 2. Yerel Yüksek Çözünürlüklü 1920x1080 PIL Render Motoru
    try:
        width, height = 1920, 1080
        img = Image.new("RGB", (width, height), color=(10, 25, 47))  # Kurumsal Koyu Mavi
        draw = ImageDraw.Draw(img)

        # Üst Rozet ve Başlık
        draw.rectangle([80, 50, 400, 95], fill=(37, 99, 235))  # Rozet
        draw.text((100, 60), f"{spec.category.upper()} | BÖLÜM {spec.chapter_num}", fill=(255, 255, 255))

        # Başlık ve Alt Başlık
        draw.text((80, 115), spec.title.upper(), fill=(255, 255, 255))
        if spec.subtitle:
            draw.text((80, 155), spec.subtitle, fill=(191, 219, 254))

        # Sol Panel (Kartlar)
        num_cards = len(spec.cards) or 1
        card_w = int((1150 - (num_cards - 1) * 20) / num_cards)
        top_y = 200
        card_h = 750

        for i, card in enumerate(spec.cards):
            x1 = 80 + i * (card_w + 20)
            x2 = x1 + card_w
            y1 = top_y
            y2 = y1 + card_h

            # Kart Gövdesi
            draw.rectangle([x1, y1, x2, y2], fill=(15, 33, 55), outline=(37, 99, 235), width=2)
            # Kart Başlık Bandı
            draw.rectangle([x1, y1, x2, y1 + 55], fill=(30, 58, 88))
            draw.text((x1 + 15, y1 + 18), card.title.upper(), fill=(255, 255, 255))

            # Kart İçeriği
            curr_y = y1 + 75
            if card.lead:
                draw.text((x1 + 15, curr_y), f"ÖZET: {card.lead[:60]}...", fill=(254, 240, 138))
                curr_y += 35

            for it in card.items[:8]:
                draw.text((x1 + 15, curr_y), f"• {it[:55]}", fill=(241, 245, 249))
                curr_y += 30

            if card.footer:
                draw.rectangle([x1 + 10, y2 - 60, x2 - 10, y2 - 15], fill=(23, 49, 80))
                draw.text((x1 + 20, y2 - 48), f"📌 {card.footer[:50]}", fill=(147, 197, 253))

        # Sağ Panel: Klinik Görsel
        if spec.selected_visual and Path(spec.selected_visual.path).is_file():
            vis_x1 = 1260
            vis_y1 = 200
            vis_w = 580
            vis_h = 620
            draw.rectangle([vis_x1, vis_y1, vis_x1 + vis_w, vis_y1 + vis_h], fill=(0, 0, 0), outline=(59, 130, 246), width=2)
            try:
                with Image.open(spec.selected_visual.path) as c_img:
                    c_rgb = c_img.convert("RGB")
                    c_rgb.thumbnail((vis_w - 20, vis_h - 20), Image.Resampling.LANCZOS)
                    img.paste(c_rgb, (vis_x1 + 10, vis_y1 + 10))
            except Exception as paste_err:
                log.debug("Görsel yapıştırma uyarısı: %s", paste_err)

            # Altyazı Kutusu
            cap = spec.selected_visual.original_caption or "Klinik Görsel"
            draw.rectangle([vis_x1, vis_y1 + vis_h + 10, vis_x1 + vis_w, vis_y1 + vis_h + 120], fill=(15, 23, 42))
            draw.text((vis_x1 + 10, vis_y1 + vis_h + 15), f"Şekil: {spec.selected_visual.figure_id} | Modalite: {spec.selected_visual.modality}", fill=(147, 197, 253))
            draw.text((vis_x1 + 10, vis_y1 + vis_h + 40), f"{cap[:90]}...", fill=(226, 232, 240))
        else:
            # Görsel Yok Karantina Bandı
            draw.rectangle([1260, 200, 1840, 820], fill=(30, 41, 59), outline=(239, 68, 68), width=2)
            draw.text((1350, 480), "⚠️ KLİNİK GÖRSEL BULUNAMADI\n(Argon veya Hekim İncelemesi Gerektirir)", fill=(252, 165, 165))

        # Alt Bilgi Çubuğu
        draw.line([80, 1000, 1840, 1000], fill=(51, 65, 85), width=1)
        src_str = ", ".join(s.source_id for s in spec.sources[:2])
        draw.text((80, 1015), f"Kaynaklar: {src_str or 'Kaynak doğrulanmadı'} | SlideID: {spec.slide_id}", fill=(148, 163, 184))

        img.save(out_path, format="PNG")
        h = file_hash(out_path)
        return True, h
    except Exception as exc:
        log.warning("PIL slide render hatası: %s", exc)
        return False, None


class ArgonSlideSupervisorGraph:
    """
    Argon Slayt Düzeltme LangGraph Alt Grafiği.
    """

    def __init__(
        self,
        *,
        use_live_api: bool = False,
        strict_argon: bool = True,
        llm_factory: Optional[Callable[[str], Any]] = None,
        max_corrections: int = 2,
        evidence_retriever=None,
        checkpoint_path: Optional[Path] = None,
    ):
        self.evidence_retriever = evidence_retriever
        self.checkpoint_path = checkpoint_path
        self._checkpoint_connection = None
        self.use_live_api = use_live_api
        self.strict_argon = strict_argon
        self.llm_factory = llm_factory
        self.max_corrections = max_corrections
        self.resolver = RetinaVisualResolver.get_instance()
        self.app = self._build_graph()

    def _build_graph(self):
        builder = StateGraph(SlideSupervisorState)

        # Düğümler
        builder.add_node("prepare_slide", self.prepare_slide_node)
        builder.add_node("render_draft", self.render_draft_node)
        builder.add_node("argon_supervisor", self.argon_supervisor_node)
        builder.add_node("retrieve_visual_candidates", self.retrieve_visual_candidates_node)
        builder.add_node("apply_visual", self.apply_visual_node)
        builder.add_node("retrieve_evidence", self.retrieve_evidence_node)
        builder.add_node("revise_slide", self.revise_slide_node)
        builder.add_node("final_checks", self.final_checks_node)
        builder.add_node("save_draft_result", self.save_draft_result_node)
        builder.add_node("save_review_item", self.save_review_item_node)

        # Akış Kenarları
        builder.add_edge(START, "prepare_slide")
        builder.add_edge("prepare_slide", "render_draft")
        builder.add_edge("render_draft", "argon_supervisor")

        # Koşullu Yönlendirme (Router)
        builder.add_conditional_edges(
            "argon_supervisor",
            self.decision_router,
            {
                "accept_draft": "final_checks",
                "replace_visual": "retrieve_visual_candidates",
                "retrieve_more": "retrieve_evidence",
                "revise_text": "revise_slide",
                "review_required": "save_review_item",
            },
        )

        # Düzeltme Döngüleri (Render'a geri döner)
        builder.add_conditional_edges(
            "retrieve_visual_candidates",
            self.router_after_candidates,
            {
                "apply_visual": "apply_visual",
                "save_review_item": "save_review_item",
            },
        )
        builder.add_conditional_edges(
            "apply_visual",
            self.router_after_apply_visual,
            {
                "render_draft": "render_draft",
                "save_review_item": "save_review_item",
            },
        )

        builder.add_conditional_edges("retrieve_evidence", lambda st: "save_review_item" if st.latest_decision and st.latest_decision.action == "review_required" else "revise_slide")
        builder.add_conditional_edges("revise_slide", lambda st: "save_review_item" if st.latest_decision and st.latest_decision.action == "review_required" else "render_draft")

        # Sonuçlandırma
        builder.add_conditional_edges("final_checks", lambda st: "save_draft_result" if st.status == "accepted_draft" else "save_review_item")
        builder.add_edge("save_draft_result", END)
        builder.add_edge("save_review_item", END)

        if self.checkpoint_path:
            from langgraph.checkpoint.sqlite import SqliteSaver
            Path(self.checkpoint_path).parent.mkdir(parents=True, exist_ok=True)
            self._checkpoint_connection = sqlite3.connect(str(self.checkpoint_path), check_same_thread=False)
            memory = SqliteSaver(self._checkpoint_connection)
        else:
            memory = MemorySaver()
        return builder.compile(checkpointer=memory)

    # -------------------------------------------------------------------------
    # DÜĞÜM 1: Slaytı Hazırla
    # -------------------------------------------------------------------------
    def prepare_slide_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        # Eğer görsel seçilmemişse adaylardan veya resolver'dan ilk uygun olanı seç
        if not spec.selected_visual and spec.candidate_images:
            unrejected = [c for c in spec.candidate_images if c.image_id not in state.rejected_candidate_ids]
            if unrejected:
                spec.selected_visual = unrejected[0]

        return {
            "slide_spec": spec,
            "status": "in_progress",
            "correction_count": state.correction_count,
            "max_corrections": self.max_corrections,
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 2: Taslağı Render Et
    # -------------------------------------------------------------------------
    def render_draft_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        render_dir = Path("assets/supervisor_renders") / state.run_id
        out_png = render_dir / f"{fingerprint(spec.slide_id)[:16]}_v{state.correction_count}.png"

        # Simülasyon bayrağı: eğer ortamda render bilerek devre dışıysa
        if os.getenv("SIMULATE_NO_RENDERER") == "1":
            return {
                "render_available": False,
                "review_findings": state.review_findings + ["Renderer bulunamadı; gerçek render alınamadı."],
            }

        ok, sha = render_slide_spec_to_png(spec, out_png)
        if ok and sha:
            spec.render_kind = "preview"
            spec.rendered_slide_path = str(out_png)
            spec.rendered_slide_hash = sha
            return {
                "slide_spec": spec,
                "render_available": True,
            }
        else:
            return {
                "render_available": False,
                "review_findings": state.review_findings + ["Render işlemi başarısız oldu."],
            }

    # -------------------------------------------------------------------------
    # DÜĞÜM 3: Argon Slayt Yöneticisi Değerlendirmesi
    # -------------------------------------------------------------------------
    def argon_supervisor_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        count = state.correction_count
        max_c = state.max_corrections

        # Renderer yokluğu kontrolü (Requirement 9.J)
        if not state.render_available:
            dec = SupervisorDecision(
                action="review_required",
                reason="Gerçek render görüntüsü mevcut olmadığından görsel inceleme tamamlanamaz; incelemeye alındı.",
                unresolved_deficiencies=["Render alınamadı."],
            )
            act_record = SupervisorActionRecord(
                action="missing_render_quarantine",
                reason=dec.reason,
                correction_step=count,
            )
            return {
                "latest_decision": dec,
                "action_history": state.action_history + [act_record],
                "status": "review_required",
            }

        decision: Optional[SupervisorDecision] = None
        actual_model = "unknown"
        provider_resp_id = None
        argon_verified = False

        # Canlı API Çağrısı (Vertex AI / Argon)
        if self.use_live_api:
            decision, actual_model, provider_resp_id, argon_verified = self._call_live_argon_supervisor(state)
        elif self.llm_factory:
            # Test enjeksiyonu / Taklit model
            decision, actual_model, provider_resp_id, argon_verified = self._call_mock_argon_supervisor(state)
        else:
            # Deterministik Klinik Kural Motoru
            decision = self._deterministic_supervisor_rules(state)
            actual_model = "unknown"
            argon_verified = False

        if count >= max_c and decision.action not in ("accept_draft", "review_required"):
            decision = SupervisorDecision(action="review_required",
                reason="Düzeltme bütçesi tükendi; otomatik kabul yapılmadı.")

        # Only a completed model review may attach evidence to specific claims.
        if decision.action == "accept_draft" and argon_verified and decision.claim_source_links:
            known = {s.source_id for s in spec.sources}
            updated = []
            for claim in spec.claims:
                links = decision.claim_source_links.get(claim.claim_id, [])
                if not links or not set(links) <= known:
                    decision = SupervisorDecision(action="review_required", reason="İddia-kaynak eşlemesi eksik veya geçersiz.")
                    break
                updated.append(claim.model_copy(update={"supporting_source_ids": links, "status": "supported"}))
            else:
                spec = spec.model_copy(update={"claims": updated})

        # Güvenlik ve Bütünlük Doğrulaması (Model kararı zorunlu kod kontrollerini atlatamaz)
        decision = self._validate_and_sanitize_decision(decision, state)

        act_record = SupervisorActionRecord(
            action=decision.action,
            reason=decision.reason,
            model_used=actual_model,
            provider_response_id=provider_resp_id,
            correction_step=count,
            details={
                "affected_claim_ids": decision.affected_claim_ids,
                "target_image_ids": decision.target_image_ids,
            },
        )

        return {
            "latest_decision": decision,
            "action_history": state.action_history + [act_record],
            "slide_spec": spec,
            "actual_model": actual_model,
            "verified_with_argon": argon_verified,
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 4: Karar Yönlendirici (Router)
    # -------------------------------------------------------------------------
    def decision_router(self, state: SlideSupervisorState) -> str:
        if not state.latest_decision:
            return "review_required"
        action = state.latest_decision.action
        if action in ("accept_draft", "replace_visual", "retrieve_more", "revise_text", "review_required"):
            return action
        return "review_required"

    def router_after_candidates(self, state: SlideSupervisorState) -> str:
        if state.latest_decision and state.latest_decision.action == "review_required":
            return "save_review_item"
        return "apply_visual"

    def router_after_apply_visual(self, state: SlideSupervisorState) -> str:
        if state.latest_decision and state.latest_decision.action == "review_required":
            return "save_review_item"
        return "render_draft"

    # -------------------------------------------------------------------------
    # DÜĞÜM 5: Görsel Adaylarını Getir
    # -------------------------------------------------------------------------
    def retrieve_visual_candidates_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        # Halihazırda seçili olup reddedilen görseli listeye ekle
        rejected_hashes = set(state.rejected_image_hashes)
        if spec.selected_visual:
            rejected_hashes.add(spec.selected_visual.image_sha256)
        rejected = list(state.rejected_candidate_ids)
        if spec.selected_visual and spec.selected_visual.image_id not in rejected:
            rejected.append(spec.selected_visual.image_id)

        # Karardaki search_request veya slayt konusuna göre alternatif ara
        disease = spec.topic_id
        modality = spec.expected_modality
        if state.latest_decision and state.latest_decision.search_request:
            disease = state.latest_decision.search_request.disease or disease
            modality = state.latest_decision.search_request.modality or modality

        # Mevcut adaylar içinden elenmemiş olanları bul
        new_candidates: List[CandidateVisual] = []
        for c in spec.candidate_images:
            if c.image_sha256 not in rejected_hashes and c.image_id not in rejected and c.image_id != (spec.selected_visual.image_id if spec.selected_visual else None):
                new_candidates.append(c)

        # Eğer listede yoksa, resolver'dan veya registry'den yeni aday çek
        if not new_candidates:
            matched_p, matched_cap = self.resolver.resolve_visual(
                chapter_num=spec.chapter_num,
                title=spec.title,
                category=spec.category,
                topic_id=disease,
                modality=modality,
                excluded_image_hashes=rejected_hashes,
            )
            if matched_p and matched_p.is_file():
                h = file_hash(matched_p)
                new_id = f"IMG-{disease.upper()}-{h[:8]}"
                if new_id not in rejected and h not in rejected_hashes:
                    new_candidates.append(CandidateVisual(
                        image_id=new_id,
                        path=str(matched_p),
                        modality=modality or "fundus",
                        figure_id="auto_resolved",
                        original_caption=matched_cap,
                        image_sha256=h,
                        source_id="retina_registry",
                        disease_ids=[disease],
                    ))

        if not new_candidates:
            # Alternatif aday bulunamadı: başka hastalığın görseliyle DOLDURMA; review_required yap
            return {
                "rejected_candidate_ids": rejected,
                "rejected_image_hashes": sorted(rejected_hashes),
                "latest_decision": SupervisorDecision(
                    action="review_required",
                    reason="Uygun alternatif görsel adayı bulunamadı; başka hastalık görseli kullanılmadı.",
                    unresolved_deficiencies=state.open_deficiencies + ["Alternatif görsel bulunamadı"],
                ),
            }

        return {
            "rejected_candidate_ids": rejected,
                "rejected_image_hashes": sorted(rejected_hashes),
            "slide_spec": spec.model_copy(update={"candidate_images": spec.candidate_images + [c for c in new_candidates if c not in spec.candidate_images]}),
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 6: Görseli Uygula
    # -------------------------------------------------------------------------
    def apply_visual_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        # Eğer visual bulunamadıysa doğrudan save_review_item'a gidecek
        if state.latest_decision and state.latest_decision.action == "review_required":
            return {}

        spec = state.slide_spec
        rejected = set(state.rejected_candidate_ids)
        available = [c for c in spec.candidate_images if c.image_id not in rejected and c.image_sha256 not in state.rejected_image_hashes]

        if not available:
            return {
                "latest_decision": SupervisorDecision(
                    action="review_required",
                    reason="Uygulanabilecek geçerli görsel kalmadı.",
                    unresolved_deficiencies=state.open_deficiencies + ["Tüm adaylar tüketildi"],
                ),
            }

        # Hedef görseli seç
        chosen = available[0]
        # Eğer yönetici belirli bir target_image_ids belirttiyse onu tercih et
        if state.latest_decision and state.latest_decision.target_image_ids:
            for tid in state.latest_decision.target_image_ids:
                cand = next((c for c in available if c.image_id == tid), None)
                if cand:
                    chosen = cand
                    break

        new_count = state.correction_count + 1
        spec.selected_visual = chosen
        act = SupervisorActionRecord(
            action="apply_visual",
            reason=f"Görsel '{chosen.image_id}' uygulandı.",
            correction_step=new_count,
            details={"selected_image_id": chosen.image_id, "modality": chosen.modality},
        )

        return {
            "slide_spec": spec,
            "correction_count": new_count,
            "action_history": state.action_history + [act],
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 7: Kanıt / Kaynak Pasajı Getir
    # -------------------------------------------------------------------------
    def retrieve_evidence_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        existing = {s.source_id for s in spec.sources}
        # An adapter must supply genuine passages. Retrieval never proves entailment.
        sources = []
        if self.evidence_retriever:
            for item in self.evidence_retriever(spec, state.latest_decision):
                source = SourcePassage.model_validate(item)
                if (source.source_id not in existing and source.text.strip()
                        and source.source_path and source.document_sha256
                        and file_hash(source.source_path) == source.document_sha256):
                    sources.append(source)
                    existing.add(source.source_id)
        if not sources:
            return {"latest_decision": SupervisorDecision(action="review_required",
                reason="Yeni, kökeni doğrulanabilir kaynak pasajı bulunamadı; kanıt üretilmedi.")}
        return {"slide_spec": spec.model_copy(update={"sources": spec.sources + sources})}

    # -------------------------------------------------------------------------
    # DÜĞÜM 8: Slayt Metnini Revize Et
    # -------------------------------------------------------------------------
    def revise_slide_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        instructions = state.latest_decision.revision_instructions if state.latest_decision else None

        updated_cards = []
        for card in spec.cards:
            if instructions and instructions.target_card_id and card.card_id == instructions.target_card_id:
                if instructions.target_field == "items" and instructions.replacement_text:
                    new_items = list(card.items)
                    idx = instructions.target_index if instructions.target_index is not None else 0
                    if 0 <= idx < len(new_items):
                        new_items[idx] = instructions.replacement_text
                    else:
                        new_items.append(instructions.replacement_text)
                    card = card.model_copy(update={"items": new_items})
                elif instructions.target_field == "lead" and instructions.replacement_text:
                    card = card.model_copy(update={"lead": instructions.replacement_text})
                elif instructions.target_field == "footer" and instructions.replacement_text:
                    card = card.model_copy(update={"footer": instructions.replacement_text})
            updated_cards.append(card)

        try:
            assert_clinical_invariants([c.model_dump() for c in spec.cards], [c.model_dump() for c in updated_cards])
        except ValueError:
            return {"latest_decision": SupervisorDecision(action="review_required",
                reason="Metin düzeltmesi klinik değişmezleri değiştirdi; uygulanmadı.")}
        new_count = state.correction_count + 1
        spec = spec.model_copy(update={"cards": updated_cards})
        act = SupervisorActionRecord(
            action="revise_text",
            reason=instructions.instructions if instructions else "Metin revize edildi.",
            correction_step=new_count,
        )
        return {
            "slide_spec": spec,
            "correction_count": new_count,
            "action_history": state.action_history + [act],
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 9: Son Doğrulama ve Güvenlik Denetimleri
    # -------------------------------------------------------------------------
    def final_checks_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        spec = state.slide_spec
        deficiencies = []

        # 1. Kaynak ve İddia Doğrulaması
        known_sources = {s.source_id for s in spec.sources if s.text.strip() and s.source_path
                         and s.document_sha256 and file_hash(s.source_path) == s.document_sha256}
        if not spec.claims:
            deficiencies.append("Klinik iddia kapsamı doğrulanmadı.")
        for clm in spec.claims:
            if clm.status != "supported" or not clm.supporting_source_ids or not all(sid in known_sources for sid in clm.supporting_source_ids):
                deficiencies.append(f"İddia '{clm.claim_id}' geçerli bir kaynak kimliğiyle desteklenmiyor.")

        # 2. Görsel Hash ve Modalite Doğrulaması
        if spec.selected_visual:
            p = Path(spec.selected_visual.path)
            if not p.is_file() or file_hash(p) != spec.selected_visual.image_sha256:
                deficiencies.append("Seçilen görsel dosyası diskte bulunamadı veya hash'i eşleşmiyor.")
            if spec.expected_modality and spec.selected_visual.modality != spec.expected_modality:
                deficiencies.append(f"Görsel modalitesi ({spec.selected_visual.modality}) beklenen ({spec.expected_modality}) ile uyuşmuyor.")

        if not spec.selected_visual:
            deficiencies.append("Klinik görsel eksik.")
        if self.strict_argon and not state.verified_with_argon:
            deficiencies.append("Argon değerlendirmesi doğrulanmadı.")
        # 3. Render Varlığı
        if (not state.render_available or not spec.rendered_slide_path
                or file_hash(spec.rendered_slide_path) != spec.rendered_slide_hash):
            deficiencies.append("Render çıktısı eksik.")

        if deficiencies:
            return {
                "latest_decision": SupervisorDecision(
                    action="review_required",
                    reason="Son güvenlik denetimlerinde tutarsızlıklar saptandı.",
                    unresolved_deficiencies=deficiencies,
                ),
                "open_deficiencies": deficiencies,
                "status": "review_required",
            }

        return {
            "expert_review_status": "review_required",  # accept_draft ASLA insan onayı anlamına gelmez
            "status": "accepted_draft",
        }

    # -------------------------------------------------------------------------
    # DÜĞÜM 10 & 11: Sonuçlandırma
    # -------------------------------------------------------------------------
    def save_draft_result_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        if state.status != "accepted_draft":
            return self.save_review_item_node(state)
        return {
            "status": "accepted_draft",
            "expert_review_status": "review_required",
        }

    def save_review_item_node(self, state: SlideSupervisorState) -> Dict[str, Any]:
        return {
            "status": "review_required",
            "expert_review_status": "review_required",
            "open_deficiencies": list(set(state.open_deficiencies + (state.latest_decision.unresolved_deficiencies if state.latest_decision else []))),
        }

    # -------------------------------------------------------------------------
    # YARDIMCI: Canlı / Taklit / Deterministik Karar Üreticileri
    # -------------------------------------------------------------------------
    def _deterministic_supervisor_rules(self, state: SlideSupervisorState) -> SupervisorDecision:
        spec = state.slide_spec

        # 1. Görsel Uyumu Kontrolü
        if spec.selected_visual:
            vis = spec.selected_visual
            cap_lower = vis.original_caption.lower()
            topic_lower = spec.topic_id.lower()

            # Birleşik patoloji (CRAO+CRVO)
            if ("crao" in cap_lower and "crvo" in cap_lower) or ("artery" in cap_lower and "vein" in cap_lower and "occlusion" in cap_lower):
                return SupervisorDecision(
                    action="replace_visual",
                    reason="Görsel birleşik CRAO+CRVO patolojisi içeriyor; saf CRAO veya CRVO için kullanılamaz.",
                    target_image_ids=[vis.image_id],
                    search_request=SearchRequest(disease=spec.topic_id, modality=spec.expected_modality or "fundus"),
                )

            # Hastalık uyuşmazlığı (Stargardt vs Best)
            if topic_lower == "stargardt" and "best" in cap_lower and "stargardt" not in cap_lower:
                return SupervisorDecision(
                    action="replace_visual",
                    reason="Görsel Best hastalığına aittir; Stargardt ile uyumsuzdur.",
                    target_image_ids=[vis.image_id],
                    search_request=SearchRequest(disease="stargardt", modality="fundus"),
                )

            # Sektör vs Santral oklüzyon (CRVO vs BRVO)
            if topic_lower == "crvo" and "brvo" in cap_lower and "crvo" not in cap_lower and "central" not in cap_lower:
                return SupervisorDecision(
                    action="replace_visual",
                    reason="Görsel dal ven tıkanıklığı (BRVO); santral oklüzyon (CRVO) ile uyuşmuyor.",
                    target_image_ids=[vis.image_id],
                    search_request=SearchRequest(disease="crvo", modality="fundus"),
                )

            # Modalite uyuşmazlığı (Şema vs OCT B-scan)
            if spec.expected_modality == "OCT B-scan" and vis.modality == "teaching_schematic":
                return SupervisorDecision(
                    action="replace_visual",
                    reason="Slayt klinik OCT B-scan gerektiriyor fakat görsel öğretici bir şemadır.",
                    target_image_ids=[vis.image_id],
                    search_request=SearchRequest(disease=spec.topic_id, modality="OCT B-scan"),
                )

            # Histoloji vs Fundus
            if spec.expected_modality == "fundus" and vis.modality == "histology":
                return SupervisorDecision(
                    action="replace_visual",
                    reason="Histopatolojik kesit renkli fundus fotoğrafı yerine kullanılamaz.",
                    target_image_ids=[vis.image_id],
                    search_request=SearchRequest(disease=spec.topic_id, modality="fundus"),
                )

        else:
            return SupervisorDecision(
                action="replace_visual",
                reason="Slaytta henüz seçilmiş bir klinik görsel bulunmuyor.",
                search_request=SearchRequest(disease=spec.topic_id, modality=spec.expected_modality or "fundus"),
            )

        # 2. Kaynak / Kanıt Kontrolü
        known_sources = {s.source_id for s in spec.sources}
        for clm in spec.claims:
            if clm.status == "unsupported" or not any(sid in known_sources for sid in clm.supporting_source_ids):
                return SupervisorDecision(
                    action="retrieve_more",
                    reason=f"Klinik iddia '{clm.claim_id}' için doğrulanabilir kaynak pasajı eksiktir.",
                    affected_claim_ids=[clm.claim_id],
                )

        return SupervisorDecision(action="review_required",
            reason="Offline kurallar piksel veya klinik kanıt değerlendirmesi yapmaz; insan incelemesi gerekir.")

    def _validate_and_sanitize_decision(
        self,
        decision: SupervisorDecision,
        state: SlideSupervisorState,
    ) -> SupervisorDecision:
        """
        Argon kararının sistem veri sözleşmesine ve gerçek kayıtlara uyumunu doğrular.
        Bilinmeyen kimlik veya uygulanamayacak kararları otomatik kabul etmez.
        """
        spec = state.slide_spec

        # 1. Bilinmeyen veya Aday Olmayan Görsel Kimliği Kullanımı Engeli
        if decision.action == "replace_visual" and decision.target_image_ids:
            # Hedef görsel kimliği eldeki adaylarda var mı?
            known_cands = {c.image_id for c in spec.candidate_images}
            for tid in decision.target_image_ids:
                if tid not in known_cands:
                    # Bilinmeyen / doğrulanmamış kimlik reddedilir
                    return SupervisorDecision(
                        action="review_required",
                        reason=f"Geçersiz karar: Model bilinmeyen görsel kimliği ('{tid}') talep etti; reddedildi.",
                        unresolved_deficiencies=[f"Geçersiz görsel kimliği: {tid}"],
                    )

        # 2. Şema dışı veya boş kararların engellenmesi
        if not decision.action or decision.action not in (
            "accept_draft", "replace_visual", "retrieve_more", "revise_text", "review_required"
        ):
            return SupervisorDecision(
                action="review_required",
                reason=f"Şema dışı karar eylemi ('{decision.action}'); uzman incelemesine alındı.",
                unresolved_deficiencies=["Şema dışı action"],
            )

        return decision

    def _call_live_argon_supervisor(self, state: SlideSupervisorState) -> Tuple[SupervisorDecision, str, Optional[str], bool]:
        """Canlı Vertex AI / Argon çağrısı."""
        from langchain_core.messages import HumanMessage
        from langchain_google_genai import ChatGoogleGenerativeAI
        import contextlib

        requested_model = "gemini-4-argon"
        prompt_name = "argon_slide_supervisor/evaluate"
        run_id = state.run_id

        span_mgr = trace_model_call(
            prompt_name,
            book="retina_slide_supervisor",
            unit=state.slide_spec.slide_id,
            requested_model=requested_model,
            run_id=run_id,
        )

        with span_mgr:
            kwargs = dict(model=requested_model, temperature=0, max_retries=0)
            if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").strip().lower() in ("1", "true", "yes"):
                kwargs["location"] = "global"

            llm = ChatGoogleGenerativeAI(**kwargs)
            spec_json = state.slide_spec.model_dump_json()

            prompt_text = f"""Sen uzman bir Baş Tıbbi Retina Editörüsün (Argon).
Aşağıdaki slayt sözleşmesini, iddialarını, kaynaklarını ve mevcut görsel durumunu değerlendir:
{spec_json}

Aşağıdaki eylemlerden YALNIZCA BİRİNİ seç:
- 'accept_draft': Her iddia kaynak pasajıyla destekleniyorsa claim_source_links içinde her claim_id için gerçek source_id listesini ver. Eksik destek varsa kabul etme.
- 'replace_visual': Görsel modalitesi, tanısı veya paneli yanlışsa veya görsel eksikse.
- 'retrieve_more': Klinik iddialar kaynak pasajlarıyla yeterince desteklenmiyorsa.
- 'revise_text': Metin üzerinde somut düzeltme gerekiyorsa.
- 'review_required': Çözülemeyen eksiklik varsa veya bütçe yetersizse.

Çıktıyı yalnızca SupervisorDecision JSON şemasına göre üret:
{{
  "action": "accept_draft" | "replace_visual" | "retrieve_more" | "revise_text" | "review_required",
  "reason": "gerekçe",
  "claim_source_links": {{"claim_id": ["source_id"]}},
  "affected_claim_ids": [],
  "target_source_ids": [],
  "target_image_ids": [],
  "search_request": {{"disease": "...", "modality": "...", "required_findings": []}},
  "revision_instructions": {{"target_card_id": "...", "target_field": "items", "target_index": 0, "replacement_text": "..."}},
  "unresolved_deficiencies": []
}}"""

            content = [{"type": "text", "text": prompt_text + "\nRender yalnız taslak önizlemesidir; nihai PPTX yerleşimini onaylama."}]
            for label, path, expected_hash in [
                ("Taslak önizlemesi", state.slide_spec.rendered_slide_path, state.slide_spec.rendered_slide_hash),
                ("Kaynak görsel", state.slide_spec.selected_visual.path if state.slide_spec.selected_visual else None,
                 state.slide_spec.selected_visual.image_sha256 if state.slide_spec.selected_visual else None),
            ]:
                if not path or file_hash(path) != expected_hash:
                    raise ValueError("Görsel payload eksik veya değişmiş")
                import io
                with Image.open(path) as im:
                    buf = io.BytesIO()
                    im.convert("RGB").save(buf, format="PNG")
                content.extend([{"type": "text", "text": label}, {"type": "image_url", "image_url": {
                    "url": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")}}])
            from bookgraph.visual_calls import invoke_json
            resp, data = invoke_json(llm, [HumanMessage(content=content)], requested_model=requested_model,
                book="retina_slide_supervisor", unit=prompt_name, run_id=run_id,
                strict=self.strict_argon, validator=SupervisorDecision.model_validate)
            if self.strict_argon:
                _assert_argon_identity(requested_model, resp)

            meta = getattr(resp, "response_metadata", {}) or {}
            actual_model = meta.get("model_version") or meta.get("modelVersion") or meta.get("model_name") or "unknown"
            provider_resp_id = meta.get("response_id") or meta.get("responseId")
            if provider_resp_id and str(provider_resp_id).startswith(("lc_run", "run-")):
                provider_resp_id = None

            decision = SupervisorDecision.model_validate(data)
            argon_verified = (actual_model != "unknown" and "gemini-4-argon" in actual_model)
            return decision, actual_model, provider_resp_id, argon_verified

    def _call_mock_argon_supervisor(self, state: SlideSupervisorState) -> Tuple[SupervisorDecision, str, Optional[str], bool]:
        """Test ortamında enjekte edilen LLM taklidini çalıştırır."""
        llm = self.llm_factory("gemini-4-argon")
        resp = llm.invoke([{"text": state.slide_spec.model_dump_json()}])
        if self.strict_argon:
            _assert_argon_identity("gemini-4-argon", resp)

        meta = getattr(resp, "response_metadata", {}) or {}
        actual_model = meta.get("model_version") or meta.get("modelVersion") or meta.get("model_name") or "unknown"
        provider_resp_id = meta.get("response_id") or meta.get("responseId")
        if provider_resp_id and str(provider_resp_id).startswith(("lc_run", "run-")):
            provider_resp_id = None

        txt = getattr(resp, "content", "")
        match = re.search(r"\{[\s\S]*\}", txt)
        data = json.loads(match.group(0)) if match else {}
        decision = SupervisorDecision.model_validate(data)
        argon_verified = (actual_model != "unknown" and "gemini-4-argon" in actual_model)
        return decision, actual_model, provider_resp_id, argon_verified

    def run_supervisor(self, spec: SlideSpec, *, thread_id: Optional[str] = None) -> SlideSupervisorState:
        """Slaytı alt grafikten geçirir ve nihai durumu döndürür."""
        payload = spec.model_dump(exclude={"rendered_slide_path", "rendered_slide_hash", "render_kind"})
        images = {c.path: file_hash(c.path) for c in spec.candidate_images}
        if spec.selected_visual:
            images[spec.selected_visual.path] = file_hash(spec.selected_visual.path)
        source_files = {s.source_path: file_hash(s.source_path) for s in spec.sources if s.source_path}
        digest = fingerprint(payload, images, source_files, self.strict_argon, self.use_live_api, self.max_corrections)
        config = {"configurable": {"thread_id": (thread_id or spec.slide_id) + ":" + digest}}
        existing = self.app.get_state(config)
        if existing and existing.values:
            if existing.values.get("status") in ("accepted_draft", "review_required") and not existing.next:
                return SlideSupervisorState.model_validate(existing.values)
            if self.use_live_api:
                # A crash may have happened after the provider charged but before checkpoint commit.
                # Never silently replay a potentially paid invocation.
                raise RuntimeError("Kesilmiş canlı çalışma; ücretli çağrıyı yinelememek için insan incelemesi gerekiyor.")
            final_state = self.app.invoke(None, config=config)
        else:
            initial_state = SlideSupervisorState(slide_spec=spec.model_copy(deep=True), max_corrections=self.max_corrections,
                input_fingerprint=digest, run_id=str(uuid.uuid4()))
            final_state = self.app.invoke(initial_state, config=config)
        return SlideSupervisorState.model_validate(final_state) if isinstance(final_state, dict) else final_state

    def close(self):
        if self._checkpoint_connection is not None:
            self._checkpoint_connection.close()
            self._checkpoint_connection = None
