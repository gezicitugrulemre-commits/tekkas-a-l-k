# -*- coding: utf-8 -*-
"""
LangGraph + Elephant-Goldfish Architecture
Retina & Vitreus Masterclass Image Revision Engine (First 200 Slides)
====================================================================
"""

import sys
import os
import json
import shutil
import time
import re
from pathlib import Path
from PIL import Image
import pptx
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
PPTX_DESKTOP = BASE_DIR / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx"
PPTX_DRIVE = Path(r"C:\Users\gezic\Drive'ım\Retina Kitabı\Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx")
PPTX_BACKUP = BASE_DIR / "Retina_Masterclass_Pre_Goldfish_Backup.pptx"
CATALOG_PATH = BASE_DIR / "assets" / "visual_catalog" / "master_catalog.json"
CACHE_DIR = BASE_DIR / "assets" / "cached_images"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

print("=" * 80)
print(">>> LANGGRAPH + ELEPHANT-GOLDFISH RETİNA GÖRSEL REVİZYON MOTORU ÇALIŞTIRILIYOR")
print("=" * 80)

# 1. Master Kataloğu Yükle
with open(CATALOG_PATH, "r", encoding="utf-8") as f:
    master_cat = json.load(f)

local_images = master_cat.get("local_images", [])
print(f"Elephant Katalog Veritabanı Yüklendi: {len(local_images)} görsel")

# 2. Öncelikli Kitaplar ve İndeksleme
images_by_book = {
    "bcsc": [],
    "ryan": [],
    "atlas": [],
    "fundamentals": [],
    "imaging": [],
    "all": []
}

for item in local_images:
    fp = item.get("file_path", "")
    if not os.path.exists(fp):
        continue
    bk = item.get("book", "")
    cap = (item.get("caption") or item.get("original_caption") or "").lower()
    fn = item.get("filename", "")
    entry = {
        "filename": fn,
        "file_path": fp,
        "book": bk,
        "caption": item.get("caption") or "",
        "orig_cap": item.get("original_caption") or "",
        "page": item.get("page", 0),
        "search_text": f"{cap} {fn.lower()} {bk.lower()}"
    }
    images_by_book["all"].append(entry)
    if "12-Retina and Vitreous" in bk:
        images_by_book["bcsc"].append(entry)
    elif "RYAN'S RETINA" in bk:
        images_by_book["ryan"].append(entry)
    elif "THE RETINAL ATLAS" in bk:
        images_by_book["atlas"].append(entry)
    elif "02-Fundamentals and Principles" in bk:
        images_by_book["fundamentals"].append(entry)
    elif "Diagnostics_in_Ocular_Imaging" in bk:
        images_by_book["imaging"].append(entry)

print(f"İndeks Dağılımı:")
print(f"  - AAO BCSC Retina 2025-2026: {len(images_by_book['bcsc'])} görsel")
print(f"  - Ryan's Retina (3 Cilt)    : {len(images_by_book['ryan'])} görsel")
print(f"  - The Retinal Atlas (2. Ed) : {len(images_by_book['atlas'])} görsel")
print(f"  - Fundamentals & Principles : {len(images_by_book['fundamentals'])} görsel")
print(f"  - Ocular Imaging & OCT      : {len(images_by_book['imaging'])} görsel")

# 3. Helper to find specific images by query
def search_elephant(keywords, pools=("bcsc", "ryan", "atlas", "fundamentals", "imaging"), exclude_used=None):
    if exclude_used is None:
        exclude_used = set()
    
    kw_list = [k.lower() for k in keywords]
    candidates = []
    
    for pool_name in pools:
        pool = images_by_book.get(pool_name, [])
        for item in pool:
            if item["filename"] in exclude_used:
                continue
            st = item["search_text"]
            # Calculate match score
            score = 0
            for kw in kw_list:
                if kw in st:
                    score += 10
            if score > 0:
                # Add pool bonus
                if pool_name == "bcsc":
                    score += 5
                elif pool_name == "ryan":
                    score += 4
                elif pool_name == "atlas":
                    score += 3
                candidates.append((score, item))
                
    candidates.sort(key=lambda x: x[0], reverse=True)
    if candidates:
        return candidates[0][1]
    return None

def get_by_filename(fn):
    for item in images_by_book["all"]:
        if item["filename"] == fn:
            return item
    return None

# 4. Sunumu Aç
print(f"\n>> Sunum dosyası açılıyor: {PPTX_DESKTOP}...")
prs = pptx.Presentation(str(PPTX_DESKTOP))
total_slides = len(prs.slides)
print(f">> Toplam Slayt Sayısı: {total_slides}")

# Yedek Al
if not PPTX_BACKUP.exists():
    shutil.copy2(str(PPTX_DESKTOP), str(PPTX_BACKUP))
    print(f">> Güvenlik Yedeği Alındı: {PPTX_BACKUP.name}")

# Cache helper
def get_safe_rgb_path(img_path_str):
    p = Path(img_path_str)
    if not p.exists():
        return None
    try:
        ext = p.suffix.lower()
        if ext in ['.jpeg', '.jpg', '.png']:
            return p
        target = CACHE_DIR / (p.stem + ".png")
        if not target.exists():
            im = Image.open(p)
            if im.mode != 'RGB':
                im = im.convert('RGB')
            im.save(target, 'PNG')
        return target
    except Exception as e:
        print(f"Uyarı (RGB dönüşüm): {p.name}: {e}")
        return p if p.exists() else None

# Right panel bounds
right_x = Inches(8.35)
right_w = Inches(4.18)
max_img_w = right_w - Inches(0.24) # ~3.94 inç
max_img_h = Inches(3.55)
img_area_y = Inches(1.9) + Inches(0.48) # 2.38 inç

# 5. Build Comprehensive Slide-by-Slide Revision Map for Slides 1 to 200
# Her slayt için klinik olarak doğrulanmış kesin atlas görseli ve Türkçe akademik altyazısı
print("\n>> Goldfish Slayt Düzeyinde Klinik Görsel Eşleme Motoru Başlatılıyor...")

used_images = set()

# Pre-defined high-accuracy clinical mappings
precise_mappings = {
    # Bölüm 1.1: Anatomi & Vitreoretinal Arayüz
    4: {
        "kw": ["fibrillar structure", "vitreous collagen", "collagen fibrils"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p570_fig541.jpeg",
        "caption": "📷 Biyokimyasal Şema & Moleküler Yapı: Tip II/IX/XI Kollajen Fibrilleri ve Hyaluronan Ağı [Ryan's Retina 7th Ed.]"
    },
    5: {
        "kw": ["internal limiting membrane", "vitreoretinal interface", "ilm"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p027_fig002.jpeg",
        "caption": "📷 Anatomi ve Kesit: Vitreoretinal Arayüz, Arka Hyaloid Korteksi ve İLM [AAO BCSC Retina]"
    },
    6: {
        "kw": ["vitreous base", "ora serrata", "sclerotomy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p030_fig005.png",
        "caption": "📷 Cerrahi Anatomi: Vitreus Tabanı Sınırları ve Pars Plana Sklerotomi Girişleri [AAO BCSC Retina]"
    },
    7: {
        "kw": ["anatomical macula", "foveal pit", "fovea"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p028_fig004.png",
        "caption": "📷 Makula Anatomisi: Foveal Çukurluk, Umbo ve Foveal Avasküler Bölge [AAO BCSC Retina]"
    },
    8: {
        "kw": ["posterior vitreous detachment", "pvd", "weiss ring"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p392_fig258.jpeg",
        "caption": "📷 SD-OKT & Renkli Fundus: Arka Vitreus Dekolmanı (PVD), Weiss Halkası ve Çekinti [The Retinal Atlas]"
    },
    9: {
        "kw": ["10 layers", "schematic section", "retinal layers"],
        "fallback_fn": "02-Fundamentals_and_Principles_of_Ophthalmology_2025-2026_p046_fig046.png",
        "caption": "📷 Histolojik & Şematik Kesit: Nörosensoryal Retinanın 10 Katmanı ve Hücresel Mimarisi [AAO BCSC Fundamentals]"
    },
    10: {
        "kw": ["foveal avascular zone", "fovea", "parafovea"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vol_2_p764_fig690.jpeg",
        "caption": "📷 Yüksek Çözünürlüklü SD-OKT: Fovea, Parafovea ve Perifovea Mikroanatomik Sınırları [Ryan's Retina 7th Ed.]"
    },
    11: {
        "kw": ["foveal avascular zone (faz)", "scanning electron micrograph"],
        "fallback_fn": "02-Fundamentals_and_Principles_of_Ophthalmology_2025-2026_p050_fig050.png",
        "caption": "📷 Taramalı Elektron Mikroskopisi & OKTA: Foveal Avasküler Zon (FAZ) Kapiller Ağı [AAO BCSC Fundamentals]"
    },
    12: {
        "kw": ["reflectivity bands", "foveal oct", "external limiting membrane"],
        "fallback_fn": "Diagnostics_in_Ocular_Imaging_Cornea,_Retina,_Glaucoma_and_Orbit_p421_fig456.jpeg",
        "caption": "📷 Spektral Domain OKT: Nörosensoryal Retina Katman Yansıma Profili ve Dış Bantlar [Ocular Imaging]"
    },
    13: {
        "kw": ["photoreceptor", "rod", "cone"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p509_fig514.jpeg",
        "caption": "📷 Moleküler & Biyofiziksel Şema: Koni ve Çomak Fotoreseptör Hücre Dinamikleri [Ryan's Retina 7th Ed.]"
    },
    14: {
        "kw": ["rpe", "retinal pigment epithelium", "apical microvilli"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p793_fig678.jpeg",
        "caption": "📷 Transmisyon Elektron Mikroskopisi: RPE Monolayırı, Apikal Mikrovilluslar ve Melanozomlar [Ryan's Retina 7th Ed.]"
    },
    15: {
        "kw": ["bruch", "bruch membrane", "five layers"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p546_fig531.jpeg",
        "caption": "📷 Elektron Mikroskopisi & Şema: Bruch Membranının 5 Tabakası ve Koryokapillaris Arayüzü [Ryan's Retina 7th Ed.]"
    },
    16: {
        "kw": ["transport", "cftr", "water transport"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p795_fig680.jpeg",
        "caption": "📷 Biyofiziksel Şema: RPE İyon Kanalları, Su Taşıyıcıları ve Polarize Transport [Ryan's Retina 7th Ed.]"
    },
    17: {
        "kw": ["drusen", "pigment epithelial detachment", "ped"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p085_fig085.jpeg",
        "caption": "📷 Renkli Fundus & SD-OKT: Drusen Birikimi ve RPE Dekolmanı (PED) [The Retinal Atlas]"
    },
    19: {
        "kw": ["choroid", "haller", "sattler"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p248_fig329.png",
        "caption": "📷 EDI-OKT & Şema: Koroid Vasküler Anatomisi, Haller ve Sattler Tabakaları [AAO BCSC Retina]"
    },
    20: {
        "kw": ["choriocapillaris", "lobular", "capillaries"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p248_fig330.png",
        "caption": "📷 OKT Anjiyografi (OKTA): Koryokapillaris Lobüler Mimarisi ve Perfüzyon Dağılımı [AAO BCSC Retina]"
    },
    21: {
        "kw": ["vortex vein", "ampulla", "venous drainage"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p248_fig331.png",
        "caption": "📷 Ultra Geniş Açılı Fundus & Şema: Vortiköz Ven Sistemi ve Koroidal Drenaj [AAO BCSC Retina]"
    },
    22: {
        "kw": ["edi-oct", "subfoveal choroidal thickness", "choroid"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p248_fig332.png",
        "caption": "📷 Geliştirilmiş Derinlik OKT (EDI-OKT): Subfoveal Koroid Kalınlığı ve Sklera Sınırı [AAO BCSC Retina]"
    },
    23: {
        "kw": ["fenestrated", "endothelial", "retinal capillaries"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p692_fig614.jpeg",
        "caption": "📷 Karşılaştırmalı Elektron Mikroskopisi: Pencereli Koryokapillaris ve Kesintisiz Retinal Endotel [Ryan's Retina 7th Ed.]"
    },
    # Bölüm 1.2: Biyokimya & Kan-Retina Bariyeri
    24: {
        "kw": ["dark current", "cgmp", "photoreceptor"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vol_3_p084_fig147.jpeg",
        "caption": "📷 Biyofiziksel Model: Fotoreseptör Karanlık Akımı ve cGMP Bağımlı Katyon Kanalları [Ryan's Retina 7th Ed.]"
    },
    25: {
        "kw": ["phototransduction", "rhodopsin", "transducin"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vol_3_p095_fig158.jpeg",
        "caption": "📷 Biyokimyasal Kaskad: Rodopsin Aktivasyonu, Transdusin ve PDE6 Amplifikasyonu [Ryan's Retina 7th Ed.]"
    },
    26: {
        "kw": ["visual cycle", "retinoid cycle", "rpe65"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p032_fig010.png",
        "caption": "📷 Biyokimyasal Yolak: Retinoid (Görme) Döngüsü ve RPE65 Enzimatik İzomerizasyonu [AAO BCSC Retina]"
    },
    27: {
        "kw": ["enzymatic cascade", "visual cycle"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vol_3_p096_fig160.jpeg",
        "caption": "📷 Enzim Kaskadı: LRAT, RPE65 ve 11-sis Retinal Rejenerasyonu [Ryan's Retina 7th Ed.]"
    },
    28: {
        "kw": ["cone visual cycle", "muller cell"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vol_3_p098_fig162.jpeg",
        "caption": "📷 Moleküler Karşılaştırma: Kanonik RPE Döngüsü ile Müller Hücre Koni Döngüsü [Ryan's Retina 7th Ed.]"
    },
    # Kan-Retina Bariyeri (ASLA Retinoblastom Değil!)
    29: {
        "kw": ["blood ocular boundaries", "inner blood-retina barrier", "tight junction"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p692_fig615.jpeg",
        "caption": "📷 Şematik Kesit: İç Kan-Retina Bariyeri (İç K-RB), Endotel Sıkı Bağlantıları ve Perisitler [Ryan's Retina 7th Ed.]"
    },
    30: {
        "kw": ["outer blood-retinal barrier", "rpe tight junction", "zonula occludens"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p692_fig616.jpeg",
        "caption": "📷 Şematik Kesit: Dış Kan-Retina Bariyeri (Dış K-RB) ve RPE Zonula Occludens Kompleksi [Ryan's Retina 7th Ed.]"
    },
    31: {
        "kw": ["glut-1", "aquaporin", "glucose transporter"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p693_fig617.jpeg",
        "caption": "📷 Taşıyıcı Protein Mimarisi: GLUT-1 Glikoz Taşıyıcıları ve AQP4 Su Kanalları [Ryan's Retina 7th Ed.]"
    },
    32: {
        "kw": ["breakdown", "fluorescein leakage", "blood-retina barrier"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p055_fig024.png",
        "caption": "📷 Floresein Anjiyografi & SD-OKT: Kan-Retina Bariyer Yıkımı ve İntraretinal Kaçak [AAO BCSC Retina]"
    },
    # RPE Metabolizması & Yaşlanma
    34: {
        "kw": ["phagocytosis", "outer segment", "rpe"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p034_fig012.png",
        "caption": "📷 Transmisyon Elektron Mikroskopisi: Fotoreseptör Dış Segment Fagositozu ve Fagozomlar [AAO BCSC Retina]"
    },
    35: {
        "kw": ["lipofuscin", "a2e", "autofluorescence"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p035_fig013.png",
        "caption": "📷 Floresan Mikroskopi & FAF: Lipofuskin Granülleri, A2E Birikimi ve RPE Sitotoksisitesi [AAO BCSC Retina]"
    },
    36: {
        "kw": ["melanosome", "melanin", "antioxidant"],
        "fallback_fn": "RYAN_S_RETINA_7th_Ed__Vo_1_p794_fig679.jpeg",
        "caption": "📷 Elektron Mikroskopisi: RPE Melanozomları ve Serbest Radikal Süpürücü Mekanizma [Ryan's Retina 7th Ed.]"
    },
    37: {
        "kw": ["drusen biogenesis", "basal laminar", "rpe senescence"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p060_fig030.png",
        "caption": "📷 Histopatoloji & EDI-OKT: RPE Hücresel Senesansı ve Drusen Biyogenezi [AAO BCSC Retina]"
    },
    # Genetik & NGS
    38: {
        "kw": ["pedigree", "autosomal dominant", "inheritance"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p288_fig370.png",
        "caption": "📷 Genetik Soy Ağacı: Kalıtsal Retina Distrofilerinde Mendeliyen Geçiş Modelleri [AAO BCSC Retina]"
    },
    39: {
        "kw": ["allelic heterogeneity", "rhodopsin mutation"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p290_fig372.png",
        "caption": "📷 Moleküler Genetik: Allelik ve Lokus Heterojenitesi (RHO ve RPGR Varyantları) [AAO BCSC Retina]"
    },
    40: {
        "kw": ["mitochondrial", "lhon", "optic neuropathy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p295_fig380.png",
        "caption": "📷 Mitokondriyal DNA Mutasyon Haritası: LHON m.11778G>A ve Maternal Kalıtım [AAO BCSC Retina]"
    },
    41: {
        "kw": ["genotype phenotype", "stargardt", "abca4"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p300_fig390.png",
        "caption": "📷 Genotip-Fenotip Korelasyonu: ABCA4 Mutasyon Şiddeti ve Klinik Spektrum [AAO BCSC Retina]"
    },
    43: {
        "kw": ["next-generation sequencing", "ngs", "targeted panel"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p289_fig371.png",
        "caption": "📷 Moleküler Tanı İş Akışı: Yeni Nesil Dizileme (NGS) Hedefli Ekzom Paneli [AAO BCSC Retina]"
    },
    44: {
        "kw": ["acmg classification", "variant", "pathogenic"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p292_fig375.png",
        "caption": "📷 Biyoenformatik Karar Matrisi: ACMG/AMP 5 Basamaklı Patojenite Sınıflaması [AAO BCSC Retina]"
    },
    45: {
        "kw": ["genetic counseling", "risk assessment"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p294_fig378.png",
        "caption": "📷 Klinik Danışmanlık Protokolü: Taşıyıcılık Taraması ve Rekürrens Riski Hesaplaması [AAO BCSC Retina]"
    },
    46: {
        "kw": ["voretigene", "luxturna", "aav2"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p310_fig410.png",
        "caption": "📷 Subretinal Gen Tedavisi Enjeksiyonu: AAV2-hRPE65v2 (Voretigene Neparvovec) [AAO BCSC Retina]"
    },
    47: {
        "kw": ["fundus", "retinitis pigmentosa", "bone spicule"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p500_fig1750.jpeg",
        "caption": "📷 Renkli Fundus & FAF: Retinitis Pigmentoza Kemik Korpuskülleri ve Wax Soluk Disk [The Retinal Atlas]"
    },
    # Bölüm 2: OKT, Biyobelirteçler, OKTA, FA, ICGA, FAF, Elektrofizyoloji
    50: {
        "kw": ["interferometry", "low coherence", "spectral domain oct"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p040_fig015.png",
        "caption": "📷 Fiziksel İlke & Optik Şema: Düşük Koherensli Michelson İnterferometrisi ve Spektral Analiz [AAO BCSC Retina]"
    },
    51: {
        "kw": ["time-domain", "spectral-domain", "swept-source"],
        "fallback_fn": "Diagnostics_in_Ocular_Imaging_Cornea,_Retina,_Glaucoma_and_Orbit_p420_fig455.jpeg",
        "caption": "📷 Karşılaştırmalı Optik Şema: Zaman Alanlı, Spektral Alanlı ve Süpürmeli Kaynaklı OKT [Ocular Imaging]"
    },
    52: {
        "kw": ["en-face", "b-scan", "c-scan"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p042_fig017.png",
        "caption": "📷 Üç Boyutlu Görüntüleme: B-Scan, Hacimsel Yoğun Tarama ve En-Face C-Scan Düzlemleri [AAO BCSC Retina]"
    },
    53: {
        "kw": ["axial resolution", "lateral resolution"],
        "fallback_fn": "Diagnostics_in_Ocular_Imaging_Cornea,_Retina,_Glaucoma_and_Orbit_p422_fig458.jpeg",
        "caption": "📷 Biyofiziksel Grafik: Aksiyel Çözünürlük (Işık Koherens Boyu) ve Yanal Çözünürlük [Ocular Imaging]"
    },
    55: {
        "kw": ["intraretinal fluid", "subretinal fluid", "irf", "srf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p044_fig019.png",
        "caption": "📷 Spektral Domain OKT: İntraretinal Kistik Boşluklar (IRF) ve Subretinal Sıvı (SRF) [AAO BCSC Retina]"
    },
    56: {
        "kw": ["dril", "disorganization of retinal inner layers"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p148_fig150.png",
        "caption": "📷 SD-OKT Biyobelirteci: Retinal İç Katmanların Dezorganizasyonu (DRIL) ve İskemik Hasar [AAO BCSC Retina]"
    },
    57: {
        "kw": ["ellipsoid zone", "external limiting membrane", "ez", "elm"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p045_fig020.png",
        "caption": "📷 SD-OKT Yüksek Çözünürlük: Elipsoid Zon (EZ) Devamlılığı ve Dış Sınırlayıcı Membran Sağlamlığı [AAO BCSC Retina]"
    },
    58: {
        "kw": ["hyperreflective foci", "hrf", "lipid extravasation"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p150_fig153.png",
        "caption": "📷 SD-OKT Biyobelirteci: Hiperreflektif Odaklar (HRF), Aktive Mikroglia ve Lipid Göçü [AAO BCSC Retina]"
    },
    59: {
        "kw": ["pigment epithelial detachment", "serous ped", "fibrovascular ped"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p070_fig045.png",
        "caption": "📷 Karşılaştırmalı SD-OKT: Seröz PED, Fibrovasküler PED ve Drusenoid PED Ayrımı [AAO BCSC Retina]"
    },
    60: {
        "kw": ["subretinal hyperreflective material", "shrm"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p072_fig048.png",
        "caption": "📷 SD-OKT Biyobelirteci: Subretinal Hiperreflektif Materyal (SHRM) ve Neovasküler Aktivite [AAO BCSC Retina]"
    },
    61: {
        "kw": ["foveal biomarkers", "sd-oct"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p012_fig012.jpeg",
        "caption": "📷 Yüksek Çözünürlüklü Foveal Atlas: Nörosensoryal Retina Biyobelirteçlerinin Korelasyonu [The Retinal Atlas]"
    },
    # OKTA
    62: {
        "kw": ["ssada", "split-spectrum", "decorrelation"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p048_fig022.png",
        "caption": "📷 Biyofiziksel Algoritma: Spektrum Bölmeli Genlik Dekorelasyonu (SSADA) ve Akış Tespiti [AAO BCSC Retina]"
    },
    63: {
        "kw": ["superficial capillary plexus", "scp", "oct angiography"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p049_fig023.png",
        "caption": "📷 OKT Anjiyografi (OKTA): Yüzeyel Kapiller Pleksus (SCP) ve Sinir Lifi Tabakası Dolaşımı [AAO BCSC Retina]"
    },
    64: {
        "kw": ["deep capillary plexus", "dcp", "radial peripapillary"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p050_fig024.png",
        "caption": "📷 OKTA Segmentasyonu: Derin Kapiller Pleksus (DCP) Poligonal Vorteks Mimarisi [AAO BCSC Retina]"
    },
    65: {
        "kw": ["choriocapillaris slab", "avascular complex"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p051_fig025.png",
        "caption": "📷 OKTA En-Face Segmentasyonu: Avasküler Dış Retina ve Subfoveal Koryokapillaris Plakı [AAO BCSC Retina]"
    },
    66: {
        "kw": ["normal macula", "oct angiography", "faz circularity"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p052_fig026.png",
        "caption": "📷 Normal Sağlıklı Göz: 3x3 mm Foveal OKTA ve Simetrik Kapiller Dolaşım [AAO BCSC Retina]"
    },
    67: {
        "kw": ["diabetic microangiopathy", "capillary nonperfusion", "dr okta"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p145_fig145.png",
        "caption": "📷 OKTA Mikroanjiyopati: Kapiller Dökülme Alanları, Mikroanevrizmalar ve FAZ Genişlemesi [AAO BCSC Retina]"
    },
    68: {
        "kw": ["vein occlusion", "rvo okta", "collateral vessel"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p165_fig170.png",
        "caption": "📷 OKTA Patoloji: Retinal Ven Tıkanıklığında Derin Pleksus İskemisi ve Kollateral Damarlar [AAO BCSC Retina]"
    },
    69: {
        "kw": ["macular neovascularization", "mnv okta", "neovascular net"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p075_fig052.png",
        "caption": "📷 En-Face OKTA: Makuler Neovaskülarizasyon (MNV) Dolaşık Kılcal Damar Yumağı [AAO BCSC Retina]"
    },
    72: {
        "kw": ["vessel density", "perfusion density", "quantification"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p053_fig027.png",
        "caption": "📷 Kantitatif OKTA Haritası: ETDRS Izgarasında Damar Yoğunluğu (Vessel Density) Yüzdeleri [AAO BCSC Retina]"
    },
    73: {
        "kw": ["faz perimeter", "faz area", "circularity index"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p054_fig028.png",
        "caption": "📷 Morfometrik Analiz: FAZ Alanı, Çevresi ve Dairesellik İndeksi (Circularity Index) [AAO BCSC Retina]"
    },
    74: {
        "kw": ["flow void", "choriocapillaris ischemia", "signal void"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p078_fig056.png",
        "caption": "📷 Koryokapillaris Kantitasyonu: Akış Boşlukları (Flow Voids) ve İskemik Kümelenme [AAO BCSC Retina]"
    },
    75: {
        "kw": ["depth-encoded", "color-coded okta"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p056_fig029.png",
        "caption": "📷 Derinlik Kodlu Renkli OKTA: Yüzeyel (Kırmızı) ve Derin (Yeşil) Pleksusların Ayrımı [AAO BCSC Retina]"
    },
    76: {
        "kw": ["normative database", "repeatability okta"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p057_fig030.png",
        "caption": "📷 Normatif Veri Dağılımı: Yaşa Bağlı Kapiller Dansite Değişimleri ve Güven Aralığı [AAO BCSC Retina]"
    },
    77: {
        "kw": ["biomarker clinical trials", "okta endpoint"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p147_fig148.png",
        "caption": "📷 Klinik Çalışma Sonlanım Noktası: Anti-VEGF Öncesi ve Sonrası OKTA Perfüzyon Takibi [AAO BCSC Retina]"
    },
    78: {
        "kw": ["widefield okta", "montage okta"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p030_fig030.jpeg",
        "caption": "📷 Geniş Açılı OKTA Montajı: Arka Kutup ve Periferik Vasküler Ağaç [The Retinal Atlas]"
    },
    # OKTA Artefaktları
    79: {
        "kw": ["motion artifact", "blink artifact", "line artifact"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p058_fig032.png",
        "caption": "📷 OKTA Artefaktı: Mikro-Sakkadik Hareket Çizgileri ve Göz Kırpma Sinyal Kaybı [AAO BCSC Retina]"
    },
    80: {
        "kw": ["projection artifact", "projection resolved"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p059_fig033.png",
        "caption": "📷 Projeksiyon Artefaktı: Yüzeyel Damarların Derin Pleksusa Yalancı Yansıması ve Yazılımsal Temizleme [AAO BCSC Retina]"
    },
    81: {
        "kw": ["segmentation failure", "mis-segmentation"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p061_fig035.png",
        "caption": "📷 Segmentasyon Hatası: Makula Ödeminde Bozulmuş Otomatik Hatlar ve Manuel Düzeltme [AAO BCSC Retina]"
    },
    82: {
        "kw": ["shadowing artifact", "hemorrhage shadowing"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p062_fig036.png",
        "caption": "📷 Gölgeleme Artefaktı: Preretinal Kanama ve Yoğun Eksüdanın Akış Sinyalini Engellemesi [AAO BCSC Retina]"
    },
    83: {
        "kw": ["artefact guide", "quality index"],
        "fallback_fn": "Diagnostics_in_Ocular_Imaging_Cornea,_Retina,_Glaucoma_and_Orbit_p440_fig470.jpeg",
        "caption": "📷 Klinik Değerlendirme Algoritması: OKTA Sinyal Kalite İndeksi ve Artefakt Doğrulama Kılavuzu [Ocular Imaging]"
    },
    # FA & ICGA
    84: {
        "kw": ["fluorescein angiography", "sodium fluorescein", "filter"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p036_fig011.jpeg",
        "caption": "📷 Optik ve Farmakokinetik: Mavi Uyarma Filtresi (490 nm) ve Sarı Bariyer Filtresi (530 nm) [AAO BCSC Retina]"
    },
    85: {
        "kw": ["fluorescein transit phases", "arteriovenous phase"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p037_fig012.jpeg",
        "caption": "📷 Normal FA Geçiş Evreleri: Koroidal Dolum, Erken Arteriyel ve Laminar Akımlı Arteriyovenöz Faz [AAO BCSC Retina]"
    },
    86: {
        "kw": ["hyperfluorescence", "leakage", "pooling"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p038_fig013.jpeg",
        "caption": "📷 Hiperfloresans Tipleri: İletim (Pencere) Defekti, Boyalanma, Havuzlanma ve Neovasküler Sızıntı [AAO BCSC Retina]"
    },
    87: {
        "kw": ["hypofluorescence", "vascular filling defect", "blockage"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p039_fig014.jpeg",
        "caption": "📷 Hipofloresans Tipleri: Kanama Kaynaklı Blokaj ve Kapiller Perfüzyon Kaybı [AAO BCSC Retina]"
    },
    89: {
        "kw": ["indocyanine green", "icga", "near-infrared"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p041_fig016.jpeg",
        "caption": "📷 Yakın Kızılötesi Floresein: Plazma Proteinlerine Yüksek Bağlanma ve Koroid Geçirgenliği [AAO BCSC Retina]"
    },
    90: {
        "kw": ["icga phases", "choroidal vasculature", "late icga"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p043_fig018.jpeg",
        "caption": "📷 Normal ICGA Fazları: Erken Koroid Arterleri, Orta Dönem Koryokapillaris ve Geç Faz İnversiyonu [AAO BCSC Retina]"
    },
    91: {
        "kw": ["polypoidal", "pcv icga", "branching vascular network"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p080_fig060.jpeg",
        "caption": "📷 ICGA Altın Standart: Dallanan Vasküler Ağ (BVN) Ucunda Polipoid Dilatasyonlar [AAO BCSC Retina]"
    },
    92: {
        "kw": ["central serous", "cscr icga", "choroidal hyperpermeability"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p088_fig070.jpeg",
        "caption": "📷 ICGA Koroidal Hiperpermeabilite: SSKR'de Çok Odaklı Koroidal Geç Kaçak Bölgeleri [AAO BCSC Retina]"
    },
    93: {
        "kw": ["fa icga comparison", "multimodal angiography"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p045_fig045.jpeg",
        "caption": "📷 Eşzamanlı FA ve ICGA: Retinal ve Koroidal Patolojilerin Karşılaştırmalı Dinamik Kaydı [The Retinal Atlas]"
    },
    # FAF (Fundus Otofloresans)
    94: {
        "kw": ["fundus autofluorescence", "faf", "fluorophores"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p046_fig021.png",
        "caption": "📷 Fundus Otofloresans (FAF): RPE İçi Floroforlar ve Foveal Luteal Pigment Emilimi [AAO BCSC Retina]"
    },
    95: {
        "kw": ["short-wavelength faf", "near-infrared faf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p047_fig022.png",
        "caption": "📷 SW-FAF ve NIR-FAF Karşılaştırması: Lipofuskin ile Melanin Floroforlarının Ayrımlı Haritası [AAO BCSC Retina]"
    },
    96: {
        "kw": ["hyperautofluorescence", "hyper-faf", "active accumulation"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p065_fig040.png",
        "caption": "📷 Hiper-Otofloresans Paternleri: RPE Hücre Ölümü Öncesi Lipofuskin Artışı ve Kenar Halkası [AAO BCSC Retina]"
    },
    97: {
        "kw": ["hypoautofluorescence", "hypo-faf", "geographic atrophy faf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p066_fig041.png",
        "caption": "📷 Hipo-Otofloresans: RPE Atrofisi, Fotoreseptör Kaybı ve Sinyal Boşluğu Bölgeleri [AAO BCSC Retina]"
    },
    99: {
        "kw": ["amd faf", "junctional zone", "geographic atrophy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p068_fig043.png",
        "caption": "📷 Coğrafi Atrofi FAF İncelemesi: Birleşme Bölgesinde (Junctional Zone) Hiper-FAF ve Progresyon [AAO BCSC Retina]"
    },
    100: {
        "kw": ["stargardt faf", "best faf", "dystrophy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p302_fig392.png",
        "caption": "📷 Genetik Makula Distrofisi FAF: Stargardt Hastalığında Fleck Birikimleri ve Koroid Susturması [AAO BCSC Retina]"
    },
    101: {
        "kw": ["gravitational tract", "descending tract", "cscr faf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p089_fig072.png",
        "caption": "📷 Kronik SSKR FAF: Yerçekimi İzi (Gravitational Tract) ve RPE Atrofi Yolu [AAO BCSC Retina]"
    },
    102: {
        "kw": ["hydroxychloroquine", "bull's eye", "toxicity faf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p270_fig350.png",
        "caption": "📷 Toksik Retinopati Taraması: Hidroksiklorokine Bağlı Parafoveal Boğa Gözü FAF Halkası [AAO BCSC Retina]"
    },
    103: {
        "kw": ["faf atlas", "multimodal faf"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p060_fig060.jpeg",
        "caption": "📷 Multimodal FAF Atlası: Değişik Retinal Patolojilerde Otofloresans Yanıt Tipleri [The Retinal Atlas]"
    },
    # Elektrofizyoloji
    104: {
        "kw": ["electroretinography", "erg", "iscev"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p063_fig038.png",
        "caption": "📷 ISCEV Standart Tam Alan ERG: Elektrot Konfigürasyonu ve Ganzfeld Stimülasyonu [AAO BCSC Retina]"
    },
    105: {
        "kw": ["scotopic erg", "dark-adapted 0.01", "rod response"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p064_fig039.png",
        "caption": "📷 Skotopik ERG Yanıtları: Karanlığa Uyarlanmış 0.01 (Rod) ve 3.0 (Kombine Rod-Koni) Dalga Formları [AAO BCSC Retina]"
    },
    106: {
        "kw": ["photopic erg", "light-adapted 3.0", "30 hz flicker"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p065_fig040.png",
        "caption": "📷 Fotopik ERG Yanıtları: Aydınlığa Uyarlanmış 3.0 Koni Yanıtı ve 30 Hz Titreşim (Flicker) [AAO BCSC Retina]"
    },
    107: {
        "kw": ["multifocal erg", "mferg", "topographic"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p067_fig042.png",
        "caption": "📷 Multifokal ERG (mfERG): Santral 30 Derece Makula Fonksiyonunun 3 Boyutlu Topografik Haritası [AAO BCSC Retina]"
    },
    108: {
        "kw": ["pattern erg", "perg", "p50", "n95"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p069_fig044.png",
        "caption": "📷 Örüntü ERG (PERG): P50 Makula Bileşeni ve N95 Gangliyon Hücre Fonksiyon Dalgaları [AAO BCSC Retina]"
    },
    109: {
        "kw": ["electrooculography", "eog", "arden ratio"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p071_fig046.png",
        "caption": "📷 Elektrookülografi (EOG): Işık Zirvesi / Karanlık Çukuru Oranı (Arden Oranı > 1.85) [AAO BCSC Retina]"
    },
    110: {
        "kw": ["visual evoked potentials", "vep", "p100"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p073_fig049.png",
        "caption": "📷 Görsel Uyarılmış Potansiyeller (VEP): Kortikal İletim Süresi ve Patognomonik P100 Dalgası [AAO BCSC Retina]"
    },
    112: {
        "kw": ["retinitis pigmentosa erg", "extinguished erg"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p305_fig398.png",
        "caption": "📷 Retinitis Pigmentozada İleri Evre: Sönmüş (Extinguished / Non-recordable) ERG Çizgisi [AAO BCSC Retina]"
    },
    113: {
        "kw": ["best disease eog", "subnormal arden ratio"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p308_fig405.png",
        "caption": "📷 Best Vitelliform Distrofisi Ayrımı: Normal ERG Eşliğinde Şiddetli Subnormal Arden Oranı [AAO BCSC Retina]"
    },
    114: {
        "kw": ["toxic retinopathy erg", "vigabatrin", "chloroquine erg"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p272_fig352.png",
        "caption": "📷 Toksik İlaç Retinopatisinde Elektrofizyolojik Takip: İskemi ve Fotoreseptör Bozulması [AAO BCSC Retina]"
    },
    115: {
        "kw": ["pediatric erg", "infant erg"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p312_fig415.png",
        "caption": "📷 Pediatrik Elektrofizyoloji: Bebeklerde Kornea Cihazı ile Sedasyonsuz ERG Kaydı [AAO BCSC Retina]"
    },
    116: {
        "kw": ["electrophysiology summary", "diagnostic table"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p075_fig075.jpeg",
        "caption": "📷 Klinik Elektrofizyoloji Karşılaştırma Matrisi: Retina Hastalıklarında Teşhis Protokolü [The Retinal Atlas]"
    },
    # Bölüm 3: Diyabetik Retinopati, DMÖ, PDR, Ven & Arter Tıkanıklıkları
    118: {
        "kw": ["pericyte ghost", "diabetic microvascular", "aldose reductase"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p140_fig140.png",
        "caption": "📷 Histopatoloji & Patogenez: Diyabette Perisit Apoptozu ve Bazal Membran Kalınlaşması [AAO BCSC Retina]"
    },
    119: {
        "kw": ["microaneurysms", "dot blot hemorrhage", "early npdr"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p142_fig142.png",
        "caption": "📷 Renkli Fundus: Erken NPDR'de Mikroanevrizmalar, Nokta Kanamalar ve Sert Eksüdalar [AAO BCSC Retina]"
    },
    120: {
        "kw": ["etdrs 4-2-1", "severe npdr", "cotton wool spots"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p144_fig144.png",
        "caption": "📷 Geniş Açılı Fundus: İleri NPDR'de ETDRS 4-2-1 Kuralı ve 4 Kadranda Kanama Dağılımı [AAO BCSC Retina]"
    },
    121: {
        "kw": ["irma", "venous beading", "intraretinal microvascular"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p146_fig146.png",
        "caption": "📷 Büyütülmüş Fundus & FA: İntraretinal Mikrovasküler Anomali (İRMA) ve Venöz Boğumlanma [AAO BCSC Retina]"
    },
    122: {
        "kw": ["diabetic macular edema", "center-involved dme", "oct dme"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p152_fig155.png",
        "caption": "📷 SD-OKT & Kalınlık Haritası: Merkez Tutulumlu Diyabetik Makula Ödemi (CI-DME) [AAO BCSC Retina]"
    },
    124: {
        "kw": ["protocol t", "drcr.net", "visual acuity dme"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p154_fig158.png",
        "caption": "📷 Kanıta Dayalı Grafik: DRCR.net Protokol T - Başlangıç Görmesine Göre Anti-VEGF Karşılaştırması [AAO BCSC Retina]"
    },
    125: {
        "kw": ["anti-vegf mechanism", "aflibercept", "faricimab"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p156_fig160.png",
        "caption": "📷 Moleküler Farmakoloji: VEGF-A, VEGF-B, PlGF ve Angiopoietin-2 İkili İnhibisyonu [AAO BCSC Retina]"
    },
    126: {
        "kw": ["subretinal fluid dme", "hrf diabetic", "oct biomarker"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p158_fig162.png",
        "caption": "📷 SD-OKT Biyobelirteçleri: Diyabetik Makulopatide Subretinal Sıvı ve İnflamatuar HRF [AAO BCSC Retina]"
    },
    127: {
        "kw": ["foveal capillary nonperfusion", "diabetic macular ischemia", "dmi"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p160_fig164.png",
        "caption": "📷 Floresein Anjiyografi & OKTA: Diyabetik Makula İskemisinde FAZ Genişlemesi ve Düzensizliği [AAO BCSC Retina]"
    },
    128: {
        "kw": ["dexamethasone implant", "ozurdex", "corticosteroid"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p162_fig166.png",
        "caption": "📷 SD-OKT Takibi: Dirençli DMÖ'de Deksametazon İmplant (Ozurdex) Sonrası Anatomik Yanıt [AAO BCSC Retina]"
    },
    129: {
        "kw": ["focal laser", "grid laser", "hard exudates circinate"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p164_fig168.png",
        "caption": "📷 Renkli Fundus: Merkez Tutulumu Olmayan DMÖ'de Sirsine Eksüdaya Yönelik Fokal Lazer [AAO BCSC Retina]"
    },
    130: {
        "kw": ["dme treatment algorithm", "summary"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p320_fig1100.jpeg",
        "caption": "📷 Multimodal DMÖ Değerlendirme Atlası: SD-OKT, FA ve OKTA Eşzamanlı Teşhis Paneli [The Retinal Atlas]"
    },
    131: {
        "kw": ["nvd", "nve", "proliferative diabetic retinopathy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p166_fig172.jpeg",
        "caption": "📷 Renkli Fundus & FA: Disk Neovaskülarizasyonu (NVD) ve Yoğun Sızıntı Gösteren NVE [AAO BCSC Retina]"
    },
    132: {
        "kw": ["high-risk pdr", "vitreous hemorrhage diabetic"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p168_fig175.jpeg",
        "caption": "📷 Klinik Görünüm: Yüksek Riskli PDR Kriterleri (Diskte >1/3 NVD ve Preretinal Kanama) [AAO BCSC Retina]"
    },
    133: {
        "kw": ["panretinal photocoagulation", "prp laser scars"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p170_fig178.jpeg",
        "caption": "📷 Ultra Geniş Açılı Fundus: İleri PDR Olgusunda Eksiksiz Panretinal Fotokoagülasyon (PRP) Yanıkları [AAO BCSC Retina]"
    },
    134: {
        "kw": ["protocol s", "clarity pdr", "ranibizumab pdr"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p172_fig181.png",
        "caption": "📷 Landmark Klinik Kanıt: DRCR.net Protokol S - Anti-VEGF ile PRP Karşılaştırmalı Görme Alanı Takibi [AAO BCSC Retina]"
    },
    135: {
        "kw": ["tractional retinal detachment", "trd diabetic"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p174_fig184.jpeg",
        "caption": "📷 Renkli Fundus & B-Scan USG: Diyabetik Fibrovasküler Membranlar ve Traksiyonel Retina Dekolmanı (TRD) [AAO BCSC Retina]"
    },
    136: {
        "kw": ["vitrectomy pdr", "diabetic ppv", "membrane peeling"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p176_fig187.jpeg",
        "caption": "📷 İntraoperatif Cerrahi Görünüm: 25-Gauge Pars Plana Vitrektomi ve Diyabetik Membran Disseksiyonu [AAO BCSC Retina]"
    },
    # Ven Tıkanıklıkları
    137: {
        "kw": ["branch retinal vein occlusion", "brvo", "flame hemorrhage"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p180_fig195.jpeg",
        "caption": "📷 Renkli Fundus: Üst Temporal Branş Retinal Ven Tıkanıklığı (BRVO) ve Alev Kanamalar [AAO BCSC Retina]"
    },
    138: {
        "kw": ["arteriovenous crossing", "av nicking", "thrombosis"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p659_fig2318.jpeg",
        "caption": "📷 Yüksek Büyütme Fundus & FA: Arteriyovenöz Çaprazlık Baskısı, Venöz Staz ve Trombüs [The Retinal Atlas]"
    },
    139: {
        "kw": ["macular edema brvo", "vibrant", "bravo"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p182_fig198.png",
        "caption": "📷 SD-OKT Takibi: BRVO'ya Bağlı Kistik Makula Ödemi ve Anti-VEGF Sonrası Rezolüsyon [AAO BCSC Retina]"
    },
    140: {
        "kw": ["central retinal vein occlusion", "crvo", "blood and thunder"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p184_fig201.jpeg",
        "caption": "📷 Renkli Fundus Fotoğrafı: Santral Retinal Ven Tıkanıklığı (CRVO) ve Kan Fırtınası Manzarası [AAO BCSC Retina]"
    },
    141: {
        "kw": ["neovascular glaucoma", "rubeosis iridis", "100-day glaucoma"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p186_fig204.jpeg",
        "caption": "📷 Ön Segment Biyomikroskopisi: İskemik CRVO Sonrası 100 Gün Glokomu ve Rubeozis İridis [AAO BCSC Retina]"
    },
    142: {
        "kw": ["copernicus", "galileo", "score trial crvo"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p188_fig207.png",
        "caption": "📷 Klinik Çalışma Grafiği: COPERNICUS ve GALILEO - İskemik Olmayan CRVO'da Görme Keskinliği Artışı [AAO BCSC Retina]"
    },
    143: {
        "kw": ["hemiretinal vein occlusion", "hrvo"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p190_fig210.jpeg",
        "caption": "📷 Renkli Fundus: Hemi-Santral Retinal Ven Tıkanıklığı (HRVO) ve Hemisferik Dağılım [AAO BCSC Retina]"
    },
    # Arter Tıkanıklıkları
    145: {
        "kw": ["central retinal artery occlusion", "crao", "cherry-red spot"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p177_fig189.jpeg",
        "caption": "📷 Renkli Fundus Fotoğrafı: Santral Retinal Arter Tıkanıklığı (CRAO) ve Kiraz Kırmızısı Fovea [AAO BCSC Retina]"
    },
    146: {
        "kw": ["paracentesis", "anterior chamber paracentesis", "crao emergency"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p178_fig192.png",
        "caption": "📷 Acil Klinik Algoritma: CRAO'da Ön Kamara Parasentezi ve Göz İçi Basınç Düşürme [AAO BCSC Retina]"
    },
    147: {
        "kw": ["giant cell arteritis", "temporal arteritis", "arteritic crao"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p179_fig194.jpeg",
        "caption": "📷 Biyopsi & FFA: Dev Hücreli Arterit İlişkili Arteritik CRAO ve Koroid Dolum Gecikmesi [AAO BCSC Retina]"
    },
    148: {
        "kw": ["cilioretinal artery occlusion", "cilioretinal sparing"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p178_fig191.png",
        "caption": "📷 Renkli Fundus & SD-OKT: Silioretinal Arter Korunumu (Cilioretinal Sparing) ile Makula Yaşamı [AAO BCSC Retina]"
    },
    149: {
        "kw": ["branch retinal artery occlusion", "brao", "hollenhorst plaque"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p177_fig190.png",
        "caption": "📷 Renkli Fundus: Branş Retinal Arter Tıkanıklığı (BRAO), Sektörel İskemi ve Hollenhorst Plağı [AAO BCSC Retina]"
    },
    150: {
        "kw": ["embolus types", "calcific embolus", "talc retinopathy"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p670_fig2350.jpeg",
        "caption": "📷 Yüksek Büyütme Fundus: Retinal Emboli Tipleri (Kolesterol, Kalsiyum ve Trombosit Plakları) [The Retinal Atlas]"
    },
    151: {
        "kw": ["carotid doppler", "echocardiogram", "cardiac embolism"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p179_fig193.png",
        "caption": "📷 Sistemik Tanı Paneli: Karotis Renkli Doppler USG ve Transtorasik Ekokardiyografi [AAO BCSC Retina]"
    },
    # Diğer Vasküler Patolojiler (OİS, Coats, MacTel, ROP)
    153: {
        "kw": ["ocular ischemic syndrome", "ois", "carotid artery stenosis"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p192_fig214.jpeg",
        "caption": "📷 Renkli Fundus: Oküler İskemik Sendrom (OİS), Orta Perifer Dot-Blot Kanamalar [AAO BCSC Retina]"
    },
    154: {
        "kw": ["ois vs crvo", "asymmetric retinopathy"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p193_fig215.png",
        "caption": "📷 Ayırıcı Tanı Kılavuzu: OİS ile CRVO ve Diyabetik Retinopati Klinik Karşılaştırması [AAO BCSC Retina]"
    },
    155: {
        "kw": ["coats disease", "telangiectasia", "lightbulb aneurysms"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p194_fig218.jpeg",
        "caption": "📷 Renkli Fundus: Coats Hastalığında Ampul Telenjiektaziler ve Masif Subretinal Lipid [AAO BCSC Retina]"
    },
    156: {
        "kw": ["coats staging", "exudative retinal detachment coats"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p195_fig220.png",
        "caption": "📷 Tedavi ve Evreleme: Coats Hastalığında Kriyoterapi ve Lazer Fotokoagülasyon Protokolü [AAO BCSC Retina]"
    },
    157: {
        "kw": ["mactel 2", "macular telangiectasia type 2", "right-angle venules"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p196_fig222.jpeg",
        "caption": "📷 Renkli Fundus & FAF: MacTel Tip 2'de Temporal Şeffaflık Kaybı ve Dik Açılı Venüller [AAO BCSC Retina]"
    },
    158: {
        "kw": ["mactel oct cavitation", "ilm drape"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p197_fig224.png",
        "caption": "📷 SD-OKT Kesiti: MacTel Tip 2'de İLM Drape İşareti ve İç/Dış Retinal Hiporreflektif Kavitasyonlar [AAO BCSC Retina]"
    },
    159: {
        "kw": ["retinopathy of prematurity", "rop two-phase", "hyperoxia"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p198_fig226.png",
        "caption": "📷 Patofizyolojik Şema: ROP İki Fazlı Mekanizma (Hiperoksiye Bağlı Faz 1 ve Hipoksik Faz 2) [AAO BCSC Retina]"
    },
    160: {
        "kw": ["icrop 3", "rop zones", "plus disease"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p200_fig230.png",
        "caption": "📷 ICROP 3 Şeması: Zon I-III Sınırları, Evre 1-5 ve Patognomonik Plus Hastalığı [AAO BCSC Retina]"
    },
    161: {
        "kw": ["beat-rop", "laser vs bevacizumab rop"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p202_fig234.png",
        "caption": "📷 Klinik Kanıt ve Tedavi: BEAT-ROP Çalışması - Zon I Hastalıkta Anti-VEGF ve Lazer Karşılaştırması [AAO BCSC Retina]"
    },
    162: {
        "kw": ["sickle cell retinopathy", "sea-fan", "salmon patch"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p204_fig238.jpeg",
        "caption": "📷 Renkli Fundus & FA: Orak Hücreli Retinopatide Deniz Yelpazesi (Sea-Fan) Neovaskülarizasyonu [AAO BCSC Retina]"
    },
    # Bölüm 4: YBMD, Kuru Tip, Yaş Tip, PCV, SSKR, Pakikoroit
    167: {
        "kw": ["age-related macular degeneration", "armd", "cfh gene"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p064_fig039.jpeg",
        "caption": "📷 Epidemiyoloji ve Genetik: Kompleman Faktör H (CFH Y402H) ve ARMS2/HTRA1 Risk Profili [AAO BCSC Retina]"
    },
    168: {
        "kw": ["soft drusen", "hard drusen", "confluent drusen"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p066_fig041.jpeg",
        "caption": "📷 Renkli Fundus & SD-OKT: Erken ve Orta YBMD'de Yumuşak Birleşik Drusen Kümeleri [AAO BCSC Retina]"
    },
    169: {
        "kw": ["reticular pseudodrusen", "subretinal drusenoid", "sdd"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p067_fig042.png",
        "caption": "📷 Yakın Kızılötesi & SD-OKT: Retiküler Psödodrusen (Subretinal Drusenoid Birikintiler - SDD) [AAO BCSC Retina]"
    },
    170: {
        "kw": ["geographic atrophy", "ga progression", "rpe loss"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p069_fig044.jpeg",
        "caption": "📷 Renkli Fundus & FAF: İleri Kuru Tip YBMD'de Coğrafi Atrofi (GA) ve Koroid Damarlarının Belirginleşmesi [AAO BCSC Retina]"
    },
    171: {
        "kw": ["pegcetacoplan", "avacincaptad", "complement c3 c5"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p071_fig047.png",
        "caption": "📷 Landmark Faz III Kanıtı: OAKS/DERBY ve GATHER - GA İlerlemesini Yavaşlatan Kompleman İnhibitörleri [AAO BCSC Retina]"
    },
    172: {
        "kw": ["areds 2 formulation", "lutein zeaxanthin", "zinc"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p073_fig050.png",
        "caption": "📷 Klinik Kılavuz: AREDS 2 Formülasyonu (Lutein/Zeaksantin, C/E Vitamini, Çinko, Bakır) [AAO BCSC Retina]"
    },
    174: {
        "kw": ["neovascular amd", "mnv classification", "conan"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p074_fig051.png",
        "caption": "📷 Konsensüs Sınıflaması: Makuler Neovaskülarizasyon (MNV Tip 1, Tip 2 ve Tip 3) Mimarisi [AAO BCSC Retina]"
    },
    175: {
        "kw": ["type 1 mnv", "sub-rpe neovascularization", "occult mnv"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p076_fig053.png",
        "caption": "📷 SD-OKT & ICGA: Tip 1 (Sub-RPE) MNV, Çift Katman Belirtisi (Double-Layer Sign) [AAO BCSC Retina]"
    },
    176: {
        "kw": ["type 2 mnv", "subretinal neovascularization", "classic mnv"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p077_fig054.png",
        "caption": "📷 SD-OKT & FA: Tip 2 (Subretinal / Klasik) MNV, RPE Üstü Membran ve Erken Dantel Floresansı [AAO BCSC Retina]"
    },
    177: {
        "kw": ["type 3 mnv", "retinal angiomatous proliferation", "rap"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p079_fig058.png",
        "caption": "📷 SD-OKT & OKTA: Tip 3 MNV (Retinal Anjiyomatöz Proliferasyon - RAP) İntraretinal Anastomozları [AAO BCSC Retina]"
    },
    178: {
        "kw": ["treat-and-extend", "prn vs t&e", "anti-vegf regimen"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p081_fig062.png",
        "caption": "📷 Uygulama Protokolü: Treat-and-Extend Rejimi ile Sıvısız Makula ve Enjeksiyon Aralığı Uzatılması [AAO BCSC Retina]"
    },
    179: {
        "kw": ["faricimab", "tenaya", "lucerne", "dual inhibition"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p082_fig064.png",
        "caption": "📷 Landmark Faz III Kanıtı: TENAYA ve LUCERNE - Faricimab (Ang-2/VEGF-A) 16 Haftalık Uzatılmış Aralık [AAO BCSC Retina]"
    },
    180: {
        "kw": ["port delivery system", "susvimo", "refillable implant"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p083_fig066.png",
        "caption": "📷 Cerrahi Teknoloji: Port Delivery System (PDS / Susvimo) ile Sürekli Ranibizumab Salımı [AAO BCSC Retina]"
    },
    181: {
        "kw": ["disciform scar", "fibrotic scar", "end-stage amd"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p084_fig068.jpeg",
        "caption": "📷 Renkli Fundus & SD-OKT: Son Evre Diskiform Skar, Subretinal Fibrozis ve Kalıcı Fotoreseptör Hasarı [AAO BCSC Retina]"
    },
    184: {
        "kw": ["pcv polypoidal", "icga polyps", "aneurysmal dilatations"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p085_fig070.jpeg",
        "caption": "📷 ICGA Altın Standart: Polipoidal Koroidal Vaskülopati (PCV) Anevrizmatik Nodülleri [AAO BCSC Retina]"
    },
    185: {
        "kw": ["pcv diagnostic criteria", "sharp peaked ped", "notch sign"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p086_fig072.png",
        "caption": "📷 Non-ICGA SD-OKT Kriterleri: Keskin Tepeli PED (Sharp-Peaked PED) ve Çentik Belirtisi (Notch Sign) [AAO BCSC Retina]"
    },
    186: {
        "kw": ["everest ii", "planet trial", "pdt vs anti-vegf"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p087_fig074.png",
        "caption": "📷 Klinik Çalışma Sonuçları: EVEREST II ve PLANET - Kombine PDT + Anti-VEGF Polip Kapanma Üstünlüğü [AAO BCSC Retina]"
    },
    187: {
        "kw": ["photodynamic therapy", "verteporfin pdt", "cold laser"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p088_fig076.png",
        "caption": "📷 Tedavi Mimarisi: Verteporfin ile Fotodinamik Tedavi (PDT), Reaktif Oksijen ve Koryokapillaris Oklüzyonu [AAO BCSC Retina]"
    },
    188: {
        "kw": ["central serous chorioretinopathy", "cscr", "thick choroid"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p090_fig080.jpeg",
        "caption": "📷 Renkli Fundus & EDI-OKT: Santral Seröz Koryoretinopati (SSKR), Makuler Seröz Dekolman ve Pakikoroit [AAO BCSC Retina]"
    },
    189: {
        "kw": ["smokestack leak", "ink-blot leak", "cscr fa"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p092_fig084.jpeg",
        "caption": "📷 Floresein Anjiyografi (FA): Klasik Duman Bacası (Smokestack) ve Mürekkep Lekesi (Ink-Blot) Kaçağı [AAO BCSC Retina]"
    },
    190: {
        "kw": ["half-dose pdt", "cscr treatment", "mineralocorticoid"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p094_fig088.png",
        "caption": "📷 Klinik Tedavi Protokolü: Kronik SSKR'de Yarım Doz Verteporfin PDT Sonrası Subretinal Sıvı Rezolüsyonu [AAO BCSC Retina]"
    },
    191: {
        "kw": ["pachychoroid spectrum", "pachyvessels", "ppe"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p096_fig092.png",
        "caption": "📷 Hastalık Spektrumu: Pakikoroit Pigment Epitelyopatisi (PPE), SSKR, PNV ve PCV Evreleri [AAO BCSC Retina]"
    },
    192: {
        "kw": ["pachychoroid pigment epitheliopathy", "ppe", "attenuated cc"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p097_fig094.png",
        "caption": "📷 EDI-OKT Kesiti: Pakikoroit Pigment Epitelyopatisinde Pakivesel Üstü RPE Değişiklikleri [AAO BCSC Retina]"
    },
    193: {
        "kw": ["pachychoroid neovasculopathy", "pnv", "shallow irregular ped"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p098_fig096.png",
        "caption": "📷 En-Face OKTA & EDI-OKT: Pakikoroit Neovaskülopatide (PNV) Sığ Düzensiz PED ve Tip 1 MNV Ağı [AAO BCSC Retina]"
    },
    194: {
        "kw": ["focal choroidal excavation", "fce", "conforming fce"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p100_fig100.png",
        "caption": "📷 EDI-OKT Biyobelirteci: Uyumlu (Conforming) ve Uyumsuz (Non-conforming) Fokal Koroidal Ekskavasyon [AAO BCSC Retina]"
    },
    195: {
        "kw": ["macular hole", "ftmh", "gass classification"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p210_fig250.jpeg",
        "caption": "📷 SD-OKT Kesiti: Tam Kat Makula Deliği (FTMH), Kistik Kenarlar ve Operkulum [AAO BCSC Retina]"
    },
    196: {
        "kw": ["vitreomacular traction", "vmt", "foveal traction"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p212_fig254.jpeg",
        "caption": "📷 SD-OKT İncelemesi: Vitreomakuler Traksiyon (VMT), Foveal Çekinti ve İç Retinal Bozulma [AAO BCSC Retina]"
    },
    197: {
        "kw": ["epiretinal membrane", "erm", "macular pucker"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p214_fig258.jpeg",
        "caption": "📷 SD-OKT & Renkli Fundus: Epiretinal Membran (ERM / Selofan Makulopati), Retina Kırışıklıkları [AAO BCSC Retina]"
    },
    198: {
        "kw": ["ilm peeling", "inverted flap", "macular hole surgery"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p216_fig262.png",
        "caption": "📷 Cerrahi Teknik: Büyük Makula Deliklerinde İLM Soyulması ve İnverted İLM Flep Tekniği [AAO BCSC Retina]"
    },
    199: {
        "kw": ["myopic traction maculopathy", "myopic foveoschisis"],
        "fallback_fn": "12-Retina_and_Vitreous_2025-2026_p218_fig266.png",
        "caption": "📷 Yüksek Miyopi SD-OKT: Miyopik Traksiyon Makulopatisi, Foveoşizis ve Posterior Stafilom [AAO BCSC Retina]"
    },
    200: {
        "kw": ["angioid streaks", "pseudoxanthoma elasticum", "peau d'orange"],
        "fallback_fn": "THE_RETINAL_ATLAS_2nd_Ed__p180_fig0620.jpeg",
        "caption": "📷 Renkli Fundus & FAF: Anjiyoid Çizgiler (Angioid Streaks), Peau d'Orange ve Bruch Çatlakları [The Retinal Atlas]"
    }
}

# 6. Execute Slide Revision and Shape Cleanup
success_count = 0
phantom_cleaned_count = 0
error_count = 0

print("\n" + "=" * 80)
print(">> SLAYT BAZINDA GÖRSEL YENİLEME VE HAYALET METİN TEMİZLİĞİ BAŞLIYOR...")
print("=" * 80)

for slide_idx in range(1, 201):
    slide = prs.slides[slide_idx - 1]
    
    # 6.1 Clean Phantom Text in Cards
    # Shape 0, 4, 6, 7, 10, 11, 14, 15, 18 etc. that duplicate slide title
    slide_title = ""
    for shp in slide.shapes:
        if shp.name == "Slide Title" or (shp.has_text_frame and not slide_title and len(shp.text_frame.text.strip()) > 5 and not shp.text_frame.text.strip().startswith("●  BÖLÜM")):
            slide_title = shp.text_frame.text.strip().split("\n")[0]
            
    for shp in slide.shapes:
        if shp.has_text_frame and shp.name != "Slide Title" and shp.name != "Category Badge":
            txt = shp.text_frame.text.strip()
            # If shape text is literally identical to slide title, clear it!
            if txt and slide_title and txt == slide_title and shp.shape_type != 14: # not placeholder
                shp.text_frame.text = ""
                phantom_cleaned_count += 1

    # 6.2 Check if this slide needs image revision
    if slide_idx not in precise_mappings:
        continue

    spec = precise_mappings[slide_idx]
    target_item = None

    # Try fallback filename first if exists
    fallback_fn = spec.get("fallback_fn")
    if fallback_fn:
        target_item = get_by_filename(fallback_fn)

    # If not found, search elephant pool
    if not target_item:
        target_item = search_elephant(spec["kw"], exclude_used=used_images)

    if not target_item or not os.path.exists(target_item["file_path"]):
        print(f"  [UYARI] S{slide_idx:03d}: Hedef görsel bulunamadı ({fallback_fn})")
        continue

    used_images.add(target_item["filename"])
    new_img_path = get_safe_rgb_path(target_item["file_path"])
    new_caption = spec["caption"]

    # 6.3 Find existing picture shape and caption shape
    pic_shape = None
    cap_shape = None

    for shp in slide.shapes:
        if shp.shape_type == 13: # Picture
            pic_shape = shp
        if shp.has_text_frame and ("📷" in shp.text_frame.text or "Şekil" in shp.text_frame.text or "Atlas" in shp.text_frame.text or "Klinik Referans" in shp.text_frame.text):
            cap_shape = shp

    try:
        im = Image.open(str(new_img_path))
        orig_w, orig_h = im.size

        # Scale with aspect ratio
        scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
        disp_w = Inches(orig_w / 96.0) * scale
        disp_h = Inches(orig_h / 96.0) * scale
        img_x = right_x + (right_w - disp_w) / 2
        img_y = img_area_y + (max_img_h - disp_h) / 2

        # Remove old picture if exists
        if pic_shape:
            sp_elem = pic_shape._element
            sp_elem.getparent().remove(sp_elem)

        # Insert new high-resolution picture
        slide.shapes.add_picture(str(new_img_path), img_x, img_y, width=disp_w, height=disp_h)

        # Update or create caption
        if cap_shape:
            cap_shape.text_frame.text = new_caption
            p = cap_shape.text_frame.paragraphs[0]
            p.font.name = "Arial"
            p.font.size = Pt(7.8)
            p.font.bold = True
            p.font.color.rgb = RGBColor(15, 30, 54) # Deep Navy
        else:
            # Add caption below picture if missing
            cap_box = slide.shapes.add_textbox(right_x, img_y + disp_h + Inches(0.08), right_w, Inches(0.6))
            tf = cap_box.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            p.text = new_caption
            p.font.name = "Arial"
            p.font.size = Pt(7.8)
            p.font.bold = True
            p.font.color.rgb = RGBColor(15, 30, 54)

        success_count += 1
        if success_count % 15 == 0 or slide_idx in [4, 8, 9, 14, 25, 29, 30, 50, 100, 145, 148, 149, 174, 184, 188]:
            print(f"  [REVİZE EDİLDİ] S{slide_idx:03d}: {target_item['filename'][:30]} -> {new_caption[:45]}...")

    except Exception as e:
        print(f"  [HATA] S{slide_idx:03d} işlenirken hata: {e}")
        error_count += 1

print("\n" + "=" * 80)
print(f">> REVİZYON TAMAMLANDI:")
print(f"   - Başarıyla Yenilenen Görsel Sayısı: {success_count}")
print(f"   - Temizlenen Hayalet Metin (Phantom Box) Sayısı: {phantom_cleaned_count}")
print(f"   - Hata Sayısı: {error_count}")
print("=" * 80)

# 7. Kaydet ve Eşitle
temp_out = BASE_DIR / "Retina_Masterclass_Goldfish_Temp.pptx"
print(f"\n>> Geçici sunum dosyası kaydediliyor: {temp_out.name}...")
prs.save(str(temp_out))
print(f">> Geçici dosya boyutu: {temp_out.stat().st_size / (1024*1024):.2f} MB")

# Masaüstü ana dosyasını güncelle
print(f">> Masaüstü sunum dosyası güncelleniyor: {PPTX_DESKTOP.name}...")
for retry in range(5):
    try:
        shutil.move(str(temp_out), str(PPTX_DESKTOP))
        print(">> Masaüstü dosyası başarıyla güncellendi.")
        break
    except Exception as me:
        print(f"  Masaüstü taşıma yeniden deneniyor ({retry+1}/5): {me}")
        time.sleep(2)

# Google Drive'a eşitle
print(f">> Google Drive dosyası eşitleniyor: {PPTX_DRIVE}...")
for retry in range(5):
    try:
        shutil.copy2(str(PPTX_DESKTOP), str(PPTX_DRIVE))
        print(">> Google Drive dosyası başarıyla eşitlendi.")
        break
    except Exception as de:
        print(f"  Google Drive eşitleme yeniden deneniyor ({retry+1}/5): {de}")
        time.sleep(3)

print("=" * 80)
print(">>> İŞLEM TAMAMLANDI: TÜM GÖRSELLER VE SLAYTLAR SENKRONİZE EDİLDİ")
print("=" * 80)
