"""
1000 Sayfalık Akademik Kitap Üretim Pipeline Konfigürasyonu.
Kaynak: C:/Users/gezic/OneDrive/Desktop/DATABASE/Ophthalmology KİTAPLARI
Mimari: LangGraph + Hibrit Model (Gemini Flash + Claude Sonnet / Gemini Pro)
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = Path(__file__).parent.resolve()
DEFAULT_DB_SOURCE = Path(r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI")


@dataclass
class BookScaleConfig:
    """
    1000 sayfalık akademik tıp/oftalmoloji kitabı için ölçekleme matematiği:
    - Akademik dizgide 1 sayfa ≈ 400 - 450 kelime (tablolar ve klinik kutular dahil).
    - 1000 sayfa ≈ 420.000 kelime.
    - LLM'lerin tek seferde en yüksek kalitede ürettiği uzunluk: 1.000 - 1.200 kelime (~2.5 sayfa).
    - Bu nedenle kitap 3 katmanlı hiyerarşik ağaca bölünür:
      12 Ana Kısım (Part) x ~6-7 Bölüm (Chapter) = 80 Bölüm
      80 Bölüm x 5 Alt-Bölüm (Subsection / Yaprak Düğüm) = 400 Alt-Bölüm
      400 Alt-Bölüm x ~1.050 kelime = 420.000 kelime (~1.000 Sayfa)
    """
    book_title: str = "Kapsamlı Klinik ve Cerrahi Oftalmoloji: Güncel Kanıta Dayalı Başvuru Kitabı"
    language: str = "Türkçe (Uluslararası Tıbbi Terminoloji Parantez İçinde İngilizce)"
    target_total_pages: int = 1000
    words_per_page: int = 420
    num_parts: int = 12
    chapters_per_part: int = 7       # Toplam ~84 Bölüm
    subsections_per_chapter: int = 5 # Toplam ~420 Alt-Bölüm (Yaprak Düğüm)
    target_words_per_subsection: int = 1050
    min_words_per_subsection: int = 850
    max_revisions_per_subsection: int = 2


@dataclass
class HybridModelConfig:
    """
    Google AI Ultra Kredilerini/Kotalarını Optimize Eden Hibrit Model Dağılımı:
    - Hızlı/Yüksek Hacimli Düğümler (Sorgu üretimi, RAG kanıt sentezleme, Eleştirmen, Bellek özeti):
      Gemini Flash (Düşük maliyet, yüksek hız, geniş context).
    - Derin Akademik Yazım & Müfredat Tasarımı Düğümleri:
      Vertex AI üzerinden Claude Sonnet veya Gemini Pro.
    """
    provider_mode: str = os.getenv("MODEL_PROVIDER_MODE", "google_ai_studio")
    # Seçenekler: "google_ai_studio" (API Key ile) veya "vertex_ai" (Google Cloud Kredileri + Claude desteği ile)
    gcp_project_id: str = os.getenv("GCP_PROJECT_ID", "")
    gcp_location: str = os.getenv("GCP_LOCATION", "us-east5")

    # 1. Hızlı İşçi Model (Sorgu, Kanıt Sentezi, Kalite Kontrol, Özetleme) - %75 token yükünü taşır
    fast_model_name: str = os.getenv("FAST_MODEL_NAME", "gemini-2.5-flash")

    # 2. Baş Yazar & Mimar Model (Anahat Tasarımı ve Akademik Bölüm Yazımı) - %25 kritik yükü taşır
    # Vertex AI kullanıyorsanız "claude-sonnet-4@20250514" veya "gemini-2.5-pro" seçebilirsiniz
    writer_model_name: str = os.getenv("WRITER_MODEL_NAME", "gemini-2.5-pro")

    # Embedding Modeli (PDF vektörleştirme için)
    embedding_model_name: str = os.getenv("EMBEDDING_MODEL_NAME", "models/text-embedding-004")

    # 3. $100 WPS / VPS Ek Kota ve Uzak Uç Nokta (Gateway / Sunucu) Ayarları
    wps_quota_budget_usd: float = float(os.getenv("WPS_QUOTA_BUDGET_USD", "100.0"))
    wps_api_base_url: str = os.getenv("WPS_API_BASE_URL", "")
    wps_api_key: str = os.getenv("WPS_API_KEY", "")
    wps_model_name: str = os.getenv("WPS_MODEL_NAME", "")
    parallel_workers: int = int(os.getenv("PARALLEL_WORKERS", "1"))

    # Kota dostu hız sınırlayıcı (Rate Limit koruması)
    requests_per_minute_limit: int = int(os.getenv("RPM_LIMIT", "30"))


@dataclass
class PipelinePaths:
    source_pdf_dir: Path = Path(os.getenv("SOURCE_PDF_DIR", str(DEFAULT_DB_SOURCE)))
    storage_dir: Path = BASE_DIR / "storage"
    chroma_dir: Path = BASE_DIR / "storage" / "chroma_db"
    bm25_index_path: Path = BASE_DIR / "storage" / "bm25_corpus.pkl"
    checkpoint_db_path: Path = BASE_DIR / "storage" / "langgraph_checkpoints.sqlite"
    blueprint_path: Path = BASE_DIR / "storage" / "book_blueprint.json"
    ledger_path: Path = BASE_DIR / "storage" / "global_memory_ledger.json"
    output_dir: Path = BASE_DIR / "output"
    chapters_dir: Path = BASE_DIR / "output" / "chapters"
    compiled_dir: Path = BASE_DIR / "output" / "compiled"

    def ensure_dirs(self) -> None:
        for d in [self.storage_dir, self.chroma_dir, self.output_dir, self.chapters_dir, self.compiled_dir]:
            d.mkdir(parents=True, exist_ok=True)


SCALE_CONFIG = BookScaleConfig()
MODEL_CONFIG = HybridModelConfig()
PATHS = PipelinePaths()
