"""
Model katmanı: Tek fonksiyonla prompt dosyası -> LLM -> (metin | JSON | Pydantic) + maliyet kaydı.

    from bookgraph.llm import ask
    text = ask("section/write", book="kitap", unit="P01-C01-S01", title=..., ...)

* Zincir: prompt dosyasındaki `models:` veya `role:` -> settings.MODELS.<role>
  İlk model birincil; hata/kota (429) durumunda LangChain `with_fallbacks` sıradakine geçer.
* Bütçe: harcama ECONOMY_THRESHOLD'u geçerse `writer` rolü otomatik `fast` zincirine düşer.
* Maliyet: yanıtın `usage_metadata` değeri (gerçek token) usage.py defterine yazılır.
* Retry: Burada bilerek elle retry DÖNGÜSÜ YOK. Geçici hataları LangGraph düğümündeki
  `RetryPolicy` yakalar (bkz. core.py -> RETRY).
"""

from __future__ import annotations

import json
import logging
import re
import os
import uuid
from functools import lru_cache
from typing import Any, List, Optional, Type

from pydantic import BaseModel

from . import usage
from .prompting import Prompt, load_prompt
from .settings import MODELS

log = logging.getLogger("bookgraph.llm")


# ---------------------------------------------------------------------------
# Tek model oluşturma
# ---------------------------------------------------------------------------

def _build(spec: str, temperature: float, max_tokens: int, json_mode: bool):
    provider, _, model = spec.partition(":")
    if not model:
        provider, model = "google", provider

    if provider == "google":
        import os
        from langchain_google_genai import ChatGoogleGenerativeAI
        kwargs = dict(model=model, temperature=temperature, max_output_tokens=max_tokens, max_retries=0)
        if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").strip().lower() in ("1", "true", "yes"):
            if model.startswith(("gemini-3", "gemini-4")):
                kwargs["location"] = "global"
        if json_mode:
            kwargs["response_mime_type"] = "application/json"
        return ChatGoogleGenerativeAI(**kwargs)

    if provider == "vertex":
        if "claude" in model.lower():
            from langchain_google_vertexai.model_garden import ChatAnthropicVertex
            return ChatAnthropicVertex(model_name=model, project=MODELS.gcp_project, location=MODELS.gcp_location,
                                       temperature=temperature, max_output_tokens=max_tokens, max_retries=0)
        from langchain_google_vertexai import ChatVertexAI
        return ChatVertexAI(model_name=model, project=MODELS.gcp_project, location=MODELS.gcp_location,
                            temperature=temperature, max_output_tokens=max_tokens, max_retries=0)

    if provider == "bedrock":
        from langchain_aws import ChatBedrockConverse
        return ChatBedrockConverse(model=model, region_name=MODELS.aws_region,
                                   credentials_profile_name=MODELS.aws_profile or None,
                                   temperature=temperature, max_tokens=max_tokens)

    if provider == "wps":
        if not (MODELS.wps_base_url and MODELS.wps_api_key):
            raise RuntimeError("wps sağlayıcısı için WPS_API_BASE_URL ve WPS_API_KEY gerekli")
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=model, base_url=MODELS.wps_base_url, api_key=MODELS.wps_api_key,
                          temperature=temperature, max_tokens=max_tokens, max_retries=0)

    raise ValueError(f"Bilinmeyen sağlayıcı: '{provider}' (google | vertex | bedrock | wps)")


def resolve_chain(prompt: Prompt, *, disable_economy: bool = False) -> List[str]:
    specs = list(prompt.models or getattr(MODELS, prompt.role, MODELS.fast))
    # Explicitly requested Argon must not be silently downgraded by budget mode.
    if not disable_economy and not prompt.models and prompt.role == "writer" and not any("gemini-4-argon" in s for s in specs):
        if usage.economy_mode():
            return list(MODELS.fast)
    return specs


def _provider(spec):
    prefix = spec.partition(":")[0]
    if prefix == "google" and os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").lower() in {"1", "true", "yes"}:
        return "vertex"
    return prefix


# ---------------------------------------------------------------------------
# JSON yardımcıları
# ---------------------------------------------------------------------------

def extract_json(raw_text: str) -> Any:
    text = raw_text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", text)
        if m:
            return json.loads(m.group(1))
        raise


def _content_text(msg) -> str:
    c = getattr(msg, "content", msg)
    if isinstance(c, list):
        return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in c)
    return str(c)


def _log_usage(msg, specs: List[str], book: str, unit: str, prompt_name: str, *, run_id=None, status="SUCCESS"):
    metadata = getattr(msg, "response_metadata", None) or {}
    tokens = getattr(msg, "usage_metadata", None) or {}
    actual = metadata.get("model_version") or metadata.get("modelVersion") or metadata.get("model_name") or "unknown"
    provider_id = metadata.get("response_id") or metadata.get("responseId")
    # A LangChain lc_run-- id is not a Google response/request id.
    if provider_id and str(provider_id).startswith(("lc_run", "run-")):
        provider_id = None
    usage.record(book, unit, prompt_name, specs[0], tokens.get("input_tokens"), tokens.get("output_tokens"),
                 requested_model=specs[0], actual_model=actual, provider=_provider(specs[0]),
                 provider_response_id=provider_id, langchain_run_id=getattr(msg, "id", None),
                 run_id=run_id, status=status if actual != "unknown" else "MODEL_UNVERIFIED",
                 model_identity_source="response_metadata" if actual != "unknown" else "unknown")
    return actual


def _assert_argon_identity(expected_model: str, response: Any) -> str:
    """Argon kimliğini sağlayıcı yanıt metadata'sından doğrular.

    Eğer expected_model içinde 'gemini-4-argon' varsa, yanıt metadata'sında bildirilen
    gerçek model kimliğinin 'gemini-4-argon' içerdiğini kontrol eder.
    Aksi hâlde ValueError fırlatır.
    Dönen gerçek model dizesini döndürür.
    """
    metadata = getattr(response, "response_metadata", None) or {}
    actual = (
        metadata.get("model_version")
        or metadata.get("modelVersion")
        or metadata.get("model_name")
        or "unknown"
    )
    if "gemini-4-argon" in expected_model:
        if actual == "unknown" or "gemini-4-argon" not in actual:
            raise ValueError(
                f"Argon zorunlu işte sağlayıcı yanıtı Argon kimliğini doğrulamadı (beklenen: '{expected_model}', dönen: '{actual}'); sonuç kabul edilmedi."
            )
    return actual


def ask(prompt_name: str, *, book: str = "default", unit: str = "", schema: Optional[Type[BaseModel]] = None,
        no_fallback: bool = False, argon_mandatory: Optional[bool] = None,
        disable_economy: bool = False, **variables: Any) -> Any:
    """Use the configured providers; no new provider or subscription is selected.

    Argon-first jobs are strict by default. Other fallback attempts are recorded.
    Identity is read from response metadata, never from the requested model.
    """
    prompt = load_prompt(prompt_name)
    messages = prompt.render(**variables)
    specs = resolve_chain(prompt, disable_economy=disable_economy)
    strict = bool(specs and "gemini-4-argon" in specs[0]) if argon_mandatory is None else argon_mandatory
    if strict:
        specs = [spec for spec in specs if "gemini-4-argon" in spec]
        if not specs:
            raise ValueError("Argon zorunlu fakat model zincirinde Argon yok.")
    if strict or no_fallback:
        specs = specs[:1]
    if not specs:
        raise ValueError("Boş model zinciri.")
    run_id = str(uuid.uuid4())
    json_mode = prompt.output == "json" and schema is None
    for index, spec in enumerate(specs):
        try:
            from phoenix_tracer import trace_model_call
            span_mgr = trace_model_call(prompt_name, book=book, unit=unit, requested_model=spec, run_id=run_id)
        except Exception:
            span_mgr = None

        import contextlib
        span_cm = span_mgr if span_mgr is not None else contextlib.nullcontext()
        with span_cm:
            try:
                model = _build(spec, prompt.temperature, prompt.max_tokens, json_mode)
                runnable = model.with_structured_output(schema, include_raw=True) if schema is not None else model
                result = runnable.invoke(messages)
            except Exception as error:
                if span_mgr:
                    span_mgr.record_error(error)
                usage.record(book, unit, prompt_name, spec, None, None,
                             requested_model=spec, provider=_provider(spec), run_id=run_id, status="FAILED")
                if index + 1 >= len(specs):
                    raise RuntimeError(f"{'Argon zorunlu çağrı' if strict else 'Model çağrısı'} başarısız; otomatik model değişikliği yapılmadı.") from error
                usage.log_fallback(run_id=run_id, book=book, unit=unit, prompt=prompt_name,
                                   from_model=spec, to_model=specs[index + 1], error=error)
                continue
            raw = result.get("raw") if schema is not None else result
            raw_meta = getattr(raw, "response_metadata", None) or {}
            reported = raw_meta.get("model_version") or raw_meta.get("modelVersion") or raw_meta.get("model_name") or "unknown"
            outcome = "MODEL_MISMATCH" if strict and reported != "unknown" and "gemini-4-argon" not in reported else "SUCCESS"
            if schema is not None and result.get("parsed") is None:
                outcome = "OUTPUT_INVALID"
            if span_mgr:
                span_mgr.set_attribute("llm.actual_model", reported)
                span_mgr.set_attribute("llm.status", outcome)
                span_mgr.set_attribute("llm.provider_response_id", raw_meta.get("response_id"))
            actual = _log_usage(raw, [spec], book, unit, prompt_name, run_id=run_id, status=outcome)
            if strict and "gemini-4-argon" not in actual:
                raise ValueError("Argon zorunlu işte sağlayıcı yanıtı Argon kimliğini doğrulamadı; sonuç kabul edilmedi.")
            if schema is not None:
                if result.get("parsed") is None:
                    raise ValueError("Yapılandırılmış çıktı ayrıştırılamadı; model değiştirilerek hata gizlenmedi.")
                return result["parsed"]
            text = _content_text(result).strip()
            return extract_json(text) if prompt.output == "json" else text
