"""Shared provenance for direct visual calls. No provider-specific fallback."""
import json
import re
from . import usage
from .llm import _assert_argon_identity
from phoenix_tracer import trace_model_call


def invoke_json(llm, messages, *, requested_model, book, unit, run_id, strict=False, validator=None):
    response = None
    actual = 'unknown'
    provider_id = None
    tokens = {}
    status = 'FAILED'
    identity_valid = False
    try:
        with trace_model_call(unit, book=book, unit=unit, requested_model=requested_model, run_id=run_id):
            response = llm.invoke(messages)
            metadata = getattr(response, 'response_metadata', {}) or {}
            actual = metadata.get('model_version') or metadata.get('modelVersion') or metadata.get('model_name') or 'unknown'
            provider_id = metadata.get('response_id') or metadata.get('responseId')
            if provider_id and str(provider_id).startswith(('lc_run', 'run-')):
                provider_id = None
            tokens = getattr(response, 'usage_metadata', {}) or {}
            status = 'MODEL_UNVERIFIED' if actual == 'unknown' else 'MODEL_MISMATCH'
            if strict:
                _assert_argon_identity(requested_model, response)
            identity_valid = True
            status = 'OUTPUT_INVALID'
            content = getattr(response, 'content', '')
            if not isinstance(content, str):
                raise ValueError('Expected JSON text response')
            match = re.search(r'\{[\s\S]*\}', content)
            if not match:
                raise ValueError('Missing JSON object')
            data = json.loads(match.group(0))
            if not isinstance(data, dict):
                raise ValueError('Expected JSON object')
            if validator:
                validator(data)
            status = 'SUCCESS' if actual != 'unknown' else 'MODEL_UNVERIFIED'
            return response, data
    finally:
        # Preserve usage even for identity failures and malformed JSON; no raw payloads.
        usage.record(book=book, unit=unit, prompt=unit, model=requested_model,
            input_tokens=tokens.get('input_tokens'), output_tokens=tokens.get('output_tokens'),
            requested_model=requested_model, actual_model=actual,
            provider='provider_response', provider_response_id=provider_id,
            langchain_run_id=getattr(response, 'id', None), run_id=run_id, status=status,
            model_identity_source='response_metadata' if actual != 'unknown' else 'unknown')
