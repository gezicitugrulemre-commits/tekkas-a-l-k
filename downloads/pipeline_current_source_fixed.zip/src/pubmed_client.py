"""
PubMed (NCBI E-Utilities) Canlı Klinik Araştırma ve Eksik Veri Tamamlama Modülü.

Veritabanındaki (Ryan's Retina vb.) kitap sayfalarında eksik kalan güncel klinik araştırmaları,
randomize kontrollü çalışmaları (RKÇ), kılavuzları (EULAR, ICROP3, AAO) ve sayısal verileri
PubMed üzerinden (`esearch.fcgi` + `efetch.fcgi`) çekerek `[PMID:xxxxxxxx]` atıflarıyla
LangGraph yazım düğümüne sunar.
"""

import json
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List

from config import PATHS

# Her başlık için optimize edilmiş PubMed MeSH / Klinik Arama Sorguları
TOPIC_PUBMED_QUERIES: Dict[str, str] = {
    "7.2.2": '(Behcet retinal vasculitis management EULAR) OR (Vogt-Koyanagi-Harada choroiditis ICGA treatment) OR (ocular sarcoidosis posterior uveitis diagnosis)',
    "7.3.1": '"multiple evanescent white dot syndrome" OR MEWDS multimodal imaging OCT autofluorescence natural course',
    "7.3.2": '"acute posterior multifocal placoid pigment epitheliopathy" OR APMPPE multimodal imaging cerebral vasculitis',
    "7.3.3": '"birdshot chorioretinopathy" AND (HLA-A29 OR multimodal imaging OR electroretinography)',
    "7.3.4": '"multifocal choroiditis" AND ("punctate inner choroidopathy" OR multimodal imaging)',
    "7.3.5": '"serpiginous choroiditis" AND (tuberculosis OR multimodal imaging OR autofluorescence)',
    "7.3.6": '"white dot syndromes" AND (MEWDS OR APMPPE OR birdshot OR "multifocal choroiditis")',
    "8.1.1": 'retinoblastoma AND ("intra-arterial chemotherapy" OR RB1 OR classification)',
    "8.1.2": '("choroidal melanoma" AND genetics) OR ("vitreoretinal lymphoma" AND masquerade)',
    "8.1.3": '("choroidal nevus" AND melanoma) OR ("choroidal hemangioma" AND photodynamic)',
    "10.1.1": '("commotio retinae" OR "choroidal rupture" OR "intraocular foreign body") AND retina',
    "10.1.2": '"intravitreal injection" AND endophthalmitis AND povidone-iodine',
    "10.2.1": '"deep learning" AND ("diabetic retinopathy" OR "macular degeneration") AND teleophthalmology',
    "10.2.2": '("retinal pigment epithelium" AND "stem cell" AND clinical trial) OR ("retinal prosthesis" AND vision)',
}


def build_pubmed_query(topic_id: str, topic_title: str) -> str:
    if topic_id in TOPIC_PUBMED_QUERIES:
        return TOPIC_PUBMED_QUERIES[topic_id]
    # Genel yedek sorgu üretici
    cleaned = topic_title.replace("(", " ").replace(")", " ").replace(":", " ").replace(",", " ")
    return f"({cleaned}) AND (retina OR choroid OR ophthalmology) AND (review[Filter] OR clinicaltrial[Filter])"


def fetch_pubmed_evidence(topic_id: str, topic_title: str, max_articles: int = 5) -> List[Dict]:
    """
    Belirtilen konu başlığı için PubMed'den en alakalı makale özetlerini (Abstract)
    ve PMID numaralarını çeker, önbelleğe (`storage/pubmed/{topic_id}.json`) kaydeder.
    """
    PATHS.ensure_dirs()
    pubmed_dir = PATHS.storage_dir / "pubmed"
    pubmed_dir.mkdir(parents=True, exist_ok=True)
    cache_path = pubmed_dir / f"{topic_id}.json"

    if cache_path.exists():
        cached = json.loads(cache_path.read_text(encoding="utf-8"))
        if cached.get("articles"):
            return cached["articles"]

    query = build_pubmed_query(topic_id, topic_title)
    esearch_params = urllib.parse.urlencode({
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": str(max_articles),
        "sort": "relevance",
    })
    esearch_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?{esearch_params}"

    headers = {"User-Agent": "AntiGravityRetinaBookPipeline/1.0 (Academic Medical Research)"}
    pmids: List[str] = []

    for attempt in range(3):
        try:
            req = urllib.request.Request(esearch_url, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                pmids = data.get("esearchresult", {}).get("idlist", [])
                break
        except Exception:
            time.sleep(1.5 * (attempt + 1))

    if not pmids:
        return []

    time.sleep(0.4)  # NCBI E-utilities hız sınırı koruması
    efetch_params = urllib.parse.urlencode({
        "db": "pubmed",
        "id": ",".join(pmids),
        "retmode": "xml",
    })
    efetch_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?{efetch_params}"

    xml_bytes = b""
    for attempt in range(3):
        try:
            req = urllib.request.Request(efetch_url, headers=headers)
            with urllib.request.urlopen(req, timeout=25) as resp:
                xml_bytes = resp.read()
                break
        except Exception:
            time.sleep(1.5 * (attempt + 1))

    if not xml_bytes:
        return []

    articles: List[Dict] = []
    try:
        root = ET.fromstring(xml_bytes)
        for art in root.findall(".//PubmedArticle"):
            pmid_el = art.find(".//MedlineCitation/PMID")
            if pmid_el is None or not pmid_el.text:
                continue
            pmid = pmid_el.text.strip()

            title_el = art.find(".//Article/ArticleTitle")
            title = "".join(title_el.itertext()).strip() if title_el is not None else ""

            journal_el = art.find(".//Article/Journal/Title")
            journal = journal_el.text.strip() if journal_el is not None and journal_el.text else ""

            year_el = art.find(".//Article/Journal/JournalIssue/PubDate/Year")
            if year_el is None:
                year_el = art.find(".//Article/Journal/JournalIssue/PubDate/MedlineDate")
            year = year_el.text.strip() if year_el is not None and year_el.text else "n.d."

            abstract_parts = []
            for ab_el in art.findall(".//Article/Abstract/AbstractText"):
                label = ab_el.attrib.get("Label", "")
                txt = "".join(ab_el.itertext()).strip()
                if txt:
                    abstract_parts.append(f"{label}: {txt}" if label else txt)

            abstract_text = " ".join(abstract_parts).strip()
            if not abstract_text:
                abstract_text = title

            citation_tag = f"[PMID:{pmid}]"
            formatted_text = (
                f"PUBMED MAKALESİ {citation_tag} ({journal}, {year}): {title}\n"
                f"Özet ve Bulgular: {abstract_text}"
            )
            articles.append({
                "citation": citation_tag,
                "pmid": pmid,
                "title": title,
                "journal": journal,
                "year": year,
                "text": formatted_text,
            })
    except Exception:
        pass

    cache_payload = {
        "topic_id": topic_id,
        "topic_title": topic_title,
        "query": query,
        "article_count": len(articles),
        "articles": articles,
    }
    cache_path.write_text(json.dumps(cache_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return articles
