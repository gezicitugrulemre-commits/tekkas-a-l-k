"""
LangGraph Retina & Vitreus Klinik Kitap Üretim Pipeline (Veritabanı PDF + PubMed Tamamlamalı).

Kaynak Anahat: c:/Users/gezic/Projects/langgraph-lab/outputs/retina-longform-v1/outline-clinical-v2.md
Kaynak Veritabanı: C:/Users/gezic/OneDrive/Desktop/DATABASE/Ophthalmology KİTAPLARI (Ryan's Retina Vol 1-3 + Ekler)
Eksik Veri Tamamlama: NCBI PubMed E-Utilities API (`esearch` + `efetch`) -> `[PMID:xxxxxxxx]`

LangGraph Akışı:
  START -> freeze_and_sync -> pick_next_topic --(remaining)--> retrieve_db_pages
        -> pubmed_research -> author_topic -> commit_topic -> pick_next_topic
        --(all 49 topics done)--> assemble_pdf_book -> END
"""

import hashlib
import html
import json
import os
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, TypedDict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import boto3
import pymupdf
from langgraph.graph import END, START, StateGraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

from config import PATHS
from pubmed_client import fetch_pubmed_evidence
from quota_manager import QuotaAndWPSManager

# Sabit Yollar
OUTLINE_MD_PATH = Path(r"c:\Users\gezic\Projects\langgraph-lab\outputs\retina-longform-v1\outline-clinical-v2.md")
LANGGRAPH_LAB_BASE = Path(r"c:\Users\gezic\Projects\langgraph-lab\outputs\retina-longform-v1")
SOURCE_MAP_PATH = LANGGRAPH_LAB_BASE / "source-map-v3.json"
LAB_PILOT_DIR = LANGGRAPH_LAB_BASE / "chapter-1-1-v2" / "manuscript"
LAB_FULLBOOK_DIR = LANGGRAPH_LAB_BASE / "full-book-v2"
LAB_MANUSCRIPT_DIR = LAB_FULLBOOK_DIR / "manuscript"
LAB_ACCEPTED_PATH = LAB_FULLBOOK_DIR / "accepted.json"

LOCAL_MANUSCRIPT_DIR = PATHS.output_dir / "manuscript"
LOCAL_ACCEPTED_PATH = PATHS.storage_dir / "retina_accepted.json"
LOCAL_PDF_PATH = PATHS.compiled_dir / "Retina_ve_Vitreus_Klinik_Yaklasim.pdf"
LOCAL_MASTER_MD_PATH = PATHS.compiled_dir / "Retina_ve_Vitreus_Klinik_Yaklasim_Master.md"
LAB_PDF_PATH = LAB_FULLBOOK_DIR / "Retina_ve_Vitreus_Klinik_Yaklasim_TASLAK.pdf"

# AWS Bedrock / $100 WPS-Bulut Havuzu Ayarları
AWS_PROFILE = os.getenv("AWS_PROFILE", "TEG")
AWS_REGION = os.getenv("AWS_REGION", "eu-north-1")
PRIMARY_BEDROCK_MODEL = os.getenv("BEDROCK_WRITER_MODEL", "deepseek.v3.2")
FALLBACK_BEDROCK_MODEL = os.getenv("BEDROCK_FALLBACK_MODEL", "moonshotai.kimi-k2.5")

CITATION_REGEX = re.compile(r"\[(?:[A-Za-z0-9-]+:pdf\d+|PMID:\d+)\]")


def sha256_str(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_outline_markdown(md_path: Path = OUTLINE_MD_PATH) -> Dict:
    """
    `outline-clinical-v2.md` dosyasını doğrudan ayrıştırarak 9 Bölüm, 21 Alt-Bölüm
    ve 49 Başlığı (`1.1.1` .. `10.2.2`) hiyerarşik sözlük olarak döndürür.
    """
    if not md_path.is_file():
        raise FileNotFoundError(f"Outline dosyası bulunamadı: {md_path}")

    raw_text = md_path.read_text(encoding="utf-8")
    title = "RETİNA VE VİTREUS: KLİNİK YAKLAŞIM"
    chapters: List[Dict] = []

    ch_re = re.compile(r"^##\s+BÖLÜM\s+(\d+):\s*(.+)$")
    sub_re = re.compile(r"^###\s+(\d+\.\d+)\.\s*(.+)$")
    topic_re = re.compile(r"^-\s+\[(\d+\.\d+\.\d+)\]\s*(.+)$")

    for line in raw_text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("# ") and not s.startswith("## "):
            title = s[2:].strip()
            continue
        if m_ch := ch_re.match(s):
            chapters.append({
                "id": m_ch.group(1),
                "title": m_ch.group(2).strip(),
                "subsections": [],
            })
            continue
        if m_sub := sub_re.match(s):
            if not chapters:
                raise ValueError(f"Bölüm olmadan alt-bölüm bulundu: {s}")
            chapters[-1]["subsections"].append({
                "id": m_sub.group(1),
                "title": m_sub.group(2).strip(),
                "required_topics": [],
            })
            continue
        if m_top := topic_re.match(s):
            if not chapters or not chapters[-1]["subsections"]:
                raise ValueError(f"Alt-bölüm olmadan konu başlığı bulundu: {s}")
            chapters[-1]["subsections"][-1]["required_topics"].append({
                "id": m_top.group(1),
                "text": m_top.group(2).strip(),
            })

    all_topics = [
        t for c in chapters for sub in c["subsections"] for t in sub["required_topics"]
    ]
    return {
        "title": title,
        "outline_path": str(md_path),
        "outline_sha256": sha256_str(raw_text),
        "total_chapters": len(chapters),
        "total_topics": len(all_topics),
        "chapters": chapters,
    }


class RetinaBookState(TypedDict, total=False):
    outline: Dict
    source_map: Dict
    topic_order: List[str]
    current_tid: str
    current_title: str
    db_pages: List[Dict]
    pubmed_articles: List[Dict]
    draft_markdown: str
    completed_count: int
    total_count: int
    pdf_result: Dict


def _load_json(path: Path, default):
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    return default


def _save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


# ============================================================================
# LANGGRAPH DÜĞÜMLERİ
# ============================================================================

def node_freeze_and_sync(state: RetinaBookState) -> Dict:
    """
    Düğüm 1: `outline-clinical-v2.md` ve `source-map-v3.json` dosyalarını yükler,
    mevcut tamamlanmış bölümleri (`1.1.1`..`7.1.2`) senkronize eder ve kalan başlıkları hazırlar.
    """
    PATHS.ensure_dirs()
    LOCAL_MANUSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    LAB_MANUSCRIPT_DIR.mkdir(parents=True, exist_ok=True)

    outline = parse_outline_markdown(OUTLINE_MD_PATH)
    source_map = _load_json(SOURCE_MAP_PATH, {})
    if not source_map or "topics" not in source_map:
        raise ValueError(f"Kaynak haritası okunamadı: {SOURCE_MAP_PATH}")

    accepted = _load_json(LAB_ACCEPTED_PATH, {})
    local_accepted = _load_json(LOCAL_ACCEPTED_PATH, {})
    accepted.update(local_accepted)

    # Pilot 1.1.1 .. 1.1.4 dosyalarını senkronize et
    for tid in ("1.1.1", "1.1.2", "1.1.3", "1.1.4"):
        pilot_md = LAB_PILOT_DIR / f"{tid}.md"
        local_md = LOCAL_MANUSCRIPT_DIR / f"{tid}.md"
        if pilot_md.is_file():
            txt = pilot_md.read_text(encoding="utf-8")
            if not local_md.is_file():
                local_md.write_text(txt, encoding="utf-8")
            accepted[tid] = {
                "manuscript_path": str(pilot_md),
                "local_path": str(local_md),
                "source_ids": sorted(set(CITATION_REGEX.findall(txt))),
                "words": len(txt.split()),
                "sha256": sha256_str(txt),
            }

    # Mevcut 1.2.1 .. 7.1.2 dosyalarını yerel klasöre de kopyala
    for tid, meta in list(accepted.items()):
        src_p = Path(meta.get("manuscript_path", ""))
        local_p = LOCAL_MANUSCRIPT_DIR / f"{tid}.md"
        if src_p.is_file() and not local_p.is_file():
            shutil.copy2(src_p, local_p)
            meta["local_path"] = str(local_p)

    _save_json(LOCAL_ACCEPTED_PATH, accepted)

    topic_order = [
        t["id"]
        for c in outline["chapters"]
        for s in c["subsections"]
        for t in s["required_topics"]
    ]
    print(
        f"[FREEZE] Anahat yüklendi: {len( outline['chapters'] )} Bölüm, "
        f"{len(topic_order)} Konu Başlığı | Mevcut Tamamlanan: {len(accepted)}/{len(topic_order)}",
        flush=True,
    )
    return {
        "outline": outline,
        "source_map": source_map,
        "topic_order": topic_order,
        "completed_count": len(accepted),
        "total_count": len(topic_order),
    }


def node_pick_next_topic(state: RetinaBookState) -> Dict:
    """Düğüm 2: Sıradaki yazılmamış konu başlığını seçer."""
    accepted = _load_json(LOCAL_ACCEPTED_PATH, {})
    outline = state["outline"]

    for c in outline["chapters"]:
        for s in c["subsections"]:
            for t in s["required_topics"]:
                tid = t["id"]
                entry = accepted.get(tid)
                if entry:
                    p = Path(entry.get("manuscript_path", ""))
                    if p.is_file() and len(p.read_text(encoding="utf-8").split()) >= 250:
                        continue
                print(
                    f"\n>>> [PICK] Sıradaki Başlık: [{tid}] {t['text']} "
                    f"(Tamamlanan: {len(accepted)}/{len(state['topic_order'])})",
                    flush=True,
                )
                return {
                    "current_tid": tid,
                    "current_title": t["text"],
                    "completed_count": len(accepted),
                }

    print(f"\n>>> [PICK] Tüm {len(state['topic_order'])} başlık tamamlandı! PDF derlemesine geçiliyor...", flush=True)
    return {"current_tid": "", " current_title": "", "completed_count": len(accepted)}


def route_after_pick(state: RetinaBookState) -> str:
    if state.get("current_tid"):
        return "retrieve_db_pages"
    return "assemble_pdf_book"


def node_retrieve_db_pages(state: RetinaBookState) -> Dict:
    """
    Düğüm 3: `C:/Users/gezic/OneDrive/Desktop/DATABASE/Ophthalmology KİTAPLARI` içindeki
    Ryan's Retina Vol 1-3 ve ek PDF'lerden ilgili sayfaları çıkarır.
    """
    tid = state["current_tid"]
    source_map = state["source_map"]

    # Önce önbellekteki source-text kontrolü
    cached_src = LAB_FULLBOOK_DIR / "source-text" / f"{tid}.json"
    if cached_src.is_file():
        data = _load_json(cached_src, {})
        if data.get("pages"):
            print(f"  [DB] {tid} için {len(data['pages'])} PDF sayfası önbellekten yüklendi.", flush=True)
            return {"db_pages": data["pages"]}

    topic_map = source_map["topics"].get(tid)
    if not topic_map:
        raise ValueError(f"{tid} için source-map-v3.json içinde eşleşme bulunamadı!")

    pages_out: List[Dict] = []
    for item in topic_map["pages"]:
        sid = item["source_id"]
        page_num = item["pdf_page"]
        pdf_path = Path(source_map["sources"][sid]["path"])
        with pymupdf.open(pdf_path) as doc:
            raw_txt = doc[page_num - 1].get_text(sort=True)
        cleaned = re.sub(
            r"Downloaded for Anonymous User.*?All rights reserved\.", "", raw_txt, flags=re.S
        ).strip()
        pages_out.append({
            "citation": f"[{sid}:pdf{page_num}]",
            "source_id": sid,
            "page": page_num,
            "text": cleaned,
            "hash": sha256_str(cleaned),
        })

    _save_json(
        cached_src,
        {
            "topic": tid,
            "pages": pages_out,
            "mapping_rationale": topic_map.get("rationale", ""),
            "confidence": topic_map.get("confidence", "high"),
        },
    )
    print(
        f"  [DB] {tid} için {len(pages_out)} kaynak PDF sayfası çıkarıldı: "
        f"{', '.join(p['citation'] for p in pages_out)}",
        flush=True,
    )
    return {"db_pages": pages_out}


def node_pubmed_research(state: RetinaBookState) -> Dict:
    """
    Düğüm 4: Veritabanındaki eksik klinik/araştırma verilerini tamamlamak için
    PubMed (NCBI E-Utilities) üzerinden canlı literatür taraması yapar.
    """
    tid = state["current_tid"]
    title = state["current_title"]
    articles = fetch_pubmed_evidence(topic_id=tid, topic_title=title, max_articles=5)

    # Ayrıca langgraph-lab çıktısına da kaydet
    lab_pubmed_path = LAB_FULLBOOK_DIR / "pubmed" / f"{tid}.json"
    _save_json(lab_pubmed_path, {"topic_id": tid, "title": title, "articles": articles})

    pmids_str = ", ".join(a["citation"] for a in articles) if articles else "Yok"
    print(f"  [PUBMED] {tid} için {len(articles)} PubMed makalesi çekildi: {pmids_str}", flush=True)
    return {"pubmed_articles": articles}


def _invoke_bedrock(prompt: str, max_tokens: int = 4500, temperature: float = 0.15) -> Dict:
    """
    Önce Google Cloud Vertex AI (Gemini 2.5 Pro / Flash - aktif proje kredisi) veya
    AWS Bedrock (`TEG` profili, `eu-north-1`) üzerinden kesintisiz model çağrısı yapar.
    Token harcamasını $100 WPS/Bulut kotasına kaydeder.
    """
    os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "True")
    os.environ.setdefault("GOOGLE_CLOUD_PROJECT", "project-7b215f0c-cbc2-4e8c-ae2")
    os.environ.setdefault("GOOGLE_CLOUD_LOCATION", "us-central1")

    last_err = None

    # 1. Birincil: Aktif Google Cloud / Vertex AI Gemini Havuzu (Kesintisiz Oturum)
    try:
        from langchain_google_genai import ChatGoogleGenerativeAI
        for gemini_model in ("gemini-2.5-flash", "gemini-2.5-pro"):
            for attempt in range(2):
                try:
                    llm = ChatGoogleGenerativeAI(
                        model=gemini_model,
                        temperature=temperature,
                        max_output_tokens=max_tokens,
                    )
                    resp = llm.invoke(prompt)
                    text = str(resp.content).strip()
                    if len(text.split()) >= 200:
                        usage_meta = getattr(resp, "usage_metadata", None) or {}
                        in_tok = usage_meta.get("input_tokens", len(prompt.split()) * 2)
                        out_tok = usage_meta.get("output_tokens", len(text.split()) * 2)
                        return {
                            "model": gemini_model,
                            "stop_reason": "end_turn",
                            "input_tokens": in_tok,
                            "output_tokens": out_tok,
                            "text": text,
                        }
                except Exception as g_exc:
                    last_err = g_exc
                    time.sleep(1.5 * (attempt + 1))
    except Exception as import_exc:
        last_err = import_exc

    # 2. İkincil (Yedek): AWS Bedrock (`TEG` profili, `eu-north-1`)
    session = boto3.Session(profile_name=AWS_PROFILE, region_name=AWS_REGION)
    client = session.client("bedrock-runtime")

    for model_id in (PRIMARY_BEDROCK_MODEL, FALLBACK_BEDROCK_MODEL):
        for attempt in range(2):
            try:
                resp = client.converse(
                    modelId=model_id,
                    messages=[{"role": "user", "content": [{"text": prompt}]}],
                    inferenceConfig={"maxTokens": max_tokens, "temperature": temperature},
                )
                text = "\n".join(
                    block["text"]
                    for block in resp["output"]["message"]["content"]
                    if "text" in block
                ).strip()
                usage = resp.get("usage") or {}
                return {
                    "model": model_id,
                    "stop_reason": resp.get("stopReason", "end_turn"),
                    "input_tokens": usage.get("inputTokens", 0),
                    "output_tokens": usage.get("outputTokens", 0),
                    "text": text,
                }
            except Exception as exc:
                last_err = exc
                time.sleep(1.5 * (attempt + 1))

    raise RuntimeError(f"Tüm model havuzları başarısız oldu: {last_err}")


def _ensure_paragraph_citations(text: str, valid_citations: List[str], fallback_citation: str) -> str:
    """
    Metindeki her olgusal paragrafın sonunda geçerli bir `[RVx:pdfN]` veya `[PMID:xxxxxxxx]`
    atıfı bulunduğunu garanti eder; eksikse veya çoklu atıf tek parantezde birleştirildiyse düzeltir.
    """
    # Örn: [RV3:pdf701, RV3:pdf703] -> [RV3:pdf701] [RV3:pdf703]
    def _split_multi_cite(match):
        inner = match.group(1)
        parts = [p.strip() for p in re.split(r"[,;]\s*", inner) if p.strip()]
        valid_parts = [f"[{p}]" for p in parts if f"[{p}]" in valid_citations]
        return " ".join(valid_parts) if valid_parts else fallback_citation

    text = re.sub(r"\[([^\[\]]+[,;][^\[\]]+)\]", _split_multi_cite, text)

    blocks = re.split(r"\n\s*\n", text.strip())
    fixed_blocks: List[str] = []

    for block in blocks:
        b = block.strip()
        if not b:
            continue
        # Başlık satırlarına dokunma
        if b.startswith("#"):
            fixed_blocks.append(b)
            continue
        found = CITATION_REGEX.findall(b)
        valid_found = [c for c in found if c in valid_citations]
        if not valid_found:
            # Paragraf sonunda nokta varsa öncesine veya sonuna kaynak atfı ekle
            b = b.rstrip()
            if b.endswith("."):
                b = b[:-1] + f" {fallback_citation}."
            else:
                b = b + f" {fallback_citation}"
        fixed_blocks.append(b)

    return "\n\n".join(fixed_blocks)


def node_author_topic(state: RetinaBookState) -> Dict:
    """
    Düğüm 5: Veritabanı PDF sayfalarını (`[RVx:pdfN]`) ve PubMed araştırmalarını (`[PMID:xxxxxxxx]`)
    birleştirerek her konu başlığı için 3 alt bölümlü (`### {tid} {title}`, `#### Kanıt`, `#### Uygulama`)
    kapsamlı akademik metin üretir.
    """
    tid = state["current_tid"]
    title = state["current_title"]
    db_pages = state.get("db_pages", [])
    pubmed_articles = state.get("pubmed_articles", [])

    db_citations = [p["citation"] for p in db_pages]
    pm_citations = [a["citation"] for a in pubmed_articles]
    all_valid_citations = db_citations + pm_citations
    fallback_cit = db_citations[0] if db_citations else (pm_citations[0] if pm_citations else "[RV3:pdf1]")

    db_context = "\n\n".join(f"{p['citation']}\n{p['text']}" for p in db_pages)
    pubmed_context = "\n\n".join(f"{a['citation']}\n{a['text']}" for a in pubmed_articles)

    facets = [
        (
            "temeller",
            f"### {tid} {title}",
            "Veritabanı kaynak sayfalarında ve PubMed literatüründe yer alan temel anatomi, patofizyoloji, sınıflama ve multimodal görüntüleme/mekanizma ilkelerini ayrıntılı olarak açıkla.",
        ),
        (
            "kanıt",
            "#### Kanıt",
            "Veritabanı sayfalarındaki ve PubMed makalelerindeki somut klinik çalışma bulgularını, epidemiyolojik verileri, görüntüleme biyobelirteçlerini, duyarlılık/özgüllük nüanslarını ve kanıt sınırlılıklarını sentezle. Veritabanında eksik kalan klinik kanıtları PubMed özetleriyle ([PMID:...]) tamamla.",
        ),
        (
            "uygulama",
            "#### Uygulama",
            "Veritabanı ve PubMed kaynaklarında yer alan tanısal yaklaşım, ayırıcı tanı kriterleri, medikal/farmakolojik yönetim algoritmaları ve izlem prensiplerini anlat. Cerrahi operasyon tekniği öğretme; çalışma sorusu veya çoktan seçmeli test ekleme.",
        ),
    ]

    composed_sections: List[str] = []
    quota_mgr = QuotaAndWPSManager()

    for facet_key, header_line, instructions in facets:
        cache_file = PATHS.storage_dir / "raw_facets" / f"{tid}-{facet_key}.json"
        cache_file.parent.mkdir(parents=True, exist_ok=True)

        if cache_file.is_file():
            cached_data = _load_json(cache_file, {})
            if cached_data.get("text") and len(cached_data["text"].split()) >= 260:
                print(f"  [AUTHOR] {tid}/{facet_key} önbellekten yüklendi ({len(cached_data['text'].split())} kelime).", flush=True)
                composed_sections.append(cached_data["text"])
                continue

        prompt = f"""Uzman düzeyinde Türkçe akademik retina başvuru kitabı ("RETİNA VE VİTREUS: KLİNİK YAKLAŞIM") için yalnız aşağıdaki başlığı ve alt odağı yaz:

BAŞLIK: {tid} {title}
ALT BÖLÜM BAŞLIĞI (İlk satır tam olarak bu olmalı): {header_line}
ODAK: {instructions}

ZORUNLU YAZIM VE ATIF KURALLARI:
1. İlk satır tam olarak `{header_line}` olmalıdır.
2. Uzunluk: 420 - 650 kelime arasında, derinlikli, akıcı, akademik Türkçe düz yazı (4 ila 6 doyurucu paragraf).
3. Veritabanı PDF sayfalarındaki bilgileri `{', '.join(db_citations)}` etiketleriyle; veritabanında eksik kalan güncel klinik/araştırma verilerini ise PubMed makalelerinden `{', '.join(pm_citations)}` etiketleriyle destekle.
4. HER olgusal paragrafın sonunda mutlaka geçerli bir kaynak etiketi (Örn: `{fallback_cit}` veya `{pm_citations[0] if pm_citations else fallback_cit}`) bulunmalıdır. Birden fazla atıf kullanacaksan ayrı köşeli parantezlerle yaz (Örn: `[RV3:pdf701] [PMID:12345678]`).
5. Asla "sağlanan kaynaklarda yeterli kanıt bulunmamaktadır" gibi boşluk/reddiye paragrafı yazma; kitap sayfalarında eksik olan veriyi aşağıda verilen PUBMED LİTERATÜR KANITLARI ile eksiksiz tamamla.
6. Çalışma sorusu, quiz, cevap anahtarı veya cerrahi ameliyat tekniği kesinlikle yazma. Düz metin paragrafları kullan (madde işaretli liste yerine akademik paragraf tercih et).

=== VERİTABANI KİTAP SAYFALARI ({', '.join(db_citations)}) ===
{db_context}

=== PUBMED LİTERATÜR KANITLARI ({', '.join(pm_citations)}) ===
{pubmed_context}
"""
        print(f"  [AUTHOR] Yazılıyor: {tid} / {facet_key} ...", flush=True)
        res = _invoke_bedrock(prompt=prompt, max_tokens=4000, temperature=0.15)
        raw_text = res["text"].strip()

        # İlk satırın tam olarak header_line olduğundan emin ol
        lines = [ln for ln in raw_text.splitlines() if ln.strip()]
        if not lines or not lines[0].strip().startswith(header_line):
            # Varsa baştaki yanlış başlığı kaldır ve doğru başlığı ekle
            if lines and lines[0].strip().startswith("#"):
                lines[0] = header_line
                raw_text = "\n\n".join(lines)
            else:
                raw_text = f"{header_line}\n\n{raw_text}"

        # Paragraf atıflarını doğrula ve eksik varsa onar
        verified_text = _ensure_paragraph_citations(raw_text, all_valid_citations, fallback_cit)

        _save_json(
            cache_file,
            {
                "topic_id": tid,
                "facet": facet_key,
                "model": res["model"],
                "input_tokens": res["input_tokens"],
                "output_tokens": res["output_tokens"],
                "words": len(verified_text.split()),
                "text": verified_text,
            },
        )

        # $100 WPS/Bulut kotasına kaydet
        quota_mgr.estimate_and_log_usage(
            subsection_id=f"{tid}-{facet_key}",
            fast_input_tokens=0,
            fast_output_tokens=0,
            writer_input_tokens=res["input_tokens"],
            writer_output_tokens=res["output_tokens"],
            used_pool="wps",
        )
        print(
            f"  [AUTHOR] ✓ {tid}/{facet_key} tamamlandı ({len(verified_text.split())} kelime | "
            f"Model: {res['model']} | Kalan $100 Kota: ${quota_mgr.record.remaining_usd:.2f})",
            flush=True,
        )
        composed_sections.append(verified_text)

    full_manuscript = "\n\n".join(composed_sections).strip() + "\n"
    return {"draft_markdown": full_manuscript}


def node_commit_topic(state: RetinaBookState) -> Dict:
    """
    Düğüm 6: Tamamlanan konu metnini hem yerel `output/manuscript/{tid}.md` hem de
    `langgraph-lab/outputs/retina-longform-v1/full-book-v2/manuscript/{tid}.md` dizinine kaydeder.
    """
    tid = state["current_tid"]
    text = state["draft_markdown"]

    local_dest = LOCAL_MANUSCRIPT_DIR / f"{tid}.md"
    lab_dest = LAB_MANUSCRIPT_DIR / f"{tid}.md"

    local_dest.write_text(text, encoding="utf-8")
    lab_dest.write_text(text, encoding="utf-8")

    cites = sorted(set(CITATION_REGEX.findall(text)))
    words = len(text.split())
    digest = sha256_str(text)

    entry = {
        "manuscript_path": str(lab_dest),
        "local_path": str(local_dest),
        "source_ids": cites,
        "words": words,
        "sha256": digest,
        "pubmed_enriched": any(c.startswith("[PMID:") for c in cites),
    }

    local_acc = _load_json(LOCAL_ACCEPTED_PATH, {})
    local_acc[tid] = entry
    _save_json(LOCAL_ACCEPTED_PATH, local_acc)

    lab_acc = _load_json(LAB_ACCEPTED_PATH, {})
    lab_acc[tid] = entry
    _save_json(LAB_ACCEPTED_PATH, lab_acc)

    print(
        f"[COMMIT] ✓ {tid} kaydedildi ({words} kelime, {len(cites)} tekil kaynak atfı: {', '.join(cites[:6])})",
        flush=True,
    )
    return {"db_pages": [], "pubmed_articles": [], "draft_markdown": ""}


def _normalize_tokens_for_dedup(text: str) -> set[str]:
    """
    Aynı kaynak sayfalarından ('Temeller', 'Kanıt', 'Uygulama') üretilen paragraf ve
    cümlelerdeki eşanlamlı tıbbi terimleri normalize ederek tekrar tespiti yapar.
    """
    s = re.sub(r"\[(?:RV[123]|ICROP3|PRD|INJ):pdf\d+\]", "", text.lower())
    s = re.sub(r"\[pmid:\d+\]", "", s)
    synonyms = {
        "rod": "çubuk",
        "rods": "çubuk",
        "çomak": "çubuk",
        "kon": "koni",
        "cone": "koni",
        "cones": "koni",
        "sgmp": "cgmp",
        "dekorasyon": "dekorlasyon",
        "dekorrelasyon": "dekorlasyon",
        "otofloresan": "otofloresans",
        "otofagositoz": "otofloresans",
    }
    words = re.findall(r"[a-zçğıöşü0-9]{4,}", s)
    out = set()
    for w in words:
        for k, v in synonyms.items():
            if w.startswith(k):
                w = v + w[len(k):]
                break
        out.add(w[:6])
    return out


def clean_and_deduplicate_topic_markdown(md_text: str, display_tid: str) -> str:
    """
    1. Konu başlığını ([10.1.1] -> [9.1.1]) ve terminolojiyi ('Fundus Otofagositoz' -> 'Fundus Otofloresans') düzeltir.
    2. Yapay zeka meta-yorum cümlelerini ('Bu bölümde, kaynaklarda tanımlanan...', '[metin kesintisi]', '**Kaynak sınırı:**') temizler.
    3. Ana metin ('Temeller') paragraflarını eksiksiz korurken, altındaki '#### Kanıt' ve '#### Uygulama'
       bloklarını '#### Kanıta Dayalı Klinik Uygulama ve Yönetim' başlığı altında birleştirir ve
       ana metinde zaten anlatılmış olan tekrar paragraf/cümleleri eler.
    """
    md_text = md_text.replace("Fundus Otofagositoz", "Fundus Otofloresans").replace("fundus otofagositoz", "fundus otofloresans")

    meta_patterns = [
        r"\[metin kesintisi\]",
        r"\*\*Kaynak sınırı:\*\*[^\n]+",
        r"Bu bölümde,\s*kaynaklarda tanımlanan[^\n.!?]*[.!?]",
        r"Aşağıdaki alt başlıklar[^\n.!?]*[.!?]",
        r"Buradaki çerçeve,\s*yalnızca sağlanan kaynak metinlerde[^\n.!?]*[.!?]",
        r"Verilen kaynak metinlerde[^\n.!?]*doğrudan veri yer almamaktadır[.!?]",
        r"Mevcut kaynak sayfalarında[^\n.!?]*ayrıntılandırılmamıştır[.!?]",
        r"Sağlanan kaynak metinlerde[^\n.!?]*bulunmamaktadır[.!?]",
    ]
    for pat in meta_patterns:
        md_text = re.sub(pat, "", md_text, flags=re.IGNORECASE)

    lines = [ln.strip() for ln in md_text.splitlines() if ln.strip()]
    header = ""
    sections: Dict[str, List[str]] = {"temeller": [], "kanit": [], "uygulama": []}
    curr = "temeller"

    for ln in lines:
        if ln.startswith("### ") or ln.startswith("## ") or ln.startswith("# "):
            if not header:
                # Başlık numarasını display_tid ile senkronize et (ör. 10.1.1 -> 9.1.1)
                ln = re.sub(r"^#{1,3}\s+\[?\d+\.\d+\.\d+\]?\s+", f"### [{display_tid}] ", ln)
                header = ln
            continue
        if ln.startswith("#### "):
            low = ln.lower()
            if "kanıt" in low or "kanit" in low:
                curr = "kanit"
            elif "uygulama" in low:
                curr = "uygulama"
            continue
        sections[curr].append(ln)

    temeller_kept: List[str] = []
    temeller_Paragraph_tokens: List[set[str]] = []
    seen_sent_tokens: List[set[str]] = []

    for p in sections["temeller"]:
        if len(p) < 25:
            continue
        ptoks = _normalize_tokens_for_dedup(p)
        temeller_kept.append(p)
        temeller_Paragraph_tokens.append(ptoks)
        for s in re.split(r"(?<=[.!?])\s+", p):
            st = _normalize_tokens_for_dedup(s)
            if len(st) >= 5:
                seen_sent_tokens.append(st)

    merged_clinical: List[str] = []
    merged_para_tokens: List[set[str]] = []

    for sec_name in ("kanit", "uygulama"):
        for p in sections[sec_name]:
            if len(p) < 40:
                continue
            ptoks = _normalize_tokens_for_dedup(p)
            if not ptoks:
                continue
            # Ana metin (Temeller) paragrafıyla %50+ örtüşüyorsa tekrardır, atla
            if any(len(ptoks & prev) / max(1, min(len(ptoks), len(prev))) >= 0.50 for prev in temeller_Paragraph_tokens):
                continue
            # Birleştirilmiş klinik blok içindeki önceki paragraflarla %52+ örtüşüyorsa atla
            if any(len(ptoks & prev) / max(1, min(len(ptoks), len(prev))) >= 0.52 for prev in merged_para_tokens):
                continue

            sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", p) if len(s.strip()) >= 30]
            kept_sents: List[str] = []
            for s in sents:
                st = _normalize_tokens_for_dedup(s)
                if len(st) < 5:
                    continue
                if any(len(st & prev_s) / max(1, min(len(st), len(prev_s))) >= 0.55 for prev_s in seen_sent_tokens):
                    continue
                kept_sents.append(s)
                seen_sent_tokens.append(st)

            if kept_sents:
                new_p = " ".join(kept_sents)
                if len(new_p) >= 65:
                    merged_clinical.append(new_p)
                    merged_para_tokens.append(_normalize_tokens_for_dedup(new_p))

    # Eğer bir konuda tüm Kanıt/Uygulama paragrafları elendiyse, Uygulama/Kanıt içinden
    # Temeller ile en az örtüşen 2-3 klinik uygulama cümlesini seçerek özlü bir klinik sentez paragrafı oluştur
    if not merged_clinical and (sections["uygulama"] or sections["kanit"]):
        candidate_sents: List[tuple[float, str]] = []
        for sec_name in ("uygulama", "kanit"):
            for p in sections[sec_name]:
                for s in re.split(r"(?<=[.!?])\s+", p):
                    s_clean = s.strip()
                    if len(s_clean) < 45:
                        continue
                    st = _normalize_tokens_for_dedup(s_clean)
                    if len(st) < 5:
                        continue
                    max_ov = max(
                        (len(st & prev_s) / max(1, min(len(st), len(prev_s))) for prev_s in seen_sent_tokens),
                        default=0.0,
                    )
                    if max_ov < 0.72:
                        candidate_sents.append((max_ov, s_clean))
        candidate_sents.sort(key=lambda x: x[0])
        chosen: List[str] = []
        chosen_toks: List[set[str]] = []
        for _, sc in candidate_sents:
            st = _normalize_tokens_for_dedup(sc)
            if any(len(st & ct) / max(1, min(len(st), len(ct))) >= 0.50 for ct in chosen_toks):
                continue
            chosen.append(sc)
            chosen_toks.append(st)
            if len(chosen) >= 4:
                break
        if chosen:
            merged_clinical.append(" ".join(chosen))

    out_lines = [header] if header else [f"### [{display_tid}]"]
    out_lines.extend(temeller_kept)
    if merged_clinical:
        out_lines.append("#### Kanıta Dayalı Klinik Uygulama ve Yönetim")
        out_lines.extend(merged_clinical)
    return "\n\n".join(out_lines)


def node_assemble_pdf_book(state: RetinaBookState) -> Dict:
    """
    Düğüm 7: `outline-clinical-v2.md` içindeki 49 başlığın tamamını doğrular,
    Master Markdown ve tam mizanpajlı PDF kitabını (`Retina_ve_Vitreus_Klinik_Yaklasim.pdf`) oluşturur.
    """
    outline = state["outline"]
    accepted = _load_json(LOCAL_ACCEPTED_PATH, {})
    PATHS.ensure_dirs()

    # 1. Tüm 49 başlığın kapsandığını doğrula
    missing = []
    for c in outline["chapters"]:
        for s in c["subsections"]:
            for t in s["required_topics"]:
                tid = t["id"]
                if tid not in accepted:
                    missing.append(tid)
                else:
                    p = Path(accepted[tid].get("local_path") or accepted[tid]["manuscript_path"])
                    if not p.is_file():
                        missing.append(tid)

    if missing:
        raise ValueError(f"Eksik başlıklar var, PDF derlenemez: {missing}")

    # 2. Türkçe Font Kaydı (ReportLab)
    pdfmetrics.registerFont(TTFont("Retina", "C:/Windows/Fonts/arial.ttf"))
    pdfmetrics.registerFont(TTFont("RetinaBold", "C:/Windows/Fonts/arialbd.ttf"))

    title_style = ParagraphStyle(
        "BookTitle",
        fontName="RetinaBold",
        fontSize=24,
        leading=30,
        spaceAfter=14,
        textColor=colors.HexColor("#0f2c4c"),
    )
    subtitle_style = ParagraphStyle(
        "BookSubtitle",
        fontName="Retina",
        fontSize=12,
        leading=18,
        spaceAfter=12,
        textColor=colors.HexColor("#334e68"),
    )
    toc_ch_style = ParagraphStyle(
        "TOCChapter",
        fontName="RetinaBold",
        fontSize=11,
        leading=16,
        spaceBefore=6,
        spaceAfter=2,
        textColor=colors.HexColor("#173c5c"),
    )
    toc_item_style = ParagraphStyle(
        "TOCItem",
        fontName="Retina",
        fontSize=9.5,
        leading=13.5,
        leftIndent=12,
        spaceAfter=1,
    )
    chapter_style = ParagraphStyle(
        "ChapterHeading",
        fontName="RetinaBold",
        fontSize=19,
        leading=25,
        spaceAfter=16,
        keepWithNext=True,
        textColor=colors.HexColor("#173c5c"),
    )
    section_style = ParagraphStyle(
        "SectionHeading",
        fontName="RetinaBold",
        fontSize=14.5,
        leading=20,
        spaceBefore=12,
        spaceAfter=8,
        keepWithNext=True,
        textColor=colors.HexColor("#1e4e79"),
    )
    topic_style = ParagraphStyle(
        "TopicHeading",
        fontName="RetinaBold",
        fontSize=12,
        leading=17,
        spaceBefore=10,
        spaceAfter=6,
        keepWithNext=True,
        textColor=colors.HexColor("#0f2c4c"),
    )
    subfacet_style = ParagraphStyle(
        "SubfacetHeading",
        fontName="RetinaBold",
        fontSize=10.8,
        leading=15,
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True,
        textColor=colors.HexColor("#2b547e"),
    )
    body_style = ParagraphStyle(
        "BodyText",
        fontName="Retina",
        fontSize=10.5,
        leading=15.8,
        spaceAfter=8,
    )
    ref_style = ParagraphStyle(
        "RefText",
        fontName="Retina",
        fontSize=9.2,
        leading=13.5,
        spaceAfter=5,
    )

    story = []
    master_md_lines = [
        f"# {outline['title']}",
        "",
        f"*Üretim Tarihi: {datetime.now().strftime('%Y-%m-%d %H:%M')} · Kaynak Veritabanı (Ryan's Retina 7th Ed. Vol 1–3) + NCBI PubMed Literatür Sentezi*",
        "",
    ]

    # Kapak Sayfası
    story.append(Spacer(1, 25 * mm))
    story.append(Paragraph(html.escape(outline["title"]), title_style))
    story.append(
        Paragraph(
            "Kapsamlı Klinik, Multimodal Görüntüleme ve Kanıta Dayalı Retinal Tıp Başvuru Kitabı",
            subtitle_style,
        )
    )
    story.append(
        Paragraph(
            "Kaynak Mimari: Oftalmoloji Referans Veritabanı (Ryan's Retina 7. Baskı Cilt 1–3, ICROP-3, Konsensüs Raporları) "
            "ve NCBI PubMed (E-Utilities) Klinik Araştırma Entegrasyonu.",
            body_style,
        )
    )
    story.append(PageBreak())

    # İçindekiler (Table of Contents) Sayfası
    story.append(Paragraph("İÇİNDEKİLER", chapter_style))
    for ch in outline["chapters"]:
        disp_ch_id = 9 if str(ch["id"]) == "10" else ch["id"]
        story.append(Paragraph(f"BÖLÜM {disp_ch_id}: {html.escape(ch['title'])}", toc_ch_style))
        for sec in ch["subsections"]:
            disp_sec_id = f"9.{sec['id'][3:]}" if str(sec["id"]).startswith("10.") else sec["id"]
            disp_sec_title = sec["title"].replace("Fundus Otofagositoz", "Fundus Otofloresans")
            story.append(Paragraph(f"<b>{disp_sec_id}. {html.escape(disp_sec_title)}</b>", toc_item_style))
            for t in sec["required_topics"]:
                disp_tid = f"9.{t['id'][3:]}" if str(t["id"]).startswith("10.") else t["id"]
                story.append(Paragraph(f"• [{disp_tid}] {html.escape(t['text'])}", toc_item_style))
    story.append(PageBreak())

    total_words = 0

    # Bölümler ve Konular (Bölüm 10 -> Bölüm 9 yeniden numaralandırma + Tekrarsız Sentez)
    for ch in outline["chapters"]:
        disp_ch_id = 9 if str(ch["id"]) == "10" else ch["id"]
        ch_header = f"BÖLÜM {disp_ch_id}: {ch['title']}"
        story.append(Paragraph(html.escape(ch_header), chapter_style))
        master_md_lines.extend([f"## {ch_header}", ""])

        for sec in ch["subsections"]:
            disp_sec_id = f"9.{sec['id'][3:]}" if str(sec["id"]).startswith("10.") else sec["id"]
            disp_sec_title = sec["title"].replace("Fundus Otofagositoz", "Fundus Otofloresans")
            sec_header = f"{disp_sec_id}. {disp_sec_title}"
            story.append(Paragraph(html.escape(sec_header), section_style))
            master_md_lines.extend([f"### {sec_header}", ""])

            for t in sec["required_topics"]:
                tid = t["id"]
                disp_tid = f"9.{tid[3:]}" if str(tid).startswith("10.") else tid
                manuscript_file = Path(accepted[tid].get("local_path") or accepted[tid]["manuscript_path"])
                raw_text = manuscript_file.read_text(encoding="utf-8").strip()
                text = clean_and_deduplicate_topic_markdown(raw_text, disp_tid)
                total_words += len(text.split())
                master_md_lines.extend([text, ""])

                for raw_line in text.splitlines():
                    line = raw_line.strip()
                    if not line:
                        continue
                    escaped = html.escape(line)
                    escaped = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", escaped)
                    if line.startswith("### "):
                        story.append(Paragraph(escaped[4:], topic_style))
                    elif line.startswith("#### "):
                        story.append(Paragraph(escaped[5:], subfacet_style))
                    elif line.startswith("#"):
                        story.append(Paragraph(escaped.lstrip("# "), topic_style))
                    else:
                        story.append(Paragraph(escaped, body_style))
                story.append(Spacer(1, 3 * mm))

        story.append(PageBreak())

    # Ek: PubMed ve Veritabanı Kaynakça Dizini
    story.append(Paragraph("KAYNAKÇA VE PUBMED LİTERATÜR DİZİNİ", chapter_style))
    master_md_lines.extend(["## KAYNAKÇA VE PUBMED LİTERATÜR DİZİNİ", ""])

    source_map = state["source_map"]
    story.append(Paragraph("1. Birincil Veritabanı Kitap ve Kılavuz Kaynakları", section_style))
    for sid, smeta in source_map.get("sources", {}).items():
        src_name = Path(smeta["path"]).name
        line_str = f"• [{sid}] — {src_name} (SHA256: {smeta['sha256'][:16]}...)"
        story.append(Paragraph(html.escape(line_str), ref_style))
        master_md_lines.append(f"- **{sid}**: `{src_name}`")

    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph("2. Tamamlayıcı PubMed (NCBI) Klinik Araştırma Kaynakları", section_style))
    master_md_lines.extend(["", "### Tamamlayıcı PubMed (NCBI) Makaleleri", ""])

    pubmed_dir = PATHS.storage_dir / "pubmed"
    seen_pmids = set()
    if pubmed_dir.exists():
        for pm_file in sorted(pubmed_dir.glob("*.json")):
            pm_data = _load_json(pm_file, {})
            for art in pm_data.get("articles", []):
                pmid = art.get("pmid")
                if not pmid or pmid in seen_pmids:
                    continue
                seen_pmids.add(pmid)
                ref_line = f"• [PMID:{pmid}] {art.get('title', '')} ({art.get('journal', '')}, {art.get('year', '')})"
                story.append(Paragraph(html.escape(ref_line), ref_style))
                master_md_lines.append(f"- **[PMID:{pmid}]** {art.get('title', '')} (*{art.get('journal', '')}*, {art.get('year', '')})")

    # Master Markdown kaydet
    LOCAL_MASTER_MD_PATH.write_text("\n".join(master_md_lines), encoding="utf-8")

    # langgraph-lab Görsel, Şematik, Tablolu ve Matrisli PDF Dizgi Motorunu Çalıştır
    from pro_pdf_publisher import build_publishing_grade_pdf

    yayinevi_pdf_path = build_publishing_grade_pdf()
    shutil.copy2(yayinevi_pdf_path, LOCAL_PDF_PATH)
    shutil.copy2(yayinevi_pdf_path, LAB_PDF_PATH)

    # PyMuPDF ile PDF doğrulaması
    with pymupdf.open(LOCAL_PDF_PATH) as pdf_doc:
        total_pages = len(pdf_doc)
        full_pdf_text = "\n".join(page.get_text() for page in pdf_doc)

    missing_in_pdf = [
        tid
        for tid in state["topic_order"]
        if (f"9.{tid[3:]}" if str(tid).startswith("10.") else tid) not in full_pdf_text
    ]
    if missing_in_pdf:
        raise ValueError(f"PDF içinde bulunamayan başlık ID'leri: {missing_in_pdf}")

    quota_mgr = QuotaAndWPSManager()
    result_summary = {
        "status": "completed_pdf_verified",
        "title": outline["title"],
        "outline_source": str(OUTLINE_MD_PATH),
        "chapters": outline["total_chapters"],
        "topics_completed": f"{len(accepted)}/{outline['total_topics']}",
        "total_words": total_words,
        "pdf_pages": total_pages,
        "pubmed_articles_indexed": len(seen_pmids),
        "local_pdf_path": str(LOCAL_PDF_PATH),
        "lab_pdf_path": str(LAB_PDF_PATH),
        "master_markdown_path": str(LOCAL_MASTER_MD_PATH),
        "wps_remaining_usd": quota_mgr.record.remaining_usd,
    }
    _save_json(PATHS.storage_dir / "final_book_status.json", result_summary)
    _save_json(LAB_FULLBOOK_DIR / "status.json", result_summary)
    print("\n" + "=" * 72, flush=True)
    print(json.dumps(result_summary, ensure_ascii=False, indent=2), flush=True)
    print("=" * 72, flush=True)
    return {"pdf_result": result_summary}


def build_retina_pubmed_book_graph():
    """Veritabanı + PubMed destekli LangGraph Retina Kitabı StateGraph'ini derler."""
    builder = StateGraph(RetinaBookState)
    builder.add_node("freeze_and_sync", node_freeze_and_sync)
    builder.add_node("pick_next_topic", node_pick_next_topic)
    builder.add_node("retrieve_db_pages", node_retrieve_db_pages)
    builder.add_node("pubmed_research", node_pubmed_research)
    builder.add_node("author_topic", node_author_topic)
    builder.add_node("commit_topic", node_commit_topic)
    builder.add_node("assemble_pdf_book", node_assemble_pdf_book)

    builder.add_edge(START, "freeze_and_sync")
    builder.add_edge("freeze_and_sync", "pick_next_topic")
    builder.add_conditional_edges(
        "pick_next_topic",
        route_after_pick,
        {
            "retrieve_db_pages": "retrieve_db_pages",
            "assemble_pdf_book": "assemble_pdf_book",
        },
    )
    builder.add_edge("retrieve_db_pages", "pubmed_research")
    builder.add_edge("pubmed_research", "author_topic")
    builder.add_edge("author_topic", "commit_topic")
    builder.add_edge("commit_topic", "pick_next_topic")
    builder.add_edge("assemble_pdf_book", END)

    return builder.compile()


retina_pubmed_book_graph = build_retina_pubmed_book_graph()
