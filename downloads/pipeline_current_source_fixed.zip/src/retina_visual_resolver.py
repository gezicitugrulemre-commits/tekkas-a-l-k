"""Conservative figure resolver: section numbers are never disease identifiers.

Only approved, hash-bound figure/panel records may be inserted. Legacy records
remain retrieval candidates, not verified clinical illustrations.

Enhanced with:
- Docling structural registry integration (v2 adapter).
- Two-stage multimodal visual verifier connection with strict Argon & human approval separation.
- Context hash binding to prevent stale approvals when context/image changes.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import logging
import os
import re
from pathlib import Path
from typing import Optional, Union, Dict, Any, List

from PIL import Image
from bookgraph.safety import atomic_json, file_hash

log = logging.getLogger("retina_visual_resolver")

BASE_DIR = Path(os.getenv('RETINA_WORKSPACE_DIR', str(Path(__file__).resolve().parent)))
REGISTRY_PATH = Path(os.getenv('RETINA_REGISTRY_PATH', str(BASE_DIR / 'retina_precise_registry.json')))
DOCLING_REGISTRY_PATH = Path(os.getenv('DOCLING_REGISTRY_PATH', str(BASE_DIR / 'assets' / 'docling_catalog' / 'docling_retina_registry.json')))
CACHE_DIR = BASE_DIR / 'assets' / 'cached_images'

# Small unambiguous set only. Unknown/compound topics require an explicit topic_id.
DISEASE_TERMS = {
    'crao': ('crao', 'central retinal artery occlusion', 'santral retinal arter'),
    'crvo': ('crvo', 'central retinal vein occlusion', 'santral retinal ven'),
    'brao': ('brao', 'branch retinal artery occlusion'),
    'brvo': ('brvo', 'branch retinal vein occlusion', 'dal retinal ven'),
    'arn': ('arn', 'acute retinal necrosis', 'akut retinal nekroz'),
    'porn': ('porn', 'progressive outer retinal necrosis'),
    'cmv': ('cmv', 'cytomegalovirus', 'sitomegalovir'),
    'toxoplasmosis': ('toxoplasm', 'toksoplazm'),
    'stargardt': ('stargardt', 'abca4'),
    'best': ('best', 'best1', 'bestrophin', 'vitelliform'),
    'npdr': ('npdr', 'nonproliferative', 'nonproliferatif'),
    'pdr': ('pdr', 'proliferative diabetic', 'proliferatif diyabetik'),
    'dme': ('dme', 'dmö', 'diabetic macular edema', 'diyabetik makula ödem'),
    'rp': ('retinitis pigmentosa', 'retinitİs pigmentosa', 'retinitis pigmentoza'),
}

def _topics(text):
    text = text.casefold()
    return {key for key, terms in DISEASE_TERMS.items()
            if any(re.search(r'(?<!\w)' + re.escape(t.casefold()) + r'\w*', text) for t in terms)}

def compute_record_context_hash(slide_title: str, disease_id: str, caption: str, claim: str = "", modality: Optional[str] = None, image_sha256: str = "") -> str:
    payload = f"{slide_title}|{disease_id}|{caption}|{claim}|{modality or ''}|{image_sha256}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

class RetinaVisualResolver:
    _instance = None

    def __init__(self, registry_path=None, cache_dir=None, docling_registry_path=None):
        self.registry = {}
        self.docling_records = []
        self.cache_dir = Path(cache_dir) if cache_dir else CACHE_DIR
        self.decisions = []
        self.registry_path = Path(registry_path) if registry_path else REGISTRY_PATH
        self.docling_registry_path = Path(docling_registry_path) if docling_registry_path else DOCLING_REGISTRY_PATH
        self.load_registry()
        self.load_docling_registry()

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def load_registry(self):
        if not self.registry_path.is_file():
            return
        data = json.loads(self.registry_path.read_text(encoding='utf-8'))
        self.registry = data.get('registry', data)

    def load_docling_registry(self):
        """Docling tarafından üretilen yapısal kayıtları (v2 şeması) yükler."""
        if not self.docling_registry_path.is_file():
            return
        try:
            docling_data = json.loads(self.docling_registry_path.read_text(encoding='utf-8'))
            self.docling_records = docling_data.get('records', [])
            log.info("Docling registry yüklendi: %d yapısal kayıt.", len(self.docling_records))
        except Exception as e:
            log.warning("Docling registry okunamadı (%s). Devam ediliyor.", e)

    def apply_expert_approval(
        self,
        record_path: str,
        *,
        reviewer_id: str,
        slide_title: str,
        disease_id: str,
        caption: str,
        claim: str = "",
        modality: Optional[str] = None,
    ) -> bool:
        """Klinik uzman insan tarafından açık onay verir. Reviewer, zaman ve bağlam hash'i kaydedilir."""
        p_canon = str(Path(record_path).resolve())
        target_rec = None
        for group in self.registry.values():
            if isinstance(group, list):
                for rec in group:
                    if rec.get('path') and str(Path(rec['path']).resolve()) == p_canon:
                        target_rec = rec
                        break
        if not target_rec:
            for rec in self.docling_records:
                if rec.get('path') and str(Path(rec['path']).resolve()) == p_canon:
                    target_rec = rec
                    break

        if not target_rec:
            return False

        ctx_hash = compute_record_context_hash(slide_title, disease_id, caption, claim, modality, target_rec.get('image_sha256', ''))
        target_rec['expert_review_status'] = 'approved'
        target_rec['review_status'] = 'approved'
        target_rec['reviewer'] = reviewer_id
        target_rec['reviewed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        target_rec['approved_context_hash'] = ctx_hash
        return True

    def ensure_rgb_cached(self, src_path):
        p = Path(src_path)
        if not p.is_file():
            return None
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        digest = file_hash(p)
        target = self.cache_dir / (digest + '.png')
        if not target.is_file():
            from tempfile import NamedTemporaryFile
            with Image.open(p) as image:
                with NamedTemporaryFile(dir=self.cache_dir, suffix='.png', delete=False) as tmp:
                    name = tmp.name
                try:
                    image.convert('RGB').save(name, format='PNG')
                    os.replace(name, target)
                finally:
                    if os.path.exists(name):
                        os.unlink(name)
        return target

    def resolve_visual(self, chapter_num, title, category, explicit_path=None,
                       explicit_caption=None, *, topic_id=None, modality=None,
                       enable_two_stage: bool = False, target_claim: str = "",
                       allow_model_placement: bool = False, excluded_image_hashes=()):
        requested = {topic_id} if topic_id else _topics(title)
        decision = dict(chapter=chapter_num, title=title, category=category,
                        requested_topics=sorted(requested), status='review_required',
                        reason='No approved, panel-specific matching record', candidates=[])

        if len(requested) != 1:
            decision['reason'] = 'Unknown or compound topic; assign an explicit topic_id'
            self.decisions.append(decision)
            return None, ''

        target_dis = list(requested)[0]

        # Aday havuzu oluştur (Birincil katalog + Docling kataloğu)
        candidates = {}
        for group in self.registry.values():
            if not isinstance(group, list):
                continue
            for rec in group:
                path = rec.get('path', '')
                if path:
                    candidates[path] = rec

        for rec in self.docling_records:
            path = rec.get('path', '')
            if path and path not in candidates:
                candidates[path] = rec

        for path, rec in candidates.items():
            if rec.get("image_sha256") in excluded_image_hashes:
                continue
            if explicit_path and Path(path).resolve() != Path(explicit_path).resolve():
                continue
            labels = set(rec.get('disease_ids') or [])
            caption_topics = _topics(rec.get('original_caption', ''))
            if not (requested & (labels | caption_topics)):
                continue
            decision['candidates'].append(path)

            if labels != requested or (caption_topics - requested):
                continue

            # Two-Stage Verifier kontrolü (Eğer aktif edildiyse)
            v_res = None
            if enable_two_stage:
                try:
                    from two_stage_visual_verifier import TwoStageVisualVerifier
                    verifier = TwoStageVisualVerifier(use_live_api=False, strict_argon=True)
                    v_res = verifier.verify_visual(
                        Path(path),
                        target_slide_title=title,
                        target_disease_id=target_dis,
                        original_caption=rec.get('original_caption', ''),
                        target_claim=target_claim,
                        expected_modality=modality,
                    )
                    # Model değerlendirmesi ayrı model_review alanında saklanır
                    rec['model_review'] = v_res.model_dump()
                    decision['two_stage_audit'] = v_res.model_dump()

                    # Model onayını asla insan onayı (expert_review_status=approved veya reviewer=model) yapma!
                except Exception as v_err:
                    log.debug("İki aşamalı görsel doğrulama hatası: %s", v_err)

            # İnsan uzman onayı kontrolü:
            # Model adı ('model', 'verifier', 'gemini', 'argon', 'two_stage') reviewer alanında insan onayı sayılamaz.
            reviewer = str(rec.get('reviewer', '')).strip()
            is_model_reviewer = any(m in reviewer.lower() for m in ('model', 'verifier', 'gemini', 'argon', 'two_stage'))
            has_human_approval = (rec.get('expert_review_status') == 'approved' or (rec.get('review_status') == 'approved' and not is_model_reviewer)) and bool(reviewer)

            # Bağlam ve görsel doğrulaması: Görsel veya bağlam değişmişse eski onay geçersizdir
            p = Path(path)
            if not p.is_file() or file_hash(p) != rec.get('image_sha256'):
                decision['reason'] = 'Görsel dosyası değişmiş veya eksik; onay geçersiz kılındı.'
                continue

            curr_ctx_hash = compute_record_context_hash(title, target_dis, rec.get('original_caption', ''), target_claim, modality, rec.get('image_sha256', ''))
            if rec.get('approved_context_hash') and rec['approved_context_hash'] != curr_ctx_hash:
                has_human_approval = False
                decision['reason'] = 'Slayt başlığı veya bağlam değiştiğinden insan onayı yeniden inceleme gerektirir.'

            # Yerleştirme politikası:
            # 1. Açık insan uzman onayı varsa yerleştirilir.
            # 2. allow_model_placement=True ve model_review tam uyumluysa yerleştirilir (model_placed olarak işaretlenir).
            # Aksi hâlde review_required kalır.
            can_place = False
            placement_status = 'approved_record_used'

            if has_human_approval:
                can_place = True
                placement_status = 'human_approved_record_used'
            elif allow_model_placement and v_res and v_res.model_decision == 'compatible':
                can_place = True
                placement_status = 'model_approved_record_used'

            if not can_place:
                decision['reason'] = 'Human expert review required (model approval is separate from expert approval)'
                continue

            if not all(rec.get(key) for key in ('source_id', 'page', 'figure_id', 'panel_id', 'modality', 'original_caption', 'image_sha256')):
                continue
            if not isinstance(rec.get('bbox'), list) or len(rec['bbox']) != 4:
                continue
            if modality and rec['modality'] != modality:
                continue

            cached = self.ensure_rgb_cached(p)
            if cached is None:
                continue

            caption = f"{rec['original_caption']} [{rec['source_id']}, PDF s.{rec['page']}, {rec['figure_id']}/{rec['panel_id']}]"
            decision.update(status=placement_status, reason='Approved record and content hash matched',
                            image_sha256=rec['image_sha256'], source_id=rec['source_id'], path=path)
            self.decisions.append(decision)
            return cached, caption

        self.decisions.append(decision)
        return None, ''

    def write_manifest(self, path):
        atomic_json(path, {'schema_version': 2, 'decisions': self.decisions,
                           'review_required': sum(d['status'] == 'review_required' for d in self.decisions)})

def get_slide_visual(chapter_num, title, category, explicit_path=None, explicit_caption=None, **kwargs):
    return RetinaVisualResolver.get_instance().resolve_visual(chapter_num, title, category, explicit_path, explicit_caption, **kwargs)
