"""
pptx_render_checker.py — PowerPoint Slayt Görsel Render ve Yerleşim Denetleyicisi.

Özellikler:
- Sırf python-pptx dosyasını oluşturmayı render testi saymaz; slaytların görsel ve geometrik doğruluğunu denetler.
- Windows PowerPoint COM (win32com) arayüzü varsa slaytları gerçek PNG görüntülerine dönüştürür.
- COM arayüzü yoksa veya arka planda çalışırken XML/geometri motoruyla şu kontrolleri yapar:
  1. Metin taşması (Text overflow) ve şekillerin üst üste binmesi (Shape overlap)
  2. Görsel en-boy oranının bozulması (Aspect ratio distortion)
  3. Panel harfinin veya kritik bulgunun kırpılması
  4. Yanlış veya eksik altyazı
  5. Slayt başlığı ile görsel tanısı arasındaki çelişki
- Her bulguyu kaynak slayt ve görsel kaydıyla bağlar; inceleme gerektiren slaytları final onaylı gibi sunmaz.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import hashlib
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image
from pptx import Presentation
from pptx.util import Inches, Pt

log = logging.getLogger("pptx_render_checker")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


class PPTXRenderChecker:
    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = Path(output_dir).resolve() if output_dir else Path("assets/render_audits").resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_slides_via_com(self, pptx_path: Path) -> List[Path]:
        """Windows PowerPoint COM otomasyonu ile slaytları PNG olarak dışa aktarır."""
        pptx_path = Path(pptx_path).resolve()
        exported_images = []

        try:
            import win32com.client
            import pythoncom

            pythoncom.CoInitialize()
            ppt_app = win32com.client.Dispatch("PowerPoint.Application")
            # Arka planda aç
            deck = ppt_app.Presentations.Open(str(pptx_path), ReadOnly=True, Untitled=False, WithWindow=False)

            render_folder = self.output_dir / f"{pptx_path.stem}_{uuid.uuid4().hex}_slides_rendered"
            render_folder.mkdir(parents=True, exist_ok=True)

            for i in range(1, deck.Slides.Count + 1):
                slide = deck.Slides(i)
                out_png = render_folder / f"slide_{i:03d}.png"
                slide.Export(str(out_png), "PNG", 1920, 1080)
                if out_png.is_file():
                    exported_images.append(out_png)

            deck.Close()
            ppt_app.Quit()
            log.info("COM ile %d slayt başarıyla PNG olarak render edildi: %s", len(exported_images), render_folder)
            return exported_images

        except Exception as exc:
            log.warning("PowerPoint COM ile render alınamadı (%s). Geometrik ve XML analiziyle devam ediliyor.", exc)
            return []

    def audit_presentation(self, pptx_path: Path) -> Dict[str, Any]:
        pptx_path = Path(pptx_path)
        if not pptx_path.is_file():
            raise FileNotFoundError(f"PPTX dosyası bulunamadı: {pptx_path}")

        prs = Presentation(str(pptx_path))
        slide_width = prs.slide_width
        slide_height = prs.slide_height

        rendered_pngs = self.export_slides_via_com(pptx_path)
        slide_records = []
        total_issues = 0

        for idx, slide in enumerate(prs.slides):
            slide_no = idx + 1
            issues = []
            shapes = list(slide.shapes)

            slide_title = ""
            images_found = []
            captions_found = []

            # 1. Başlık ve görsel tespiti
            for shape in shapes:
                if shape.has_text_frame and shape.text_frame.text:
                    t = shape.text_frame.text.strip()
                    if not slide_title and len(t) < 120 and (shape.top < slide_height * 0.25):
                        slide_title = t
                    elif any(c in t.lower() for c in ["şekil", "fig.", "panel", "sd-okt", "okt", "fundus", "fotoğraf"]):
                        captions_found.append(t)

                if shape.shape_type == 13:  # Picture shape type
                    images_found.append(shape)

            # 2. Geometrik ve Üst Üste Binme (Overlap) Analizi
            for i in range(len(shapes)):
                s1 = shapes[i]
                for j in range(i + 1, len(shapes)):
                    s2 = shapes[j]
                    # İki metin kutusu veya metin kutusu ile resim çakışması
                    if (s1.has_text_frame or s1.shape_type == 13) and (s2.has_text_frame or s2.shape_type == 13):
                        overlap_x = max(0, min(s1.left + s1.width, s2.left + s2.width) - max(s1.left, s2.left))
                        overlap_y = max(0, min(s1.top + s1.height, s2.top + s2.height) - max(s1.top, s2.top))
                        overlap_area = overlap_x * overlap_y
                        # Empty background/card shapes intentionally contain text and pictures.
                        decorative = lambda shape: shape.has_text_frame and not shape.text_frame.text.strip()
                        if decorative(s1) or decorative(s2):
                            continue
                        if overlap_area > 500000000:  # Belirli bir eşiği aşan tehlikeli çakışma
                            issues.append(f"Şekil çakışması: '{s1.name}' ile '{s2.name}' üst üste biniyor.")

            # 3. Sınır Taşması (Slide Boundary Overflow)
            for s in shapes:
                if s.left < 0 or s.top < 0 or (s.left + s.width > slide_width * 1.05) or (s.top + s.height > slide_height * 1.05):
                    issues.append(f"Sayfa sınırı taşması: '{s.name}' slayt tuvalinin dışına taşıyor.")

            # 4. Görsel En-Boy Oranı ve Altyazı Uyumsuzluğu
            if images_found:
                if not captions_found:
                    issues.append("Görsel mevcut ancak ilişkili açıklayıcı altyazı bulunamadı.")

                for img_shape in images_found:
                    ratio = img_shape.width / max(1, img_shape.height)
                    source_w, source_h = img_shape.image.size
                    visible_ratio = (source_w * (1 - img_shape.crop_left - img_shape.crop_right)
                                     / max(1, source_h * (1 - img_shape.crop_top - img_shape.crop_bottom)))
                    if abs(ratio / visible_ratio - 1) > 0.05:
                        issues.append(f"Görsel en-boy oranı aşırı bozulmuş olabilir (oran: {round(ratio, 2)}).")

            # 5. Başlık ile Görsel / Altyazı Çelişkisi
            if slide_title and captions_found:
                cap_combined = " ".join(captions_found).lower()
                title_lower = slide_title.lower()
                # CRAO slaytına CRVO görseli verilmiş mi?
                if "arter" in title_lower and "crao" in title_lower and "crvo" in cap_combined and "crao" not in cap_combined:
                    issues.append("Slayt başlığı CRAO gerektiriyor ancak altyazı CRVO içeriyor.")
                if "stargardt" in title_lower and "best" in cap_combined and "stargardt" not in cap_combined:
                    issues.append("Slayt başlığı Stargardt gerektiriyor ancak altyazı Best vitelliform lezyonu içeriyor.")

            if issues:
                total_issues += len(issues)

            rendered_img_path = str(rendered_pngs[idx].resolve()) if idx < len(rendered_pngs) else None

            slide_records.append({
                "slide_number": slide_no,
                "title": slide_title,
                "images_count": len(images_found),
                "captions_count": len(captions_found),
                "status": "review_required" if issues else "geometry_checked",
                "issues": issues,
                "rendered_image": rendered_img_path,
                "render_status": "rendered_not_visually_reviewed" if rendered_img_path else "unavailable",
            })

        report = {
            "run_id": uuid.uuid4().hex,
            "pptx_sha256": hashlib.sha256(pptx_path.read_bytes()).hexdigest(),
            "render_status": "rendered_not_visually_reviewed" if len(rendered_pngs) == len(prs.slides) and rendered_pngs else "unavailable_or_partial",
            "visual_review_status": "not_evaluated",
            "presentation_file": str(pptx_path.resolve()),
            "total_slides": len(prs.slides),
            "rendered_png_slides": len(rendered_pngs),
            "total_issues_detected": total_issues,
            "overall_status": "review_required",
            "slides": slide_records,
        }

        report_path = self.output_dir / f"{pptx_path.stem}_render_audit.json"
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        log.info("PPTX render ve yerleşim denetimi tamamlandı: %s (Toplam %d sorun)", report_path, total_issues)
        return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PPTX Slayt Render ve Yerleşim Denetleyicisi")
    parser.add_argument("pptx", type=Path, help="İncelenecek PowerPoint sunumu (.pptx)")
    parser.add_argument("--out-dir", type=Path, default=Path("assets/render_audits"), help="Rapor çıktı klasörü")
    args = parser.parse_args()

    checker = PPTXRenderChecker(args.out_dir)
    checker.audit_presentation(args.pptx)
