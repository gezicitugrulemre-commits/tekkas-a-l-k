"""
build_comprehensive_dr_dmo_masterclass.py — 280 Slaytlık İleri Düzey DR & DMÖ Masterclass Derleyicisi
Tüm güncel literatür, DRCR.net protokolleri, 40 görsel atlası ve LangGraph mimarisi.
"""

from __future__ import annotations

import sys
import os
import time
from pathlib import Path

# UTF-8 ayarı
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.append(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")

from dr_masterclass_engine import MasterclassPublisher
from dr_masterclass_data_part1 import build_part1_slides
from dr_masterclass_data_part2 import build_part2_slides
from dr_masterclass_data_part3 import build_part3_slides

OUTPUT_PPTX_PATH = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity\Diyabetik_Retinopati_ve_DMO_Kapsamli_Masterclass.pptx")


def generate_masterclass_deck():
    start_time = time.time()
    print("=" * 70)
    print("DİYABETİK RETİNOPATİ VE DMÖ — 280 SLAYTLIK MASTERCLASS DERLEYİCİSİ")
    print("=" * 70)

    # 1. Motoru Başlat
    print("[1/5] 16:9 Geniş Ekran Sunum Motoru Başlatılıyor...")
    publisher = MasterclassPublisher(
        title="DİYABETİK RETİNOPATİ VE DİYABETİK MAKULA ÖDEMİ",
        subtitle="AAO BCSC Sec 12, Ryan's Retina, Atlas of Retinal OCT ve Landmark RKÇ'ler İleri Düzey Çalışma Atlası"
    )

    # 2. Modül 1 (Slayt 1 - 86)
    print("[2/5] Bölüm 1 - 4 İnşa Ediliyor (Epidemiyoloji, Moleküler Patogenez, Multimodal Görüntüleme, DMÖ Sınıflaması)...")
    build_part1_slides(publisher)
    print(f" -> Güncel Slayt Sayısı: {len(publisher.prs.slides)}")

    # 3. Modül 2 (Slayt 87 - 188)
    print("[3/5] Bölüm 5 - 8 İnşa Ediliyor (Anti-VEGF Protokol T/I/S/W, Faricimab, 8mg HD, PDS, Steroid/Lazer, 25G/27G PPV)...")
    build_part2_slides(publisher)
    print(f" -> Güncel Slayt Sayısı: {len(publisher.prs.slides)}")

    # 4. Modül 3 (Slayt 189 - 280)
    print("[4/5] Bölüm 9 - 12 İnşa Ediliyor (LENS, GLP-1, Gebelik, ASM/SUT/GEE, 40 Görselden Oluşan Büyük Atlas, 7 Aktif Vaka)...")
    build_part3_slides(publisher)
    print(f" -> Güncel Slayt Sayısı: {len(publisher.prs.slides)}")

    # 5. Geometri ve Bilişsel Yük Denetimi
    print("[5/5] Layout Triage ve Bilişsel Yük Geometri Denetimi Yapılıyor...")
    audit_report = publisher.audit_slide_deck_layout()

    print("\n--- MASTERCLASS PPTX YERLEŞİM VE BİLİŞSEL YÜK DENETİM RAPORU ---")
    print(f"Toplam Slayt Sayısı   : {audit_report['total_slides']}")
    print(f"Geometri Taşması      : {len(audit_report['overflow_issues'])} adet")
    print(f"Yoğunluk Uyarısı      : {len(audit_report['density_warnings'])} adet")
    print(f"Eksik Konuşmacı Notu  : {len(audit_report['missing_notes'])} adet")
    print(f"Denetim Onayı         : {'BAŞARILI (PASSED)' if audit_report['passed'] else 'DÜZELTME GEREKLİ (FAILED)'}")

    if audit_report["overflow_issues"]:
        print("\nUyarı! Taşma Yaşanan Slaytlar:")
        for iss in audit_report["overflow_issues"][:5]:
            print(f" - {iss}")

    # Kaydet (Hem v2 hem ana dosya güncellenir)
    target_names = [
        "Diyabetik_Retinopati_ve_DMO_Kapsamli_Masterclass_v2.pptx",
        "Diyabetik_Retinopati_ve_DMO_Kapsamli_Masterclass.pptx"
    ]
    saved_paths = []
    for t_name in target_names:
        t_path = OUTPUT_PPTX_PATH.with_name(t_name)
        try:
            sp = publisher.save(t_path)
            saved_paths.append(sp)
            print(f"\nPowerPoint dosyası başarıyla kaydedildi: {sp.name}")
        except PermissionError:
            print(f"\nUyarı: {t_name} açık olduğu için üzerine yazılamadı.")

    if not saved_paths:
        # Alternatif ad dene
        fallback_p = OUTPUT_PPTX_PATH.with_name("Diyabetik_Retinopati_ve_DMO_Kapsamli_Masterclass_v3.pptx")
        saved_paths.append(publisher.save(fallback_p))
        print(f"\nPowerPoint alternatif adla kaydedildi: {fallback_p.name}")

    saved_path = saved_paths[0]
    elapsed = time.time() - start_time
    print(f"\nİşlem {elapsed:.2f} saniyede başarıyla tamamlandı.")
    print(f"Dosya Boyutu: {saved_path.stat().st_size / (1024 * 1024):.2f} MB")
    print("=" * 70)
    return saved_path


if __name__ == "__main__":
    generate_masterclass_deck()
