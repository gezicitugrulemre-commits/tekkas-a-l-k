import json
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

with open('all_slides_extracted_info.json', 'r', encoding='utf-8') as f:
    slides = json.load(f)

with open('retina_precise_registry.json', 'r', encoding='utf-8') as f:
    reg = json.load(f)['registry']

def classify_slide_perfect(slide):
    title = slide['title'].upper()
    cat = slide['category'].upper()
    sub = slide['subtitle'].upper()
    full = f"{cat} || {title} || {sub}"

    # 1. High-priority Title Disease Keywords (Global Overrides)
    # Chapter 3 Vascular
    if "CRAO" in title or "ARTER TIKANIKLIĞI" in title or "SANTRAL RETİNAL ARTER" in title or "KİRAZ KIRMIZISI" in title or "CHERRY-RED" in title or "BRAO" in title:
        return "3.3.1"
    if "CRVO" in title or "SANTRAL RETİNAL VEN" in title or "KAN FIRTINASI" in title:
        return "3.2.2"
    if "BRVO" in title or "DAL RETİNAL VEN" in title or "BRANŞ" in title:
        return "3.2.1"
    if "COATS" in title:
        return "3.4.2"
    if "MAKROANEVRİZMA" in title or " RAM " in f" {title} ":
        return "3.3.2"
    if "MACTEL" in title or "TELENJİEKTAZİ TİP 2" in title:
        return "3.4.3"
    if "ORAK HÜCRE" in title or "SICKLE" in title or "SEA FAN" in title:
        return "3.4.4"
    if "OİS" in title or "OIS" in title or "OKÜLER İSKEMİK" in title:
        return "3.4.1"
    if "ROP" in title or "PREMATÜRE RETİNOPATİ" in title:
        return "3.4.4"
    if "DMÖ" in title or "DME" in title or ("MAKULA ÖDEMİ" in title and "DİYABETİK" in full):
        return "3.1.2"
    if "PDR" in title or "PROLİFERATİF DİYABETİK" in title or "NVD" in title or "NVE" in title:
        return "3.1.3"
    if "NPDR" in title or "NONPROLİFERATİF" in title:
        return "3.1.1"

    # Chapter 4 Macula
    if "POLİPOİDAL" in title or "PCV" in title or "EVEREST" in title or "PLANET" in title:
        return "4.1.3"
    if "ERM" in title or "EPİRETİNAL" in title or "PUCKER" in title or "VMT" in title or "VİTREOMAKÜLER TRAKSİYON" in title:
        return "4.3.2"
    if "MAKULA DELİĞİ" in title or "FTMH" in title or "DELİK" in title:
        return "4.3.1"
    if "SSKR" in title or "CSCR" in title or "SANTRAL SERÖZ" in title:
        return "4.2.1"
    if "PAKİKOROİD" in title or "PACHYCHOROID" in title or "PAKİVESSEL" in title:
        return "4.2.2"
    if "MİYO" in title or "STAFİLO" in title or "FUCHS" in title or "LACQUER" in title:
        return "4.4.1"
    if "ANJİYOİD ÇİZGİ" in title or "ANGIOID" in title or "PEAU D'ORANGE" in title:
        return "4.4.2"
    if "YAŞ TİP" in title or "MNV" in title or "NEOVASKÜLER YBMD" in title or "CNV" in title:
        return "4.1.2"
    if "KURU TİP" in title or "COĞRAFİ ATROFİ" in title or "GEOGRAPHIC ATROPHY" in title:
        return "4.1.1"
    if "DRUSEN" in title:
        return "4.1.1"

    # Chapter 6 Dystrophies
    if "STARGARDT" in title or "ABCA4" in title:
        return "6.1.2"
    if "BEST" in title or "VİTELLİFORM" in title or "BEST1" in title:
        return "6.1.3"
    if "KONİ-ROD" in title or "KONİ DİSTROFİ" in title or "BULL'S EYE" in title or "BOĞA GÖZÜ" in title:
        return "6.1.4"
    if "LEBER" in title or "LCA" in title:
        return "6.1.5"
    if "RETİNOŞİZİS" in title or "XLRS" in title:
        return "6.2.1"
    if "KOROİDEREMİ" in title or "JİRAT" in title or "GYRATE" in title:
        return "6.2.2"
    if "STİCKLER" in title or "FEVR" in title:
        return "6.2.3"
    if "RETİNİTİS PİGMENTOSA" in title or " RP " in f" {title} " or "USHER" in title:
        return "6.1.1"

    # Chapter 7 Infections / Inflammation
    if "ARN" in title or "AKUT RETİNAL NEKROZ" in title or "PORN" in title:
        return "7.1.3"
    if "CMV" in title or "SİTOMEGALO" in title or "PİZZA-PİE" in title:
        return "7.1.2"
    if "TOKSOPLAZMO" in title or "TOXO" in title or "SİSTE ARABA FARI" in title or "SİS İÇİNDE FAR" in title:
        return "7.1.1"
    if "TÜBERKÜLOZ" in title or "SİFİLİZ" in title:
        return "7.1.4"
    if "ENDOFTALMİ" in title or "EVS" in title:
        return "7.1.5"
    if "BEHÇET" in title:
        return "7.2.3"
    if "VKH" in title or "VOGT" in title or "HARADA" in title or "SARKOİDOZ" in title or "SEMPATİK" in title:
        return "7.2.1"
    if "BEYAZ NOKTA" in title or "MEWDS" in title or "APMPPE" in title or "BİRDSHOT" in title or "SERPİNÖZ" in title or "PIC" in title or "MFC" in title:
        return "7.2.2"

    # Chapter 8 Tumors
    if "RETİNOBLASTOM" in title or "RB" in title or "LÖKOKORİ" in title:
        return "8.2.2"
    if "MELANOM" in title:
        return "8.1.2"
    if "NEVÜS" in title or "TFSOM" in title:
        return "8.1.1"
    if "HEMANJİOM" in title or "OSTEOM" in title:
        return "8.1.3"
    if "HEMANJİYOBLASTOM" in title or "VHL" in title:
        return "8.2.1"
    if "LENFOMA" in title or "METASTAZ" in title:
        return "8.2.3"

    # Chapter 9 Trauma & Treatment
    if "COMMOTIO" in title or "BERLİN" in title or "KOROİD RÜPTÜR" in title or "PURTSCHER" in title or "KÜNT TRAVMA" in title:
        return "9.1.1"
    if "YABANCI CİSİM" in title or "İOYC" in title or "SİDEROZİS" in title or "AÇIK GLOB" in title or "GLOB" in title:
        return "9.1.2"
    if "YAPAY ZEKA" in title or "TELEOFTALMOLOJİ" in title or "TELETIP" in title:
        return "9.3.2"
    if "GEN TEDAVİSİ" in title or "LUXTURNA" in title or "KÖK HÜCRE" in title or "BİYONİK" in title:
        return "9.3.1"
    if "ANTİ-VEGF" in title or "AFLİBERCEPT" in title or "FARİCİMAB" in title:
        return "9.2.1"
    if "STEROİD" in title or "OZURDEX" in title or "DEKSAMETAZON" in title:
        return "9.2.2"

    # Chapter 5 Detachment & Periphery
    if "LATTİCE" in title or "KAFES" in title or "SNAIL" in title or "COBBLESTONE" in title:
        return "5.2.1"
    if "PVR" in title or "PROLİFERATİF VİTREORETİNOPATİ" in title or "STAR FOLD" in title:
        return "5.2.2"
    if "TRD" in title or "TRAKSİYONEL" in title:
        return "5.1.3"
    if "RRD" in title or "YIRTILMALI" in title or "REGMATOJEN" in title or "LİNCOFF" in title:
        return "5.1.2"
    if "PVD" in title or "ARKA VİTREUS" in title or "WEİSS" in title or "AT NALI" in title:
        return "5.1.1"
    if "VİTREKTOMİ" in title or "PPV" in title or "SKLERAL ÇÖKERTME" in title or "BUCKLE" in title:
        return "5.3.1"
    if "SİLİKON" in title or "GAZ TAMPONAD" in title or "C3F8" in title or "SF6" in title:
        return "5.3.2"

    # Chapter 10 Statistics & Cases
    if "İSTATİSTİK" in title or "EYE-LEVEL" in title or "PATIENT-LEVEL" in title or "GEE" in title:
        return "10.2"
    if "VAKA" in title or "BOARD" in title:
        return "10.3"
    if "MATRİS" in title or "KARŞILAŞTIRMA" in title:
        return "10.1"

    # 2. Category Fallbacks (when title is descriptive without exact disease keyword)
    idx = slide['index']
    if idx <= 48: # Chapter 1
        if "1.1.1" in cat: return "1.1.1"
        if "1.1.2" in cat: return "1.1.2"
        if "1.1.3" in cat: return "1.1.3"
        if "1.1.4" in cat: return "1.1.4"
        if "1.2.1" in cat: return "1.2.1"
        if "1.2.2" in cat: return "1.2.2"
        if "1.2.3" in cat: return "1.2.3"
        if "1.3.1" in cat: return "1.3.1"
        if "1.3.2" in cat: return "1.3.2"
        return "1.1.2"

    if idx <= 111: # Chapter 2
        if "2.1.1" in cat: return "2.1.1"
        if "2.1.2" in cat: return "2.1.2"
        if "2.1.3" in cat: return "4.2.2"
        if "2.2.1" in cat or "2.2.2" in cat or "2.2.3" in cat: return "2.1.2"
        if "2.3.1" in cat: return "2.2.1"
        if "2.3.2" in cat: return "2.2.2"
        if "2.3.3" in cat: return "3.1.3"
        if "2.4.1" in cat: return "2.3.1"
        if "2.4.2" in cat: return "2.3.2"
        if "2.5.1" in cat: return "2.4.1"
        return "2.1.1"

    if idx <= 167: # Chapter 3
        if "3.1.1" in cat: return "3.1.1"
        if "3.1.2" in cat: return "3.1.2"
        if "3.1.3" in cat: return "3.1.3"
        if "3.2.1" in cat: return "3.2.1"
        if "3.2.2" in cat: return "3.3.1"
        if "3.3.1" in cat: return "3.4.2"
        if "3.3.2" in cat: return "3.4.4"
        return "3.1.1"

    if idx <= 219: # Chapter 4
        if "4.1.1" in cat: return "4.1.1"
        if "4.1.2" in cat: return "4.1.2"
        if "4.1.3" in cat: return "4.1.3"
        if "4.2.1" in cat: return "4.2.1"
        if "4.2.2" in cat: return "4.2.2"
        if "4.3.1" in cat: return "4.3.1"
        if "4.3.2" in cat: return "4.3.2"
        if "4.4.1" in cat: return "4.4.1"
        if "4.4.2" in cat: return "4.4.2"
        return "4.1.1"

    if idx <= 260: # Chapter 5
        if "5.1.1" in cat: return "5.1.1"
        if "5.1.2" in cat: return "5.1.2"
        if "5.1.3" in cat: return "5.1.3"
        if "5.2.1" in cat: return "5.2.1"
        if "5.2.2" in cat: return "5.2.2"
        if "5.3.1" in cat: return "5.3.1"
        if "5.3.2" in cat: return "5.3.2"
        return "5.1.2"

    if idx <= 299: # Chapter 6
        if "6.1.1" in cat: return "6.1.1"
        if "6.1.2" in cat: return "6.1.4"
        if "6.1.3" in cat: return "6.1.2"
        if "6.2.1" in cat: return "6.2.1"
        if "6.2.2" in cat: return "9.3.1"
        return "6.1.1"

    if idx <= 361: # Chapter 7
        if "7.1.1" in cat: return "7.1.3"
        if "7.1.2" in cat: return "7.1.1"
        if "7.2.1" in cat: return "7.2.3"
        if "7.2.2" in cat: return "7.2.1"
        if "7.3." in cat: return "7.2.2"
        return "7.1.1"

    if idx <= 387: # Chapter 8
        if "8.1.1" in cat: return "8.2.2"
        if "8.1.2" in cat: return "8.1.2"
        if "8.1.3" in cat: return "8.1.3"
        return "8.1.2"

    if idx <= 418: # Chapter 9
        if "9.1.1" in cat: return "9.1.1"
        if "9.1.2" in cat: return "7.1.5"
        if "9.2.1" in cat: return "9.3.2"
        if "9.2.2" in cat: return "9.3.1"
        return "9.1.1"

    return "10.1"

# Now evaluate across all 366 image slides
plan = []
used_images = set()

for s in slides:
    if not s['has_pic']:
        continue
    idx = s['index']
    title = s['title']
    cat = s['category']
    sub = s['subtitle']
    old_cap = s['caption']

    rule_key = classify_slide_perfect(s)
    candidates = reg.get(rule_key, [])

    title_words = set(re.findall(r'\w{4,}', (title + " " + sub).lower()))

    best_cand = None
    best_score = -100

    for cand in candidates:
        c_path = cand.get('path', '')
        if not c_path or not Path(c_path).exists():
            continue

        orig_cap = cand.get('original_caption', '').lower()
        fn = cand.get('filename', '').lower()
        combined = orig_cap + " " + fn

        score = cand.get('score', 5)

        if c_path in used_images:
            score -= 50

        # Topic boosts
        if "crao" in (title + sub).lower() and ("artery occlusion" in combined or "crao" in combined):
            score += 40
        if "crvo" in (title + sub).lower() and ("vein occlusion" in combined or "crvo" in combined):
            score += 40
        if "brvo" in (title + sub).lower() and ("branch" in combined or "brvo" in combined):
            score += 40
        if "stargardt" in (title + sub).lower() and "stargardt" in combined:
            score += 50
        if "best" in (title + sub).lower() and ("best" in combined or "vitelliform" in combined):
            score += 50
        if "arn" in (title + sub).lower() and ("acute retinal necrosis" in combined or "arn" in combined):
            score += 50
        if "cmv" in (title + sub).lower() and ("cytomegalovirus" in combined or "cmv" in combined):
            score += 50
        if "tokso" in (title + sub).lower() and ("toxoplas" in combined or "toxo" in combined):
            score += 50
        if "retinoblastom" in (title + sub).lower() and "retinoblastoma" in combined:
            score += 50
        if "melanom" in (title + sub).lower() and ("melanoma" in combined or "mushroom" in combined):
            score += 50
        if "erm" in (title + sub).lower() and ("epiretinal" in combined or "pucker" in combined):
            score += 50
        if "delik" in (title + sub).lower() or "hole" in (title + sub).lower():
            if "macular hole" in combined:
                score += 50

        for w in title_words:
            if len(w) > 3 and w in combined:
                score += 5

        if score > best_score:
            best_score = score
            best_cand = cand

    if not best_cand and candidates:
        best_cand = candidates[0]

    if best_cand:
        used_images.add(best_cand.get('path'))

        book_source = best_cand.get('book', 'Retina Atlası')
        short_book = book_source.replace('.pdf', '').replace('_', ' ')
        if "THE RETINAL ATLAS" in short_book:
            short_book = "The Retinal Atlas"
        elif "RYAN" in short_book:
            short_book = "Ryan's Retina 7th Ed."
        elif "12-Retina" in short_book:
            short_book = "AAO BCSC Retina"
        elif "Atlas of Retinal OCT" in short_book:
            short_book = "Atlas of Retinal OCT"
        elif "Uveitis" in short_book:
            short_book = "The Uveitis Atlas"
        elif "Pathology" in short_book:
            short_book = "Ophthalmic Pathology"

        default_cap = best_cand.get('caption', '')
        if not default_cap.startswith('📷'):
            default_cap = f"📷 {default_cap}"

        full_cap = f"{default_cap} [{short_book}]"

        plan.append({
            'slide': idx,
            'title': title,
            'rule': rule_key,
            'selected_image': best_cand.get('path'),
            'image_filename': best_cand.get('filename'),
            'book': short_book,
            'caption': full_cap,
            'old_caption': old_cap,
            'score': best_score
        })

print(f"Total planned replacements: {len(plan)}")
print(f"Total unique images selected: {len(used_images)}")

with open('perfect_image_revision_plan.json', 'w', encoding='utf-8') as f:
    json.dump(plan, f, ensure_ascii=False, indent=2)

# Check critical test slides
test_cases = [138, 145, 206, 276, 302, 309, 363, 364, 389, 412]
print("\nCritical test slides verification:")
for p in plan:
    if p['slide'] in test_cases:
        print(f"S{p['slide']:03d} | Tit: {p['title'][:32]:<32} | Rule: {p['rule']:5s} | Cap: {p['caption'][:55]}")
