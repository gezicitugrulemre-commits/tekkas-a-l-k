# -*- coding: utf-8 -*-
"""
Kanski Klinik Oftalmoloji Soru Bankası PDF Dizgi Motoru (kanski_pdf_publisher.py)
ReportLab 5.x tabanlı, TrueType Unicode Arial fontları ile tam Türkçe karakter desteği
(ç, ğ, ı, ö, ş, ü, Ç, Ğ, İ, Ö, Ş, Ü), iki geçişli dinamik sayfa numaralandırmalı (NumberedCanvas),
kitap ayracı (bookmark) hiyerarşili, renkli soru şeritli ve 10 sütunlu
hızlı cevap anahtarlı yayım kalitesinde PDF üretir.
"""

from __future__ import annotations

import html
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import reportlab
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    HRFlowable,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

if sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from kanski_metadata import CHAPTERS_METADATA, ChapterMeta, get_chapter_meta

# ==============================================================================
# UNICODE TRUETYPE FONT KAYDI (TÜRKÇE KARAKTERLER İÇİN ZORUNLU)
# ==============================================================================
_FONTS_REGISTERED = False


def register_fonts() -> None:
    global _FONTS_REGISTERED
    if _FONTS_REGISTERED:
        return

    regular = "C:/Windows/Fonts/arial.ttf"
    bold = "C:/Windows/Fonts/arialbd.ttf"
    italic = "C:/Windows/Fonts/ariali.ttf"
    bold_italic = "C:/Windows/Fonts/arialbi.ttf"

    if not Path(regular).is_file():
        # Yedek alternatif fontlar
        regular = "C:/Windows/Fonts/segoeui.ttf"
        bold = "C:/Windows/Fonts/segoeuib.ttf"
        italic = "C:/Windows/Fonts/segoeuii.ttf"
        bold_italic = "C:/Windows/Fonts/segoeuiz.ttf"

    pdfmetrics.registerFont(TTFont("Arial", regular))
    pdfmetrics.registerFont(TTFont("Arial-Bold", bold))
    pdfmetrics.registerFont(TTFont("Arial-Italic", italic))
    pdfmetrics.registerFont(TTFont("Arial-BoldItalic", bold_italic))

    pdfmetrics.registerFontFamily(
        "Arial",
        normal="Arial",
        bold="Arial-Bold",
        italic="Arial-Italic",
        boldItalic="Arial-BoldItalic",
    )
    _FONTS_REGISTERED = True


register_fonts()


def tr_upper(text: str) -> str:
    """Türkçe karakter duyarlı büyük harf dönüşümü (i -> İ, ı -> I)."""
    if not text:
        return ""
    return (
        text.replace("i", "İ")
        .replace("ı", "I")
        .replace("ğ", "Ğ")
        .replace("ü", "Ü")
        .replace("ş", "Ş")
        .replace("ö", "Ö")
        .replace("ç", "Ç")
        .upper()
    )


# Renk Paleti (Akademik Kurumsal Standart)
INK = HexColor("#0F172A")          # Koyu arduvaz
MUTED = HexColor("#475569")        # İkincil gri
BLUE = HexColor("#1E40AF")         # Tıbbi mavi
BLUE_BG = HexColor("#EFF6FF")      # Açık mavi zemin
PURPLE = HexColor("#6B21A8")       # Mor vurgu
PURPLE_BG = HexColor("#F5F3FF")    # Açık mor zemin
GREEN = HexColor("#15803D")        # Klinik çözüm yeşili
GREEN_BG = HexColor("#F0FDF4")     # Açık yeşil zemin
AMBER = HexColor("#B45309")        # Uyarı kehribarı
AMBER_BG = HexColor("#FFFBEB")     # Açık kehribar zemin
LINE = HexColor("#CBD5E1")         # İnce kenarlık çizgisi
WHITE = colors.white

OUTPUT_DIR = Path(r"C:\Users\gezic\OneDrive\Desktop\Anti Gravity\output\kanski_qbank")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


class NumberedCanvas(canvas.Canvas):
    """İki geçişli dinamik sayfa numaralandırma ve koşan başlık/altlık şablonu (Unicode Arial)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, total_pages: int):
        self.saveState()
        self.setFont("Arial", 8)
        self.setFillColor(MUTED)

        # Kapak sayfasında başlık/altlık çizme
        if self._pageNumber > 1:
            # Koşan Üst Başlık (Running Header)
            self.drawString(
                18 * mm,
                285 * mm,
                "KANSKI'S CLINICAL OPHTHALMOLOGY (10. BASKI) — MASTER SORU BANKASI"
            )
            self.setStrokeColor(LINE)
            self.setLineWidth(0.5)
            self.line(18 * mm, 283 * mm, 192 * mm, 283 * mm)

            # Koşan Alt Bilgi (Footer) & Dinamik Sayfa Sayısı
            page_text = f"Sayfa {self._pageNumber} / {total_pages}"
            self.drawRightString(192 * mm, 12 * mm, page_text)
            self.drawString(
                18 * mm,
                12 * mm,
                "TUS • YDUS • FEBO • ICO Board Düzeyi Oftalmoloji Soru Bankası"
            )
            self.line(18 * mm, 15 * mm, 192 * mm, 15 * mm)

        self.restoreState()


class KanskiPDFPublisher:
    def __init__(self, output_dir: Optional[Path | str] = None):
        register_fonts()
        self.output_dir = Path(output_dir or OUTPUT_DIR)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _esc(self, text: str) -> str:
        """HTML ve Markdown kaçışlarını ReportLab etiketlerine dönüştürür."""
        if not text:
            return ""
        s = html.escape(str(text))
        # Markdown **bold** -> <b>...</b>
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        # Markdown *italic* -> <i>...</i>
        s = re.sub(r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<i>\1</i>", s)
        return s

    def build_chapter_pdf(
        self,
        chapter_id: int,
        questions: List[Dict[str, Any]],
        output_file_name: Optional[str] = None
    ) -> Path:
        """Belirtilen tek bir bölüm için yayım kalitesinde PDF kitapçığı üretir."""
        register_fonts()
        meta = get_chapter_meta(chapter_id)
        if output_file_name is None:
            output_file_name = f"Kanski_Bolum_{chapter_id:02d}_{meta['title_en'].replace(' ', '_')}_Soru_Bankasi.pdf"

        pdf_path = self.output_dir / output_file_name

        doc = SimpleDocTemplate(
            str(pdf_path),
            pagesize=A4,
            leftMargin=18 * mm,
            rightMargin=18 * mm,
            topMargin=18 * mm,
            bottomMargin=18 * mm,
        )

        story: List[Any] = []
        usable_w = 174 * mm

        # Tipografik Stiller (Türkçe Destekli Arial)
        s_title = ParagraphStyle(
            "ChTitle",
            fontName="Arial-Bold",
            fontSize=19,
            leading=24,
            textColor=BLUE,
            alignment=TA_CENTER,
            spaceAfter=6,
        )
        s_subtitle = ParagraphStyle(
            "ChSubTitle",
            fontName="Arial",
            fontSize=10.5,
            leading=15,
            textColor=MUTED,
            alignment=TA_CENTER,
            spaceAfter=12,
        )
        s_badge = ParagraphStyle(
            "BadgeStyle",
            fontName="Arial-Bold",
            fontSize=8.5,
            leading=12,
            textColor=BLUE,
        )
        s_stem = ParagraphStyle(
            "StemStyle",
            fontName="Arial-Bold",
            fontSize=9.5,
            leading=14.5,
            textColor=INK,
            spaceBefore=3,
            spaceAfter=4,
        )
        s_roman = ParagraphStyle(
            "RomanStyle",
            fontName="Arial",
            fontSize=9,
            leading=13.5,
            textColor=INK,
            leftIndent=8,
            spaceAfter=2,
        )
        s_option = ParagraphStyle(
            "OptionStyle",
            fontName="Arial",
            fontSize=9.2,
            leading=13.8,
            textColor=INK,
            leftIndent=10,
            firstLineIndent=-10,
            spaceAfter=2,
        )
        s_expl = ParagraphStyle(
            "ExplStyle",
            fontName="Arial",
            fontSize=8.8,
            leading=13,
            textColor=INK,
            alignment=TA_JUSTIFY,
        )
        s_table_cell = ParagraphStyle(
            "TblCell",
            fontName="Arial",
            fontSize=8,
            leading=11,
            alignment=TA_CENTER,
            textColor=INK,
        )
        s_table_hdr = ParagraphStyle(
            "TblHdr",
            fontName="Arial-Bold",
            fontSize=8.2,
            leading=11,
            alignment=TA_CENTER,
            textColor=WHITE,
        )

        # 1. BÖLÜM KAPAK / GİRİŞ KARTI
        story.append(Spacer(1, 6 * mm))
        story.append(Paragraph(f"BÖLÜM {chapter_id}: {tr_upper(meta['title_tr'])}", s_title))
        story.append(Paragraph(f"Kanski's Clinical Ophthalmology (10. Baskı, Salmon 2025) — {meta['title_en']}", s_subtitle))

        # İstatistik Şerit Tablosu
        stat_data = [
            [
                Paragraph("<b>Kitap Sayfa Aralığı:</b>", s_badge),
                Paragraph(f"s. {meta['book_start_page']} – {meta['book_end_page']} ({meta['page_count']} sayfa)", s_badge),
                Paragraph("<b>Hedef Soru Kotası:</b>", s_badge),
                Paragraph(f"<b>{len(questions)} Soru</b> (Ölçekli Kota)", s_badge),
            ],
            [
                Paragraph("<b>Soru Formatı:</b>", s_badge),
                Paragraph("5 Şıklı (A–E) + Açıklamalı", s_badge),
                Paragraph("<b>Sınav Standardı:</b>", s_badge),
                Paragraph("TUS / YDUS / FEBO / ICO", s_badge),
            ]
        ]
        stat_table = Table(stat_data, colWidths=[38 * mm, 49 * mm, 38 * mm, 49 * mm])
        stat_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), BLUE_BG),
            ("BOX", (0, 0), (-1, -1), 1, BLUE),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(stat_table)
        story.append(Spacer(1, 8 * mm))

        # 2. VEKTÖREL ŞEMATİK DİYAGRAM (300+ DPI Çizim Standardı - Arial)
        drawing = Drawing(usable_w, 48 * mm)
        step_w = 40 * mm
        step_h = 36 * mm
        gap = 4.6 * mm

        steps = [
            ("1. KLİNİK TRİYAJ", "Öykü, Risk Faktörleri,\nErken Bulgular"),
            ("2. MULTİMODAL TANI", "OCT, FFA, USG,\nBiyomikroskopi"),
            ("3. EVRELEME & PROTOKOL", "Kılavuz Kriterleri,\nHedefe Özgü Plan"),
            ("4. İZLEM & SONUÇ", "Objektif İlerleme,\nYapay Zeka Sevk")
        ]

        for idx, (title_step, desc_step) in enumerate(steps):
            x = idx * (step_w + gap)
            drawing.add(Rect(x, 4 * mm, step_w, step_h, rx=3, ry=3, fillColor=BLUE_BG, strokeColor=BLUE, strokeWidth=1))
            drawing.add(String(x + step_w / 2, step_h - 2 * mm, title_step, fontName="Arial-Bold", fontSize=8, textAnchor="middle", fillColor=BLUE))
            lines = desc_step.split("\n")
            for l_idx, line in enumerate(lines):
                drawing.add(String(x + step_w / 2, step_h - 12 * mm - l_idx * 5 * mm, line, fontName="Arial", fontSize=7.2, textAnchor="middle", fillColor=INK))

        story.append(drawing)
        story.append(Spacer(1, 8 * mm))
        story.append(HRFlowable(width="100%", thickness=1, color=LINE, spaceBefore=4, spaceAfter=8))

        # 3. SORULARIN DİZGİSİ
        for q in questions:
            q_flowables: List[Any] = []

            # Renkli Başlık Şeridi
            badge_html = (
                f"<b>SORU {q['local_num']}</b> (Genel: #{q['global_num']}) | "
                f"Konu Kodu: {q['topic_code']} | "
                f"Kategori: <i>{q['category']}</i> | "
                f"Zorluk: <b>{q['difficulty']}</b>"
            )
            q_ribbon_table = Table(
                [[Paragraph(badge_html, s_badge)]],
                colWidths=[usable_w]
            )
            q_ribbon_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), PURPLE_BG),
                ("BOX", (0, 0), (-1, -1), 0.75, PURPLE),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            q_flowables.append(q_ribbon_table)
            q_flowables.append(Spacer(1, 2.5 * mm))

            # Soru Kökü
            q_flowables.append(Paragraph(self._esc(q["stem"]), s_stem))

            # Öncüller (varsa)
            if q.get("roman_items"):
                roman_numerals = ["I.", "II.", "III.", "IV.", "V."]
                for r_idx, r_text in enumerate(q["roman_items"]):
                    r_lbl = roman_numerals[r_idx] if r_idx < len(roman_numerals) else f"{r_idx+1}."
                    q_flowables.append(Paragraph(f"<b>{r_lbl}</b> {self._esc(r_text)}", s_roman))
                q_flowables.append(Spacer(1, 1.5 * mm))

            # Şıklar (A - E)
            for letter in ["A", "B", "C", "D", "E"]:
                opt_val = q["options"].get(letter, "")
                q_flowables.append(Paragraph(f"<b>{letter})</b> {self._esc(opt_val)}", s_option))

            q_flowables.append(Spacer(1, 2.5 * mm))

            # Yeşil Çözüm Kutusu
            cites_str = " ".join(q.get("citations", []))
            expl_html = (
                f"<b>ÇÖZÜM, KLİNİK YORUM VE KAYNAK KANITI:</b><br/>"
                f"{self._esc(q['explanation'])}<br/><br/>"
                f"<font color='{MUTED}'><b>Kaynak:</b> {self._esc(cites_str)}</font>"
            )
            expl_table = Table(
                [[Paragraph(expl_html, s_expl)]],
                colWidths=[usable_w]
            )
            expl_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), GREEN_BG),
                ("BOX", (0, 0), (-1, -1), 0.75, GREEN),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]))
            q_flowables.append(expl_table)
            q_flowables.append(Spacer(1, 5 * mm))

            story.append(KeepTogether(q_flowables))

        # 4. BÖLÜM SONU HIZLI CEVAP ANAHTARI (10 Sütunlu Matris)
        story.append(PageBreak())
        story.append(Paragraph(f"BÖLÜM {chapter_id}: HIZLI CEVAP ANAHTARI", s_title))
        story.append(Paragraph(f"{meta['title_tr']} — Toplam {len(questions)} Soru", s_subtitle))
        story.append(Spacer(1, 4 * mm))

        matrix_rows: List[List[Any]] = []
        matrix_rows.append([Paragraph(f"<b>K{c}</b>", s_table_hdr) for c in range(1, 11)])

        col_count = 10
        total_q = len(questions)
        for r_start in range(0, total_q, col_count):
            row_items = []
            for c in range(col_count):
                idx = r_start + c
                if idx < total_q:
                    q_item = questions[idx]
                    cell_text = f"<b>{q_item['local_num']}:</b> {q_item['correct_letter']}"
                    row_items.append(Paragraph(cell_text, s_table_cell))
                else:
                    row_items.append(Paragraph("-", s_table_cell))
            matrix_rows.append(row_items)

        ans_table = Table(matrix_rows, colWidths=[usable_w / 10] * 10)
        ans_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), BLUE),
            ("BOX", (0, 0), (-1, -1), 1, BLUE),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, BLUE_BG]),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(ans_table)

        # PDF Derleme
        doc.build(story, canvasmaker=NumberedCanvas)
        return pdf_path


if __name__ == "__main__":
    from kanski_question_engine import KanskiQuestionEngine
    engine = KanskiQuestionEngine()
    publisher = KanskiPDFPublisher()

    print("Bölüm 1 Soru Bankası Test Ediliyor (Unicode Arial ile)...")
    q1 = engine.generate_chapter_questions(1)
    pdf_out = publisher.build_chapter_pdf(1, q1)
    print(f"PDF Başarıyla Üretildi: {pdf_out}")
