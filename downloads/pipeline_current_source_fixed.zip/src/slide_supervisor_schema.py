"""
slide_supervisor_schema.py — Argon Tarafından Yönetilen Slayt Düzeltme Veri Sözleşmesi.

Pydantic v2 tabanlı veri modelleri:
- SlideSpec: Slaytın klinik içeriği, iddiaları, kaynakları, aday görselleri ve render durumu.
- SupervisorDecision: Argon'un seçebileceği 5 eylem:
  * accept_draft
  * replace_visual
  * retrieve_more
  * revise_text
  * review_required
- SlideSupervisorState: LangGraph yürütme durumu, döngü sayaçları ve işlem geçmişi.
"""

from __future__ import annotations

import datetime
from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field


class ClinicalClaim(BaseModel):
    """Slaytta öne sürülen belirli bir klinik iddia veya biyobelirteç bulgusu."""
    claim_id: str = Field(..., description="Örn: 'CLM-01'")
    statement: str = Field(..., description="Klinik önerme / iddia metni")
    supporting_source_ids: List[str] = Field(default_factory=list, description="İddiayı destekleyen gerçek kaynak kimlikleri")
    status: Literal["supported", "unsupported", "disputed", "unverified"] = Field(
        default="unverified", description="İddianın kanıt durumu"
    )


class SourcePassage(BaseModel):
    """Gerçek kaynak pasajı ve atıf kaydı."""
    source_id: str = Field(..., description="Gerçek belge/kaynak kimliği (örn: 'SRC-GUNCEL-RETINA-2018-P18')")
    citation_ref: str = Field(..., description="APA / Vancouver formatında doğrulanabilir kaynak künyesi")
    text: str = Field(..., description="Kaynaktan alıntılanan veya sentezlenen pasaj")
    document_sha256: Optional[str] = None
    source_path: Optional[str] = None
    page_num: Optional[int] = Field(default=None, description="PDF / Basılı sayfa numarası")


class CandidateVisual(BaseModel):
    """Slayta yerleştirilebilecek görsel adayı."""
    image_id: str = Field(..., description="Benzersiz görsel kimliği (örn: 'IMG-CRAO-01-A')")
    path: str = Field(..., description="Görselin disk üzerindeki mutlak yolu")
    modality: str = Field(..., description="Görüntüleme yöntemi (fundus, OCT B-scan, OCTA, FA vb.)")
    figure_id: str = Field(default="", description="Kitap/makaledeki şekil numarası")
    panel_id: Optional[str] = Field(default=None, description="Panel harfi (A, B, C vb.)")
    original_caption: str = Field(default="", description="Özgün şekil altyazısı")
    image_sha256: str = Field(..., description="Görsel dosyasının SHA-256 hash'i")
    source_id: str = Field(default="", description="Görselin çıkarıldığı kaynak kimliği")
    source_page: Optional[int] = None
    bbox: Optional[List[float]] = None
    coord_system: Optional[str] = None
    disease_ids: List[str] = Field(default_factory=list, description="Görselle ilişkili hastalık kimlikleri")


class SlideCard(BaseModel):
    """Slayt üzerindeki yapılandırılmış bilgi kartı."""
    card_id: str = Field(..., description="Kart kimliği (örn: 'CARD-PATOGENEZ')")
    title: str = Field(..., description="Kart başlığı")
    lead: Optional[str] = Field(default=None, description="Kart vurgu cümlesi")
    items: List[str] = Field(default_factory=list, description="Madde işaretli klinik içerik")
    footer: Optional[str] = Field(default=None, description="Kart altı klinik inci / ipucu")
    theme: str = Field(default="primary", description="primary | danger | success | warning")


class SlideSpec(BaseModel):
    """
    Slayt Veri Sözleşmesi.
    Klinik iddialar, kartlar, kaynaklar, aday görseller ve render durumunu taşır.
    Bölüm numarası hastalık kimliği olarak kullanılmaz; topic_id klinik hastalığı temsil eder.
    """
    slide_id: str = Field(..., description="Slayt kimliği (örn: 'SLIDE-RETINA-CRAO-01')")
    topic_id: str = Field(..., description="Klinik hastalık kimliği (örn: 'crao', 'stargardt', 'dme')")
    chapter_num: int = Field(default=1, description="Müfredat bölüm numarası")
    title: str = Field(..., description="Slayt başlığı")
    category: str = Field(default="KLİNİK ÇALIŞMA", description="Üst rozet kategorisi")
    subtitle: str = Field(default="", description="Slayt alt başlığı")
    cards: List[SlideCard] = Field(default_factory=list, description="Slayt yüzeyindeki yapılandırılmış kartlar")
    speaker_notes: str = Field(default="", description="Varsa ek çalışma notları")
    claims: List[ClinicalClaim] = Field(default_factory=list, description="Slayttaki klinik iddialar")
    sources: List[SourcePassage] = Field(default_factory=list, description="Kullanılan gerçek kaynak pasajları")
    candidate_images: List[CandidateVisual] = Field(default_factory=list, description="Aday görseller listesi")
    selected_visual: Optional[CandidateVisual] = Field(default=None, description="Slayta seçilmiş görsel")
    expected_modality: Optional[str] = Field(default=None, description="Gereken görsel modalitesi")
    render_kind: Literal["unavailable", "preview", "pptx"] = "unavailable"
    rendered_slide_path: Optional[str] = Field(default=None, description="Render edilen taslak slayt PNG yolu")
    rendered_slide_hash: Optional[str] = Field(default=None, description="Taslak slayt PNG SHA-256 hash'i")


# -----------------------------------------------------------------------------
# Argon Karar Şeması
# -----------------------------------------------------------------------------

SUPERVISOR_ACTIONS = Literal[
    "accept_draft",
    "replace_visual",
    "retrieve_more",
    "revise_text",
    "review_required",
]


class SearchRequest(BaseModel):
    """Görsel veya kaynak eksikliğinde talep edilen arama nesnesi."""
    disease: str = Field(..., description="Aranacak hastalık/tanı kimliği")
    modality: str = Field(..., description="Gerekli görüntüleme modalitesi")
    required_findings: List[str] = Field(default_factory=list, description="Görselde aranacak lezyon/patoloji bulguları")


class RevisionInstructions(BaseModel):
    """Metin düzeltme talebi talimatı."""
    target_card_id: Optional[str] = Field(default=None, description="Düzeltilecek kart kimliği")
    target_field: Optional[str] = Field(default="items", description="Düzeltilecek alan ('items', 'lead', 'footer')")
    target_index: Optional[int] = Field(default=None, description="Madde indeksi")
    replacement_text: Optional[str] = Field(default=None, description="Yeni metin önerisi")
    preserve_dosages_and_units: bool = Field(default=True, description="Doz ve birimleri koruma zorunluluğu")
    instructions: str = Field(default="", description="Argon'un düzeltme gerekçesi ve açık talimatı")


class SupervisorDecision(BaseModel):
    """
    Argon Slayt Yöneticisi Karar Modeli.
    Yalnızca tanımlı 5 eylemden birini seçebilir.
    """
    action: SUPERVISOR_ACTIONS = Field(..., description="Yöneticinin kararı")
    reason: str = Field(..., description="Kararın klinik ve görsel gerekçesi")
    claim_source_links: Dict[str, List[str]] = Field(default_factory=dict, description="Model-reviewed claim-to-source links; not human approval")
    affected_claim_ids: List[str] = Field(default_factory=list, description="Etkilenen iddia kimlikleri")
    target_source_ids: List[str] = Field(default_factory=list, description="Kullanılacak gerçek kaynak kimlikleri")
    target_image_ids: List[str] = Field(default_factory=list, description="Kullanılacak gerçek görsel kimlikleri")
    search_request: Optional[SearchRequest] = Field(default=None, description="Ek arama gerekliyse arama parametreleri")
    revision_instructions: Optional[RevisionInstructions] = Field(default=None, description="Metin revizyonu gerekliyse talimatlar")
    unresolved_deficiencies: List[str] = Field(default_factory=list, description="Çözülemeyen açık eksikler")


class SupervisorActionRecord(BaseModel):
    """Uygulanan yönetici eyleminin izlenebilir kütük kaydı."""
    action: str = Field(..., description="Uygulanan eylem")
    timestamp: str = Field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(),
        description="Eylem zaman damgası"
    )
    reason: str = Field(default="", description="Eylemin gerekçesi")
    model_used: str = Field(default="unknown", description="Kararı veren model")
    provider_response_id: Optional[str] = Field(default=None, description="Sağlayıcı yanıt kimliği")
    correction_step: int = Field(default=0, description="Düzeltme adımı sayısı")
    details: Dict[str, Any] = Field(default_factory=dict, description="Ek eylem detayları")


class SlideSupervisorState(BaseModel):
    """
    LangGraph Slayt Düzeltme Yöneticisi Graf Durumu.
    """
    slide_spec: SlideSpec = Field(..., description="İncelenen slaytın tam sözleşmesi")
    latest_decision: Optional[SupervisorDecision] = Field(default=None, description="En son Argon kararı")
    review_findings: List[str] = Field(default_factory=list, description="Tespit edilen inceleme bulguları")
    action_history: List[SupervisorActionRecord] = Field(default_factory=list, description="Uygulanan eylemler geçmişi")
    correction_count: int = Field(default=0, description="Kullanılan düzeltme bütçesi")
    max_corrections: int = Field(default=2, description="İzin verilen maksimum düzeltme sayısı")
    rejected_candidate_ids: List[str] = Field(default_factory=list, description="Reddedilen ve tekrar denenmeyecek aday görsel kimlikleri")
    status: str = Field(default="initialized", description="initialized | in_progress | accepted_draft | review_required")
    open_deficiencies: List[str] = Field(default_factory=list, description="Kalan çözülmemiş eksiklikler")
    expert_review_status: str = Field(default="review_required", description="İnsan uzman inceleme durumu (asla modelce approved yapılmaz)")
    verified_with_argon: bool = Field(default=False, description="Argon yürütme kanıtı")
    actual_model: str = Field(default="unknown", description="Bildirilen gerçek model kimliği")
    rejected_image_hashes: List[str] = Field(default_factory=list)
    input_fingerprint: str = ""
    run_id: str = ""
    render_available: bool = Field(default=False, description="Gerçek render PNG'sinin üretilip üretilemediği")
