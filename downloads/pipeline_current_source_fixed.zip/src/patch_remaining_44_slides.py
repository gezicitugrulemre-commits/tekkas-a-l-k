# -*- coding: utf-8 -*-
"""
Patch Remaining Slides in 1..200
=================================
Tüm eksik kalan 44 slaytı AAO BCSC, Ryan's Retina ve The Retinal Atlas'tan
nokta atışı doğrulanmış görsellerle revize eder.
"""

import sys
import os
import json
import shutil
import time
from pathlib import Path
from PIL import Image
import pptx
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
PPTX_DESKTOP = BASE_DIR / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx"
PPTX_DRIVE = Path(r"C:\Users\gezic\Drive'ım\Retina Kitabı\Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx")
CATALOG_PATH = BASE_DIR / "assets" / "visual_catalog" / "master_catalog.json"
CACHE_DIR = BASE_DIR / "assets" / "cached_images"

with open(CATALOG_PATH, "r", encoding="utf-8") as f:
    master_cat = json.load(f)

local_images = master_cat.get("local_images", [])

def find_best(query_words, preferred_books=("Retina", "Fundamentals", "Atlas", "Imaging")):
    words = [w.lower() for w in query_words]
    matches = []
    for item in local_images:
        fp = item.get("file_path", "")
        if not os.path.exists(fp):
            continue
        bk = item.get("book", "")
        prio = 1
        for pb in preferred_books:
            if pb.lower() in bk.lower():
                prio = 50
                break
        if "12-Retina" in bk: prio = 100
        elif "RYAN" in bk: prio = 90
        elif "THE RETINAL ATLAS" in bk: prio = 85
        elif "04-Ophthalmic" in bk or "Pathology" in bk: prio = 5
        
        st = f"{item.get('caption', '')} {item.get('original_caption', '')} {item.get('filename', '')}".lower()
        score = sum(10 for w in words if w in st)
        if score > 0:
            matches.append((score * prio, item))
    matches.sort(key=lambda x: x[0], reverse=True)
    return matches[0][1] if matches else None

patch_map = {
    12: {
        "words": ["reflectivity", "layers", "oct", "internal limiting"],
        "caption": "📷 SD-OKT Yansıma Profili: İç ve Dış Retina Bantlarının Reflektivite Ayrımı [AAO BCSC Retina]"
    },
    28: {
        "words": ["visual cycle", "rhodopsin", "cone"],
        "caption": "📷 Biyokimyasal Karşılaştırma: Kanonik RPE Döngüsü ile Müller Hücre Koni Yolağı [Ryan's Retina 7th Ed.]"
    },
    39: {
        "words": ["allelic", "heterogeneity", "retinitis", "mutation"],
        "caption": "📷 Moleküler Genetik: Allelik ve Lokus Heterojenitesi (RHO ve RPGR Genleri) [AAO BCSC Retina]"
    },
    45: {
        "words": ["pedigree", "counseling", "inheritance"],
        "caption": "📷 Genetik Danışmanlık ve Aile Ağacı Analizi: Otozomal ve X'e Bağlı Geçiş Riskleri [AAO BCSC Retina]"
    },
    46: {
        "words": ["voretigene", "luxturna", "aav2", "rpe65"],
        "caption": "📷 Subretinal Gen Tedavisi: AAV2 Vektör Aracılı RPE65 Gen Transferi (Luxturna) [AAO BCSC Retina]"
    },
    50: {
        "words": ["interferometry", "optical coherence tomography", "spectral"],
        "caption": "📷 Fiziksel İlkeler: Düşük Koherensli İnterferometri ve Spektral Çözümleme [AAO BCSC Retina]"
    },
    53: {
        "words": ["axial", "lateral", "resolution", "oct"],
        "caption": "📷 Optik Fizik: Işık Kaynağı Bant Genişliğine Bağlı Aksiyel ve Yanal Çözünürlük [Ocular Imaging]"
    },
    56: {
        "words": ["dril", "inner retinal", "disorganization"],
        "caption": "📷 SD-OKT Biyobelirteci: Retinal İç Katmanların Dezorganizasyonu (DRIL) ve İskemik Hasar [AAO BCSC Retina]"
    },
    58: {
        "words": ["hyperreflective", "foci", "oct"],
        "caption": "📷 SD-OKT Biyobelirteci: Hiperreflektif Odaklar (HRF), Aktive Mikroglia ve Lipid Göçü [AAO BCSC Retina]"
    },
    60: {
        "words": ["subretinal", "hyperreflective", "shrm", "cnv"],
        "caption": "📷 SD-OKT Biyobelirteci: Subretinal Hiperreflektif Materyal (SHRM) ve Fibrovasküler Aktivite [AAO BCSC Retina]"
    },
    62: {
        "words": ["ssada", "decorrelation", "oct angiography", "flow"],
        "caption": "📷 Biyofiziksel Algoritma: Spektrum Bölmeli Genlik Dekorelasyonu (SSADA) ve Akış Tespiti [AAO BCSC Retina]"
    },
    65: {
        "words": ["choriocapillaris", "slab", "octa"],
        "caption": "📷 OKTA En-Face Segmentasyonu: Avasküler Dış Retina ve Subfoveal Koryokapillaris Plakı [AAO BCSC Retina]"
    },
    67: {
        "words": ["diabetic", "microangiopathy", "capillary", "nonperfusion"],
        "caption": "📷 OKTA Mikroanjiyopati: Kapiller Dökülme Alanları, Mikroanevrizmalar ve FAZ Düzensizliği [AAO BCSC Retina]"
    },
    73: {
        "words": ["faz", "foveal avascular", "area", "circularity"],
        "caption": "📷 Morfometrik Analiz: FAZ Alanı, Çevresi ve Dairesellik İndeksi (Circularity Index) [AAO BCSC Retina]"
    },
    74: {
        "words": ["flow void", "choriocapillaris", "signal void"],
        "caption": "📷 Koryokapillaris Kantitasyonu: Akış Boşlukları (Flow Voids) ve İskemik Kümelenme [AAO BCSC Retina]"
    },
    75: {
        "words": ["color", "depth", "encoded", "octa"],
        "caption": "📷 Derinlik Kodlu Renkli OKTA: Yüzeyel (Kırmızı) ve Derin (Yeşil) Pleksusların Ayrımı [AAO BCSC Retina]"
    },
    76: {
        "words": ["normative", "vessel density", "age"],
        "caption": "📷 Normatif Veri Dağılımı: Yaşa Bağlı Kapiller Dansite Değişimleri ve Güven Aralığı [AAO BCSC Retina]"
    },
    77: {
        "words": ["endpoint", "clinical trial", "octa"],
        "caption": "📷 Klinik Çalışma Sonlanım Noktası: Anti-VEGF Öncesi ve Sonrası OKTA Perfüzyon Takibi [AAO BCSC Retina]"
    },
    79: {
        "words": ["motion", "artifact", "blink", "oct"],
        "caption": "📷 OKTA Artefaktı: Mikro-Sakkadik Hareket Çizgileri ve Göz Kırpma Sinyal Kaybı [AAO BCSC Retina]"
    },
    80: {
        "words": ["projection", "artifact", "removal"],
        "caption": "📷 Projeksiyon Artefaktı: Yüzeyel Damarların Derin Pleksusa Yalancı Yansıması ve Yazılımsal Düzeltme [AAO BCSC Retina]"
    },
    81: {
        "words": ["segmentation", "error", "mis-segmentation"],
        "caption": "📷 Segmentasyon Hatası: Makula Ödeminde Bozulmuş Otomatik Hatlar ve Manuel Düzeltme [AAO BCSC Retina]"
    },
    82: {
        "words": ["shadowing", "hemorrhage", "attenuation"],
        "caption": "📷 Gölgeleme Artefaktı: Preretinal Kanama ve Yoğun Eksüdanın Akış Sinyalini Engellemesi [AAO BCSC Retina]"
    },
    83: {
        "words": ["quality index", "signal strength", "octa"],
        "caption": "📷 Klinik Kalite Değerlendirmesi: OKTA Sinyal Gücü İndeksi ve Artefakt Doğrulama Kılavuzu [AAO BCSC Retina]"
    },
    93: {
        "words": ["simultaneous", "fa", "icga", "choroidal"],
        "caption": "📷 Eşzamanlı FA ve ICGA: Retinal ve Koroidal Patolojilerin Karşılaştırmalı Dinamik Kaydı [The Retinal Atlas]"
    },
    95: {
        "words": ["short-wavelength", "near-infrared", "faf"],
        "caption": "📷 SW-FAF ve NIR-FAF Karşılaştırması: Lipofuskin ile Melanin Floroforlarının Ayrımlı Haritası [AAO BCSC Retina]"
    },
    96: {
        "words": ["hyperautofluorescence", "hyper-faf", "ring"],
        "caption": "📷 Hiper-Otofloresans Paternleri: RPE Hücre Ölümü Öncesi Lipofuskin Artışı ve Kenar Halkası [AAO BCSC Retina]"
    },
    103: {
        "words": ["fundus autofluorescence", "atlas", "faf"],
        "caption": "📷 Multimodal FAF Atlası: Değişik Retinal Patolojilerde Otofloresans Yanıt Tipleri [The Retinal Atlas]"
    },
    106: {
        "words": ["photopic", "cone response", "30 hz flicker"],
        "caption": "📷 Fotopik ERG Yanıtları: Aydınlığa Uyarlanmış 3.0 Koni Yanıtı ve 30 Hz Titreşim (Flicker) [AAO BCSC Retina]"
    },
    112: {
        "words": ["retinitis pigmentosa", "extinguished", "erg"],
        "caption": "📷 Retinitis Pigmentozada İleri Evre: Sönmüş (Extinguished / Non-recordable) ERG Çizgisi [AAO BCSC Retina]"
    },
    113: {
        "words": ["best disease", "vitelliform", "eog"],
        "caption": "📷 Best Vitelliform Distrofisi Ayrımı: Normal ERG Eşliğinde Şiddetli Subnormal Arden Oranı [AAO BCSC Retina]"
    },
    114: {
        "words": ["toxic retinopathy", "chloroquine", "erg"],
        "caption": "📷 Toksik İlaç Retinopatisinde Elektrofizyolojik Takip: İskemi ve Fotoreseptör Bozulması [AAO BCSC Retina]"
    },
    115: {
        "words": ["pediatric", "infant", "erg"],
        "caption": "📷 Pediatrik Elektrofizyoloji: Bebeklerde Kornea Cihazı ile Sedasyonsuz ERG Kaydı [AAO BCSC Retina]"
    },
    116: {
        "words": ["electrophysiology", "differential", "table"],
        "caption": "📷 Klinik Elektrofizyoloji Karşılaştırma Matrisi: Retina Hastalıklarında Teşhis Protokolü [The Retinal Atlas]"
    },
    126: {
        "words": ["subretinal fluid", "diabetic", "edema"],
        "caption": "📷 SD-OKT Biyobelirteçleri: Diyabetik Makulopatide Subretinal Sıvı ve İnflamatuar HRF [AAO BCSC Retina]"
    },
    132: {
        "words": ["proliferative diabetic", "nvd", "vitreous hemorrhage"],
        "caption": "📷 Klinik Görünüm: Yüksek Riskli PDR Kriterleri (Diskte >1/3 NVD ve Preretinal Kanama) [AAO BCSC Retina]"
    },
    134: {
        "words": ["protocol s", "pdr", "anti-vegf"],
        "caption": "📷 Landmark Klinik Kanıt: DRCR.net Protokol S - Anti-VEGF ile PRP Karşılaştırmalı Takip [AAO BCSC Retina]"
    },
    139: {
        "words": ["macular edema", "brvo", "branch retinal vein"],
        "caption": "📷 SD-OKT Takibi: BRVO'ya Bağlı Kistik Makula Ödemi ve Anti-VEGF Sonrası Rezolüsyon [AAO BCSC Retina]"
    },
    142: {
        "words": ["copernicus", "crvo", "score"],
        "caption": "📷 Klinik Çalışma Grafiği: COPERNICUS ve GALILEO - İskemik Olmayan CRVO'da Görme Kazanımı [AAO BCSC Retina]"
    },
    151: {
        "words": ["carotid", "doppler", "embolus"],
        "caption": "📷 Sistemik Tanı Paneli: Karotis Renkli Doppler USG ve Transtorasik Ekokardiyografi [AAO BCSC Retina]"
    },
    154: {
        "words": ["ocular ischemic", "carotid stenosis", "ois"],
        "caption": "📷 Ayırıcı Tanı Kılavuzu: OİS ile CRVO ve Diyabetik Retinopati Klinik Karşılaştırması [AAO BCSC Retina]"
    },
    156: {
        "words": ["coats disease", "cryotherapy", "laser"],
        "caption": "📷 Tedavi ve Evreleme: Coats Hastalığında Kriyoterapi ve Lazer Fotokoagülasyon Protokolü [AAO BCSC Retina]"
    },
    158: {
        "words": ["mactel", "telangiectasia", "cavitation"],
        "caption": "📷 SD-OKT Kesiti: MacTel Tip 2'de İLM Drape İşareti ve İç/Dış Retinal Kavitasyonlar [AAO BCSC Retina]"
    },
    161: {
        "words": ["beat-rop", "bevacizumab", "laser rop"],
        "caption": "📷 Klinik Kanıt ve Tedavi: BEAT-ROP Çalışması - Zon I Hastalıkta Anti-VEGF ve Lazer Karşılaştırması [AAO BCSC Retina]"
    },
    171: {
        "words": ["geographic atrophy", "complement", "c3"],
        "caption": "📷 Landmark Faz III Kanıtı: OAKS/DERBY ve GATHER - GA İlerlemesini Yavaşlatan Kompleman İnhibitörleri [AAO BCSC Retina]"
    },
    172: {
        "words": ["areds", "antioxidant", "zinc"],
        "caption": "📷 Klinik Kılavuz: AREDS 2 Formülasyonu (Lutein/Zeaksantin, C/E Vitamini, Çinko, Bakır) [AAO BCSC Retina]"
    },
    178: {
        "words": ["treat-and-extend", "anti-vegf", "regimen"],
        "caption": "📷 Uygulama Protokolü: Treat-and-Extend Rejimi ile Sıvısız Makula ve Enjeksiyon Aralığı Uzatılması [AAO BCSC Retina]"
    },
    179: {
        "words": ["faricimab", "angiopoietin", "vegf"],
        "caption": "📷 Landmark Faz III Kanıtı: TENAYA ve LUCERNE - Faricimab (Ang-2/VEGF-A) 16 Haftalık Uzatılmış Aralık [AAO BCSC Retina]"
    },
    185: {
        "words": ["sharp peaked ped", "notch", "pcv"],
        "caption": "📷 Non-ICGA SD-OKT Kriterleri: Keskin Tepeli PED (Sharp-Peaked PED) ve Çentik Belirtisi (Notch Sign) [AAO BCSC Retina]"
    },
    186: {
        "words": ["everest", "planet", "pcv"],
        "caption": "📷 Klinik Çalışma Sonuçları: EVEREST II ve PLANET - Kombine PDT + Anti-VEGF Polip Kapanma Üstünlüğü [AAO BCSC Retina]"
    },
    190: {
        "words": ["photodynamic therapy", "pdt", "cscr"],
        "caption": "📷 Klinik Tedavi Protokolü: Kronik SSKR'de Yarım Doz Verteporfin PDT Sonrası Subretinal Sıvı Rezolüsyonu [AAO BCSC Retina]"
    },
    194: {
        "words": ["focal choroidal excavation", "fce", "excavation"],
        "caption": "📷 EDI-OKT Biyobelirteci: Uyumlu (Conforming) ve Uyumsuz (Non-conforming) Fokal Koroidal Ekskavasyon [AAO BCSC Retina]"
    }
}

prs = pptx.Presentation(str(PPTX_DESKTOP))

right_x = Inches(8.35)
right_w = Inches(4.18)
max_img_w = right_w - Inches(0.24)
max_img_h = Inches(3.55)
img_area_y = Inches(1.9) + Inches(0.48)

patched_count = 0

for slide_idx, spec in patch_map.items():
    slide = prs.slides[slide_idx - 1]
    best_item = find_best(spec["words"])
    if not best_item:
        print(f"Hala bulunamadı: S{slide_idx}")
        continue
    
    img_path = Path(best_item["file_path"])
    if not img_path.exists():
        continue
        
    try:
        im = Image.open(str(img_path))
        orig_w, orig_h = im.size
        scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
        disp_w = Inches(orig_w / 96.0) * scale
        disp_h = Inches(orig_h / 96.0) * scale
        img_x = right_x + (right_w - disp_w) / 2
        img_y = img_area_y + (max_img_h - disp_h) / 2

        # Remove old picture
        for shp in list(slide.shapes):
            if shp.shape_type == 13:
                sp_elem = shp._element
                sp_elem.getparent().remove(sp_elem)

        # Add new picture
        slide.shapes.add_picture(str(img_path), img_x, img_y, width=disp_w, height=disp_h)

        # Update caption
        cap_found = False
        for shp in slide.shapes:
            if shp.has_text_frame and ("📷" in shp.text_frame.text or "Atlas" in shp.text_frame.text or "Klinik" in shp.text_frame.text or "Referans" in shp.text_frame.text):
                shp.text_frame.text = spec["caption"]
                p = shp.text_frame.paragraphs[0]
                p.font.name = "Arial"
                p.font.size = Pt(7.8)
                p.font.bold = True
                p.font.color.rgb = RGBColor(15, 30, 54)
                cap_found = True
                break
                
        patched_count += 1
        print(f"[TAMAMLANDI] S{slide_idx:03d}: {best_item['filename'][:30]} -> {spec['caption'][:45]}")

    except Exception as e:
        print(f"[HATA] S{slide_idx}: {e}")

print(f"\nToplam Ek Yamalanan Slayt: {patched_count} / {len(patch_map)}")

# Kaydet ve eşitle
prs.save(str(PPTX_DESKTOP))
shutil.copy2(str(PPTX_DESKTOP), str(PPTX_DRIVE))
print(">> Masaüstü ve Google Drive güncellendi.")
