"""
phoenix_tracer.py — Yerel Arize Phoenix & OpenTelemetry Gözlemlenebilirlik Modülü.

Özellikler:
- Tamamen yerel çalışır; harici bulut hesabı veya API anahtarı gerektirmez.
- LangChain ve LangGraph çağrılarını OpenInference ile otomatik enstrümante eder.
- Özel model/düğüm özniteliklerini kütükler:
  * run_id, node_id, task_id
  * requested_model vs actual_model (sağlayıcıdan bildirilen gerçek kimlik)
  * provider, provider_response_id, langchain_run_id
  * token kullanımı (yoksa None/unknown, asla 0 değil)
  * süre, cache hit/miss
  * prompt hash, source hash, image hash
- Güvenlik: API anahtarlarını, bearer token'ları, gizli kimlikleri ve ham medikal belgeleri trace içine asla yazmaz; hash ve referans kullanır.
- Dayanıklılık (Graceful Degradation): Phoenix kapalıyken veya hata verirse üretim hattı kesintiye uğramaz; izleme arızası model/kalite hatalarını gizlemez.
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
from typing import Any, Dict, Optional

log = logging.getLogger("phoenix_tracer")

_PHOENIX_SESSION = None
_INSTRUMENTED = False
_TRACER = None


def is_phoenix_enabled() -> bool:
    return os.getenv("PHOENIX_ENABLED", "").strip().lower() in ("1", "true", "yes", "on")


def hash_text(text: str) -> str:
    if not text:
        return ""
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()[:16]


def sanitize_attributes(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """Hassas kimlik bilgilerini, token'ları ve ham devasa metinleri temizler."""
    clean = {}
    forbidden_keys = {"api_key", "authorization", "bearer", "cookie", "password", "secret", "access_token", "refresh_token"}
    for k, v in attrs.items():
        if any(bad in k.lower() for bad in forbidden_keys):
            continue
        # Ham büyük medikal belgeleri hash'e çevir
        if isinstance(v, str) and any(word in k.lower() for word in ("pdf", "document", "chunk", "prompt", "input.value", "output.value")):
            clean[f"{k}_sha256"] = hash_text(v)
            clean[f"{k}_length"] = len(v)
        else:
            clean[k] = v
    return clean


def init_phoenix(
    *,
    port: int = 6006,
    auto_launch: Optional[bool] = None,
) -> bool:
    """
    Yerel Phoenix uygulamasını başlatır ve LangChain enstrümantasyonunu kaydeder.
    """
    global _PHOENIX_SESSION, _INSTRUMENTED, _TRACER

    should_launch = auto_launch if auto_launch is not None else is_phoenix_enabled()
    if not should_launch:
        log.debug("Phoenix izleme devre dışı (PHOENIX_ENABLED!=1). Standart yerel çalışma.")
        return False

    if _INSTRUMENTED:
        return True

    try:
        import phoenix as px
        from openinference.instrumentation.langchain import LangChainInstrumentor

        # 1. Yerel Phoenix oturumunu başlat
        if _PHOENIX_SESSION is None:
            try:
                _PHOENIX_SESSION = px.launch_app(port=port)
                log.info("Yerel Phoenix UI başarıyla başlatıldı: http://localhost:%d", port)
            except Exception as launch_exc:
                log.warning("Phoenix sunucusu başlatılamadı veya zaten çalışıyor: %s", launch_exc)

        # 2. OpenTelemetry ve LangChain enstrümantasyonu
        try:
            from phoenix.otel import register
            tracer_provider = register(project_name=os.getenv("PHOENIX_PROJECT_NAME", "retina-langgraph-production"))
            from openinference.instrumentation import TraceConfig
            privacy = TraceConfig(hide_inputs=True, hide_outputs=True, hide_input_images=True)
            LangChainInstrumentor().instrument(tracer_provider=tracer_provider, config=privacy)
            _INSTRUMENTED = True
            log.info("LangChain OpenInference Phoenix enstrümantasyonu aktif.")
            return True
        except Exception as otel_exc:
            log.warning("OpenInference LangChain enstrümantasyonu bağlanamadı: %s", otel_exc)
            return False

    except ImportError as imp_exc:
        log.warning("Phoenix veya OpenInference kurulu değil (%s). İzleme atlandı.", imp_exc)
        return False
    except Exception as exc:
        log.warning("Phoenix başlatma sırasında beklenmeyen hata (%s). Üretim akışı normal devam ediyor.", exc)
        return False


def get_tracer():
    global _TRACER
    if _TRACER is None:
        try:
            from opentelemetry import trace
            _TRACER = trace.get_tracer("retina.langgraph.llm")
        except Exception:
            _TRACER = None
    return _TRACER


class SpanContextManager:
    """Güvenli yerel span bağlamı (Phoenix çalışmadığında no-op)."""

    def __init__(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        self.name = name
        self.attributes = sanitize_attributes(attributes or {})
        self.start_time = None
        self.span = None

    def __enter__(self):
        self.start_time = time.time()
        tracer = get_tracer()
        if tracer and is_phoenix_enabled():
            try:
                self.span = tracer.start_span(self.name)
                for k, v in self.attributes.items():
                    if v is not None:
                        self.span.set_attribute(str(k), v if isinstance(v, (str, int, float, bool)) else str(v))
            except Exception as e:
                log.debug("Span başlatma hatası: %s", e)
        return self

    def set_attribute(self, key: str, value: Any):
        if value is None:
            return
        clean = sanitize_attributes({key: value})
        if key not in clean:
            return
        value = clean[key]
        self.attributes[key] = value
        if self.span:
            try:
                clean_val = value if isinstance(value, (str, int, float, bool)) else str(value)
                self.span.set_attribute(key, clean_val)
            except Exception:
                pass

    def record_error(self, error: Exception):
        if self.span:
            try:
                self.span.set_attribute("error", True)
                self.span.set_attribute("error.type", type(error).__name__)
                self.span.set_attribute("error.message", "redacted")
            except Exception:
                pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - (self.start_time or time.time())
        self.set_attribute("duration_seconds", round(duration, 4))
        if exc_val is not None:
            self.record_error(exc_val)
        if self.span:
            try:
                self.span.end()
            except Exception:
                pass
        return False  # Hataları gizlemez; yukarı iletir


def trace_model_call(
    prompt_name: str,
    *,
    book: str,
    unit: str,
    requested_model: str,
    run_id: str,
    prompt_hash: Optional[str] = None,
    image_hash: Optional[str] = None,
) -> SpanContextManager:
    if is_phoenix_enabled():
        init_phoenix()
    attrs = {
        "llm.prompt_name": prompt_name,
        "llm.book": book,
        "llm.unit": unit,
        "llm.requested_model": requested_model,
        "llm.run_id": run_id,
        "llm.prompt_hash": prompt_hash or "",
        "llm.image_hash": image_hash or "",
    }
    return SpanContextManager(f"llm.ask:{prompt_name}", attrs)
