# -*- coding: utf-8 -*-
r"""
create_retina_image_bank.py — Retina ve Vitreus Çalışma Atlası Görsel Bankası Oluşturucu
========================================================================================
Bu betik:
1. 'master_catalog.json' ve 'extracted_figures/retina_vitreus_kitap' içindeki görselleri tarar.
2. Bölüm 1'den 10'a kadar her ana retina disiplinine göre doğrulanmış, yüksek çözünürlüklü
   klinik görselleri (OCT, FFA, OKTA, Renkli Fundus, USG, Patoloji) eşleştirir.
3. Hızlı ve hatasız erişim için 'retina_visual_index.json' dosyasını üretir.
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Any

# UTF-8 stdout
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
CATALOG_PATH = BASE_DIR / "assets" / "visual_catalog" / "master_catalog.json"
EXTRACTED_DIR = BASE_DIR / "extracted_figures" / "retina_vitreus_kitap"
OUTPUT_INDEX_PATH = BASE_DIR / "retina_visual_index.json"

CHAPTER_KEYWORDS = {
    1: [
        "vitre", "retina layer", "fovea", "foveol", "rpe", "bruch", "choriocapillar",
        "photoreceptor", "phototransduction", "rhodopsin", "rod", "cone", "muller",
        "inner plexiform", "outer plexiform", "ganglion cell", "tight junction",
        "blood-retina", "zonula occludens", "pedigree", "autosomal", "x-linked"
    ],
    2: [
        "oct", "spectral-domain", "swept-source", "octa", "angiograph", "fluorescein",
        "fa", "ffa", "indocyanine", "icg", "autofluorescence", "faf", "ultrasound",
        "b-scan", "ubm", "erg", "electroretinogram", "eog", "vep", "adaptive optics"
    ],
    3: [
        "diabet", "npdr", "pdr", "edema", "dme", "microaneurysm", "cotton wool",
        "vein occlusion", "brvo", "crvo", "artery occlusion", "brao", "crao",
        "macroaneurysm", "ram", "ischemic", "ois", "coats", "eales", "mactel",
        "telangiectasia", "sickle", "radiation"
    ],
    4: [
        "amd", "macular degeneration", "drusen", "reticular", "pseudodrusen",
        "geographic atrophy", "cnv", "mnv", "neovascular", "polypoidal", "pcv",
        "rap", "central serous", "cscr", "csc", "macular hole", "epiretinal",
        "erm", "vitreomacular", "vmt", "myopic", "lacquer", "angioid"
    ],
    5: [
        "detachment", "rhegmatogenous", "tractional", "exudative", "tear",
        "break", "hole", "lattice", "pvd", "vitreous detachment", "pvr",
        "vitreoretinopathy", "vitrectomy", "scleral buckle", "pneumatic",
        "cryotherapy", "silicone oil", "gas tamponade", "peripher"
    ],
    6: [
        "retinitis pigmentosa", "rp", "spicule", "usher", "stargardt", "abca4",
        "flavimaculatus", "best", "bestrophin", "vitelliform", "cone-rod",
        "cone dystrophy", "leber congenital", "lca", "retinoschisis",
        "choroideremia", "gyrate atrophy", "bietti", "alport"
    ],
    7: [
        "uveitis", "toxoplasm", "cmv", "cytomegalovirus", "retinitis", "arn",
        "porn", "necrosis", "tuberculosis", "syphilis", "bartonella",
        "endophthalmitis", "vkh", "vogt-koyanagi", "sympathetic", "birdshot",
        "white dot", "apmppe", "mewds", "serpiginous", "multifocal choroiditis",
        "behcet", "sarcoid"
    ],
    8: [
        "tumor", "nevus", "melanoma", "hemangioma", "osteoma", "astrocytoma",
        "hamartoma", "retinoblastoma", "lymphoma", "metastasis", "von hippel",
        "tuberous sclerosis", "choroid tumor"
    ],
    9: [
        "trauma", "commotio", "rupture", "foreign body", "iofb", "siderosis",
        "chalcosis", "purtscher", "anti-vegf", "vegf", "aflibercept", "faricimab",
        "ranibizumab", "bevacizumab", "dexamethasone", "ozurdex", "fluocinolone",
        "port delivery", "susvimo", "gene therapy", "luxturna", "optogenetics",
        "artificial intelligence", "deep learning"
    ],
    10: [
        "matrix", "case", "trial", "etdrs", "catt", "protocol t", "hawk",
        "tenaya", "lucerne", "pulsar", "photon", "landmark", "multimodal",
        "fundus", "oct", "biostatistics", "gee"
    ]
}


def build_image_bank():
    print(">>> 1. Master Catalog Yükleniyor...")
    with open(CATALOG_PATH, "r", encoding="utf-8") as f:
        master_data = json.load(f)
    
    local_images = master_data.get("local_images", [])
    print(f"Toplam Katalog Görseli: {len(local_images)}")

    # 2. Kitaptan çıkarılan görselleri yükle
    book_images = []
    if EXTRACTED_DIR.exists():
        for f in sorted(EXTRACTED_DIR.glob("*.*")):
            if f.suffix.lower() in [".png", ".jpg", ".jpeg"] and f.stat().st_size > 15000:
                book_images.append({
                    "id": f"BOOK_{f.stem}",
                    "source": "retina_kitap_pdf",
                    "file_path": str(f),
                    "filename": f.name,
                    "caption": f"Klinik Referans Kitabı — {f.stem}",
                    "tags": ["retina", "vitreus", "kitap", "klinik"]
                })
    print(f"Kitaptan Çıkarılan Doğrulanmış Görsel: {len(book_images)}")

    # 3. Bölümlere göre görsel havuzları oluştur
    chapter_pools: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(1, 11)}

    # Öncelikle kitaptan çıkarılan görselleri sayfa sırasına göre bölümlere dağıt
    # Kitap Sayfa Dağılımı:
    # Ch 1: s.3-37
    # Ch 2: s.38-76
    # Ch 3: s.77-119
    # Ch 4: s.120-158
    # Ch 5: s.159-188
    # Ch 6: s.189-214
    # Ch 7: s.215-248
    # Ch 8: s.249-264
    # Ch 9: s.265-275
    # Ch 10: s.276-280
    for b_img in book_images:
        fn = b_img["filename"]
        try:
            # page_019_xref_33.png
            parts = fn.split("_")
            p_num = int(parts[1])
            if p_num <= 37:
                chapter_pools[1].append(b_img)
            elif p_num <= 76:
                chapter_pools[2].append(b_img)
            elif p_num <= 119:
                chapter_pools[3].append(b_img)
            elif p_num <= 158:
                chapter_pools[4].append(b_img)
            elif p_num <= 188:
                chapter_pools[5].append(b_img)
            elif p_num <= 214:
                chapter_pools[6].append(b_img)
            elif p_num <= 248:
                chapter_pools[7].append(b_img)
            elif p_num <= 264:
                chapter_pools[8].append(b_img)
            elif p_num <= 275:
                chapter_pools[9].append(b_img)
            else:
                chapter_pools[10].append(b_img)
        except Exception:
            chapter_pools[1].append(b_img)

    print("Kitap görselleri bölümlere dağıtıldı:")
    for ch, pool in chapter_pools.items():
        print(f"  Bölüm {ch}: {len(pool)} kitap görseli")

    # 4. Master Catalog'dan retina-spesifik klasörlerdeki görselleri tara ve bölümlere eşleştir
    RETINA_DIRS = [
        "12-Retina_and_Vitreous_2025-2026",
        "THE_RETINAL_ATLAS_2nd_Ed_",
        "Atlas_of_Retinal_OCT",
        "Atlas_of_Retinal_OCT_2nd_Ed_",
        "ATLAS_OCT_of_Macular_Diseases",
        "Clinical_Atlas_of_Peripheral_Retinal_Disorders",
        "The_Uveitis_Atlas",
        "04-Ophthalmic_Pathology_and_Intraocular_Tumors_2025-2026",
        "09-Uveitis_and_Ocular_Inflammation_2025-2026",
        "Diagnostics_in_Ocular_Imaging_Cornea__Retina__Glaucoma_and_Orbit",
        "Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3_",
        "RYAN_S_RETINA_7th_Ed__Vol_2",
        "RYAN_S_RETINA_7th_Ed__Vol_3",
        "RYAN_S_RETINA_7th_Ed__Vo_1"
    ]

    print("\n>>> 2. Master Catalog Retina Görselleri İnceleniyor ve Eşleştiriliyor...")
    matched_count = 0
    seen_paths = set()

    for item in local_images:
        fpath = item.get("file_path", "")
        if not fpath:
            continue
        
        # Sadece retina ilgili klasörlerden al
        in_retina_dir = any(rd.lower() in fpath.lower() for rd in RETINA_DIRS)
        if not in_retina_dir:
            continue

        # Dosyanın varlığını ve boyutunu teyit et
        p = Path(fpath)
        if not p.exists():
            continue
        if p.stat().st_size < 15000:  # 15 KB altı küçük ikonları atla
            continue
        if str(p) in seen_paths:
            continue
        seen_paths.add(str(p))

        # Arama metni
        search_text = (
            p.name.lower() + " " +
            item.get("caption", "").lower() + " " +
            " ".join(item.get("tags", [])).lower() + " " +
            fpath.lower()
        )

        # Bölüm anahtar kelimeleriyle puanla
        best_ch = None
        max_score = 0
        for ch, kw_list in CHAPTER_KEYWORDS.items():
            score = 0
            for kw in kw_list:
                if kw in search_text:
                    score += 2 if len(kw) > 4 else 1
            if score > max_score:
                max_score = score
                best_ch = ch

        # Eğer puan varsa ilgili bölüme ekle
        if best_ch is not None and max_score >= 2:
            entry = {
                "id": item.get("id", p.stem),
                "source": item.get("book", p.parent.name),
                "file_path": str(p),
                "filename": p.name,
                "caption": item.get("caption", f"Klinik Retina Atlası — {p.stem}"),
                "tags": item.get("tags", []),
                "score": max_score
            }
            chapter_pools[best_ch].append(entry)
            matched_count += 1

    print(f"\nToplam {matched_count} doğrulanmış klinik görsel bölümlere eşleştirildi.")
    print("=" * 60)
    for ch in range(1, 11):
        # Puana göre sırala (yüksek skorlu olanlar öne)
        chapter_pools[ch].sort(key=lambda x: x.get("score", 0), reverse=True)
        print(f"Bölüm {ch:02d} Görsel Havuzu: {len(chapter_pools[ch])} adet yüksek çözünürlüklü görsel")
    print("=" * 60)

    # 5. İndeksi diske kaydet
    final_index = {
        "title": "Retina ve Vitreus Klinik Çalışma Atlası Bölüm Görsel Havuzları",
        "total_images": sum(len(pool) for pool in chapter_pools.values()),
        "chapter_pools": chapter_pools
    }

    with open(OUTPUT_INDEX_PATH, "w", encoding="utf-8") as f:
        json.dump(final_index, f, ensure_ascii=False, indent=2)

    print(f"\n>>> Başarıyla kaydedildi: {OUTPUT_INDEX_PATH} (Toplam {final_index['total_images']} görsel)")


if __name__ == "__main__":
    build_image_bank()
