# -*- coding: utf-8 -*-
"""
Kanski Master Question Bank Orchestrator (kanski_master_orchestrator.py)
Tüm 22 bölümün soru üretimini, JSON önbelleğini ve ReportLab PDF derlemesini yönetir.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

if sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from kanski_langgraph_pipeline import run_kanski_chapter_pipeline
from kanski_metadata import CHAPTERS_METADATA, get_chapter_meta
from kanski_pdf_publisher import KanskiPDFPublisher
from kanski_question_engine import KanskiQuestionEngine

OUTPUT_DIR = Path(r"C:\Users\gezic\OneDrive\Desktop\Anti Gravity\output\kanski_qbank")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def generate_single_chapter(chapter_id: int) -> Dict[str, Any]:
    print(f"\n{'='*70}\nBÖLÜM {chapter_id} ÇALIŞTIRILIYOR: {CHAPTERS_METADATA[chapter_id]['title_tr']}\n{'='*70}")
    res = run_kanski_chapter_pipeline(chapter_id)

    # JSON Olarak Kaydet
    qs = res.get("humanized_questions") or []
    json_path = OUTPUT_DIR / f"ch_{chapter_id:02d}_questions.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(qs, f, ensure_ascii=False, indent=2)

    print(f"[OK] Bolum {chapter_id} JSON Kaydedildi: {json_path.name} ({len(qs)} Soru)")
    print(f"[OK] PDF: {res.get('published_pdfs')}")
    return res


def run_batch(start_ch: int = 1, end_ch: int = 22) -> None:
    total_generated = 0
    generated_pdfs: List[str] = []

    for ch_id in range(start_ch, end_ch + 1):
        res = generate_single_chapter(ch_id)
        qs = res.get("humanized_questions") or []
        total_generated += len(qs)
        generated_pdfs.extend(res.get("published_pdfs") or [])

    print(f"\n{'='*70}\nTOPLU ÜRETİM TAMAMLANDI!\n{'='*70}")
    print(f"İşlenen Bölüm Aralığı: {start_ch} - {end_ch}")
    print(f"Toplam Üretilen Soru Sayısı: {total_generated}")
    print(f"Üretilen PDF Kitapçıkları ({len(generated_pdfs)} adet):")
    for pdf in generated_pdfs:
        print(f"  - {pdf}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Kanski Oftalmoloji Master Soru Bankası Orkestratörü")
    parser.add_argument("--chapter", type=int, default=1, help="Çalıştırılacak tekil bölüm (1-22)")
    parser.add_argument("--batch", action="store_true", help="Bölümleri toplu olarak çalıştır")
    parser.add_argument("--start", type=int, default=1, help="Toplu çalıştırma başlangıç bölümü")
    parser.add_argument("--end", type=int, default=22, help="Toplu çalıştırma bitiş bölümü")

    args = parser.parse_args()

    if args.batch:
        run_batch(args.start, args.end)
    else:
        generate_single_chapter(args.chapter)
