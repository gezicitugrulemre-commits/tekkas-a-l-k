"""
Katarakt Cerrahisi Komplikasyonları İçin Ultra Yüksek Çözünürlüklü Şematik Çizim Modülü
Üretilen Şemalar (1600 x 620 px):
  1. schema_1_vitrectomy.png: Bimanual Ön Vitrektomi ve Triamsinolon Görselleştirmesi
  2. schema_2_yamane.png: Yamane Çift İğneli İntraskleral Haptik Fiksasyonu (ISHF) Geometrisi
  3. schema_3_optic_capture.png: Standart Optic Capture vs Reverse Optic Capture Mekanizması
  4. schema_4_tass_endo.png: TASS vs Akut Enfeksiyöz Endoftalmi Ayırıcı Anatomisi
"""

from pathlib import Path
from typing import Tuple, List
from PIL import Image, ImageDraw, ImageFont

# Kurumsal Renk Paleti
PALETTE = {
    "bg": "#ffffff",
    "ink": "#142f43",
    "muted": "#476174",
    "line": "#cddce8",
    "blue": "#1c5ba6",
    "blue_bg": "#edf4ff",
    "green": "#087d6c",
    "green_bg": "#eaf8f2",
    "amber": "#a46109",
    "amber_bg": "#fff5df",
    "purple": "#6941a5",
    "purple_bg": "#f4effc",
    "red": "#b91c1c",
    "red_bg": "#fef2f2",
    "panel_bg": "#f8fbff",
    "cornea": "#7dd3fc",
    "iris": "#c084fc",
    "lens": "#fde047",
    "vitreous": "#fed7aa",
    "sclera": "#e2e8f0"
}


def get_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    paths = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for p in paths:
        if Path(p).exists():
            return ImageFont.truetype(p, size=size)
    return ImageFont.load_default()


def create_base_canvas(title: str, subtitle: str) -> Tuple[Image.Image, ImageDraw.ImageDraw]:
    w, h = 1600, 620
    im = Image.new("RGB", (w, h), PALETTE["bg"])
    draw = ImageDraw.ImageDraw(im)

    # Dış Kutu ve Gölge
    draw.rounded_rectangle([(4, 4), (w - 4, h - 4)], radius=12, fill=PALETTE["bg"], outline=PALETTE["line"], width=2)

    # Üst Banner (Koyu Mavi)
    draw.rounded_rectangle([(6, 6), (w - 6, 85)], radius=10, fill=PALETTE["blue"])
    # Köşeleri düzelt (alt taraf düz kalsın)
    draw.rectangle([(6, 50), (w - 6, 85)], fill=PALETTE["blue"])

    f_title = get_font(23, bold=True)
    f_sub = get_font(14, bold=False)

    draw.text((28, 18), title, font=f_title, fill="#ffffff")
    draw.text((28, 52), subtitle, font=f_sub, fill="#dbeafe")

    # Sol ve Sağ Panel Ayırıcı
    split_x = 760
    draw.rounded_rectangle([(18, 98), (split_x, h - 18)], radius=10, fill=PALETTE["panel_bg"], outline=PALETTE["line"], width=1)
    draw.rounded_rectangle([(split_x + 16, 98), (w - 18, h - 18)], radius=10, fill="#ffffff", outline=PALETTE["line"], width=1)

    return im, draw


def draw_steps_box(draw: ImageDraw.ImageDraw, steps: List[Tuple[str, str, str]], x: int, y_start: int, w: int):
    f_step_title = get_font(15, bold=True)
    f_step_body = get_font(13, bold=False)

    badge_colors = {
        "blue": (PALETTE["blue"], PALETTE["blue_bg"]),
        "green": (PALETTE["green"], PALETTE["green_bg"]),
        "amber": (PALETTE["amber"], PALETTE["amber_bg"]),
        "purple": (PALETTE["purple"], PALETTE["purple_bg"]),
        "red": (PALETTE["red"], PALETTE["red_bg"]),
    }

    y = y_start
    box_h = 108
    gap = 12

    for title, desc, color_key in steps:
        fg, bg = badge_colors.get(color_key, (PALETTE["blue"], PALETTE["blue_bg"]))
        # Adım Arka Planı
        draw.rounded_rectangle([(x, y), (x + w, y + box_h)], radius=8, fill=bg, outline=fg, width=1)
        # Sol Rozet Çubuğu
        draw.rounded_rectangle([(x, y), (x + 8, y + box_h)], radius=4, fill=fg)

        draw.text((x + 20, y + 12), title, font=f_step_title, fill=fg)

        # Metni sar (wrap)
        words = desc.split()
        lines = []
        cur_line = []
        for wd in words:
            test_line = " ".join(cur_line + [wd])
            bbox = draw.textbbox((0, 0), test_line, font=f_step_body)
            if bbox[2] - bbox[0] > (w - 35):
                lines.append(" ".join(cur_line))
                cur_line = [wd]
            else:
                cur_line.append(wd)
        if cur_line:
            lines.append(" ".join(cur_line))

        t_y = y + 38
        for ln in lines[:3]:
            draw.text((x + 20, t_y), ln, font=f_step_body, fill=PALETTE["ink"])
            t_y += 20

        y += box_h + gap


# ==========================================
# 1. BİMANUAL ÖN VİTREKTOMİ ŞEMASI
# ==========================================
def generate_schema_vitrectomy(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 1.1 — Bimanual Ön Vitrektomi ve Triamsinolon Görselleştirmesi",
        "Ayrı parasentez infüzyonu, pars plana kesici girişi (3.0-3.5 mm) ve OVD ile kompartmantalizasyon biyomekaniği"
    )

    f_label = get_font(13, bold=True)
    f_sub = get_font(11, bold=False)

    # Sol Panel Çizimi (Göz Ön Segment Kesiti)
    cx, cy = 380, 340

    # Sklera ve Kornea Kubbesi
    draw.arc([(cx - 260, cy - 200), (cx + 260, cy + 240)], start=195, end=345, fill=PALETTE["cornea"], width=12)
    draw.text((cx - 50, cy - 190), "Kornea Kubbesi", font=f_label, fill=PALETTE["blue"])

    # Ön Kamara Boşluğu (Açık Mavi Dolgu)
    draw.chord([(cx - 250, cy - 180), (cx + 250, cy + 220)], start=205, end=335, fill=PALETTE["blue_bg"])

    # İris Dokusu (İki Kanat)
    draw.polygon([(cx - 240, cy - 20), (cx - 100, cy - 15), (cx - 100, cy - 3), (cx - 240, cy - 8)], fill=PALETTE["iris"])
    draw.polygon([(cx + 100, cy - 15), (cx + 240, cy - 20), (cx + 240, cy - 8), (cx + 100, cy - 3)], fill=PALETTE["iris"])
    draw.text((cx - 210, cy - 42), "İris (Nazal)", font=f_sub, fill=PALETTE["purple"])
    draw.text((cx + 130, cy - 42), "İris (Temporal)", font=f_sub, fill=PALETTE["purple"])

    # Pupilla Açıklığı ve Kapsül Kalıntısı
    draw.line([(cx - 95, cy + 15), (cx - 40, cy + 25)], fill=PALETTE["amber"], width=5)
    draw.line([(cx + 40, cy + 25), (cx + 95, cy + 15)], fill=PALETTE["amber"], width=5)
    draw.text((cx - 85, cy + 32), "Arka Kapsül Rüptürü (PCR Açıklığı)", font=f_sub, fill=PALETTE["amber"])

    # Triamsinolon ile Boyanmış Beyaz Vitreus Lifleri (Ön Kamaraya Uzanıyor)
    for off in [-40, -20, 0, 20, 40]:
        draw.line([(cx + off, cy + 120), (cx + off * 0.7, cy - 40)], fill="#ffffff", width=4)
        draw.ellipse([(cx + off * 0.7 - 3, cy - 40 - 3), (cx + off * 0.7 + 3, cy - 40 + 3)], fill="#ffffff", outline=PALETTE["line"])
    draw.text((cx - 110, cy - 70), "Boyanmış Vitreus Lifleri (Triesence)", font=f_label, fill=PALETTE["green"])

    # Enstrüman 1: İnfüzyon Kanülü (Sol Parasentezden)
    draw.line([(cx - 270, cy - 80), (cx - 130, cy - 40)], fill=PALETTE["blue"], width=7)
    draw.polygon([(cx - 130, cy - 40), (cx - 142, cy - 48), (cx - 142, cy - 32)], fill=PALETTE["blue"])
    draw.text((cx - 290, cy - 105), "İnfüzyon Kanülü (A)\n(Düşük Şişe: 40 cm H2O)", font=f_label, fill=PALETTE["blue"])

    # Enstrüman 2: Vitrektomi Kesicisi (Sağ Pars Plana'dan: Limbusun 3.5 mm gerisi)
    draw.line([(cx + 280, cy + 80), (cx + 30, cy + 30)], fill=PALETTE["red"], width=6)
    draw.polygon([(cx + 30, cy + 30), (cx + 45, cy + 22), (cx + 45, cy + 38)], fill=PALETTE["red"])
    draw.text((cx + 130, cy + 95), "Vitrektomi Kesicisi (B)\n(Pars Plana 3.5 mm / 4500 cpm)", font=f_label, fill=PALETTE["red"])

    # Alt Açıklama Kutusu
    draw.rounded_rectangle([(30, 520), (748, 590)], radius=6, fill="#ffffff", outline=PALETTE["line"])
    draw.text((45, 532), "ALTIN KURAL: Alet aniden çekilmez! Önce dispersif OVD ile kamara doldurulur,", font=f_sub, fill=PALETTE["red"])
    draw.text((45, 555), "infüzyon ve kesici ayrı kanallardan girilerek vitreus traksiyonu sıfırlanır.", font=f_sub, fill=PALETTE["ink"])

    # Sağ Panel Adımları
    steps = [
        ("1. OVD ile Kamara Kompartmantalizasyonu", "Fako probu çekilmeden önce yan parasentezden bol dispersif OVD (Viscoat) verilerek pozitif vitreus basıncı dengelenir ve ön kamara çökmesi önlenir.", "amber"),
        ("2. Bimanual Ayrım ve Düşük İnfüzyon", "İnfüzyon kanülü ile vitrektomi probu ayrı girişlerden yönlendirilir. Şişe yüksekliği 40 cm H2O'ya indirilerek aşırı hidrasyon engellenir.", "blue"),
        ("3. Yüksek Hızlı Kesim & Kuru Aspirasyon", "Kesici 4000-5000 cpm hızına ve 100-150 mmHg vakuma ayarlanır. Kalan korteks infüzyon açılmadan kuru kanülle (dry aspiration) temizlenir.", "green"),
        ("4. Triamsinolon Asetonid ile Doğrulama", "Koruyucusuz triamsinolon verilerek ön kamara ve kesi ağzında hapsolmuş vitreus lifi kalmadığı (%100 şeffaflık) doğrulanır.", "purple")
    ]
    draw_steps_box(draw, steps, 792, 115, 770)

    im.save(output_path, "PNG", dpi=(200, 200))
    print(f" -> Şema 1 kaydedildi: {output_path.name}")


# ==========================================
# 2. YAMANE TEKNİĞİ GEOMETRİSİ VE SKLEROTOMİ AÇISI
# ==========================================
def generate_schema_yamane(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 2.1 — Yamane Çift İğneli İntraskleral Haptik Fiksasyonu (ISHF)",
        "Tam 180° aks simetrisi, limbusa 2.0-2.5 mm giriş mesafesi, PVDF flanş geometrisi ve skleral tünel açısı"
    )

    f_label = get_font(13, bold=True)
    f_sub = get_font(11, bold=False)

    cx, cy = 380, 330

    # Kornea Dairesi (Önden Kuşbakışı Görünüm)
    r_cornea = 135
    draw.ellipse([(cx - r_cornea, cy - r_cornea), (cx + r_cornea, cy + r_cornea)], fill=PALETTE["blue_bg"], outline=PALETTE["blue"], width=3)
    draw.text((cx - 55, cy - 20), "KORNEA\n(11.5 mm)", font=f_label, fill=PALETTE["blue"], align="center")

    # Limbus Çizgisi ve Dış Sklera Halkası
    r_sclera = 210
    draw.ellipse([(cx - r_sclera, cy - r_sclera), (cx + r_sclera, cy + r_sclera)], outline=PALETTE["muted"], width=2)
    draw.text((cx - 30, cy - r_sclera + 15), "SKLERA", font=f_sub, fill=PALETTE["muted"])

    # 180 Derece Eksen Referans Çizgisi (Saat 3 - Saat 9)
    draw.line([(cx - r_sclera - 35, cy), (cx + r_sclera + 35, cy)], fill=PALETTE["line"], width=2)
    draw.text((cx - r_sclera - 85, cy - 8), "Saat 9 (180°)", font=f_sub, fill=PALETTE["purple"])
    draw.text((cx + r_sclera + 15, cy - 8), "Saat 3 (0°)", font=f_sub, fill=PALETTE["purple"])

    # Sklerotomi Noktası 1 (Saat 9): Limbusun 2.0 - 2.5 mm Gerisinde
    sk1_x = cx - r_cornea - 35
    sk1_y = cy
    draw.ellipse([(sk1_x - 6, sk1_y - 6), (sk1_x + 6, sk1_y + 6)], fill=PALETTE["red"], outline="#ffffff", width=2)
    draw.line([(sk1_x, sk1_y), (sk1_x - 45, sk1_y - 45)], fill=PALETTE["red"], width=2)
    draw.text((sk1_x - 145, sk1_y - 65), "Giriş: Limbus 2.0-2.5 mm\n(30G İnce Duvarlı İğne)", font=f_label, fill=PALETTE["red"])

    # Tünel 1 Vektörü: Limbus paralelinde 1.5 - 2.0 mm Skleral Tünel (Açılı)
    draw.line([(sk1_x, sk1_y), (sk1_x + 25, sk1_y + 35)], fill=PALETTE["amber"], width=5)
    draw.text((sk1_x - 30, sk1_y + 42), "Tünel: 1.5-2.0 mm (İris düzlemine paralel)", font=f_sub, fill=PALETTE["amber"])

    # Sklerotomi Noktası 2 (Saat 3): Tam 180° Simetrik
    sk2_x = cx + r_cornea + 35
    sk2_y = cy
    draw.ellipse([(sk2_x - 6, sk2_y - 6), (sk2_x + 6, sk2_y + 6)], fill=PALETTE["red"], outline="#ffffff", width=2)
    draw.line([(sk2_x, sk2_y), (sk2_x - 25, sk2_y - 35)], fill=PALETTE["amber"], width=5)

    # 3 Parçalı GİL Optiği ve PVDF Haptikleri
    draw.ellipse([(cx - 40, cy - 40), (cx + 40, cy + 40)], fill=PALETTE["lens"], outline=PALETTE["amber"], width=2)
    draw.text((cx - 24, cy - 7), "GİL", font=f_label, fill=PALETTE["ink"])

    # Haptik 1 (Sol): Dışarı uzanıp mantar flanş oluşturmuş
    draw.arc([(cx - 140, cy - 50), (cx + 10, cy + 50)], start=90, end=210, fill=PALETTE["purple"], width=4)
    # 0.30 mm Mantar Flanş
    draw.ellipse([(sk1_x - 12, sk1_y - 6), (sk1_x, sk1_y + 6)], fill=PALETTE["purple"], outline="#ffffff", width=1)
    draw.text((sk1_x - 130, sk1_y + 12), "0.30 mm PVDF Flanş\n(Koter ile eritilmiş)", font=f_label, fill=PALETTE["purple"])

    # Haptik 2 (Sağ): Diğer tünele uzanmış
    draw.arc([(cx - 10, cy - 50), (cx + 140, cy + 50)], start=270, end=30, fill=PALETTE["purple"], width=4)
    draw.ellipse([(sk2_x, sk2_y - 6), (sk2_x + 12, sk2_y + 6)], fill=PALETTE["purple"], outline="#ffffff", width=1)

    # Alt Açıklama Kutusu
    draw.rounded_rectangle([(30, 520), (748, 590)], radius=6, fill="#ffffff", outline=PALETTE["line"])
    draw.text((45, 532), "TÜNEL GEOMETRİSİ: İğneler limbusa tam paralel ve 180° açıyla sokulmalıdır.", font=f_sub, fill=PALETTE["red"])
    draw.text((45, 555), "Asimetrik giriş GİL tiltine, <2.0 mm giriş ise iris sürtünmesine (UGH) yol açar.", font=f_sub, fill=PALETTE["ink"])

    # Sağ Panel Adımları
    steps = [
        ("1. Simetrik 180° Aks İşaretlemesi", "Göz ekseni cerrahi pergelle tam 180° zıt iki noktada işaretlenir. Giriş noktası limbusun tam 2.0–2.5 mm gerisinde olmalıdır.", "blue"),
        ("2. Açılı Skleral Tünel Oluşturma", "30G ince duvarlı iğneler skleraya 20° açıyla sokulur; sklera lamelinde 1.5–2.0 mm ilerletildikten sonra siliyer sulkustan vitreusa dalınır.", "green"),
        ("3. PVDF Haptiklerin Eksternalizasyonu", "3 parçalı PVDF haptikli lens ön kamaraya enjekte edilir. Öncü ve artçı haptikler 25G forsepsle 30G iğne lümenine yönlendirilip çıkarılır.", "amber"),
        ("4. Düşük Isılı Termal Koter Flanşı", "Haptik ucuna koter yaklaştırılarak 0.30 mm çapında küresel pürüzsüz mantar flanş oluşturulur ve skleral tünel içine tamamen gömülür.", "purple")
    ]
    draw_steps_box(draw, steps, 792, 115, 770)

    im.save(output_path, "PNG", dpi=(200, 200))
    print(f" -> Şema 2 kaydedildi: {output_path.name}")


# ==========================================
# 3. STANDART OPTIC CAPTURE VS REVERSE OPTIC CAPTURE
# ==========================================
def generate_schema_optic_capture(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 3.1 — Standart Optic Capture vs Reverse Optic Capture Anatomisi",
        "Kapsüler destek eksikliğinde sulkus fiksasyonu ve negatif disfotopsiyi çözen optik ışık yolu anatomisi"
    )

    f_label = get_font(12, bold=True)
    f_sub = get_font(10, bold=False)

    # İki Dikey Alt Kutu (Üst: Standart Optic Capture, Alt: Reverse Optic Capture)
    box_w = 700
    y_std = 110
    y_rev = 345

    # ÜST KUTU: STANDART OPTIC CAPTURE
    draw.rounded_rectangle([(30, y_std), (740, y_std + 215)], radius=8, fill="#ffffff", outline=PALETTE["blue"], width=2)
    draw.text((45, y_std + 12), "A) STANDART OPTIC CAPTURE (PCR Durumunda Sulkus Fiksasyonu)", font=f_label, fill=PALETTE["blue"])

    # Anatomik Çizim A: İris, Sulkus, Kapsül, GİL
    ay = y_std + 110
    # İris
    draw.rectangle([(80, ay - 55), (240, ay - 42)], fill=PALETTE["iris"])
    draw.rectangle([(530, ay - 55), (690, ay - 42)], fill=PALETTE["iris"])
    draw.text((120, ay - 75), "İris (Ön Kamara)", font=f_sub, fill=PALETTE["purple"])

    # Ön Kapsülorheksis Kenarı
    draw.line([(180, ay - 10), (320, ay - 10)], fill=PALETTE["amber"], width=5)
    draw.line([(450, ay - 10), (590, ay - 10)], fill=PALETTE["amber"], width=5)
    draw.text((80, ay - 15), "Ön Kapsül ->", font=f_sub, fill=PALETTE["amber"])

    # GİL Optiği: Kapsülün ARKASINDA (Kapsül optiğin önünde kilitli)
    draw.ellipse([(310, ay - 22), (460, ay + 28)], fill=PALETTE["lens"], outline=PALETTE["green"], width=2)
    draw.text((355, ay - 2), "GİL OPTİK", font=f_label, fill=PALETTE["ink"])

    # Haptikler: Sulkusta (İris arkasında, kapsülün ÖNÜNDE)
    draw.line([(310, ay), (200, ay - 35)], fill=PALETTE["green"], width=5)
    draw.line([(460, ay), (570, ay - 35)], fill=PALETTE["green"], width=5)
    draw.text((215, ay - 35), "Haptik Sulkusta", font=f_sub, fill=PALETTE["green"])
    draw.text((290, ay + 38), "Ön kapsül kenarı optiğin ÖNÜNDE kilitli (Güç düşümüne gerek yok)", font=f_sub, fill=PALETTE["blue"])

    # ALT KUTU: REVERSE OPTIC CAPTURE
    draw.rounded_rectangle([(30, y_rev), (740, y_rev + 235)], radius=8, fill="#ffffff", outline=PALETTE["purple"], width=2)
    draw.text((45, y_rev + 12), "B) REVERSE OPTIC CAPTURE (Negatif Disfotopsi Tedavi Protokolü)", font=f_label, fill=PALETTE["purple"])

    by = y_rev + 120
    # İris
    draw.rectangle([(80, by - 65), (240, by - 52)], fill=PALETTE["iris"])
    draw.rectangle([(530, by - 65), (690, by - 52)], fill=PALETTE["iris"])

    # Ön Kapsülorheksis Kenarı (Şimdi Optiğin ARKASINDA kalacak)
    draw.line([(220, by + 18), (340, by + 18)], fill=PALETTE["amber"], width=5)
    draw.line([(430, by + 18), (550, by + 18)], fill=PALETTE["amber"], width=5)
    draw.text((80, by + 12), "Ön Kapsül Kenarı ->", font=f_sub, fill=PALETTE["amber"])

    # GİL Optiği: Kapsülün ÖNÜNDE (Sulkus düzlemine doğru çekilmiş)
    draw.ellipse([(310, by - 32), (460, by + 18)], fill=PALETTE["lens"], outline=PALETTE["purple"], width=2)
    draw.text((355, by - 12), "GİL OPTİK", font=f_label, fill=PALETTE["ink"])

    # Haptikler: Kapsül Torbası İÇİNDE (Kapsül kenarının arkasında)
    draw.line([(325, by + 12), (180, by + 30)], fill=PALETTE["purple"], width=5)
    draw.line([(445, by + 12), (590, by + 30)], fill=PALETTE["purple"], width=5)
    draw.text((160, by + 35), "Haptik Torba İçinde", font=f_sub, fill=PALETTE["purple"])

    draw.text((250, by + 50), "Kapsül kenarı optiğin ARKASINDA kalır -> Gölge etkisi ortadan kalkar!", font=f_sub, fill=PALETTE["red"])

    # Sağ Panel Adımları
    steps = [
        ("1. Standart Optic Capture Kriterleri", "PCR zemininde ön kapsülorheksis intakt ise 3 parçalı GİL haptikleri sulkusa, optik ise kapsül içine kilitlenir. Efektif lens pozisyonu (ELP) korunur, güç düşülmez.", "blue"),
        ("2. Negatif Disfotopsi Etiyolojisi", "Ön kapsülorheksis kenarının optik ön yüzünü örtmesi, optik kenarından sapan ışığın nazal retinaya ulaşmasını engelleyerek temporal karanlık hilal yaratır.", "amber"),
        ("3. Reverse Capture Cerrahi Mekanizması", "GİL optiği cerrahi kanca veya OVD ile kapsülorheksis açıklığından öne doğru çıkarılır. Kapsül kenarı optiğin arkasında kilitlenerek optik gölgesi anında silinir.", "green"),
        ("4. 1-Piece Akrilik Uyarısı ve Güvenlik", "Reverse capture yapılırken tek parça akrilik lensin haptikleri KESİNLİKLE torba içinde kalmalıdır. Haptikler sulkusa kaçarsa UGH sendromu kaçınılmazdır.", "purple")
    ]
    draw_steps_box(draw, steps, 792, 115, 770)

    im.save(output_path, "PNG", dpi=(200, 200))
    print(f" -> Şema 3 kaydedildi: {output_path.name}")


# ==========================================
# 4. TASS VS ENDOFTALMİ AYIRICI ANATOMİSİ
# ==========================================
def generate_schema_tass_endo(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 4.1 — TASS ile Akut Enfeksiyöz Endoftalmi Ayırıcı Anatomisi",
        "Limbusdan limbusa diffüz endotel ödemi vs Kesi odaklı reaksiyon, pupilla durumu ve vitritis varlığı"
    )

    f_label = get_font(12, bold=True)
    f_sub = get_font(10, bold=False)

    # İki Karşılaştırmalı Göz Kesiti: Sol = TASS, Sağ = ENDOFTALMİ
    # Panel 1: TASS (Sol Yarım: 30 to 380)
    draw.rounded_rectangle([(30, 110), (375, 590)], radius=8, fill="#ffffff", outline=PALETTE["amber"], width=2)
    draw.text((50, 125), "A) TOKSİK ÖN SEGMENT (TASS)", font=f_label, fill=PALETTE["amber"])

    t_cx, t_cy = 200, 310
    # TASS: Limbusdan limbusa diffüz bulanık kornea
    draw.arc([(t_cx - 130, t_cy - 120), (t_cx + 130, t_cy + 130)], start=200, end=340, fill=PALETTE["amber"], width=14)
    draw.text((t_cx - 85, t_cy - 145), "Diffüz Kornea Ödemi\n(Limbusdan Limbusa)", font=f_sub, fill=PALETTE["amber"], align="center")

    # Ön Kamarada Steril Hipopiyon
    draw.chord([(t_cx - 100, t_cy - 20), (t_cx + 100, t_cy + 80)], start=30, end=150, fill="#fef08a")
    draw.text((t_cx - 38, t_cy + 55), "Hipopiyon", font=f_sub, fill=PALETTE["ink"])

    # Dilate / Fikse Pupilla
    draw.line([(t_cx - 95, t_cy - 10), (t_cx - 55, t_cy - 10)], fill=PALETTE["purple"], width=6)
    draw.line([(t_cx + 55, t_cy - 10), (t_cx + 95, t_cy - 10)], fill=PALETTE["purple"], width=6)
    draw.text((t_cx - 65, t_cy - 30), "Dilate / Fikse Pupil", font=f_sub, fill=PALETTE["purple"])

    # Vitreus: KESİNLİKLE BERRAK!
    draw.ellipse([(t_cx - 70, t_cy + 120), (t_cx + 70, t_cy + 220)], fill=PALETTE["blue_bg"], outline=PALETTE["line"])
    draw.text((t_cx - 50, t_cy + 160), "Vitreus: BERRAK!\n(Vitritis YOKTUR)", font=f_label, fill=PALETTE["green"], align="center")

    # Panel 2: ENDOFTALMİ (Sağ Yarım: 395 to 745)
    draw.rounded_rectangle([(395, 110), (745, 590)], radius=8, fill="#ffffff", outline=PALETTE["red"], width=2)
    draw.text((415, 125), "B) AKUT ENFEKSİYÖZ ENDOFTALMİ", font=f_label, fill=PALETTE["red"])

    e_cx, e_cy = 570, 310
    # Endoftalmi: Kesi odaklı ödem
    draw.arc([(e_cx - 130, e_cy - 120), (e_cx + 130, e_cy + 130)], start=200, end=340, fill=PALETTE["cornea"], width=8)
    draw.line([(e_cx - 120, e_cy - 60), (e_cx - 70, e_cy - 30)], fill=PALETTE["red"], width=10)
    draw.text((e_cx - 130, e_cy - 85), "Kesi İnfiltrasyonu", font=f_sub, fill=PALETTE["red"])

    # Şiddetli Fibrinöz Hipopiyon
    draw.chord([(e_cx - 100, e_cy - 20), (e_cx + 100, e_cy + 80)], start=30, end=150, fill="#fca5a5")
    draw.text((e_cx - 45, e_cy + 55), "Fibrin / Pus", font=f_sub, fill=PALETTE["red"])

    # Spastik / Miyotik Pupilla
    draw.line([(e_cx - 95, e_cy - 10), (e_cx - 25, e_cy - 10)], fill=PALETTE["purple"], width=6)
    draw.line([(e_cx + 25, e_cy - 10), (e_cx + 95, e_cy - 10)], fill=PALETTE["purple"], width=6)
    draw.text((e_cx - 40, e_cy - 30), "Miyotik Pupil", font=f_sub, fill=PALETTE["purple"])

    # Vitreus: YOĞUN VİTRİTİS VE EKSÜDA!
    draw.ellipse([(e_cx - 70, e_cy + 120), (e_cx + 70, e_cy + 220)], fill="#fee2e2", outline=PALETTE["red"])
    for pt in [(-30, 140), (20, 150), (-10, 180), (35, 190), (-25, 200)]:
        draw.ellipse([(e_cx + pt[0] - 4, e_cy + pt[1] - 4), (e_cx + pt[0] + 4, e_cy + pt[1] + 4)], fill=PALETTE["red"])
    draw.text((e_cx - 55, e_cy + 160), "YOĞUN VİTRİTİS!\n(USG'de Membran/Hücre)", font=f_label, fill=PALETTE["red"], align="center")

    # Sağ Panel Adımları
    steps = [
        ("1. Zamanlama: 12-24 Saat vs 3-7 Gün", "TASS ilk 12-24 saatte (1. gün sabahında) zirve yapar. Endoftalmi ise genellikle 3 ila 7. günlerde (ortalama 6. gün) ortaya çıkar.", "amber"),
        ("2. Ağrı Seviyesi: Ağrısız vs Zonklayıcı Ağrı", "TASS'ta hipopiyona rağmen belirgin ağrı yoktur. Endoftalmide ise hastayı uyutmayan şiddetli, derin zonklayıcı göz ağrısı patognomoniktir.", "blue"),
        ("3. Vitreus Muayenesi (B-Scan USG)", "TASS inflamasyonu kesinlikle ön kamarada sınırlıdır. B-scan ultrasonda vitreusta hücre veya membran görülmesi endoftalmi tanısını kesinleştirir.", "red"),
        ("4. Tedavi: Saatlik Steroid vs Tap & Inject / PPV", "TASS saatlik topikal steroidle saatler içinde açılır. Endoftalmi ise acil vitreus biyopsisi, intravitreal vankomisin + seftazidim veya acil PPV gerektirir.", "green")
    ]
    draw_steps_box(draw, steps, 792, 115, 770)

    im.save(output_path, "PNG", dpi=(200, 200))
    print(f" -> Şema 4 kaydedildi: {output_path.name}")


if __name__ == "__main__":
    assets_dir = Path("assets")
    assets_dir.mkdir(parents=True, exist_ok=True)
    generate_schema_vitrectomy(assets_dir / "schema_1_vitrectomy.png")
    generate_schema_yamane(assets_dir / "schema_2_yamane.png")
    generate_schema_optic_capture(assets_dir / "schema_3_optic_capture.png")
    generate_schema_tass_endo(assets_dir / "schema_4_tass_endo.png")
    print("Tüm klinik şemalar başarıyla üretildi!")
