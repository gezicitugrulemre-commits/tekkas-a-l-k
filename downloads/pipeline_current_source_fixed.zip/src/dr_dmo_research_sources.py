# -*- coding: utf-8 -*-
"""
DR & DMÖ Çok Kaynaklı Araştırma Katmanı (Yerel Oftalmoloji Veritabanı + Canlı PubMed NCBI E-Utilities)
======================================================================================================
LangGraph boru hattı (`dr_dmo_langgraph_pipeline.py`) için iki bağımsız kanıt düğümüne veri sağlar:
  1. Yerel Oftalmoloji Veritabanı (`C:\\Users\\gezic\\OneDrive\\Desktop\\DATABASE\\Ophthalmology KİTAPLARI`):
     - AAO BCSC 2023-2024 Section 12: Retina and Vitreous (Chapter 5 DR/DME, Chapter 18 Laser, Chapter 19 PPV)
     - Güncel Retina 2017-2026 Yerel Arşivi (2021, 2023 Diyabetik Vitrektomi Özel Sayısı, 2025 Katarakt+DR, 2026 DR Oküler Genetik)
  2. Canlı PubMed (NCBI E-Utilities `esearch.fcgi` + `efetch.fcgi`):
     - 2019-2026 arası mihenk taşı RKÇ'ler, meta-analizler ve kılavuzlar (Protokol V, W, AA, AB, AC, T 5-Yıl, S 5-Yıl, U;
       YOSEMITE/RHINE/RHONE-X Faricimab; PHOTON Aflibercept 8 mg; KESTREL/KITE Brolucizumab; PAGODA/PAVILION PDS;
       LENS Fenofibrat; SUSTAIN-6/FOCUS GLP-1RA Semaglutid; DIAMOND 577 nm Mikropulse; Otonom YZ DR Tarama).
"""

from __future__ import annotations

import json
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pymupdf

_PUBMED_LOCK = threading.Lock()

DB_ROOT = Path(r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI")
BCSC_S12_PDF = DB_ROOT / "2023_2024_Basic_and_Clinical_Science_Course,_Section_12_Retina_a.pdf"
GR_ARCHIVE_DIR = DB_ROOT / "Guncel_Retina_2017_2026"

# Modül bazlı AAO BCSC 2023-2024 Section 12 PDF sayfa aralıkları (1-tabanlı PDF sayfası)
MODULE_BCSC_PAGES: Dict[str, List[Tuple[int, int, str]]] = {
    "M01": [(121, 127, "AAO BCSC 2023-2024 Sec 12 Ch 5: Epidemiology & Systemic Medical Management of DR")],
    "M02": [(122, 125, "AAO BCSC 2023-2024 Sec 12 Ch 5: Pathogenesis of DR"), (142, 143, "AAO BCSC 2023-2024 Sec 12 Ch 5: DME Blood-Retina Barrier")],
    "M03": [(124, 124, "AAO BCSC 2023-2024 Sec 12: DR Screening Schedule"), (128, 138, "AAO BCSC 2023-2024 Sec 12: NPDR 4:2:1, PDR & DRCR.net Studies")],
    "M04": [(124, 125, "AAO BCSC 2023-2024 Sec 12: OCTA in DR"), (131, 132, "AAO BCSC 2023-2024 Sec 12: IRMA & UWFA"), (142, 145, "AAO BCSC 2023-2024 Sec 12: DME Multimodal OCT Classification")],
    "M05": [(136, 139, "AAO BCSC 2023-2024 Sec 12: Anti-VEGF vs PRP in PDR"), (145, 148, "AAO BCSC 2023-2024 Sec 12: DME Anti-VEGF, Protocol V, T, AC & I")],
    "M06": [(146, 149, "AAO BCSC 2023-2024 Sec 12: Corticosteroids, Protocol U & Refractory DME")],
    "M07": [(139, 140, "AAO BCSC 2023-2024 Sec 12: Laser Photocoagulation"), (145, 149, "AAO BCSC 2023-2024 Sec 12: Micropulse Laser, Faricimab & Emerging Agents")],
    "M08": [(140, 141, "AAO BCSC 2023-2024 Sec 12: Diabetic Vitrectomy Indications"), (456, 458, "AAO BCSC 2023-2024 Sec 12 Ch 19: PPV for Complications of DR & TRD")],
}

# Modül bazlı Güncel Retina (2017-2026) ek/yeni makaleler (2018;2(2) dışındaki dosyalar)
MODULE_GR_EXTRA_FILES: Dict[str, List[Tuple[str, str, int]]] = {
    "M01": [
        (r"2026_Cilt_10_Sayi_4\0598_Diabetic Retinopathy_ Ocular Genetic Studies.pdf", "Güncel Retina 2026;10(4) — DR Oküler Genetik Çalışmalar", 14000),
    ],
    "M02": [
        (r"2023_Cilt_7_Sayi_4\0391_Pathophysiological Changes in Diabetic Vitreous and Retina.pdf", "Güncel Retina 2023;7(4) — Diyabetik Vitreus ve Retinada Patofizyolojik Değişiklikler", 14000),
    ],
    "M03": [
        (r"2025_Cilt_9_Sayi_2\0548_Diabetic Papillopathy and Papillophlebitis.pdf", "Güncel Retina 2025;9(2) — Diyabetik Papillopati Ayırıcı Tanısı", 7000),
        (r"2025_ViewAll_45\0625_Non-Proliferative Diabetic Retinopathy and Cataract_ Treatment Strategies and Current Approaches.pdf", "Güncel Retina 2025 — NPDR ve Katarakt Güncel Yaklaşımlar", 8500),
        (r"2025_ViewAll_45\0607_Proliferative Diabetic Retinopathy and Cataract_ Treatment Strategies and Current Approaches.pdf", "Güncel Retina 2025 — PDR ve Katarakt Güncel Yaklaşımlar", 8500),
    ],
    "M04": [
        (r"2017_ViewAll_8\0083_Differential Diagnoses in Diabetic Optic Neuropathies_ Diabetic Papillopathy, Ischemic Optic Neuropathy and Optic Atrophy.pdf", "Güncel Retina — Diyabetik Optik Nöropatilerde Görüntüleme ve Ayırıcı Tanı", 9000),
    ],
    "M05": [
        (r"2017_ViewAll_8\0088_Bevacizumab and Treatment Regimes in Diabetic Retinopathy and Diabetic Macular Edema.pdf", "Güncel Retina — DR ve DMÖ'de Bevacizumab Tedavisi ve Rejimleri", 12000),
    ],
    "M06": [
        (r"2021_Cilt_5_Sayi_4\0286_Vitrectomy and Vitreoretinal Surgery in Persistent Macular Edema.pdf", "Güncel Retina 2021;5(4) — Persistan Maküla Ödeminde Medikal Direnç ve Cerrahi Sınır", 11000),
    ],
    "M07": [
        (r"2017_ViewAll_8\0091_Conventional and Pattern Laser Applications in Diabetic Retinopathy and Diabetic Macular Edema.pdf", "Güncel Retina — DR ve DMÖ'de Konvansiyonel ve Patern Lazer Uygulamaları", 10000),
        (r"2017_ViewAll_8\0094_Stem Cell Treatment and Gene Therapy in Diabetic Retinopathy.pdf", "Güncel Retina — DR'de Kök Hücre ve Gen Tedavisi", 9000),
    ],
    "M08": [
        (r"2023_Cilt_7_Sayi_4\0355_Current Approaches and Developments in the Surgical Treatment of Proliferative Diabetic Retinopathy Complications.pdf", "Güncel Retina 2023;7(4) — PDR Komplikasyonlarının Cerrahi Tedavisinde Güncel Gelişmeler", 6500),
        (r"2023_Cilt_7_Sayi_4\0360_Currently Recommended Small Incision Vitrectomies and Bimanual Surgery in Diabetic Vitrectomy.pdf", "Güncel Retina 2023;7(4) — Küçük Kesili Vitrektomi (25G/27G) ve Bimanuel Cerrahi", 6500),
        (r"2023_Cilt_7_Sayi_4\0373_Surgical Treatment of Diabetic Combined Tractional-Rhegmatogenous Retinal Detachment.pdf", "Güncel Retina 2023;7(4) — Kombine Traksiyonel-Regmatojen Retina Dekolmanı Cerrahisi", 5500),
        (r"2023_Cilt_7_Sayi_4\0337_Cataract Surgery Combined with Diabetic Vitrectomy and the Use of Intraoperative Optical Coherence Tomography.pdf", "Güncel Retina 2023;7(4) — Kombine Fakovitrektomi ve İntraoperatif OKT (iOCT)", 5500),
        (r"2023_Cilt_7_Sayi_4\0397_Preoperative _ Intraoperative and Postoperative Intravitreal Applications and Preoperative Evaluation in Diabetic Vitrectomy (Advantages of Early.pdf", "Güncel Retina 2023;7(4) — Diyabetik Vitrektomide Preop/İntraop Anti-VEGF ve Erken Vitrektomi", 6000),
    ],
}

# Modül bazlı hedefli PubMed 2019-2026 sorguları
MODULE_PUBMED_QUERIES: Dict[str, List[Tuple[str, int]]] = {
    "M01": [
        ('("fenofibrate"[Title] AND "diabetic retinopathy"[Title] AND ("LENS" OR 2024[dp]))', 2),
        ('("semaglutide"[Title] AND "diabetic retinopathy"[Title])', 3),
        ('("Global Prevalence of Diabetic Retinopathy and Projection of Burden"[Title]) OR ("global burden"[Title] AND "diabetic retinopathy"[Title] AND 2021[dp])', 2),
    ],
    "M02": [
        ('("neurovascular unit"[Title] OR "retinal neurodegeneration"[Title]) AND "diabetic retinopathy"[Title] AND (2019:2026[dp])', 3),
        ('("angiopoietin-2"[Title] OR "Tie2"[Title] OR "Tie-2"[Title]) AND ("diabetic macular edema"[Title/Abstract] OR "diabetic retinopathy"[Title/Abstract]) AND (2019:2026[dp])', 3),
    ],
    "M03": [
        ('("Effect of Initial Management With Aflibercept vs Laser Photocoagulation vs Observation"[Title]) OR ("good visual acuity"[Title] AND "diabetic macular edema"[Title] AND 2019[dp])', 2),
        ('("Effect of Intravitreous Anti-Vascular Endothelial Growth Factor vs Sham"[Title]) OR ("Protocol W"[Title/Abstract] AND "nonproliferative"[Title/Abstract])', 3),
        ('("Pivotal trial of an autonomous AI-based diagnostic system for detection of diabetic retinopathy"[Title]) OR ("autonomous"[Title] AND "diabetic retinopathy"[Title] AND "screening"[Title])', 2),
    ],
    "M04": [
        ('("Retinal Nonperfusion and"[Title] AND "Predominantly Peripheral Lesions"[Title]) OR ("predominantly peripheral lesions"[Title] AND "diabetic retinopathy"[Title])', 2),
        ('("disorganization of retinal inner layers"[Title] OR "hyperreflective foci"[Title]) AND "diabetic macular edema"[Title] AND (2020:2026[dp])', 3),
        ('("swept-source"[Title] OR "widefield"[Title]) AND "optical coherence tomography angiography"[Title] AND "diabetic retinopathy"[Title] AND (2020:2026[dp])', 2),
    ],
    "M05": [
        ('("aflibercept monotherapy"[Title] AND "bevacizumab first"[Title])', 2),
        ('("five-year outcomes"[Title] AND ("Protocol T"[Title/Abstract] OR ("aflibercept"[Title] AND "bevacizumab"[Title] AND "ranibizumab"[Title])))', 2),
        ('("five-year"[Title] AND "panretinal photocoagulation"[Title] AND "ranibizumab"[Title])', 2),
    ],
    "M06": [
        ('("Continued Ranibizumab With"[Title] AND "Dexamethasone"[Title] AND "Persistent Diabetic Macular Edema"[Title])', 2),
        ('("early switch"[Title] AND "dexamethasone"[Title] AND "diabetic macular edema"[Title])', 3),
        ('("PALADIN"[Title/Abstract] AND "fluocinolone acetonide"[Title] AND "diabetic macular edema"[Title])', 2),
    ],
    "M07": [
        ('("Efficacy, durability, and safety of intravitreal faricimab with extended dosing up to every 16 weeks in patients with diabetic macular oedema"[Title]) OR ("YOSEMITE and RHINE"[Title] AND "faricimab"[Title])', 3),
        ('("Intravitreal aflibercept 8 mg in diabetic macular oedema (PHOTON)"[Title]) OR ("PHOTON"[Title] AND "aflibercept 8 mg"[Title])', 2),
        ('("KESTREL and KITE"[Title] AND "brolucizumab"[Title])', 2),
        ('("Standard-Care"[Title] AND "Subthreshold Micropulse Laser"[Title] AND "DIAMOND"[Title/Abstract]) OR ("subthreshold micropulse"[Title] AND "DIAMOND"[Title/Abstract])', 2),
        ('("Port Delivery System with Ranibizumab"[Title] AND ("Diabetic Macular Edema"[Title] OR "Diabetic Retinopathy"[Title]))', 2),
    ],
    "M08": [
        ('("Effect of Initial Intravitreal Aflibercept vs Vitrectomy With Panretinal Photocoagulation"[Title]) OR ("Protocol AB"[Title/Abstract] AND "vitreous hemorrhage"[Title])', 2),
        ('("27-gauge"[Title] OR "beveled"[Title] OR "bimanual"[Title]) AND "diabetic"[Title] AND "tractional retinal detachment"[Title] AND (2020:2026[dp])', 3),
        ('("preoperative"[Title] AND "anti-VEGF"[Title] AND "diabetic"[Title] AND "tractional retinal detachment"[Title] AND (2019:2026[dp]))', 2),
    ],
}


def fetch_local_db_evidence_for_module(module_id: str, cache_dir: Path) -> Dict[str, Any]:
    """
    Yerel Oftalmoloji Veritabanından (AAO BCSC 2023-2024 Section 12 + Güncel Retina 2021-2026)
    ilgili modülün tam metin pasajlarını çıkarır ve önbelleğe kaydeder.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    cfile = cache_dir / f"local_db_{module_id}.json"
    if cfile.is_file():
        return json.loads(cfile.read_text(encoding="utf-8"))

    blocks: List[str] = []
    citations: List[str] = []

    # 1. AAO BCSC 2023-2024 Section 12
    if BCSC_S12_PDF.is_file():
        with pymupdf.open(str(BCSC_S12_PDF)) as bdoc:
            for p_start, p_end, label in MODULE_BCSC_PAGES.get(module_id, []):
                citations.append(f"{label} (PDF s. {p_start}-{p_end})")
                page_txts = []
                for pno in range(p_start, p_end + 1):
                    if 1 <= pno <= len(bdoc):
                        book_p = pno - 21  # BCSC S12 kitap sayfası yaklaşıklığı
                        raw = bdoc[pno - 1].get_text("text").strip()
                        page_txts.append(f"[AAO BCSC 2023-2024:s.{book_p} / PDF s.{pno}]\n{raw}")
                if page_txts:
                    blocks.append(f"### {label}\n" + "\n\n".join(page_txts))

    # 2. Güncel Retina 2017-2026 Ek & Güncel Derlemeler
    for rel_path, label, char_cap in MODULE_GR_EXTRA_FILES.get(module_id, []):
        pdf_path = GR_ARCHIVE_DIR / rel_path
        if pdf_path.is_file():
            citations.append(label)
            with pymupdf.open(str(pdf_path)) as gdoc:
                g_pages = []
                for idx in range(len(gdoc)):
                    g_pages.append(f"[{label} | PDF s.{idx + 1}]\n{gdoc[idx].get_text('text').strip()}")
                joined = "\n\n".join(g_pages)
                if len(joined) > char_cap:
                    # Giriş/Özet + Sonuç/Güncel Klinik bölümlerini koru
                    half = char_cap // 2
                    joined = joined[:half] + "\n...[ORTA KISIM ÖZETLENDİ]...\n" + joined[-half:]
                blocks.append(f"### {label}\n{joined}")

    payload = {
        "module_id": module_id,
        "db_citations": citations,
        "formatted_text": "\n\n====================\n\n".join(blocks) if blocks else "Yerel veritabanı ek metni bulunamadı.",
    }
    cfile.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def _pubmed_esearch(query: str, retmax: int = 3) -> List[str]:
    params = urllib.parse.urlencode({
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": str(retmax),
        "sort": "relevance",
    })
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?{params}"
    headers = {"User-Agent": "AntiGravityDRStudyGuide/2.0 (Academic Medical Synthesis)"}
    for attempt in range(4):
        try:
            with _PUBMED_LOCK:
                time.sleep(0.48)
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=20) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    return data.get("esearchresult", {}).get("idlist", [])
        except Exception:
            time.sleep(1.8 * (attempt + 1))
    return []


def _pubmed_efetch(pmids: List[str]) -> List[Dict[str, Any]]:
    if not pmids:
        return []
    params = urllib.parse.urlencode({
        "db": "pubmed",
        "id": ",".join(pmids),
        "retmode": "xml",
    })
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?{params}"
    headers = {"User-Agent": "AntiGravityDRStudyGuide/2.0 (Academic Medical Synthesis)"}
    xml_bytes = b""
    for attempt in range(4):
        try:
            with _PUBMED_LOCK:
                time.sleep(0.50)
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=25) as resp:
                    xml_bytes = resp.read()
                    break
        except Exception:
            time.sleep(1.8 * (attempt + 1))
    if not xml_bytes:
        return []

    records: List[Dict[str, Any]] = []
    root = ET.fromstring(xml_bytes)
    for art in root.findall(".//PubmedArticle"):
        pmid = (art.findtext(".//MedlineCitation/PMID") or "").strip()
        if not pmid:
            continue
        title_el = art.find(".//Article/ArticleTitle")
        title = "".join(title_el.itertext()).strip() if title_el is not None else ""
        journal = (art.findtext(".//Article/Journal/ISOAbbreviation") or art.findtext(".//Article/Journal/Title") or "").strip()
        year = (
            art.findtext(".//Article/Journal/JournalIssue/PubDate/Year")
            or art.findtext(".//Article/ArticleDate/Year")
            or art.findtext(".//Article/Journal/JournalIssue/PubDate/MedlineDate")
            or "n.d."
        ).strip()[:4]

        authors = art.findall(".//Article/AuthorList/Author")
        first_author = "Çalışma Grubu"
        if authors:
            last = (authors[0].findtext("LastName") or authors[0].findtext("CollectiveName") or "").strip()
            if last:
                first_author = f"{last} ve ark." if len(authors) > 1 and authors[0].findtext("LastName") else last

        doi = ""
        for aid in art.findall(".//PubmedData/ArticleIdList/ArticleId"):
            if aid.attrib.get("IdType") == "doi" and aid.text:
                doi = aid.text.strip()
                break

        pub_types = [pt.text.strip() for pt in art.findall(".//Article/PublicationTypeList/PublicationType") if pt.text]

        ab_parts = []
        for ab_el in art.findall(".//Article/Abstract/AbstractText"):
            lbl = ab_el.attrib.get("Label", "")
            txt = "".join(ab_el.itertext()).strip()
            if txt:
                ab_parts.append(f"{lbl}: {txt}" if lbl else txt)
        abstract = " ".join(ab_parts).strip() or "(PubMed kaydında yapılandırılmış özet metni yer almamaktadır; yalnızca başlık ve üst veri doğrulanmıştır.)"

        pubmed_url = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
        doi_url = f"https://doi.org/{doi}" if doi else ""
        inline_cite = f"[{first_author}, {year} — PMID:{pmid}]"

        formatted = (
            f"DOĞRULANMIŞ PUBMED KAYDI {inline_cite}\n"
            f"- Başlık: {title}\n"
            f"- Dergi & Yıl: {journal} ({year}) | Yayın Türü: {', '.join(pub_types[:4])}\n"
            f"- Bağlantı: {pubmed_url}" + (f" | DOI: {doi_url}" if doi_url else "") + "\n"
            f"- Erişim Kapsamı: Yalnızca PubMed Özeti (Abstract) — Tam metin alt tabloları görülmemiştir.\n"
            f"- Özet Bulguları: {abstract}"
        )
        records.append({
            "pmid": pmid,
            "doi": doi,
            "pubmed_url": pubmed_url,
            "doi_url": doi_url,
            "first_author": first_author,
            "year": year,
            "journal": journal,
            "title": title,
            "pub_types": pub_types,
            "inline_cite": inline_cite,
            "access_scope": "pubmed_abstract_only",
            "formatted": formatted,
        })
    return records


def fetch_pubmed_landmark_evidence_for_module(module_id: str, cache_dir: Path) -> Dict[str, Any]:
    """
    Her modül için hedefli PubMed E-Utilities aramalarını çalıştırır, benzersiz PMID'leri birleştirir
    ve yapılandırılmış kanıt paketini önbelleğe (`pubmed_{module_id}.json`) yazar.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    cfile = cache_dir / f"pubmed_{module_id}.json"
    if cfile.is_file():
        cached = json.loads(cfile.read_text(encoding="utf-8"))
        if cached.get("articles"):
            return cached

    ordered_pmids: List[str] = []
    for query, rmax in MODULE_PUBMED_QUERIES.get(module_id, []):
        ids = _pubmed_esearch(query, retmax=rmax)
        for pid in ids:
            if pid not in ordered_pmids:
                ordered_pmids.append(pid)

    articles = _pubmed_efetch(ordered_pmids)

    payload = {
        "module_id": module_id,
        "pmid_count": len(articles),
        "verified_pmids": [f"{a['inline_cite']} ({a['journal']}, {a['year']})" for a in articles],
        "articles": articles,
        "formatted_text": "\n\n--------------------\n\n".join(a["formatted"] for a in articles) if articles else "PubMed kaydı bulunamadı.",
    }
    if articles:
        cfile.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload
