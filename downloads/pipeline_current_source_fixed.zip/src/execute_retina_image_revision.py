import pptx
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
import json
import sys
import os
import shutil
import time
from PIL import Image
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

PPTX_DESKTOP = Path(r'c:\Users\gezic\OneDrive\Desktop\Anti Gravity\Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx')
PPTX_DRIVE = Path(r"C:\Users\gezic\Drive'ım\Retina Kitabı\Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx")
PLAN_FILE = Path(r'c:\Users\gezic\OneDrive\Desktop\Anti Gravity\perfect_image_revision_plan.json')
CACHE_DIR = Path(r'c:\Users\gezic\OneDrive\Desktop\Anti Gravity\assets\cached_images')
CACHE_DIR.mkdir(parents=True, exist_ok=True)

print("=" * 80)
print(">>> RETİNA VE VİTREUS MASTERCLASS: GÖRSEL REVİZYON VE DOĞRULAMA MOTORU BAŞLATILDI")
print("=" * 80)

# 1. Load Plan
with open(PLAN_FILE, 'r', encoding='utf-8') as f:
    plan_list = json.load(f)

plan_map = {item['slide']: item for item in plan_list}
print(f"Toplam revizyon planlanan slayt sayısı: {len(plan_map)}")

# 2. Open Presentation
print(f">> Sunum dosyası yükleniyor: {PPTX_DESKTOP}...")
prs = pptx.Presentation(str(PPTX_DESKTOP))
total_slides = len(prs.slides)
print(f">> Toplam slayt sayısı: {total_slides}")
assert total_slides == 446, f"Beklenmeyen slayt sayısı: {total_slides}"

# 3. Helper to ensure RGB cache
def get_safe_rgb_path(img_path_str):
    p = Path(img_path_str)
    if not p.exists():
        return None
    try:
        # Check if already RGB or simple jpeg/png
        ext = p.suffix.lower()
        if ext in ['.jpeg', '.jpg', '.png']:
            return p
        # If tiff or other format, convert
        target = CACHE_DIR / (p.stem + ".png")
        if not target.exists():
            im = Image.open(p)
            if im.mode != 'RGB':
                im = im.convert('RGB')
            im.save(target, 'PNG')
        return target
    except Exception as e:
        print(f"Uyarı (RGB dönüşüm): {p.name}: {e}")
        return p if p.exists() else None

# 4. Right Panel Geometry
right_x = Inches(8.35)
right_w = Inches(4.18)
max_img_w = right_w - Inches(0.24) # 3.94 in
max_img_h = Inches(3.55)
img_area_y = Inches(1.9) + Inches(0.48) # 2.38 in

success_count = 0
skip_count = 0
error_count = 0

for slide_idx, slide in enumerate(prs.slides, 1):
    if slide_idx not in plan_map:
        continue
    
    spec = plan_map[slide_idx]
    new_img_raw = spec['selected_image']
    new_cap_text = spec['caption']
    
    new_img_path = get_safe_rgb_path(new_img_raw)
    if not new_img_path or not new_img_path.exists():
        print(f"[HATA] S{slide_idx:03d}: Görsel bulunamadı ({new_img_raw})")
        error_count += 1
        continue

    # Find existing picture and caption shape
    pic_shape = None
    cap_shape = None
    for shp in slide.shapes:
        if shp.shape_type == 13: # Picture
            pic_shape = shp
        if shp.has_text_frame and '📷' in shp.text_frame.text:
            cap_shape = shp

    if not pic_shape:
        print(f"[UYARI] S{slide_idx:03d}: Resim şekli bulunamadı, atlandı.")
        skip_count += 1
        continue

    try:
        # Calculate aspect ratio
        im = Image.open(str(new_img_path))
        orig_w, orig_h = im.size
        
        # Scale with aspect ratio
        scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
        disp_w = Inches(orig_w / 96.0) * scale
        disp_h = Inches(orig_h / 96.0) * scale
        img_x = right_x + (right_w - disp_w) / 2
        img_y = img_area_y + (max_img_h - disp_h) / 2

        # Remove old picture element
        sp_elem = pic_shape._element
        sp_elem.getparent().remove(sp_elem)

        # Add new picture
        slide.shapes.add_picture(str(new_img_path), img_x, img_y, width=disp_w, height=disp_h)

        # Update caption
        if cap_shape:
            cap_shape.text_frame.text = new_cap_text
            p = cap_shape.text_frame.paragraphs[0]
            p.font.name = "Arial"
            p.font.size = Pt(7.8)
            p.font.bold = True
            p.font.color.rgb = RGBColor(15, 30, 54) # Navy

        success_count += 1
        if success_count % 50 == 0 or slide_idx in [138, 145, 206, 276, 302, 309, 363, 389]:
            print(f"  [OK] S{slide_idx:03d} güncellendi ({success_count}/{len(plan_map)}): {spec['rule']} -> {new_img_path.name[:30]}")

    except Exception as e:
        print(f"[HATA] S{slide_idx:03d} işlenirken hata: {e}")
        error_count += 1

print("\n" + "=" * 80)
print(f">> GÖRSEL YENİLEME TAMAMLANDI: Başarılı: {success_count}, Atlanan: {skip_count}, Hata: {error_count}")
print("=" * 80)

# 5. Save to Desktop
temp_out = PPTX_DESKTOP.parent / "Retina_Masterclass_Images_Updated_Temp.pptx"
print(f">> Geçici dosya kaydediliyor: {temp_out}...")
prs.save(str(temp_out))
print(f">> Geçici dosya boyutu: {temp_out.stat().st_size / (1024*1024):.2f} MB")

# Replace desktop file safely
print(f">> Masaüstü ana dosyası güncelleniyor: {PPTX_DESKTOP}...")
if PPTX_DESKTOP.exists():
    backup_file = PPTX_DESKTOP.parent / "Retina_Masterclass_Pre_Image_Fix_Backup.pptx"
    try:
        shutil.copy2(PPTX_DESKTOP, backup_file)
        print(f"  [Yedek alındı]: {backup_file.name}")
    except Exception as be:
        print(f"  [Yedek uyarısı]: {be}")

for retry in range(5):
    try:
        shutil.move(str(temp_out), str(PPTX_DESKTOP))
        print(">> Masaüstü dosyası başarıyla güncellendi.")
        break
    except Exception as me:
        print(f"  Masaüstü taşıma yeniden deneniyor ({retry+1}/5): {me}")
        time.sleep(2)

# Synchronize to Google Drive
print(f">> Google Drive dosyası eşitleniyor: {PPTX_DRIVE}...")
for retry in range(5):
    try:
        shutil.copy2(str(PPTX_DESKTOP), str(PPTX_DRIVE))
        print(">> Google Drive dosyası başarıyla eşitlendi.")
        break
    except Exception as de:
        print(f"  Google Drive eşitleme yeniden deneniyor ({retry+1}/5): {de}")
        time.sleep(3)

print("=" * 80)
print(">>> TÜM GÖRSELLER REVİZE EDİLDİ VE ÇİFT KONUMA EŞİTLENDİ")
print("=" * 80)
