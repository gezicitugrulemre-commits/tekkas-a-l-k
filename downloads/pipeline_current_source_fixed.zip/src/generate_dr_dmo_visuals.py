# -*- coding: utf-8 -*-
"""
Diyabetik Retinopati ve Diyabetik Maküla Ödemi (DR & DMÖ) — 2026 Güncel Sürüm
Ultra Yüksek Çözünürlüklü Vektörel/PIL Şematik Çizim ve Veritabanı Klinik Görüntü Kompozisyon Modülü

Üretilen 16 Görsel (1600 x 620 px — Tüm Bölümler M01..M08 + Bölüm 9 Tam Kapsam):
  - Şemalar (PIL):
      1. schema_0_epi_metabolic: Sistemik Kontrol, Epigenetik Metabolik Hafıza, Fenofibrat (LENS) & GLP-1RA Erken Kötüleşme
      2. schema_1: Nörovasküler Ünite Hasarı, 4 Biyokimyasal Yolak, Ang-2/Tie-2, Lökostaz ve KRB/Müller Yıkımı
      3. schema_2: Yapısal OKT Biyobelirteçleri (DRIL, HRF, EZ) ve SD-OKTA vs SS-OKTA Pleksus Analizi
      4. schema_3: 2026 Kanıta Dayalı DMÖ & DR Anti-VEGF Algoritması (Protokol V, T, AC, W ve S)
      5. schema_4: Konvansiyonel Lazer vs Endpoint Management (%30) vs 577 nm Subliminal Mikropulse (%5 DC, DIAMOND)
      6. schema_5: Diyabetik VİH (Protokol AB) & TRD Cerrahisi — Preop Anti-VEGF (<3-7 Gün) ve En Bloc Delaminasyon
      7. schema_6_steroid_switch: Steroid Farmakokinetik Paradoksu (DEX/TA/FA), Ozurdex/Iluvien ve Erken Switch Algoritması
      8. schema_7_nextgen_2026: Yeni Nesil Ajanlar (Faricimab YOSEMITE/RHINE, Aflibercept 8 mg PHOTON, PDS, Brolucizumab IOI)
      9. schema_8_biostat_gee: Hasta Düzeyi vs Göz Düzeyi Analiz Birimi, ICC, GEE ve Karma Modeller (SPSS Akışı)
  - Klinik Paneller (AAO BCSC 2023-2024 Section 12 + Güncel Retina Arşivi):
     10. panel_dme_brb_oct: KRB Yıkımı Mekanizması + SD-OKT Kistoid/Seröz DMÖ ve Sert Eksüda Gölgelenmesi
     11. panel_etdrs_421_uwfa: ETDRS Ağır NPDR 4:2:1 Kuralı (2A, 6B, IRMA) + Ultra-Geniş Açılı FA (UWFA - Protokol AA)
     12. panel_hr_pdr_nvd_nve: Yüksek Riskli PDR (NVD, NVE + Preretinal Hemoraji ve FA Sızıntısı)
     13. panel_octa_faz_dril: En-Face OKTA FAZ Genişlemesi (Erken vs İleri DR) ve Yapısal OKT Foveal DRIL
     14. panel_dme_ci_nci_prp: Merkezi Tutmayan vs Merkezi Tutan DMÖ OKT Haritası ve Panretinal Fotokoagülasyon (PRP)
     15. panel_oct_dril_vmt: İnflamatuvar/Dirençli DMÖ OKT Fenotipi (SMD + HRF + Dev Kist) ve Vitreomaküler Traksiyon (VMT)
     16. panel_trd_surgery_db: Masaüstü (Tabletop) Diyabetik TRD, 577 nm Kromofor Seçiciliği ve Bimanuel En Bloc Delaminasyon
"""

from pathlib import Path
from typing import Dict, List, Tuple
from PIL import Image, ImageDraw, ImageFont

PALETTE = {
    "bg": "#ffffff",
    "ink": "#142f43",
    "muted": "#476174",
    "line": "#cddce8",
    "blue": "#1c5ba6",
    "blue_bg": "#edf4ff",
    "green": "#087d6c",
    "green_bg": "#eaf8f2",
    "amber": "#a46109",
    "amber_bg": "#fff5df",
    "purple": "#6941a5",
    "purple_bg": "#f4effc",
    "red": "#b91c1c",
    "red_bg": "#fef2f2",
    "panel_bg": "#f8fbff",
}

BCSC_PDF_DEFAULT = Path(
    r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI\2023_2024_Basic_and_Clinical_Science_Course,_Section_12_Retina_a.pdf"
)


def get_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    paths = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for p in paths:
        if Path(p).exists():
            return ImageFont.truetype(p, size=size)
    return ImageFont.load_default()


def create_base_canvas(title: str, subtitle: str, split_x: int = 790, single_panel: bool = False) -> Tuple[Image.Image, ImageDraw.ImageDraw]:
    w, h = 1600, 620
    im = Image.new("RGB", (w, h), PALETTE["bg"])
    draw = ImageDraw.ImageDraw(im)

    draw.rounded_rectangle([(4, 4), (w - 4, h - 4)], radius=12, fill=PALETTE["bg"], outline=PALETTE["line"], width=2)
    draw.rounded_rectangle([(6, 6), (w - 6, 86)], radius=10, fill=PALETTE["blue"])
    draw.rectangle([(6, 50), (w - 6, 86)], fill=PALETTE["blue"])

    draw.text((28, 17), title, font=get_font(21, bold=True), fill="#ffffff")
    draw.text((28, 52), subtitle, font=get_font(13, bold=False), fill="#dbeafe")

    if single_panel:
        draw.rounded_rectangle([(18, 98), (w - 18, h - 18)], radius=10, fill=PALETTE["panel_bg"], outline=PALETTE["line"], width=1)
    else:
        draw.rounded_rectangle([(18, 98), (split_x, h - 18)], radius=10, fill=PALETTE["panel_bg"], outline=PALETTE["line"], width=1)
        draw.rounded_rectangle([(split_x + 16, 98), (w - 18, h - 18)], radius=10, fill="#ffffff", outline=PALETTE["line"], width=1)
    return im, draw


def draw_wrapped_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    x: int,
    y: int,
    max_w: int,
    font: ImageFont.FreeTypeFont,
    fill: str,
    line_h: int = 19,
    max_lines: int = 4,
) -> int:
    words = text.split()
    lines: List[str] = []
    cur: List[str] = []
    for wd in words:
        cand = " ".join(cur + [wd])
        bbox = draw.textbbox((0, 0), cand, font=font)
        if bbox[2] - bbox[0] > max_w and cur:
            lines.append(" ".join(cur))
            cur = [wd]
        else:
            cur.append(wd)
    if cur:
        lines.append(" ".join(cur))
    cy = y
    for ln in lines[:max_lines]:
        draw.text((x, cy), ln, font=font, fill=fill)
        cy += line_h
    return cy


def draw_steps_box(
    draw: ImageDraw.ImageDraw,
    steps: List[Tuple[str, str, str]],
    x: int,
    y_start: int,
    w: int,
    box_h: int = 110,
    gap: int = 12,
):
    f_title = get_font(15, bold=True)
    f_body = get_font(13, bold=False)
    badge_colors = {
        "blue": (PALETTE["blue"], PALETTE["blue_bg"]),
        "green": (PALETTE["green"], PALETTE["green_bg"]),
        "amber": (PALETTE["amber"], PALETTE["amber_bg"]),
        "purple": (PALETTE["purple"], PALETTE["purple_bg"]),
        "red": (PALETTE["red"], PALETTE["red_bg"]),
    }
    y = y_start
    for title, desc, ckey in steps:
        fg, bg = badge_colors.get(ckey, (PALETTE["blue"], PALETTE["blue_bg"]))
        draw.rounded_rectangle([(x, y), (x + w, y + box_h)], radius=8, fill=bg, outline=fg, width=1)
        draw.rounded_rectangle([(x, y), (x + 8, y + box_h)], radius=4, fill=fg)
        draw.text((x + 20, y + 10), title, font=f_title, fill=fg)
        draw_wrapped_text(draw, desc, x + 20, y + 35, w - 32, f_body, PALETTE["ink"], line_h=19, max_lines=3)
        y += box_h + gap


def ensure_bcsc_figures_extracted(db_fig_dir: Path) -> None:
    """AAO BCSC 2023-2024 Section 12 içerisindeki hedef DR/DMÖ/TRD görsellerini otomatik çıkarır."""
    needed = [
        (124, 26566),
        (124, 26569),
        (130, 26573),
        (130, 26574),
        (131, 26577),
        (131, 26578),
        (135, 26580),
        (135, 26581),
        (140, 26592),
        (142, 26596),
        (142, 26597),
        (144, 26608),
        (144, 26610),
        (457, 27802),
    ]
    db_fig_dir.mkdir(parents=True, exist_ok=True)
    existing = list(db_fig_dir.glob("bcsc_p*.png"))
    if len(existing) >= len(needed) or not BCSC_PDF_DEFAULT.is_file():
        return
    try:
        import pymupdf
        doc = pymupdf.open(str(BCSC_PDF_DEFAULT))
        for pno, xref in needed:
            pix = pymupdf.Pixmap(doc, xref)
            if pix.colorspace != pymupdf.csRGB:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            fname = f"bcsc_p{pno}_x{xref}_{pix.width}x{pix.height}.png"
            pix.save(str(db_fig_dir / fname))
        doc.close()
    except Exception:
        pass


def _find_db_img(db_fig_dir: Path, prefix: str) -> Path:
    matches = sorted(db_fig_dir.glob(f"{prefix}*.png"))
    return matches[0] if matches else (db_fig_dir / f"{prefix}.png")


# ==============================================================================
# 0. BÖLÜM 1 ŞEMASI: EPİDEMİYOLOJİ, METABOLİK HAFIZA, FENOFİBRAT & ERKEN KÖTÜLEŞME
# ==============================================================================
def generate_dr_schema_0_epi_metabolic(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 1.1 — Sistemik Kontrol, Epigenetik Metabolik Hafıza (DCCT/EDIC), Fenofibrat ve Erken Kötüleşme",
        "Glisemik/hipertansif kontrol, PPAR-α agonizmi (FIELD/ACCORD/LENS 2024) ve hızlı HbA1c düşüşünde (İnsülin/GLP-1RA) paradoksal kötüleşme",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    # Üst Sol: DCCT/EDIC Epigenetik Metabolik Hafıza Eğrisi Şeması
    draw.rounded_rectangle([(34, 112), (772, 286)], radius=10, fill="#ffffff", outline=PALETTE["blue"], width=2)
    draw.text((50, 122), "A) DCCT / EDIC EPİGENETİK 'METABOLİK HAFIZA' VE SİSTEMİK KORUMA", font=f_b, fill=PALETTE["blue"])

    # Eksen çizimi
    draw.line([(68, 252), (430, 252)], fill=PALETTE["muted"], width=2)
    draw.line([(68, 155), (68, 252)], fill=PALETTE["muted"], width=2)
    # Konvansiyonel eğri (kırmızı yüksek) vs Yoğun eğri (yeşil düşük)
    draw.line([(72, 246), (175, 224), (275, 190), (415, 160)], fill=PALETTE["red"], width=4)
    draw.line([(72, 246), (135, 232), (240, 236), (415, 222)], fill=PALETTE["green"], width=4)
    draw.line([(205, 155), (205, 252)], fill=PALETTE["amber"], width=2)
    draw.text((82, 160), "DCCT (6.5 Yıl)", font=get_font(11, bold=True), fill=PALETTE["muted"])
    draw.text((216, 155), "EDIC (HbA1c Eşitlendi ~%8)", font=get_font(11, bold=True), fill=PALETTE["amber"])
    draw.text((312, 192), "Konvansiyonel Kol", font=get_font(11, bold=True), fill=PALETTE["red"])
    draw.text((285, 234), "Yoğun Kol (-%76 Yeni DR)", font=get_font(11, bold=True), fill=PALETTE["green"])

    # Sağ kutucuk (Genetik/Epigenetik)
    draw.rounded_rectangle([(446, 154), (756, 270)], radius=8, fill=PALETTE["purple_bg"], outline=PALETTE["purple"], width=1)
    draw.text((458, 164), "Epigenetik & Genetik İzler:", font=get_font(13, bold=True), fill=PALETTE["purple"])
    draw.text((458, 187), "• BCOR DNA metilasyonu & SUV39H2 histon", font=f_s, fill=PALETTE["ink"])
    draw.text((458, 207), "• miR-126 ↓ (VEGF ↑), miR-146a ↓ (NF-κB ↑)", font=f_s, fill=PALETTE["ink"])
    draw.text((458, 227), "• Polimorfizm: VEGFA rs2010963, ALR2 Z-2,", font=f_s, fill=PALETTE["ink"])
    draw.text((458, 247), "  EPO rs1617640, eNOS, RAGE -374T/A", font=f_s, fill=PALETTE["ink"])

    # Orta Sol: Erken Kötüleşme Fenomeni (İnsülin & GLP-1RA Semaglutid)
    draw.rounded_rectangle([(34, 300), (772, 434)], radius=10, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((50, 310), "B) ERKEN KÖTÜLEŞME (EARLY WORSENING): DCCT (%13.1) & SUSTAIN-6 (SEMAGLUTİD)", font=f_b, fill=PALETTE["red"])
    draw.text((50, 336), "Uzun süreli kötü glisemik kontrol (yüksek HbA1c) + Mevcut orta/ağır NPDR veya PDR zemininde", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 357), "HIZLI HbA1c DÜŞÜŞÜ (>%1.5-2 / 3 ay) -> IGF-1 biyoyararlanımı ↑ + Otoregülatuvar hipoperfüzyon + HIF-1α/VEGF deşarjı", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((50, 381), "• Klinik Kural: GLP-1RA (semaglutid) veya yoğun insülin başlanmadan önce bazal fundus/OKT muayenesi şarttır;", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 402), "  aktif yüksek riskli PDR veya merkezi tutan DMÖ varsa önce oküler stabilizasyon sağlanıp kademeli düşüş hedeflenir.", font=f_s, fill=PALETTE["ink"])

    # Alt Sol: Fenofibrat Üçlemesi (FIELD, ACCORD-Eye, LENS 2024)
    draw.rounded_rectangle([(34, 448), (772, 586)], radius=10, fill=PALETTE["green_bg"], outline=PALETTE["green"], width=2)
    draw.text((50, 458), "C) FENOFİBRAT KANIT ÜÇLEMESİ (SERUM LİPİD DÜŞÜŞÜNDEN BAĞIMSIZ PPAR-α KORUMASI)", font=f_b, fill=PALETTE["green"])
    draw.text((50, 484), "• FIELD (n=9795): Lazer gereksiniminde %31-37 azalma | ACCORD-Eye: Simvastatine ek fenofibrat ile %40 progresyon azalması.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 506), "• LENS RKÇ (Preiss ve ark., NEJM Evid 2024; n=1151): Fenofibrat 145 mg ile sevk edilebilir DR/DMÖ", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((50, 528), "  veya tedavi ihtiyacında %27 rölatif risk azalması (HR 0.73) — kapiller endotel sağkalımı, anti-apoptotik & anti-VEGF etki.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 552), "• RAS Blokajı (EUCLID, DIRECT, RASS): Normotansif erken evrede koruyucu; belirgin hipertansiyonda hedef KB <130/80 mmHg.", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("UKPDS & GLİSEMİK/KAN BASINCI EŞİKLERİ", "Her %1 HbA1c düşüşü mikrovasküler riski %35 azaltır; sıkı KB kontrolü DR progresyonunu %34 ve lazer ihtiyacını %35 düşürür.", "blue"),
        ("ACCORD SINIRI (AŞIRI SIKI KONTROL RİSKİ)", "HbA1c <%6.0 hedefi DR progresyonunu azaltsa da ağır hipoglisemi ve kardiyovasküler mortaliteyi artırdığından hedef genellikle <%7.0'dir.", "amber"),
        ("RENAL-RETİNAL EKSEN, ANEMİ VE UYKU APNESİ", "Albüminüri/düşük eGFR, demir eksikliği anemisi (hipoksik EPO deşarjı) ve OUA (nokturnal desatürasyon) dirençli DMÖ'yü ağırlaştırır.", "purple"),
        ("KÜRESEL YÜK (TEO VE ARK. & TÜRKİYE VERİLERİ)", "20 yıl diyabet süresinde Tip 1 DM'nin >%90'ında, Tip 2 DM'nin ~%60'ında DR gelişir; küresel DR yükü >103 milyon erişkindir.", "green"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 1. PATOGENEZ VE KAN-RETİNA BARİYERİ ŞEMASI
# ==============================================================================
def generate_dr_schema_1_pathogenesis(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 2.1 — Diyabetik Nörovasküler Ünite Hasarı, 4 Biyokimyasal Yolak ve KRB Yıkımı",
        "Kronik hiperglisemiden perisit apoptozu (Ang-2/Tie-2), lökostaz, VEGF-A165 ve Müller hücresi (AQP4/Kir4.1) ödemine geçiş",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    draw.rounded_rectangle([(195, 114), (615, 162)], radius=8, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((225, 123), "KRONİK HİPERGLİSEMİ + MİTOKONDRİYAL ROS", font=f_b, fill=PALETTE["red"])
    draw.text((238, 143), "PARP Aktivasyonu -> GAPDH İnhibisyonu -> 4 Yolak Akışı ↑", font=f_s, fill=PALETTE["ink"])

    pathways = [
        ("1. Polyol Yolağı", "Aldoz redüktaz -> Sorbitol\nNADPH tükenmesi -> GSH ↓\nOsmotik perisit hasarı", "amber", 36),
        ("2. AGE - RAGE", "Non-enzimatik glikasyon\nBM çapraz bağlanması\nNF-κB & ROS aktivasyonu", "purple", 220),
        ("3. PKC-β Yolağı", "DAG artışı -> PKC-β1/2\neNOS ↓, ET-1 ↑ (vazokonst.)\nVEGF & geçirgenlik artışı", "blue", 404),
        ("4. Heksozamin", "Fruktoz-6P -> UDP-GlcNAc\nTGF-β1 & PAI-1 artışı\nKapiller bazal membran ↑", "green", 588),
    ]
    for ptitle, pdesc, ckey, px in pathways:
        fg = PALETTE[ckey]
        bg = PALETTE[f"{ckey}_bg"]
        draw.line([(405, 162), (px + 86, 192)], fill=PALETTE["muted"], width=2)
        draw.rounded_rectangle([(px, 192), (px + 174, 302)], radius=8, fill=bg, outline=fg, width=2)
        draw.text((px + 12, 202), ptitle, font=f_b, fill=fg)
        for idx, ln in enumerate(pdesc.split("\n")):
            draw.text((px + 12, 228 + idx * 21), ln, font=f_s, fill=PALETTE["ink"])

    draw.rounded_rectangle([(36, 326), (762, 470)], radius=10, fill="#ffffff", outline=PALETTE["blue"], width=2)
    draw.text((52, 336), "İÇ KAN-RETİNA BARİYERİ (İç KRB), ANG-2/TIE-2 VE MİKROVASKÜLER YIKIM", font=f_b, fill=PALETTE["blue"])
    draw.rounded_rectangle([(56, 368), (742, 418)], radius=16, fill="#fee2e2", outline=PALETTE["red"], width=2)
    draw.text((68, 384), "Kapiller Lümen: ICAM-1 + CD11/18 Lökostaz -> Fas/FasL Endotel Apoptozu -> Asellüler Kapiller", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((56, 428), "• Perisit Apoptozu (1:1 oran bozulur; Ang-2 ↑ -> Tie-2 inaktivasyonu, PDGF-β ↓) -> Mikroanevrizma", font=f_s, fill=PALETTE["ink"])
    draw.text((56, 448), "• Erken Retinal Nörodejenerasyon: Ganglion/amakrin apoptozu ve RNFL/GCL incelmesi vaskülopatiden önce başlar!", font=f_s, fill=PALETTE["purple"])

    draw.rounded_rectangle([(36, 484), (762, 586)], radius=10, fill=PALETTE["green_bg"], outline=PALETTE["green"], width=2)
    draw.text((52, 494), "DMÖ OLUŞUMU: VASKÜLER SIZINTI + GLİAL POMPA İFLASI (Starling Yasası)", font=f_b, fill=PALETTE["green"])
    draw.text((52, 520), "• Okludin / Klaudin-5 / ZO-1 fosforilasyonu (VEGF-A165, PlGF & IL-6/MCP-1) -> İç KRB yıkımı (Kist)", font=f_s, fill=PALETTE["ink"])
    draw.text((52, 543), "• Müller Hücresi Kir4.1 ↓ ve AQP4 dislokasyonu -> İntrasellüler şişme + RPE dış KRB yıkımı -> Seröz MD", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("ADIM 1: Nörovasküler Ünite (NVÜ) Bozulması", "Klinik mikroanevrizmadan önce nöronal apoptoz, mikroglial aktivasyon, Müller GFAP artışı ve glutamat eksitotoksisitesi başlar.", "blue"),
        ("ADIM 2: Ang-2/Tie-2 Dengesizliği & Lökostaz", "Hipokside endotelden salınan Ang-2, Tie-2 reseptörünü bloke ederek perisit ayrılmasını ve VEGF duyarlılığını katlar.", "red"),
        ("ADIM 3: VEGF-A165, PlGF ve Sitokin Fırtınası", "VEGF-A165 VEGFR-2 üzerinden sıkı bağlantıları çözer ve endositozu artırır; kronik DMÖ'de IL-6, IL-1β ve MCP-1 baskınlaşır.", "amber"),
        ("ADIM 4: Starling Dengesi ve Müller Ödemi", "Hidrostatik basınç artışı ve doku onkotik yükü (lipoprotein sert eksüda) sıvıyı dış pleksiform (Henle) ve İNT'de biriktirir.", "green"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 2. MULTİMODAL GÖRÜNTÜLEME: YAPISAL OKT & OKTA ŞEMASI
# ==============================================================================
def generate_dr_schema_2_oct_octa(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 4.1 — Yapısal OKT Biyobelirteçleri, UWFA (Protokol AA) ve OKTA Pleksus Analizi",
        "Otani DMÖ paternleri, DRIL (>1 mm), HRF, ELM/EZ bütünlüğü, kistoid dejenerasyon ve SD-OKTA vs SS-OKTA akım fiziği",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    draw.rounded_rectangle([(34, 112), (768, 415)], radius=10, fill="#0f172a", outline=PALETTE["blue"], width=2)
    draw.text((52, 124), "YAPISAL OKT KESİTİ: PROGNOSTİK BİYOBELİRTEÇ HARİTASI", font=f_b, fill="#93c5fd")

    draw.arc([(65, 145), (735, 225)], start=15, end=165, fill="#f59e0b", width=3)
    draw.text((275, 152), "Kalın Arka Hiyaloid / VMT & ERM", font=f_s, fill="#fde68a")

    draw.rectangle([(60, 210), (390, 265)], fill="#334155", outline="#ef4444", width=2)
    draw.text((74, 222), "DRIL (>1 mm / >%50 Foveal Alan)", font=get_font(12, bold=True), fill="#fca5a5")
    draw.text((74, 242), "GHT-İPT-İNT sınırları silinmiş -> Kötü GK!", font=f_s, fill="#e2e8f0")

    draw.line([(405, 228), (740, 228)], fill="#64748b", width=2)
    draw.line([(405, 252), (740, 252)], fill="#64748b", width=2)
    draw.text((425, 212), "Korunmuş İç Retina Sınırları", font=f_s, fill="#cbd5e1")

    for cx, cy, rx, ry in [(240, 305, 42, 28), (335, 302, 52, 32), (435, 306, 38, 26)]:
        draw.ellipse([(cx - rx, cy - ry), (cx + rx, cy + ry)], fill="#020617", outline="#38bdf8", width=2)
    draw.text((255, 296), "KMÖ Kistleri (DPT/İNT)", font=f_s, fill="#7dd3fc")

    for hx, hy in [(520, 278), (542, 292), (565, 274), (585, 300), (550, 312)]:
        draw.ellipse([(hx - 3, hy - 3), (hx + 3, hy + 3)], fill="#ffffff")
    draw.text((508, 322), "HRF (<30 µm, gölgesiz)", font=get_font(11, bold=True), fill="#fde047")

    draw.polygon([(645, 276), (685, 276), (692, 294), (638, 294)], fill="#facc15")
    draw.rectangle([(642, 295), (688, 398)], fill="#020617")
    draw.text((602, 258), "Sert Eksüda (>30 µm)", font=get_font(11, bold=True), fill="#facc15")

    draw.polygon([(265, 360), (430, 360), (395, 342), (300, 342)], fill="#020617", outline="#34d399", width=2)
    draw.text((275, 345), "Seröz MD (%15-30)", font=get_font(11, bold=True), fill="#6ee7b7")
    draw.line([(60, 362), (250, 362)], fill="#22c55e", width=2)
    draw.line([(445, 362), (635, 362)], fill="#22c55e", width=2)
    draw.line([(60, 376), (638, 376)], fill="#f97316", width=4)
    draw.line([(688, 376), (740, 376)], fill="#f97316", width=4)
    draw.text((66, 384), "ELM & EZ (IS/OS) + RPE Bandı (Sert eksüda arkasında gölgelenme - PED değildir!)", font=get_font(11, bold=False), fill="#fed7aa")

    draw.rounded_rectangle([(34, 430), (768, 586)], radius=10, fill=PALETTE["blue_bg"], outline=PALETTE["blue"], width=2)
    draw.text((50, 442), "OKTA PLEKSUS VE CİHAZ FİZİĞİ KARŞILAŞTIRMASI", font=f_b, fill=PALETTE["blue"])
    draw.text((50, 468), "• SD-OKTA (840 nm, 70k A-scan/sn): Yavaş/türbülan akımlı mikroanevrizmaların yalnızca ~%62'sini saptar.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 491), "• SS-OKTA (1050 nm, ≥100k A-scan/sn): Geniş açılı montajda NVE/nonperfüzyon ve derin koryokapillariste üstün.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 514), "• Derin Kapiller Pleksus (DCP): İskemi, mikroanevrizma ve FAZ genişlemesi DCP'de SCP'den DAHA ERKEN başlar!", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((50, 539), "• UWFA (Protokol AA): Periferik ağırlıklı lezyonlar (PPL) ve periferik nonperfüzyon ≥2 basamak DR artışını öngörür.", font=f_s, fill=PALETTE["purple"])

    steps = [
        ("FA vs OKTA KLİNİK ROL AYRIMI", "OKTA boyasız 3B katman (SCP vs DCP) perfüzyonunu gösterir ancak SIZINTIYI göstermez; sızıntı için FA/UWFA gerekir.", "blue"),
        ("DRIL VE DIŞ RETİNA (ELM/EZ) PROGNOZU", "Tedaviyle MFK tamamen incelse bile santral 1 mm'de >%50 DRIL veya ELM/EZ kopukluğu varsa görsel kazanç sınırlı kalır.", "red"),
        ("KİSTOİD ÖDEM vs KİSTOİD DEJENERASYON", "Normal/ince foveada köşeli kaviteler, FA'da sızıntı yokluğu ve Müller nekrozu dejenerasyonu gösterir; anti-VEGF faydasızdır.", "amber"),
        ("İNFLAMATUVAR OKT FENOTİPİ (SMD + HRF)", "Subfoveal seröz dekolman ve çok sayıda hiperreflektif odak (>20 HRF) yüksek IL-6/mikroglial aktivasyonu ve steroid yanıtını işaret eder.", "green"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 3. 2026 KANITA DAYALI DMÖ & DR TEDAVİ ALGORİTMASI ŞEMASI
# ==============================================================================
def generate_dr_schema_3_dmo_algorithm(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 5.1 — 2026 Kanıta Dayalı DMÖ ve DR Tedavi Algoritması (Protokol V, T, AC, W ve S)",
        "Merkezi tutulum, başlangıç EİGK eşikleri (≥20/25 Gözlem; 20/32-20/40; ≤20/50) ve basamaklı (Step-Therapy) yönetim",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    draw.rounded_rectangle([(205, 112), (595, 158)], radius=8, fill=PALETTE["blue"], outline=PALETTE["blue"], width=2)
    draw.text((232, 127), "OKT + MUAYENE: MERKEZİ TUTULUM ANALİZİ", font=f_b, fill="#ffffff")

    draw.line([(310, 158), (195, 188)], fill=PALETTE["muted"], width=2)
    draw.line([(490, 158), (585, 188)], fill=PALETTE["muted"], width=2)

    # Sol Kutu: Merkezi Tutmayan DMÖ & Protokol W
    draw.rounded_rectangle([(34, 188), (355, 312)], radius=8, fill=PALETTE["green_bg"], outline=PALETTE["green"], width=2)
    draw.text((48, 198), "Merkezi Tutmayan DMÖ (Santral 1 mm Dışı)", font=get_font(13, bold=True), fill=PALETTE["green"])
    draw.text((48, 222), "• Yakın gözlem veya sızdıran odaklara fokal", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 241), "   / 577 nm subliminal mikropulse lazer.", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 263), "• Orta-Ağır NPDR (DMÖ yok, Protokol W):", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((48, 282), "  Profilaktik anti-VEGF 4 yılda GK ek farkı", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 298), "  yaratmaz -> Yakın takip esastır!", font=f_s, fill=PALETTE["ink"])

    # Sağ Kutu: Merkezi Tutan DMÖ (3 EİGK Basamağı: Protokol V + T + AC!)
    draw.rounded_rectangle([(375, 188), (770, 312)], radius=8, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((389, 198), "Merkezi Tutan DMÖ (Santral 1 mm Kalın)", font=get_font(13, bold=True), fill=PALETTE["red"])
    draw.text((389, 222), "1) EİGK ≥20/25 (≥79 Harf — Protokol V):", font=get_font(12, bold=True), fill=PALETTE["blue"])
    draw.text((389, 241), "   Başlangıç GÖZLEM güvenli; GK ≥5 harf düşerse ilaç!", font=f_s, fill=PALETTE["ink"])
    draw.text((389, 261), "2) EİGK 20/32–20/40 (69–78 Harf — Protokol T):", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((389, 280), "   Ranibizumab = Aflibercept = Bevacizumab EŞDEĞER.", font=f_s, fill=PALETTE["ink"])
    draw.text((389, 297), "3) EİGK ≤20/50 (<69 Harf): 1. yılda Aflibercept üstün!", font=get_font(12, bold=True), fill=PALETTE["red"])

    # Orta Kutu: Protokol AC & Uzun Aralıklı Ajanlar
    draw.rounded_rectangle([(34, 328), (770, 444)], radius=8, fill=PALETTE["purple_bg"], outline=PALETTE["purple"], width=2)
    draw.text((50, 338), "PROTOKOL AC (STEP-THERAPY) & UZATILMIŞ ARALIKLI TEDAVİ (T&E / q12w–q16w)", font=f_b, fill=PALETTE["purple"])
    draw.text((50, 364), "• Protokol AC (NEJM 2022, GK 20/50–20/320): Önce Bevacizumab başlanıp yanıtsızlıkta (~%70 olgu) Aflibercept'e", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 384), "  geçilmesi, 2 yıllık görsel sonuçta doğrudan Aflibercept monoterapisinden aşağı değildir (maliyet-etkin strateji).", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 406), "• Yükleme Sonrası Uzatma: Faricimab 6 mg (Ang-2/VEGF-A, YOSEMITE/RHINE) ve Aflibercept 8 mg (PHOTON)", font=get_font(12, bold=True), fill=PALETTE["purple"])
    draw.text((50, 425), "  ile hastaların %60-80'inde 12-16 haftalık (q12w-q16w) enjeksiyon aralıklarına güvenli çıkış sağlanır.", font=f_s, fill=PALETTE["ink"])

    # Alt Kutu: PDR ve Cerrahi Entegrasyonu
    draw.rounded_rectangle([(34, 460), (770, 586)], radius=8, fill=PALETTE["amber_bg"], outline=PALETTE["amber"], width=2)
    draw.text((50, 470), "EŞLİK EDEN PDR (PROTOKOL S 5-YIL) VE VİTREOMAKÜLER ARAYÜZ KARARI", font=f_b, fill=PALETTE["amber"])
    draw.text((50, 496), "• Protokol S (5 Yıl): Anti-VEGF ile periferik görme alanı korunur ve yeni DMÖ/TRD azalır; ANCAK takip uyumsuzluğu", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 517), "  riski olan hastada kalıcı Panretinal Fotokoagülasyon (PRP) geri dönüşsüz ağır görme kaybına karşı daha güvenlidir!", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((50, 540), "• OKT'de Belirgin VMT / Traksiyonel ERM varsa: Anti-VEGF tek başına yetmez -> Erken PPV + Membran Soyulması.", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("PROTOKOL V DEVRİMİ (İYİ GÖRME ≥20/25)", "Merkezi tutan DMÖ olsa bile EİGK ≥20/25 ise 2 yılda başlangıç gözlem, lazer ve aflibercept arasında görme farkı yoktur (~%66'sı enjeksiyonsuz kalır).", "blue"),
        ("PROTOKOL I & T 5 YILLIK UZUN DÖNEM DERSİ", "İlk yıldaki 8-9 enjeksiyon yükü 4-5. yıllarda 1-3'e düşer; ancak 2-5. yıllar arasında rutin pratikte gevşeme olursa kazanılan harflerin bir kısmı yitirilir.", "green"),
        ("SİSTEMİK VE OKÜLER GÜVENLİK KONTROLÜ", "Povidon-iyot (%5) antisepsisi endoftalmiyi (~1/2000) önlemede tek kanıtlı adımdır; yakın MI/inme öyküsünde yoğun anti-VEGF'ten kaçınılır.", "red"),
        ("3-6 ENJEKSİYON SONRASI YANIT DEĞERLENDİRMESİ", "MFK azalması <%10-20 veya <5 harf kazançta erken anti-VEGF içi değişim veya psödofak/KV yüksek riskli gözde Deksametazon 0.7 mg Switch düşünülür.", "purple"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 4. EŞİK ALTI VE SUBLİMİNAL MİKROPULSE LAZER FİZİĞİ ŞEMASI
# ==============================================================================
def generate_dr_schema_4_subliminal_laser(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 7.1 — Konvansiyonel Lazer, Endpoint Management (%30) ve 577 nm Subliminal Mikropulse",
        "%5 görev döngüsü (100 µs açık / 1900 µs kapalı) ile fotoreseptör yıkımı olmadan RPE'de HSP70 biyomodülasyonu (DIAMOND RKÇ)",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    modes = [
        ("1. Konvansiyonel CW Lazer (ETDRS)", 114, PALETTE["red"], PALETTE["red_bg"], "Sürekli 100-200 ms darbe -> Termal koagülasyon nekrozu, dış retina yıkımı ve yıllık %16 skar genişlemesi.", "continuous"),
        ("2. PASCAL Endpoint Mgmt (NRT %30)", 272, PALETTE["amber"], PALETTE["amber_bg"], "Kısa darbe (15 ms), eşik enerjinin %30'u; görünür referans yanık + aralıklı ızgara (0.25-0.5 spot boşluk).", "nrt"),
        ("3. 577 nm Subliminal Mikropulse (%5 DC)", 430, PALETTE["green"], PALETTE["green_bg"], "100 µs AÇIK + 1900 µs KAPALI soğuma; sıfır skar, sıfır boşluklu konfluent tarama ve HSP70 uyarımı.", "micropulse"),
    ]
    for mtitle, my, fg, bg, mdesc, mtype in modes:
        draw.rounded_rectangle([(34, my), (768, my + 144)], radius=10, fill=bg, outline=fg, width=2)
        draw.text((50, my + 10), mtitle, font=f_b, fill=fg)
        wx0, wy0, ww, wh = 54, my + 40, 310, 56
        draw.rectangle([(wx0, wy0), (wx0 + ww, wy0 + wh)], fill="#ffffff", outline=PALETTE["line"])
        if mtype == "continuous":
            draw.rectangle([(wx0 + 25, wy0 + 8), (wx0 + 275, wy0 + wh - 4)], fill=fg)
        elif mtype == "nrt":
            draw.rectangle([(wx0 + 35, wy0 + 32), (wx0 + 135, wy0 + wh - 4)], fill=fg)
            draw.line([(wx0 + 10, wy0 + 12), (wx0 + 295, wy0 + 12)], fill=PALETTE["red"], width=1)
            draw.text((wx0 + 150, wy0 + 22), "%30 Enerji", font=get_font(11, bold=True), fill=fg)
        else:
            draw.text((wx0 + 62, wy0 + 5), "%5 Görev Döngüsü (100/1900 µs)", font=get_font(11, bold=True), fill=fg)
            for px in range(wx0 + 18, wx0 + 290, 22):
                draw.rectangle([(px, wy0 + 24), (px + 4, wy0 + wh - 4)], fill=fg)
        draw_wrapped_text(draw, mdesc, 382, my + 38, 370, f_s, PALETTE["ink"], line_h=19, max_lines=4)

    steps = [
        ("NEDEN 577 nm SARI DALGA BOYU?", "Maküler ksantofil pigmenti 577 nm'yi neredeyse hiç emmez (fovea güvenliği); melanin ve oksihemoglobin pikinde seçici tutulur.", "amber"),
        ("HSP70 VE MÜLLER BİYOMODÜLASYONU", "Subletal termal stres RPE'yi öldürmeden Isı Şok Proteini-70'i (HSP70) uyarır; VEGF azalır, PEDF artar ve Müller GFAP baskılanır.", "green"),
        ("DIAMOND RKÇ (OPHTHALMOLOGY 2023)", "MFK <400 µm olan merkezi DMÖ'de 577 nm eşik altı mikropulse lazer, standart maküler lazere görsel olarak eşdeğer ve doku koruyucudur.", "blue"),
        ("KRİTİK 400 MİKRON KURALI!", "MFK >400 µm ağır ödemde tek başına mikropulse lazer yetersizdir; önce anti-VEGF ile kalınlık ≤350-400 µm'ye indirilmelidir.", "red"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 5. DİYABETİK VİH & TRD CERRAHİ BİYOMEKANİĞİ ŞEMASI
# ==============================================================================
def generate_dr_schema_5_trd_surgery(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 8.1 — Diyabetik VİH (Protokol AB) ve TRD Cerrahi Biyomekaniği",
        "Preoperatif anti-VEGF (<3-7 gün Crunch kuralı), 200x membran direnci ve 25G/27G eğimli uç (beveled-tip) delaminasyon",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    draw.rounded_rectangle([(34, 112), (394, 445)], radius=10, fill="#ffffff", outline=PALETTE["blue"], width=2)
    draw.text((50, 124), "A) SEGMENTASYON (Dikey Kesim)", font=f_b, fill=PALETTE["blue"])
    draw.arc([(58, 220), (366, 420)], start=200, end=340, fill=PALETTE["amber"], width=6)
    draw.polygon([(145, 285), (175, 240), (205, 285)], fill="#fee2e2", outline=PALETTE["amber"], width=2)
    draw.polygon([(225, 285), (255, 240), (285, 285)], fill="#fee2e2", outline=PALETTE["amber"], width=2)
    draw.line([(120, 240), (310, 240)], fill=PALETTE["red"], width=5)
    draw.line([(215, 165), (215, 255)], fill=PALETTE["blue"], width=5)
    draw.text((155, 148), "Dikey Makas / 27G Kesici", font=f_s, fill=PALETTE["blue"])
    draw.text((52, 345), "• Teğetsel traksiyon köprülerini izole adacıklara", font=f_s, fill=PALETTE["ink"])
    draw.text((52, 367), "  ayırır; sıkı vasküler episantr odaklarında", font=f_s, fill=PALETTE["ink"])
    draw.text((52, 389), "  iyatrojenik yırtık riskini en aza indirir.", font=f_s, fill=PALETTE["ink"])

    draw.rounded_rectangle([(408, 112), (768, 445)], radius=10, fill="#ffffff", outline=PALETTE["green"], width=2)
    draw.text((424, 124), "B) DELAMİNASYON (En Bloc Yatay)", font=f_b, fill=PALETTE["green"])
    draw.arc([(432, 220), (740, 420)], start=200, end=340, fill=PALETTE["amber"], width=6)
    draw.line([(480, 232), (690, 222)], fill=PALETTE["red"], width=5)
    draw.line([(545, 228), (545, 262)], fill=PALETTE["red"], width=3)
    draw.line([(625, 225), (625, 260)], fill=PALETTE["red"], width=3)
    draw.line([(680, 248), (560, 245)], fill=PALETTE["green"], width=5)
    draw.text((462, 195), "Bimanuel Chandelier + Beveled 27G / iOCT", font=f_s, fill=PALETTE["green"])
    draw.text((424, 345), "• Retina-membran klivaj planından fibrovasküler", font=f_s, fill=PALETTE["ink"])
    draw.text((424, 367), "  besleyici kökler yatay düzlemde kesilir.", font=f_s, fill=PALETTE["ink"])
    draw.text((424, 389), "• İntraoperatif OKT (iOCT) gizli planı gösterir.", font=f_s, fill=PALETTE["ink"])

    draw.rounded_rectangle([(34, 460), (768, 586)], radius=10, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((50, 472), "KRİTİK CERRAHİ BİYOMEKANİK VE ZAMANLAMA KURALLARI", font=f_b, fill=PALETTE["red"])
    draw.text((50, 500), "• Preop Anti-VEGF (3–7 Gün Penceresi): >10 gün gecikirse anjiyo-fibrotik dönüşüm ('Crunch') TRD'yi kombine", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 522), "  traksiyonel + regmatojen (TRD+RRD) dekolmana çevirir! Ameliyat 3-7 gün (kesinlikle <10 gün) içinde yapılmalıdır.", font=f_s, fill=PALETTE["red"])
    draw.text((50, 548), "• 200x Direnç Yasası: Fibrovasküler membran çekme direnci iskemik retinadan 200 kat güçlüdür; ASLA soyarak çekilmez!", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("DRCR.NET PROTOKOL AB (JAMA 2020 — VİH)", "PDR kaynaklı VİH'te başlangıç aflibercept ile erken PPV+PRP arasında 24 haftalık ortalama GK eğri altı alanında anlamlı fark yoktur; ancak PPV kanamayı daha hızlı temizler ve TRD/rekürren VİH'i azaltır.", "blue"),
        ("VİTREKTOMİZE GÖZDE İLAÇ KLİRENSİ GERÇEĞİ", "Triamsinolon klirensi vitrektomize gözde ~1.5x hızlanırken, Deksametazon 0.7 mg implant (CHAMPLAIN) klirensi değişmez!", "amber"),
        ("25G/27G EĞİMLİ UÇ (BEVELED-TIP) & 10-20K CPM", "Yüksek kesim hızı ve retina yüzeyine yakın kesici port açıklığı vitreoretinal traksiyonu azaltarak tek aletle diseksiyon sağlar.", "green"),
        ("REKÜRREN VİH VE TAMPONAD YÖNETİMİ", "Post-PPV kanamanın başlıca nedeni sklerotomi fibrovasküler içe büyümesi ve rezidüel ön hiyaloiddir; kombine TRD-RRD'de C3F8/silikon kullanılır.", "purple"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 6. BÖLÜM 6 ŞEMASI: STEROİD FARMAKOKİNETİK PARADOKSU VE SWITCH ALGORİTMASI
# ==============================================================================
def generate_dr_schema_6_steroid_switch(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 6.1 — İntravitreal Kortikosteroid Farmakokinetik Paradoksu ve Erken Switch Algoritması",
        "DEX vs TA vs Fluosinolon reseptör afinitesi / lipofilisite ters orantısı, Ozurdex/Iluvien kinetiği ve mutlak kontrendikasyonlar",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    # Sol Üst: Farmakokinetik Paradoks Çubuk Karşılaştırması
    draw.rounded_rectangle([(34, 112), (770, 294)], radius=10, fill="#ffffff", outline=PALETTE["purple"], width=2)
    draw.text((50, 122), "A) FARMAKOKİNETİK PARADOKS: POTENS vs SERBEST SÜSPANSİYON YARI ÖMRÜ", font=f_b, fill=PALETTE["purple"])

    agents = [
        ("Deksametazon (DEX 0.7 mg PLGA)", 320, 95, "Potens: 5x (En Yüksek) | Suda çözünür (t1/2 ~3.5-5.5 saat) -> PLGA İmplant ŞART (3-6 ay)", PALETTE["blue"]),
        ("Fluosinolon Asetonid (FA 0.19 mg)", 230, 210, "Potens: Orta-Yüksek | Non-biyobozunur poliimid mikro-tüp (0.2 µg/gün -> 36 AY salınım)", PALETTE["green"]),
        ("Triamsinolon Asetonid (TA 1-4 mg)", 140, 315, "Potens: Düşük (1x) | Lipofilik kristal süspansiyon -> Vitreusta doğal depo (~18.6 gün; vitrektomizede 3.2 gün)", PALETTE["amber"]),
    ]
    ay = 152
    for name, aff_w, lip_w, note, col in agents:
        draw.text((50, ay), name, font=get_font(12, bold=True), fill=col)
        draw.rectangle([(300, ay + 2), (300 + aff_w, ay + 16)], fill=col)
        draw.text((632, ay + 1), "GR Afinite", font=get_font(11, bold=False), fill=PALETTE["muted"])
        draw.text((50, ay + 20), note, font=get_font(11, bold=False), fill=PALETTE["ink"])
        ay += 44

    # Sol Orta: İnflamatuvar OKT Biyobelirteç Temelli Erken Switch Kutusu
    draw.rounded_rectangle([(34, 308), (770, 444)], radius=10, fill=PALETTE["green_bg"], outline=PALETTE["green"], width=2)
    draw.text((50, 318), "B) ANTİ-VEGF DİRENCİ VE İNFLAMATUVAR FENOTİPTE ERKEN SWITCH KARARI", font=f_b, fill=PALETTE["green"])
    draw.text((50, 344), "• Persistan DMÖ Tanımı: 3–6 ardışık anti-VEGF yüklemesi sonrası MFK azalması <%10-20 (veya MFK >300 µm) + <5 harf artış.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 366), "• OKT 'Steroid-Duyarlı İnflamatuvar Dörtlü': 1) Subfoveal Seröz MD, 2) Yoğun HRF (>20), 3) Dev Foveal Kist (>200 µm),", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((50, 388), "  4) Kronik DMÖ (≥3 yıl — FAME çalışmasında FA 0.19 mg ile ≥15 harf kazancı %34.0 vs sham %13.4, p<0.001!).", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 411), "• Protokol U: Ranibizumaba DEX eklenmesi MFK'yi anlamlı kurutur; görsel üstünlük özellikle PSÖDOFAK gözlerde belirgindir.", font=f_s, fill=PALETTE["ink"])

    # Sol Alt: Mutlak Kontrendikasyon Kırmızı Kutu
    draw.rounded_rectangle([(34, 458), (770, 586)], radius=10, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((50, 468), "C) OZURDEX / İMPLANT MUTLAK KONTRENDİKASYONLARI (ÖN KAMARA MİGRASYONU!)", font=f_b, fill=PALETTE["red"])
    draw.text((50, 495), "• Yırtık Arka Kapsül, Afaki, Zonül Diyalizi, Ön Kamara GİL veya İris/Skleral Fiksasyonlu GİL (Bariyer Yoksa):", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((50, 517), "  PLGA çubuk ön kamaraya geçerek geri dönüşsüz KORNEA ENDOTEL YETMEZLİĞİ ve büllöz keratopati yapar (Acil çıkarılmalı!).", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 541), "• Diğer Kontrendikasyonlar: İleri/kontrolsüz glokom, steroid yanıtçısı öyküsü, aktif oküler/perioküler enfeksiyon (HSV/tokso).", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("MEAD, BEVORDEX VE CHAMPLAIN KANITLARI", "MEAD: Fakik gözde %67.9 katarakt, çoğunluğu topikal damlayla kontrol edilen GİB artışı. CHAMPLAIN: Vitrektomize gözde tam etkinlik!", "purple"),
        ("İLK TERCİH STEROİD ENDİKASYONLARI", "1) Son 3-6 ayda MI/inme (yüksek KV tromboembolik risk), 2) Psödofak + vitrektomize göz, 3) Sık aylık enjeksiyona gelemeyecek hasta.", "blue"),
        ("TAŞİFLAKSİ vs TOLERANS vs GERÇEK DİRENÇ", "Taşiflaksi hızlı gelişen reseptör duyarsızlaşmasıdır (ilaç tatili/switch ile açılır); kronik ödemde ise VEGF'den IL-6/MCP-1'e kayış vardır.", "amber"),
        ("PALADIN & FAME GÜVENLİK KURALI", "Iluvien (36 ay) öncesi daha kısa etkili steroidle (DEX/TA) 'steroid GİB provokasyon testi' yapılması cerrahi glokom riskini azaltır.", "green"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 7. BÖLÜM 7 İKİNCİ ŞEMA: YENİ NESİL BİYOLOJİKLER VE REZERVUAR SİSTEMLERİ (2022-2026)
# ==============================================================================
def generate_dr_schema_7_nextgen_2026(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 7.2 — Yeni Nesil DMÖ & DR Tedavileri (2022–2026): Çift Hedefli Antikorlar ve Yüksek Molar Doz",
        "Faricimab (Ang-2/VEGF-A Bispesifik), Aflibercept 8 mg (PHOTON), PDS Susvimo ve Brolucizumab / Abicipar Güvenlik Dersleri",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    cards = [
        (
            "1. FARİCİMAB 6.0 mg (Vabysmo) — YOSEMITE, RHINE & RHONE-X (4 Yıl)",
            "• CrossMAb teknolojili ilk BİSPESİFİK IgG1 antikoru: Bir kol VEGF-A'yı, diğer kol Anjiyopoietin-2'yi (Ang-2) bağlar; modifiye Fc (FcRn/FcγR sessiz) sistemik yarı ömrü ve kompleman inflamasyonunu azaltır.\n• Tie-2 reseptör aktivasyonunu koruyarak perisit-endotel stabilitesini onarır; hastaların ~%60'ı q16w, ~%78-80'i ≥q12w aralığa ulaşır.",
            "green",
            112,
        ),
        (
            "2. YÜKSEK DOZ AFLİBERCEPT 8.0 mg (Eylea HD) — PHOTON Faz 2/3 (96 Hafta)",
            "• Standart 2 mg'ın 4 katı molar doz (115 kDa VEGFR1/2 tuzak protein) -> Vitreus içi etkin konsantrasyon süresini uzatır.\n• 3 aylık yükleme sonrası 12 (8q12) ve 16 haftalık (8q16) rejimler, 2q8 rejimiyle eşdeğer görme kazancı ve güçlü sıvı kontrolü sağlar.",
            "blue",
            274,
        ),
        (
            "3. PDS RANİBİZUMAB (Susvimo 100 mg/mL) & BROLUCİZUMAB / ABİCİPAR UYARISI",
            "• PAGODA (DMÖ) & PAVILION (DR): Skleraya implante yeniden doldurulabilir rezervuar ile 24-36 haftada bir dolum; endoftalmi/septum takibi şart!\n• KESTREL/KITE (Brolucizumab 6 mg, 26 kDa): Güçlü kurutma ancak İOİ ve OKÜLÜZİF RETİNAL VASKÜLİT riski! Abicipar pegol (DARPin) ise yüksek İOİ nedeniyle 2020'de FDA onayı alamamıştır.",
            "red",
            422,
        ),
    ]
    for ctitle, cbody, ckey, cy in cards:
        fg = PALETTE[ckey]
        bg = PALETTE[f"{ckey}_bg"]
        bh = 152 if ckey != "blue" else 136
        if ckey == "red":
            bh = 164
        draw.rounded_rectangle([(34, cy), (772, cy + bh)], radius=10, fill=bg, outline=fg, width=2)
        draw.text((48, cy + 10), ctitle, font=get_font(13, bold=True), fill=fg)
        ly = cy + 34
        for para in cbody.split("\n"):
            ly = draw_wrapped_text(draw, para, 48, ly, 710, f_s, PALETTE["ink"], line_h=18, max_lines=4) + 3

    steps = [
        ("2018'DEN 2026'YA PARADİGMA DEĞİŞİMİ", "2018'de Faz 2 aşamasında olan Ang-2/Tie-2 (Faricimab), yüksek molar doz (Aflibercept 8 mg) ve PDS rezervuarı artık Faz 3 RKÇ'lerle klinik standart olmuştur.", "green"),
        ("NEDEN ANG-2 + VEGF-A İKİLİ BLOKAJI?", "Tek başına anti-VEGF sızıntıyı keser ancak Ang-2 yüksek kaldığında Tie-2 kapalı kalır; Faricimab Tie-2'yi serbest bırakarak damar duvarını stabilize eder.", "blue"),
        ("OKÜLER İNFLAMASYON (İOİ) VE VASKÜLİT DERSİ", "Küçük moleküllü yüksek molar yoğunluklu ajanlarda (brolucizumab, abicipar) anti-ilaç antikorları tip III/IV aşırı duyarlılıkla tıkayıcı retinal vaskülit yapabilir.", "red"),
        ("GEN TEDAVİSİ VE YENİ MOLEKÜLER UFUKLAR", "AAV vektörlü anti-VEGF gen tedavisi (ABBV-RGX-314 / ixoberogene soroparvovec), plazma kallikrein, Senolitik (UBX1325) ve konneksin-43 / NLRP3 inhibitörleri erken klinik fazdadır.", "purple"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# 8. BÖLÜM 9 ŞEMASI: HASTA DÜZEYİ vs GÖZ DÜZEYİ ANALİZ BİRİMİ (ICC / GEE / KARMA MODEL)
# ==============================================================================
def generate_dr_schema_8_biostat_gee(output_path: Path):
    im, draw = create_base_canvas(
        "ŞEKİL 9.1 — Oftalmolojik Araştırmalarda Analiz Birimi: Hasta Düzeyi vs Göz Düzeyi (ICC, GEE ve Karma Model)",
        "Bilateral diyabetik göz verisinde sınıf içi korelasyon (ICC), yalancı örneklem şişmesi (Tip I hata) ve doğru SPSS model seçimi",
    )
    f_b = get_font(14, bold=True)
    f_s = get_font(12, bold=False)

    # Sol Üst: Yanlış Yaklaşım (Naif Bağımsız Göz Analizi)
    draw.rounded_rectangle([(34, 112), (770, 266)], radius=10, fill=PALETTE["red_bg"], outline=PALETTE["red"], width=2)
    draw.text((50, 122), "YANLIŞ YAKLAŞIM: 50 HASTANIN 100 GÖZÜNÜ 'N=100 BAĞIMSIZ HASTA' SAYMAK!", font=f_b, fill=PALETTE["red"])
    draw.text((50, 150), "• Biyolojik Gerçek: Aynı hastanın Sağ (OD) ve Sol (OS) gözü ortak HbA1c, kan basıncı, eGFR, diyabet süresi ve", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 171), "  VEGFA/ALR2 genotipini paylaşır -> Sınıf İçi Korelasyon (ICC = σ²_hasta / [σ²_hasta + σ²_hata]) genellikle 0.40 – 0.75!", font=get_font(12, bold=True), fill=PALETTE["red"])
    draw.text((50, 196), "• İstatistiksel Hata: Standart Bağımsız t-Testi / Mann-Whitney / Ki-Kare uygulandığında efektif örneklem boyutu", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 217), "  N_eff = 2N / (1 + ICC) olmasına rağmen N_göz = 2N sanılır -> Standart hata yapay küçülür, p değeri sahte anlamlı çıkar!", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 239), "  (Örn. ICC=0.60 iken gerçek bilgi 100 göz değil yalnızca 2x50 / 1.60 = 62.5 bağımsız birim eşdeğeridir!)", font=get_font(11, bold=True), fill=PALETTE["purple"])

    # Sol Orta: Tasarım Çözümü vs Model Çözümü
    draw.rounded_rectangle([(34, 280), (392, 452)], radius=10, fill=PALETTE["blue_bg"], outline=PALETTE["blue"], width=2)
    draw.text((48, 292), "ÇÖZÜM A: TASARIM DÜZEYİ (Tek Göz)", font=get_font(13, bold=True), fill=PALETTE["blue"])
    draw.text((48, 318), "• Hasta başı 1 çalışma gözü (N_göz = N_hasta)", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 340), "• Örnekler: RESTORE, RIDE/RISE,", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 360), "  VISTA/VIVID, Protokol T, YOSEMITE.", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 384), "• Eşleştirilmiş Göz (Kontralateral Kontrol):", font=get_font(12, bold=True), fill=PALETTE["blue"])
    draw.text((48, 404), "  Sağ göz ilaç vs Sol göz lazer -> Paired t-test", font=f_s, fill=PALETTE["ink"])
    draw.text((48, 424), "  veya McNemar testi (ETDRS tasarımı).", font=f_s, fill=PALETTE["ink"])

    draw.rounded_rectangle([(408, 280), (770, 452)], radius=10, fill=PALETTE["green_bg"], outline=PALETTE["green"], width=2)
    draw.text((422, 292), "ÇÖZÜM B: MODEL DÜZEYİ (Bilateral Göz)", font=get_font(13, bold=True), fill=PALETTE["green"])
    draw.text((422, 318), "• Her iki göz dahil (Uzun Format / Long Data)", font=f_s, fill=PALETTE["ink"])
    draw.text((422, 340), "• Sürekli Sonlanım (LogMAR GK, MFK µm):", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((422, 360), "  Linear Mixed Model (Random Intercept: ID)", font=f_s, fill=PALETTE["ink"])
    draw.text((422, 384), "• İkili Sonlanım (Kuruma / GİB Artışı E/H):", font=get_font(12, bold=True), fill=PALETTE["green"])
    draw.text((422, 404), "  GEE (Binary Logistic, Exchangeable matris,", font=f_s, fill=PALETTE["ink"])
    draw.text((422, 424), "  Robust Sandwich SE -> Düzeltilmiş OR).", font=f_s, fill=PALETTE["ink"])

    # Sol Alt: Görme Keskinliği Ölçek Kuralı
    draw.rounded_rectangle([(34, 466), (770, 586)], radius=10, fill=PALETTE["amber_bg"], outline=PALETTE["amber"], width=2)
    draw.text((50, 476), "GÖRME KESKİNLİĞİ ÖLÇEK TUZAĞI: ONDALIK SNELLEN ASLA DOĞRUDAN ORTALANMAZ!", font=f_b, fill=PALETTE["amber"])
    draw.text((50, 502), "• Snellen/ondalık eşel (0.1 -> 1.0) geometrik değildir; aritmetik ortalama almak ağır görme kaybını çarpıtır.", font=f_s, fill=PALETTE["ink"])
    draw.text((50, 524), "• Doğru Dönüşüm: LogMAR = -log10(Ondalık GK) veya ETDRS Harf Skoru = 85 - (50 x LogMAR) üzerinden analiz yapılır;", font=get_font(12, bold=True), fill=PALETTE["amber"])
    draw.text((50, 546), "  CF (parmak sayma) ≈ 1.9–2.0 LogMAR, HM (el hareketi) ≈ 2.3 LogMAR standart karşılıklarıyla kodlanır.", font=f_s, fill=PALETTE["ink"])

    steps = [
        ("ADIM 1: SPSS VERİ KODLAMA (LONG FORMAT)", "Her satır = 1 göz x 1 zaman noktası: Hasta_ID, Goz_Tarafi (1=OD, 2=OS), Zaman, Tedavi_Grubu, EIGK_LogMAR, MFK_um.", "blue"),
        ("ADIM 2: ICC VE KALINTI VARSAYIMI KONTROLÜ", "Boş karma modelde (Null Mixed Model) Hasta_ID rastgele kesişim varyansı ile ICC raporlanır; Q-Q grafiğiyle kalıntı normalliği doğrulanır.", "purple"),
        ("ADIM 3: SPSS MIXED MODELS & GEE MENÜ YOLU", "Sürekli: Analyze > Mixed Models > Linear (Subjects: Hasta_ID). Kategorik: Analyze > Generalized Linear Models > GEE (Exchangeable).", "green"),
        ("ADIM 4: DERGİ / APA TABLO RAPORLAMA STANDARDI", "Tablo dipnotunda N_hasta ve n_göz ayrı ayrı yazılmalı; p değerinin GEE veya LMM küme düzeltmeli olduğu açıkça belirtilmelidir.", "amber"),
    ]
    draw_steps_box(draw, steps, x=824, y_start=112, w=742, box_h=110, gap=12)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


# ==============================================================================
# GERÇEK KLİNİK GÖRÜNTÜ KOMPOZİSYON FONKSİYONLARI (2'Lİ, 3'LÜ VE 4'LÜ PANELLER)
# ==============================================================================
def _paste_fit(im: Image.Image, draw: ImageDraw.ImageDraw, p_path: Path, px: int, py: int, pw: int, ph: int, bg_hex: str = "#0f172a"):
    draw.rounded_rectangle([(px, py), (px + pw, py + ph)], radius=6, fill=bg_hex, outline=PALETTE["line"], width=1)
    if p_path.exists():
        src = Image.open(str(p_path)).convert("RGB")
        scale = min((pw - 8) / src.width, (ph - 8) / src.height)
        nw, nh = max(1, int(src.width * scale)), max(1, int(src.height * scale))
        resized = src.resize((nw, nh), Image.Resampling.LANCZOS)
        ox = px + (pw - nw) // 2
        oy = py + (ph - nh) // 2
        im.paste(resized, (ox, oy))


def compose_clinical_panel(
    left_img_path: Path,
    right_img_path: Path,
    title: str,
    subtitle: str,
    left_caption: str,
    right_caption: str,
    output_path: Path,
    left_bg: str = "#0f172a",
    right_bg: str = "#0f172a",
):
    im, draw = create_base_canvas(title, subtitle, split_x=792)
    f_cap = get_font(12, bold=True)

    panels = [
        (left_img_path, 28, 108, 754, 442, left_caption, left_bg),
        (right_img_path, 818, 108, 754, 442, right_caption, right_bg),
    ]
    for p_path, px, py, pw, ph, cap, bg_hex in panels:
        _paste_fit(im, draw, p_path, px, py, pw, ph, bg_hex=bg_hex)
        draw_wrapped_text(draw, cap, px + 6, py + ph + 8, pw - 12, f_cap, PALETTE["ink"], line_h=18, max_lines=2)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


def compose_3grid_clinical_panel(
    items: List[Tuple[Path, str, str]],
    title: str,
    subtitle: str,
    output_path: Path,
):
    im, draw = create_base_canvas(title, subtitle, single_panel=True)
    f_lbl = get_font(13, bold=True)
    f_cap = get_font(12, bold=False)

    col_w = 500
    gap = 20
    start_x = 30
    for idx, (p_path, badge, cap) in enumerate(items[:3]):
        px = start_x + idx * (col_w + gap)
        draw.rounded_rectangle([(px, 108), (px + col_w, 590)], radius=8, fill="#ffffff", outline=PALETTE["line"], width=1)
        draw.rounded_rectangle([(px, 108), (px + col_w, 138)], radius=6, fill=PALETTE["blue_bg"])
        draw.text((px + 12, 115), badge, font=f_lbl, fill=PALETTE["blue"])
        _paste_fit(im, draw, p_path, px + 10, 144, col_w - 20, 382)
        draw_wrapped_text(draw, cap, px + 12, 534, col_w - 24, f_cap, PALETTE["ink"], line_h=17, max_lines=3)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


def compose_4grid_clinical_panel(
    items: List[Tuple[Path, str, str]],
    title: str,
    subtitle: str,
    output_path: Path,
):
    im, draw = create_base_canvas(title, subtitle, single_panel=True)
    f_lbl = get_font(12, bold=True)
    f_cap = get_font(11, bold=False)

    col_w = 372
    gap = 16
    start_x = 32
    for idx, (p_path, badge, cap) in enumerate(items[:4]):
        px = start_x + idx * (col_w + gap)
        draw.rounded_rectangle([(px, 108), (px + col_w, 590)], radius=8, fill="#ffffff", outline=PALETTE["line"], width=1)
        draw.rounded_rectangle([(px, 108), (px + col_w, 136)], radius=6, fill=PALETTE["blue_bg"])
        draw.text((px + 10, 114), badge, font=f_lbl, fill=PALETTE["blue"])
        _paste_fit(im, draw, p_path, px + 8, 142, col_w - 16, 378)
        draw_wrapped_text(draw, cap, px + 10, 528, col_w - 20, f_cap, PALETTE["ink"], line_h=16, max_lines=3)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(str(output_path), "PNG")


def build_all_dr_dmo_visuals(base_dir: Path) -> Dict[str, str]:
    assets = base_dir / "assets"
    ext = base_dir / "extracted_figures" / "dr_dmo"
    db_ext = base_dir / "extracted_figures" / "dr_dmo_db"
    assets.mkdir(parents=True, exist_ok=True)
    ensure_bcsc_figures_extracted(db_ext)

    paths = {
        "schema_0_epi_metabolic": assets / "dr_schema_0_epi_metabolic.png",
        "schema_1": assets / "dr_schema_1_pathogenesis.png",
        "panel_dme_brb_oct": assets / "dr_panel_dme_brb_oct.png",
        "panel_etdrs_421_uwfa": assets / "dr_panel_etdrs_421_uwfa.png",
        "panel_hr_pdr_nvd_nve": assets / "dr_panel_hr_pdr_nvd_nve.png",
        "schema_2": assets / "dr_schema_2_oct_octa.png",
        "panel_octa_faz_dril": assets / "dr_panel_octa_faz_dril.png",
        "schema_3": assets / "dr_schema_3_dmo_algorithm.png",
        "panel_dme_ci_nci_prp": assets / "dr_panel_dme_ci_nci_prp.png",
        "schema_6_steroid_switch": assets / "dr_schema_6_steroid_switch.png",
        "panel_oct_dril_vmt": assets / "dr_panel_oct_dril_vmt.png",
        "schema_4": assets / "dr_schema_4_subliminal_laser.png",
        "schema_7_nextgen_2026": assets / "dr_schema_7_nextgen_2026.png",
        "schema_5": assets / "dr_schema_5_trd_surgery.png",
        "panel_trd_surgery_db": assets / "dr_panel_trd_surgery_db.png",
        "schema_8_biostat_gee": assets / "dr_schema_8_biostat_gee.png",
    }

    # 1. Tüm Vektörel/PIL Şemaları Üret
    generate_dr_schema_0_epi_metabolic(paths["schema_0_epi_metabolic"])
    generate_dr_schema_1_pathogenesis(paths["schema_1"])
    generate_dr_schema_2_oct_octa(paths["schema_2"])
    generate_dr_schema_3_dmo_algorithm(paths["schema_3"])
    generate_dr_schema_4_subliminal_laser(paths["schema_4"])
    generate_dr_schema_5_trd_surgery(paths["schema_5"])
    generate_dr_schema_6_steroid_switch(paths["schema_6_steroid_switch"])
    generate_dr_schema_7_nextgen_2026(paths["schema_7_nextgen_2026"])
    generate_dr_schema_8_biostat_gee(paths["schema_8_biostat_gee"])

    # 2. Gerçek Klinik Veritabanı + Kaynak Dergi Panellerini Üret
    compose_clinical_panel(
        _find_db_img(db_ext, "bcsc_p142_x26596"),
        _find_db_img(db_ext, "bcsc_p142_x26597"),
        "KLİNİK GÖRÜNTÜ 2.2 — İç KRB Yıkımı Mekanizması ve SD-OKT'de Kistoid / Seröz DMÖ",
        "Kaynak: AAO BCSC 2023-2024 Section 12: Retina and Vitreous (Chapter 5, Figure 5-11A & 5-11B)",
        "Sol: Mikroanevrizma duvarından sıvı/lipoprotein ekstravazasyonu, intraretinal ödem ve RPE pompa yönü.",
        "Sağ: SD-OKT B-kesitinde dev foveal kistoid boşluklar, subfoveal seröz dekolman ve hiperreflektif eksüda odakları.",
        paths["panel_dme_brb_oct"],
        left_bg="#fffbeb",
    )

    compose_4grid_clinical_panel(
        [
            (
                _find_db_img(db_ext, "bcsc_p130_x26573"),
                "A) 4 Kadran Hemoraji (ETDRS 2A)",
                "4 kadranın her birinde ≥20 intraretinal nokta/leke hemoraji ve mikroanevrizma.",
            ),
            (
                _find_db_img(db_ext, "bcsc_p130_x26574"),
                "B) ≥2 Kadran Venöz Boncuklanma (6B)",
                "Retinal venüllerde sosis dizisi tarzında kalibrasyon düzensizliği (ağır iskemi göstergesi).",
            ),
            (
                _find_db_img(db_ext, "bcsc_p131_x26577"),
                "C) ≥1 Kadran Belirgin IRMA",
                "İntraretinal şant damarları; ILM'yi delmez ve geç faz FA'da NVE gibi yoğun sızdırmaz.",
            ),
            (
                _find_db_img(db_ext, "bcsc_p131_x26578"),
                "D) Ultra-Geniş Açılı FA (UWFA)",
                "Yaygın periferik kapiller nonperfüzyon (hipoflöresan) ve vasküler arkadlarda fokal NVE sızıntısı.",
            ),
        ],
        "KLİNİK GÖRÜNTÜ 3.1 — Ağır NPDR '4:2:1 Kuralı' Standart Fotoğrafları ve Ultra-Geniş Açılı FA (Protokol AA)",
        "Kaynak: AAO BCSC 2023-2024 Section 12: Retina and Vitreous (ETDRS Standart 2A, 6B, Jennifer K. Sun IRMA & UWFA, Fig 5-2..5-5)",
        paths["panel_etdrs_421_uwfa"],
    )

    compose_3grid_clinical_panel(
        [
            (
                _find_db_img(db_ext, "bcsc_p135_x26580"),
                "A) Optik Disk Neovaskülarizasyonu (NVD)",
                "Disk alanının >1/4-1/3'ünü aşan ince NVD ağları; vitreus hemorajisi olmasa bile Yüksek Riskli PDR!",
            ),
            (
                _find_db_img(db_ext, "bcsc_p135_x26581"),
                "B) NVE + Preretinal Hemoraji (DRS Std 7)",
                "ILM'yi delip arka hiyaloid yüzeyde büyüyen NVE yumağı, atılmış pamuk manzarası ve preretinal kanama.",
            ),
            (
                ext / "art05_p33_x355.png",
                "C) Kayık Preretinal Kanama & Geç FA",
                "Güncel Retina arşivinden: Subhiyaloid seviyeli kanama blokajı ve aktif NVD/NVE'den yoğun boya sızıntısı.",
            ),
        ],
        "KLİNİK GÖRÜNTÜ 3.2 — Yüksek Riskli Proliferatif Diyabetik Retinopati (NVD, NVE ve Preretinal Kanama)",
        "Kaynak: AAO BCSC 2023-2024 Section 12 (Fig 5-6, Fig 5-7) ve Güncel Retina (Arvas & Yılmaz Çebi, s. 121)",
        paths["panel_hr_pdr_nvd_nve"],
    )

    compose_3grid_clinical_panel(
        [
            (
                _find_db_img(db_ext, "bcsc_p124_x26566"),
                "A) Erken DR En-Face OKTA",
                "Korunmuş perifoveal kapiller halka ve erken mikroanevrizma/tortuozite başlangıcı.",
            ),
            (
                _find_db_img(db_ext, "bcsc_p124_x26569"),
                "B) İleri DR En-Face OKTA (FAZ ↑)",
                "Perifoveal kapiller arkad yıkımıyla belirgin genişlemiş düzensiz FAZ ve kapiller nonperfüzyon.",
            ),
            (
                ext / "art07_p47_x493.png",
                "C) Yapısal OKT'de Foveal DRIL",
                "Güncel Retina (Özdemir & Ekinci): Santral foveada iç retina katman sınırlarının silinmesi (DRIL).",
            ),
        ],
        "KLİNİK GÖRÜNTÜ 4.2 — En-Face OKTA FAZ Genişlemesi ve Yapısal OKT'de Foveal DRIL Korelasyonu",
        "Kaynak: AAO BCSC 2023-2024 Section 12 (Fig 5-1) ve Güncel Retina (Özdemir & Ekinci, s. 141)",
        paths["panel_octa_faz_dril"],
    )

    compose_3grid_clinical_panel(
        [
            (
                _find_db_img(db_ext, "bcsc_p144_x26610"),
                "A) Merkezi Tutmayan DMÖ (Non-CI DME)",
                "ETDRS santral 1 mm halka normal (mavi/yeşil); parasantral kalınlaşma santral halka dışında.",
            ),
            (
                _find_db_img(db_ext, "bcsc_p144_x26608"),
                "B) Merkezi Tutan DMÖ (CI-DME)",
                "Santral 1 mm foveal alt alanda belirgin kalınlaşma (beyaz/kırmızı) -> Protokol V / T karar eşiği.",
            ),
            (
                _find_db_img(db_ext, "bcsc_p140_x26592"),
                "C) Panretinal Fotokoagülasyon (PRP)",
                "Maküla arkadları dışına uygulanan panretinal lazer skarları (iskemik dış retinada O2 tüketimini azaltır).",
            ),
        ],
        "KLİNİK GÖRÜNTÜ 5.2 — Merkezi Tutmayan vs Merkezi Tutan DMÖ OKT Haritası ve Panretinal Fotokoagülasyon",
        "Kaynak: AAO BCSC 2023-2024 Section 12 (Jennifer K. Sun Fig 5-13 & Fig 5-10)",
        paths["panel_dme_ci_nci_prp"],
    )

    compose_clinical_panel(
        _find_db_img(db_ext, "bcsc_p142_x26597"),
        ext / "art14_p85_x844.png",
        "KLİNİK GÖRÜNTÜ 6.2 — İnflamatuvar/Dirençli DMÖ OKT Fenotipi (SMD + HRF) ve Traksiyonel VMT Ayrımı",
        "Kaynak: AAO BCSC 2023-2024 (Fig 5-11B) ve Güncel Retina (Durukan ve ark., s. 196)",
        "Sol: Subfoveal seröz dekolman (SMD), dev santral kist ve çoklu HRF -> Erken kortikosteroid (DEX) switch adayı!",
        "Sağ: Kalınlaşmış arka hiyaloidin foveaya uyguladığı vitreomaküler traksiyon (VMT) -> Farmakoterapi değil PPV adayı!",
        paths["panel_oct_dril_vmt"],
    )

    compose_3grid_clinical_panel(
        [
            (
                _find_db_img(db_ext, "bcsc_p457_x27802"),
                "A) Masaüstü (Tabletop) Diyabetik TRD",
                "Üst/alt vasküler arkadlar boyunca uzanan yoğun fibrovasküler proliferasyon ve makülaya uzanan traksiyon.",
            ),
            (
                ext / "art12_p73_x729.png",
                "B) Retinal Kromofor Emilim Spektrumu",
                "577 nm sarı lazerin ksantofilde sıfıra yakın emilimi ve melanin/oksihemoglobinde yüksek seçiciliği.",
            ),
            (
                ext / "art15_p94_x904.png",
                "C) Bimanuel En Bloc TRD Delaminasyonu",
                "Güncel Retina (Kapran & Sayın): Fibrovasküler membran köklerinin bimanuel yatay makasla kesilmesi.",
            ),
        ],
        "KLİNİK GÖRÜNTÜ 8.2 — Proliferatif DR'de Masaüstü TRD, Kromofor Fiziği ve Bimanuel En Bloc Delaminasyon",
        "Kaynak: AAO BCSC 2023-2024 Section 12 (Fig 19-7) ve Güncel Retina (Çıtırık & Teke s. 179; Kapran & Sayın s. 205)",
        paths["panel_trd_surgery_db"],
    )

    return {k: str(v) for k, v in paths.items()}


if __name__ == "__main__":
    out = build_all_dr_dmo_visuals(Path(__file__).parent)
    for k, v in out.items():
        print(f"Generated {k}: {v}")
