# -*- coding: utf-8 -*-
"""
Kanski PDF Bölüm ve Konu Metin Madenciliği Motoru (kanski_extractor.py)
PyMuPDF (fitz) kullanarak Kanski 10. Baskı PDF'inden bölüm bazında temiz metin,
alt başlıklar, TIP kutuları ve klinik tabloları yapılandırılmış olarak çıkarır.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pymupdf

from kanski_metadata import CHAPTERS_METADATA, ChapterMeta, get_chapter_meta

KANSKI_PDF_DEFAULT_PATH = Path(
    r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI\KANSAKI'S_Clinical_Ophthalmology_A_Systematic_Appr_240922_131738_compressed-1-4.pdf"
)


class KanskiExtractor:
    def __init__(self, pdf_path: Optional[Path | str] = None):
        self.pdf_path = Path(pdf_path or KANSKI_PDF_DEFAULT_PATH)
        if not self.pdf_path.is_file():
            raise FileNotFoundError(f"Kanski PDF dosyası bulunamadı: {self.pdf_path}")
        self._doc: Optional[pymupdf.Document] = None

    @property
    def doc(self) -> pymupdf.Document:
        if self._doc is None or self._doc.is_closed:
            self._doc = pymupdf.open(self.pdf_path)
        return self._doc

    def close(self):
        if self._doc and not self._doc.is_closed:
            self._doc.close()

    def extract_chapter_content(self, chapter_id: int) -> Dict[str, Any]:
        """
        Belirtilen bölümün tüm sayfalarından ham metin, alt başlıklar ve klinik ipuçlarını (TIP) çıkarır.
        """
        meta: ChapterMeta = get_chapter_meta(chapter_id)
        doc = self.doc
        start_idx = meta["pdf_start_page"] - 1  # 0-indexed
        end_idx = min(meta["pdf_end_page"], len(doc))  # inclusive in PDF page number

        pages_data: List[Dict[str, Any]] = []
        full_text_parts: List[str] = []
        tips: List[str] = []

        for p_idx in range(start_idx, end_idx):
            page = doc[p_idx]
            p_num = p_idx + 1
            b_num = p_num - 12  # approximate book page number
            text = page.get_text()
            full_text_parts.append(text)

            # TIP / CLINICAL PEARL arama
            tip_matches = re.findall(r"TIP\s+([^\n]+(?:\n[^\n]+){1,4})", text)
            for tm in tip_matches:
                cleaned_tip = " ".join(tm.split()).strip()
                if len(cleaned_tip) > 20 and cleaned_tip not in tips:
                    tips.append(cleaned_tip)

            pages_data.append({
                "pdf_page": p_num,
                "book_page": b_num,
                "char_count": len(text),
                "text": text
            })

        combined_text = "\n\n".join(full_text_parts)

        # Alt başlık ve kavram segmentasyonu
        paragraphs = [p.strip() for p in combined_text.split("\n\n") if len(p.strip()) > 35]

        # Sayısal ve klinik kritik verileri çıkarma
        numbers_and_thresholds = re.findall(
            r"\b(?:\d+(?:\.\d+)?\s*(?:mm|µm|mmHg|D|dioptre|prism|%|mg|ml|IU|sn|dakika|hafta|ay|yıl|kat))\b",
            combined_text,
            re.IGNORECASE
        )

        return {
            "chapter_id": chapter_id,
            "title_en": meta["title_en"],
            "title_tr": meta["title_tr"],
            "page_count": meta["page_count"],
            "target_questions": meta["target_questions"],
            "core_subsections": meta["core_subsections"],
            "high_yield_keywords": meta["high_yield_keywords"],
            "total_chars": len(combined_text),
            "paragraphs_count": len(paragraphs),
            "tips": tips,
            "sample_thresholds": list(dict.fromkeys(numbers_and_thresholds))[:40],
            "pages": pages_data,
            "full_text": combined_text
        }


if __name__ == "__main__":
    extractor = KanskiExtractor()
    try:
        ch1 = extractor.extract_chapter_content(1)
        print(f"Bölüm 1 Başarıyla Çıkarıldı:")
        print(f"  Başlık: {ch1['title_tr']}")
        print(f"  Toplam Karakter: {ch1['total_chars']:,}")
        print(f"  Paragraf Sayısı: {ch1['paragraphs_count']}")
        print(f"  Tespit Edilen Klinik TIP Sayısı: {len(ch1['tips'])}")
        print(f"  Örnek TIP: {ch1['tips'][0] if ch1['tips'] else 'Yok'}")
    finally:
        extractor.close()
