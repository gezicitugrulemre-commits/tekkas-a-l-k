"""
LangGraph Görsel, Şematik, Mnemonic'li ve Tablolu Klinik PDF Dizgi Motoru (pro_pdf_publisher.py).

Kullanıcının geri bildirimleri doğrultusunda:
1. Ferahlatılmış Tipografi ve Satır/Paragraf Aralığı:
   - Gövde metni: 10.2 pt, 16.6 pt satır aralığı (1.63x leading) ve 9.5 pt paragraf arası boşluk.
   - Tablo ve kutu içi genişletilmiş dolgu (padding: 7.5-10 pt) ve bileşenler arası 4-5 mm nefes alanı.
2. Her Alt Bölümde (1.1 - 10.2, 24 Alt Bölüm):
   - Tam genişlikli (174 mm) 1600x580 PIL Anatomik/OKT/Algoritma Şeması,
   - Mavi Klinik Karşılaştırma ve Tanı Tablosu (#1c5ba6),
   - Mor Varsayımsal Klinik Olgu Tablosu (#6941a5: Durum / Akıl Yürütme / Karar),
   - Açık Erişim (PMC CC BY 4.0) Gerçek Klinik OCTA/OCT/FAF Görüntüleri.
3. Her Konu Başlığının İçinde (1.1.1 - 10.2.2, 61 Konu - Uzun Metin Duvarlarını Kıran Yerleşim):
   - Konu Başında: Mavi sol şeritli 'ÖNE ÇIKAN KLİNİK İLKE' kutusu,
   - 3. Paragraftan Sonra: Yeşil başlıklı 4 maddeli '📌 ÖNEMLİ NOKTALAR VE KLİNİK İNCİLER' kutucuğu,
   - 6. Paragraftan Sonra: Konuya ait gerçek Ryan's Retina veritabanı klinik görüntüsü (veya görsel şema kartı),
   - 9. Paragraftan Sonra: Mor/Amber rozetli '🧠 KLİNİK MNEMONIC (AKILDA KALICI KODLAMA)' tablosu,
   - Konu Sonunda: Yeşil/Amber 'VERİTABANI vs PUBMED KANIT SENTEZİ VE KLİNİK ETKİ' tablosu + Amber sol şeritli '⚠️ KLİNİK TUZAK VE YORUM SINIRI' kutusu.
4. Kitap Sonunda:
   - A4 Yatay (Landscape) 9 Bölümlük Tıklanabilir 'Hızlı Klinik Başvuru Özeti (Karşılaştırma Matrisi)'.
"""

from __future__ import annotations

import html
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pymupdf
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from clinical_tables_and_cases import (
    BOOK_SUMMARY_MATRIX_ROWS,
    SUBSECTION_CLINICAL_PACKAGES,
    build_all_clinical_tables_manifest,
    extract_topic_structured_cards,
)
from config import PATHS
from visual_schematics import generate_all_subsection_visuals

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# langgraph-lab standart renk paleti
INK = colors.HexColor("#142f43")
MUTED = colors.HexColor("#476174")
LINE = colors.HexColor("#cddce8")
BLUE = colors.HexColor("#1c5ba6")
BLUE_BG = colors.HexColor("#edf4ff")
GREEN = colors.HexColor("#087d6c")
GREEN_BG = colors.HexColor("#eaf8f2")
AMBER = colors.HexColor("#a46109")
AMBER_BG = colors.HexColor("#fff5df")
PURPLE = colors.HexColor("#6941a5")
PURPLE_BG = colors.HexColor("#f4effc")
ROW_ALT = colors.HexColor("#f6f9fc")


class BookmarkParagraph(Paragraph):
    """Hem metni çizer hem de PDF sol menüsüne (Bookmarks) tıklanabilir başlık ekler."""

    _last_level = 0

    def __init__(self, text: str, style: ParagraphStyle, bookmark_key: str, bookmark_title: str, level: int = 0):
        super().__init__(text, style)
        self.bookmark_key = bookmark_key
        self.bookmark_title = bookmark_title
        self.bookmark_level = level

    def draw(self):
        safe_level = min(self.bookmark_level, BookmarkParagraph._last_level + 1)
        BookmarkParagraph._last_level = safe_level
        self.canv.bookmarkPage(self.bookmark_key)
        self.canv.addOutlineEntry(
            self.bookmark_title,
            self.bookmark_key,
            level=safe_level,
            closed=(safe_level >= 1),
        )
        super().draw()


def register_fonts() -> None:
    regular = "C:/Windows/Fonts/arial.ttf"
    bold = "C:/Windows/Fonts/arialbd.ttf"
    italic = "C:/Windows/Fonts/ariali.ttf" if Path("C:/Windows/Fonts/ariali.ttf").exists() else regular
    pdfmetrics.registerFont(TTFont("Arial", regular))
    pdfmetrics.registerFont(TTFont("ArialBold", bold))
    pdfmetrics.registerFont(TTFont("ArialItalic", italic))
    pdfmetrics.registerFontFamily(
        "Arial",
        normal="Arial",
        bold="ArialBold",
        italic="ArialItalic",
        boldItalic="ArialBold",
    )


def tr_upper(text: str) -> str:
    """Türkçe karakter duyarlı büyük harf dönüşümü (i -> İ, ı -> I)."""
    return text.replace("i", "İ").replace("ı", "I").upper()


def fmt_inline(raw_text: str) -> str:
    """Markdown kalın/italik ve [RV1:pdf123] / [PMID:12345] rozetlerini biçimlendirir (R* gibi biyokimyasal sembolleri korur)."""
    escaped = html.escape(raw_text.strip())
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", escaped)
    escaped = re.sub(r"(?<![A-Za-z0-9ÇĞİÖŞÜçğıöşü])\*([^\s*][^*]{1,80}?)\*(?![A-Za-z0-9ÇĞİÖŞÜçğıöşü])", r"<i>\1</i>", escaped)
    escaped = re.sub(
        r"(\[(?:[A-Za-z0-9-]+:pdf\d+|PMID:\d+)\])",
        r'<font size="8.5" color="#1c5ba6"><b>\1</b></font>',
        escaped,
    )
    return escaped


def make_styles() -> Dict[str, ParagraphStyle]:
    # Ferahlatılmış gövde tipografisi: 10.2 pt font, 16.6 pt satır aralığı, 9.5 pt paragraf boşluğu
    body = ParagraphStyle(
        "Body",
        fontName="Arial",
        fontSize=10.2,
        leading=16.6,
        alignment=TA_JUSTIFY,
        textColor=INK,
        spaceBefore=1.5,
        spaceAfter=9.5,
    )
    return {
        "body": body,
        "bold": ParagraphStyle("Bold", parent=body, fontName="ArialBold", alignment=TA_LEFT),
        "small": ParagraphStyle("Small", parent=body, fontSize=8.7, leading=12.6, alignment=TA_LEFT, textColor=MUTED, spaceAfter=3),
        "small_bold": ParagraphStyle("SmallBold", parent=body, fontName="ArialBold", fontSize=9.0, leading=13.0, alignment=TA_LEFT, textColor=INK, spaceAfter=3),
        "tbl_hdr": ParagraphStyle("TblHdr", parent=body, fontName="ArialBold", fontSize=9.3, leading=13.0, alignment=TA_LEFT, textColor=colors.white, spaceAfter=0),
        "tbl_cell": ParagraphStyle("TblCell", parent=body, fontSize=9.1, leading=13.6, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "tbl_cell_bold": ParagraphStyle("TblCellBold", parent=body, fontName="ArialBold", fontSize=9.1, leading=13.6, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "ch_banner_kicker": ParagraphStyle("ChKicker", parent=body, fontName="ArialBold", fontSize=9.5, leading=13, alignment=TA_LEFT, textColor=colors.HexColor("#dbeafe"), spaceAfter=2),
        "ch_banner_title": ParagraphStyle("ChTitle", parent=body, fontName="ArialBold", fontSize=18.0, leading=23, alignment=TA_LEFT, textColor=colors.white, spaceAfter=0),
        "sec_title": ParagraphStyle("SecTitle", parent=body, fontName="ArialBold", fontSize=13.8, leading=19.0, alignment=TA_LEFT, textColor=BLUE, spaceBefore=12, spaceAfter=7, keepWithNext=True),
        "topic_title": ParagraphStyle("TopicTitle", parent=body, fontName="ArialBold", fontSize=11.8, leading=16.5, alignment=TA_LEFT, textColor=INK, backColor=BLUE_BG, borderPadding=(7, 9, 7, 9), spaceBefore=14, spaceAfter=8, keepWithNext=True),
        "facet_title": ParagraphStyle("FacetTitle", parent=body, fontName="ArialBold", fontSize=10.6, leading=15.0, alignment=TA_LEFT, textColor=GREEN, spaceBefore=11, spaceAfter=5, keepWithNext=True),
        "callout_blue": ParagraphStyle("CalloutBlue", parent=body, fontSize=9.4, leading=14.2, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "callout_amber": ParagraphStyle("CalloutAmber", parent=body, fontSize=9.4, leading=14.2, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
    }


def build_callout_box(label: str, text: str, border_color, bg_color, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    content = f'<font color="{border_color.hexval()}"><b>{html.escape(label)}:</b></font> {fmt_inline(text)}'
    p = Paragraph(content, styles["callout_blue"])
    t = Table([[p]], colWidths=[178 * mm])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), bg_color),
                ("LINEBEFORE", (0, 0), (0, -1), 3.8, border_color),
                ("BOX", (0, 0), (-1, -1), 0.6, LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ("LEFTPADDING", (0, 0), (-1, -1), 11),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    return KeepTogether([Spacer(1, 2.5 * mm), t, Spacer(1, 3.5 * mm)])


def build_important_points_box(topic_id: str, points: List[str], styles: Dict[str, ParagraphStyle]) -> Optional[KeepTogether]:
    """
    Metin duvarlarını kıran ferah, 4 maddeli Yeşil 'ÖNEMLİ NOKTALAR VE KLİNİK İNCİLER' kutucuğu.
    """
    if not points:
        return None
    rows = [
        [
            Paragraph(
                f'<b>ÖNEMLİ NOKTALAR VE KLİNİK İNCİLER [{html.escape(topic_id)}]</b>',
                styles["tbl_hdr"],
            )
        ]
    ]
    for idx, pt in enumerate(points, 1):
        bullet_html = f'<font color="#087d6c"><b>[{idx}]</b></font> &nbsp;{fmt_inline(pt)}'
        rows.append([Paragraph(bullet_html, styles["tbl_cell"])])

    t = Table(rows, colWidths=[178 * mm])
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("BOX", (0, 0), (-1, -1), 0.8, GREEN),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 6.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
    ]
    for i in range(1, len(rows)):
        tstyle.append(("BACKGROUND", (0, i), (-1, i), GREEN_BG if i % 2 == 1 else colors.white))
    t.setStyle(TableStyle(tstyle))
    return KeepTogether([Spacer(1, 3.5 * mm), t, Spacer(1, 4.5 * mm)])


def build_mnemonic_box(mnemonic: dict, styles: Dict[str, ParagraphStyle]) -> Optional[KeepTogether]:
    """
    Kullanıcının istediği akılda kalıcı 'KLİNİK MNEMONIC (BELLEK KODU)' kutucuğu.
    Mor başlık + harf/anahtar sütunu + açıklama sütunu + alt amber klinik ipucu şeridi.
    """
    if not mnemonic or not mnemonic.get("items"):
        return None

    code_title = mnemonic.get("code", "KLİNİK MNEMONIC")
    data = [
        [
            Paragraph("<b>KOD / HARF</b>", styles["tbl_hdr"]),
            Paragraph(f'<b>KLİNİK MNEMONIC (AKILDA KALICI KODLAMA): {html.escape(code_title)}</b>', styles["tbl_hdr"]),
        ]
    ]
    for key_str, desc_str in mnemonic["items"]:
        data.append(
            [
                Paragraph(f'<font color="#6941a5"><b>{html.escape(key_str)}</b></font>', styles["tbl_cell_bold"]),
                Paragraph(fmt_inline(desc_str), styles["tbl_cell"]),
            ]
        )

    pearl_text = mnemonic.get("pearl", "")
    if pearl_text:
        data.append(
            [
                Paragraph('<font color="#a46109"><b>KLİNİK İPUCU</b></font>', styles["tbl_cell_bold"]),
                Paragraph(f'<font color="#142f43"><b>Hatırla:</b> {fmt_inline(pearl_text)}</font>', styles["tbl_cell"]),
            ]
        )

    t = Table(data, colWidths=[36 * mm, 142 * mm])
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), PURPLE),
        ("BOX", (0, 0), (-1, -1), 0.9, PURPLE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]
    for i in range(1, len(data)):
        if pearl_text and i == len(data) - 1:
            tstyle.append(("BACKGROUND", (0, i), (-1, i), AMBER_BG))
        else:
            tstyle.append(("BACKGROUND", (0, i), (-1, i), PURPLE_BG if i % 2 == 1 else colors.white))
    t.setStyle(TableStyle(tstyle))
    return KeepTogether([Spacer(1, 3.5 * mm), t, Spacer(1, 4.5 * mm)])


def build_source_comparison_box(card: dict, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    """Yeşil (Yerel Veritabanı RV1-3) ve Amber (PubMed / Güncel Kanıt) karşılaştırma + Klinik Etki tablosu."""
    left_html = f'<font color="#087d6c"><b>KLASİK REFERANS (VERİTABANI)</b></font><br/>{fmt_inline(card["green_db_cell"])}'
    right_html = f'<font color="#a46109"><b>GÜNCEL LİTERATÜR / PUBMED SENTEZİ</b></font><br/>{fmt_inline(card["amber_pubmed_cell"])}'

    top_grid = Table(
        [[Paragraph(left_html, styles["tbl_cell"]), Paragraph(right_html, styles["tbl_cell"])]],
        colWidths=[89 * mm, 89 * mm],
    )
    top_grid.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, 0), GREEN_BG),
                ("BACKGROUND", (1, 0), (1, 0), AMBER_BG),
                ("BOX", (0, 0), (-1, -1), 0.6, LINE),
                ("INNERGRID", (0, 0), (-1, -1), 0.6, LINE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 7.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7.5),
                ("LEFTPADDING", (0, 0), (-1, -1), 9),
                ("RIGHTPADDING", (0, 0), (-1, -1), 9),
            ]
        )
    )

    bottom_grid = Table(
        [
            [
                Paragraph('<font color="#1c5ba6"><b>KLİNİK KARARA ETKİSİ</b></font>', styles["tbl_cell_bold"]),
                Paragraph(fmt_inline(card["clinical_impact_cell"]), styles["tbl_cell"]),
            ]
        ],
        colWidths=[38 * mm, 140 * mm],
    )
    bottom_grid.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, 0), BLUE_BG),
                ("BACKGROUND", (1, 0), (1, 0), colors.white),
                ("BOX", (0, 0), (-1, -1), 0.6, LINE),
                ("INNERGRID", (0, 0), (-1, -1), 0.6, LINE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 6.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
                ("LEFTPADDING", (0, 0), (-1, -1), 9),
                ("RIGHTPADDING", (0, 0), (-1, -1), 9),
            ]
        )
    )
    return KeepTogether([Spacer(1, 3 * mm), top_grid, bottom_grid, Spacer(1, 3.5 * mm)])


def build_blue_clinical_table(pkg: dict, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    """langgraph-lab standart Mavi Klinik Karşılaştırma ve Tanı Tablosu (178 mm)."""
    headers = pkg["headers"]
    rows = pkg["rows"]
    ncols = len(headers)
    if ncols == 4:
        col_widths = [38 * mm, 42 * mm, 52 * mm, 46 * mm]
    else:
        col_widths = [46 * mm, 66 * mm, 66 * mm]

    table_data = [[Paragraph(fmt_inline(h), styles["tbl_hdr"]) for h in headers]]
    for r in rows:
        row_cells = []
        for idx, cell_text in enumerate(r):
            st = styles["tbl_cell_bold"] if idx == 0 else styles["tbl_cell"]
            row_cells.append(Paragraph(fmt_inline(cell_text), st))
        table_data.append(row_cells)

    t = Table(table_data, colWidths=col_widths, repeatRows=1)
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), BLUE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.8, BLUE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("TOPPADDING", (0, 0), (-1, -1), 6.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]
    for i in range(1, len(table_data)):
        bg = BLUE_BG if i % 2 == 1 else colors.white
        tstyle.append(("BACKGROUND", (0, i), (-1, i), bg))
    t.setStyle(TableStyle(tstyle))

    title_p = Paragraph(f'<font color="#1c5ba6"><b>{html.escape(pkg["table_title"])}</b></font>', styles["small_bold"])
    return KeepTogether([Spacer(1, 3.5 * mm), title_p, Spacer(1, 1.5 * mm), t, Spacer(1, 4 * mm)])


def build_purple_case_table(case_dict: dict, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    """langgraph-lab standart Mor Varsayımsal Klinik Olgu Tablosu ([38*mm, 140*mm])."""
    data = [
        [
            Paragraph("<b>Basamak</b>", styles["tbl_hdr"]),
            Paragraph(f'<b>{html.escape(case_dict["title"])}</b>', styles["tbl_hdr"]),
        ],
        [
            Paragraph('<font color="#6941a5"><b>Klinik Durum</b></font>', styles["tbl_cell_bold"]),
            Paragraph(fmt_inline(case_dict["durum"]), styles["tbl_cell"]),
        ],
        [
            Paragraph('<font color="#6941a5"><b>Multimodal Akıl Yürütme</b></font>', styles["tbl_cell_bold"]),
            Paragraph(fmt_inline(case_dict["akil_yurutme"]), styles["tbl_cell"]),
        ],
        [
            Paragraph('<font color="#6941a5"><b>Klinik Karar ve İzlem</b></font>', styles["tbl_cell_bold"]),
            Paragraph(fmt_inline(case_dict["karar"]), styles["tbl_cell"]),
        ],
    ]
    t = Table(data, colWidths=[38 * mm, 140 * mm])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), PURPLE),
                ("BACKGROUND", (0, 1), (-1, -1), PURPLE_BG),
                ("BOX", (0, 0), (-1, -1), 0.8, PURPLE),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 6.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    return KeepTogether([Spacer(1, 3 * mm), t, Spacer(1, 4 * mm)])


def build_schematic_card(vis_info: dict, styles: Dict[str, ParagraphStyle]) -> Optional[KeepTogether]:
    """1600x680 PIL şemasını 174 mm genişlikte ve gerçek en-boy oranında çerçeveli kart olarak gömer."""
    img_path = Path(vis_info.get("schematic_path", ""))
    if not img_path.is_file():
        return None
    w_mm = 174 * mm
    try:
        with PILImage.open(img_path) as pim:
            iw, ih = pim.size
        h_mm = w_mm * (float(ih) / float(max(iw, 1)))
    except Exception:
        h_mm = w_mm * (680.0 / 1600.0)
    rl_img = Image(str(img_path), width=w_mm, height=h_mm)
    cap_html = (
        f'<font color="#1c5ba6"><b>{html.escape(vis_info["title"])}</b></font> — '
        f'{html.escape(vis_info["subtitle"])}'
    )
    card = Table(
        [[rl_img], [Paragraph(cap_html, styles["small"])]],
        colWidths=[178 * mm],
    )
    card.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),
                ("BACKGROUND", (0, 1), (0, 1), ROW_ALT),
                ("BOX", (0, 0), (-1, -1), 0.7, LINE),
                ("LINEABOVE", (0, 1), (0, 1), 0.5, LINE),
                ("ALIGN", (0, 0), (0, 0), "CENTER"),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    return KeepTogether([Spacer(1, 2 * mm), card, Spacer(1, 2.5 * mm)])


def build_real_figure_card(fig_item: dict, styles: Dict[str, ParagraphStyle], is_db: bool = False) -> Optional[KeepTogether]:
    """Gerçek klinik görüntüyü (PMC CC BY 4.0 veya Ryan's Retina Veritabanı) 2 sütunlu provenans kartıyla gömer."""
    p = Path(fig_item.get("local_path", ""))
    if not p.is_file():
        return None
    try:
        with PILImage.open(p) as pim:
            iw, ih = pim.size
    except Exception:
        return None

    max_w = 82 * mm
    max_h = 56 * mm
    scale = min(max_w / max(iw, 1), max_h / max(ih, 1))
    draw_w = iw * scale
    draw_h = ih * scale

    rl_img = Image(str(p), width=draw_w, height=draw_h)
    badge_color = "#087d6c" if not is_db else "#1c5ba6"
    badge_label = "DOĞRULANMIŞ KLİNİK GÖRÜNTÜ (AÇIK ERİŞİM / PMC)" if not is_db else "YEREL VERİTABANI KLİNİK GÖRÜNTÜSÜ (RYAN'S RETINA)"

    right_html = (
        f'<font color="{badge_color}"><b>{badge_label}</b></font><br/>'
        f'<b>{html.escape(fig_item.get("title", ""))}</b><br/><br/>'
        f'{fmt_inline(fig_item.get("caption", ""))}<br/><br/>'
        f'<font size="8.2" color="#476174"><i>{html.escape(fig_item.get("provenance", ""))}</i></font>'
    )

    t = Table(
        [[rl_img, Paragraph(right_html, styles["tbl_cell"])]],
        colWidths=[86 * mm, 92 * mm],
    )
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, 0), colors.white),
                ("BACKGROUND", (1, 0), (1, 0), GREEN_BG if not is_db else BLUE_BG),
                ("BOX", (0, 0), (-1, -1), 0.8, GREEN if not is_db else BLUE),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ALIGN", (0, 0), (0, 0), "CENTER"),
                ("TOPPADDING", (0, 0), (-1, -1), 6.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
                ("LEFTPADDING", (0, 0), (-1, -1), 7),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    return KeepTogether([Spacer(1, 3 * mm), t, Spacer(1, 4 * mm)])


def append_landscape_summary_matrix(book_pdf: Path, chapter_start_pages: Dict[str, int]) -> int:
    """
    clinical_matrix.py stiliyle kitabın sonuna A4 Yatay (Landscape) 9 Bölümlük
    'Hızlı Klinik Başvuru Özeti (Karşılaştırma Matrisi)' sayfası ekler ve tıklanabilir
    bölüm bağlantıları (LINK_GOTO) oluşturur.
    """
    matrix_pdf = book_pdf.parent / "_temp_landscape_matrix.pdf"
    w, h = pymupdf.paper_size("a4-l")
    margin = 10 * mm
    available = w - 2 * margin

    body_st = ParagraphStyle("MBody", fontName="Arial", fontSize=8.0, leading=10.3, textColor=INK)
    bold_st = ParagraphStyle("MBold", parent=body_st, fontName="ArialBold", textColor=BLUE)
    hdr_st = ParagraphStyle("MHdr", parent=bold_st, fontSize=8.6, textColor=colors.white)

    headers = [
        "Bölüm & Sayfa",
        "Hedef Doku & Anatomi",
        "Multimodal Görüntüleme & Biyobelirteç",
        "Klinik Seyir & Kırmızı Bayraklar",
        "Birincil Tedavi & Klinik Karar",
    ]
    data = [[Paragraph(html.escape(col), hdr_st) for col in headers]]

    row_targets: List[int] = []
    for row in BOOK_SUMMARY_MATRIX_ROWS:
        ch_num = row["chapter_num"]
        start_pg = chapter_start_pages.get(ch_num, 3)
        row_targets.append(start_pg - 1)
        first_cell = f'<b>{html.escape(ch_num)}</b><br/>{html.escape(row["chapter_title"])}<br/><font color="#087d6c"><b>s. {start_pg}</b></font>'
        data.append(
            [
                Paragraph(first_cell, body_st),
                Paragraph(fmt_inline(row["target_tissue"]), body_st),
                Paragraph(fmt_inline(row["imaging_biomarker"]), body_st),
                Paragraph(fmt_inline(row["clinical_course"]), body_st),
                Paragraph(fmt_inline(row["clinical_decision"]), body_st),
            ]
        )

    widths = [available * v for v in (0.14, 0.19, 0.22, 0.22, 0.23)]
    table = Table(data, colWidths=widths, hAlign="LEFT")
    tstyle = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (-1, 0), BLUE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3.0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.0),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, LINE),
        ("BOX", (0, 0), (-1, -1), 0.7, BLUE),
    ]
    for i in range(1, len(data)):
        tstyle.append(("BACKGROUND", (0, i), (-1, i), BLUE_BG if i % 2 == 1 else ROW_ALT))
    table.setStyle(TableStyle(tstyle))

    can = canvas.Canvas(str(matrix_pdf), pagesize=(w, h))
    can.setTitle("Hızlı Klinik Başvuru Özeti — Karşılaştırma Matrisi")
    for idx, col_hex in enumerate(["#1c5ba6", "#087d6c", "#a46109"]):
        can.setFillColor(colors.HexColor(col_hex))
        can.rect(idx * w / 3.0, h - 8, w / 3.0, 8, fill=1, stroke=0)

    can.setFillColor(BLUE)
    can.setFont("ArialBold", 15.5)
    can.drawString(margin, h - 28, "Hızlı Klinik Başvuru Özeti — 9 Bölüm Karşılaştırma Matrisi (Tıklanabilir Dizin)")
    can.setFillColor(MUTED)
    can.setFont("Arial", 8.8)
    can.drawString(
        margin,
        h - 42,
        "9 Ana Bölüm · 24 Alt Bölüm · 61 Klinik Başlık · Ryan's Retina 7th Ed. [RV1-3] ve PubMed [PMID] Kanıt Sentezi. İlgili bölüme gitmek için sol sütuna tıklayın.",
    )

    top_y = h - 50
    tw, th = table.wrapOn(can, available, top_y - 36)
    table.drawOn(can, margin, top_y - th)

    row_rects = []
    curr_y = top_y - table._rowHeights[0]
    for target_pg, r_h in zip(row_targets, table._rowHeights[1:]):
        rect = [margin, h - curr_y, margin + widths[0], h - curr_y + r_h]
        row_rects.append((rect, target_pg))
        curr_y -= r_h

    footer_notes = [
        "[RV1-3] kaynak etiketleri yerel Ryan's Retina 7th Ed. PDF sayfasını, [PMID] etiketleri ise NCBI PubMed kanıtını gösterir.",
        "Kısaltmalar: OKT: Optik koherens tomografi · OKTA: OKT anjiyografi · FA/ICGA: Floresein/İndosiyanin anjiyografi · FAF: Otofloresans · PPV: Vitrektomi.",
    ]
    for i, note in enumerate(footer_notes):
        can.setFillColor(MUTED)
        can.setFont("Arial", 8.0)
        can.drawString(margin, 24 - i * 10, note)
    can.save()

    with pymupdf.open(book_pdf) as doc, pymupdf.open(matrix_pdf) as mdoc:
        doc.insert_pdf(mdoc)
        last_page = doc[-1]
        for rect, target_pg in row_rects:
            if 0 <= target_pg < len(doc):
                last_page.insert_link(
                    {
                        "kind": pymupdf.LINK_GOTO,
                        "from": pymupdf.Rect(rect),
                        "page": target_pg,
                        "to": pymupdf.Point(0, 0),
                    }
                )
        toc = doc.get_toc()
        toc.append([1, "Ek: Hızlı Klinik Başvuru Özeti (Karşılaştırma Matrisi)", len(doc)])
        doc.set_toc(toc)
        total_pages = len(doc)

        for block in doc[0].get_text("dict").get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if span.get("text", "").strip() == "999+":
                        bbox = pymupdf.Rect(span["bbox"])
                        doc[0].add_redact_annot(bbox, fill=(244 / 255, 239 / 255, 252 / 255))
                        doc[0].apply_redactions(images=0, graphics=0)
                        doc[0].insert_text(
                            pymupdf.Point(span["origin"]),
                            str(total_pages),
                            fontname="CoverPageCount",
                            fontfile="C:/Windows/Fonts/arialbd.ttf",
                            fontsize=span["size"],
                            color=(105 / 255, 65 / 255, 165 / 255),
                        )

        temp_saved = book_pdf.parent / "_temp_final_book.pdf"
        doc.save(temp_saved, garbage=4, deflate=True)

    matrix_pdf.unlink(missing_ok=True)
    temp_saved.replace(book_pdf)
    return total_pages


def build_publishing_grade_pdf() -> Path:
    """
    Ferahlatılmış tipografi, 114 görsel/şema, 61 Önemli Noktalar kutusu,
    61 Klinik Mnemonic tablosu, 24 Mavi Tanı Tablosu, 24 Mor Klinik Olgu Tablosu
    ve A4 yatay özet matrisi içeren tam LangGraph PDF kitabını üretir.
    """
    master_md = PATHS.compiled_dir / "Retina_ve_Vitreus_Klinik_Yaklasim_Master.md"
    out_pdf = PATHS.compiled_dir / "Retina_ve_Vitreus_Klinik_Yaklasim_Yayinevi_Baski.pdf"

    if not master_md.is_file():
        raise FileNotFoundError(f"Master Markdown bulunamadı: {master_md}")

    register_fonts()
    styles = make_styles()

    # 1. Görsel Şemaları ve Gerçek Klinik Görüntüleri Hazırla
    visuals_manifest = generate_all_subsection_visuals()
    build_all_clinical_tables_manifest()

    # Konu bazlı (topic_id -> list of db_figures) indeks oluştur (tekrarsız)
    topic_db_figures: Dict[str, List[dict]] = {}
    for sec_id, vinfo in visuals_manifest.items():
        for dbfig in vinfo.get("db_figures", []):
            for key_candidate in (dbfig.get("topic_id", ""), dbfig.get("display_topic_id", "")):
                if key_candidate:
                    lst = topic_db_figures.setdefault(key_candidate, [])
                    if all(x.get("local_path") != dbfig.get("local_path") for x in lst):
                        lst.append(dbfig)

    lines = master_md.read_text(encoding="utf-8").splitlines()
    story: List = []
    BookmarkParagraph._last_level = 0

    # 2. KAPAK SAYFASI
    hero_table = Table(
        [
            [Paragraph("LANGGRAPH KLİNİK OFTALMOLOJİ SERİSİ · KANITA DAYALI BAŞVURU KİTABI", styles["ch_banner_kicker"])],
            [Spacer(1, 2 * mm)],
            [
                Paragraph(
                    "RETİNA VE VİTREUS: KLİNİK YAKLAŞIM",
                    ParagraphStyle("HeroH1", parent=styles["ch_banner_title"], fontSize=23, leading=28),
                )
            ],
            [Spacer(1, 2 * mm)],
            [
                Paragraph(
                    "Multimodal Görüntüleme Şemaları, Gerçek Klinik OCT/OCTA/FAF Bulguları, Önemli Noktalar Kutucukları, Klinik Mnemonic'ler ve Vaka Senaryoları",
                    ParagraphStyle("HeroSub", parent=styles["body"], fontSize=10.8, leading=15.5, textColor=colors.HexColor("#e2e8f0"), alignment=TA_LEFT),
                )
            ],
            [Spacer(1, 4 * mm)],
            [
                Paragraph(
                    f"<b>Birincil Veritabanı:</b> Ryan's Retina 7th Ed. (Vol. 1–3), ICROP-3 &amp; Güncel NCBI PubMed Literatür Sentezi · <b>Tarih:</b> {datetime.now().strftime('%d.%m.%Y')}",
                    ParagraphStyle("HeroMeta", parent=styles["small"], fontSize=8.8, textColor=colors.HexColor("#cbd5e1")),
                )
            ],
        ],
        colWidths=[178 * mm],
    )
    hero_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), INK),
                ("BOX", (0, 0), (-1, -1), 1.2, BLUE),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
            ]
        )
    )
    story.append(hero_table)
    story.append(Spacer(1, 5 * mm))

    stat_num_st = lambda col: ParagraphStyle("SNum", parent=styles["bold"], fontSize=17.5, leading=21, textColor=col, alignment=TA_CENTER)
    stat_lbl_st = ParagraphStyle("SLbl", parent=styles["small_bold"], fontSize=8.2, leading=11, textColor=MUTED, alignment=TA_CENTER)
    stats_grid = Table(
        [
            [
                Paragraph("9 BÖLÜM", stat_num_st(BLUE)),
                Paragraph("61 BAŞLIK", stat_num_st(GREEN)),
                Paragraph("114 GÖRSEL", stat_num_st(AMBER)),
                Paragraph("999+", stat_num_st(PURPLE)),
            ],
            [
                Paragraph("24 Klinik Alt Bölüm", stat_lbl_st),
                Paragraph("+61 Mnemonic & Önemli Nokta", stat_lbl_st),
                Paragraph("PIL Şema + PMC/DB Görüntü", stat_lbl_st),
                Paragraph("Toplam Sayfa (Matris Dahil)", stat_lbl_st),
            ],
        ],
        colWidths=[44.5 * mm, 44.5 * mm, 44.5 * mm, 44.5 * mm],
    )
    stats_grid.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), BLUE_BG),
                ("BACKGROUND", (1, 0), (1, -1), GREEN_BG),
                ("BACKGROUND", (2, 0), (2, -1), AMBER_BG),
                ("BACKGROUND", (3, 0), (3, -1), PURPLE_BG),
                ("BOX", (0, 0), (-1, -1), 0.8, LINE),
                ("INNERGRID", (0, 0), (-1, -1), 0.8, colors.white),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    story.append(stats_grid)
    story.append(Spacer(1, 4 * mm))

    legend_box = Table(
        [
            [
                Paragraph(
                    '<font color="#087d6c"><b>YEŞİL = Önemli Noktalar / Kanıt</b></font> &nbsp;·&nbsp; '
                    '<font color="#1c5ba6"><b>MAVİ = Klinik Tanı &amp; Multimodal Tablo</b></font> &nbsp;·&nbsp; '
                    '<font color="#a46109"><b>AMBER = Klinik Tuzak &amp; İpucu</b></font> &nbsp;·&nbsp; '
                    '<font color="#6941a5"><b>MOR = Klinik Mnemonic &amp; Vaka</b></font>',
                    ParagraphStyle("Leg", parent=styles["small_bold"], alignment=TA_CENTER, fontSize=8.6),
                )
            ]
        ],
        colWidths=[178 * mm],
    )
    legend_box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), ROW_ALT),
                ("BOX", (0, 0), (-1, -1), 0.7, LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.append(legend_box)
    story.append(Spacer(1, 5 * mm))

    if "2.1" in visuals_manifest:
        preview_card = build_schematic_card(visuals_manifest["2.1"], styles)
        if preview_card:
            story.append(preview_card)

    story.append(PageBreak())

    # 3. KART STİLİ İÇİNDEKİLER SAYFASI
    story.append(
        BookmarkParagraph(
            "İÇİNDEKİLER — BÖLÜM, TABLO, MNEMONIC VE GÖRSEL ŞEMA DİZİNİ",
            styles["sec_title"],
            bookmark_key="toc_root",
            bookmark_title="İçindekiler",
            level=0,
        )
    )
    story.append(
        Paragraph(
            "Her bölüm başlığına tıklayarak ilgili bölüme gidebilirsiniz. Her alt bölümde tam genişlikli multimodal şema, mavi tanı tablosu, mor vaka senaryosu; her konuda ise Önemli Noktalar kutucukları, Klinik Mnemonic'ler ve gerçek klinik görüntüler yer almaktadır.",
            styles["small"],
        )
    )
    story.append(Spacer(1, 3 * mm))

    chapters_toc: List[Tuple[str, str, List[str]]] = []
    curr_ch_key = ""
    curr_ch_title = ""
    curr_secs: List[str] = []
    ch_counter = 0

    for ln in lines:
        s = ln.strip()
        if s.startswith("## BÖLÜM "):
            if curr_ch_title:
                chapters_toc.append((curr_ch_key, curr_ch_title, curr_secs))
            ch_counter += 1
            curr_ch_key = f"ch_{ch_counter}"
            curr_ch_title = s.replace("## ", "").strip()
            curr_secs = []
        elif re.match(r"^###\s+\d+\.\d+(?!\.\d+)\.?\s+", s):
            curr_secs.append(s.replace("### ", "").strip())
    if curr_ch_title:
        chapters_toc.append((curr_ch_key, curr_ch_title, curr_secs))

    toc_cards_rows = []
    for ch_key, ch_title, secs in chapters_toc:
        sec_str = " &nbsp;·&nbsp; ".join(html.escape(x) for x in secs)
        card_html = (
            f'<a href="#{ch_key}"><font color="#1c5ba6" size="10.2"><b>{html.escape(ch_title)}</b></font></a><br/>'
            f'<font color="#476174" size="8.4">{sec_str}</font><br/>'
            f'<font color="#087d6c" size="8.0"><b>+ Multimodal Şema · + Mavi Tanı Tablosu · + Önemli Noktalar Kutusu · + Klinik Mnemonic · + Gerçek Görüntüler</b></font>'
        )
        toc_cards_rows.append([Paragraph(card_html, styles["tbl_cell"])])

    toc_table = Table(toc_cards_rows, colWidths=[178 * mm])
    toc_style = [
        ("BOX", (0, 0), (-1, -1), 0.6, LINE),
        ("INNERGRID", (0, 0), (-1, -1), 0.6, colors.white),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for idx in range(len(toc_cards_rows)):
        toc_style.append(("BACKGROUND", (0, idx), (0, idx), BLUE_BG if idx % 2 == 0 else ROW_ALT))
    toc_table.setStyle(TableStyle(toc_style))
    story.append(toc_table)
    story.append(PageBreak())

    # 4. ANA METİN: KONU İÇİ METİN DUVARLARINI KIRAN AKILLI YERLEŞİM
    ch_idx = 0
    sec_idx = 0
    topic_idx = 0
    current_topic_id: Optional[str] = None
    current_topic_items: List[Tuple[str, str]] = []  # ("sub", text) veya ("para", text)

    def flush_topic_content(tid: Optional[str], items: List[Tuple[str, str]]) -> None:
        """
        Bir konunun (ör. 1.1.1) paragraflarını tekdüze duvar gibi basmak yerine:
        - 3. paragraftan sonra: Yeşil 'ÖNEMLİ NOKTALAR VE KLİNİK İNCİLER' kutusu,
        - 6. paragraftan sonra: Konunun gerçek Ryan's Retina veritabanı klinik görüntüsü,
        - 9. paragraftan sonra: Mor/Amber 'KLİNİK MNEMONIC (AKILDA KALICI KODLAMA)' kutusu,
        - Konu sonunda: Yeşil/Amber 'VERİTABANI vs PUBMED SENTEZİ' + Amber 'KLİNİK TUZAK' kutusu
        yerleştirir.
        """
        if not tid or not items:
            return

        raw_md = "\n".join(val for kind, val in items if kind == "para")
        card = extract_topic_structured_cards(tid, raw_md)

        para_counter = 0
        inserted_points = False
        inserted_fig = False
        inserted_mnemonic = False

        t_figs = topic_db_figures.get(tid, [])

        for kind, text_val in items:
            if kind == "sub":
                story.append(Paragraph(f"• {html.escape(tr_upper(text_val))}", styles["facet_title"]))
            else:
                story.append(Paragraph(fmt_inline(text_val), styles["body"]))
                para_counter += 1

                # 3. paragraftan sonra Önemli Noktalar Kutucuğu
                if para_counter == 3 and not inserted_points:
                    pts_box = build_important_points_box(tid, card.get("important_points", []), styles)
                    if pts_box:
                        story.append(pts_box)
                    inserted_points = True

                # 5. veya 6. paragraftan sonra Konuya Ait Gerçek Klinik Görüntü Kartı
                if para_counter == 6 and not inserted_fig and t_figs:
                    for dbfig in t_figs:
                        fc = build_real_figure_card(dbfig, styles, is_db=True)
                        if fc:
                            story.append(fc)
                    inserted_fig = True

                # 8. veya 9. paragraftan sonra Klinik Mnemonic Kutucuğu
                if para_counter == 9 and not inserted_mnemonic:
                    mn_box = build_mnemonic_box(card.get("mnemonic", {}), styles)
                    if mn_box:
                        story.append(mn_box)
                    inserted_mnemonic = True

        # Eğer paragraf sayısı azsa ve henüz eklenmediyse konu sonunda eksiksiz ekle
        if not inserted_points:
            pts_box = build_important_points_box(tid, card.get("important_points", []), styles)
            if pts_box:
                story.append(pts_box)

        if not inserted_fig and t_figs:
            for dbfig in t_figs:
                fc = build_real_figure_card(dbfig, styles, is_db=True)
                if fc:
                    story.append(fc)

        if not inserted_mnemonic:
            mn_box = build_mnemonic_box(card.get("mnemonic", {}), styles)
            if mn_box:
                story.append(mn_box)

        # Konu sonu Kaynak Sentez ve Klinik Tuzak kutuları
        story.append(build_source_comparison_box(card, styles))
        story.append(
            build_callout_box(
                f"[{tid}] KLİNİK TUZAK VE YORUM SINIRI",
                card["caution_box"],
                AMBER,
                AMBER_BG,
                styles,
            )
        )
        story.append(Spacer(1, 4 * mm))

    for ln in lines:
        stripped = ln.strip()
        if not stripped:
            continue
        if (
            stripped.startswith("# RETİNA")
            or stripped.startswith("*Üretim Tarihi")
            or stripped.startswith("*Anahat (Outline)")
            or stripped.startswith("**Alt Başlık")
            or stripped.startswith("**Baskı Tarihi")
            or stripped.startswith("**Mimari")
        ):
            continue
        if stripped in ("---", "# KAYNAKÇA VE DOĞRULAMA ÖZETİ", "## KAYNAKÇA VE PUBMED LİTERATÜR DİZİNİ") or stripped.startswith("Bu kitapta yer alan"):
            if stripped == "## KAYNAKÇA VE PUBMED LİTERATÜR DİZİNİ":
                flush_topic_content(current_topic_id, current_topic_items)
                current_topic_id, current_topic_items = None, []
                story.append(PageBreak())
                story.append(
                    BookmarkParagraph(
                        "KAYNAKÇA VE PUBMED LİTERATÜR DİZİNİ",
                        styles["sec_title"],
                        bookmark_key="refs_root",
                        bookmark_title="Kaynakça ve PubMed Dizini",
                        level=0,
                    )
                )
            continue

        # BÖLÜM BAŞLIĞI (## BÖLÜM X: ...)
        if stripped.startswith("## BÖLÜM "):
            flush_topic_content(current_topic_id, current_topic_items)
            current_topic_id, current_topic_items = None, []

            if ch_idx > 0:
                story.append(PageBreak())
            ch_idx += 1
            ch_text = stripped.replace("## ", "").strip()
            bkey = f"ch_{ch_idx}"

            ch_banner = Table(
                [
                    [Paragraph(f"RETİNA VE VİTREUS KLİNİK BAŞVURU KİTABI · BÖLÜM {ch_idx}", styles["ch_banner_kicker"])],
                    [BookmarkParagraph(html.escape(ch_text), styles["ch_banner_title"], bookmark_key=bkey, bookmark_title=ch_text, level=0)],
                ],
                colWidths=[178 * mm],
            )
            ch_banner.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, -1), BLUE),
                        ("BOX", (0, 0), (-1, -1), 1.0, INK),
                        ("TOPPADDING", (0, 0), (-1, -1), 8),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                        ("LEFTPADDING", (0, 0), (-1, -1), 11),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 11),
                    ]
                )
            )
            story.append(ch_banner)
            story.append(Spacer(1, 3 * mm))
            continue

        # KONU BAŞLIĞI (### [1.1.1] ... veya ### 1.1.1 ...)
        m_topic = re.match(r"^#{1,3}\s+\[?(\d+\.\d+\.\d+)\]?\s+(.*)", stripped)
        if m_topic:
            flush_topic_content(current_topic_id, current_topic_items)
            current_topic_items = []

            topic_idx += 1
            current_topic_id = m_topic.group(1)
            t_rest = m_topic.group(2).strip()
            t_text = f"[{current_topic_id}] {t_rest}"
            bkey = f"topic_{topic_idx}"

            story.append(
                BookmarkParagraph(
                    html.escape(t_text),
                    styles["topic_title"],
                    bookmark_key=bkey,
                    bookmark_title=t_text,
                    level=2,
                )
            )

            # Konu başında Mavi Sol Şeritli 'ÖNE ÇIKAN KLİNİK İLKE' kutusu
            topic_md_file = PATHS.output_dir / "manuscript" / f"{current_topic_id}.md"
            if not topic_md_file.is_file() and current_topic_id.startswith("9."):
                topic_md_file = PATHS.output_dir / "manuscript" / f"10.{current_topic_id[2:]}.md"
            if topic_md_file.is_file():
                t_raw = topic_md_file.read_text(encoding="utf-8")
                t_card = extract_topic_structured_cards(current_topic_id, t_raw)
                story.append(
                    build_callout_box(
                        f"[{current_topic_id}] ÖNE ÇIKAN KLİNİK İLKE",
                        t_card["highlight_box"],
                        BLUE,
                        BLUE_BG,
                        styles,
                    )
                )
            continue

        # ALT BÖLÜM BAŞLIĞI (### 1.1. ...)
        m_subsec = re.match(r"^###\s+(\d+\.\d+)(?!\.\d+)\.?\s+(.*)", stripped)
        if m_subsec:
            flush_topic_content(current_topic_id, current_topic_items)
            current_topic_id, current_topic_items = None, []

            sec_idx += 1
            sec_id = m_subsec.group(1)
            sec_text = f"{sec_id}. {m_subsec.group(2).strip()}"
            bkey = f"sec_{sec_idx}"
            story.append(
                BookmarkParagraph(
                    html.escape(sec_text),
                    styles["sec_title"],
                    bookmark_key=bkey,
                    bookmark_title=sec_text,
                    level=1,
                )
            )

            # 1) PIL Yüksek Çözünürlüklü Şema Kartı
            if sec_id in visuals_manifest:
                sc_card = build_schematic_card(visuals_manifest[sec_id], styles)
                if sc_card:
                    story.append(sc_card)

            # 2) Mavi Klinik Karşılaştırma ve Tanı Tablosu + Mor Varsayımsal Klinik Olgu Tablosu
            if sec_id in SUBSECTION_CLINICAL_PACKAGES:
                pkg = SUBSECTION_CLINICAL_PACKAGES[sec_id]
                story.append(build_blue_clinical_table(pkg, styles))
                story.append(build_purple_case_table(pkg["case"], styles))

            # 3) Açık Erişim (PMC CC BY 4.0) Gerçek Klinik Görüntüler
            if sec_id in visuals_manifest:
                for rfig in visuals_manifest[sec_id].get("real_figures", []):
                    rc = build_real_figure_card(rfig, styles, is_db=False)
                    if rc:
                        story.append(rc)
            continue

        # KANIT / UYGULAMA VEYA DİĞER ALT BAŞLIKLAR (#### Kanıt / #### Uygulama / ### ...)
        if stripped.startswith("#"):
            sub_t = re.sub(r"^#+\s*", "", stripped).strip()
            if current_topic_id:
                current_topic_items.append(("sub", sub_t))
            else:
                story.append(Paragraph(f"• {html.escape(tr_upper(sub_t))}", styles["facet_title"]))
            continue

        # NORMAL AKADEMİK PARAGRAF
        if current_topic_id:
            current_topic_items.append(("para", stripped))
        else:
            story.append(Paragraph(fmt_inline(stripped), styles["body"]))

    flush_topic_content(current_topic_id, current_topic_items)

    # 5. HER SAYFADA 3 RENKLİ ÜST ŞERİT + ÜST/ALT BİLGİ ÇİZEN CANVAS CALLBACK
    chapter_start_pages: Dict[str, int] = {}

    def on_page(canv: canvas.Canvas, doc_tmpl):
        canv.saveState()
        w, h = A4
        for idx, col_hex in enumerate(["#1c5ba6", "#087d6c", "#a46109"]):
            canv.setFillColor(colors.HexColor(col_hex))
            canv.rect(idx * w / 3.0, h - 3.5 * mm, w / 3.0, 3.5 * mm, fill=1, stroke=0)

        pnum = canv.getPageNumber()
        if pnum > 1:
            canv.setFont("ArialBold", 7.8)
            canv.setFillColor(BLUE)
            canv.drawString(16 * mm, h - 9.5 * mm, "RETİNA VE VİTREUS: KLİNİK YAKLAŞIM")
            canv.setFont("Arial", 7.8)
            canv.setFillColor(MUTED)
            canv.drawRightString(w - 16 * mm, h - 9.5 * mm, "Multimodal Şema, Önemli Noktalar, Mnemonic ve Vaka Sentezi")
            canv.setStrokeColor(LINE)
            canv.setLineWidth(0.5)
            canv.line(16 * mm, h - 11.2 * mm, w - 16 * mm, h - 11.2 * mm)

            canv.line(16 * mm, 12.5 * mm, w - 16 * mm, 12.5 * mm)
            canv.setFont("Arial", 7.5)
            canv.setFillColor(MUTED)
            canv.drawString(16 * mm, 8.2 * mm, "Ryan's Retina 7th Ed. [RV1-3] & PubMed [PMID] · YEŞİL: Önemli Nokta · MAVİ: Tanı · AMBER: İpucu · MOR: Mnemonic")
            canv.setFont("ArialBold", 8.5)
            canv.setFillColor(BLUE)
            canv.drawRightString(w - 16 * mm, 8.2 * mm, f"Sayfa {pnum}")
        canv.restoreState()

    doc = SimpleDocTemplate(
        str(out_pdf),
        pagesize=A4,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=15.5 * mm,
        bottomMargin=15.5 * mm,
        title="Retina ve Vitreus: Klinik Yaklaşım (Görsel, Şematik, Mnemonic'li ve Tablolu Baskı)",
        author="LangGraph Clinical Pipeline",
        subject="Ophthalmology - Retina & Vitreous Multimodal Textbook",
    )
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)

    with pymupdf.open(out_pdf) as d:
        for lvl, title, pg in d.get_toc():
            if lvl == 1 and title.startswith("BÖLÜM "):
                m = re.match(r"^BÖLÜM\s+(\d+)", title)
                if m:
                    chapter_start_pages[f"Bölüm {m.group(1)}"] = pg

    # 6. KİTAP SONUNA A4 YATAY (LANDSCAPE) HIZLI KLİNİK BAŞVURU MATRİSİ EKLE
    total_pages = append_landscape_summary_matrix(out_pdf, chapter_start_pages)

    # 7. ÖNİZLEME GÖRSELLERİNİ ÜRET
    previews_dir = PATHS.compiled_dir / "page-previews"
    previews_dir.mkdir(parents=True, exist_ok=True)
    with pymupdf.open(out_pdf) as d:
        sample_pages = sorted({0, 1, 2, 3, 4, 5, 6, 7, len(d) - 1})
        for p_idx in sample_pages:
            if 0 <= p_idx < len(d):
                pix = d[p_idx].get_pixmap(matrix=pymupdf.Matrix(1.4, 1.4))
                out_png = previews_dir / f"page-{p_idx + 1}.png"
                pix.save(out_png)

    size_mb = out_pdf.stat().st_size / (1024 * 1024)
    print(f"[OK] Ferahlatılmış Görsel, Mnemonic'li & Tablolu LangGraph PDF Kitabı Hazır: {out_pdf} ({total_pages} sayfa, {size_mb:.2f} MB)")
    return out_pdf


if __name__ == "__main__":
    build_publishing_grade_pdf()
