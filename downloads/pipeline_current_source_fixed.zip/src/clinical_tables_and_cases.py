"""
LangGraph Yapılandırılmış Klinik Tablo, Vaka Senaryosu, Kaynak Sentez Kutusu
ve Hızlı Başvuru Matrisi Üretim Modülü (clinical_tables_and_cases.py).

Kullanıcının langgraph-lab (clinical_publish.py, hcq-clinical-note-v2/build_note.py,
komitan-ezotropya-detayli-v2/render_detailed.py, clinical_matrix.py) standartlarına birebir uyumlu:
1. Mavi Karşılaştırma ve Multimodal Tanı Tabloları (#1c5ba6 başlık, #edf4ff/#ffffff alternatif satırlar)
2. Mor Varsayımsal Klinik Olgu Tabloları (#6941a5 başlık, #f4effc gövde: Durum / Akıl Yürütme / Karar)
3. Yeşil / Amber Kaynak Karşılaştırma ve Klinik Etki Kutuları (Veritabanı [RV1-3] vs PubMed [PMID])
4. Sol Şeritli Vurgu Kutuları (Mavi 3pt 'ÖNE ÇIKAN KLİNİK İLKE' & Amber 3pt 'KLİNİK TUZAK VE YORUM SINIRI')
5. Kitap Sonu A4 Yatay (Landscape) 'Hızlı Klinik Başvuru Özeti (Karşılaştırma Matrisi)' verisi.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from config import PATHS


# 24 Alt Bölüm İçin Mavi Klinik Karşılaştırma Tabloları + Mor Varsayımsal Vaka Senaryoları
SUBSECTION_CLINICAL_PACKAGES: Dict[str, dict] = {
    "1.1": {
        "table_title": "Tablo 1.1 — Vitreoretinal Arayüz, Retina Katmanları ve Koroidin Yapısal-Klinik Korelasyonu",
        "headers": ["Anatomik Yapı / Katman", "Mikroanatomik ve Histolojik Özellik", "Multimodal Karşılık ve Klinik Önemi"],
        "rows": [
            ["Vitreus Tabanı ve Korteks [RV1:pdf416]", "Ora serrata önünde 2 mm, arkasında 3-4 mm dikey kollajen II/IX lif tutunması", "PVD sırasında traksiyonun durduğu ve at nalı yırtıkların geliştiği birincil bölge"],
            ["İç Limitan Membran (İLM) [RV1:pdf425]", "Müller hücre ayakçıkları + tip IV kollajen, laminin ve fibronektin bazal laminası", "ERM ve makula deliği cerrahisinde (PPV) miyofibroblastik kontraksiyon iskelesi"],
            ["Foveola ve Henle Lif Tabakası [RV1:pdf469]", "İç retina katmanlarının perifoveaya itilmesi; oblik uzanan fotoreseptör aksonları", "Yüksek koni yoğunluğu, santral görme keskinliği ve kistoid ödemde yıldız/petaloid patern"],
            ["RPE ve Bruch Membranı (5 Katman) [RV1:pdf500]", "Zonula occludens dış B-RB; iç/dış kollajen ve merkezi elastik tabaka", "Yaşlanmayla lipid/drusen birikimi, hidrolik iletkenlik kaybı ve Tip 1 KNV bariyeri"],
            ["Koryokapillaris ve Haller/Sattler [RV1:pdf526]", "Fenestrasyonlu lobüler kapiller yatak; makulada en yüksek akım ve kalınlık", "Dış retina oksijenasyonu; pakikoroid spektrum ve beyaz nokta sendromlarının hedef dokusu"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 1.1 — Foveal Kontur Bozulması ve Dış Retina Bütünlük Analizi",
            "durum": "62 yaşında hasta metamorfopsi ile başvuruyor; SD-OKT'de foveal çukurlukta sığlaşma, İLM üzerinde hiperreflektif membran ve dış retinada kesintisiz ELM/EZ hattı izleniyor.",
            "akil_yurutme": "Henle lif tabakasındaki gerilme iç retinayı kalınlaştırsa da fotoreseptör iç/dış segment birleşimini temsil eden elipsoid zon (EZ) ve ELM'nin sağlam olması [RV1:pdf469] geri dönüşümlü görsel potansiyeli kanıtlar.",
            "karar": "Cerrahi zamanlama kararında yalnız santral retina kalınlığı değil, dış retina bantlarının (ELM/EZ) bütünlüğü ve semptomatik metamorfopsi düzeyi temel alınır.",
        },
    },
    "1.2": {
        "table_title": "Tablo 1.2 — Fototransdüksiyon, Görsel Retinoid Döngüsü ve Kan-Retina Bariyeri Mekanizmaları",
        "headers": ["Biyokimyasal Süreç / Bariyer", "Anahtar Molekül ve Hücresel Lokalizasyon", "Patofizyolojik Bozulma ve Klinik Fenotip"],
        "rows": [
            ["Fototransdüksiyon Kaskadı [RV1:pdf457]", "Rodopsin -> Transdüsin -> PDE6 -> cGMP düşüşü -> CNG kanal kapanması", "PDE6 veya CNG kanal mutasyonlarında gece körlüğü, RP ve akromatopsi"],
            ["Disk Membran Транsportu [RV1:pdf459]", "ABCA4 flippaz (fotoreseptör dış segment disk kenarı)", "All-trans-retinal temizlenemez; A2E/lipofuskin birikimi -> Stargardt hastalığı"],
            ["RPE İzomerizasyon Döngüsü [RV1:pdf466]", "LRAT ve RPE65 izomerohidrolaz (RPE endoplazmik retikulumu)", "11-cis-retinal üretilemez -> RPE65 ilişkili Leber konjenital amarozisi (LCA2)"],
            ["İç Kan-Retina Bariyeri [RV1:pdf692]", "Retinal endotel claudin-5/occludin sıkı bağlantıları + perisit/Müller desteği", "VEGF-A ve sitokin aracılı yıkım -> Diyabetik ve RVT kaynaklı kistoid makula ödemi"],
            ["Dış Kan-Retina Bariyeri ve Fagositoz [RV1:pdf475]", "RPE apikal sıkı bağlantıları, bazolateral pompa ve MERTK fagositoz reseptörü", "Pompa yetmezliğinde subretinal sıvı (SSKR); MERTK defektinde dış segment birikimi"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 1.2 — Görsel Döngü Enzim Defekti ile Lipofuskin Toksisitesi Ayrımı",
            "durum": "Erken çocuklukta ağır gece körlüğü olan iki olgudan birinde fundus tama yakın normalken (Olgu A), diğerinde makulada sarımsı flecks birikimi ve FAF'ta yoğun hiperotofloresans (Olgu B) saptanıyor.",
            "akil_yurutme": "Olgu A'da RPE65 defekti nedeniyle görsel kromofor üretilemez ve otofloresans sinyali düşüktür [RV1:pdf466]; Olgu B'de ise ABCA4 kusuru sonucu dış segmentlerden temizlenemeyen retinoid yan ürünleri RPE'de lipofuskin olarak birikir.",
            "karar": "Olgu A subretinal RPE65 gen replasmanı (voretigene neparvovec) açısından değerlendirilirken, Olgu B'de yüksek doz A vitamini takviyesinden kaçınılması önerilir.",
        },
    },
    "1.3": {
        "table_title": "Tablo 1.3 — Kalıtsal Retinal Hastalıklarda Kalıtım Modelleri ve Moleküler Test Stratejileri",
        "headers": ["Kalıtım / Test Stratejisi", "Genetik Özellik ve Örnek Genler", "Klinik Yorumlama ve Danışmanlık İlkeleri"],
        "rows": [
            ["Otozomal Dominant (OD) [RV1:pdf654]", "Kuşaklar arası dikey geçiş (%50 risk); RHO, BEST1, PRPH2, CRX", "Eksik penetrans ve değişken ekspresyon nedeniyle asemptomatik ebeveynler FAF/EOG ile taranmalıdır"],
            ["Otozomal Resesif (OR) [RV1:pdf657]", "Taşıyıcı ebeveynlerden %25 risk, akraba evliliği ilişkisi; ABCA4, USH2A, RPE65", "İki patojenik varyantın farklı allellerde (trans) olduğu ebeveyn segregasyonu ile kanıtlanmalıdır"],
            ["X'e Bağlı (XL) Kalıtım [RV1:pdf657]", "Erkekten erkeğe geçiş yoktur; RPGR, CHM (koroideremi), RS1 (XLRS)", "Taşıyıcı kadınlarda X-inaktivasyonuna (lyonizasyon) bağlı mozaik fundus/FAF bulguları görülür"],
            ["Hedefli NGS Paneli vs WES/WGS [RV1:pdf659]", "Bilinen >300 retina geni + kopya sayısı değişimi (CNV) ve derin intronik analiz", "ABCA4 ve USH2A'da derin intronik varyantlar standart ekzomda kaçabilir; özel panel/WGS gerekir"],
            ["ACMG/AMP Varyant Sınıflaması [RV1:pdf666]", "Patojenik, Olası Patojenik, VUS (Önemi Belirsiz), Olası Benign, Benign", "Yalnızca VUS sonucuna dayanarak gen tedavisi veya invaziv klinik karar verilmez"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 1.3 — Bileşik Heterozigot Varyantlarda Faz (Cis/Trans) Doğrulaması",
            "durum": "Stargardt fenotipli 19 yaşındaki hastanın NGS panelinde ABCA4 geninde iki farklı heterozigot yanlış anlamlı (missense) varyant raporlanıyor.",
            "akil_yurutme": "Otozomal resesif bir hastalıkta iki varyantın aynı kromozom üzerinde (cis) bulunması hastalığı açıklamaz; biallelik (trans) olduğunun kanıtlanması şarttır [RV1:pdf659].",
            "karar": "Anne ve babadan hedefli Sanger segregasyon analizi yapılarak varyantların ayrı ebeveynlerden geçtiği doğrulanır ve kesin moleküler tanı konur.",
        },
    },
    "2.1": {
        "table_title": "Tablo 2.1 — SD-OKT / SS-OKT Retinal Biyobelirteçler ve Koryoidal Görüntüleme Parametreleri",
        "headers": ["OKT Biyobelirteci / Modu", "Morfolojik Tanım ve Dalga Boyu İlkesi", "Görsel Prognoz ve Klinik Karara Etkisi"],
        "rows": [
            ["Dış Limitan Membran (ELM) ve EZ [RV1:pdf112]", "Fotoreseptör-Müller bağlantı hattı (ELM) ve iç segment mitokondri bandı (EZ)", "Tedavi sonrası görme keskinliği kazanımının en güçlü bağımsız yapısal belirleyicisi"],
            ["DRIL (İç Retina Dezorganizasyonu) [RV1:pdf127]", "Santral 1 mm'de GCL-İPL, İNL ve OPL katman sınırlarının seçilememesi", "Makula ödemi tamamen çekilse dahi kalıcı görsel kısıtlılığı ve bipolar akson hasarını gösterir"],
            ["Hiperreflektif Odaklar (HRF) [RV1:pdf129]", "<=30 µm, RPE'ye eş reflektiviteli, gölgelenme yapmayan intraretinal noktalar", "Aktif mikroglial inflamasyon veya RPE göçü; DMÖ'de steroid yanıtını, YBMD'de atrofi riskini işaret eder"],
            ["Dış Retinal Tübülasyon (ORT) [RV1:pdf129]", "Dış nükleer tabakada hiperreflektif halkasal fotoreseptör rozetleri", "Dejeneratif/kronik yeniden düzenlenme bulgusudur; aktif eksüdasyon değildir, anti-VEGF gerektirmez"],
            ["EDI-OKT ve CVI (SS-OKT 1050 nm) [RV1:pdf141]", "Sıfır gecikme hattının skleraya yaklaştırılması; Lüminal alan / Toplam koroid alanı", "Pakikoroid spektrumda (SSKR/PCV) artmış kalınlık ve CVI; yaşlılık/yüksek miyopide belirgin incelme"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 2.1 — Dış Retinal Tübülasyon (ORT) ile İntraretinal Kistoid Sıvı Ayrımı",
            "durum": "Yaş tip YBMD nedeniyle 14 enjeksiyon almış hastanın kontrol SD-OKT'sinde subretinal sıvı yok; ancak dış nükleer tabakada yuvarlak hiporeflektif boşluk ve etrafında parlak halka görülüyor.",
            "akil_yurutme": "Etrafı kesintisiz hiperreflektif sınırla çevrili bu yapı aktif intraretinal ödem kisti değil, kronik fotoreseptör sağkalım tepkisi olan dış retinal tübülasyondur (ORT) [RV1:pdf129].",
            "karar": "ORT varlığı tek başına aktif KNV sızıntısı kabul edilmez; gereksiz sık enjeksiyon yerine mevcut T&E aralığı korunur.",
        },
    },
    "2.2": {
        "table_title": "Tablo 2.2 — OKT Anjiyografi (OKTA) Pleksus Katmanları, KNV Tespiti ve Artefakt Yönetimi",
        "headers": ["OKTA Dilimi / Parametre", "Anatomik Sınırlar ve Fiziksel İlke", "Klinik Bulgular ve Yorumlama Kuralı"],
        "rows": [
            ["Yüzeyel Kapiller Pleksus (SCP) [RV1:pdf154]", "İLM ile İPL iç/orta sınırı arasındaki arteriyol, venül ve kapiller ağ", "DR ve RVT'de mikroanevrizmalar, kapiller non-perfüzyon ve FAZ kontur bozulması"],
            ["Derin Kapiller Pleksus (DCP) [RV1:pdf155]", "İNL iç ve dış sınırlarında yer alan vorteks kapiller yatak", "Venöz konjesyon, PAMM (parasantral akut orta makulopati) ve erken diyabetik iskeminin ilk hedefi"],
            ["Dış Retina ve Koryokapillaris (ORCC) [RV1:pdf163]", "Normalde tamamen avasküler dış retina + Bruch altı koryokapillaris", "Tip 1, Tip 2 ve Tip 3 MNV'nin boyasız tespiti; koryokapillaris akım boşlukları (flow voids)"],
            ["Projeksiyon (Kuyruk) Artefaktı [PMID:38343949]", "Yüzeyel damarlardan geçen ışığın RPE/derin dokuda sahte dekorelasyon üretmesi", "Sahte KNV tanısını önlemek için projeksiyon giderme algoritması ve B-scan akım bindirmesi şarttır"],
            ["Segmentasyon ve Gölgelenme [PMID:38343949]", "Ödem/PED/atrofide otomatik katman çizgilerinin kayması; kanama/eksüda gölgesi", "Sinyal gücü düşük veya gölgeli alanlar gerçek koryokapillaris iskemisi olarak raporlanmamalıdır"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 2.2 — Kronik SSKR'de Çift Katman İşaretinde Sekonder PKNV Tespiti",
            "durum": "Kronik SSKR tanılı hastada FA'da yaygın pencere defektleri nedeniyle sızıntı odağı net seçilemiyor; SD-OKT'de sığ düzensiz RPE dekolmanı ('double-layer sign') mevcut.",
            "akil_yurutme": "Boya sızıntısı olmasa veya FA'da maskelense bile, OKTA'da RPE ile Bruch membranı arasındaki dilimde dallanan yüksek akımlı vasküler ağ görülmesi Tip 1 pakikoroid neovaskülarizasyonu (PKNV) kanıtlar [RV1:pdf163].",
            "karar": "Hastaya yalnız gözlem yerine intravitreal anti-VEGF (veya kombine yarım doz PDT) tedavisi başlanır.",
        },
    },
    "2.3": {
        "table_title": "Tablo 2.3 — Floresein (FA), İndosiyanin Yeşili (ICGA) ve Ultra-Geniş Açılı (UWF) Anjiyografi Matrisi",
        "headers": ["Anjiyografi Yöntemi / Patern", "Biyofiziksel Özellik ve Faz Dinamiği", "Ayırıcı Tanısal Karşılığı"],
        "rows": [
            ["FA Hipoflöresans Paternleri [RV1:pdf80]", "Blokaj (tüm fazlarda sabit koyu alan) vs Dolum Defekti (damar/kapiller oklüzyon)", "Preretinal kanama/pigment blokajı ile diyabetik/RVT iskemik non-perfüzyonun kesin ayrımı"],
            ["FA Hiperflöresans Paternleri [RV1:pdf87]", "Pencere defekti (erken, sınırları sabit), Sızıntı (büyüyen), Göllenme (boşlukta), Boyanma", "Aktif KNV/vaskülit sızıntısı ile kuru RPE atrofisi veya kronik fibrotik skar boyanmasının ayrımı"],
            ["ICGA (790-805 nm Yakın Kızılötesi) [RV1:pdf100]", "%98 proteine bağlı; RPE ve seröz/hemorajik sıvıyı aşarak koroidi görüntüler", "Polipoidal koroideal vaskülopati (PCV polipleri), kronik SSKR hiperpermeabilitesi ve Birdshot noktaları"],
            ["Ultra-Geniş Açı (UWF 200°) FA [RV1:pdf96]", "Ekvator önü ve ora serrataya kadar tek çekimde panretinal perfüzyon haritası", "Periferik iskemi indeksi, gizli neovaskülarizasyon, FEVR, Eales ve hedefli (targeted) lazer planlaması"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 2.3 — Submaküler Hemorajide FA Maskelenmesini Aşan ICGA Tanısı",
            "durum": "68 yaşında hastada makulada kalın subretinal hemoraji ve seröz-hemorajik PED mevcut; FA'da kanama blokajı nedeniyle altta yatan lezyon seçilemiyor.",
            "akil_yurutme": "ICGA'nın yakın kızılötesi dalga boyu ince-orta kalınlıktaki kanamayı ve RPE'yi geçer [RV1:pdf100]; erken fazda dallanan vasküler ağ ve orta-geç fazda fokal nodüler hiperflöresans PCV tanısını koydurur.",
            "karar": "Polipoidal koroideal vaskülopati (PCV) tanısıyla intravitreal anti-VEGF yüklemesi ve gerekirse fokal ICGA-güdümlü PDT planlanır.",
        },
    },
    "2.4": {
        "table_title": "Tablo 2.4 — Fundus Otofloresans (FAF) Sinyal Paternleri ve B-Scan Ultrasonografi Kriterleri",
        "headers": ["Modalite ve Parametre", "Sinyal Kaynağı ve Akustik Özellik", "Klinik Tanı ve İzlemdeki Rolü"],
        "rows": [
            ["Mavi-FAF Hiperotofloresans (488 nm) [RV1:pdf217]", "RPE lizozomlarında artmış lipofuskin (A2E/bisretinoid) veya fotoreseptör dış segment birikimi", "Stargardt flecks, Best vitelliform lezyon, coğrafi atrofi büyüme sınırı ve RP Robson-Holder halkası"],
            ["Mavi-FAF Hipootofloresans [RV1:pdf220]", "RPE hücre ölümüne bağlı tam sinyal kaybı (karanlık alan) veya ön blokaj", "Coğrafi atrofi (GA) alanının kantitatif büyüme hızı ölçümü ve Stargardt atrofi takibi"],
            ["B-Scan: RRD vs Arka Vitreus Dekolmanı [RV1:pdf254]", "10 MHz prob; yüksek reflektiviteli, optik diske/ora serrataya bağlı, az salınımlı membran", "Katarakt veya yoğun vitreus hemorajisinde yırtıklı retina dekolmanının acil tespiti"],
            ["B-Scan: Koroid Melanomu vs Hemoraji [RV1:pdf261]", "Mantar/kubbe şekil, A-modda düşük-orta iç reflektivite (kappa açısı) ve koroideal ekskavasyon", "Masif subretinal kanama/diskiform skar (yüksek-düzensiz eko) ile malign melanom ayrımı"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 2.4 — Yoğun Vitreus Hemorajisinde Dinamik B-Scan ile Yırtık ve Dekolman Tespiti",
            "durum": "Akut fotopsi ve görme kaybıyla gelen hastada fundus seçilemiyor; B-scan'de üst temporal kadranda vitreus membranının tutunduğu yüksek reflektiviteli fokal flep izleniyor.",
            "akil_yurutme": "Kinetik (göz hareketli) ve düşük kazançlı (low-gain) B-scan incelemesinde optik diske tutunan, yüksek ekolu ve sert hareketli membran RRD'yi; ön-üst kadrandaki fokal dikensi çekinti ise at nalı yırtık operkülünü gösterir [RV1:pdf254].",
            "karar": "Ultrasonografik RRD/yırtık şüphesinde vitreus kanamasının kendiliğinden açılması beklenmeden erken pars plana vitrektomi planlanır.",
        },
    },
    "2.5": {
        "table_title": "Tablo 2.5 — ISCEV Standart Elektrofizyolojik Testler ve Anatomik Lokalizasyon Matrisi",
        "headers": ["Elektrofizyolojik Test", "Hücresel Kaynak ve Ölçülen Dalga", "Tipik Patolojik Bulgu ve Endikasyon"],
        "rows": [
            ["Tam Alan ERG (ffERG) - Skotopik/Fotopik [RV1:pdf271]", "a-dalgası: Fotoreseptörler (çomak/koni); b-dalgası: ON-bipolar ve Müller hücreleri", "Yaygın photoreceptor distrofileri (RP, koni-çomak distrofisi, LCA) ve kanser ilişkili retinopati"],
            ["Elektromanyetik Negatif ERG [RV1:pdf278]", "Normal a-dalgası + seçici olarak baskılanmış b-dalgası (b/a oranı < 1.0)", "X'e bağlı retinoskizis (XLRS), konjenital durağan gece körlüğü (CSNB), akut SAT ve MAR"],
            ["Multifokal ERG (mfERG) ve pERG [RV1:pdf280]", "Arka kutup 61/103 altıgen koni yanıtı; pERG P50 (makula) ve N95 (gangliyon hücresi)", "ffERG'nin normal olduğu okült makulopatiler, hidroksiklorokin taraması ve optik sinir ayrımı"],
            ["Elektrookülografi (EOG - Arden Oranı) [RV1:pdf284]", "RPE bazolateral klorür iletkenliği; Işık tepesi / Karanlık çukuru oranı (Normal >= 1.85)", "Normal ffERG ile birlikte Arden oranının <1.5 olması Best vitelliform distrofisi (BEST1) için tanısaldır"],
            ["Görsel Uyarılmış Potansiyeller (VEP) [RV1:pdf286]", "Oksipital korteks P100 dalga latansı ve genliği", "Açıklanamayan görme kaybında makula fonksiyonu (pERG/mfERG) doğrulandıktan sonra optik nöropati tespiti"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 2.5 — Normal Funduslu Görme Kaybında mfERG ve VEP ile Lokalizasyon",
            "durum": "34 yaşında hastada bilateral santral görme azalması (20/60) mevcut; biyomikroskopi, renkli fundus ve ffERG tamamen normal bulunuyor.",
            "akil_yurutme": "Tam alan ERG tüm retinanın kümülatif yanıtını ölçtüğü için foveaya sınırlı koni disfonksiyonunu kaçırır [RV1:pdf280]; mfERG'de santral halkalarda genlik çöküşü saptanması okült maküler distrofiyi (ör. RP1L1) optik nöropatiden ayırır.",
            "karar": "Gereksiz nörolojik/steroid tedavisi önlenerek hastaya makula distrofisi genetik paneli (RP1L1, ABCA4) istenir.",
        },
    },
    "3.1": {
        "table_title": "Tablo 3.1 — Diyabetik Retinopati (DR) Evrelemesi ve Diyabetik Makula Ödemi (DMÖ) Tedavi Protokolleri",
        "headers": ["Klinik Evre / Durum", "Tanısal Kriterler ve Görüntüleme", "Kanıta Dayalı Yönetim (DRCR.net & Güncel Kılavuz)"],
        "rows": [
            ["Hafif - Orta NPDR [RV2:pdf36]", "Yalnız mikroanevrizmalar (Hafif) veya 4-2-1 kuralı altındaki hemoraji/eksüda (Orta)", "Glisemik (HbA1c), kan basıncı ve lipid kontrolü; 6-12 ayda bir dilate fundus ve OKT takibi"],
            ["Şiddetli NPDR (4-2-1 Kuralı) [RV2:pdf38]", "4 kadranda >=20 hemoraji VEYA 2 kadranda venöz boncuklanma VEYA 1 kadranda belirgin IRMA", "1 yıl içinde %50 PDR gelişim riski; 3-4 ayda bir yakın takip, uyumsuz/tek gözlü hastada erken PRP"],
            ["Proliferatif DR (PDR) [RV2:pdf42]", "NVD, NVE, preretinal/vitreus hemorajisi veya traksiyonel fibröz proliferasyon", "Panretinal fotokoagülasyon (PRP) ve/veya intravitreal anti-VEGF (Protokol S); TRD'de vitrektomi"],
            ["Merkez Tutulumlu DMÖ (GK >= 20/25) [RV2:pdf91]", "OKT'de santral 1 mm'de ödem, ancak başlangıç görme keskinliği çok iyi (>=20/25)", "DRCR.net Protokol V: Yakın gözlem güvenlidir; görme düşüşü olursa anti-VEGF başlanır"],
            ["Merkez Tutulumlu DMÖ (GK <= 20/32) [RV2:pdf93]", "Santral 1 mm'de kistoid ödem, subretinal sıvı veya HRF varlığı", "İlk basamak anti-VEGF (Protokol T: GK <=20/50'de aflibercept/faricimab üstünlüğü); dirençli/psödofakikte steroid"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 3.1 — Eşzamanlı Yüksek Riskli PDR ve Merkez Tutulumlu DMÖ Yönetimi",
            "durum": "54 yaşında Tip 2 diyabetik hastada görme keskinliği 20/80; muayenede optik diskte neovaskülarizasyon (NVD > 1/3 DA) ve OKT'de 490 µm merkez tutulumlu DMÖ saptanıyor.",
            "akil_yurutme": "Tek seansta agresif tam PRP makula ödemini akut olarak artırabilir [RV2:pdf93]; buna karşın intravitreal anti-VEGF hem DMÖ'yü çözer hem de NVD'yi hızla geriletir.",
            "karar": "Önce intravitreal anti-VEGF enjeksiyonu ile makula ödemi ve aktif neovaskülarizasyon baskılanır, ardından bölünmüş seanslarla kalıcı PRP tamamlanır.",
        },
    },
    "3.2": {
        "table_title": "Tablo 3.2 — Retinal Ven (SVT/DVT) ve Retinal Arter Tıkanıklıkları (SAT/DAT) Karşılaştırma Tablosu",
        "headers": ["Vasküler Oklüzyon Tipi", "Klinik ve Anjiyografik Bulgular", "Acil Yaklaşım, Oküler Tedavi ve Sistemik Araştırma"],
        "rows": [
            ["Non-İskemik SVT [RV2:pdf151]", "4 kadranda dilate kıvrımlı venler, alev hemorajileri; FA'da <10 DA non-perfüzyon, RAPD yok/hafif", "Makula ödemi için intravitreal anti-VEGF veya deksametazon implant; aylık iskemi dönüşüm takibi"],
            ["İskemik SVT [RV2:pdf155]", "GK <=20/200, belirgin RAPD, yaygın atılmış pamuk manzarası; FA'da >=10 DA kapiller kayıp", "İlk 3-6 ayda ('100 gün glokomu') aylık dilate olmayan gonyoskopi; NVI/NVA geliştiğinde acil PRP"],
            ["Dal Retinal Ven Tıkanıklığı (DVT) [RV2:pdf171]", "Arteriyovenöz çaprazlaşma distalinde sektörel hemoraji ve makula ödemi", "Akut makula ödeminde anti-VEGF/steroid; >5 DA iskemi ve sekonder NVE gelişirse sektörel lazer"],
            ["Santral Retinal Arter Tıkanıklığı (SAT) [RV2:pdf121]", "Ani ağrısız ağır görme kaybı, soluk/ödemli iç retina ve foveada 'kiraz kırmızısı' nokta", ">=50 yaşta acil ESR/CRP ile dev hücreli arterit dışlanır; hasta AKUT İNME ÜNİTESİNE sevk edilir"],
            ["Silioretinal Arter ve Susac Sendromu [RV2:pdf125]", "Popülasyonun %15-30'unda silioretinal arter foveayı besler; Susac: DAT + ensefalopati + işitme kaybı", "Silioretinal arter korunmuşsa SAT'ta santral görme kurtulabilir; Susac'ta agresif immünsüpresyon"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 3.2 — Akut Santral Retinal Arter Tıkanıklığında (SAT) Hayat Kurtarıcı Triyaj",
            "durum": "71 yaşında hasta sağ gözünde 3 saat önce başlayan ani görme kaybı, şakak ağrısı ve çene kladikasyosu ile başvuruyor; fundusta soluk retina ve kiraz kırmızısı nokta mevcut.",
            "akil_yurutme": "İleri yaşta eşlik eden baş ağrısı ve çene kladikasyosu arteritik SAT (dev hücreli arterit) için kırmızı bayraktır [RV2:pdf121]; gecikme durumunda karşı göz dakikalar/günler içinde kaybedilebilir.",
            "karar": "Derhal acil ESR, CRP ve tam kan sayımı alınarak biyopsi sonucu beklenmeden yüksek doz IV metilprednizolon başlanır ve nörovasküler inme protokolü aktive edilir.",
        },
    },
    "3.3": {
        "table_title": "Tablo 3.3 — Hipertansif Retinopati, Makroanevrizma (RAM) ve Prematüre Retinopatisi (ICROP-3)",
        "headers": ["Klinik Antite / Evre", "Tanısal Fundus ve Görüntüleme Bulguları", "Klinik Yönetim ve Tedavi Endikasyonu"],
        "rows": [
            ["Malign Hipertansif Koroidopati [RV2:pdf202]", "Elschnig lekeleri (fokal RPE nekrozu), Siegrist çizgileri, seröz RD ve optik disk ödemi", "Hipertansif acildir; optik sinir infarktını önlemek için kan basıncı kontrollü/kademeli düşürülür"],
            ["Retinal Arter Makroanevrizması (RAM) [RV2:pdf212]", "Temporal arter dallarında sakküler genişleme; sub-İLM, intraretinal ve subretinal kanama", "Asemptomatikse spontan tromboz için izlem; makula ödemi/eksüdasyonda anti-VEGF veya eşik lazer"],
            ["ICROP-3 Zon ve Evre Tanımı [ICROP3:pdf1]", "Zon I, Posterior Zon II, Zon II, Zon III; Evre 1-3, çentik (notch) ve Evre 4A/4B/5 RD", "Posterior Zon II ve 'notch' varlığı daha agresif seyir göstergesidir; sık tarama gerektirir"],
            ["Tip 1 ROP ve Agresif ROP (A-ROP) [ICROP3:pdf2]", "Zon I (Plus ile herhangi evre veya Plus'sız Evre 3), Zon II Evre 2-3 + Plus; A-ROP'ta hızlı şant", "48-72 saat içinde tedavi: Zon I ve A-ROP'ta intravitreal anti-VEGF; uzun dönem reaktivasyon takibi"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 3.3 — Anti-VEGF Sonrası Geç ROP Reaktivasyonunun Yönetimi",
            "durum": "25. gebelik haftasında 720 g doğan ve 34. PMA haftasında A-ROP nedeniyle intravitreal anti-VEGF uygulanan bebekte, 49. PMA haftasında arka Zon II'de yeni demarkasyon hattı ve Evre 3 proliferasyon saptanıyor.",
            "akil_yurutme": "Anti-VEGF tedavisi sonrası periferik avasküler retina (PAR) varlığını sürdürebilir ve 45-55. haftalar arasında geç reaktivasyon gelişebilir [ICROP3:pdf2].",
            "karar": "Tam periferik vaskülarizasyon sağlanmayan ve geç reaktivasyon gösteren gözde kalıcı kontrol için periferik avasküler retinaya konfluent lazer fotokoagülasyon uygulanır.",
        },
    },
    "4.1": {
        "table_title": "Tablo 4.1 — Yaşa Bağlı Makula Dejenerasyonu (YBMD): Kuru Tip, cRORA ve MNV Sınıflaması",
        "headers": ["YBMD Alt Tipi / Evresi", "Multimodal Görüntüleme (OKT / FAF / FA / ICGA)", "Kanıta Dayalı Tedavi ve İzlem Stratejisi"],
        "rows": [
            ["Orta Evre Kuru YBMD ve SDD [RV2:pdf280]", "Büyük yumuşak drusen (>125 µm) ve/veya RPE üzerinde retiküler psödodrusen (SDD)", "AREDS2 formülasyonu (Lutein 10 mg, Zeaksantin 2 mg, C/E vit, Çinko, Bakır - beta-karotensiz), Amsler takibi"],
            ["Coğrafi Atrofi (CAM cRORA) [RV2:pdf301]", "OKT'de >=250 µm koroid hipertransmisyonu + RPE kaybı + fotoreseptör dejenerasyonu", "FAF'ta birleşik/bant hiperotofloresan kenarda hızlı büyüme; komplement C3/C5 inhibitörleri değerlendirmesi"],
            ["Tip 1 MNV (RPE Altı / Gizli) [RV2:pdf338]", "Bruch membranı ile RPE arasında fibro-vasküler PED veya çift katman işareti", "İntravitreal anti-VEGF (aflibercept 2/8 mg, faricimab, ranibizumab) yükleme + Treat-and-Extend (T&E)"],
            ["Tip 2 MNV (RPE Üstü / Klasik) [RV2:pdf342]", "RPE'yi delerek subretinal boşlukta büyüyen hiperreflektif lezyon ve subretinal sıvı", "Hızlı fotoreseptör hasarı ve subretinal fibrozis riski nedeniyle acil anti-VEGF yüklemesi"],
            ["Tip 3 MNV (RAP Lezyonu) [RV2:pdf346]", "Derin retinal kapiller pleksustan başlayan intraretinal neovaskülarizasyon + kistoid ödem", "Anti-VEGF'ye çok hızlı yanıt verir ancak yüksek SDD yükü ve bilateralite/atrofi riski nedeniyle yakın izlem gerekir"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 4.1 — Treat-and-Extend (T&E) Rejiminde Sıvı Kompartmanlarına Göre Aralık Ayarı",
            "durum": "Tip 1 MNV nedeniyle 8 haftalık T&E aralığında izlenen hastada GK 20/25; OKT'de intraretinal sıvı (IRF) tamamen yok, yalnızca fovea altında 35 µm sabit ince subretinal sıvı (SRF) mevcut.",
            "akil_yurutme": "İntraretinal kistoid sıvı (IRF) ve yeni hemoraji kötü görsel prognozla ilişkiliyken, görsel keskinliğin korunduğu minimal stabil subretinal sıvı tolere edilebilir [RV2:pdf380].",
            "karar": "Aralık hemen 4 haftaya kısaltılmaz; mevcut 8 haftalık enjeksiyon aralığı korunarak yakın OKT takibi sürdürülür.",
        },
    },
    "4.2": {
        "table_title": "Tablo 4.2 — Pakikoroid Spektrum Hastalıkları (PPE, SSKR, PKNV ve PCV) Ayırıcı Tanı Matrisi",
        "headers": ["Pakikoroid Antitesi", "EDI-OKT, FAF ve ICGA Karakteristik Bulguları", "Birincil Tedavi Yaklaşımı"],
        "rows": [
            ["Pakikoroid Pigment Epitelyopati (PPE) [RV2:pdf445]", "Genişlemiş Haller paki-damarları + iç koroid incelmesi + fokal RPE düzensizliği (sıvı yok)", "Semptomsuz olguda gözlem; sistemik/topikal/inhale/nazal kortikosteroid kullanımının kesilmesi"],
            ["Akut SSKR [RV2:pdf448]", "Kubbe şeklinde seröz makula dekolmanı, küçük seröz PED; FA'da mürekkep lekesi/duman sızıntısı", "İlk 3-4 ay gözlem + steroid kesilmesi + stres yönetimi; hızlı görsel ihtiyaç varsa yarım doz PDT"],
            ["Kronik / Rekürren SSKR [RV2:pdf455]", ">4-6 ay süren sıvı, FAF'ta yerçekimsel hipootofloresan oluklar ('gravitational tracts')", "Altın standart: ICGA-güdümlü yarım doz veya yarım akım verteporfin PDT (PLACE çalışması kanıtı)"],
            ["Pakikoroid Neovaskülarizasyon (PKNV) [RV2:pdf462]", "Paki-damarlar üzerinde sığ düzensiz PED ('double-layer sign') ve OKTA'da Tip 1 MNV ağı", "İntravitreal anti-VEGF enjeksiyonu; dirençli koroideal hiperpermeabilitede kombine yarım doz PDT"],
            ["Polipoidal Koroideal Vaskülopati (PCV) [RV2:pdf468]", "Keskin tepe noktalı ('thumb-like') çentikli PED, subretinal turuncu nodül, ICGA'da polip + BVN", "Anti-VEGF monoterapi (aflibercept/faricimab, PLANET) veya aktif poliplerde anti-VEGF + PDT (EVEREST II)"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 4.2 — Steroid İlişkili Kronik SSKR ve Sekonder PKNV Yönetimi",
            "durum": "Allerjik rinit için 2 yıldır nazal steroid sprey kullanan 46 yaşında erkek hastada 7 aydır düzelmeyen subretinal sıvı, EDI-OKT'de 460 µm koroid kalınlığı ve sığ düzensiz PED saptanıyor.",
            "akil_yurutme": "Nazal steroidler de SSKR'yi tetikler ve kronikleştirir [RV2:pdf448]; ayrıca sığ düzensiz PED ('çift katman işareti') altında sekonder Tip 1 PKNV gelişmiş olma olasılığı yüksektir.",
            "karar": "Nazal steroid derhal kesilir; OKTA'da neovasküler ağ doğrulanırsa intravitreal anti-VEGF + ICGA-güdümlü yarım doz PDT kombinasyonu uygulanır.",
        },
    },
    "4.3": {
        "table_title": "Tablo 4.3 — Vitreomaküler Arayüz Bozuklukları (IVTS / Govetto) ve Miyopik Makulopati (ATN)",
        "headers": ["Patoloji / Sınıflama", "OKT Morfolojik Kriterleri", "Cerrahi veya Medikal Yönetim"],
        "rows": [
            ["Vitreomaküler Traksiyon (VMT) [RV3:pdf412]", "Fokal (<=1500 µm) veya diffüz (>1500 µm) vitreofoveal yapışıklık + foveal kontur distorsiyonu", "Hafif/asemptomatikte 3 ay spontan ayrılma takibi; ilerleyici GK kaybı ve metamorfopside PPV"],
            ["Epiretinal Membran (ERM - Govetto 1-4) [RV3:pdf428]", "Evre 1: Çukur var; Evre 2: Çukur yok; Evre 3: Ektopik iç foveal katman (EIFL); Evre 4: Dezorganize", "Semptomatik metamorfopsi ve GK düşüşünde Evre 4'e ilerlemeden PPV + ERM/İLM soyulması"],
            ["Tam Kat Makula Deliği (FTMH) [RV3:pdf416]", "Küçük (<=250 µm), Orta (250-400 µm), Büyük (>400 µm) İLM'den RPE'ye tam kat defekt", "PPV + İLM soyulması (>400 µm veya miyopik delikte ters İLM flebi) + gaz tamponad (%90+ kapanma)"],
            ["Miyopik Traksiyonel Makulopati (MTM) [RV2:pdf512]", "Arka stafilom içinde iç/dış maküler retinoskizis -> foveal dekolman -> miyopik makula deliği", "İzole stabil skiziste takip; foveal dekolman veya makula deliğinde fovea koruyucu İLM soyulmalı PPV"],
            ["Miyopik KNV (mKNV) [RV2:pdf518]", "Lake çatlakları (lacquer cracks) komşuluğunda küçük Tip 2 subretinal hiperreflektif lezyon", "İlk basamak: Tek doz intravitreal anti-VEGF başlangıcı + hastalık aktivitesine göre PRN rejim"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 4.3 — Yüksek Miyopide Subretinal Kanama: Miyopik KNV vs Basit Lake Çatlağı Kanaması",
            "durum": "-11.50 D yüksek miyop hastada ani santral skotom ve fovea kenarında küçük subretinal hemoraji saptanıyor.",
            "akil_yurutme": "Bruch membranının mekanik yırtılmasına bağlı basit 'coin hemorrhage' (bozuk para kanaması) FA/OKTA'da neovasküler ağ ve sızıntı göstermez ve kendiliğinden çekilir; mKNV ise aktif sızıntı/akım gösterir [RV2:pdf518].",
            "karar": "OKTA ve FA ile aktif Tip 2 neovasküler membran doğrulandığında derhal intravitreal anti-VEGF (1+PRN) başlanır; basit mekanik kanamada ise gereksiz enjeksiyondan kaçınılır.",
        },
    },
    "5.1": {
        "table_title": "Tablo 5.1 — Periferik Retina Dejenerasyonları, Yırtık Tipleri ve Profilaktik Lazer Endikasyonları",
        "headers": ["Periferik Lezyon / Yırtık", "Klinik Görünüm ve Traksiyon Dinamiği", "RD Riski ve Profilaktik Bariyer Lazer Kararı"],
        "rows": [
            ["Lattice ve Snail-Track Dejenerasyonu [RV3:pdf112]", "Ekvator önünde sirkümferansiyel incelmiş retina, sklerotik damarlar ve kenarda sıkı vitreus tutunması", "Asemptomatik lattice lezyonlarına rutin lazer yapılmaz; karşı gözde RRD veya akut semptom varsa değerlendirilir"],
            ["Dejeneratif Retinoskizis [RV3:pdf120]", "Alt temporalde pürüzsüz kubbe şeklinde OPL/İNL ayrışması; mutlak skotom, pigment hattı yok", "Tek başına iç/dış yaprak delikleri nadiren RRD yapar; yalnız ilerleyici kombine skizis-dekolmanda müdahale"],
            ["Akut Semptomatik At Nalı (Flap) Yırtık [RV3:pdf126]", "Akut PVD, fotopsi ve Shafer işareti ile birlikte apeksinden vitreusun çektiği U-şekilli yırtık", "Tedavi edilmezse %30-50 RRD riski taşır; ACİL (aynı gün) 3 sıra konfluent bariyer lazer/kriyoterapi şarttır"],
            ["Operküllü ve Atrofik Yuvarlak Delikler [RV3:pdf128]", "Operkülde vitreus traksiyonu serbestleşmiştir; atrofik delik lattice içinde traksiyonsuzdur", "Asemptomatik operküllü/atrofik deliklerde RRD riski çok düşüktür, gözlem yeterlidir; semptomatikse lazer"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 5.1 — Akut PVD ve Shafer İşaretinde Skleral Çökertmeli Muayene ve Bariyer Lazer",
            "durum": "58 yaşında miyop hasta 2 gündür şimşek çakması ve kurum yağması tarifliyor; biyomikroskopide ön vitreusta kahverengi pigment granülleri (Shafer +) var, ancak arka kutup normal.",
            "akil_yurutme": "Ön vitreusta pigment ('tobacco dust') varlığında periferde retinal yırtık bulunma olasılığı %70'in üzerindedir [RV3:pdf126]; standart 90D muayenede ora serrata komşuluğundaki yırtıklar kaçabilir.",
            "karar": "360 derece skleral çökertmeli indirekt oftalmoskopi (veya üç aynalı Goldmann lensi) ile üst temporaldeki at nalı yırtık saptanır ve ora serrataya uzanan 3 sıra bariyer lazer uygulanır.",
        },
    },
    "5.2": {
        "table_title": "Tablo 5.2 — Retina Dekolmanı Tipleri (RRD, TRD, ERD) ve Proliferatif Vitreoretinopati (PVR) Sınıflaması",
        "headers": ["Dekolman Tipi / PVR Evresi", "Patofizyoloji ve Muayene Özellikleri", "Klinik Yönetim ve Cerrahi Strateji"],
        "rows": [
            ["Regmatojen RD (RRD) [RV3:pdf145]", "Tam kat retinal yırtık + sıvılaşmış vitreus + traksiyon; oluklu yüzey, Lincoff kurallarına uyan sıvı", "Makula-on RRD'de acil cerrahi; skleral çökertme, pnömatik retinopeksi veya pars plana vitrektomi (PPV)"],
            ["Traksiyonel RD (TRD) [RV3:pdf152]", "Fibrovasküler membran kontraksiyonu (PDR, ROP, FEVR); içbükey (konkav) yüzey, yırtık yok", "Makulayı tehdit eden/tutan TRD veya kombine traksiyonel-regmatojen RD'de membran diseksiyonlu PPV"],
            ["Eksüdatif / Seröz RD (ERD) [RV3:pdf155]", "Dış/iç B-RB yıkımı (VKH, posterior sklerit, koroid tümörü, malign HT); 'shifting fluid' (yer değiştiren sıvı)", "Cerrahi kontrendikedir (tümör tohumlanması/başarısızlık riski); altta yatan inflamatuar/onkolojik neden tedavi edilir"],
            ["PVR Evre A ve Evre B [RV3:pdf238]", "Evre A: Vitreus bulanıklığı ve pigment kümeleri; Evre B: Retinal kırışıklık, kıvrılmış yırtık kenarı", "Yüksek PVR riskini gösterir; cerrahide eksiksiz arka hyaloid ve vitreus tabanı temizliği gerektirir"],
            ["PVR Evre C (CA ve CP) [RV3:pdf240]", "Ekvator arkasında (CP 1-12 saat) veya önünde (CA 1-12 saat) tam kat sabit yıldız katlantılar", "PPV + epiretinal/subretinal PVR membran soyulması + gerekirse gevşetici retinotomi ve silikon yağı tamponadı"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 5.2 — Yerçekimiyle Yer Değiştiren ('Shifting Fluid') Büllöz Dekolmanda Cerrahi Tuzak",
            "durum": "42 yaşında kadın hasta bilateral büllöz alt yarı retina dekolmanı ve baş ağrısı ile başvuruyor; skleral çökertmeli muayenede yırtık bulunamıyor ve hasta sırtüstü yatınca sıvı arka kutba kayıyor.",
            "akil_yurutme": "Yırtık yokluğu, pürüzsüz büllöz yüzey ve pozisyonla yer değiştiren subretinal sıvı ('shifting fluid') eksüdatif dekolmanın (VKH veya posterior sklerit) klasik imzasıdır [RV3:pdf155].",
            "karar": "Vitreoretinal cerrahi yapılmaz; OKT (septalı sıvı/koroid kalınlaşması) ve B-scan (T-sign) ile VKH sendromu doğrulanarak yüksek doz sistemik kortikosteroid başlanır.",
        },
    },
    "6.1": {
        "table_title": "Tablo 6.1 — Retinitis Pigmentosa (RP), Koni Distrofileri ve Maküler Distrofiler (Stargardt / Best)",
        "headers": ["Kalıtsal Distrofi", "Sorumlu Genler ve Kalıtım", "Karakteristik Multimodal Görüntüleme ve Elektrofizyoloji"],
        "rows": [
            ["Retinitis Pigmentosa (RP) [RV1:pdf762]", "RHO (OD), USH2A (OR), RPGR (XL); >80 gen", "Kemik spikülleri, arteriyoler incelme; FAF'ta hiperotofloresan Robson-Holder halkası, skotopik ERG kaybı"],
            ["Usher ve Bardet-Biedl Sendromu [RV1:pdf774]", "Usher: MYO7A, USH2A; BBS: BBS1, BBS10 (silyopati)", "Usher: Konjenital/ilerleyici işitme kaybı + RP; BBS: Polidaktili, obezite, hipogonadizm, böbrek anomalisi + RP"],
            ["Koni ve Koni-Çomak Distrofisi [RV1:pdf802]", "GUCY2D, ABCA4, CRX, PRPH2", "Erken fotofobi, disromatopsi, 'bull's eye' makulopati; ffERG'de 30-Hz koni flicker yanıtının erken çöküşü"],
            ["Stargardt Hastalığı (STGD1) [RV1:pdf826]", "ABCA4 (Otozomal resesif)", "Pisciform sarı-beyaz flecks, FA'da 'karanlık koroid', mavi-FAF'ta karakteristik peripapiller korunma"],
            ["Best Vitelliform Distrofi (BVMD) [RV1:pdf845]", "BEST1 / Bestrofin-1 (Otozomal dominant)", "Previtelliform -> Yumurta sarısı -> Psödohipopyon -> Çırpılmış yumurta; ffERG normal, EOG Arden < 1.5"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 6.1 — Vitelliform Makula Lezyonunda Sekonder KNV ile Psödohipopyon Ayrımı",
            "durum": "Best hastalığı tanılı 24 yaşındaki hastanın sağ gözünde makulada sarımsı materyal ve OKT'de fovea altında hiporeflektif boşluk görülüyor; hekim yaş tip YBMD/KNV şüphesiyle anti-VEGF düşünüyor.",
            "akil_yurutme": "Best hastalığında vitelliform materyalin emilim aşamasında OKT'de subretinal sıvıya benzeyen optik boşluk oluşması doğal seyirdir [RV1:pdf845]; subretinal hemoraji veya OKTA'da vasküler ağ yoksa KNV değildir.",
            "karar": "OKTA'da neovasküler ağ dışlanarak gereksiz anti-VEGF enjeksiyonundan kaçınılır; hasta doğal evre takibine alınır.",
        },
    },
    "6.2": {
        "table_title": "Tablo 6.2 — Koroid Distrofileri, Vitreoretinopatiler ve Oküler Gen Tedavisi (Voretigene Neparvovec)",
        "headers": ["Hastalık / Tedavi", "Genetik Temel ve Patofizyoloji", "Ayırıcı Tanısal Bulgular ve Klinik Yönetim"],
        "rows": [
            ["Koroideremi [RV1:pdf868]", "CHM geni (REP-1 proteini, X'e bağlı resesif)", "Erkeklerde gece körlüğü, periferden merkeze ilerleyen skleranın göründüğü koroid/RPE atrofisi; fovea geç korunur"],
            ["Jirat Atrofi [RV1:pdf874]", "OAT geni (Ornitin aminotransferaz, OR); plazma ornitini 10-20x yüksek", "Periferde keskin sınırlı, birbiriyle birleşen deniz kabuğu (scalloped) koryoretinal atrofi; argininsiz diyet + B6"],
            ["Stickler Sendromu ve FEVR [RV3:pdf520]", "Stickler: COL2A1/COL11A1; FEVR: FZD4, LRP5, TSPAN12 (Wnt yolu)", "Stickler: Optik boş vitreus, yarık damak, dev yırtık. FEVR: Zamanında doğan bebekte periferik avasküler retina"],
            ["X'e Bağlı Retinoskizis (XLRS) [RV1:pdf884]", "RS1 geni (Retinoskizin adezyon proteini, X'e bağlı)", "Foveada 'araba tekerleği' ışınsal kistler, OKT'de İNL skizisi, negatif ERG; topikal dorzolamid/brinzolamid"],
            ["Voretigene Neparvovec (Luxturna) [RV1:pdf902]", "Biallelik RPE65 mutasyonu için AAV2 vektörlü gen replasmanı", "Canlı fotoreseptör varlığında (OKT ONL kalınlığı) PPV ile 300 µL subretinal bleb; FST ve mobilitede artış"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 6.2 — Yaygın Koryoretinal Atrofide Biyokimyasal Olarak Tedavi Edilebilir Neden: Jirat Atrofi",
            "durum": "16 yaşında miyop hasta gece körlüğü ve periferik görme alanı daralmasıyla geliyor; fundusta midperiferde keskin sınırlı, lobüler birleşik koryoretinal atrofi plakları izleniyor.",
            "akil_yurutme": "Periferik deniz kabuğu ('scalloped') koryoretinal atrofi plaklarında mutlaka plazma aminoasit (ornitin) düzeyi ölçülmelidir [RV1:pdf874]; çünkü jirat atrofi diyetle ilerlemesi yavaşlatılabilen nadir metabolik distrofilerden biridir.",
            "karar": "Plazma ornitin yüksekliği ve OAT mutasyonu doğrulanarak hastaya argininden kısıtlı diyet ve piridoksin (B6 vitamini) yanıt testi başlanır.",
        },
    },
    "7.1": {
        "table_title": "Tablo 7.1 — Enfeksiyöz Retinitler: Herpetik (ARN/PORN), CMV, Toksoplazmoz, Tüberküloz ve Sifiliz",
        "headers": ["Enfeksiyöz Antite", "Klinik Fenotip ve İmmün Durum", "Tanısal Doğrulama ve Antimikrobiyal Tedavi"],
        "rows": [
            ["Akut Retinal Nekroz (ARN) [RV2:pdf712]", "VZV/HSV-1/2 (immünkompetan); yoğun vitrit, oklüzif arteriolit, periferik 360° konfluent nekroz", "Aköz/vitreus PCR + beklemeden IV asiklovir (veya yüksek doz oral valasiklovir) + intravitreal foskarnet"],
            ["PORN ve CMV Retiniti [RV2:pdf720]", "Ağır immünsüprese (CD4 <50); PORN: vitritsiz hızlı dış nekroz; CMV: damar boyu kanamalı nekroz", "CMV: Sistemik valgansiklovir + intravitreal gansiklovir/foskarnet ve HAART ile immün rekonstrüksiyon"],
            ["Oküler Toksoplazmoz [RV2:pdf742]", "Eski pigmente skara komşu aktif sarı-beyaz fokal nekrotizan retinit ve yoğun vitrit ('sis içinde far')", "Makula/optik disk/büyük damar tehdidinde pirimetamin + sülfadiazin (veya TMP-SMX) + 48 saat sonra oral steroid"],
            ["Oküler Tüberküloz [RV2:pdf760]", "Serpijinöz-benzeri koroidit (SLC), koroid tüberkülomu, oklüzif periflebit (Eales fenotipi)", "IGRA (QuantiFERON), TDT ve toraks BT; 4'lü anti-TB tedavi (İNH, RİF, PZA, EMB) + kontrollü steroid"],
            ["Oküler Sifiliz (Büyük Taklitçi) [RV2:pdf772]", "Akut sifilitik posterior plakoid koryoretinit (ASPPC: dış retinada nodüler RPE/EZ bozulması), panüveit", "Treponemal (TPHA/FTA-ABS) + Non-treponemal (VDRL/RPR) + BOS analizi; nörosifiliz dozu IV Penisilin G"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 7.1 — Atipik Plakoid Makulopatide Steroid Öncesi Sifiliz Dışlamasının Önemi",
            "durum": "45 yaşında hastada tek taraflı görme bulanıklığı, hafif vitrit ve makulada sarımsı plakoid lezyon saptanıyor; OKT'de EZ kaybı ve RPE üzerinde nodüler hiperreflektif noktalar görülüyor.",
            "akil_yurutme": "Bu görünüm non-enfeksiyöz APMPPE'yi taklit eden Akut Sifilitik Posterior Plakoid Koryoretinittir (ASPPC) [RV2:pdf772]; antibiyotiksiz steroid verilmesi enfeksiyonu fulminan hale getirir.",
            "karar": "Steroid başlanmadan önce yapılan TPHA ve RPR testleri pozitif saptanır; hasta 14 gün intravenöz kristalize Penisilin G tedavisi ile tam görsel iyileşme sağlar.",
        },
    },
    "7.2": {
        "table_title": "Tablo 7.2 — Non-Enfeksiyöz Posterior Üveitler: Behçet Hastalığı, VKH Sendromu ve Oküler Sarkoidoz",
        "headers": ["İnflamatuar Sendrom", "Karakteristik Klinik ve Anjiyografik Bulgular", "İmmünomodülatör ve Biyolojik Tedavi Stratejisi"],
        "rows": [
            ["Behçet Üveiti [RV2:pdf812]", "Gezici hipopyon, diffüz vitrit, geçici beyaz retinal infiltratlar, oklüzif nekrotizan vaskülit ve FA'da 'eğrelti otu' sızıntısı", "EULAR Kılavuzu: Akut arka kutup atağında yüksek doz steroid + ilk basamak anti-TNF-alfa (infliksimab/adalimumab) ve azatioprin"],
            ["Vogt-Koyanagi-Harada (VKH) [RV2:pdf828]", "Meningismus/tinnitus prodromu; akut multilobüler eksüdatif RD, OKT'de septalı sıvı (BALAD) ve masif koroid kalınlaşması", "Erken yüksek doz IV/oral steroid (>=6 ay yavaş azaltma) + nüksleri ve 'sunset glow fundus'u önlemek için erken IMT (mikofenolat/siklosporin/adalimumab)"],
            ["Oküler Sarkoidoz (IWOS) [RV2:pdf842]", "Koyun yağı KP, iris nodülleri, kartopu/inci dizisi vitrit, 'mum damlası' segmenter periflebit ve koryoretinal lezyonlar", "Serum ACE, lizozim, toraks YÇBT ve biyopsi; sistemik/perioküler/intravitreal kortikosteroid + metotreksat/mikofenolat"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 7.2 — Akut Behçet Retinal Vaskülitinde Erken Biyolojik Ajan Kararı",
            "durum": "26 yaşında oral aft ve genital ülser öyküsü olan erkek hasta sağ gözde 20/200 görme, yoğun vitrit, makula ödemi ve FA'da yaygın kapiller 'eğrelti otu' sızıntısı ile başvuruyor.",
            "akil_yurutme": "Behçet hastalığında arka segmenti ve makulayı tutan akut oklüzif vaskülit ataklarında yalnız klasik immünsüpresiflerin etkisi geç başlar ve kalıcı optik atrofi/makula iskemisi gelişebilir [RV2:pdf812].",
            "karar": "Enfeksiyöz nedenler ve latent tüberküloz hızla dışlanarak yüksek doz sistemik kortikosteroid ile eşzamanlı anti-TNF-alfa (infliksimab veya adalimumab) tedavisi başlanır.",
        },
    },
    "7.3": {
        "table_title": "Tablo 7.3 — Beyaz Nokta Sendromları: Anatomik Hedef, Multimodal Görüntüleme ve Ayırıcı Tanı Matrisi",
        "headers": ["Sendrom (Birincil Hedef)", "Demografi ve Klinik Seyir", "OKT, FAF, FA ve ICGA Ayırt Edici İmza", "Yönetim ve Kırmızı Bayraklar"],
        "rows": [
            ["MEWDS (EZ/İZ ve RPE) [RV2:pdf865]", "Genç miyop kadın, viral prodrom, tek taraflı fotopsi ve büyümüş kör nokta", "OKT: EZ/İZ kesintisi; FA: Erken 'çelenk' hiperflöresans; ICGA: Çok sayıda geç hipoflöresan nokta; FAF: Hiperotofloresan noktalar", "6-10 haftada skarsız spontan iyileşme; rutin tedavi gerekmez"],
            ["APMPPE (Koryokapillaris) [RV2:pdf872]", "Genç erişkin, bilateral akut krem rengi plakoid arka kutup lezyonları", "FA: Karakteristik 'erken hipo / geç hiper' boyanma; ICGA: Tüm fazlarda hipoflöresans; OKTA: Koryokapillaris akım kaybı", "Serebral vaskülit (şiddetli baş ağrısı/inme) riski! Makula/CNS tutulumunda sistemik steroid"],
            ["Birdshot (Koroid Stroması) [RV2:pdf880]", "Orta yaş, bilateral kronik progresif, HLA-A29 pozitifliği (>%95)", "Optik diskten ışınsal yayılan krem-sarı oval lezyonlar; ICGA'da klinik muayeneden çok daha fazla düzenli hipoflöresan stromal noktalar", "Merkezi GK korunsa bile ERG ve görme alanı bozulur; erken steroid koruyucu IMT şarttır"],
            ["Multifokal Koroidit / PIC [RV2:pdf890]", "Genç-orta yaş miyop kadın; MFC'de vitrit ve ön üveit var, PIC'de vitrit yoktur", "Zımba deliği atrofik skarlar; aktif lezyonda OKT'de RPE/Bruch yarığı ve yüksek oranda (%30-40) sekonder Tip 2 KNV", "İnflamatuar atakta sistemik steroid/IMT; sekonder KNV'de (OKTA ile doğrulanmış) intravitreal anti-VEGF"],
            ["Serpijinöz Koroidit [RV2:pdf898]", "Orta yaş, bilateral asimetrik, peripapillerden helikoid/yılanvari ilerleyen yıkıcı koroidit", "Aktif grimsi-sarı kenarda FA erken hipo/geç sızıntı, FAF'ta aktif sınırda hiperotofloresan halo, atrofi alanında tam hipootofloresans", "İmmünsüpresyon öncesi IGRA ile Tüberküloz (SLC) mutlaka dışlanmalıdır! Ardından agresif IMT"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 7.3 — Multifokal Koroiditte Akut İnflamatuar Lezyon ile Sekonder KNV Ayrımı",
            "durum": "Punktat iç koroidopati (PIC) tanılı 31 yaşında miyop kadın hastada yeni metamorfopsi ve OKT'de fovea kenarında RPE üzerinde konik hiperreflektif lezyon + minimal subretinal sıvı saptanıyor.",
            "akil_yurutme": "FA'da hem akut inflamatuar PIC lezyonu hem de sekonder Tip 2 KNV erken/geç sızıntı verir [PMID:31123892]; ancak OKTA'da lezyon içinde gerçek mikrovasküler ağ görülmesi sekonder KNV'yi kesinleştirir.",
            "karar": "OKTA'da vasküler ağ saptandığı için hastaya sistemik immünsüpresyona ek olarak intravitreal anti-VEGF enjeksiyonu uygulanır.",
        },
    },
    "8.1": {
        "table_title": "Tablo 8.1 — Retina ve Koroid Tümörleri: Retinoblastom, Koroid Melanomu, Lenfoma ve Nevüs (TFSOM-DIM)",
        "headers": ["Oküler Tümör", "Klinik ve Görüntüleme Özellikleri", "Tanısal Kural ve Güncel Onkolojik Yönetim"],
        "rows": [
            ["Retinoblastom (RB1) [RV3:pdf701]", "Çocukta lökokori ve şaşılık; endofitik/ekzofitik kalsifiye kitle ve vitreus/subretinal tohumlanma", "İİAB/vitrektomi KESİNLİKLE kontrendikedir; BT çekilmez (ikincil tümör riski), MRG/B-scan kullanılır; İAK + İVK (melfalan)"],
            ["Koroid Melanomu [RV3:pdf755]", "Pigmente/amelanotik kubbe veya mantar şekilli kitle; B-scan'de düşük iç reflektivite ve akustik çukurlaşma", "Orta boy tümörde I-125/Ru-106 plak brakiterapi veya proton ışın; GEP Sınıf 2 ve BAP1/Monozomi 3 karaciğer metastaz riskini belirler"],
            ["Vitreoretinal Lenfoma (VRL) [RV3:pdf810]", "İleri yaşta steroide dirençli 'maskeli' vitrit ve OKT'de RPE ile Bruch arasında nodüler ('leopar derisi') infiltrat", "%60-80 santral sinir sistemi lenfoması (PCNSL) ilişkisi; tanısal vitrektomi (IL-10/IL-6 > 1 ve MYD88 L265P PCR) + kraniyal MRG"],
            ["Koroid Nevüsü (TFSOM-DIM) [RV3:pdf740]", "Kalınlık >2 mm, Subretinal sıvı, Semptom, Turuncu pigment (FAF+), Marj <=3 mm, Boşluk (B-scan hollowness)", "0 faktörde %1, >=3 faktörde >%50 melanom dönüşüm riski; kronik drusen ve RPE halosu ise benignite lehinedir"],
            ["Koroid Hemanjiomu [RV3:pdf790]", "Sınırlı (turuncu-kırmızı arka kutup kitlesi) veya diffüz (Sturge-Weber sendromu, 'ketçap fundus')", "B-scan'de yüksek iç reflektivite, ICGA'da erken hızlı dolum ve geç 'wash-out' fenomeni; semptomatik sıvıda verteporfin PDT"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 8.1 — Şüpheli Pigmente Koroid Lezyonunda TFSOM-DIM Risk Skorlaması",
            "durum": "59 yaşında hastada optik diske 2 mm mesafede, 2.4 mm kalınlığında, üzerinde FAF ile doğrulanan hiperotofloresan lipofuskin (turuncu pigment) ve subretinal sıvı bulunan pigmente koroid kitlesi saptanıyor.",
            "akil_yurutme": "TFSOM-DIM kriterlerinden Kalınlık (>2 mm), Sıvı (SRF), Turuncu pigment (Orange pigment) ve Optik diske yakınlık (<3 mm) olmak üzere 4 majör risk faktörü bir aradadır [RV3:pdf740]; 5 yılda büyüme/melanom olasılığı >%50'dir.",
            "karar": "Lezyon basit nevüs olarak izlenmez; erken küçük koroid melanomu / yüksek riskli melanocytic lezyon kabul edilerek oküler onkoloji konseyinde plak brakiterapi planlanır.",
        },
    },
    "9.1": {
        "table_title": "Tablo 9.1 — Posterior Segment Travmaları, İOYC ve İntravitreal Enjeksiyon Güvenlik Protokolü",
        "headers": ["Travma / Prosedür", "Klinik ve Görüntüleme Bulguları", "Acil Yönetim ve Güvenlik Standartları"],
        "rows": [
            ["Berlin Ödemi ve Koroid Rüptürü [RV3:pdf993]", "Künt travma sonrası dış retinada (EZ/İZ) süt beyazı parlama; Bruch/RPE/koryokapillaris hilal yırtığı", "Berlin ödemi spontan açılabilir ancak foveal atrofi bırakabilir; koroid rüptüründe geç KNV gelişimi açısından Amsler/OKT takibi"],
            ["Açık Glob ve İOYC [RV3:pdf1012]", "Skleral/korneal tam kat laserasyon, gözyaşı pupilla, hipotoni ve göz içi yabancı cisim", "İlk 24 saatte primer kapatma + sistemik florokinolon; İOYC için ince kesitli orbital BT (MRG metalik İOYC'de kontrendikedir!)"],
            ["Siderozis ve Kalkozis Bulbi [RV3:pdf1018]", "Demir İOYC: Heterokromi, midriyazis, ERG b-dalgası çöküşü; Saf bakır İOYC: Akut fulminan steril endoftalmi", "Toksik reaksiyon ve PVR gelişmeden erken PPV ile yabancı cismin çıkarılması"],
            ["İntravitreal Enjeksiyon Asepsisi [INJ:pdf1]", "Pars plana girişi: Fakik gözde limbustan 3.5-4.0 mm, psödofakik/afak gözde 3.0-3.5 mm", "%5 povidon-iyot (en az 30 sn konjonktiva/forniks teması), steril kapak spekulumu ve konuşmama/maske kuralı; rutin topikal antibiyotik önerilmez"],
            ["Akut Enjeksiyon Sonrası Endoftalmi [INJ:pdf2]", "Enjeksiyondan 1-5 gün sonra şiddetli ağrı, görme kaybı, hipopyon ve yoğun vitrit (Staphylococcus/Streptococcus)", "Oftalmolojik acildir: Derhal vitreus tap (veya PPV) + intravitreal vankomisin (1 mg/0.1 mL) ve seftazidim (2.25 mg/0.1 mL)"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 9.1 — İntravitreal Anti-VEGF Sonrası 3. Gün Akut Enfeksiyöz Endoftalmi vs Steril İrit",
            "durum": "İntravitreal enjeksiyondan 72 saat sonra şiddetli göz ağrısı, kapak ödemi, 1.5 mm hipopyon, kırmızı refle kaybı ve el hareketleri düzeyine düşen görme ile başvuran hasta.",
            "akil_yurutme": "Enjeksiyondan 2-4 gün sonra ağrı, hipopyon ve yoğun vitrit ile başvuran her tablo aksi kanıtlanana kadar akut bakteriyel endoftalmidir [INJ:pdf2]; oral konjonktival floradan kaynaklanan Streptococcus türleri çok yıkıcıdır.",
            "karar": "Aynı saat içinde vitreus örneği (tap/biyopsi) alınarak intravitreal vankomisin + seftazidim enjekte edilir; görme ışık hissi düzeyindeyse acil pars plana vitrektomi uygulanır.",
        },
    },
    "9.2": {
        "table_title": "Tablo 9.2 — Retinada Yapay Zekâ (Derin Öğrenme), Kök Hücre Tedavileri ve Biyonik Görme Protezleri",
        "headers": ["Teknoloji / Modalite", "Mühendislik ve Biyolojik Mekanizma", "Klinik Uygulama Alanı ve Güncel Sınırlılıklar"],
        "rows": [
            ["Otonom DR Tarama Sistemleri (CNN) [RV1:pdf310]", "Konvolüsyonel sinir ağları (IDx-DR, EyeArt) ile renkli fundus fotoğraflarından otomatik sınıflama", "Birinci basamakta sevk gerektiren DR'yi (orta NPDR+ ve DMÖ) yüksek duyarlılıkla saptar; spektrum yanlılığına dikkat edilmelidir"],
            ["Kantitatif OKT Sıvı Segmentasyonu (U-Net) [RV1:pdf315]", "Piksel bazlı derin öğrenme ile IRF, SRF, PED hacmi ve EZ bütünlüğünün nanolitre/mikrometre ölçümü", "YBMD ve DMÖ'de objektif aktivite takibi, T&E aralık tahmini ve erken coğrafi atrofi progresyon modellemesi"],
            ["Kök Hücre RPE Replasmanı (hESC / iPSC) [RV1:pdf912]", "Pluripotent kök hücrelerden farklılaştırılan polarize RPE tek tabakalı yamasının subretinal nakli", "İleri kuru YBMD (coğrafi atrofi) ve Stargardt hastalığında Faz I/II çalışmalar; cerrahi travma ve immünsüpresyon gereksinimi"],
            ["Retinal Protezler ve Optogenetik [RV1:pdf918]", "Epiretinal (gangliyon) veya kablosuz subretinal fotovoltaik mikroçip (PRIMA, bipolar hücre uyarımı); ChrimsonR", "Fotoreseptörlerin tamamen kaybolduğu ileri RP ve coğrafi atrofide iç retina sağlamsa ışık/form/büyük harf algısı sağlar"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 9.2 — İleri Evre Retinitis Pigmentosada Retinal Protez / Optogenetik Aday Seçimi",
            "durum": "Işık hissi düzeyinde görmesi olan 58 yaşında ileri evre RP hastası biyonik göz veya optogenetik çalışma uygunluğu için değerlendiriliyor; SD-OKT'de dış retina (ONL/EZ) tamamen atrofik, ancak GCL ve İNL katmanları korunmuş.",
            "akil_yurutme": "RPE65 gibi fotoreseptör/RPE gen replasmanları canlı dış retina gerektirir; buna karşın subretinal fotovoltaik protezler (PRIMA) ve optogenetik tedaviler sağlam kalan iç retinal nöronları (bipolar/gangliyon) doğrudan uyarır [RV1:pdf918].",
            "karar": "Optik sinir fonksiyonu (flaş VEP / elektrik uyarım testi) ve iç retina mimarisi korunduğu için hasta gen replasmanı yerine subretinal protez veya optogenetik klinik çalışmasına yönlendirilir.",
        },
    },
    "10.1": {
        "table_title": "Tablo 9.1 — Posterior Segment Travmaları, İOYC ve İntravitreal Enjeksiyon Güvenlik Protokolü",
        "headers": ["Travma / Prosedür", "Klinik ve Görüntüleme Bulguları", "Acil Yönetim ve Güvenlik Standartları"],
        "rows": [
            ["Berlin Ödemi ve Koroid Rüptürü [RV3:pdf993]", "Künt travma sonrası dış retinada (EZ/İZ) süt beyazı parlama; Bruch/RPE/koryokapillaris hilal yırtığı", "Berlin ödemi spontan açılabilir ancak foveal atrofi bırakabilir; koroid rüptüründe geç KNV gelişimi açısından Amsler/OKT takibi"],
            ["Açık Glob ve İOYC [RV3:pdf1012]", "Skleral/korneal tam kat laserasyon, gözyaşı pupilla, hipotoni ve göz içi yabancı cisim", "İlk 24 saatte primer kapatma + sistemik florokinolon; İOYC için ince kesitli orbital BT (MRG metalik İOYC'de kontrendikedir!)"],
            ["Siderozis ve Kalkozis Bulbi [RV3:pdf1018]", "Demir İOYC: Heterokromi, midriyazis, ERG b-dalgası çöküşü; Saf bakır İOYC: Akut fulminan steril endoftalmi", "Toksik reaksiyon ve PVR gelişmeden erken PPV ile yabancı cismin çıkarılması"],
            ["İntravitreal Enjeksiyon Asepsisi [INJ:pdf1]", "Pars plana girişi: Fakik gözde limbustan 3.5-4.0 mm, psödofakik/afak gözde 3.0-3.5 mm", "%5 povidon-iyot (en az 30 sn konjonktiva/forniks teması), steril kapak spekulumu ve konuşmama/maske kuralı; rutin topikal antibiyotik önerilmez"],
            ["Akut Enjeksiyon Sonrası Endoftalmi [INJ:pdf2]", "Enjeksiyondan 1-5 gün sonra şiddetli ağrı, görme kaybı, hipopyon ve yoğun vitrit (Staphylococcus/Streptococcus)", "Oftalmolojik acildir: Derhal vitreus tap (veya PPV) + intravitreal vankomisin (1 mg/0.1 mL) ve seftazidim (2.25 mg/0.1 mL)"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 9.1 — İntravitreal Anti-VEGF Sonrası 3. Gün Akut Enfeksiyöz Endoftalmi vs Steril İrit",
            "durum": "İntravitreal enjeksiyondan 72 saat sonra şiddetli göz ağrısı, kapak ödemi, 1.5 mm hipopyon, kırmızı refle kaybı ve el hareketleri düzeyine düşen görme ile başvuran hasta.",
            "akil_yurutme": "Enjeksiyondan 2-4 gün sonra ağrı, hipopyon ve yoğun vitrit ile başvuran her tablo aksi kanıtlanana kadar akut bakteriyel endoftalmidir [INJ:pdf2]; oral konjonktival floradan kaynaklanan Streptococcus türleri çok yıkıcıdır.",
            "karar": "Aynı saat içinde vitreus örneği (tap/biyopsi) alınarak intravitreal vankomisin + seftazidim enjekte edilir; görme ışık hissi düzeyindeyse acil pars plana vitrektomi uygulanır.",
        },
    },
    "10.2": {
        "table_title": "Tablo 9.2 — Retinada Yapay Zekâ (Derin Öğrenme), Kök Hücre Tedavileri ve Biyonik Görme Protezleri",
        "headers": ["Teknoloji / Modalite", "Mühendislik ve Biyolojik Mekanizma", "Klinik Uygulama Alanı ve Güncel Sınırlılıklar"],
        "rows": [
            ["Otonom DR Tarama Sistemleri (CNN) [RV1:pdf310]", "Konvolüsyonel sinir ağları (IDx-DR, EyeArt) ile renkli fundus fotoğraflarından otomatik sınıflama", "Birinci basamakta sevk gerektiren DR'yi (orta NPDR+ ve DMÖ) yüksek duyarlılıkla saptar; spektrum yanlılığına dikkat edilmelidir"],
            ["Kantitatif OKT Sıvı Segmentasyonu (U-Net) [RV1:pdf315]", "Piksel bazlı derin öğrenme ile IRF, SRF, PED hacmi ve EZ bütünlüğünün nanolitre/mikrometre ölçümü", "YBMD ve DMÖ'de objektif aktivite takibi, T&E aralık tahmini ve erken coğrafi atrofi progresyon modellemesi"],
            ["Kök Hücre RPE Replasmanı (hESC / iPSC) [RV1:pdf912]", "Pluripotent kök hücrelerden farklılaştırılan polarize RPE tek tabakalı yamasının subretinal nakli", "İleri kuru YBMD (coğrafi atrofi) ve Stargardt hastalığında Faz I/II çalışmalar; cerrahi travma ve immünsüpresyon gereksinimi"],
            ["Retinal Protezler ve Optogenetik [RV1:pdf918]", "Epiretinal (gangliyon) veya kablosuz subretinal fotovoltaik mikroçip (PRIMA, bipolar hücre uyarımı); ChrimsonR", "Fotoreseptörlerin tamamen kaybolduğu ileri RP ve coğrafi atrofide iç retina sağlamsa ışık/form/büyük harf algısı sağlar"],
        ],
        "case": {
            "title": "Varsayımsal Klinik Olgu 9.2 — İleri Evre Retinitis Pigmentosada Retinal Protez / Optogenetik Aday Seçimi",
            "durum": "Işık hissi düzeyinde görmesi olan 58 yaşında ileri evre RP hastası biyonik göz veya optogenetik çalışma uygunluğu için değerlendiriliyor; SD-OKT'de dış retina (ONL/EZ) tamamen atrofik, ancak GCL ve İNL katmanları korunmuş.",
            "akil_yurutme": "RPE65 gibi fotoreseptör/RPE gen replasmanları canlı dış retina gerektirir; buna karşın subretinal fotovoltaik protezler (PRIMA) ve optogenetik tedaviler sağlam kalan iç retinal nöronları (bipolar/gangliyon) doğrudan uyarır [RV1:pdf918].",
            "karar": "Optik sinir fonksiyonu (flaş VEP / elektrik uyarım testi) ve iç retina mimarisi korunduğu için hasta gen replasmanı yerine subretinal protez veya optogenetik klinik çalışmasına yönlendirilir.",
        },
    },
}


# Kitap Sonu A4 Yatay (Landscape) 9 Bölümlük Hızlı Klinik Başvuru Matrisi (clinical_matrix.py stili)
BOOK_SUMMARY_MATRIX_ROWS: List[dict] = [
    {
        "chapter_num": "Bölüm 1",
        "chapter_title": "Temel Bilimler, Anatomi ve Genetik",
        "target_tissue": "Vitreoretinal arayüz (İLM), 10 katmanlı nörosensoryal retina, RPE-Bruch kompleksi ve koryokapillaris [RV1:pdf416]",
        "imaging_biomarker": "SD-OKT dış bantları (ELM, EZ, İZ), mavi-FAF lipofuskin (ABCA4) ve hedefli NGS/WES genetik paneli [RV1:pdf659]",
        "clinical_course": "İç/dış kan-retina bariyeri yıkımı makula ödemine; görsel döngü ve fagositoz defektleri ilerleyici distrofilere yol açar [RV1:pdf475]",
        "clinical_decision": "Varyantlar ACMG kriterleri ve aile segregasyonu (trans fazı) ile doğrulanmadan gen tedavisi kararı verilmez [RV1:pdf666]",
    },
    {
        "chapter_num": "Bölüm 2",
        "chapter_title": "Multimodal Retinal Görüntüleme",
        "target_tissue": "Retinal kapiller pleksuslar (SCP/DCP), FAZ, RPE metabolik sinyali ve derin koroid stroması [RV1:pdf154]",
        "imaging_biomarker": "OKT (DRIL, HRF, ORT, CVI), OKTA (ORCC akımı), FA/ICGA (sızıntı/polip), FAF ve 10 MHz B-scan [RV1:pdf127]",
        "clinical_course": "OKTA projeksiyon/hareket artefaktları sahte KNV'yi taklit eder; izole makulopatide tam alan ERG normal kalabilir [PMID:38343949]",
        "clinical_decision": "En-face OKTA mutlaka kesitsel B-scan ile doğrulanmalı; okült makula patolojisinde mfERG/pERG ve Best'te EOG istenmelidir [RV1:pdf280]",
    },
    {
        "chapter_num": "Bölüm 3",
        "chapter_title": "Retinal Vasküler Hastalıklar ve ROP",
        "target_tissue": "Retinal endotel/perisit bariyeri, arteriyovenöz çaprazlaşma, santral retinal arter ve immatür periferik damarlar [RV2:pdf36]",
        "imaging_biomarker": "ICDR 4-2-1 kuralı, CI-DME santral kalınlık, UWF-FA iskemi indeksi (>=10 DA) ve ICROP-3 Zon/Evre/Plus [ICROP3:pdf1]",
        "clinical_course": "İskemik SVT'de ilk 100 günde neovasküler glokom riski; akut SAT'ta yüksek eşzamanlı serebral inme ve GCA riski [RV2:pdf121]",
        "clinical_decision": "CI-DME'de GK <=20/32 ise anti-VEGF (Protokol T/V); akut SAT'ta acil ESR/CRP + İnme Ünitesi; Tip 1 ROP'ta 48-72 saatte tedavi [RV2:pdf93]",
    },
    {
        "chapter_num": "Bölüm 4",
        "chapter_title": "YBMD, Pakikoroid ve VMA Bozuklukları",
        "target_tissue": "Maküler fotoreseptör-RPE-Bruch-koryokapillaris kompleksi, Haller paki-damarları ve vitreofoveal arayüz [RV2:pdf280]",
        "imaging_biomarker": "CAM cRORA (>=250 µm), Tip 1/2/3 MNV, 'double-layer sign', ICGA polipleri (PCV) ve IVTS/Govetto OKT evresi [RV2:pdf338]",
        "clinical_course": "Kuru YBMD'de SDD ve birleşik FAF kenarı hızlı atrofi büyümesini; kronik SSKR ise PKNV ve kalıcı fotoreseptör kaybını tetikler [RV2:pdf455]",
        "clinical_decision": "Yaş YBMD ve mKNV'de anti-VEGF (T&E / PRN); kronik SSKR'de steroid kesilmesi + yarım doz PDT; FTMH ve semptomatik ERM'de PPV [RV2:pdf468]",
    },
    {
        "chapter_num": "Bölüm 5",
        "chapter_title": "Retina Dekolmanı ve Periferik Patolojiler",
        "target_tissue": "Ora serrata, vitreus tabanı, periferik nörosensoryal retina ve subretinal potansiyel boşluk [RV3:pdf112]",
        "imaging_biomarker": "Ön vitreusta pigment (Shafer +), 360° skleral çökertmeli İO, Lincoff sıvı konturu ve PVR Evre A-C sınıflaması [RV3:pdf145]",
        "clinical_course": "Akut semptomatik at nalı yırtık %30-50 RRD'ye ilerler; kronik RRD'de RPE göçü ve EMT ile kontraktil PVR membranları gelişir [RV3:pdf238]",
        "clinical_decision": "Akut flap yırtıkta acil 3 sıra bariyer lazer; makula-on RRD'de acil cerrahi; 'shifting fluid'li eksüdatif RD'de cerrahiden kaçınılır [RV3:pdf155]",
    },
    {
        "chapter_num": "Bölüm 6",
        "chapter_title": "Kalıtsal Retinal ve Koroidal Distrofiler",
        "target_tissue": "Çomak/koni fotoreseptörler, RPE görsel döngüsü (RPE65/ABCA4), Müller/retinoskizin ağı ve koroid yatağı [RV1:pdf762]",
        "imaging_biomarker": "FAF Robson-Holder halkası (RP), peripapiller korunma (ABCA4), negatif ERG (XLRS), EOG (BEST1) ve plazma ornitini (OAT) [RV1:pdf826]",
        "clinical_course": "İlerleyici dış retina ve RPE kaybı; Usher'da işitme kaybı, Bardet-Biedl'de böbrek/metabolik tutulum, Stickler'da dev yırtık riski [RV1:pdf774]",
        "clinical_decision": "Biallelik RPE65'te canlı dış retina varken subretinal voretigene neparvovec; jirat atrofide argininsiz diyet + B6; XLRS'de karbonik anhidraz [RV1:pdf902]",
    },
    {
        "chapter_num": "Bölüm 7",
        "chapter_title": "Enfeksiyöz/İnflamatuar Üveitler ve BNS",
        "target_tissue": "Nörosensoryal retina, retinal venüller/arteriyoller, RPE-fotoreseptör arayüzü, koryokapillaris ve koroid stroması [RV2:pdf712]",
        "imaging_biomarker": "Vitreus PCR (HSV/VZV/CMV), TPHA/RPR, IGRA, HLA-A29, FA 'eğrelti otu' sızıntısı ve ICGA hipoflöresan noktalar [RV2:pdf880]",
        "clinical_course": "ARN'de %75 RRD riski; Behçet'te oklüzif nekrotizan ataklar; APMPPE'de CNS vasküliti; MFC/PIC'de %30-40 sekonder KNV riski [RV2:pdf872]",
        "clinical_decision": "Sifiliz/TB/Herpes dışlanmadan steroid verilmez! Behçet'te erken anti-TNF; VKH/Birdshot/Serpijinözde erken IMT; MFC-KNV'de anti-VEGF [RV2:pdf812]",
    },
    {
        "chapter_num": "Bölüm 8",
        "chapter_title": "Retina ve Koroid Tümörleri",
        "target_tissue": "Gelişmekte olan nöroblastik retina (RB1), uveal melanositler (GNAQ/GNA11/BAP1), RPE altı lenfoid aralık ve koroid damarları [RV3:pdf701]",
        "imaging_biomarker": "B-scan kalsifikasyon/akustik çukurlaşma, MRG, TFSOM-DIM risk kriterleri ve vitreus IL-10/IL-6 > 1 + MYD88 L265P PCR [RV3:pdf755]",
        "clinical_course": "Retinoblastomda ekstraoküler/optik sinir yayılımı; Sınıf 2 / BAP1(-) melanomda karaciğer metastazı; VRL'de %60-80 PCNSL birlikteliği [RV3:pdf810]",
        "clinical_decision": "Retinoblastomda biyopsi kontrendikedir (İAK + İVK uygulanır); melanomda plak brakiterapi; VRL'de tanısal vitrektomi + kraniyal MRG [RV3:pdf701]",
    },
    {
        "chapter_num": "Bölüm 9",
        "chapter_title": "Travma, Enjeksiyon Güvenliği ve Yapay Zekâ",
        "target_tissue": "Bruch membranı, pars plana giriş zonu, vitreus kavitesi ve dejenere retinada sağlam iç retinal nöronlar (bipolar/GCL) [RV3:pdf993]",
        "imaging_biomarker": "İnce kesitli orbital BT (İOYC), OKT Berlin ödemi, CNN/U-Net sıvı hacim segmentasyonu ve iç retina kalınlık haritası [RV3:pdf1012]",
        "clinical_course": "Demir/bakır İOYC'de siderozis/kalkozis; enjeksiyon sonrası 1-5. günde bakteriyel endoftalmi; ileri RP/GA'da fotoreseptör kaybı [INJ:pdf2]",
        "clinical_decision": "Metalik İOYC'de MRG çekilmez, erken PPV yapılır; enjeksiyonda %5 povidon-iyot şarttır; akut endoftalmide acil tap + vankomisin/seftazidim [INJ:pdf1]",
    },
]


def extract_topic_structured_cards(topic_id: str, md_text: str, pubmed_dir: Optional[Path] = None) -> dict:
    """
    Her bir konu (ör. [1.1.1] - [10.2.2], toplam 61 konu) metninden ve PubMed önbelleğinden:
    1. 'ÖNE ÇIKAN KLİNİK İLKE' (Mavi sol şeritli kutu)
    2. '📌 ÖNEMLİ NOKTALAR VE KLİNİK İNCİLER' (4 maddeli ferah özet kutusu - metin ortasında)
    3. '🧠 KLİNİK MNEMONIC / AKILDA KALICI KODLAMA' (Konuya/alt bölüme özel bellek çivisi)
    4. 'KLİNİK TUZAK VE YORUM SINIRI' (Amber sol şeritli kutu)
    5. 'YEŞİL / AMBER KAYNAK SENTEZ KUTUSU' (Sol: Yerel Veritabanı [RV1-3] Kanıtı, Sağ: Güncel Klinik/PubMed Kanıtı, Alt: Klinik Karara Etkisi)
    üretir.
    """
    clean_lines = [
        re.sub(r"\*\*([^*]+)\*\*", r"\1", ln.strip())
        for ln in md_text.splitlines()
        if ln.strip()
        and not ln.strip().startswith("#")
        and not re.match(r"^\*\*[^*]{4,95}\*\*$", ln.strip())
    ]
    full_text = " ".join(clean_lines)

    # Cümlelere ayır (6. haftada gibi sıra sayılarını bölmemek için büyük harf kontrolü)
    sentences = [
        s.strip()
        for s in re.split(r"(?<=[.!?])\s+(?=[A-ZÇĞİÖŞÜ])", full_text)
        if len(s.strip()) >= 45 and s.strip()[0].isupper()
    ]

    db_citations = sorted(set(re.findall(r"\[(?:RV[123]|ICROP3|PRD|INJ):pdf\d+\]", full_text)))
    pmid_citations = sorted(set(re.findall(r"\[PMID:\d+\]", full_text)))

    # 1. Öne Çıkan Klinik İlke (İlk cümlenin birebir tekrarını önlemek için orta-üst klinik mekanizma cümlesi)
    highlight_sent = sentences[min(2, len(sentences) - 1)] if sentences else "Temel mekanizma ve multimodal görüntüleme bulguları klinik evrelemenin omurgasını oluşturur."
    start_search = min(2, max(0, len(sentences) - 1))
    for s in sentences[start_search:]:
        if re.search(r"\[(?:RV[123]|ICROP3|PRD|INJ):pdf\d+\]", s) and s != sentences[0]:
            highlight_sent = s
            break

    # 2. Klinik Tuzak ve Yorum Sınırı (Uygulama / ayırıcı tanı / dikkat cümlesi)
    caution_sent = sentences[-1] if sentences else "Tek bir görüntüleme kesitiyle karar verilmemeli, klinik öykü ve sistemik bulgular birlikte değerlendirilmelidir."
    caution_keywords = ("ancak", "dikkat", "ayrım", "kontrendike", "kaçınılmalı", "tuzak", "yanlış", "risk", "zorunlu", "şart", "dışlan")
    for s in reversed(sentences):
        if any(k in s.lower() for k in caution_keywords) and s not in (highlight_sent, sentences[0] if sentences else ""):
            caution_sent = s
            break

    # 3. Klinik Karara Etkisi (caution_sent ve highlight_sent'ten tamamen farklı yönetim/karar cümlesi)
    impact_sent = "Multimodal görüntüleme bulguları, görsel prognoz beklentisi ve bireyselleştirilmiş tedavi/izlem aralığı birlikte değerlendirilmelidir."
    decision_keywords = ("tedavi", "yönetim", "cerrahi", "izlem", "takip", "endikasyon", "tanı", "prognoz", "enjeksiyon", "lazer", "karar")
    for s in reversed(sentences):
        if s not in (highlight_sent, caution_sent, sentences[0] if sentences else "") and any(k in s.lower() for k in decision_keywords):
            impact_sent = s
            break
    if impact_sent.startswith("Multimodal görüntüleme bulguları") and len(sentences) >= 4:
        for s in reversed(sentences):
            if s not in (highlight_sent, caution_sent, sentences[0]):
                impact_sent = s
                break

    # 3. Önemli Noktalar (Metin içinden seçilmiş 4 farklı anahtar klinik inci)
    important_points: List[str] = []
    if len(sentences) >= 8:
        indices = [
            max(1, len(sentences) // 6),
            len(sentences) * 2 // 5,
            len(sentences) * 3 // 5,
            min(len(sentences) - 2, len(sentences) * 4 // 5),
        ]
        seen_pts = {highlight_sent, caution_sent}
        for idx in indices:
            cand = sentences[idx]
            if cand not in seen_pts:
                if len(cand) > 230:
                    cand = cand[:227].rsplit(" ", 1)[0] + "..."
                important_points.append(cand)
                seen_pts.add(cand)
    if not important_points:
        for s in sentences[1:5]:
            important_points.append(s[:225])

    # 4. Konuya / Alt Bölüme Özel Klinik Mnemonic (Akılda Kalıcı Kodlama)
    sec_id = ".".join(topic_id.split(".")[:2])
    mnemonic_data = get_mnemonic_for_topic(topic_id, sec_id)

    # 5. Yeşil (Veritabanı: Ryan's Retina) vs Amber (PubMed / Klinik Uygulama Sentezi)
    db_tags_str = ", ".join(db_citations[:5]) if db_citations else "[RV1-3]"
    db_summary = highlight_sent
    if len(db_summary) > 310:
        db_summary = db_summary[:307].rsplit(" ", 1)[0] + "..."

    # PubMed JSON önbelleği varsa gerçek makale başlığı/özet bilgisini çek
    pdir = pubmed_dir or (PATHS.storage_dir / "pubmed")
    pfile = pdir / f"{topic_id.replace('.', '_')}.json"
    if not pfile.is_file() and topic_id.startswith("9."):
        pfile = pdir / f"{('10.' + topic_id[2:]).replace('.', '_')}.json"
    pubmed_summary = ""
    if pfile.is_file():
        try:
            pdata = json.loads(pfile.read_text(encoding="utf-8"))
            articles = pdata.get("articles", [])
            if articles:
                top_a = articles[0]
                pmid_str = top_a.get("pmid", "")
                jour = top_a.get("journal", "")
                yr = top_a.get("pub_date", "")
                title_str = top_a.get("title", "").rstrip(".")
                pubmed_summary = f"Güncel PubMed Kanıtı ([PMID:{pmid_str}], {jour} {yr}): {title_str}. Klinik pratikte multimodal biyobelirteçlerle erken tanı ve bireyselleştirilmiş takip doğrulanmaktadır."
        except Exception:
            pubmed_summary = ""

    if not pubmed_summary:
        mid_idx = len(sentences) // 2
        mid_sent = sentences[mid_idx] if sentences else caution_sent
        if len(mid_sent) > 310:
            mid_sent = mid_sent[:307].rsplit(" ", 1)[0] + "..."
        pmid_tags_str = ", ".join(pmid_citations[:3]) if pmid_citations else "Güncel Klinik Konsensus"
        pubmed_summary = f"{pmid_tags_str}: {mid_sent}"

    impact_summary = impact_sent
    if len(impact_summary) > 320:
        impact_summary = impact_summary[:317].rsplit(" ", 1)[0] + "..."

    return {
        "topic_id": topic_id,
        "db_citations": db_citations,
        "pmid_citations": pmid_citations,
        "highlight_box": highlight_sent,
        "important_points": important_points,
        "mnemonic": mnemonic_data,
        "caution_box": caution_sent,
        "green_db_cell": f"Yerel Referans Veritabanı ({db_tags_str}): {db_summary}",
        "amber_pubmed_cell": pubmed_summary,
        "clinical_impact_cell": impact_summary,
    }


# Alt Bölüm ve Konular İçin Klinik Mnemonic (Bellek Çivisi / Kodlama) Kütüphanesi
SUBSECTION_MNEMONICS: Dict[str, dict] = {
    "1.1": {
        "code": "VİTREUS-5B (Vitreoretinal Sıkı Tutunma Bölgeleri)",
        "items": [
            ("V", "Vitreus tabanı (Ora serrata ön/arkası — en güçlü ve kalıcı tutunma)"),
            ("O", "Optik disk kenarı (Peripapiller halka — PVD'de Weiss halkası oluşturur)"),
            ("F", "Foveola ve perifoveal makula (VMT ve makula deliği traksiyon merkezi)"),
            ("D", "Damarlar boyunca (Retinal vasküler arklar üzerinde paravasküler tutunma)"),
            ("L", "Lens arka kapsülü (Hyaloideokapsüler Wieger ligamanı — gençlerde çok sıkı)"),
        ],
        "pearl": "Bruch membranı 5 katmanı içten dışa: R-İ-E-D-K (RPE bazal laminası -> İç kollajen -> Elastik tabaka -> Dış kollajen -> Koryokapillaris bazal laminası).",
    },
    "1.2": {
        "code": "FOTON-cGMP (Fototransdüksiyon ve Görsel Döngü Kodu)",
        "items": [
            ("F", "Foton -> 11-cis-retinal'i all-trans-retinal'e izomerize eder (Rodopsin aktifleşir)"),
            ("T", "Transdüsin (G-proteini) aktifleşir ve PDE6 enzimini uyarır"),
            ("P", "PDE6 -> cGMP'yi yıkar (Sitoplazmik cGMP konsantrasyonu hızla düşer)"),
            ("K", "Kapılı Na+/Ca2+ kanalları (CNG) KAPANIR -> Fotoreseptör HİPERPOLARİZE olur"),
            ("G", "Glutamat salınımı karanlıkta MAKSİMUM iken ışıkta AZALIR"),
        ],
        "pearl": "Unutmayın: İnsan fotoreseptörleri ışıkta depolarize değil, HİPERPOLARİZE olur ('Karanlık akım' ışıkla kesilir).",
    },
    "1.3": {
        "code": "ACMG-5 & KALITIM (Genetik Varyant ve Geçiş Kodu)",
        "items": [
            ("OD", "Otozomal Dominant: Her kuşakta görülür (%50 risk) — BEST1, RHO, PRPH2"),
            ("OR", "Otozomal Resesif: Anne-baba taşıyıcı (%25 risk, trans fazı şart) — ABCA4, USH2A, RPE65"),
            ("XL", "X'e Bağlı: Erkekten erkeğe geçiş ASLA olmaz — RPGR, CHM (Koroideremi), RS1 (XLRS)"),
            ("MT", "Mitokondriyal: Yalnız anneden tüm çocuklara geçer — MIDD (m.3243A>G), NARP"),
        ],
        "pearl": "Otozomal resesif hastalıkta iki varyantın farklı kromozomlarda (trans) olduğu anne-baba segregasyonu ile kanıtlanmadan kesin tanı konmaz.",
    },
    "2.1": {
        "code": "ELM-EZ-İZ-RPE (SD-OKT Dış Retina 4 Hiperreflektif Bant Kodu)",
        "items": [
            ("1. ELM", "Dış Limitan Membran: Fotoreseptör iç segmentleri ile Müller hücrelerinin zonula adherens bağlantısı"),
            ("2. EZ", "Elipsoid Zon: Fotoreseptör iç segment elipsoidindeki yoğun mitokondri kuşağı (Görme keskinliği anahtarı)"),
            ("3. İZ", "İnterdijitasyon Zonu (COST): Fotoreseptör dış segment uçları ile RPE apikal mikrovilluslarının temas hattı"),
            ("4. RPE", "RPE / Bruch Kompleksi: En kalın dış hiperreflektif bant; koroid hipertransmisyonunu engeller"),
        ],
        "pearl": "DRIL (İç retina katman dezorganizasyonu) + ELM/EZ kaybı birlikteyse, makula ödemi tamamen kurusa bile görme artışı sınırlı kalır.",
    },
    "2.2": {
        "code": "OKTA-4A (OKT Anjiyografide 4 Temel Artefakt Tuzak Kodu)",
        "items": [
            ("P", "Projeksiyon (Kuyruk) Artefaktı: Yüzeyel damarların RPE/dış retinada sahte KNV ağı gibi görünmesi"),
            ("S", "Segmentasyon Hatası: Ödem, PED veya atrofide otomatik katman çizgilerinin yanlış dokudan geçmesi"),
            ("G", "Gölgelenme (Maskeleme): Hemoraji, yoğun eksüda veya vitrit altında sahte 'akım kaybı' (flow void) oluşması"),
            ("H", "Hareket / Göz Kırpma: Fiksasyon kaybına bağlı yatay beyaz çizgiler, damar kopukluğu ve siyah bantlar"),
        ],
        "pearl": "En-face OKTA görüntüsü asla tek başına okunmaz; eşzamanlı B-scan akım bindirmesi (flow overlay) ve segmentasyon çizgileri kontrol edilmelidir.",
    },
    "2.3": {
        "code": "FA-4H (Floresein Anjiyografide 4 Hiperflöresans Mekanizması)",
        "items": [
            ("P", "Pencere Defekti (Window Defect): RPE atrofisi; erken başlar, sınırları büyümez, geç fazda solar"),
            ("S", "Sızıntı (Leakage): KNV, NVD/NVE, aktif vaskülit; geç fazda hem boyutu büyür hem parlaklığı artar"),
            ("G", "Göllenme (Pooling): Seröz PED, SSKR, kistoid boşluk; anatomik sınırları belli bir boşluğun boyayla dolması"),
            ("B", "Boyanma (Staining): Drusen, diskiform skar, sklera; geç fazda doku kollajenine boya tutunması (sınır aşmaz)"),
        ],
        "pearl": "Subretinal kanama veya seröz-hemorajik PED varlığında FA maskelenir; polip (PCV) ve koroid damarları için ICGA altın standarttır.",
    },
    "2.4": {
        "code": "FAF-LİPO & B-SCAN (Otofloresans ve Ultrason Kodu)",
        "items": [
            ("HİPER-FAF", "Lipofuskin/A2E artışı (Stargardt flecks, Best vitelliform, GA büyüme sınırı, RP halkası)"),
            ("HİPO-FAF", "RPE ölümü / Coğrafi atrofi (keskin sınırlı simsiyah alan) veya kanama blokajı"),
            ("RRD (B-Scan)", "Yüksek reflektiviteli, optik diske ve ora serrataya tutunan, kinetikte az salınan sert membran"),
            ("MELANOM", "Mantar/kubbe şekil + A-modda düşük-orta iç reflektivite (azalan kappa açısı) + akustik boşluk"),
        ],
        "pearl": "Mavi-FAF'ta optik disk çevresinin korunması ('peripapillary sparing') ABCA4 ilişkili Stargardt hastalığının imzasıdır.",
    },
    "2.5": {
        "code": "ERG-NEGATİF ('KISS-CSNB' — Elektromanyetik Negatif ERG Nedenleri)",
        "items": [
            ("K", "Kalıtsal X'e Bağlı Retinoskizis (XLRS — RS1 mutasyonu, iç nükleer tabaka skizisi)"),
            ("İ", "İskemik Santral Retinal Arter Tıkanıklığı (SAT) ve İskemik SVT (İç retina hipoksisi)"),
            ("S", "Siderozis Bulbi (Demir göz içi yabancı cisim toksisitesi) ve Kinin/Vinkristin toksisitesi"),
            ("S", "Sendromik / Paraneoplastik: Melanom İlişkili Retinopati (MAR — ON-bipolar TRPM1 antikorları)"),
            ("CSNB", "Konjenital Durağan Gece Körlüğü (Tam ve tamamlanmamış tip CSNB)"),
        ],
        "pearl": "Tam alan ERG (ffERG) normal iken EOG Arden oranının (<1.5) bozuk olması Best vitelliform makula distrofisi için patognomoniktir.",
    },
    "3.1": {
        "code": "4-2-1 KURALI & PROTOKOL T-V-S (Diyabetik Retinopati Kodu)",
        "items": [
            ("4 Kadran", "Her 4 kadranın tamamında >= 20 intraretinal nokta/leke hemoraji bulunması"),
            ("2 Kadran", "En az 2 kadranda belirgin venöz boncuklanma (venous beading) saptanması"),
            ("1 Kadran", "En az 1 kadranda belirgin intraretinal mikrovasküler anomali (IRMA) varlığı"),
            ("Protokol V", "Merkez tutulumlu DMÖ'de görme keskinliği >= 20/25 ise yakın gözlem güvenlidir"),
            ("Protokol T", "Görme keskinliği <= 20/50 olan DMÖ'de ilk yıl aflibercept/faricimab görsel kazanımı daha yüksektir"),
        ],
        "pearl": "4-2-1 kriterlerinden herhangi BİRİ varsa 'Şiddetli NPDR' (1 yılda %15, 3 yılda %45 PDR riski); İKİSİ varsa 'Çok Şiddetli NPDR' (%45/yıl risk) tanısı konur.",
    },
    "3.2": {
        "code": "100-GÜN NVG & AKUT SAT (Retinal Vasküler Tıkanıklık Kodu)",
        "items": [
            (">=10 DA", "FA'da 10 disk alanından geniş kapiller non-perfüzyon İskemik SVT'yi tanımlar"),
            ("100 Gün", "İskemik SVT'den sonraki ilk 90-100 gün içinde '100 Gün Glokomu' (NVG) gelişir; aylık gonyoskopi şarttır"),
            ("GCA (SAT)", ">=50 yaş akut SAT hastasında şakak ağrısı/çene kladikasyosu + acil ESR/CRP/Trombosit bakılmalıdır"),
            ("İNME KODU", "Akut SAT oküler bir inmedir; ilk 24-48 saatte yüksek serebral infarkt riski nedeniyle İnme Ünitesine sevk edilir"),
        ],
        "pearl": "İskemik SVT'de neovaskülarizasyon (NVI/NVA) gelişmeden önce yapılan profilaktik PRP'nin yararı yoktur; ancak NVI/NVA görülür görülmez ACİL PRP yapılır.",
    },
    "3.3": {
        "code": "ICROP-3 (Z-E-P-N: Prematüre Retinopatisi Sınıflama Kodu)",
        "items": [
            ("Zon I-III", "Zon I (Optik disk-fovea yarıçapının 2 katı), Posterior Zon II, Zon II ve Zon III (Periferik temporal hilal)"),
            ("Evre 1-5", "1: Demarkasyon hattı · 2: Kabarıklık (Ridge) · 3: Ekstraretinal proliferasyon · 4A/4B: Kısmi RD · 5: Tam RD"),
            ("Plus (+)", "Arka kutupta en az 2 kadranda arteriyoler kıvrımlanma (tortuosity) ve venöz dilatasyon"),
            ("Notch (Çentik)", "Lezyonun 1-2 saat kadranı boyunca bir arka zona doğru içeri sokulması (ICROP-3 yeni kriteri)"),
        ],
        "pearl": "Tip 1 ROP (Zon I Plus'lı herhangi evre, Zon I Plus'sız Evre 3, Zon II Evre 2-3 + Plus) ve A-ROP tanıdan itibaren 48-72 saat içinde tedavi edilmelidir.",
    },
    "4.1": {
        "code": "CAM-cRORA & MNV 1-2-3 (YBMD Multimodal Tanı Kodu)",
        "items": [
            ("cRORA >=250 µm", "1) >=250 µm koroid hipertransmisyonu + 2) RPE zayıflaması/kaybı + 3) Üzerindeki fotoreseptör (ONL/EZ/ELM) dejenerasyonu"),
            ("Tip 1 MNV", "RPE Altı (Gizli): Bruch membranı ile RPE arasında fibro-vasküler PED / çift katman işareti"),
            ("Tip 2 MNV", "RPE Üstü (Klasik): RPE'yi delip subretinal boşlukta büyüyen hiperreflektif membran (hızlı fibrozis riski)"),
            ("Tip 3 MNV", "İntraretinal (RAP): Derin kapiller pleksustan başlayan dikey anastomoz; yüksek SDD ve bilateralite riski"),
        ],
        "pearl": "AREDS2 formülasyonunda eski sigara içicilerinde akciğer kanseri riskini artıran beta-karoten çıkarılmış, yerine Lutein (10 mg) + Zeaksantin (2 mg) konmuştur.",
    },
    "4.2": {
        "code": "PAKİKOROİD-4P (PPE -> SSKR -> PKNV -> PCV Spektrum Kodu)",
        "items": [
            ("1. PPE", "Pakikoroid Pigment Epitelyopati: Genişlemiş Haller paki-damarları + iç koroid incelmesi + sıvısız RPE değişikliği"),
            ("2. SSKR", "Santral Seröz Koryoretinopati: Seröz makula dekolmanı + kortikosteroid/stres ilişkisi (Kronikte yarım doz PDT)"),
            ("3. PKNV", "Pakikoroid Neovaskülarizasyon: Paki-damarlar üzerinde sığ düzensiz PED ('double-layer sign') + Tip 1 MNV"),
            ("4. PCV", "Polipoidal Koroideal Vaskülopati: Keskin tepe noktalı ('thumb-like') PED, subretinal kanama ve ICGA polipleri"),
        ],
        "pearl": "SSKR hastasında yalnızca oral/IV değil; burun spreyi, astım inhaleri, cilt kremi ve eklem içi kortikosteroid enjeksiyonları da mutlaka sorgulanıp kesilmelidir!",
    },
    "4.3": {
        "code": "IVTS & ATN (Vitreomaküler Arayüz ve Miyopik Makulopati Kodu)",
        "items": [
            ("VMT (1500 µm)", "Fokal (<=1500 µm) vs Diffüz (>1500 µm) vitreofoveal traksiyon + foveal kontur bozulması"),
            ("FTMH (250/400)", "Tam Kat Makula Deliği: Küçük (<=250 µm), Orta (250-400 µm), Büyük (>400 µm — ters İLM flebi)"),
            ("Govetto 1-4", "ERM Evre 3'te Ektopik İç Foveal Katmanlar (EIFL) gelişir; Evre 4'e kalmadan cerrahi yapılmalıdır"),
            ("Miyopik ATN", "A: Atrofi (A0-A4) · T: Traksiyon (Skizis -> Foveal RD -> Makula Deliği) · N: Neovaskülarizasyon (mKNV)"),
        ],
        "pearl": "Miyopik KNV'de (mKNV) yaş tip YBMD gibi uzun yükleme yerine '1 başlangıç anti-VEGF enjeksiyonu + hastalık aktivitesine göre yakın PRN' protokolü uygulanır.",
    },
    "5.1": {
        "code": "SHAFER-PVD (Akut Semptomatik PVD ve Retinal Yırtık Kodu)",
        "items": [
            ("S", "Semptomatik Akut Başlangıç: Yeni başlayan şimşek çakması (fotopsi - traksiyon) ve kurum yağması (vitreus kanaması)"),
            ("H", "Hemoraji veya Shafer İşareti: Ön vitreusta kahverengi pigment granülleri ('tütün tozu') -> %70 yırtık riski!"),
            ("A", "At Nalı (Flap) Yırtık: Dinamik vitreus çekintisi devam ettiği için ACİL 3 sıra bariyer lazer gerektirir"),
            ("O", "Operküllü / Atrofik Delik: Operkülde traksiyon kopmuştur; asemptomatik atrofik deliklerde rutin lazer gerekmez"),
        ],
        "pearl": "Akut PVD ve vitreus hemorajisi olan hastada ilk muayenede yırtık görülemese bile 2-4 hafta içinde gizli yırtık çıkabileceği için skleral çökertmeli kontrol şarttır.",
    },
    "5.2": {
        "code": "LINCOFF-4 (Regmatojen Retina Dekolmanında Yırtık Bulma Kuralları)",
        "items": [
            ("Kural 1 (%98)", "Üst temporal veya üst nazal dekolmanlarda birincil yırtık, en yüksek sıvı sınırının 1.5 saat kadranı içindedir"),
            ("Kural 2 (%93)", "Saat 12'yi aşan üst veya total dekolmanlarda yırtık saat 12'ye komşu 1.5 saatlik üçgen içindedir (daha alçak kenar tarafında)"),
            ("Kural 3 (%95)", "Alt yarı dekolmanlarında sıvının daha yüksek olduğu taraf, yırtığın saat 6'nın hangi yanında olduğunu gösterir"),
            ("Kural 4", "Alt yarıda büllöz bir dekolman varsa birincil yırtık alt yarıda değil, üst kadranda aranmalıdır (sinüs oluğu ile iner)"),
        ],
        "pearl": "Yırtık bulunamayan, pürüzsüz büllöz yüzeyli ve hasta başını çevirdiğinde yer değiştiren ('shifting fluid') dekolman EKSÜDATİFTİR; cerrahi yapılmaz!",
    },
    "6.1": {
        "code": "RP-TRİAD & ABCA4-BEST (Kalıtsal Distrofi Ayırıcı Tanı Kodu)",
        "items": [
            ("RP Triadı", "1) Kemik spikül pigmentasyonu + 2) Retinal arteriyoler incelme + 3) Mumsu optik disk solukluğu"),
            ("Usher vs BBS", "Usher: RP + Sensörinöral işitme kaybı · Bardet-Biedl: RP + Polidaktili + Obezite + Böbrek anomalisi"),
            ("Stargardt (ABCA4)", "Sarı-beyaz pisciform flecks + FA'da 'Karanlık Koroid' (%80) + FAF'ta 'Peripapiller Korunma'"),
            ("Best (BEST1)", "Makulada yumurta sarısı (vitelliform) lezyon + Normal tam alan ERG + Ağır bozuk EOG (Arden < 1.5)"),
        ],
        "pearl": "ABCA4 mutasyonu olan Stargardt hastalarında yüksek doz A vitamini takviyesi toksik bisretinoid/A2E birikimini hızlandıracağı için KESİNLİKLE kontrendikedir.",
    },
    "6.2": {
        "code": "OAT-B6 & LUXTURNA (Tedavi Edilebilir Distrofi ve Gen Tedavisi Kodu)",
        "items": [
            ("Jirat Atrofi (OAT)", "Midperiferde deniz kabuğu (scalloped) atrofi + Plazma ornitini 10-20x yüksek -> Argininsiz diyet + B6 vitamini"),
            ("Refsum (PHYH)", "RP + Polinöropati + Ataksi -> Plazma fitanik asit yüksekliği -> Fitanik asitten kısıtlı diyet"),
            ("XLRS (RS1)", "Erkek çocukta araba tekerleği foveal skizis + İNL kistleri + Negatif ERG -> Topikal dorzolamid/brinzolamid"),
            ("RPE65 (AAV2)", "Biallelik RPE65 mutasyonu + Canlı dış retina (OKT ONL varlığı) -> Subretinal voretigene neparvovec"),
        ],
        "pearl": "X'e bağlı retinoskizis (XLRS) kistlerinde FA'da sızıntı OLMAZ (sessiz makula); anti-VEGF etkisizdir, topikal karbonik anhidraz inhibitörü kullanılır.",
    },
    "7.1": {
        "code": "STEROİD-ÖNCE-3D (Üveitte Steroid Öncesi Zorunlu Enfeksiyöz Dışlama)",
        "items": [
            ("1. SİFİLİZ", "Büyük taklitçi! Her posterior/panüveitte TPHA/FTA-ABS + VDRL/RPR bakılır; pozitifse IV Penisilin G"),
            ("2. TÜBERKÜLOZ", "Serpijinöz-benzeri koroidit ve oklüzif periflebitte IGRA (QuantiFERON) + Toraks BT şarttır"),
            ("3. HERPES (ARN)", "Periferik hızla birleşen sarı-beyaz nekroz + oklüzif arteriolit -> Aköz/vitreus PCR + Acil IV Asiklovir"),
            ("TOKSOPLAZMA", "Eski pigmente skar kenarında aktif retinit + yoğun vitrit ('sis içinde far') -> Antibiyotik + 48 st sonra steroid"),
        ],
        "pearl": "Akut Retinal Nekroz (ARN) immünkompetan bireyde, PORN ise ağır immünsüprese (CD4 < 50) hastada görülür; ARN'de %75'e varan RRD riski vardır.",
    },
    "7.2": {
        "code": "BEHÇET-VKH-SARKO (Non-Enfeksiyöz Posterior Üveit Ayırıcı Kodu)",
        "items": [
            ("BEHÇET", "Gezici hipopyon + Oklüzif nekrotizan vaskülit + FA'da 'eğrelti otu' kapiller sızıntı -> Erken Anti-TNF-alfa"),
            ("VKH (Akut)", "Meningismus/tinnitus + Multilobüler seröz RD + OKT'de septalı sıvı (BALAD) ve kalın koroid -> Yüksek doz steroid + IMT"),
            ("VKH (Kronik)", "Yetersiz tedavi edilirse 'Sunset Glow Fundus' (günbatımı fundusu), Dalen-Fuchs nodülleri ve vitiligo/poliozis"),
            ("SARKOİDOZ", "Koyun yağı KP + Kartopu/inci dizisi vitrit + 'Mum damlası' (tache de bougie) venöz periflebit + bilateral hiler LAP"),
        ],
        "pearl": "Behçet hastalığında yalnız sistemik steroid monoterapisi nüksleri önleyemez; arka kutup tutulumunda anti-TNF-alfa (infliksimab/adalimumab) + azatioprin esastır.",
    },
    "7.3": {
        "code": "BNS-KATMAN (Beyaz Nokta Sendromlarında Tutulan Anatomik Katman Kodu)",
        "items": [
            ("MEWDS", "Hedef: Dış Retina (EZ/İZ) ve RPE · Tek taraflı genç miyop kadın, FA'da 'çelenk', 6-10 haftada spontan tam iyileşme"),
            ("APMPPE", "Hedef: Koryokapillaris İskemisi · FA'da 'Erken Hipo / Geç Hiper' · DİKKAT: Serebral vaskülit / baş ağrısı kırmızı bayraktır!"),
            ("BIRDSHOT", "Hedef: Derin Koroid Stroması · HLA-A29 (>%95), ICGA'da çok sayıda hipoflöresan nokta · Erken IMT şarttır"),
            ("MFC / PIC", "Hedef: RPE / Bruch Membranı · Zımba deliği skarlar ve %30-40 sekonder Tip 2 KNV riski (OKTA + Anti-VEGF)"),
            ("SERPİJİNÖZ", "Hedef: Koryokapillaris + RPE · Peripapillerden yılanvari ilerler; IMT öncesi Tüberküloz (SLC) dışlanmalıdır!"),
        ],
        "pearl": "APMPPE'de FA'da 'Erken HİPOflöresans (iskemi) -> Geç HİPERflöresans (boyanma)' görülürken, MEWDS'te tam tersine erken fazdan itibaren noktasal hiperflöresans vardır.",
    },
    "8.1": {
        "code": "TFSOM-DIM (Koroid Nevüsünün Melanoma Dönüşüm Risk Kodu)",
        "items": [
            ("T (Thickness)", "Kalınlığın B-scan ultrasonografide > 2 mm olması"),
            ("F (Fluid)", "SD-OKT'de lezyon üzerinde veya kenarında subretinal sıvı (SRF) bulunması"),
            ("S (Symptoms)", "Görme keskinliği azalması, metamorfopsi veya fotopsi semptomu"),
            ("O (Orange pigment)", "Mavi-FAF'ta parlak hiperotofloresans veren yüzeyel lipofuskin (turuncu pigment) varlığı"),
            ("M (Margin)", "Tümör arka sınırının optik disk kenarına <= 3 mm mesafede olması"),
            ("DIM (Hollow/Drusen)", "B-scan'de akustik iç boşluk (Hollowness) ve yüzeyde kronik drusen/halo YOKLUĞU"),
        ],
        "pearl": "Retinoblastom şüphesi olan çocukta tümör tohumlanması nedeniyle İİAB/vitrektomi ve ikincil sarkom riski nedeniyle BT çekimi KESİNLİKLE kontrendikedir!",
    },
    "9.1": {
        "code": "5P-ASEPSİ & İOYC (İntravitreal Enjeksiyon ve Travma Güvenlik Kodu)",
        "items": [
            ("1. Povidon-İyot %5", "Enfeksiyöz endoftalmiyi kanıtlı azaltan tek antiseptik; konjonktivada en az 30-60 sn bekletilmelidir"),
            ("2. Pikap (Spekulum)", "İğne ucunun kirpik ve kapak kenarı meibomian florasına değmesini önleyen steril blefarosta"),
            ("3. Parol (Konuşmama)", "Oral floradaki Streptococcus viridans damlacık yayılımını önlemek için maske ve sessizlik kuralı"),
            ("4. Pars Plana Girişi", "Fakik gözde limbustan 3.5-4.0 mm, psödofakik/afak gözde 3.0-3.5 mm (inferotemporal/süperotemporal)"),
            ("5. BT vs MRG (İOYC)", "Açık glob ve metalik göz içi yabancı cisim (İOYC) şüphesinde ince kesitli BT çekilir; MRG KESİNLİKLE kontrendikedir!"),
        ],
        "pearl": "İntravitreal enjeksiyon öncesi/sonrası rutin topikal antibiyotik damla kullanımı endoftalmiyi azaltmaz; aksine dirençli konjonktival flora seçer.",
    },
    "9.2": {
        "code": "AI-CNN & PRIMA (Yapay Zekâ ve Biyonik Görme Aday Seçim Kodu)",
        "items": [
            ("CNN (Tarama)", "Konvolüsyonel sinir ağları (IDx-DR, EyeArt): Sevk gerektiren DR'yi (orta NPDR+ ve DMÖ) otonom saptar"),
            ("U-Net (OKT)", "Piksel düzeyinde intraretinal (IRF), subretinal (SRF) ve PED sıvı hacmini nanolitre hassasiyetinde ölçer"),
            ("hESC / iPSC RPE", "Coğrafi atrofi ve Stargardt hastalığında polarize RPE tek tabakalı yama replasmanı"),
            ("Subretinal PRIMA", "Fotoreseptörlerin tamamen kaybolduğu ancak iç retinanın (bipolar/gangliyon) korunduğu ileri RP/GA'da fotovoltaik mikroçip"),
        ],
        "pearl": "Gen tedavisi (RPE65) için canlı fotoreseptörler (ONL) şarttır; fotoreseptörler tamamen kaybolmuşsa yalnız iç retinayı uyaran protez veya optogenetik çalışır.",
    },
    "10.1": {
        "code": "5P-ASEPSİ & İOYC (İntravitreal Enjeksiyon ve Travma Güvenlik Kodu)",
        "items": [
            ("1. Povidon-İyot %5", "Enfeksiyöz endoftalmiyi kanıtlı azaltan tek antiseptik; konjonktivada en az 30-60 sn bekletilmelidir"),
            ("2. Pikap (Spekulum)", "İğne ucunun kirpik ve kapak kenarı meibomian florasına değmesini önleyen steril blefarosta"),
            ("3. Parol (Konuşmama)", "Oral floradaki Streptococcus viridans damlacık yayılımını önlemek için maske ve sessizlik kuralı"),
            ("4. Pars Plana Girişi", "Fakik gözde limbustan 3.5-4.0 mm, psödofakik/afak gözde 3.0-3.5 mm (inferotemporal/süperotemporal)"),
            ("5. BT vs MRG (İOYC)", "Açık glob ve metalik göz içi yabancı cisim (İOYC) şüphesinde ince kesitli BT çekilir; MRG KESİNLİKLE kontrendikedir!"),
        ],
        "pearl": "İntravitreal enjeksiyon öncesi/sonrası rutin topikal antibiyotik damla kullanımı endoftalmiyi azaltmaz; aksine dirençli konjonktival flora seçer.",
    },
    "10.2": {
        "code": "AI-CNN & PRIMA (Yapay Zekâ ve Biyonik Görme Aday Seçim Kodu)",
        "items": [
            ("CNN (Tarama)", "Konvolüsyonel sinir ağları (IDx-DR, EyeArt): Sevk gerektiren DR'yi (orta NPDR+ ve DMÖ) otonom saptar"),
            ("U-Net (OKT)", "Piksel düzeyinde intraretinal (IRF), subretinal (SRF) ve PED sıvı hacmini nanolitre hassasiyetinde ölçer"),
            ("hESC / iPSC RPE", "Coğrafi atrofi ve Stargardt hastalığında polarize RPE tek tabakalı yama replasmanı"),
            ("Subretinal PRIMA", "Fotoreseptörlerin tamamen kaybolduğu ancak iç retinanın (bipolar/gangliyon) korunduğu ileri RP/GA'da fotovoltaik mikroçip"),
        ],
        "pearl": "Gen tedavisi (RPE65) için canlı fotoreseptörler (ONL) şarttır; fotoreseptörler tamamen kaybolmuşsa yalnız iç retinayı uyaran protez veya optogenetik çalışır.",
    },
}


TOPIC_SPECIFIC_MNEMONICS: Dict[str, dict] = {
    "1.1.2": {
        "code": "ONL-OPL-İNL-İPL-GCL (Nörosensoryal Retina Sinaptik Zincir Kodu)",
        "items": [
            ("1. Nöron", "Fotoreseptörler (Çomak & Koni çekirdekleri ONL'de) -> Işığı hiperpolarizasyona çevirir"),
            ("OPL (1. Sinaps)", "Fotoreseptör pedikül/sferülleri ile Bipolar ve Horizontal hücrelerin sinaps katmanı (Henle lifleri)"),
            ("2. Nöron", "Bipolar Hücreler (İNL'de: ON-merkez mGluR6 / OFF-merkez AMPA-kainat) + Müller glia ve Amakrin"),
            ("İPL (2. Sinaps)", "Bipolar aksonları ile Gangliyon dendritlerinin OFF (sublamina a) ve ON (sublamina b) sinapsı"),
            ("3. Nöron", "Gangliyon Hücreleri (GCL: Midget/Parvo renk-detay, Parasol/Magno hareket) -> Aksonları RNFL ve Optik Sinir"),
        ],
        "pearl": "Foveolada iç katmanlar (RNFL, GCL, İPL, İNL, OPL) kenara çekilir; yalnızca koni fotoreseptörleri ve Müller uzantıları kalır.",
    },
    "1.1.3": {
        "code": "RPE-5G & BRUCH-5K (RPE Görevleri ve Bruch Membranı 5 Katmanı)",
        "items": [
            ("G1 - Bariyer", "Zonula occludens sıkı bağlantıları ile Dış Kan-Retina Bariyerini (dış B-RB) oluşturur"),
            ("G2 - Pompa", "Subretinal boşluktan koroide aktif iyon ve su pompalayarak retinanın yatışık kalmasını sağlar"),
            ("G3 - Döngü", "All-trans-retinolü RPE65 ve LRAT ile 11-cis-retinale dönüştürür (Görsel retinoid döngüsü)"),
            ("G4 - Fagositoz", "Her sabah fotoreseptör dış segment disklerinin %10'unu MERTK aracılığıyla fagosite eder"),
            ("Bruch 5 Katman", "1) RPE bazal laminası · 2) İç kollajen · 3) Elastik tabaka · 4) Dış kollajen · 5) Koryokapillaris bazal laminası"),
        ],
        "pearl": "Yaşlanmayla Bruch membranında esterleşmiş kolesterol (lipid duvarı) birikir, hidrolik iletkenlik düşer ve bazal lineer depozit (yumuşak drusen) oluşur.",
    },
    "1.1.4": {
        "code": "KOROİD-3K (Koryokapillaris -> Sattler -> Haller Vasküler Mimari Kodu)",
        "items": [
            ("1. Koryokapillaris", "Bruch altında tek katlı, geniş lümenli ve yalnız RPE tarafına bakan bol fenestrasyonlu lobüler kapiller ağ"),
            ("2. Sattler Tabakası", "Orta çaplı arteriyol ve venüllerin bulunduğu ara vasküler stroma katmanı"),
            ("3. Haller Tabakası", "Sklera (suprakoroidea) komşuluğundaki en geniş çaplı dış koroid venleri ve vorteks ven kökleri"),
            ("Vorteks Venleri", "Her kadranda en az 1 adet (toplam 4-7) vorteks veni koroid kanını süperior/inferior oftalmik venlere drene eder"),
        ],
        "pearl": "Koryokapillaris akımı vücutta birim ağırlık başına en yüksek kan akımıdır ve otonom sempatik sinirlerle (koroid otoregülasyonu sınırlı) kontrol edilir.",
    },
    "1.2.2": {
        "code": "İÇ vs DIŞ B-RB (Kan-Retina Bariyerleri Karşılaştırma Kodu)",
        "items": [
            ("İç B-RB (Endotel)", "Fenestrasyonsuz retinal kapiller endotel + Claudin-5 / Occludin + Perisit (1:1 oranı) + Müller glia"),
            ("Dış B-RB (RPE)", "Tek katlı RPE hücrelerinin apikal-lateral sınırındaki ZO-1 / Claudin-19 sıkı bağlantı kuşağı"),
            ("İç B-RB Yıkımı", "Diyabetik retinopati ve RVT'de VEGF-A / PKC-beta aktivasyonu -> İntraretinal kistoid makula ödemi"),
            ("Dış B-RB Yıkımı", "SSKR, VKH ve malign hipertansiyonda RPE pompa/bariyer yetmezliği -> Seröz subretinal sıvı (SRD)"),
        ],
        "pearl": "Retinal kapillerlerde perisit/endotel oranı 1:1'dir (beyinden bile yüksektir); diyabette ilk kaybolan hücre perisitlerdir (mikroanevrizma gelişimi).",
    },
    "1.2.3": {
        "code": "MERTK-A2E (RPE Sirkadiyen Fagositoz ve Lipofuskin Kodu)",
        "items": [
            ("MERTK & Gas6", "Dış segment yüzeyindeki fosfatidilserin -> MerTK reseptör tirozin kinazı uyarır ve yutmayı başlatır"),
            ("İntegrin αvβ5", "Dış segmentin RPE apikal mikrovilluslarına ilk bağlanmasını (binding) koordine eder"),
            ("Katepsin D", "Fagolizozom içinde rodopsin ve disk proteinlerini parçalayan ana asidik proteaz"),
            ("A2E (Lipofuskin)", "Sindirim tamamlanamazsa bisretinoidler (A2E) lizozomda birikir, mavi ışıkta serbest radikal üretir ve FAF sinyali verir"),
        ],
        "pearl": "MERTK gen mutasyonlarında RPE dış segmentleri yutamaz; subretinal boşlukta fotoreseptör enkazı birikir ve erken başlangıçlı ağır RP/rod-cone distrofisi gelişir.",
    },
    "2.1.2": {
        "code": "DRIL-HRF-ORT (OKT Prognostik Biyobelirteç Üçlüsü)",
        "items": [
            ("DRIL (Kötü Prognoz)", "Santral 1 mm'de GCL-İPL / İNL / OPL sınırlarının silinmesi -> Bipolar akson kopukluğu, kalıcı GK düşüklüğü"),
            ("HRF (İnflamasyon)", "<=30 µm, gölge yapmayan parlak noktalar -> Aktif mikroglia/lipoprotein; DMÖ'de steroid yanıtını işaret eder"),
            ("ORT (Tübülasyon)", "ONL içinde hiperreflektif halka rozetleri -> Kronik dejeneratif fotoreseptör sağkalımı; AKTİF SIVI DEĞİLDİR!"),
            ("EZ & ELM", "Dış limitan membran ve elipsoid zonun fovea altında kesintisiz olması en güçlü görsel iyileşme göstergesidir"),
        ],
        "pearl": "Dış retinal tübülasyon (ORT) intraretinal kistoid ödemle karıştırılmamalıdır; ORT varlığında gereksiz anti-VEGF enjeksiyonu yapılmaz.",
    },
    "2.1.3": {
        "code": "EDI-CVI (Koryoidal Vaskülarite İndeksi ve Kalınlık Kodu)",
        "items": [
            ("EDI-OKT İlkesi", "SD-OKT cihazının göze yaklaştırılıp sıfır gecikme hattının (zero-delay line) koroid/skleraya taşınması"),
            ("SS-OKT (1050 nm)", "Daha uzun dalga boyu sayesinde RPE melanininden saçılmaz; sklerokoroidal sınırı (%100'e yakın) net gösterir"),
            ("Normal SFKT", "Genç erişkinde subfoveal koroid kalınlığı ~280-350 µm; yaşla (her dekadda ~15 µm) ve aksiyel uzunlukla azalır"),
            ("CVI (%65)", "Lüminal (damar) alan / Toplam koroid alanı oranı; diurnal (gün içi) dalgalanmadan kalınlığa göre çok daha az etkilenir"),
        ],
        "pearl": "Subfoveal koroid kalınlığı akşam saatlerinde düşer, sabah erken saatlerde yükselir; takip ölçümleri günün aynı saatinde yapılmalıdır.",
    },
}


def get_mnemonic_for_topic(topic_id: str, sec_id: str) -> dict:
    """Konu ve alt bölüme uygun zengin klinik mnemonic döndürür."""
    if topic_id in TOPIC_SPECIFIC_MNEMONICS:
        spec = TOPIC_SPECIFIC_MNEMONICS[topic_id]
        return {
            "topic_id": topic_id,
            "section_id": sec_id,
            "code": spec["code"],
            "items": spec["items"],
            "pearl": spec["pearl"],
        }
    base = SUBSECTION_MNEMONICS.get(sec_id, SUBSECTION_MNEMONICS["1.1"])
    return {
        "topic_id": topic_id,
        "section_id": sec_id,
        "code": base["code"],
        "items": base["items"],
        "pearl": base["pearl"],
    }


def build_all_clinical_tables_manifest() -> Path:
    """
    Tüm 24 alt bölümün mavi tablo + mor vaka paketlerini ve tüm 61 konunun
    vurgu/kaynak sentez kutularını JSON manifest olarak kaydeder.
    """
    manuscript_dir = PATHS.output_dir / "manuscript"
    topic_cards: Dict[str, dict] = {}

    if manuscript_dir.is_dir():
        for md_path in sorted(manuscript_dir.glob("*.md")):
            tid = md_path.stem
            if not re.match(r"^\d+\.\d+\.\d+$", tid):
                continue
            text = md_path.read_text(encoding="utf-8")
            topic_cards[tid] = extract_topic_structured_cards(tid, text)

    payload = {
        "subsection_packages": SUBSECTION_CLINICAL_PACKAGES,
        "topic_cards": topic_cards,
        "summary_matrix_rows": BOOK_SUMMARY_MATRIX_ROWS,
    }
    out_path = PATHS.output_dir / "compiled" / "clinical_tables_manifest.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_path


if __name__ == "__main__":
    p = build_all_clinical_tables_manifest()
    print(f"Tablo ve vaka manifesti üretildi: {p}")
