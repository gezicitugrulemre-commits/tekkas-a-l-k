# part3_ch11_atlas_data.py
"""
Chapter 11: 40 Verified Atlas Slides for Grand Ophthalmology Visual Archive & Diagnostic Atlas.
Deterministik Bölüm ve Sayfa Provenance Eşlemesi (BCSC 12 Bölüm 5, Spalton Bölüm 15,
The Retinal Atlas Bölüm 6, Atlas of Retinal OCT Bölüm 15, Gonioscopy).
"""

ATLAS_SLIDES_DATA = [
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p471_fig471.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Bölüm 15 (s. 471, Şekil 15.2)",
        "title": "Mikroanevrizmalar ve Fokal Sızıntı",
        "key_findings": [
            "Patognomonik Görünüm: Retinal tripsin sindiriminde ve erken FFA'da fokal perisit kaybı sonucu oluşan hiperfloresan sakküler keseler.",
            "OCT ve Derin Pleksus Analizi: Lezyonların büyük çoğunluğu derin kapiller pleksus (DCP / INL) yerleşimlidir ve perifokal seröz sızıntı başlatır.",
            "Hücresel Korelasyon: Perisit apoptozu sonucu zayıflayan kapiller endotel duvarının balonlaşması ve iç kan-retina bariyerinin fokal çöküşü.",
        ],
        "differentials": [
            "Retinal telenjiektazi",
            "Makuler telanjiektazi Tip 2 (MacTel 2)",
        ],
        "pearl": "Klinik İnci: Erken faz FFA'da noktasal hiperfloresans ve geç fazda fokal sızıntı; OCT'de INL tabakasında mikroanevrizma lümeni net seçilir."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p130_fig131.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 130, Şekil 5-2 / ETDRS Std Foto 2A)",
        "title": "Nokta ve Leke Hemorajileri",
        "key_findings": [
            "Patognomonik Görünüm: Dış pleksiform tabakadan (OPL) iç nükleer tabakaya uzanan, dikey hücre mimarisi arasında hapsolmuş yuvarlak kan odakları.",
            "OCT Kesit Mimarisi: Orta retinal katmanlarda vertikal hiperreflektif kitle görünümü ve arkasındaki RPE sinyalinde belirgin akustik gölgelenme.",
            "Hücresel Korelasyon: Derin kapiller pleksustaki venöz staz ve endotel rüptürü; alev hemorajilerinden derinliği ve yuvarlak formuyla ayrılır.",
        ],
        "differentials": [
            "Mikroanevrizma (küçük kırmızı nokta)",
            "Dal retinal ven tıkanıklığı kanamaları",
        ],
        "pearl": "Klinik İnci: INL/OPL yerleşimli leke hemorajileri derin pleksus iskemisini yansıtır; 4 kadranda yaygınlığı ETDRS 4:2:1 kuralının temel direğidir."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p591_fig2035.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 591, Şekil 2035)",
        "title": "Sert Eksüdalar ve Lipid Çökeltileri",
        "key_findings": [
            "Patognomonik Görünüm: Dış pleksiform tabakada (Henle lif tabakası) yoğun posterior optik gölgelenme yapan parlak sarı-beyaz hiperreflektif nodüller.",
            "OCT Kesit Mimarisi: Sert eksüdaların arkasında kalan fotoreseptör tabakalarında ve RPE'de belirgin akustik sinyal kaybı (shadowing).",
            "Hücresel Korelasyon: Kronik mikrovasküler sızıntıdan suyun geri emilmesiyle geride çöken lipoprotein ve doymuş esterleşmiş kolesterol kristalleri.",
        ],
        "differentials": [
            "Drusen (RPE altında bazal laminer birikim)",
            "Retinal astrositom / Kalsifikasyon",
        ],
        "pearl": "Klinik İnci: Dış pleksiform tabakada (OPL) lipoprotein çökeltileri; foveaya yaklaştıkça makula yıldızı ve foveal kistler oluşturarak santral görmeyi bozar."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p484_fig484.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Bölüm 15 (s. 484, Şekil 15.27)",
        "title": "Makuler Sirsinat Halka Morfolojisi",
        "key_findings": [
            "Patognomonik Görünüm: Merkezdeki sızdıran mikroanevrizma kümesinin çevresinde dairesel veya at nalı şeklinde dizilmiş lipid eksüda halkası.",
            "OCT Kesit Mimarisi: Halkanın merkezinde süngerimsi veya kistik retina kalınlaşması, çeperinde ise OPL yerleşimli hiperreflektif lipid agregatları.",
            "Hücresel Korelasyon: Fokal bariyer yıkımı noktasından çevreye yayılan eksüdanın periferik sınırda makrofajlarca sınırlanıp çökelmesi.",
        ],
        "differentials": [
            "Koroid neovaskülarizasyonu eksüdasyonu",
            "Coats hastalığı eksüdatif halkası",
        ],
        "pearl": "Klinik İnci: Halkanın merkezinde daima sızıntı kaynağı olan mikroanevrizma kümesi yer alır; fokal lazer doğrudan bu merkeze titrasyonla uygulanır."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p476_fig476.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Bölüm 15 (s. 476, Şekil 15.10)",
        "title": "Pamuk Atığı Odakları (Cotton-Wool Spots)",
        "key_findings": [
            "Patognomonik Görünüm: Retina sinir lifi tabakasında (RNFL) kabarık, sınırları silik beyaz lezyon ve alttaki retina katmanlarına tam optik gölgelenme.",
            "OCT Kesit Mimarisi: Sinir lifi aksonlarının şişmesi (sitoit cisimcikler); lezyon rezolüsyona uğradığında o odakta kalıcı RNFL incelmesi kalır.",
            "Hücresel Korelasyon: Terminal prekapiller arteriyol tıkanıklığı sonucu aksonal transportun durması, mitokondri ve hücre içi organel yığılması.",
        ],
        "differentials": [
            "Miyelinli sinir lifi (doğuştan, gölge yapmaz)",
            "Retinit odağı (Toksoplazma / CMV)",
        ],
        "pearl": "Klinik İnci: Sinir lifi tabakasında (RNFL) prekapiller arteriyol tıkanıklığı ve aksoplazmik akış durmasıdır; gerçek eksüda değil mikro-retinal enfarkttır."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p130_fig132.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 130, Şekil 5-3 / ETDRS Std Foto 6B)",
        "title": "Venöz Boncuklanma (Venous Beading)",
        "key_findings": [
            "Patognomonik Görünüm: Retinal ven duvarında fokal segmental daralmalar ve anevrizmal dilatasyonların ardışık tespih tanesi (sausage-string) dizilimi.",
            "OCT ve Fundus Analizi: Retinal ven lümen çapında bölgesel düzensizlikler, ven endotelinde kıvrımlanma ve perivenöz doku iskemisi.",
            "Hücresel Korelasyon: Şiddetli retina hipoksisine sekonder venöz endotel proliferasyonu ve damar duvarı elastik liflerinin tonus kaybı.",
        ],
        "differentials": [
            "RVDT venöz kıvrımlanması",
            "Lösemi ve hiperviskozite infiltrasyonu",
        ],
        "pearl": "Klinik İnci: ETDRS 4-2-1 kuralının en güçlü bağımsız PDR prediktörüdür; 2 kadranda varlığı gözü doğrudan Çok Ağır NPDR grubuna sokar."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p131_fig133.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 131, Şekil 5-4 / ETDRS Std Foto 8A)",
        "title": "İntraretinal Mikrovasküler Anormallikler (IRMA)",
        "key_findings": [
            "Patognomonik Görünüm: Renkli fundusta ve FFA'da kılcal damarlar arasında kıvrımlı, genişlemiş şant damarları; iç sınırlayıcı membranı (İLM) ASLA delmez.",
            "FFA ve OCT Ayrımı: FFA'da erken evrede belirginleşir ancak geç evrede masif boya sızdırmaz; neovaskülarizasyondan (NVE) en kritik farkı budur.",
            "Hücresel Korelasyon: İskemik kapiller alanları köprüleyen endotel tomurcuklanması ve arteriyovenöz kollateral şant oluşumu.",
        ],
        "differentials": [
            "NVE (Retina neovaskülarizasyonu - İLM'yi deler ve sızdırır)",
            "Telanjiektatik kollateral damarlar",
        ],
        "pearl": "Klinik İnci: IRMA retina içi kollateral damardır; İLM'yi delmez ve FFA'da sızıntı yapmaz. NVE ise İLM'yi delerek vitreusa doğru büyür ve yoğun sızdırır."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p135_fig135.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 135, Şekil 5-6)",
        "title": "Optik Diskte Neovaskülarizasyon (NVD)",
        "key_findings": [
            "Patognomonik Görünüm: Optik disk üzerinde veya diske 1 disk çapı (DD) mesafede gelişen frajil, kıvrımlı yeni damar yumağı.",
            "FFA Dinamiği: Erken transit fazında hızla hiperfloresans verir, geç fazda ise yoğun ve sınırları taşan masif floresein sızıntısı oluşturur.",
            "Klinik Risk Sınıflaması: NVD alanı 1/4 - 1/3 disk çapından büyükse, göz kanama olmasa dahi doğrudan 'Yüksek Riskli PDR' kategorisine girer.",
        ],
        "differentials": [
            "Optik disk kollateralleri (CRVO sonrası optosiliyer şant)",
            "Persistan hyaloid arter kalıntısı",
        ],
        "pearl": "Klinik İnci: NVD > 1/3 disk alanı ise veya preretinal hemoraji eşlik ediyorsa acil PRP veya anti-VEGF endikasyonu vardır (Yüksek Riskli PDR)."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p135_fig136.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 135, Şekil 5-7)",
        "title": "Retinada Neovaskülarizasyon (NVE)",
        "key_findings": [
            "Patognomonik Görünüm: Optik diske 1 disk çapından daha uzak mesafede, perfüze olmayan iskemik retina sınırında teğetsel büyüyen neovasküler ağ.",
            "OCT Kesiti: İç sınırlayıcı membranı (İLM) delip arka hyaloid yüzeyine tutunan ve hyaloid boyunca uzanan hiperreflektif vasküler tomurcuklar.",
            "FFA Karakteristiği: Erken fazda ağsı vasküler görünüm, geç evrede ise tüm lezyonu örten yoğun diffüz boya göllenmesi.",
        ],
        "differentials": [
            "IRMA (intraretinal kalır, sızıntı yapmaz)",
            "Retinal anjiyomatöz proliferasyon (RAP)",
        ],
        "pearl": "Klinik İnci: NVE daima perfüze olan ve olmayan retinanın sınırında gelişir; vitreus traksiyonu ile koparak ani preretinal/vitreus hemorajisi yaratır."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p482_fig482.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Bölüm 15 (s. 482, Şekil 15.23)",
        "title": "Preretinal ve Subhiyaloit Hemoraji",
        "key_findings": [
            "Patognomonik Görünüm: İç sınırlayıcı membran ile arka hyaloid arasında hapsolmuş, yerçekimi etkisiyle üst sınırı düz (D şeklinde / kayık formunda) kanama.",
            "OCT Kesit Mimarisi: Retina yüzeyinde arka hyaloidi öne doğru kubbeleştiren optik yoğun gölgelenmeli hiperreflektif sıvı-hücre birikimi.",
            "Hücresel Korelasyon: NVD veya NVE'nin arka hyaloid yüzeyine yapışması ve hafif vitreus mikro-hareketiyle damar duvarının yırtılması.",
        ],
        "differentials": [
            "Valsalva retinopatisi kanaması",
            "Terson sendromu preretinal hematomu",
        ],
        "pearl": "Klinik İnci: D şeklindeki yatay seviyelenme kanamanın subhyaloid aralıkta olduğunu kanıtlar; makulayı kapatıyorsa erken YAG lazer hyaloidotomi veya vitrektomi planlanır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p597_fig2073.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 597, Şekil 2073)",
        "title": "Vitreus Hemorajisi",
        "key_findings": [
            "Patognomonik Görünüm: Arka hyaloidin yırtılarak kanın santral vitreus jel boşluğuna dağılması; fundus detaylarının ve kırmızı refleksin tamamen silinmesi.",
            "Ultrasonografi (B-Scan): Vitreus boşluğunda hareketli, düşük ila orta yansıtıcılıklı noktasal ekojeniteler ve arka hyaloid kalınlaşması.",
            "Klinik Yönetim Eşiği: 1 aydan uzun süren veya B-scanda eşlik eden traksiyonel dekolman (TRD) saptanan olgularda 25G/27G pars plana vitrektomi endikedir.",
        ],
        "differentials": [
            "Yırtıklı retina dekolmanına bağlı vitreus kanaması",
            "Terson sendromu / Travmatik hifema-vitreus kanaması",
        ],
        "pearl": "Klinik İnci: Diyabetik bir hastada ani ağrısız tek taraflı görme kaybında fundus görünmüyorsa ilk adım acil B-Scan USG ile retina dekolmanını dışlamaktır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p598_fig2079.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 598, Şekil 2079)",
        "title": "Fibrovasküler Proliferasyon ve Membranlar",
        "key_findings": [
            "Patognomonik Görünüm: Arka kutup ve vasküler arkatlar boyunca uzanan, beyazımsı fibrotik bantlar ve bu bantların içine gömülü gerilemiş neovasküler damarlar.",
            "OCT Dinamiği: Kalınlaşmış arka hyaloid ve iç retina katmanlarına sıkı yapışıklık gösteren, retinayı teğetsel ve anteroposterior çeken fibröz köprüler.",
            "Hücresel Mekanizma: Kronik iskemik uyarı ile astrosit, Müller hücresi ve myofibroblastların proliferasyonu; kollajen senteziyle doku büzüşmesi.",
        ],
        "differentials": [
            "Proliferatif vitreoretinopati (PVR) membranları",
            "Kombine hamartom fibröz plağı",
        ],
        "pearl": "Klinik İnci: Fibrotik doku damarsız beyaz hale geldiyse anti-VEGF enjeksiyonu 'crunch sendromuna' (fibrozisin aniden kasılarak retinanın yırtılmasına) yol açabilir."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p607_fig2124.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 607, Şekil 2124)",
        "title": "Traksiyonel Retina Dekolmanı (TRD)",
        "key_findings": [
            "Patognomonik Görünüm: Konkav yüzeyli, hareketsiz, retinal yırtık içermeyen ve vasküler arkat boyunca retinayı vitreusa doğru çadır gibi kaldıran dekolman.",
            "OCT ve B-Scan Ayrımı: B-scanda yüksek yansıtıcılıklı, hareket etmeyen membran retinanın tepe noktasına yapışıktır; subretinal sıvı seröz ve berraktır.",
            "Cerrahi Eşik: Dekolman foveayı tehdit ediyorsa veya foveayı kaldırdıysa acil pars plana vitrektomi ve membran diseksiyonu zorunludur.",
        ],
        "differentials": [
            "Regmatojen retina dekolmanı (konveks, hareketli, yırtıklı)",
            "Eksüdatif retina dekolmanı (yer değiştiren sıvı)",
        ],
        "pearl": "Klinik İnci: TRD'nin yüzeyi konkavdır (çukur) ve retina yırtığı yoktur; regmatojen dekolmanda ise yüzey konvekstir (tümsek) ve daima yırtık bulunur."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p483_fig483.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Bölüm 15 (s. 483, Şekil 15.25)",
        "title": "Kombine Traksiyonel-Regmatojen Dekolman",
        "key_findings": [
            "Patognomonik Görünüm: Fibröz traksiyon bandının tabanında retinanın gerilerek yırtılması sonucu hem konkav traksiyon hem konveks büllöz dekolman görünümü.",
            "Klinik Seyir: Saf TRD aylarca stabil kalabilirken, yırtık eklendiği anda (kombine TRD-RRD) subretinal sıvı saatler içinde periferden foveaya hızla ilerler.",
            "Cerrahi Yaklaşım: Acil 3 portlu PPV, traksiyon membranlarının segmentasyonu/delaminasyonu, endolazer ve gaz/silikon yağı tamponadı.",
        ],
        "differentials": [
            "Saf traksiyonel retina dekolmanı",
            "Dev yırtıklı regmatojen dekolman",
        ],
        "pearl": "Klinik İnci: Önceden yavaş seyreden bir TRD'de ani görme alanı kaybı ve dekolmanın konveksleşmesi yırtık eklendiğinin (kombine RRD) göstergesidir; acil cerrahi gerekir."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p222_fig146.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 222, Şekil 15.1.2)",
        "title": "Floresein Sızıntısı ve Kapiller Kapanma (FFA)",
        "key_findings": [
            "Patognomonik Görünüm: Erken transit fazında kapiller perfüzyon kaybına bağlı hipofloresan alanlar ile geç fazda endotel sızıntısına bağlı hiperfloresans.",
            "Mikrovasküler Dağılım: Foveal avasküler zon çevresinde güve yeniği tarzında kapiller kesintiler ve geç fazda foveayı saran petaloit boya göllenmesi.",
            "Klinik Çıkarım: FFA sızıntı alanları ile iskemi alanlarını mükemmel ayırır; lazer fokal mikroanevrizmalara uygulanırken iskemik fovea korunmalıdır.",
        ],
        "differentials": [
            "Retinal vaskülit sızıntısı",
            "Santral seröz koryoretinopati duman bacası paterni",
        ],
        "pearl": "Klinik İnci: FFA'da foveal sızıntı ile foveal iskemiyi ayırt etmek hayati önem taşır; iskemik makülopatide sızıntı az olsa da görme potansiyeli düşüktür."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p124_fig127.png",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 124, Şekil 5-1 / OCTA)",
        "title": "Foveal Avasküler Zon (FAZ) Genişlemesi ve İskemi",
        "key_findings": [
            "Patognomonik Görünüm: Yüzeyel ve derin kapiller pleksusta (SCP ve DCP) foveal halkanın parçalanması ve FAZ alanının patolojik genişlemesi (>0.4 mm²).",
            "Derin Pleksus Hassasiyeti: Diyabetik iskemi ilk ve en ağır darbeyi derin kapiller pleksusa (DCP) vurur; santral skotoma ve kontrast kaybı yaratır.",
            "Hücresel Korelasyon: Terminal perifoveal kapillerlerin trombüs ve lökostazla tıkanması sonucu fotoreseptörlerin beslenememesi.",
        ],
        "differentials": [
            "Fizyolojik geniş FAZ (normal varyant, damar uçları düzgündür)",
            "MacTel Tip 2 temporal kapiller kaybı",
        ],
        "pearl": "Klinik İnci: OCT Anjiyografi (OCTA) FAZ konturlarını ve derin pleksus iskemisini boya vermeden mikron düzeyinde gösteren altın standart yöntemdir."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p602_fig2108.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 602, Şekil 2108)",
        "title": "Fokal vs Diffüz Makula Ödemi Sızıntı Paternleri",
        "key_findings": [
            "Patognomonik Görünüm: Fokal DMÖ'de izole mikroanevrizmalardan kaynaklanan lokalize sızıntı; Diffüz DMÖ'de ise tüm foveayı saran yaygın kapiller geçirgenlik.",
            "OCT Mimarisi: Fokal formda lokal kist ve sert eksüda halkası; diffüz formda ise tüm retina katmanlarında süngerimsi kalınlaşma ve yaygın kistler.",
            "Tedavi Yanıtı Farkı: Fokal DMÖ argon lazere mükemmel yanıt verirken, diffüz DMÖ sistemik inflamasyon ve yaygın VEGF salınımına bağlıdır; anti-VEGF gerektirir.",
        ],
        "differentials": [
            "Üveitik makula ödemi",
            "Katarakt cerrahisi sonrası Irvine-Gass sendromu",
        ],
        "pearl": "Klinik İnci: Fokal ödemde sızıntı odağı olan mikroanevrizmalar FFA'da net seçilir ve fokal lazerle kurutulabilir; diffüz ödemde ise ilk tercih daima anti-VEGF'tir."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p223_fig147.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 223, Şekil 15.1.3)",
        "title": "Kistoid Makula Ödemi (KMO) Petaloid Formasyon",
        "key_findings": [
            "Patognomonik Görünüm: İç nükleer tabaka (INL) ve Henle lif tabakasında (OPL) optik olarak boş, yuvarlak/oval hiporeflektif kistik kaviteler.",
            "Petaloid Dağılım: Fovea merkezinde radial dizilimli Müller hücrelerinin anatomik eğimine uyarak çiçek yaprağı (petaloid) tarzında kist dizilimi.",
            "Hücresel Mekanizma: Sıvı göllenmesi ve Müller hücrelerinin aşırı gerilerek lizise uğraması; foveal kon mimarisinin bozulması.",
        ],
        "differentials": [
            "Retinitis pigmentosa kistoid ödemi",
            "Juvenil retinoşizis (iç retinal tabakalarda ayrılma)",
        ],
        "pearl": "Klinik İnci: Kist tavanındaki Müller liflerinin kopması kalıcı foveal incelmeye ve 'foveal kist rüptürüne' yol açar; erken anti-VEGF bu hasarı önler."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p221_fig145.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 221, Şekil 15.1.1)",
        "title": "Süngerimsi Retinal Kalınlaşma (OCT)",
        "key_findings": [
            "Patognomonik Görünüm: Belirgin kistik boşluklar oluşmadan önce retinanın orta ve iç katmanlarında yaygın optik yoğunluk azalması ve kalınlaşma.",
            "OCT Yansıması: İnterstisyel ödem nedeniyle retinanın normal yansıtıcılığının 'süngerimsi' homojen hiporeflektiviteye dönüşmesi.",
            "Evreleme Önemi: Diyabetik makula ödeminin en erken yapısal evresidir; kapiller endotel geçirgenliğinin ilk başladığı dönemi belgeler.",
        ],
        "differentials": [
            "Erken santral seröz retinopati",
            "Kommoyo retina (Berlin ödemi / Travma)",
        ],
        "pearl": "Klinik İnci: Kistler henüz oluşmamışken saptanan süngerimsi kalınlaşma, fotoreseptör hasarı başlamadan anti-VEGF veya lazerle tam anatomik kür şansı verir."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p222_fig146.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 222, Şekil 15.1.2)",
        "title": "Seröz Subretinal Sıvı Dekolmanı (SRF)",
        "key_findings": [
            "Patognomonik Görünüm: Nörosensoryal retina ile retina pigment epiteli (RPE) arasında optik olarak berrak, kubbe şeklinde hiporeflektif sıvı birikimi.",
            "Klinik Anlam: DMÖ olgularının %15-30'unda görülür; dış kan-retina bariyerinin (RPE sıkı bağlantıları) ve RPE pompa fonksiyonunun iflasını gösterir.",
            "İnflamatuar Korelasyon: Subretinal sıvı varlığı yüksek IL-6 ve sitokin düzeyleri ile ilişkilidir; intravitreal steroid implantlara dramatik yanıt verir.",
        ],
        "differentials": [
            "Santral seröz koryoretinopati (paki-koroid)",
            "Yaş tip YBMD koroid neovaskülarizasyonu",
        ],
        "pearl": "Klinik İnci: DMÖ'de seröz dekolman varlığı dış kan-retina bariyeri çöküşünü ve yoğun inflamasyonu gösterir; anti-VEGF'e dirençli vakalarda steroid anahtardır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p605_fig2119.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 605, Şekil 2119)",
        "title": "Hiperreflektif Odaklar (HRF) ve Lipofuskin",
        "key_findings": [
            "Patognomonik Görünüm: Tüm retina katmanlarında (özellikle iç ve orta katmanlarda) saçılmış, akustik gölge yapmayan, <30 µm mikro-noktasal hiperreflektiviteler.",
            "Hücresel Köken: Aktive olmuş ve lipid yutmuş mikroglia hücreleri ile lipid yüklü makrofajların migrasyonunu temsil eder.",
            "Prognostik Değer: Yüksek HRF sayısı aktif inflamatuar süreci gösterir; anti-VEGF monoterapisine zayıf, steroid tedavisine güçlü yanıt göstergesidir.",
        ],
        "differentials": [
            "Sert eksüdalar (büyüktür ve arkasında derin gölge bırakır)",
            "Retinal damar kesiti (perfüzyon lümeni ile ayrılır)",
        ],
        "pearl": "Klinik İnci: HRF'ler sert eksüdalardan küçüktür (<30 µm) ve arka gölge yapmaz; aktive mikrogliaları simgeleyen güçlü bir inflamatuar biyobelirteçtir."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p225_fig149.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 225, Şekil 15.2.2)",
        "title": "DRIL (İç Retina Katmanlarının Düzensizleşmesi)",
        "key_findings": [
            "Patognomonik Görünüm: Foveal 1 mm alanda ganglion hücre tabakası (GCL), iç pleksiform (IPL) ve iç nükleer tabaka (INL) sınırlarının ayırt edilememesi.",
            "Fonksiyonel Anlam: Foveadaki bipolar, amakrin ve yatay hücrelerin aksonal bağlantılarının kalıcı kaybını gösterir.",
            "En Güçlü Görme Prediktörü: Makula ödemi anti-VEGF ile tamamen kurusa dahi, DRIL varlığında görme keskinliği artmaz; kalıcı görme kaybını öngörür.",
        ],
        "differentials": [
            "Şiddetli kistoid ödem kaynaklı optik maskeleme",
            "Retinal enfarkt (akut evre solukluğu)",
        ],
        "pearl": "Klinik İnci: DRIL > 500 µm ise ödem gerilese bile görme artışı sınırlı kalır; anatomik kuruma ile fonksiyonel başarı arasındaki uyumsuzluğun baş nedenidir."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 131, Şekil 5-5 / Protokol AA)",
        "title": "Ultra Geniş Açılı (UWF) FFA Periferik İskemi",
        "key_findings": [
            "Patognomonik Görünüm: Optos 200 derece UWF-FFA'da ekvator ötesi orta ve uzak periferik retinada 360 derece kapiller dolum yokluğu.",
            "Görüş Alanı Devrimi: Klasik 7-alan ETDRS görüntüsünün (75 derece) yakalayamadığı dev periferik non-perfüzyon alanlarını ve gizli NVE odaklarını saptar.",
            "Klinik Risk Artışı: DRCR.net Protokol AA uyarınca periferik non-perfüzyon alanı arttıkça 4 yıllık PDR gelişim riski 3.2 kat artmaktadır.",
        ],
        "differentials": [
            "Orak hücreli retinopati periferik iskemisi (deniz yelpazesi)",
            "Eales hastalığı periferik vasküliti",
        ],
        "pearl": "Klinik İnci: UWF-FFA sadece arka kutba bakma yanılgısını bitirmiştir; periferik iskemisi geniş olan NPDR gözleri hızla proliferatif evreye ilerler."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg",
        "provenance": "AAO BCSC Section 12, Bölüm 5 (s. 131, Şekil 5-5 / PPL)",
        "title": "Predominantly Peripheral Lesions (PPL)",
        "key_findings": [
            "Patognomonik Görünüm: Retinal kanama, mikroanevrizma ve IRMA'ların standart ETDRS 7-alan dışındaki periferik sahada arka kutuptan daha yoğun olması.",
            "DRCR.net Protokol AA Tanımı: Bir gözde lezyon şiddet skoru periferde posterior polden en az bir derece yüksekse o göz 'PPL Pozitif' kabul edilir.",
            "Prognostik Anlam: Başlangıçta PPL saptanan gözlerde klinik evre hafif görünse dahi PDR'ye ilerleme riski belirgin olarak katlanmaktadır.",
        ],
        "differentials": [
            "Standart arka kutup diyabetik retinopatisi",
            "Periferik retina vasküliti",
        ],
        "pearl": "Klinik İnci: PPL pozitif NPDR olguları standart tablolardan çok daha hızlı dekompanse olur; takip aralıkları daraltılmalı ve erken tedavi düşünülmelidir."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p594_fig2052.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Bölüm 6 (s. 594, Şekil 2052)",
        "title": "İskemi İndeksi ve Non-Perfüzyon Alanları",
        "key_findings": [
            "Patognomonik Görünüm: FFA görüntüsünde kapiller ağı perfüze olmayan siyah avasküler sahaların toplam retina yüzölçümüne oranı (İskemi İndeksi).",
            "İskemi Eşiği: İskemi İndeksi %30-35'in üzerine çıktığında intraoküler VEGF konsantrasyonu kritik eşiği aşarak masif NVD ve NVE gelişimini tetikler.",
            "Klinik Korelasyon: İskemik alanların genişliği tedaviye dirençli refrakter makula ödeminin en önemli sistemik sürükleyicisidir.",
        ],
        "differentials": [
            "Retinal dal arter tıkanıklığı kapiller perfüzyonsuzluğu",
            "Radyasyon retinopatisi iskemisi",
        ],
        "pearl": "Klinik İnci: İskemi indeksi arttıkça makula ödemi anti-VEGF'e dirençli hale gelir; periferik iskemik sahalara selektif lazer eklenmesi bu kısırdöngüyü kırabilir."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p487_fig487.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Chapter 15 (s. 487, Şekil 15.33)",
        "title": "İris Neovaskülarizasyonu (Rubeosis Iridis)",
        "key_findings": [
            "Patognomonik Görünüm: Pupilla kenarında (sfinkter kenarında) ince, kıvrımlı, radyal olmayan patolojik damar tomurcuklarının belirmesi.",
            "İlerleme Patern: Pupilla kenarından başlayarak iris stroması üzerinden ön kamara açısına ve trabeküler ağa doğru ilerler.",
            "Kritik Alarm: Retinanın global olarak aşırı derecede hipoksik kaldığını gösteren en tehlikeli ön segment alarm bulgusudur.",
        ],
        "differentials": [
            "Normal iris damarları (kalındır, radyal seyreder ve sızdırmaz)",
            "Fuchs heterokromik iridosikliti ince damarlanması",
        ],
        "pearl": "Klinik İnci: Diyabetik bir hastada pupilla kenarında tek bir rubeozis damarı dahi görseniz, arka segmentte dev bir iskemi var demektir; derhal acil PRP planlanmalıdır."
    },
    {
        "img": "Gonioscopy_A_Text_and_Atlas_p049_fig081.jpeg",
        "provenance": "Gonioscopy: A Text and Atlas (s. 49, Şekil 81)",
        "title": "Gonioskopide Açı Neovaskülarizasyonu",
        "key_findings": [
            "Patognomonik Görünüm: Trabeküler ağ ve sklera mahmuzu üzerinde ağ gibi örülen, Schwalbe çizgisini aşan patolojik yeni damarlar.",
            "Gonyoskopik Muayene Şartı: Rubeozis iridis henüz pupilla kenarında çok belirgin değilken dahi ön kamara açısında sessizce başlayabilir.",
            "Fibröz Membran Oluşumu: Yeni damarlara eşlik eden şeffaf myofibroblastik membran trabeküler ağ gözeneklerini tıkayarak aköz dışa akımını engeller.",
        ],
        "differentials": [
            "Normal açı damarları (siliyer cisim bandında seyreder, ağı aşmaz)",
            "Eksfoliasyon sendromu açı pigmentasyonu",
        ],
        "pearl": "Klinik İnci: İriste rubeozis görmeseniz bile yüksek riskli PDR hastalarında açı gonyoskopisi zorunludur; açı damarları kapanmadan lazer yapılırsa göz kurtulur."
    },
    {
        "img": "Gonioscopy_A_Text_and_Atlas_p076_fig146.jpeg",
        "provenance": "Gonioscopy: A Text and Atlas (s. 76, Şekil 146)",
        "title": "Neovasküler Glokom (NVG) ve Göz İçi Basınç Krizi",
        "key_findings": [
            "Patognomonik Görünüm: Fibröz membranın kasılmasıyla irisin trabeküler ağa yapışması (periferik anterior sineşi - PAS) ve açının 360 derece fermuar gibi kapanması.",
            "Klinik Tablo: Refrakter göz içi basıncı (>50-60 mmHg), kornea epitel ödemi, şiddetli göz ve baş ağrısı, bulantı ve körlük tablosu.",
            "Yönetim Mimarisi: Acil anti-VEGF enjeksiyonu, GİB düşürücü tıbbi tedavi, retinal iskemi için PRP ve dirençli olgularda Glokom Drenaj İmplantı (Ahmed/Baerveldt).",
        ],
        "differentials": [
            "Akut açı kapanması glokomu (pupiller blok)",
            "Fakolitik glokom / İridosiklit krizi",
        ],
        "pearl": "Klinik İnci: Açı tamamen kapandıktan sonra (sineşik evre) anti-VEGF damarları geriletse bile GİB düşmez; çünkü mekanik trabeküler ağ tahrip olmuştur, cerrahi kaçınılmazdır."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p492_fig492.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Chapter 15 (s. 492, Şekil 15.39)",
        "title": "Fokal Argon Lazer Yanıkları ve Skarları",
        "key_findings": [
            "Patognomonik Görünüm: Fovea avasküler zonunu koruyarak, sızdıran mikroanevrizma kümelerine uygulanan 50-100 µm boyutlu hafif gri-beyaz yanık odakları.",
            "Geç Dönem Değişimi: Yanıklar zamanla RPE hiperpigmentasyonu ve koryoretinal atrofi skarlarına dönüşür; foveaya doğru lazer skar genişlemesi (laser creep) riski vardır.",
            "Etki Mekanizması: Sızdıran endotelin doğrudan koagülasyonu ve sağlıklı RPE hücrelerinin prolifere edilerek kan-retina bariyerinin onarılması.",
        ],
        "differentials": [
            "Grid lazer paternleri",
            "Toksik koryoretinit skarları",
        ],
        "pearl": "Klinik İnci: Fokal lazer fovea merkezine 500 µm'den daha yakın mikroanevrizmalara uygulanmaz; koryoretinal skar yıllar içinde foveaya doğru genişleyebilir."
    },
    {
        "img": "12-Retina_and_Vitreous_2025-2026_p140_fig139.jpeg",
        "provenance": "AAO BCSC Section 12, Chapter 5 (s. 140, Şekil 5-10)",
        "title": "Panretinal Fotokoagülasyon (PRP) Yanık Paternleri",
        "key_findings": [
            "Patognomonik Görünüm: Arka kutup ve arkatlar korunarak, ekvatordan ora serrataya kadar retinanın tamamına uygulanan 1200-1600 adet 500 µm'lik lazer yanığı.",
            "Olgunlaşma Süreci: Akut beyaz yanıklar haftalar içinde pigmentli, sınırlı koryoretinal atrofi adacıklarına dönüşür.",
            "Fizyolojik Prensip: Oksijen tüketen hipoksik fotoreseptörlerin ablasyonu ile koroitten iç retinaya oksijen difüzyonunun artırılması ve VEGF üretiminin kalıcı çökertilmesi.",
        ],
        "differentials": [
            "Kriyoterapi skarları (daha geniştir ve kaba pigmentasyon yapar)",
            "Yaygın koryoretinit sekelleri",
        ],
        "pearl": "Klinik İnci: PRP, yüksek riskli PDR'de ciddi görme kaybı riskini %50'den fazla azaltan cerrahi kalıcılıkta altın standarttır; anti-VEGF gibi kesilince nüksetmez."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p610_fig2136.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 610, Şekil 2136)",
        "title": "Navigasyonlu Lazer (Navilas) ve Subthreshold Grid",
        "key_findings": [
            "Patognomonik Görünüm: Canlı göz takip sistemi (eye-tracking) ile önceden çekilen FFA/OCT haritası üzerine mikron hassasiyetinde dijital lazer atışları.",
            "Subthreshold (Eşikaltı) Prensip: Görünür retinal yanık ve fotoreseptör hasarı oluşturmadan, yalnızca RPE hücrelerini ısıtarak ısı şok proteinlerini (HSP) aktive etme.",
            "Avantajı: Foveaya çok yakın sızıntılarda dahi skotoma ve skar genişlemesi riski olmadan ödemi geriletme olanağı sunar.",
        ],
        "differentials": [
            "Konvansiyonel argon lazer",
            "Mikrodarbe (Micropulse) lazer sistemleri",
        ],
        "pearl": "Klinik İnci: Navigasyonlu lazerde hedeflenen her mikroanevrizma dijital olarak kaydedilir ve hasta hareket etse bile yanlış atış yapılması imkansızdır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p616_fig2159.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 616, Şekil 2159)",
        "title": "Anti-VEGF Öncesi ve Sonrası Anatomik Yanıt (OCT)",
        "key_findings": [
            "Patognomonik Görünüm: İntravitreal anti-VEGF enjeksiyonu (Aflibercept/Ranibizumab/Faricimab) sonrası 1. ayda santral foveal kalınlıkta dramatik azalma.",
            "OCT Mimarisi: İntraretinal kistoid boşlukların ve seröz subretinal sıvının tamamen rezorbe olması; foveal çukurun (foveal kontur) anatomik olarak yeniden belirmesi.",
            "Protokol T Kanıtı: Başlangıç görmesi 20/50 veya daha kötü olan olgularda aflibercept en hızlı ve en yüksek harf artışı sağlayan ajandır.",
        ],
        "differentials": [
            "Spontan rezolüsyon (çok nadir ve aylar sürer)",
            "Steroid yanıtı (katarakt ve glokom gelişimi eşlik edebilir)",
        ],
        "pearl": "Klinik İnci: Anti-VEGF ile anatomik kuruma genellikle ilk enjeksiyonla başlar; ancak görme artışının kalıcı olması için stabilite sağlanana kadar yükleme dozu şarttır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p617_fig2161.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 617, Şekil 2161)",
        "title": "İntravitreal Steroid (Deksametazon İmplant) Anatomik Yanıtı",
        "key_findings": [
            "Patognomonik Görünüm: Alt vitreus boşluğunda yavaş salınımlı beyaz silindirik Ozurdex implantı ve eş zamanlı masif santral kuruma.",
            "Çoklu Yolak Blokajı: Sadece VEGF'i değil, IL-6, ICAM-1, MCP-1 ve prostoglandinleri de bloke ederek endotel sıkı bağlantılarını (tight junction) yeniden stabilize eder.",
            "Özel Endikasyon: Vitrektomize gözlerde anti-VEGF yarı ömrü saatlere düşerken Ozurdex klerensi değişmez; vitrektomize ve psödofak gözlerde ilk tercihtir.",
        ],
        "differentials": [
            "Triamsinolon asetonid süspansiyonu",
            "Fluosinolon asetonid (Iluvien implantı)",
        ],
        "pearl": "Klinik İnci: Psödofakik veya vitrektomize diyabetik hastalarda ve anti-VEGF'e yanıtsız seröz dekolmanlı olgularda deksametazon implantı en yüksek anatomik başarıyı verir."
    },
    {
        "img": "Atlas_of_Retinal_OCT_2nd_Ed__p226_fig151.jpeg",
        "provenance": "Atlas of Retinal OCT 2nd Ed, Section 15 (s. 226, Şekil 15.2.4)",
        "title": "Persistan / Refrakter DMÖ OCT Paternleri",
        "key_findings": [
            "Patognomonik Görünüm: En az 3-6 ardışık aylık anti-VEGF enjeksiyonuna rağmen santral retinal kalınlığın (CST) >300-350 µm üzerinde takılı kalması.",
            "Altta Yatan Patoloji: Kronik iskemik doku hipoksisi, yaygın kapiller dökülme, DRIL varlığı ve VEGF dışı inflamatuar mediyatörlerin baskın hale gelmesi.",
            "Klinik Manevra: Anti-VEGF molekül değişimi (switch - Faricimab çift anjiyopoietin-2 inhibisyonu) veya Deksametazon implanta geçiş.",
        ],
        "differentials": [
            "Vitreomakuler traksiyona bağlı mekanik ödem (cerrahi gerektirir)",
            "Eşlik eden hipertansif ya da renal kriz ödemi",
        ],
        "pearl": "Klinik İnci: Refrakter DMÖ'de körlemesine aynı anti-VEGF'e devam etmek faydasızdır; 3. dozdan sonra anatomik yanıt yoksa Faricimab veya Ozurdex'e geçilmelidir."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p615_fig2152.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 615, Şekil 2152)",
        "title": "Vitrektomi Sonrası Retinal Yatışma ve Membran Temizliği",
        "key_findings": [
            "Patognomonik Görünüm: Cerrahi olarak tüm fibrovasküler membranların delamine edildiği, retinanın RPE üzerine tam yatıştığı postoperatif fundus görüntüsü.",
            "Cerrahi Bulgular: Arka hyaloidin tam soyulması, retina yüzeyindeki traksiyonel güçlerin sıfırlanması ve periferik retinanın 360 derece endolazerlenmesi.",
            "Görsel İyileşme Potansiyeli: Makula cerrahi öncesi 6 aydan daha kısa süre dekolmanda kaldıysa postoperatif 2-4 sıra Snellen görme kazanımı mümkündür.",
        ],
        "differentials": [
            "Kalıntı epiretinal membran ve nüks traksiyon",
            "Postoperatif makula ödemi",
        ],
        "pearl": "Klinik İnci: Diyabetik vitrektomide başarı traksiyonun retinanın tamamından teğetsel ve dikine eksiksiz temizlenmesine ve agresif 360 endolazere bağlıdır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p601_fig2100.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 601, Şekil 2100)",
        "title": "Diabetik Papillopati ve Optik Disk Ödemi",
        "key_findings": [
            "Patognomonik Görünüm: Diyabetik hastalarda görme keskinliği genellikle iyi korunmuşken, optik diskte telanjiektatik damarlanma ve belirgin hiperemi/ödem.",
            "Ayırıcı Tanı Masası: NVD'den en büyük farkı diskin iskemik değil hiperemik olması ve FFA'da erken yoğun masif sızıntı yerine geç diffüz boyanma yapmasıdır.",
            "Doğal Seyir: Genellikle 6-12 ay içinde optik atrofi bırakmadan kendiliğinden geriler; intrakraniyal kafa içi basınç artışı (papilödem) mutlaka dışlanmalıdır.",
        ],
        "differentials": [
            "NVD (neovaskülarizasyon - FFA'da erken evreden itibaren şiddetle sızdırır)",
            "Non-arteritik anterior iskemik optik nöropati (NAİON - ani ağır görme kaybı yapar)",
        ],
        "pearl": "Klinik İnci: Diabetik papillopati benign ve kendini sınırlayan bir tablodur; NVD ile karıştırılıp gereksiz panretinal lazer yapılmamalıdır."
    },
    {
        "img": "Atlas_of_Clinical_Ophthalmology_Spalton_3rd_Ed__p489_fig489.jpeg",
        "provenance": "Spalton Clinical Ophthalmology 3rd Ed, Chapter 15 (s. 489, Şekil 15.33)",
        "title": "Optik Atrofi ve Glokomatöz Çanaklaşma",
        "key_findings": [
            "Patognomonik Görünüm: Terminal PDR veya neovasküler glokom krizi sonrasında optik disk nöroretinal halkasının tamamen solması ve çanaklaşması (C/D >0.9).",
            "Mikroyapısal Hasar: RNFL tabakasında tam aksonal kayıp, lamina kribroza gözeneklerinin açığa çıkması ve foveal ganglion hücre kompleksinin (GCC) çöküşü.",
            "Son Evre: Görme ışık hissi (LP) veya el hareketi (HM) seviyesindedir; tedavi hedefini ağrıyı dindirmek ve gözü korumak oluşturur.",
        ],
        "differentials": [
            "Primer açık açılı glokom son dönemi",
            "Santral retinal arter tıkanıklığı sekeli soluk disk",
        ],
        "pearl": "Klinik İnci: Neovasküler glokomda göz içi basıncı düşürülse bile gelişen optik atrofi geri dönüşsüzdür; tüm çaba gözü bu aşamaya getirmeden erken lazer yapmaktır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p592_fig2043.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 592, Şekil 2043)",
        "title": "Retinal Arter Dal Tıkanıklığı ve Diyabet Birlikteliği",
        "key_findings": [
            "Patognomonik Görünüm: Ağır diyabetik mikrovaskülopati zemininde fokal terminal retinal arteriyol dalının tıkanmasıyla oluşan kama şeklinde opasifiye soluk retina.",
            "Sistemik Risk: Diyabete eşlik eden karotis aterosklerozu, hipertansiyon ve hiperlipidemi zemininde embolik (Hollenhorst plağı) kökenli gelişir.",
            "OCT Görünümü: Akut evrede iç retinal katmanlarda hiperreflektivite ve kalınlaşma, kronik evrede ise tam bir iç katman atrofisi.",
        ],
        "differentials": [
            "Pamuk atığı odağı (küçük ve lokalizedir)",
            "Santral retinal arter tıkanıklığı (tüm retina soluk, kiraz kırmızısı benek)",
        ],
        "pearl": "Klinik İnci: Diyabetik bir hastada arter dal tıkanıklığı saptandığında acil karotis Doppler ultrasonografisi ve kardiyak emboli odağı araştırması zorunludur."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p593_fig2046.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 593, Şekil 2046)",
        "title": "Asteroid Hiyalozis ve Diyabetik Fundus",
        "key_findings": [
            "Patognomonik Görünüm: Vitreus boşluğunda asılı duran, altın sarısı veya beyaz parıltılı binlerce mikroskobik kalsiyum-lipid küreciği (kalsiyum sabunları).",
            "Diyabet Birlikteliği: Asteroid hiyalozis diyabetli hastalarda normal popülasyondan belirgin derecede daha sık görülür (%30'a varan korelasyon).",
            "Görüntüleme Zorluğu: Oftalmoskopi ve fundus fotoğraflarında retinayı perdeleyebilir; ancak FFA ve OCT görüntülemesini şaşırtıcı şekilde çok az bozar.",
        ],
        "differentials": [
            "Senil senşizis sintillans (serbestçe dibe çöken kolesterol kristalleri)",
            "Amiloidoz vitreus infiltrasyonu",
        ],
        "pearl": "Klinik İnci: Asteroid hiyalozis hastanın görmesini nadiren bozar ancak hekimin lazer yapmasını engelliyorsa veya vitreus kanamasını gizliyorsa vitrektomi yapılır."
    },
    {
        "img": "THE_RETINAL_ATLAS_2nd_Ed__p614_fig2148.jpeg",
        "provenance": "The Retinal Atlas 2nd Ed, Chapter 6 (s. 614, Şekil 2148)",
        "title": "Silikon Yağı ve Gaz Tamponadı Altında Diyabetik Retina",
        "key_findings": [
            "Patognomonik Görünüm: Cerrahi sonrasında vitreus boşluğunu dolduran şeffaf silikon yağı refleksi veya gerileyen gaz kabarcığı altında yatışmış retina ve eksiksiz PRP skarları.",
            "Tamponad Fonksiyonu: Nörosensoryal retinayı fiziksel olarak RPE'ye yapıştırır, kanamaların vitreusa dağılmasını önler ve rezidüel traksiyonu engeller.",
            "Silikon Emülsifikasyonu: Uzun süreli silikon varlığında ön kamaraya silikon yağı damlacıklarının geçmesi (emülsifikasyon) ve sekonder açık kapanması riski.",
        ],
        "differentials": [
            "C3F8 ve SF6 gaz tamponadı (kendiliğinden emilir)",
            "Ağır silikon yağı (Densiron - alt retina yırtıkları için)",
        ],
        "pearl": "Klinik İnci: Silikon yağı altındaki diyabetik retinada nüks neovaskülarizasyon olmaması için cerrahi sırasında veya sonrasında lazer eksiksiz tamamlanmalıdır."
    },
]
