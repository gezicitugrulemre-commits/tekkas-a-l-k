import pptx
import sys
import json

sys.stdout.reconfigure(encoding='utf-8')

pptx_path = r'c:\Users\gezic\OneDrive\Desktop\Anti Gravity\Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass_REVIZE.pptx'
prs = pptx.Presentation(pptx_path)

print(f"Toplam Slayt Sayısı: {len(prs.slides)}")

test_slides = [138, 145, 206, 276, 302, 309, 363, 364, 389, 412]

print("\nKritik Slaytlar Denetim Sonuçları:")
print("=" * 80)
for idx in test_slides:
    slide = prs.slides[idx - 1]
    title = ""
    category = ""
    caption = ""
    has_pic = False
    pic_dims = None
    
    for shp in slide.shapes:
        if shp.name == 'Category Badge' or (shp.has_text_frame and 'BÖLÜM' in shp.text_frame.text):
            category = shp.text_frame.text.strip().replace('\n', ' ')
        elif shp.name == 'Slide Title' or (shp.has_text_frame and not title and len(shp.text_frame.text.strip()) > 5):
            title = shp.text_frame.text.strip().replace('\n', ' ')
        if shp.shape_type == 13: # picture
            has_pic = True
            pic_dims = f"{shp.width/914400:.2f}x{shp.height/914400:.2f} inç"
        if shp.has_text_frame and '📷' in shp.text_frame.text:
            caption = shp.text_frame.text.strip().replace('\n', ' ')

    print(f"Slayt {idx:03d}:")
    print(f"  Başlık : {title}")
    print(f"  Görsel : {has_pic} ({pic_dims})")
    print(f"  Altyazı: {caption}")
    print("-" * 80)
