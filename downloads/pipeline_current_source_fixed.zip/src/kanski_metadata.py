# -*- coding: utf-8 -*-
"""
Kanski's Clinical Ophthalmology (10. Baskı, Salmon 2025)
Bölüm Meta Verileri, Sayfa Aralıkları ve Tam Türkçe Akademik Terminoloji Matrisi
"""

from typing import Dict, List, TypedDict


class ChapterMeta(TypedDict):
    id: int
    title_en: str
    title_tr: str
    book_start_page: int
    book_end_page: int
    pdf_start_page: int
    pdf_end_page: int
    page_count: int
    target_questions: int
    core_subsections: List[str]
    high_yield_keywords: List[str]


PDF_PAGE_OFFSET = 12

CHAPTERS_METADATA: Dict[int, ChapterMeta] = {
    1: {
        "id": 1,
        "title_en": "Examination Techniques",
        "title_tr": "Muayene Yöntemleri ve Tanısal Testler",
        "book_start_page": 1,
        "book_end_page": 36,
        "pdf_start_page": 13,
        "pdf_end_page": 48,
        "page_count": 36,
        "target_questions": 120,
        "core_subsections": [
            "Oftalmik Öykü Alma ve Görme Keskinliği Değerlendirmesi (Snellen, LogMAR ve ETDRS Eşelleri)",
            "Psikofiziksel Testler (Kontrast Duyarlılığı, Renk Görme: Ishihara, Farnsworth-Munsell 100-Hue, City Testi)",
            "Perimetri ve Görme Alanı Analizi (Statik Otomatize Perimetri, Kinetik Goldmann, SITA Standart ve Hızlı Algoritmaları)",
            "Biyomikroskopi ve Ön Segment Görüntülemesi (Yarık Lamba Biyomikroskopisi ve Ön Segment OKT)",
            "Fundus Muayenesi ve Retinal Görüntüleme (Doğrudan ve Dolaylı Oftalmoskopi, 78D, 90D ve SuperField Lensleri)",
            "Tonometri ve Göz İçi Basıncı Ölçümü (Goldmann Aplanasyon, Dinamik Kontur, Tonopen, iCare ve Oküler Yanıt Analizörü)",
            "Gonyoskopi ve Ön Kamara Açısı Evrelemesi (Goldmann, Posner, Sussman Lensleri; Shaffer ve Spaeth Sınıflaması)",
            "Merkezi Kornea Kalınlığı ve Pakimetrik Düzeltme Protokolleri"
        ],
        "high_yield_keywords": [
            "LogMAR minimum rezolüsyon açısı (*minimum angle of resolution* - MAR)",
            "Ishihara renk görme tarama testi (*Ishihara pseudoisochromatic plates*)",
            "Farnsworth-Munsell 100-hue renk ayrım testi (*Farnsworth-Munsell test*)",
            "SITA standart eşik perimetri stratejisi (*SITA standard perimetry*)",
            "İzopter eğrileri ve skotom morfolojisi (*isopter & scotoma analysis*)",
            "Goldmann aplanasyon tonometrisi ve Imbert-Fick prensibi (*Goldmann applanation*)",
            "Gonyoskopik açı anatomisi ve trabeküler ağ değerlendirmesi (*gonioscopic angle*)",
            "Shaffer ve Spaeth açı derecelendirme şemaları (*Shaffer & Spaeth grading*)",
            "Merkezi kornea kalınlığı ve aplanasyon tonometri düzeltmesi (*CCT pachymetry*)",
            "Amsler gridi ile makula fonksiyon testi (*Amsler grid testing*)"
        ]
    },
    2: {
        "id": 2,
        "title_en": "Eyelids",
        "title_tr": "Göz Kapakları ve Oküloplasti",
        "book_start_page": 37,
        "book_end_page": 96,
        "pdf_start_page": 49,
        "pdf_end_page": 108,
        "page_count": 60,
        "target_questions": 150,
        "core_subsections": [
            "İyi Huylu ve İnflamatuar Kapak Lezyonları (Şalazyon, Arpacık, Epidermal Kistler, Papillom)",
            "İyi Huylu Pigmente ve Adneksiyal Tümörler (Nevüsler, Siringom, Pilomatriksoma, Ksantelazma)",
            "Kötü Huylu Kapak Tümörleri (Bazal Hücreli Karsinom, Skuamöz Hücreli Karsinom, Sebase Karsinom, Malign Melanom)",
            "Kirpik Bozuklukları (Trikiyazis, Distikiyazis, Madarozis, Poliozis)",
            "Alerjik ve İmmün İlişkili Blefaritler (Kontakt Dermatit, Atopik Blefarit, Seboreik Blefarit)",
            "Bakteriyel ve Viral Kapak Enfeksiyonları (Preseptal Selülit, Herpes Zoster Oftalmikus, Molluscum Contagiosum)",
            "Pitozis: Etyolojik Sınıflandırma, Tanısal Ölçümler ve Cerrahi Onarım İlkeleri",
            "Ektropion ve Entropion: İnvolüsyonel Mekanizmalar, Klinik Tipler ve Cerrahi Düzeltme Yöntemleri",
            "Blefaroplasti ve Gevşek Kapak Sendromu (Floppy Eyelid Sendromu)"
        ],
        "high_yield_keywords": [
            "Bazal hücreli karsinom nodüloülseratif tipi (*basal cell carcinoma* - BCC)",
            "Sebase bez karsinomu ve Pagetoid yayılım (*sebaceous gland carcinoma*)",
            "Muir-Torre sendromu ve iç organ maligniteleri (*Muir-Torre syndrome*)",
            "Levator fonksiyonu ve marjinal refleks mesafesi (*MRD-1 & MRD-2*)",
            "Müller kası rezeksiyonu ve Fasanella-Servat ameliyatı (*Fasanella-Servat procedure*)",
            "Frontalis askı cerrahisi endikasyonları (*frontalis suspension sling*)",
            "Gevşek kapak sendromu ve obstrüktif uyku apnesi (*floppy eyelid syndrome*)",
            "İnvolüsyonel ektropion ve horizontal kantal laksite (*horizontal laxity*)",
            "Quickert sütür tekniği ve lateral tarsal şerit ameliyatı (*lateral tarsal strip*)"
        ]
    },
    3: {
        "id": 3,
        "title_en": "Lacrimal Drainage System",
        "title_tr": "Gözyaşı Drenaj Sistemi ve Epifora",
        "book_start_page": 97,
        "book_end_page": 112,
        "pdf_start_page": 109,
        "pdf_end_page": 124,
        "page_count": 16,
        "target_questions": 100,
        "core_subsections": [
            "Gözyaşı Pompasının Anatomisi, Fizyolojisi ve Lakrimal Kinetik",
            "Epifora Muayenesi ve Ayırıcı Tanı (Floresein Kaybolma Testi, Jones I ve Jones II Boya Testleri)",
            "Konjenital Nazolakrimal Kanal Tıkanıklığı ve Hasner Valfi İmperforasyonu",
            "Edinsel Nazolakrimal Kanal Tıkanıklığı ve Punktum Darlıkları",
            "Akut ve Kronik Dakriyosistit: Medikal Tedavi Protokolleri ve Cerrahi Zamanlama",
            "Kanalikülit ve Dakriyolitiazis (Actinomyces israelii Enfeksiyonu)",
            "Gözyaşı Yolu Cerrahi Yaklaşımları: Sondalama, Silikon Tüp Entübasyonu, Eksternal ve Endoskopik DCR"
        ],
        "high_yield_keywords": [
            "Hasner valfi imperforasyonu ve konjenital darlık (*valve of Hasner*)",
            "Jones I ve Jones II primer-sekonder boya testleri (*Jones dye tests*)",
            "Lakrimal sondalama ve lavaj tekniği (*lacrimal probing & syringing*)",
            "Actinomyces israelii ve kükürt granülleri (*Actinomyces canaliculitis*)",
            "Dakriyosistorinostomi endikasyonları ve ostium tasarımı (*DCR surgery*)",
            "Bikanaliküler silikon tüp entübasyonu (*silicone tube intubation*)",
            "Lester Jones baypas tüpü cerrahisi (*Lester Jones glass tube*)"
        ]
    },
    4: {
        "id": 4,
        "title_en": "Orbit",
        "title_tr": "Orbita Hastalıkları ve Tümörleri",
        "book_start_page": 113,
        "book_end_page": 156,
        "pdf_start_page": 125,
        "pdf_end_page": 168,
        "page_count": 44,
        "target_questions": 130,
        "core_subsections": [
            "Orbita Anatomisi, Cerrahi Boşluklar, Topografi ve Radyolojik Değerlendirme",
            "Tiroid Göz Hastalığı (Graves Orbitopatisi: İmmünopatogenez, NOSPECS ve Klinik Aktivite Skoru [CAS])",
            "Orbita Enfeksiyonları: Preseptal ve Postseptal (Orbital) Selülit, Subperiosteal Apse ve Mukormikozis",
            "İdiyopatik Orbital İnflamatuar Hastalık (Orbital Psödotümör) ve IgG4 İlişkili Sklerozan Hastalık",
            "Orbita Vasküler Lezyonları: Kapiller Hemanjiom, Kavernöz Venöz Malformasyon ve Karotikokavernöz Fistül",
            "Erişkin Çağı Orbita Tümörleri (MALT Lenfoma, Menenjiom, Schwannom, Adenoid Kistik Karsinom)",
            "Çocukluk Çağı Orbita Kitleleri (Rabdomyosarkom, Dermoid Kist, Metastatik Nöroblastom)"
        ],
        "high_yield_keywords": [
            "Graves orbitopatisi ve rektus kas tutulum paterni (*Graves ophthalmopathy*)",
            "NOSPECS ve Klinik Aktivite Skoru (*CAS scoring system*)",
            "Teprotumumab ve IGF-1 reseptör hedefli tedaviler (*teprotumumab*)",
            "Preseptal selülit ile orbital selülit ayırıcı tanısı (*orbital cellulitis*)",
            "Rinoserebral mukormikozis acil yönetimi (*rhinocerebral mucormycosis*)",
            "IgG4 ilişkili oftalmik hastalık (*IgG4-related ophthalmic disease*)",
            "Düşük ve yüksek debili karotikokavernöz fistül (*carotid-cavernous fistula*)",
            "Embriyonal rabdomyosarkom acil biyopsisi (*orbital rhabdomyosarcoma*)",
            "Orbita apeks sendromu ve superior orbital fissür sendromu (*orbital apex syndrome*)"
        ]
    },
    5: {
        "id": 5,
        "title_en": "Dry Eye",
        "title_tr": "Kuru Göz ve Oküler Yüzey Bozuklukları",
        "book_start_page": 157,
        "book_end_page": 168,
        "pdf_start_page": 169,
        "pdf_end_page": 180,
        "page_count": 12,
        "target_questions": 100,
        "core_subsections": [
            "TFOS DEWS II Tanımı, Etyopatogenezi ve Kuru Göz Sınıflandırması",
            "Aköz Yetmezlikli Kuru Göz (Sjögren Sendromu ve Non-Sjögren Tabloları)",
            "Buharlaşma Artışına Bağlı Kuru Göz ve Meibomius Bezi Disfonksiyonu (MGD)",
            "Tanısal Klinik Testler: Gözyaşı Kırılma Zamanı (TBUT), Osmolarite, MMP-9 ve Schirmer Testleri (I ve II)",
            "Basamaklı Kuru Göz Tedavi Protokolleri: Suni Gözyaşları, Siklosporin, Lifitegrast, Punktum Tıkaçları ve Otolog Serum"
        ],
        "high_yield_keywords": [
            "TFOS DEWS II kılavuz sınıflandırması (*TFOS DEWS II criteria*)",
            "Schirmer I ve Schirmer II test farkları (*Schirmer testing*)",
            "Gözyaşı filmi kırılma zamanı eşik değerleri (*tear breakup time* - TBUT)",
            "Gözyaşı osmolaritesi ve inter-oküler değişkenlik (*tear osmolarity*)",
            "Matriks metalloproteinaz-9 pozitifliği (*MMP-9 biomarker*)",
            "Meibomius bezi disfonksiyonu evrelemesi (*meibomian gland dysfunction* - MGD)",
            "Sjögren sendromu tanısal kriterleri (*Sjögren syndrome*)",
            "Topikal Siklosporin A ve Lifitegrast etki mekanizması (*cyclosporine & lifitegrast*)"
        ]
    },
    6: {
        "id": 6,
        "title_en": "Conjunctiva",
        "title_tr": "Konjonktiva Hastalıkları",
        "book_start_page": 169,
        "book_end_page": 204,
        "pdf_start_page": 181,
        "pdf_end_page": 216,
        "page_count": 36,
        "target_questions": 120,
        "core_subsections": [
            "Konjonktival Klinik Yanıtlar: Folikül ve Papilla Ayrımı, Membran ve Psödomembran Morfolojisi",
            "Bakteriyel Konjonktivitler: Akut Pürülan, Hiperakut Gonokok Enfeksiyonu ve Trahom (Klamidya)",
            "Viral Konjonktivitler: Adenoviral Epidemik Keratokonjonktivit (EKC), Faringokonjonktival Ateş ve Molluskum",
            "Alerjik Konjonktivit Spektrumu: Mevsimsel/Pereniyal, Vernal (VKC), Atopik (AKC) ve Dev Papiller Konjonktivit (GPC)",
            "Sikatrisyel Konjonktivitler: Oküler Skatrisyel Pemfigoid (OCP) ve Stevens-Johnson Sendromu (SJS/TEN)",
            "Dejeneratif Konjonktiva Durumları: Pinguekula ve Pterjiyum (Etyopatogenez, Otogreft Cerrahisi ve Mitomisin C)",
            "Konjonktiva Neoplazileri: Konjonktival İntraepitelyal Neoplazi (CIN/OSSN), Primer Edinsel Melanozis (PAM) ve Melanom"
        ],
        "high_yield_keywords": [
            "Dünya Sağlık Örgütü Trahom SAFE stratejisi (*WHO SAFE strategy*)",
            "Neisseria gonorrhoeae hiperakut pürülan konjonktiviti (*gonococcal conjunctivitis*)",
            "Epidemik keratokonjonktivit ve subepitelyal infiltratlar (*EKC infiltrates*)",
            "Vernal keratokonjonktivit, Horner-Trantas noktaları ve kalkan ülseri (*VKC shield ulcer*)",
            "Oküler sikatrisyel pemfigoid ve konjonktival büzüşme (*ocular cicatricial pemphigoid*)",
            "Oküler yüzey skuamöz neoplazisi ve cerrahi sınır kontrolü (*OSSN*)",
            "Mitomisin C ve İnterferon alfa-2b topikal kemoterapisi (*interferon alfa-2b*)"
        ]
    },
    7: {
        "id": 7,
        "title_en": "Cornea",
        "title_tr": "Kornea Hastalıkları ve Distrofileri",
        "book_start_page": 205,
        "book_end_page": 274,
        "pdf_start_page": 217,
        "pdf_end_page": 286,
        "page_count": 70,
        "target_questions": 160,
        "core_subsections": [
            "Enfeksiyöz Keratitler: Bakteriyel (Pseudomonas, Stafilokok, Streptokok), Fungal (Aspergillus, Kandida) ve Acanthamoeba",
            "Herpetik Keratitler: Herpes Simpleks (Epitelyal Dendritik/Coğrafi, Nekrotizan Stromal, İmmün Stromal, Endoteliit)",
            "Herpes Zoster Oftalmikus (Psödodendritler, Nörotropik Komplikasyonlar ve Post-herpetik Nevralji)",
            "Periferik Ülseratif Keratit (PUK) ve Mooren Ülseri Ayırıcı Tanısı",
            "Kornea Distrofileri (IC3D Sınıflandırması: Epitelyal/Subepitelyal, Stromal TGFBI Mutasyonları, Endotelyal Fuchs)",
            "Korneal Ektaziler: Keratokonus (Belin-Ambrósio Tomografisi, Çapraz Bağlama [CXL], İntrastromal Halkalar), Pellusid Marjinal Dejenerasyon",
            "Nörotrofik Keratopati (Mackie Evrelemesi ve Rekombinant İnsan Sinir Büyüme Faktörü - Cenegermin)",
            "Metabolik ve Toksik Keratopati: Vortex Keratopati (Kornea Verticillata) ve Fabry Hastalığı"
        ],
        "high_yield_keywords": [
            "Acanthamoeba keratitinde radyal perinörit ve kist morfolojisi (*Acanthamoeba perineural infiltrates*)",
            "Herpes simpleks dendritik ülseri ve terminal ampul bulgusu (*HSV dendritic ulcer*)",
            "IC3D kornea distrofisi anatomik sınıflandırması (*IC3D classification*)",
            "TGFBI geni ilişkili kornea distrofileri: Granüler, Kafes tipi (*TGFBI corneal dystrophies*)",
            "Fuchs endotelyal kornea distrofisi ve kornea guttataları (*Fuchs endothelial dystrophy*)",
            "Keratokonus progresyon kriterleri ve korneal çapraz bağlama (*corneal cross-linking* - CXL)",
            "Periferik ülseratif keratit ve altta yatan sistemik vaskülit (*peripheral ulcerative keratitis*)",
            "Cenegermin tedavisi ve nörotrofik kornea iyileşmesi (*cenegermin*)"
        ]
    },
    8: {
        "id": 8,
        "title_en": "Corneal and Refractive Surgery",
        "title_tr": "Kornea Nakli ve Refraktif Cerrahi",
        "book_start_page": 275,
        "book_end_page": 290,
        "pdf_start_page": 287,
        "pdf_end_page": 302,
        "page_count": 16,
        "target_questions": 100,
        "core_subsections": [
            "Penetran Keratoplasti (PK): Endikasyonlar, Cerrahi Teknik ve Greft Reddi Tipleri (Endotelyal, Epitelyal, Stromal)",
            "Endotelyal Keratoplasti Teknikleri: DSAEK ve DMEK (Greft Hazırlama, Ters Greft Tanısı, Re-bubbling ve Klinik Sonuçlar)",
            "Derin Ön Lameller Keratoplasti (DALK): Büyük Balon (Big-Bubble) Tekniği ve Endotel Koruyucu Yaklaşım",
            "Keratoprotez Cerrahisi (Boston Tip 1 ve Osteo-Odonto-Keratoprotez)",
            "Lazer Refraktif Cerrahi: PRK, LASIK ve SMILE (Ablasyon Profilleri, Flep Komplikasyonları, DLK ve Ektazi Riski)",
            "Fakik İntraoküler Lensler (ICL) ve Refraktif Lens Değişimi (RLE)"
        ],
        "high_yield_keywords": [
            "Descemet membran endotelyal keratoplasti (*DMEK*)",
            "Descemet stripping otomatize endotelyal keratoplasti (*DSAEK*)",
            "DALK cerrahisinde Anwar büyük balon tekniği (*big-bubble technique*)",
            "Khodadoust endotelyal red çizgisi (*Khodadoust line*)",
            "SMILE refraktif cerrahi lentikül ekstraksiyonu (*SMILE surgery*)",
            "Diffüz lameller keratit ve kum fırtınası görüntüsü (*diffuse lamellar keratitis* - DLK)",
            "Lazer refraktif cerrahi sonrası korneal ektazi (*post-LASIK ectasia*)",
            "Fakik arka kamara intraoküler lensleri (*phakic ICL*)"
        ]
    },
    9: {
        "id": 9,
        "title_en": "Episclera and Sclera",
        "title_tr": "Episkler ve Skler Hastalıkları",
        "book_start_page": 291,
        "book_end_page": 306,
        "pdf_start_page": 303,
        "pdf_end_page": 318,
        "page_count": 16,
        "target_questions": 100,
        "core_subsections": [
            "Episklerit: Basit ve Nodüler Tipler (Klinik Ayrım, Fenilefrin %2.5 Testi, Kendiliğinden İyileşme Seyri)",
            "Ön Sklerit: Nekrotizan Olmayan (Diffüz ve Nodüler) ile Nekrotizan Sklerit (Enflamasyonlu vs Skleromalazi Perforans)",
            "Arka Sklerit: Klinik Prezentasyon (B-taramada T-belirtisi, Koroidal Katlantılar, Optik Disk Ödemi)",
            "Sistemik İlişkiler: Romatoid Artrit, Polianjitli Granülomatozis (Wegener / GPA), Tekrarlayıcı Polikondrit",
            "Basamaklı Sistemik İmmünsüpresif Tedavi: Oral NSAİİ, Sistemik Kortikosteroidler ve Biyolojik Ajanlar (Rituksimab, İnfliksimab)"
        ],
        "high_yield_keywords": [
            "Topikal fenilefrin testi ile episklerit-sklerit ayrımı (*phenylephrine test*)",
            "Skleromalazi perforans ve romatoid artrit birlikteliği (*scleromalacia perforans*)",
            "Arka skleritte ultrasonografik T-belirtisi (*posterior scleritis T-sign*)",
            "Polianjitli granülomatozis ve c-ANCA pozitifliği (*granulomatosis with polyangiitis*)",
            "Nekrotizan skleritte acil sistemik steroid ve immünsüpresyon (*necrotizing scleritis*)",
            "Rituksimab ve biyolojik ajan protokolleri (*rituximab therapy*)"
        ]
    },
    10: {
        "id": 10,
        "title_en": "Lens",
        "title_tr": "Lens Hastalıkları ve Katarakt Cerrahisi",
        "book_start_page": 307,
        "book_end_page": 344,
        "pdf_start_page": 319,
        "pdf_end_page": 356,
        "page_count": 38,
        "target_questions": 120,
        "core_subsections": [
            "Edinsel Katarakt Tipleri: Nükleer Sklerotik, Kortikal, Arka Subkapsüler (PSC) ve Matür/Hipermatür Morgagnian",
            "Konjenital ve Pediatrik Kataraktlar: Rubella, Lowe Sendromu, Galaktozemi ve Deprivasyon Ambliyopisi Yönetimi",
            "Lens Ektopisi ve Sublüksasyonu: Marfan Sendromu, Homosistinüri, Weill-Marchesani Sendromu ve Travma",
            "Ameliyat Öncesi Biyometri: Keratometri, Aksiyel Uzunluk ve Yeni Kuşak GİL Formülleri (Barrett Universal II, Kane, Hill-RBF)",
            "Fakoemülsifikasyon Cerrahisi: Kesi Mimarisi, Sürekli Eğrisel Kapsüloreksis, Nükleus Parçalama Teknikleri",
            "Ameliyat İçi Komplikasyonlar: Arka Kapsül Rüptürü (AKR), Zonüler Diyaliz ve Vitreusa Düşen Nükleus Parçaları",
            "Ameliyat Sonrası Komplikasyonlar: Akut Endoftalmi (ESCRS İntrakameral Sefuroksim Profilaksisi), TASS ve Arka Kapsül Opasitesi (PCO)"
        ],
        "high_yield_keywords": [
            "Arka subkapsüler katarakt ve steroid ilişkisi (*posterior subcapsular cataract*)",
            "Marfan sendromunda yukarı-dışa lens subluksasyonu (*Marfan ectopia lentis*)",
            "Homosistinüride aşağı-içe lens lüksasyonu (*homocystinuria lens dislocation*)",
            "Barrett Universal II ve Kane yapay zeka biyometri formülleri (*IOL calculation formulas*)",
            "Arka kapsül rüptüründe ön vitrektomi ilkeleri (*posterior capsule rupture*)",
            "İntrakameral sefuroksim profilaksisi ile endoftalmi önleme (*cefuroxime prophylaxis*)",
            "Toksik ön segment sendromu ile enfeksiyöz endoftalmi ayrımı (*TASS vs endophthalmitis*)",
            "Nd:YAG lazer arka kapsülotomi zamanlaması ve güvenliği (*Nd:YAG capsulotomy*)"
        ]
    },
    11: {
        "id": 11,
        "title_en": "Glaucoma",
        "title_tr": "Glokom ve Oküler Hipertansiyon",
        "book_start_page": 345,
        "book_end_page": 428,
        "pdf_start_page": 357,
        "pdf_end_page": 440,
        "page_count": 84,
        "target_questions": 180,
        "core_subsections": [
            "Aköz Dinamiği, Trabeküler Dışaakım Yolları ve Optik Sinir Başı Biyomekaniği",
            "Primer Açık Açılı Glokom (POAG): Patogenez, Hedef GİB Tayini, OKT RNFL ve Gangliyon Hücre Kompleksi (GCC) Analizi",
            "Normal Tansiyonlu Glokom (NTG): Gece Hipotansiyonu, Optik Disk Hemorajisi (Drance) ve Vazospastik Durumlar",
            "Oküler Hipertansiyon (OHT) ve OHTS Risk Tahmin Kılavuzu",
            "Primer Açı Kapanması Spektrumu (PACS, PAC, PACG): Akut Kriz Tedavisi, Lazer Periferik İridotomi ve Erken Lens Ekstraksiyonu (EAGLE Çalışması)",
            "Sekonder Açık Açılı Glokomlar: Psödoeksfoliasyon (PEX), Pigmenter Glokom, Neovasküler Glokom (NVG) ve Steroid Glokomu",
            "Sekonder Açı Kapanması Glokomları: Fakomorfik Glokom, İridokorneal Endotelyal (ICE) Sendromları ve Aköz Yönlenme Bozukluğu (Malign Glokom)",
            "Gelişimsel Glokomlar: Primer Konjenital Glokom (Haab Çizgileri, Buphtalmos, Gonyotomi/Trabekülotomi) ve Axenfeld-Rieger Anomalisi",
            "Glokom Medikal Tedavisi: Prostaglandin Analogları, Beta-Blokörler, Alfa-2 Agonistler, Karbonik Anhidraz İnhibitörleri ve Rho Kinaz İnhibitörleri (Netarsudil)",
            "Lazer ve Cerrahi Yöntemler: Selektif Lazer Trabeküloplasti (LiGHT Çalışması), Trabekülektomi + MMC, Drenaj İmplantları (Ahmed vs Baerveldt) ve MİGS"
        ],
        "high_yield_keywords": [
            "Primer açık açılı glokom ve hedef göz içi basıncı (*POAG target IOP*)",
            "Optik koherens tomografide RNFL ve GCC progresyon analizi (*OCT RNFL analysis*)",
            "Normal tansiyonlu glokomda Drance tipi optik disk kanaması (*Drance disc haemorrhage*)",
            "EAGLE klinik çalışması ve primer açı kapanmasında lens ekstraksiyonu (*EAGLE trial*)",
            "LiGHT çalışması doğrultusunda birinci basamak SLT lazer (*LiGHT trial SLT*)",
            "Psödoeksfoliasyon sendromunda zonül zayıflığı ve glokom riski (*pseudoexfoliation*)",
            "Pigment dispersiyon sendromu ve Krukenberg iği (*pigmentary glaucoma*)",
            "Malign glokom (aköz yönlenme bozukluğu) yönetimi (*aqueous misdirection*)",
            "Trabekülektomi cerrahisinde Mitomisin C kullanımı (*trabeculectomy with MMC*)",
            "Ahmed ve Baerveldt glokom tüp implantasyon karşılaştırmaları (*glaucoma drainage devices*)"
        ]
    },
    12: {
        "id": 12,
        "title_en": "Uveitis",
        "title_tr": "Üveit ve Oküler İnflamatuar Hastalıklar",
        "book_start_page": 429,
        "book_end_page": 504,
        "pdf_start_page": 441,
        "pdf_end_page": 516,
        "page_count": 76,
        "target_questions": 170,
        "core_subsections": [
            "SUN (Standardization of Uveitis Nomenclature) Anatomik Sınıflaması, Hücre ve Parlama Derecelendirmesi",
            "Ön Üveitler: HLA-B27 İlişkili Spondiloartropatiler (Ankilozan Spondilit, Reaktif Artrit, İBH), Fuchs Üveitik Sendromu ve Posner-Schlossman",
            "İntermedyer Üveit ve Pars Planit (Kartopu ve Kar Yığını Bulguları, Vitreus Kondansasyonu)",
            "Arka Üveit ve Retinokoroiditler: Oküler Toksoplazmozis (Siste Far Işığı Görünümü), Toksokariyazis, Sitomegalovirüs Retiniti ve Akut Retinal Nekroz (ARN)",
            "Beyaz Nokta Sendromları: APMPPE, MEWDS, Kuşkonmaz Koryoretinopatisi (Birdshot, HLA-A29), Serpinöz Koroit ve Multifokal Koroidit (PIC/MCP)",
            "Sistemik Enfeksiyöz Üveitler: Oküler Tüberküloz, Oküler Sifiliz (Büyük Taklitçi) ve Lyme Hastalığı",
            "Sistemik Non-enfeksiyöz Üveitler: Sarkoidoz (Koyun Yağı KP, Şamdan Damlası Vaskülit), Behçet Hastalığı (Hipopiyon, Obliteratif Retinal Vaskülit), VKH Sendromu ve Sempatik Oftalmi",
            "Sistemik ve Lokal Kortikosteroidler, Konvansiyonel İmmünsüpresifler (Metotreksat, Azatioprin, Mikofenolat) ve Biyolojik Ajanlar (Adalimumab / VISUAL Çalışmaları)"
        ],
        "high_yield_keywords": [
            "SUN ön kamara hücre ve flare derecelendirme standardı (*SUN classification*)",
            "HLA-B27 ilişkili akut anterior üveit özellikleri (*HLA-B27 anterior uveitis*)",
            "Fuchs üveitik sendromunda diffüz stellat KP ve rubella ilişkisi (*Fuchs uveitis*)",
            "Posner-Schlossman glokomatöz siklitik kriz (*glaucomatocyclitic crisis*)",
            "Oküler toksoplazmoziste hiperpigmente skar kenarında aktif odak (*toxoplasmosis*)",
            "Birdshot koryoretinopatisi ve HLA-A29 pozitifliği (*Birdshot chorioretinopathy*)",
            "Behçet hastalığında tekrarlayıcı hipopiyon ve nekrotizan vaskülit (*Behçet uveitis*)",
            "Vogt-Koyanagi-Harada sendromu ve gün batımı fundusu (*sunset-glow fundus in VKH*)",
            "Sempatik oftalmide penetran travma öyküsü ve Dalen-Fuchs nodülleri (*sympathetic ophthalmia*)",
            "Adalimumab biyolojik tedavisi ve VISUAL Faz 3 çalışmaları (*adalimumab in uveitis*)"
        ]
    },
    13: {
        "id": 13,
        "title_en": "Retinal Vascular Disease",
        "title_tr": "Retinal Vasküler Hastalıklar",
        "book_start_page": 505,
        "book_end_page": 564,
        "pdf_start_page": 517,
        "pdf_end_page": 576,
        "page_count": 60,
        "target_questions": 150,
        "core_subsections": [
            "Diyabetik Retinopati (DR): Mikroanevrizmalar, IRMA, Sert Eksüdalar, Pamuk Atığı Odakları ve Ağır NPDR için ETDRS 4-2-1 Kuralı",
            "Proliferatif Diyabetik Retinopati (PDR): NVD, NVE, Yüksek Risk Kriterleri, Panretinal Fotokoagülasyon (PRP) ve Anti-VEGF Yaklaşımları",
            "Diyabetik Makula Ödemi (DMO): Santral Tutulumlu ve Santral Tutulumsuz Ödem, DRCR.net Klinik Çalışma Protokolleri (Protokol T, V, W)",
            "Retinal Ven Tıkanıklıkları (RVO): Santral Retinal Ven Tıkanıklığı (İskemik vs Non-iskemik, 100 Gün Glokomu), Dal Ven Tıkanıklığı, Anti-VEGF ve Deksametazon İmplantları",
            "Retinal Arter Tıkanıklıkları (RAO): Santral Retinal Arter Tıkanıklığı (Kiraz Kırmızısı Benek, Akut Triyaj), Dal Retinal Arter Tıkanıklığı ve Dev Hücreli Arterit Taraması (ESR/CRP)",
            "Hipertansif Retinopati ve Malign Hipertansiyon (Keith-Wagener-Barker Evrelemesi, Elschnig Noktaları, Siegrist Çizgileri)",
            "Retinal Arter Makroanevrizması (RAM), Coats Hastalığı, Eales Hastalığı ve Ailesel Eksüdatif Vitreoretinopati (FEVR)",
            "Prematüre Retinopatisi (ROP): ICROP3 Uluslararası Sınıflaması (Zonlar, Evreler, Plus Hastalığı), Lazer ve İntravitreal Anti-VEGF Tedavileri"
        ],
        "high_yield_keywords": [
            "ETDRS 4-2-1 kuralı ile proliferatif evreye ilerleme riski (*ETDRS 4-2-1 rule*)",
            "DRCR.net Protokol T görme keskinliğine göre anti-VEGF seçimi (*DRCR.net Protocol T*)",
            "Santral tutulumlu diyabetik makula ödemi eşikleri (*center-involving DMO*)",
            "İskemik santral retinal ven tıkanıklığı ve neovasküler glokom riski (*ischaemic CRVO*)",
            "Santral retinal arter tıkanıklığında kiraz kırmızısı benek bulgusu (*cherry-red spot in CRAO*)",
            "Dev hücreli arterit taramasında sedimentasyon ve CRP zorunluluğu (*giant cell arteritis*)",
            "Coats hastalığında tek taraflı telenjiektaziler ve eksüdatif dekolman (*Coats disease*)",
            "ICROP3 sınıflamasında agressif prematüre retinopatisi (*ICROP3 ROP classification*)",
            "Optik koherens tomografi anjiyografide foveal avasküler bölge genişlemesi (*FAZ on OCTA*)"
        ]
    },
    14: {
        "id": 14,
        "title_en": "Acquired Macular Disorders",
        "title_tr": "Edinsel Makula Hastalıkları ve Yaşa Bağlı Makula Dejenerasyonu",
        "book_start_page": 565,
        "book_end_page": 626,
        "pdf_start_page": 577,
        "pdf_end_page": 638,
        "page_count": 62,
        "target_questions": 150,
        "core_subsections": [
            "Yaşa Bağlı Makula Dejenerasyonu (YBMD): Sert ve Yumuşak Druzenler, Retiküler Psödodruzenler, AREDS Sınıflaması ve Antioksidan Destekleri",
            "Neovasküler Olmayan YBMD ve Coğrafi Atrofi (GA): Kompleman Kaskadı İnhibitörleri (Pegsetakoplan, Avaksinkaptad Pegol)",
            "Neovasküler YBMD (nYBMD): Tip 1 (Sub-RPE), Tip 2 (Subretinal), Tip 3 (Retinal Anjiyomatöz Proliferasyon - RAP) ve Polipoidal Koroidal Vaskülopati (PCV)",
            "Anti-VEGF Tedavi Rejimleri (Ranibizumab, Aflibersept 2mg/8mg, Farikimab [Çift Ang-2/VEGF-A İnhibitörü]): PRN ve Treat-and-Extend (T&E) Protokolleri",
            "Santral Seröz Koryoretinopati (SSKR): Pakikoroid Spektrumu, Subretinal Sıvı Dinamiği, Yarım Doz Fotodinamik Tedavi (PDT)",
            "Vitreomaküler Arayüz Bozuklukları: Vitreomaküler Adezyon (VMA), Vitreomaküler Traksiyon (VMT), Epiretinal Membran (ERM) ve Makula Deliği (Gass Evrelemesi, Ters Çevrilmiş İLM Flebi)",
            "Miyopik Makulopati: Arka Stafilom, Vernik Çatlakları (Lacquer Cracks), Miyopik KNV ve Foveoşizis",
            "Diğer Edinsel Makulopatiler: Maküler Telenjiektazi Tip 2 (MacTel 2) ve Hidroksiklorokin Retinal Toksisitesi Taraması (AAO Kılavuzları)"
        ],
        "high_yield_keywords": [
            "AREDS2 klinik çalışma formülasyonu ve lutein/zeaksantin (*AREDS2 formulation*)",
            "Coğrafi atrofide kompleman C3 ve C5 inhibitör tedavileri (*complement inhibitors in GA*)",
            "Tip 1, Tip 2 ve Tip 3 koroid neovaskülarizasyon ayrımı (*neovascular AMD subtypes*)",
            "Polipoidal koroidal vaskülopati ve indosiyanin yeşili anjiyografisi (*PCV on ICGA*)",
            "Farikimab ile anjiyopoietin-2 ve VEGF-A eşzamanlı inhibisyonu (*faricimab dual inhibition*)",
            "Treat-and-extend kişiselleştirilmiş enjeksiyon rejimleri (*treat-and-extend regimen*)",
            "Santral seröz koryoretinopatide pakikoroid neovaskülarizasyon (*pachychoroid spectrum*)",
            "Tam kat makula deliğinde cerrahi internal limitan membran soyulması (*macular hole ILM peel*)",
            "Hidroksiklorokin retinopatisi erken teşhisinde 10-2 görme alanı ve FAF (*hydroxychloroquine screening*)"
        ]
    },
    15: {
        "id": 15,
        "title_en": "Inherited Retinal Degenerations",
        "title_tr": "Kalıtsal Retina Distrofileri ve Elektrofizyoloji",
        "book_start_page": 627,
        "book_end_page": 664,
        "pdf_start_page": 639,
        "pdf_end_page": 676,
        "page_count": 38,
        "target_questions": 120,
        "core_subsections": [
            "Retinitis Pigmentosa (RP): Genetik Kalıtım (Otozomal Dominant, Resesif, X'e Bağlı), Kemik Spikülü Pigmentasyonu, Balık Pulu Solukluk, RPE65 Gen Tedavisi (Voretigene Neparvovec)",
            "Retinitis Pigmentosa ile İlişkili Sistemik Sendromlar: Usher Sendromu (Tip 1-3), Bardet-Biedl, Bassen-Kornzweig, Refsum ve Kearns-Sayre Sendromları",
            "Stargardt Hastalığı (Fundus Flavimaculatus): ABCA4 Gen Mutasyonları, Floresein Anjiyografide Sessiz Koroid (Karanlık Koroid) ve Boğa Gözü Makulopati",
            "Best Vitelliform Makula Distrofisi (BEST1): Klinik Evreler (Previtemliform, Yumurta Sarısı, Psödohipopiyon, Parçalanmış Yumurta, Atrofik), EOG Arden Oranı Anormalliği (<1.5)",
            "Koni ve Koni-Rod Distrofileri: Klinik Fenotip, Fotofobi, Renk Körlüğü ve ERG Sönmesi",
            "X'e Bağlı Retinoşizis (XLRS): RS1 Mutasyonu, Foveal Tekerlek Parmaklığı Yarıkları, Periferik Şizis ve Negatif ERG Prensibi (Normal a-dalgası, Baskılanmış b-dalgası)",
            "Oküler ve Okülokütanöz Albinizm: Foveal Hipoplazi, İris Transillüminasyonu ve Kiazmal Hatalı Lif Dağılımı",
            "Oftalmik Elektrofizyoloji Standartları (ISCEV Kılavuzları): Tam Alan Flaş ERG (Skotopik ve Fotopik), Patern ERG, Multifokal ERG ve EOG"
        ],
        "high_yield_keywords": [
            "Retinitis pigmentosa triadı: Kemik spikülleri, balmumu optik disk, incelmiş damarlar (*RP triad*)",
            "Voretigene neparvovec AAV2 aracılı gen replasman tedavisi (*voretigene neparvovec RPE65*)",
            "Usher sendromunda sensorinöral işitme kaybı ve vestibüler disfonksiyon (*Usher syndrome*)",
            "Stargardt hastalığında lipofuskin birikimi ve karanlık koroid bulgusu (*silent choroid on FFA*)",
            "Best vitelliform distrofisinde elektro-okülografi Arden oranı düşüklüğü (*Arden ratio in Best disease*)",
            "X'e bağlı retinoşiziste negatif elektroretinogram dalga formu (*electronegative ERG in XLRS*)",
            "ISCEV standart elektroretinografi protokol basamakları (*ISCEV ERG standards*)",
            "Foveal hipoplazi derecelendirmesi ve optik koherens tomografi (*foveal hypoplasia*)"
        ]
    },
    16: {
        "id": 16,
        "title_en": "Retinal Detachment",
        "title_tr": "Retina Dekolmanı ve Vitreoretinal Cerrahi",
        "book_start_page": 665,
        "book_end_page": 700,
        "pdf_start_page": 677,
        "pdf_end_page": 712,
        "page_count": 36,
        "target_questions": 120,
        "core_subsections": [
            "Arka Vitreus Dekolmanı (PVD): Weiss Halkası, Fotopsi, Uçuşan Cisimler ve Retinal Yırtık Riski",
            "Yırtık Gelişimine Zemin Hazırlayan Periferik Retina Lezyonları: Kafes (Lattice) Dejenerasyonu, Salyangoz İzi, Dejeneratif Retinoşizis, At nalı Yırtıklar",
            "Yırtıklı (Regmatojen) Retina Dekolmanı (RRD): Patogenez, Primer Yırtığın Yerini Belirlemede Lincoff Kuralları, Ön Vitreusta Tütün Tozu (Shafer Belirtisi)",
            "Traksiyonel Retina Dekolmanı (TRD): İçbükey Yüzey, Hareketsiz Retina, Yırtık Bulunmayışı (PDR ve Travma Etiyolojisi)",
            "Eksüdatif (Seröz) Retina Dekolmanı (ERD): Yer Değiştiren Sıvı (Shifting Fluid), Dışbükey Düzgün Yüzey (VKH, Coats Hastalığı, Koroid Melanomu)",
            "Proliferatif Vitreoretinopati (PVR): Patofizyoloji, Retina Derneği Evreleme Sistemi (Evre A, B, C)",
            "Vitreoretinal Cerrahi Yaklaşımlar: Skleral Çökertme (Kriyopeksi, Serklaj Bandı, Radyal Sünger), Pnömatik Retinopeksi, Pars Plana Vitrektomi ve Gaz (SF6, C3F8) / Silikon Yağı Tamponadı"
        ],
        "high_yield_keywords": [
            "Lincoff kuralları ile primer retinal yırtık lokalizasyonu (*Lincoff rules for RRD*)",
            "Ön vitreusta Shafer belirtisi (tütün tozu görünümü) (*Shafer sign tobacco dust*)",
            "At nalı yırtıkta vitreoretinal traksiyon dinamikleri (*horseshoe retinal tear*)",
            "Kafes (lattice) dejenerasyonu profilaktik lazer endikasyonları (*lattice degeneration*)",
            "Proliferatif vitreoretinopati ve periretinal membran kontraktürü (*proliferative vitreoretinopathy*)",
            "Pnömatik retinopeksi seçim kriterleri ve gaz dinamikleri (*pneumatic retinopexy*)",
            "Pars plana vitrektomide SF6 ve C3F8 gaz tamponad kinetiği (*gas tamponade SF6 C3F8*)",
            "Silikon yağı emülsifikasyonu ve ikincil glokom yönetimi (*silicone oil emulsification*)"
        ]
    },
    17: {
        "id": 17,
        "title_en": "Vitreous Opacities",
        "title_tr": "Vitreus Opasiteleri ve Bozuklukları",
        "book_start_page": 701,
        "book_end_page": 706,
        "pdf_start_page": 713,
        "pdf_end_page": 718,
        "page_count": 6,
        "target_questions": 100,
        "core_subsections": [
            "Asteroid Hiyalozis: Kalsiyum-Lipid Kompleksleri, Tek Taraflı Baskınlık, Görme Keskinliğine Etkisi ve Serum Kalsiyum Düzeyiyle İlişkisizliği",
            "Sinkizis Sintillans (Kolesterolozis Bulbi): Sıvılaşmış Vitreusta Polikromatik Kolesterol Kristalleri, İleri Derecede Harap Olmuş Göz Etiyolojisi",
            "Vitreus Amiloidozu: Transtiretin (TTR) Gen Mutasyonları, İki Taraflı Cam Yünü Opasiteleri ve Tanısal Vitrektomi Biyopsisi",
            "Kalıcı Fetal Vaskülatür (PFV / PHPV): Ön ve Arka Tipler, Mittendorf Noktası, Bergmeister Papillası ve Mikroftalmi Birlikteliği",
            "Vitreus Kanaması: Etyolojik Ayırıcı Tanı (PDR, Retinal Yırtık, RVO, Travma, Terson Sendromu), B-tarama USG ile Retina Kontrolü ve Vitrektomi Zamanlaması"
        ],
        "high_yield_keywords": [
            "Asteroid hiyalozis kalsiyum sabunları ve görme korunumu (*asteroid hyalosis*)",
            "Sinkizis sintillans serbest kolesterol kristalleri ayrımı (*synchysis scintillans*)",
            "Ailesel amiloidozda cam yünü vitreus opasiteleri (*vitreous amyloidosis*)",
            "Kalıcı fetal vaskülatür ve retrolental fibröz doku (*persistent foetal vasculature* - PFV)",
            "Mittendorf noktası ve Bergmeister papillası embriyolojik kalıntıları (*Mittendorf dot*)",
            "Subaraknoid kanama ilişkili Terson sendromu (*Terson syndrome vitreous haemorrhage*)",
            "Opak vitreus ortamında B-tarama ultrasonografik değerlendirme (*B-scan ultrasound*)"
        ]
    },
    18: {
        "id": 18,
        "title_en": "Strabismus",
        "title_tr": "Şaşılık, Oküler Motilite ve Ambliyopi",
        "book_start_page": 707,
        "book_end_page": 756,
        "pdf_start_page": 719,
        "pdf_end_page": 768,
        "page_count": 50,
        "target_questions": 135,
        "core_subsections": [
            "Ekstraoküler Kas Anatomisi ve Motor Kanunlar (Hering Eşit İnnervasyon Kanunu, Sherrington Resiprokal İnnervasyon Kanunu)",
            "Duyusal Adaptasyonlar: Anormal Retinal Uyum (ARC), Süpresyon, Mikrotropya ve Ambliyopi Tipleri (Şaşılık, Anizometropi, Deprivasyon; PEDIG Kapama Protokolleri)",
            "Klinik Şaşılık Muayenesi: Korneal Işık Refleksi (Hirschberg, Krimsky), Örtme-Açma Testi, Alternan Örtme, Prizma Örtme Testi ve Parks-Bielschowsky Üç Basamaklı Testi",
            "Ezotropya Spektrumu: İnfantil Ezotropya (Çapraz Fiksasyon, DVD, İAO Aşırı Fonksiyonu), Akomodatif Ezotropya (Refraktif vs Yüksek AC/A Oranı), Altıncı Sinir Felci, Duane Retraksiyon Sendromu (Tip 1-3)",
            "Ekzotropya Spektrumu: İntermittan Ekzotropya (Temel Tip, Konverjans Yetmezliği, Diverjans Fazlalığı), Duyusal Ekzotropya ve Ardışık Ekzotropya",
            "Vertikal ve Siklotorsiyonel Şaşılıklar: Dördüncü Sinir Felci, Brown Sendromu, Disososiye Vertikal Deviasyon (DVD) ve İnferior Oblik Aşırı Fonksiyonu",
            "Paralitik ve Kısıtlayıcı Şaşılıklar: Üçüncü Sinir Felci (Pupilla Korunan vs Pupilla Tutan, PCoA Anevrizması Riski), Tiroid Miyopatisi ve Blowout Kırığı Kas Sıkışması",
            "Şaşılık Cerrahi Teknikleri: Rektus Kas Geriletmesi (Resesyon), Rezeksiyon, Plikasyon ve Transpozisyon Ameliyatları (Knapp, Jensen, Nishida Prosedürleri)"
        ],
        "high_yield_keywords": [
            "Hering eşit innervasyon ve Sherrington resiprokal innervasyon kanunları (*Hering & Sherrington laws*)",
            "Parks-Bielschowsky üç basamaklı motilite analizi (*Parks-Bielschowsky 3-step test*)",
            "İnfantil ezotropya cerrahi zamanlaması ve klinik özellikleri (*infantile esotropia*)",
            "Yüksek AC/A oranı ve bifokal gözlük yönetimi (*high AC/A ratio accommodative esotropia*)",
            "PEDIG ambliyopi kapama ve atropin penalizasyon rejimleri (*PEDIG amblyopia trials*)",
            "Duane retraksiyon sendromu tip 1, tip 2 ve tip 3 ayırıcı özellikleri (*Duane syndrome*)",
            "Brown sendromu ve süperior oblik tendon kılıf anomalisi (*Brown syndrome*)",
            "Dördüncü sinir felcinde baş eğme testi (*trochlear nerve palsy Bielschowsky head tilt*)",
            "Pupilla tutulumlu üçüncü sinir felcinde arka komünikan arter anevrizması (*PCoA aneurysm*)",
            "Knapp kas transpozisyon cerrahisi endikasyonları (*Knapp procedure*)"
        ]
    },
    19: {
        "id": 19,
        "title_en": "Neuro-ophthalmology",
        "title_tr": "Nöro-oftalmoloji ve Görme Yolları",
        "book_start_page": 757,
        "book_end_page": 842,
        "pdf_start_page": 769,
        "pdf_end_page": 854,
        "page_count": 86,
        "target_questions": 180,
        "core_subsections": [
            "Pupilla Yolları ve Bozuklukları: Rölatif Aferent Pupilla Defekti (RAPD / Marcus Gunn), Horner Sendromu (Kokain, Apraklonidin, Hidroksiamfetamin Testleri), Adie Tonik Pupillası (%0.1 Seyreltik Pilokarpin Testi), Argyll Robertson Pupillası",
            "Optik Nörit Spektrumu: Demiyelinizan Tip (ONTT Kılavuzları), MOGAD (MOG-IgG, Perinörit), AQP4-IgG Nöromiyelitis Optika (NMOSD, Uzun Segment Tutulum) ve Akut Tedavi Protokolleri",
            "İskemik Optik Nöropatiler: Non-arteritik AION (NAION: Riskli Kalabalık Optik Disk, PDE-5 İnhibitörleri, Uyku Apnesi) ile Arteritik AION (AAION: Dev Hücreli Arterit, Kireç Beyazı Ödem, Acil Yüksek Doz IV Metilprednizolon)",
            "Papilödem ve Kafa İçi Basınç Artışı: Frisén Evreleme Sistemi, İdiyopatik İntrakraniyal Hipertansiyon (İİH / Psödotümör Serebri: IIHTT Çalışması, Asetazolamid, Şant Cerrahisi, Optik Sinir Kılıf Fenestrasyonu)",
            "Basısal, Kalıtsal ve Toksik Optik Nöropatiler: Hipofiz Adenomu (Bitemporal Hemianopsi), Kraniofarenjiom, Leber Herediter Optik Nöropatisi (LHON: Mitokondriyal DNA 11778 Mutasyonu, İdebenon), Dominant Optik Atrofi (OPA1) ve Etambutol Toksisitesi",
            "Görme Yolları Lezyonları ve Görme Alanı Defektleri: Kiazmal Lezyonlar, Optik Traktus (Uyumsuz Homonim Hemianopsi), Temporal Lob/Meyer İlmeği (Gökyüzünde Pasta), Parietal Lob (Yerde Pasta), Oksipital Korteks (Makula Korunumlu Homonim Defekt)",
            "Oküler Miyastenia Gravis: Tensilon ve Buz Torbası Testleri, Anti-AChR ve Anti-MuSK Antikorları, Tek Lif EMG, Piridostigmin ve Timektomi Yaklaşımları",
            "Nistagmus ve Supranükleer Okülomotor Bozukluklar: İnfantil Nistagmus Sendromu (Nötr Nokta, Kestenbaum Ameliyatı), Progresif Supranükleer Palsi (PSP), İnternükleer Oftalmopleji (İNO: MLF Lezyonu, Abdüksiyon Nistagmusu) ve Bir Buçuk Sendromu"
        ],
        "high_yield_keywords": [
            "Apraklonidin damla testi ile Horner sendromunda denerve miyozis tersine dönmesi (*apraclonidine test*)",
            "Optic Neuritis Treatment Trial (ONTT) oral tek başına steroid kontrendikasyonu (*ONTT trial*)",
            "MOGAD perinöriti ile NMOSD kiazma tutulumu ayrımı (*MOGAD vs NMOSD*)",
            "Dev hücreli arterit kaynaklı arteritik AION acil yönetimi (*arteritic AION biopsy*)",
            "Frisén papilödem derecelendirme basamakları (*Frisén papilloedema scale*)",
            "İdiyopatik intrakraniyal hipertansiyon IIHTT kilo kaybı ve asetazolamid (*IIHTT study*)",
            "Leber kalıtsal optik nöropatisi mitokondriyal 11778, 3460, 14484 mutasyonları (*LHON mutations*)",
            "Temporal lob lezyonunda Meyer ilmeği ve üst kadranopya (*Meyer loop quadrantanopia*)",
            "Oküler miyastenia graviste buz torbası testi pitozis düzelmesi (*ice pack test*)",
            "Medial longitudinal fasikülüs lezyonunda internükleer oftalmopleji (*internuclear ophthalmoplegia* - INO)"
        ]
    },
    20: {
        "id": 20,
        "title_en": "Ocular Tumours",
        "title_tr": "Oküler ve İntraoküler Tümörler",
        "book_start_page": 843,
        "book_end_page": 886,
        "pdf_start_page": 855,
        "pdf_end_page": 898,
        "page_count": 44,
        "target_questions": 130,
        "core_subsections": [
            "İyi Huylu İntraoküler Tümörler: Koroid Nevüsü (Melanoma Dönüşüm için TFSOM-UHHD Risk Belirteçleri), İris Nevüsü, Retinal Astrositik Hamartom (Tüberoz Skleroz), Retinal Kapiller Hemanjoblastom (von Hippel-Lindau)",
            "Koroid Melanomu: Klinik Belirtiler, Ultrasonografik Özellikler (Düşük İç Reflektivite, Akustik Boşluk, Koroid Ekskavasyonu), COMS Klinik Çalışması Bulguları, Brakiterapi (İyot-125) ve Enükleasyon Kriterleri, Genetik Prognoz (Monozomi 3, BAP1 Mutasyonu)",
            "Koroid Metastazları: Primer Odaklar (Meme, Akciğer, Prostat), Multifokalite, Krem-Sarı Plak Morfolojisi, Sistemik Kemoterapi ve Radyoterapi Yönetimi",
            "Retinoblastom: Genetik Mekanizma (RB1 Gen Mutasyonu, Germline vs Somatik), Lökokori, Şaşılık, Uluslararası ABCDE Evreleme Sistemi, Trilateral Retinoblastom, İntra-arteriyel Kemoterapi (Melfalan)",
            "Primer Vitreoretinal Lenfoma (PVRL): Primer Santral Sinir Sistemi Lenfoması Birlikteliği, Maskeli Balo Üveiti Tablosu, Tanısal Vitrektomi, IL-10 / IL-6 Oranının 1.0'dan Büyük Olması, MYD88 L265P Mutasyonu ve Yüksek Doz Metotreksat Tedavisi",
            "İris ve Siliyer Cisim Tümörleri: İris Melanomu, Medulloepitelyoma (Diktiyoma), Melanositoma ve Siliyer Cisim Halka Melanomu"
        ],
        "high_yield_keywords": [
            "TFSOM-UHHD mnemonik risk analizi ile koroid nevüsü takibi (*TFSOM-UHHD criteria*)",
            "Koroid melanomunda ultrasonografik akustik sessizlik ve koroid çöküntüsü (*choroidal melanoma*)",
            "COMS Faz 3 klinik çalışması brakiterapi ile enükleasyon sağkalım eşitliği (*COMS trial*)",
            "Monozomi 3 ve BAP1 mutasyonunun metastaz prognozuna etkisi (*monosomy 3 BAP1*)",
            "Retinoblastomda RB1 iki vuruş hipotezi ve lökokori triyajı (*retinoblastoma RB1*)",
            "Retinoblastomda melfalan ile süperselektif oftalmik arter kemoterapisi (*intra-arterial melphalan*)",
            "Primer vitreoretinal lenfomada vitreus sıvısı IL-10/IL-6 oranı (*IL-10 to IL-6 ratio*)",
            "von Hippel-Lindau hastalığı retinal anjiyomları (*retinal capillary haemangioblastoma*)",
            "Tüberoz sklerozda dut benzeri retinal astrositik hamartom (*astrocytic hamartoma*)"
        ]
    },
    21: {
        "id": 21,
        "title_en": "Ophthalmic Side Effects of Systemic Medication",
        "title_tr": "Sistemik İlaçların Oküler Yan Etkileri ve Toksisiteleri",
        "book_start_page": 887,
        "book_end_page": 906,
        "pdf_start_page": 899,
        "pdf_end_page": 918,
        "page_count": 20,
        "target_questions": 100,
        "core_subsections": [
            "Kornea ve Ön Segment Toksisitesi: Amiodaron (Kornea Verticillata), Klorokin ve Hidroksiklorokin Epitelyal Birikimleri, Klorpromazin, İndometazin ve Tamoksifen Keratopatisi",
            "Katarakt ve Glokom Oluşturan Sistemik İlaçlar: Sistemik Kortikosteroidler (Arka Subkapsüler Katarakt, Steroid GİB Yükselmesi), Topiramat (İki Taraflı Siliyer Efüzyon ve Akut Açı Kapanması), Trisiklik Antidepresanlar ve Antikolinerjikler",
            "Retina ve Makula Toksisiteleri: Hidroksiklorokin (HCQ: Boğa Gözü Makulopatisi, Asyatik vs Kafkasik Tutulum Dağılımı, AAO 2016 Tarama Protokolü: 10-2 Görme Alanı, SD-OKT, FAF, mfERG), Fenotiyazinler (Tiyoridazin, Klorpromazin), Vigabatrin (Geri Dönüşümsüz Konsantrik Görme Alanı Daralması), Pentozan Polisülfat Sodyum (PPS Makulopatisi)",
            "Nöro-oftalmik Toksisiteler: Etambutol (Toksik Optik Nöropati, Santral/Sekosentral Skotom, Kırmızı-Yeşil Renk Bozukluğu), İzoniyazid, Linezolid ve Fosfodiesteraz-5 İnhibitörleri (Sildenafil/Tadalafil: NAION Riski, Siyanopsi/Mavi Görme)",
            "Modern Onkolojik Hedefe Yönelik Tedaviler ve Kontrol Noktası İnhibitörleri: MEK İnhibitörleri (MEKAR Seröz Ayrışması), EGFR İnhibitörleri (Aberan Kirpik Uzaması), İmmün Kontrol Noktası İnhibitörleri (Anti-PD-1, Anti-CTLA-4: Şiddetli Üveit, VKH Benzeri Sendrom, Miyasteni ve Hipofizit)"
        ],
        "high_yield_keywords": [
            "Amerikan Oftalmoloji Akademisi (AAO) 2016 Hidroksiklorokin tarama dozu (<5.0 mg/kg/gün) (*AAO screening*)",
            "Topiramat kullanımında iki taraflı akut açı kapanması ve siliyokoroidal efüzyon (*topiramate angle closure*)",
            "Amiodaron kornea verticillata vorteks keratopatisi (*amiodarone vortex keratopathy*)",
            "Etambutol toksik optik nöropatisi ve renk görme kaybı (*ethambutol optic neuropathy*)",
            "Vigabatrin ile indüklenen geri dönüşümsüz retina sinir lifi hasarı (*vigabatrin field loss*)",
            "Pentozan polisülfat sodyum (PPS) pigmenter makulopatisi (*pentosan polysulfate maculopathy*)",
            "Fosfodiesteraz-5 inhibitörleri ve geçici siyanopsi bulgusu (*PDE-5 inhibitors cyanopsia*)",
            "MEK inhibitörü ilişkili retinopati (MEKAR) multifokal subretinal sıvı (*MEK inhibitor retinopathy*)"
        ]
    },
    22: {
        "id": 22,
        "title_en": "Trauma",
        "title_tr": "Oküler Travma ve Acil Yönetim",
        "book_start_page": 907,
        "book_end_page": 938,
        "pdf_start_page": 919,
        "pdf_end_page": 950,
        "page_count": 32,
        "target_questions": 115,
        "core_subsections": [
            "BETT (Birmingham Eye Trauma Terminology) Uluslararası Sınıflaması: Kapalı Küre (Kontüzyon, Lameller Laserasyon) ile Açık Küre Travmaları (Rüptür, Penetran, Perfore, İntraoküler Yabancı Cisim / İOYC)",
            "Kimyasal Göz Yaralanmaları: Alkali ve Asit Yanıkları (Dua ve Roper-Hall Sınıflamaları, Limbal Kök Hücre Yetmezliği, Acil Bol İrrigasyon, Askorbat, Sitrat ve Amniyon Zarı Tedavisi)",
            "Ön Segment Mekanik Travmaları: Kornea Erozyonu, Travmatik Hifema (Evreleme, Sekonder Kanama Önleme, Orak Hücreli Anemi Önlemleri), İridodiyaliz, Siklodiyaliz Klefti ve Açı Resesyonu Glokomu",
            "Lens Travmaları: Travmatik Katarakt (Vossius Halkası, Rozet Katarakt), Travmatik Lens Lüksasyonu ve Sublüksasyonu",
            "Arka Segment Travmaları: Commotio Retinae (Berlin Ödemi), Koroid Rüptürleri (Sekonder KNV Gelişimi), Sklopoterya, Travmatik Makula Deliği ve Purtscher Retinopatisi",
            "İntraoküler Yabancı Cisimler (İOYC): Demir Parçacıkları (Siderozis Bulbi: ERG Değişiklikleri), Bakır Parçacıkları (Kalkozis: Ayçiçeği Kataraktı), Yüksek Çözünürlüklü BT Taraması ve Manyetik Rezonans (MR) Kesin Kontrendikasyonu",
            "Orbita ve Adneks Travmaları: Orbita Blowout Kırıkları (Taban ve Medial Duvar, İnferior Rektus Kas Sıkışması, Okülokardiyak Refleks), Travmatik Optik Nöropati (TON: Gözlem, Yüksek Doz Steroid ve Cerrahi Dekompresyon)"
        ],
        "high_yield_keywords": [
            "BETT uluslararası oküler travma sınıflama terminolojisi (*BETT classification*)",
            "Alkali kimyasal yanıklarında kollajen erimesi ve limbal iskemi (*alkali chemical burns*)",
            "Dua ve Roper-Hall limbal kök hücre yetmezliği evrelemesi (*Dua classification*)",
            "Travmatik hifemada orak hücreli anemide karbonik anhidraz kontrendikasyonu (*traumatic hyphaema*)",
            "Gonyoskopide açı resesyonu glokomu ve siliyer cisim bandı genişlemesi (*angle recession glaucoma*)",
            "Commotio retinae (Berlin ödemi) fotoreseptör dış segment ayrışması (*Berlin oedema*)",
            "Siderozis bulbi demir toksisitesi ve ERG b-dalgası çökmesi (*siderosis bulbi*)",
            "Kalkozis bulbi ve bakır birikimi ayçiçeği kataraktı (*chalcosis sunflower cataract*)",
            "Orbita taban blowout kırığında tuzak kapı kırığı ve okülokardiyak refleks (*blowout fracture trapdoor*)"
        ]
    }
}


def get_chapter_meta(chapter_id: int) -> ChapterMeta:
    if chapter_id not in CHAPTERS_METADATA:
        raise ValueError(f"Geçersiz bölüm numarası: {chapter_id} (1-22 arasında olmalıdır)")
    return CHAPTERS_METADATA[chapter_id]


def get_all_target_questions() -> int:
    return sum(meta["target_questions"] for meta in CHAPTERS_METADATA.values())


if __name__ == "__main__":
    total = get_all_target_questions()
    print(f"Toplam 22 Bölüm Tanımlandı. Toplam Hedef Soru Sayısı: {total}")
