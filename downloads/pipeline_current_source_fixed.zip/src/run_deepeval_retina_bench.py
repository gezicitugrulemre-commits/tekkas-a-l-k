"""
run_deepeval_retina_bench.py — DeepEval & İki Aşamalı Görsel Doğrulama Değerlendirme Seti.

10 Kritik Medikal Test Senaryosu:
1. CRAO / CRVO ve birleşik oklüzyon ayrımı (Combined occlusion pure CRAO olamaz)
2. Stargardt / Best hastalığı ayrımı (Best lezyonu Stargardt slaytına verilemez)
3. ARN / Toksoplazmoz ayrımı (Tokso lezyonu ARN slaytına verilemez)
4. Toksoplazmoz / CMV ayrımı (CMV retiniti Tokso slaytına verilemez)
5. CRVO / BRVO ayrımı (Dal oklüzyonu santral oklüzyon diye verilemez)
6. Şemanın OCT olarak tanıtılması (Öğretici şema klinik B-scan sayılamaz)
7. Histolojinin fundus olarak tanıtılması (H&E kesiti renkli fundus sayılamaz)
8. Yanlış panel ve altyazı uyumsuzluğu (B paneli A altyazısıyla eşleşemez)
9. Doğru görselin yanlış kırpılması / belirsizlik (Panel ayrımı net değilse karantina)
10. Eksik kaynak, bilinmeyen modalite ve yetersiz kanıt (Altyazısız görsel kabul edilemez)

Varsayılan mod: Tamamen deterministik / çevrimdışı (0 USD maliyet).
Canlı mod: --live-eval parametresi ile açıkça tetiklenir.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from PIL import Image

from two_stage_visual_verifier import TwoStageVisualVerifier, FullVisualAuditRecord

log = logging.getLogger("deepeval_bench")
logging.basicConfig(level=logging.INFO, format="%(message)s")


def create_synthetic_test_case_image(tmp_dir: Path, name: str, color: str = "red", size: tuple = (200, 200)) -> Path:
    p = tmp_dir / f"{name}.png"
    if not p.is_file():
        img = Image.new("RGB", size, color=color)
        img.save(p, format="PNG")
    return p


def get_clinical_eval_cases(tmp_dir: Path) -> List[Dict[str, Any]]:
    return [
        {
            "case_id": "TC01_COMBINED_CRAO_CRVO",
            "name": "CRAO/CRVO ve Birleşik Oklüzyon Ayrımı",
            "image": create_synthetic_test_case_image(tmp_dir, "crao_crvo_combined", "orange"),
            "target_slide_title": "Santral Retinal Arter Tıkanıklığı (CRAO) Yönetimi",
            "target_disease_id": "crao",
            "original_caption": "Combined central retinal vein and artery occlusion with widespread hemorrhages and ischemic whitening.",
            "expected_modality": "fundus",
            "expected_decision": "review_required",  # Birleşik patoloji tek başına CRAO olarak kabul edilmemeli
            "trap_type": "compound_pathology_relabeled_as_single",
        },
        {
            "case_id": "TC02_STARGARDT_VS_BEST",
            "name": "Stargardt / Best Karışması",
            "image": create_synthetic_test_case_image(tmp_dir, "best_vitelliform", "yellow"),
            "target_slide_title": "Stargardt Hastalığı (ABCA4) ve Fleck Lezyonları",
            "target_disease_id": "stargardt",
            "original_caption": "Best vitelliform macular dystrophy (BEST1) showing typical 'egg-yolk' subretinal lesion.",
            "expected_modality": "fundus",
            "expected_decision": "incompatible",
            "trap_type": "disease_mismatch",
        },
        {
            "case_id": "TC03_ARN_VS_TOXOPLASMOSIS",
            "name": "ARN / Toksoplazmoz Karışması",
            "image": create_synthetic_test_case_image(tmp_dir, "toxo_scar", "brown"),
            "target_slide_title": "Akut Retinal Nekroz (ARN) Patofizyolojisi ve VZV/HSV",
            "target_disease_id": "arn",
            "original_caption": "Ocular toxoplasmosis with focal necrotizing retinochoroiditis adjacent to pigmented chorioretinal scar ('headlight in the fog').",
            "expected_modality": "fundus",
            "expected_decision": "incompatible",
            "trap_type": "disease_mismatch",
        },
        {
            "case_id": "TC04_TOXO_VS_CMV",
            "name": "Toksoplazmoz / CMV Karışması",
            "image": create_synthetic_test_case_image(tmp_dir, "cmv_retinitis", "purple"),
            "target_slide_title": "Oküler Toksoplazmoz Tanı ve Tedavi Prensipleri",
            "target_disease_id": "toxoplasmosis",
            "original_caption": "Cytomegalovirus (CMV) retinitis with typical 'pizza-pie' appearance of dense retinal hemorrhages and granular necrosis in an AIDS patient.",
            "expected_modality": "fundus",
            "expected_decision": "incompatible",
            "trap_type": "disease_mismatch",
        },
        {
            "case_id": "TC05_CRVO_VS_BRVO",
            "name": "CRVO / BRVO Karışması",
            "image": create_synthetic_test_case_image(tmp_dir, "brvo_sector", "magenta"),
            "target_slide_title": "Santral Retinal Ven Tıkanıklığı (CRVO)",
            "target_disease_id": "crvo",
            "original_caption": "Branch retinal vein occlusion (BRVO) confined strictly to the superotemporal quadrant.",
            "expected_modality": "fundus",
            "expected_decision": "incompatible",
            "trap_type": "sector_vs_central_mismatch",
        },
        {
            "case_id": "TC06_SCHEMATIC_MISREPRESENTED_AS_OCT",
            "name": "Şemanın OCT Olarak Tanıtılması (DMÖ Örneği)",
            "image": create_synthetic_test_case_image(tmp_dir, "dme_schematic", "cyan"),
            "target_slide_title": "Diyabetik Makula Ödeminde (DMÖ) SD-OKT Biyobelirteçleri",
            "target_disease_id": "dme",
            "original_caption": "Schematic diagram of the vitreoretinal interface and inner retinal fluid accumulation pathways in diabetic retinopathy.",
            "expected_modality": "OCT B-scan",
            "expected_decision": "incompatible",  # Şema klinik B-scan olarak kabul edilemez
            "trap_type": "modality_mismatch_schematic",
        },
        {
            "case_id": "TC07_HISTOLOGY_MISREPRESENTED_AS_FUNDUS",
            "name": "Histolojinin Renkli Fundus Olarak Tanıtılması",
            "image": create_synthetic_test_case_image(tmp_dir, "retina_he_histology", "pink"),
            "target_slide_title": "Santral Retinal Arter Tıkanıklığında Klinik Fundus Bulguları",
            "target_disease_id": "crao",
            "original_caption": "Histology of human retina demonstrating ischemic swelling of the nerve fiber layer stained with hematoxylin and eosin (H&E).",
            "expected_modality": "fundus",
            "expected_decision": "incompatible",
            "trap_type": "histology_vs_fundus",
        },
        {
            "case_id": "TC08_WRONG_PANEL_ALIGNMENT",
            "name": "Yanlış Panel ve Altyazı Eşleşmesi",
            "image": create_synthetic_test_case_image(tmp_dir, "unsplit_panels_abc", "darkblue"),
            "target_slide_title": "Stargardt Hastalığı (ABCA4)",
            "target_disease_id": "stargardt",
            "original_caption": "Fig. 4. A: Color fundus, B: FAF autofluorescence showing hyperautofluorescent flecks, C: OCT B-scan.",
            "expected_modality": "fundus",
            "expected_decision": "review_required",
            "trap_type": "unsplit_multi_panel",
        },
        {
            "case_id": "TC09_VALID_PURE_CRAO",
            "name": "Doğru ve Geçerli Saf CRAO Olgusu (Önkontrol Başarılı, Görsel Doğrulama Bekliyor)",
            "image": create_synthetic_test_case_image(tmp_dir, "pure_crao_fundus", "white"),
            "target_slide_title": "Santral Retinal Arter Tıkanıklığı (CRAO)",
            "target_disease_id": "crao",
            "original_caption": "Color fundus photograph of acute CRAO showing opaque white retina and a prominent cherry-red spot at the fovea.",
            "expected_modality": "fundus",
            "expected_decision": "review_required",
            "trap_type": "valid_positive_quarantined_until_visual_verification",
        },
        {
            "case_id": "TC10_MISSING_CAPTION_INSUFFICIENT_EVIDENCE",
            "name": "Eksik Kaynak / Yetersiz Kanıt",
            "image": create_synthetic_test_case_image(tmp_dir, "no_caption_image", "gray"),
            "target_slide_title": "Diyabetik Makula Ödemi",
            "target_disease_id": "dme",
            "original_caption": "",
            "expected_modality": "fundus",
            "expected_decision": "review_required",
            "trap_type": "insufficient_evidence",
        },
    ]


def run_eval_suite(*, live_eval: bool = False, strict_argon: bool = False) -> Dict[str, Any]:
    if live_eval:
        raise ValueError("Sentetik renk kutuları canlı klinik benchmark olarak kullanılamaz.")
    with tempfile.TemporaryDirectory() as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        cases = get_clinical_eval_cases(tmp_dir)
        verifier = TwoStageVisualVerifier(use_live_api=live_eval, strict_argon=strict_argon)

        results = []
        false_acceptances = 0
        true_rejections = 0
        quarantined_samples = 0
        modality_accuracy_matches = 0
        panel_accuracy_matches = 0
        claim_support_matches = 0
        layout_issues = 0

        for c in cases:
            res: FullVisualAuditRecord = verifier.verify_visual(
                image_path=c["image"],
                target_slide_title=c["target_slide_title"],
                target_disease_id=c["target_disease_id"],
                original_caption=c["original_caption"],
                expected_modality=c["expected_modality"],
            )

            actual_dec = res.model_decision
            expected_dec = c["expected_decision"]

            # İstatistik kontrolleri
            is_match = (actual_dec == expected_dec)
            if actual_dec == "compatible" and expected_dec != "compatible":
                false_acceptances += 1
            if actual_dec in ("incompatible", "review_required") and expected_dec in ("incompatible", "review_required"):
                true_rejections += 1
            if actual_dec == "review_required":
                quarantined_samples += 1

            if res.stage2.modality_check is True:
                modality_accuracy_matches += 1
            if res.stage2.panel_check is True:
                panel_accuracy_matches += 1
            if res.stage2.claim_support_check is True:
                claim_support_matches += 1

            results.append({
                "case_id": c["case_id"],
                "name": c["name"],
                "trap_type": c["trap_type"],
                "expected": expected_dec,
                "actual": actual_dec,
                "passed": is_match,
                "clinical_rationale": res.stage2.clinical_rationale,
                "quarantine_reason": res.stage2.quarantine_reason,
                "actual_model": res.actual_model,
            })

        total = len(cases)
        all_passed = all(r["passed"] for r in results)

        summary_report = {
            "mode": "live_api" if live_eval else "deterministic_offline",
            "total_cases": total,
            "passed_cases": sum(r["passed"] for r in results),
            "false_acceptances": false_acceptances,
            "non_acceptances": true_rejections,
            "quarantined_samples": quarantined_samples,
            "modality_check_true_pct": round(modality_accuracy_matches / total * 100, 1),
            "panel_check_true_pct": round(panel_accuracy_matches / total * 100, 1),
            "claim_support_check_true_pct": round(claim_support_matches / total * 100, 1),
            "layout_issues": None,
            "evaluation_kind": "synthetic_caption_rules",
            "clinical_model_performance": "not_evaluated",
            "deepeval_metrics_executed": False,
            "estimated_cost_usd": 0.0 if not live_eval else "Bilinmiyor (gerçek çağrıda usage defterine yazılır)",
            "results": results,
        }

        return summary_report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DeepEval & İki Aşamalı Görsel Doğrulama Değerlendirme Seti")
    parser.add_argument("--live-eval", action="store_true", help="Canlı ücretli/harici Gemini API çağrılarını etkinleştir")
    parser.add_argument("--strict-argon", action="store_true", help="Canlı modda Argon'u zorunlu tut")
    args = parser.parse_args()

    report = run_eval_suite(live_eval=args.live_eval, strict_argon=args.strict_argon)

    print("\n" + "=" * 70)
    print("SENTETİK ALTYAZI KURAL TESTİ — KLİNİK MODEL PERFORMANSI DEĞİLDİR")
    print("=" * 70)
    print(f"Çalışma Modu             : {report['mode']}")
    print(f"Toplam Test Olgusu       : {report['total_cases']}")
    print(f"Başarıyla Geçen Olgular  : {report['passed_cases']}/{report['total_cases']}")
    print(f"Yanlış Görsel Kabulü     : {report['false_acceptances']} (İstenen: 0)")
    print(f"Doğru Görsel Reddi       : {report['non_acceptances']}")
    print(f"Karantinaya Alınan       : {report['quarantined_samples']}")
    print(f"Modalite Doğruluğu       : %{report['modality_check_true_pct']}")
    print(f"Panel Doğruluğu          : %{report['panel_check_true_pct']}")
    print(f"İddia Desteği            : %{report['claim_support_check_true_pct']}")
    print(f"Tahmini API Maliyeti     : {report['estimated_cost_usd']}")
    print("-" * 70)

    for r in report["results"]:
        status_sym = "[PASS]" if r["passed"] else "[FAIL]"
        print(f"{status_sym} {r['case_id']}: {r['name']}")
        print(f"       Beklenen: {r['expected']} | Alınan: {r['actual']}")
        if r["quarantine_reason"]:
            print(f"       Gerekçe : {r['quarantine_reason']}")

    print("=" * 70 + "\n")
