"""
two_stage_visual_verifier.py — İki Aşamalı Multimodal Medikal Görsel Doğrulayıcı.

Mimari ve İlke Ayrımı:
1. "Argon İstendi": argon_requested=True, requested_model='gemini-4-argon'
2. "Argon Gerçekten Çalıştı": verified_with_argon=True (sağlayıcı response metadata ile doğrulandı)
3. "Argon Görseli Uygun Buldu": model_decision='compatible' (tüm kontroller True olmalı)
4. "İnsan Uzman Onayladı": expert_review_status='approved' (ayrı insan kararı, asla otomatik atanmaz)

Aşama 1 (Kör Muayene / Blind Inspection):
- Hedef slayt başlığı modele GÖSTERİLMEZ.
- Yalnızca gerçek görsel verisi (multimodal byte payload) verilir.
- Modalite, lezyonlar, panel harfleri ve belirsizlikler çıkarılır.

Aşama 2 (Bağlamsal Tutarlılık / Contextual Consistency):
- Görsel, özgün açıklama, 1. aşama gözlemleri ve hedef iddia birlikte değerlendirilir.
- Hastalık, modalite, panel ve iddia desteği zorunlu kontrollerdir.
- compatible kararı için TÜM zorunlu kontroller True olmalıdır.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple, Union

from pydantic import BaseModel, Field

from bookgraph.safety import file_hash
from bookgraph.llm import _assert_argon_identity

log = logging.getLogger("two_stage_visual_verifier")

MODALITY_TYPES = Literal[
    "fundus",
    "OCT B-scan",
    "OCTA",
    "FA",
    "ICGA",
    "FAF",
    "histology",
    "teaching_schematic",
    "unknown",
]

DECISION_TYPES = Literal["compatible", "incompatible", "review_required"]


def compute_context_hash(
    *,
    target_slide_title: str,
    target_disease_id: str,
    original_caption: str,
    target_claim: str = "",
    expected_modality: Optional[str] = None,
    image_sha256: str = "",
) -> str:
    """Değerlendirmeye giren bağlamın ve görselin kriptografik özetini üretir."""
    payload = f"{target_slide_title}|{target_disease_id}|{original_caption}|{target_claim}|{expected_modality or ''}|{image_sha256}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class Stage1BlindObservation(BaseModel):
    detected_modality: MODALITY_TYPES = Field(..., description="Görüntüleme yöntemi")
    visible_findings: List[str] = Field(default_factory=list, description="Objektif görülen lezyon veya yapılar")
    readable_panel_letters: List[str] = Field(default_factory=list, description="Görselde okunabilen A, B, C panel harfleri")
    image_quality_notes: str = Field(default="", description="Netlik, çözünürlük veya kırpma notları")
    uncertainties: List[str] = Field(default_factory=list, description="Belirsizlikler veya şüpheli alanlar")
    is_compound_pathology: bool = Field(default=False, description="Birden fazla hastalığın bir arada bulunması")


class Stage2ContextualVerification(BaseModel):
    disease_check: bool = Field(..., description="Hastalık tanısı ve hedef konu örtüşüyor mu?")
    modality_check: bool = Field(..., description="Görsel modalitesi slaytın gerektirdiği yöntemle uyumlu mu?")
    panel_check: bool = Field(..., description="İlgili panel veya alt şekil doğru mu?")
    claim_support_check: Optional[Union[bool, str]] = Field(default="not_evaluated", description="Görsel, slaytta öne sürülen klinik iddiayı doğrudan destekliyor mu?")
    decision: DECISION_TYPES = Field(..., description="Genel doğrulama kararı")
    clinical_rationale: str = Field(..., description="Kararın tıbbi ve kanıtsal gerekçesi")
    quarantine_reason: Optional[str] = Field(default=None, description="Red veya inceleme gereksiniminin nedeni")


class FullVisualAuditRecord(BaseModel):
    image_path: str
    image_sha256: str
    context_hash: str
    target_slide_title: str
    target_disease_id: str
    original_caption: str
    target_claim: str = ""
    expected_modality: Optional[str] = None

    # Argon / Model Yürütme ve Sağlayıcı Kanıtları (Ayrı alanlar)
    argon_requested: bool = False
    requested_model: str = "unknown"
    actual_model: str = "unknown"
    execution_mode: Literal["offline", "live"] = "offline"
    stage1_completed: bool = False
    stage2_completed: bool = False
    verified_with_argon: bool = False

    # İçerik Kararı ve İnsan Onayı (Kesinlikle Ayrı)
    model_decision: DECISION_TYPES = "review_required"
    expert_review_status: Literal["approved", "review_required", "rejected"] = "review_required"

    # Sağlayıcı ve İzleme Kimlikleri
    provider_response_id: Optional[str] = None
    langchain_run_id: Optional[str] = None

    # Aşama Ayrıntıları
    stage1: Stage1BlindObservation
    stage2: Stage2ContextualVerification


def validate_model_decision(
    *,
    suggested_decision: str,
    disease_check: bool,
    modality_check: bool,
    panel_check: bool,
    claim_support_check: Any,
    stage1: Stage1BlindObservation,
    clinical_rationale: str = "",
    quarantine_reason: Optional[str] = None,
) -> Tuple[DECISION_TYPES, str, Optional[str]]:
    """
    Model kararını tutarlı olarak doğrular.
    compatible kararı için tüm kontroller (disease, modality, panel, claim_support) True olmalıdır.
    Herhangi biri False ise -> incompatible.
    Herhangi biri None, unknown veya not_evaluated ise -> review_required.
    """
    checks = {
        "disease_check": disease_check,
        "modality_check": modality_check,
        "panel_check": panel_check,
        "claim_support_check": claim_support_check,
    }

    # Birleşik patoloji veya çoklu panel kontrolü
    if stage1.is_compound_pathology:
        return "review_required", "Görsel birleşik patoloji içeriyor; tek bir hastalık için onaylanamaz.", "compound_pathology"

    if len(stage1.readable_panel_letters) > 1 and not panel_check:
        return "review_required", "Çoklu panel ayrıştırılamadı.", "unsegmented_multi_panel"

    if suggested_decision == "compatible":
        # Kontrollerden herhangi biri açıkça False ise -> incompatible
        for name, val in checks.items():
            if val is False:
                reason = f"Model 'compatible' önerdi fakat '{name}' olumsuz (False); karar incompatible olarak düzeltildi."
                return "incompatible", reason, f"failed_check_{name}"

        # Kontrollerden herhangi biri True değilse (None, 'not_evaluated', 'unknown') -> review_required
        for name, val in checks.items():
            if val is not True:
                reason = f"Model 'compatible' önerdi fakat '{name}' tam doğrulanmadı ({val}); karar review_required olarak düzeltildi."
                return "review_required", reason, f"unverified_check_{name}"

        return "compatible", clinical_rationale or "Tüm zorunlu kontroller olumlu.", quarantine_reason

    # Model incompatible veya review_required demişse koru
    return suggested_decision, clinical_rationale, quarantine_reason


def encode_image_base64(image_path: Path) -> Tuple[str, str]:
    """Görüntüyü teknik olarak doğrulanmış base64 ve mime-type olarak kodlar."""
    if not image_path.is_file():
        raise FileNotFoundError(f"Görsel bulunamadı: {image_path}")
    ext = image_path.suffix.lower()
    mime = "image/png"
    if ext in (".jpg", ".jpeg"):
        mime = "image/jpeg"
    elif ext == ".webp":
        mime = "image/webp"

    with open(image_path, "rb") as f:
        data = f.read()
    if len(data) < 100:
        raise ValueError(f"Görsel dosyası bozuk veya çok küçük ({len(data)} byte)")

    b64 = base64.b64encode(data).decode("utf-8")
    return b64, mime


class TwoStageVisualVerifier:
    def __init__(
        self,
        *,
        use_live_api: bool = False,
        strict_argon: bool = False,
        llm_factory: Optional[Callable[[str], Any]] = None,
    ):
        self.use_live_api = use_live_api
        self.strict_argon = strict_argon
        self.llm_factory = llm_factory

    def verify_visual(
        self,
        image_path: Path,
        *,
        target_slide_title: str,
        target_disease_id: str,
        original_caption: str,
        target_claim: str = "",
        expected_modality: Optional[str] = None,
    ) -> FullVisualAuditRecord:
        image_path = Path(image_path)
        img_sha = file_hash(image_path)
        ctx_hash = compute_context_hash(
            target_slide_title=target_slide_title,
            target_disease_id=target_disease_id,
            original_caption=original_caption,
            target_claim=target_claim,
            expected_modality=expected_modality,
            image_sha256=img_sha,
        )

        b64_data, mime_type = encode_image_base64(image_path)

        if not self.use_live_api:
            return self._offline_verify(
                image_path=image_path,
                img_sha=img_sha,
                ctx_hash=ctx_hash,
                target_slide_title=target_slide_title,
                target_disease_id=target_disease_id,
                original_caption=original_caption,
                target_claim=target_claim,
                expected_modality=expected_modality,
            )

        return self._live_api_verify(
            image_path=image_path,
            img_sha=img_sha,
            ctx_hash=ctx_hash,
            b64_data=b64_data,
            mime_type=mime_type,
            target_slide_title=target_slide_title,
            target_disease_id=target_disease_id,
            original_caption=original_caption,
            target_claim=target_claim,
            expected_modality=expected_modality,
        )

    def _offline_verify(
        self,
        *,
        image_path: Path,
        img_sha: str,
        ctx_hash: str,
        target_slide_title: str,
        target_disease_id: str,
        original_caption: str,
        target_claim: str,
        expected_modality: Optional[str],
    ) -> FullVisualAuditRecord:
        """
        Deterministik kural motoru (use_live_api=False):
        - verified_with_argon daima False'tur.
        - actual_model asla Argon olarak yazılamaz (offline_precheck veya unknown).
        - Altyazıdan çıkarılan bilgiler gerçek görüntü gözlemi gibi sunulmaz.
        - claim_support_check 'not_evaluated' kalır.
        - Önkontrol başarılı olsa dahi karar 'review_required' kalır.
        - expert_review_status otomatik approved OLMAZ.
        """
        cap_lower = original_caption.lower()
        target_dis = target_disease_id.lower()

        # 1. Aşama: Altyazı ön-taraması (Görsel gözlemi DEĞİLDİR)
        modality = "unknown"
        if any(w in cap_lower for w in ["oct", "b-scan", "cross-section", "retinal layers", "sd-oct"]):
            modality = "OCT B-scan"
        elif any(w in cap_lower for w in ["octa", "angiography", "choriocapillaris", "deep capillary"]):
            modality = "OCTA"
        elif any(w in cap_lower for w in ["fundus photograph", "color fundus", "retina photograph", "cherry red"]):
            modality = "fundus"
        elif any(w in cap_lower for w in ["fluorescein", "ffa", "fa ", "leakage", "hyperfluorescence"]):
            modality = "FA"
        elif any(w in cap_lower for w in ["histology", "histopatholog", "biopsy", "microscop", "h&e"]):
            modality = "histology"
        elif any(w in cap_lower for w in ["diagram", "schematic", "şema", "illustration"]):
            modality = "teaching_schematic"

        if "schematic" in cap_lower or "diagram" in cap_lower:
            if modality == "OCT B-scan" or expected_modality == "OCT B-scan":
                modality = "teaching_schematic"

        if "histology" in cap_lower or ("section" in cap_lower and "stained" in cap_lower):
            modality = "histology"

        panel_match = re.findall(r"\b([A-D])\b[:\.\s]", original_caption)
        is_compound = ("crao" in cap_lower and "crvo" in cap_lower) or ("artery" in cap_lower and "vein" in cap_lower and "occlusion" in cap_lower)

        stage1 = Stage1BlindObservation(
            detected_modality=modality,
            visible_findings=["Altyazı anahtar kelimeleri (görüntü pikselleri incelenmedi)"],
            readable_panel_letters=panel_match,
            image_quality_notes="Offline mod: Görüntü pikselleri doğrudan incelenmedi (yalnız altyazı ön-taraması).",
            uncertainties=["Görüntü pikselleri model veya uzman tarafından henüz doğrulanmadı."],
            is_compound_pathology=is_compound,
        )

        # 2. Aşama: Kural tabanlı çelişki denetimi
        disease_ok = False
        modality_ok = (expected_modality is None) or (modality == expected_modality)
        panel_ok = True
        decision: DECISION_TYPES = "review_required"
        quarantine = None

        if target_dis in ("crao", "crvo"):
            if is_compound:
                disease_ok = False
                decision = "review_required"
                quarantine = "Görsel birleşik CRAO+CRVO patolojisi içeriyor; saf CRAO veya CRVO olarak etiketlenemez."
            elif target_dis == "crvo" and "brvo" in cap_lower and "crvo" not in cap_lower and "central retinal vein" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel dal retinal ven tıkanıklığı (BRVO); santral oklüzyon (CRVO) slaytı ile uyuşmuyor."
            elif target_dis == "crao" and "brao" in cap_lower and "crao" not in cap_lower and "central retinal artery" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel dal retinal arter tıkanıklığı (BRAO); santral oklüzyon (CRAO) slaytı ile uyuşmuyor."
            elif (target_dis in cap_lower) or (target_dis == "crao" and "central retinal artery" in cap_lower) or (target_dis == "crvo" and "central retinal vein" in cap_lower):
                disease_ok = True
        elif target_dis == "stargardt":
            if "best" in cap_lower and "stargardt" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel Best hastalığına ait; Stargardt slaytı ile uyuşmuyor."
            elif "stargardt" in cap_lower:
                disease_ok = True
        elif target_dis == "best":
            if "stargardt" in cap_lower and "best" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel Stargardt hastalığına ait; Best slaytı ile uyuşmuyor."
            elif "best" in cap_lower or "vitelliform" in cap_lower:
                disease_ok = True
        elif target_dis == "arn":
            if "toxoplasm" in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel Toksoplazmoz lezyonu; Akut Retinal Nekroz (ARN) slaytı ile uyuşmuyor."
            elif "arn" in cap_lower or "acute retinal necrosis" in cap_lower:
                disease_ok = True
        elif target_dis == "toxoplasmosis":
            if "cmv" in cap_lower and "toxoplasm" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel CMV retiniti; Toksoplazmoz slaytı ile uyuşmuyor."
            elif "arn" in cap_lower and "toxoplasm" not in cap_lower:
                disease_ok = False
                decision = "incompatible"
                quarantine = "Görsel ARN; Toksoplazmoz slaytı ile uyuşmuyor."
            elif "toxoplasm" in cap_lower:
                disease_ok = True
        elif target_dis in ("npdr", "pdr", "dme"):
            if expected_modality == "OCT B-scan" and modality == "teaching_schematic":
                modality_ok = False
                decision = "incompatible"
                quarantine = "Slayt klinik OCT B-scan gerektiriyor fakat görsel öğretici bir şemadır."
            else:
                disease_ok = any(d in cap_lower for d in ["dme", "dmö", "npdr", "pdr", "diabetic"])

        if expected_modality == "fundus" and modality == "histology":
            modality_ok = False
            decision = "incompatible"
            quarantine = "Histopatolojik kesit renkli fundus fotoğrafı olarak kullanılamaz."

        if len(panel_match) > 1:
            panel_ok = False
            decision = "review_required"
            quarantine = "Görsel birden çok panel (A, B, C) içeriyor ve spesifik panel ayrıştırılmamış; panel eşleşmesi inceleme gerektirir."

        if not original_caption or len(original_caption.strip()) < 10:
            decision = "review_required"
            quarantine = "Özgün şekil altyazısı eksik veya doğrulanamadı; kanıtsız onay verilemez."

        # Önkontrol başarılıysa dahi çevrimdışı modda görsel incelenmediği için review_required kalır!
        if disease_ok and modality_ok and panel_ok and not quarantine:
            decision = "review_required"
            quarantine = "Altyazı ön-taramasında açık çelişki saptanmadı; fakat görüntü pikselleri incelenmediğinden nihai karar inceleme gerektirir (review_required)."

        stage2 = Stage2ContextualVerification(
            disease_check=disease_ok,
            modality_check=modality_ok,
            panel_check=panel_ok,
            claim_support_check="not_evaluated",  # Offline modda iddia desteği görsel olarak incelenemez
            decision=decision,
            clinical_rationale=quarantine or "Görsel ön-tarama incelemesi.",
            quarantine_reason=quarantine,
        )

        return FullVisualAuditRecord(
            image_path=str(image_path),
            image_sha256=img_sha,
            context_hash=ctx_hash,
            target_slide_title=target_slide_title,
            target_disease_id=target_disease_id,
            original_caption=original_caption,
            target_claim=target_claim,
            expected_modality=expected_modality,
            argon_requested=self.strict_argon,
            requested_model="gemini-4-argon" if self.strict_argon else "none",
            actual_model="unknown",
            execution_mode="offline",
            stage1_completed=False,
            stage2_completed=False,
            verified_with_argon=False,
            model_decision=decision,
            expert_review_status="review_required",
            provider_response_id=None,
            langchain_run_id=None,
            stage1=stage1,
            stage2=stage2,
        )

    def _live_api_verify(
        self,
        *,
        image_path: Path,
        img_sha: str,
        ctx_hash: str,
        b64_data: str,
        mime_type: str,
        target_slide_title: str,
        target_disease_id: str,
        original_caption: str,
        target_claim: str,
        expected_modality: Optional[str],
    ) -> FullVisualAuditRecord:
        """
        Canlı / Multimodal API Çağrısı:
        Aşama 1 (Kör Muayene): Başlık olmadan görsel pikselleri modele gönderilir.
        Aşama 2 (Bağlamsal Onay): Görsel, altyazı, ilk gözlem ve iddia birlikte değerlendirilir.
        """
        import uuid
        from langchain_core.messages import HumanMessage
        from bookgraph import usage

        requested_model = "gemini-4-argon" if self.strict_argon else "gemini-3.8-flash"
        from bookgraph.visual_calls import invoke_json
        run_id = str(uuid.uuid4())
        stage1_completed = False
        stage2_completed = False
        actual1 = "unknown"
        actual2 = "unknown"
        resp_id1 = None
        resp_id2 = None
        lc_id1 = None
        lc_id2 = None

        def _get_llm(model_str: str):
            if self.llm_factory:
                return self.llm_factory(model_str)
            from langchain_google_genai import ChatGoogleGenerativeAI
            kwargs = dict(model=model_str, temperature=0, max_retries=0)
            if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").strip().lower() in ("1", "true", "yes"):
                if model_str.startswith(("gemini-3", "gemini-4")):
                    kwargs["location"] = "global"
            return ChatGoogleGenerativeAI(**kwargs)

        llm = _get_llm(requested_model)

        # -------------------------------------------------------------------------
        # AŞAMA 1: Kör Muayene (Hedef başlık ve iddia gösterilmez)
        # -------------------------------------------------------------------------
        s1_prompt = """Sen uzman bir tıbbi retina görüntüleme denetleyicisisin.
Aşağıdaki görseli incele. Başlık veya hastalık bilgisi verilmemiştir; yalnızca görüntüye dayanarak yanıt ver.
Çıktıyı yalnızca JSON formatında üret:
{
  "detected_modality": "fundus" | "OCT B-scan" | "OCTA" | "FA" | "ICGA" | "FAF" | "histology" | "teaching_schematic" | "unknown",
  "visible_findings": ["bulgu 1", "bulgu 2"],
  "readable_panel_letters": ["A", "B"],
  "image_quality_notes": "çözünürlük ve netlik",
  "uncertainties": ["belirsizlikler"],
  "is_compound_pathology": false
}"""
        msg_stage1 = HumanMessage(
            content=[
                {"type": "text", "text": s1_prompt},
                {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64_data}"}},
            ]
        )

        resp1, data1 = invoke_json(llm, [msg_stage1], requested_model=requested_model,
            book="retina_visual_verification", unit="stage1_blind_inspection", run_id=run_id,
            strict=self.strict_argon, validator=Stage1BlindObservation.model_validate)
        meta1 = getattr(resp1, "response_metadata", {}) or {}
        actual1 = meta1.get("model_version") or meta1.get("modelVersion") or meta1.get("model_name") or "unknown"
        resp_id1 = meta1.get("response_id") or meta1.get("responseId")
        if resp_id1 and str(resp_id1).startswith(("lc_run", "run-")):
            resp_id1 = None
        lc_id1 = getattr(resp1, "id", None)
        tokens1 = getattr(resp1, "usage_metadata", {}) or {}

        stage1 = Stage1BlindObservation(
            detected_modality=data1.get("detected_modality", "unknown"),
            visible_findings=data1.get("visible_findings", []),
            readable_panel_letters=data1.get("readable_panel_letters", []),
            image_quality_notes=data1.get("image_quality_notes", ""),
            uncertainties=data1.get("uncertainties", []),
            is_compound_pathology=data1.get("is_compound_pathology", False),
        )
        stage1_completed = True

        # -------------------------------------------------------------------------
        # AŞAMA 2: Bağlamsal Doğrulama (Görsel, altyazı, ilk gözlem ve iddia birlikte)
        # -------------------------------------------------------------------------
        s2_prompt = f"""Şimdi eldeki görseli ve 1. Aşama gözlemlerini aşağıdaki bağlamla karşılaştır:
- Hedef Slayt Başlığı: {target_slide_title}
- Hedef Hastalık ID: {target_disease_id}
- Hedef İddia: {target_claim}
- Beklenen Modalite: {expected_modality or 'belirtilmedi'}
- Özgün Şekil Altyazısı: {original_caption}
- 1. Aşama Gözlemleri: {stage1.model_dump_json()}

Aşağıdaki JSON şemasına göre değerlendir:
{{
  "disease_check": true,
  "modality_check": true,
  "panel_check": true,
  "claim_support_check": true,
  "decision": "compatible" | "incompatible" | "review_required",
  "clinical_rationale": "gerekçe",
  "quarantine_reason": "varsa karantina nedeni"
}}"""

        msg_stage2 = HumanMessage(
            content=[
                {"type": "text", "text": s2_prompt},
                {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64_data}"}},
            ]
        )

        resp2, data2 = invoke_json(llm, [msg_stage2], requested_model=requested_model,
            book="retina_visual_verification", unit="stage2_contextual_verification", run_id=run_id,
            strict=self.strict_argon, validator=Stage2ContextualVerification.model_validate)
        meta2 = getattr(resp2, "response_metadata", {}) or {}
        actual2 = meta2.get("model_version") or meta2.get("modelVersion") or meta2.get("model_name") or "unknown"
        resp_id2 = meta2.get("response_id") or meta2.get("responseId")
        if resp_id2 and str(resp_id2).startswith(("lc_run", "run-")):
            resp_id2 = None
        lc_id2 = getattr(resp2, "id", None)
        tokens2 = getattr(resp2, "usage_metadata", {}) or {}

        stage2_completed = True

        # Model kararının tutarlılık denetimi
        raw_decision = data2.get("decision", "review_required")
        final_decision, rationale, quarantine = validate_model_decision(
            suggested_decision=raw_decision,
            disease_check=data2.get("disease_check", False),
            modality_check=data2.get("modality_check", False),
            panel_check=data2.get("panel_check", False),
            claim_support_check=data2.get("claim_support_check", "not_evaluated"),
            stage1=stage1,
            clinical_rationale=data2.get("clinical_rationale", ""),
            quarantine_reason=data2.get("quarantine_reason"),
        )

        stage2 = Stage2ContextualVerification(
            disease_check=data2.get("disease_check", False),
            modality_check=data2.get("modality_check", False),
            panel_check=data2.get("panel_check", False),
            claim_support_check=data2.get("claim_support_check", "not_evaluated"),
            decision=final_decision,
            clinical_rationale=rationale,
            quarantine_reason=quarantine,
        )

        # Gerçek model belirleme (Asla istenen modeli gerçek model yerine yazma)
        actual_model = actual2  # A stage-1 identity cannot fill a missing stage-2 identity.

        # Argon doğrulama kontrolü:
        # strict_argon istendiyse, her iki aşama da tamamlandıysa ve her iki sağlayıcı yanıtı da gemini-4-argon içeriyorsa True olur.
        # DİKKAT: verified_with_argon=True olması model_decision'ın compatible olduğu anlamına GELMEZ.
        verified_with_argon = (
            self.strict_argon
            and stage1.detected_modality != "unknown"
            and stage1_completed
            and stage2_completed
            and actual1 != "unknown"
            and "gemini-4-argon" in actual1
            and actual2 != "unknown"
            and "gemini-4-argon" in actual2
        )

        return FullVisualAuditRecord(
            image_path=str(image_path),
            image_sha256=img_sha,
            context_hash=ctx_hash,
            target_slide_title=target_slide_title,
            target_disease_id=target_disease_id,
            original_caption=original_caption,
            target_claim=target_claim,
            expected_modality=expected_modality,
            argon_requested=self.strict_argon,
            requested_model=requested_model,
            actual_model=actual_model,
            execution_mode="live",
            stage1_completed=stage1_completed,
            stage2_completed=stage2_completed,
            verified_with_argon=verified_with_argon,
            model_decision=stage2.decision,
            expert_review_status="review_required",  # Otomatik asla approved olmaz
            provider_response_id=resp_id2 or resp_id1,
            langchain_run_id=lc_id2 or lc_id1,
            stage1=stage1,
            stage2=stage2,
        )
