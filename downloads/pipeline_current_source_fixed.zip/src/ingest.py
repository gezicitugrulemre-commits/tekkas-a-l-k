"""
Aşama 1: Oftalmoloji PDF Veritabanı Okuyucu ve Hibrit (ChromaDB Vektör + BM25) İndeksleyici.
Kaynak Dizin: C:/Users/gezic/OneDrive/Desktop/DATABASE/Ophthalmology KİTAPLARI

Özellikler:
- PyMuPDF (fitz) ile yüksek hızlı sayfa bazlı metin ve tablo çıkarımı.
- Her parçaya (chunk) tam kitap adı ve sayfa numarası (`source_book`, `page_number`) ekler.
- Artımlı (incremental) indeksleme: Daha önce işlenmiş PDF'leri tekrar işlemez, kaldığı yerden devam eder.
- Hibrit Arama (Reciprocal Rank Fusion - RRF): Vektör araması (anlamsal) + BM25 (OCT, BCSC, VEGF gibi tam tıbbi kısaltmalar).
"""

import hashlib
import json
import pickle
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import fitz  # PyMuPDF
from langchain_text_splitters import RecursiveCharacterTextSplitter
from rank_bm25 import BM25Okapi
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from config import MODEL_CONFIG, PATHS

console = Console()


class MedicalPDFCorpusIndexer:
    """PDF kütüphanesini parçalara ayırır, ChromaDB ve BM25 indekslerini oluşturur."""

    def __init__(self, source_dir: Path = PATHS.source_pdf_dir):
        PATHS.ensure_dirs()
        self.source_dir = source_dir
        self.manifest_path = PATHS.storage_dir / "ingested_files_manifest.json"
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=1600,
            chunk_overlap=250,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        self._chroma_collection = None

    def _get_chroma_collection(self):
        if self._chroma_collection is None:
            import chromadb
            client = chromadb.PersistentClient(path=str(PATHS.chroma_dir))
            # Chroma'nın varsayılan yerel çok dilli / hafif embedding modeli veya Google embedding'i kullanılabilir
            self._chroma_collection = client.get_or_create_collection(
                name="ophthalmology_library",
                metadata={"hnsw:space": "cosine"},
            )
        return self._chroma_collection

    def _load_manifest(self) -> Dict[str, dict]:
        if self.manifest_path.exists():
            return json.loads(self.manifest_path.read_text(encoding="utf-8"))
        return {}

    def _save_manifest(self, manifest: Dict[str, dict]) -> None:
        self.manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    @staticmethod
    def _file_fingerprint(pdf_path: Path) -> str:
        stat = pdf_path.stat()
        raw = f"{pdf_path.name}:{stat.st_size}:{int(stat.st_mtime)}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def discover_pdfs(self) -> List[Path]:
        if not self.source_dir.exists():
            raise FileNotFoundError(f"Veritabanı dizini bulunamadı: {self.source_dir}")
        pdfs = sorted(self.source_dir.rglob("*.pdf"))
        return pdfs

    def extract_pdf_chunks(self, pdf_path: Path) -> List[Dict]:
        """Tek bir PDF dosyasından sayfa numaralı metin parçaları çıkarır."""
        chunks_out: List[Dict] = []
        book_name = pdf_path.stem
        relative_folder = str(pdf_path.parent.relative_to(self.source_dir)) if pdf_path.parent != self.source_dir else "Root"

        try:
            doc = fitz.open(str(pdf_path))
        except Exception as exc:
            console.print(f"[yellow]Uyarı: {pdf_path.name} açılamadı ({exc})[/yellow]")
            return []

        for page_idx in range(len(doc)):
            try:
                page = doc[page_idx]
                text = page.get_text("text")
            except Exception:
                continue

            if not text or len(text.strip()) < 120:
                continue

            # Bozuk kontrol karakterlerini temizle
            cleaned = " ".join(text.split())
            page_chunks = self.splitter.split_text(cleaned)

            for chunk_idx, chunk_text in enumerate(page_chunks):
                chunk_id = f"{self._file_fingerprint(pdf_path)}_p{page_idx + 1}_c{chunk_idx}"
                chunks_out.append({
                    "id": chunk_id,
                    "text": chunk_text,
                    "metadata": {
                        "source_book": book_name,
                        "sub_collection": relative_folder,
                        "page_number": page_idx + 1,
                        "file_name": pdf_path.name,
                    }
                })

        doc.close()
        return chunks_out

    def run_ingestion(self, max_files: Optional[int] = None) -> Dict[str, int]:
        """
        Tüm PDF'leri tarar, yeni olanları ChromaDB'ye ve BM25 indeksine ekler.
        Kesintiye dayanıklıdır (her PDF sonunda manifest kaydedilir).
        """
        pdfs = self.discover_pdfs()
        if max_files:
            pdfs = pdfs[:max_files]

        manifest = self._load_manifest()
        collection = self._get_chroma_collection()

        console.print(f"[bold cyan]Toplam {len(pdfs)} PDF bulundu:[/bold cyan] {self.source_dir}")

        new_chunks_count = 0
        processed_files = 0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("PDF Kütüphanesi İndeksleniyor...", total=len(pdfs))

            for pdf_path in pdfs:
                fp = self._file_fingerprint(pdf_path)
                if pdf_path.name in manifest and manifest[pdf_path.name].get("fingerprint") == fp:
                    progress.advance(task)
                    continue

                progress.update(task, description=f"İşleniyor: {pdf_path.name[:45]}...")
                chunks = self.extract_pdf_chunks(pdf_path)

                if chunks:
                    # ChromaDB batch sınırına takılmamak için 250'lik gruplar halinde ekle
                    batch_size = 250
                    for i in range(0, len(chunks), batch_size):
                        batch = chunks[i : i + batch_size]
                        collection.upsert(
                            ids=[c["id"] for c in batch],
                            documents=[c["text"] for c in batch],
                            metadatas=[c["metadata"] for c in batch],
                        )
                    new_chunks_count += len(chunks)

                manifest[pdf_path.name] = {
                    "fingerprint": fp,
                    "chunks": len(chunks),
                    "path": str(pdf_path),
                }
                self._save_manifest(manifest)
                processed_files += 1
                progress.advance(task)

        # BM25 anahtar kelime indeksini güncelle
        self._rebuild_bm25_index(collection)

        return {
            "total_pdfs_found": len(pdfs),
            "newly_processed_pdfs": processed_files,
            "new_chunks_indexed": new_chunks_count,
            "total_chunks_in_db": collection.count(),
        }

    def _rebuild_bm25_index(self, collection) -> None:
        """ChromaDB'deki tüm dokümanlar üzerinden hızlı BM25 sözcüksel indeksi oluşturur."""
        total = collection.count()
        if total == 0:
            return
        console.print(f"[cyan]BM25 tıbbi terim indeksi oluşturuluyor ({total} parça)...[/cyan]")
        all_data = collection.get(include=["documents", "metadatas"])
        tokenized_corpus = [doc.lower().split() for doc in all_data["documents"]]
        bm25 = BM25Okapi(tokenized_corpus)
        payload = {
            "ids": all_data["ids"],
            "documents": all_data["documents"],
            "metadatas": all_data["metadatas"],
            "bm25": bm25,
        }
        with open(PATHS.bm25_index_path, "wb") as f:
            pickle.dump(payload, f)


class HybridMedicalRetriever:
    """
    Vektör (Anlamsal) + BM25 (Tam Tıbbi Terim/Kısaltma) sonuçlarını
    Reciprocal Rank Fusion (RRF) ile birleştiren hibrit erişim motoru.
    """

    def __init__(self):
        import chromadb
        client = chromadb.PersistentClient(path=str(PATHS.chroma_dir))
        self.collection = client.get_or_create_collection(name="ophthalmology_library")
        self.bm25_data = None
        if PATHS.bm25_index_path.exists():
            with open(PATHS.bm25_index_path, "rb") as f:
                self.bm25_data = pickle.load(f)

    def retrieve(self, queries: List[str], top_k: int = 12) -> List[Dict]:
        if self.collection.count() == 0:
            return []

        fused_scores: Dict[str, float] = {}
        chunk_store: Dict[str, Dict] = {}
        rrf_k = 60

        # 1. Vektör Araması (Semantic Search)
        vec_results = self.collection.query(
            query_texts=queries,
            n_results=min(top_k, self.collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        for q_idx in range(len(queries)):
            ids = vec_results["ids"][q_idx]
            docs = vec_results["documents"][q_idx]
            metas = vec_results["metadatas"][q_idx]
            for rank, (cid, doc, meta) in enumerate(zip(ids, docs, metas)):
                fused_scores[cid] = fused_scores.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)
                chunk_store[cid] = {
                    "id": cid,
                    "content": doc,
                    "source_book": meta.get("source_book", "Unknown"),
                    "page_number": meta.get("page_number", 0),
                }

        # 2. BM25 Sözcüksel Arama (Exact Medical Terminology Search)
        if self.bm25_data is not None:
            bm25: BM25Okapi = self.bm25_data["bm25"]
            bm25_ids = self.bm25_data["ids"]
            bm25_docs = self.bm25_data["documents"]
            bm25_metas = self.bm25_data["metadatas"]

            for query in queries:
                tokens = query.lower().split()
                scores = bm25.get_scores(tokens)
                # En yüksek skorlu top_k indeksi al
                top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
                for rank, idx in enumerate(top_indices):
                    if scores[idx] <= 0:
                        continue
                    cid = bm25_ids[idx]
                    fused_scores[cid] = fused_scores.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)
                    if cid not in chunk_store:
                        meta = bm25_metas[idx]
                        chunk_store[cid] = {
                            "id": cid,
                            "content": bm25_docs[idx],
                            "source_book": meta.get("source_book", "Unknown"),
                            "page_number": meta.get("page_number", 0),
                        }

        # RRF skoruna göre sırala ve en iyi top_k parçayı döndür
        sorted_ids = sorted(fused_scores.keys(), key=lambda cid: fused_scores[cid], reverse=True)[:top_k]
        results = []
        for cid in sorted_ids:
            item = chunk_store[cid]
            item["score"] = round(fused_scores[cid], 4)
            results.append(item)
        return results
