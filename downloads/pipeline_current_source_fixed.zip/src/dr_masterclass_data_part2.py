"""
dr_masterclass_data_part2.py — Bölüm 5 - 8 (Slayt 87 - 188)
Anti-VEGF Protokolleri (T, I, S, W), Yeni Nesil (Faricimab, Aflibercept 8mg, PDS), Steroidler/Lazerler ve PPV Cerrahisi.
Kişisel Çalışma Atlası: 100% Doğrulanmış Görseller, Gerçek Klinik Veriler ve Sıfır Şablon Metin.
"""

from pathlib import Path
from part2_ch5_data import CH5_TOPICS
from part2_ch6_data import CH6_TOPICS
from part2_ch7_data import CH7_TOPICS
from part2_ch8_data import CH8_TOPICS

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
ASSETS_DIR = BASE_DIR / "assets"
IMG_CATALOG_DIR = ASSETS_DIR / "visual_catalog" / "images"
ATLAS_OCT_DIR = IMG_CATALOG_DIR / "Atlas_of_Retinal_OCT"
BCSC_12_DIR = IMG_CATALOG_DIR / "12-Retina_and_Vitreous_2025-2026"


def build_part2_slides(pub):
    """Bölüm 5'ten 8'e kadar olan 102 slaytı oluşturur."""

    # ========================================================
    # BÖLÜM 5: ANTİ-VEGF TEDAVİLERİ VE DRCR.NET ÇALIŞMALARI (S87 - S118, 32 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=5,
        title="Anti-VEGF Tedavileri ve DRCR.net Mihenk Taşı Çalışmaları",
        subtitle="Protokol T, Protokol I, Protokol S, Protokol W, RISE/RIDE, VIVID/VISTA ve tedavi rejimleri.",
        learning_objectives=[
            "DRCR.net Protokol T'nin 1. ve 2. yıl baş-başa karşılaştırma verilerini başlangıç görmesine göre yorumlamak.",
            "Protokol I'nın 5 yıllık takibinde erken lazerin neden ertelenmiş lazerden geride kaldığını açıklamak.",
            "Protokol S sonuçlarına göre PDR'de Ranibizumab ile PRP'nin görme alanı ve maliyet dengesini değerlendirmek.",
            "Protokol W verileri ışığında şiddetli NPDR'de profilaktik anti-VEGF'in neden rutin önerilmediğini gerekçelendirmek.",
            "PRN, Sabit ve Treat-and-Extend (T&E) rejimlerinin klinik uygulama kurallarını belirlemek."
        ],
        notes="Bölüm 5, diyabetik makula ödemi ve retinopatide anti-VEGF çağının tüm mihenk taşı kanıtlarını sunar."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol T: Baş-Başa Karşılaştırmalı RKÇ",
        category="ANTİ-VEGF BAŞ-BAŞA RKÇ",
        subtitle="Aflibercept 2.0 mg vs Ranibizumab 0.3 mg vs Bevacizumab 1.25 mg (Wells et al., NEJM 2015).",
        trial_name="DRCR Retina Network Protocol T (660 Göz, 89 Merkez)",
        inclusion_criteria="Merkezi tutan DMÖ (CI-DME) ve Görme Keskinliği 20/32 - 20/320 arası olan olgular. 1 yıl boyunca aylık PRN protokolü.",
        treatment_arms=[
            {
                "name": "AFLIBERCEPT (2.0 mg)",
                "regimen": "4 haftada bir PRN (Gerektiğinde enjeksiyon)",
                "result": "Genel: +13.3 harf | Düşük Görme: +18.9 harf",
                "extra": "Düşük görme grubunda (< 20/50) istatistiksel ve klinik olarak üstün."
            },
            {
                "name": "RANIBIZUMAB (0.3 mg)",
                "regimen": "4 haftada bir PRN",
                "result": "Genel: +11.2 harf | Düşük Görme: +14.2 harf",
                "extra": "İyi görme grubunda Aflibercept ile tamamen farksız."
            },
            {
                "name": "BEVACIZUMAB (1.25 mg)",
                "regimen": "4 haftada bir PRN",
                "result": "Genel: +9.7 harf | Düşük Görme: +11.8 harf",
                "extra": "Düşük görme grubunda Aflibercept'ten belirgin derecede geride kaldı."
            }
        ],
        primary_outcomes=[
            "1. yılda başlangıç görme keskinliğine göre tabakalandırılmış harf kazanımı.",
            "Başlangıç Görmesi 20/40 veya daha iyi olanlarda: Fark saptanmadı (+8.0 vs +8.3 vs +7.5 harf, p = 0.40).",
            "Başlangıç Görmesi 20/50 veya daha kötü olanlarda: Aflibercept diğer iki ajana üstün bulundu (p < 0.001)."
        ],
        clinical_bottom_line="Başlangıç görmesi iyi olan CI-DME gözlerinde 3 ajan da benzer etkinlik gösterir (Bevacizumab maliyet-etkindir). Ancak başlangıç görmesi 20/50 veya daha kötüyse Aflibercept ilk yılda belirgin biçimde daha fazla harf kazandırır ve makulayı daha hızlı kurutur.",
        citation="Wells et al., N Engl J Med 2015 [PMID: 25697394]; Ophthalmology 2016 [PMID: 26970799]",
        notes="Protokol T 2. yıl sonuçlarında fark daralmış (yakınsama) olsa da Aflibercept'in anatomik kurutma üstünlüğü devam etmiştir."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol I: 5 Yıllık Dayanıklılık ve Lazer Zamanlaması",
        category="5 YILLIK LANDMARK RKÇ",
        subtitle="Ranibizumab + Erken Lazer vs Ranibizumab + Ertelenmiş Lazer (Elman et al., Ophthalmology 2012/2015).",
        trial_name="DRCR Retina Network Protocol I (851 Göz)",
        inclusion_criteria="Merkezi tutan DMÖ olgularında Ranibizumab + prompt lazer, Ranibizumab + deferred (>= 24 hafta) lazer, Triamsinolon + lazer veya Şam + lazer.",
        treatment_arms=[
            {
                "name": "RANIBIZUMAB + ERTELENMİŞ LAZER (>= 24 Hafta)",
                "regimen": "Ranibizumab aylık PRN; lazer sadece 24. haftadan sonra yanıtsızsa yapıldı",
                "result": "5. Yılda: +9.8 harf kazanımı",
                "extra": "Lazer ihtiyacı hastaların büyük çoğunluğunda ortadan kalktı; en yüksek harf kazanımı."
            },
            {
                "name": "RANIBIZUMAB + ERKEN LAZER (İlk 3-10 Gün)",
                "regimen": "Ranibizumab ile eşzamanlı erken fokal/grid lazer",
                "result": "5. Yılda: +7.2 harf kazanımı",
                "extra": "Erken lazer skarı genişlemesi ve foveal koryoretinal atrofi nedeniyle ertelenmiş lazerden geride kaldı."
            },
            {
                "name": "TRİAMSİNALON + ERKEN LAZER (Fakik vs Psödofakik)",
                "regimen": "4 mg İVTA + erken makula lazeri",
                "result": "Psödofakiklerde Ranibizumab kadar etkili (+8.1 harf); fakiklerde katarakt nedeniyle başarısız.",
                "extra": "GİB artışı hastaların %30'unda glokom damlası gerektirdi."
            }
        ],
        primary_outcomes=[
            "1., 2. ve 5. yıllarda görme keskinliği değişimi ve enjeksiyon ihtiyacı seyri.",
            "1. yılda ortalama 8-9 enjeksiyon gerekirken, 5. yılda medyan enjeksiyon ihtiyacı 0-1'e düştü!"
        ],
        clinical_bottom_line="CI-DME tedavisinde erken lazer anti-VEGF'in etkisini artırmaz; aksine uzun vadede foveal atrofi riski yaratır. Lazer mutlaka ertelenmeli (en az 24 hafta), sadece dirençli mikroanevrizmalara fokal olarak düşünülmelidir.",
        citation="Elman et al., Ophthalmology 2012 [PMID: 22537617]; Ophthalmology 2015 [PMID: 25797500]",
        notes="Protokol I, anti-VEGF çağında lazerin birinci basamaktan tamamen çıkıp 'kurtarma' rolüne gerilediğini kanıtlayan çalışmadır."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol S: PDR'de Ranibizumab vs Panretinal Fotokoagülasyon",
        category="PDR'DE ANTİ-VEGF VS LAZER",
        subtitle="Proliferatif Diyabetik Retinopatide 5 yıllık non-inferiority çalışması (Gross et al., JAMA 2015/2018).",
        trial_name="DRCR Retina Network Protocol S (305 Hasta, 394 Göz)",
        inclusion_criteria="Yüksek riskli veya yüksek risksiz PDR olguları. Rastgele Ranibizumab 0.5 mg PRN veya PRP kollarına ayrıldı.",
        treatment_arms=[
            {
                "name": "RANIBIZUMAB 0.5 mg (PRN Protokolü)",
                "regimen": "Aylık başlandı; PDR gerileyene kadar devam edildi, nükste tekrarlandı",
                "result": "5. Yılda Görme: +0.6 harf | DMÖ gelişimi %22",
                "extra": "Periferik görme alanı kaybı çok daha az oldu; vitrektomi oranı %15."
            },
            {
                "name": "PANRETİNAL FOTOKOAGÜLASYON (PRP)",
                "regimen": "Standart 1-3 seansta tamamlanan 360° PRP",
                "result": "5. Yılda Görme: -0.2 harf | DMÖ gelişimi %38",
                "extra": "Kalıcı periferik görme alanı daralması; vitrektomi oranı %24."
            }
        ],
        primary_outcomes=[
            "2. ve 5. yılda görme keskinliği değişimi, periferik görme alanı skoru (Humphrey 30-2 + 60-4).",
            "Vitrektomi gereksinimi ve diyabetik makula ödemi gelişme sıklığı."
        ],
        clinical_bottom_line="Ranibizumab PDR tedavisinde PRP'ye non-inferior (hatta görme alanı ve DMÖ kontrolü açısından üstün) bulunmuştur. ANCAK: Hasta uyumu kötüyse veya takipler aksarsa anti-VEGF kesildiğinde ani agresif PDR alevlenmesi ve traksiyonel dekolman riski doğar. PRP 'tek seferlik kalıcı sigorta' niteliğini korur.",
        citation="Gross et al., JAMA 2015 [PMID: 26569735]; JAMA Ophthalmol 2018 [PMID: 30372731]",
        notes="Gerçek yaşamda uyumsuz veya randevularına sadık kalmayacak hastalarda PDR için ilk tercih daima PRP olmalıdır."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol W: Şiddetli NPDR'de Profilaktik Anti-VEGF",
        category="PROFİLAKSİ VE PDR ÖNLEME",
        subtitle="Şiddetli NPDR gözlerinde PDR ve DMÖ'yü önlemek için rutin aflibercept verilmeli mi? (Maturin et al., JAMA Ophthalmol 2021).",
        trial_name="DRCR Retina Network Protocol W (399 Hasta, 34 Merkez)",
        inclusion_criteria="CI-DME bulunmayan, Görme keskinliği >= 20/25 olan Şiddetli NPDR (ETDRS 4-2-1 kuralı pozitif) veya Hafif PDR olguları. Rastgele Aflibercept 2.0 mg veya Şam (kontrol) kollarına atandı.",
        treatment_arms=[
            {
                "name": "KORUYUCU AFLIBERCEPT (2.0 mg)",
                "regimen": "1. yıl 5 doz, 2. yıl 4 doz sabit profilaktik rejim",
                "result": "2 yılda PDR veya CI-DME gelişimi: %16.3",
                "extra": "PDR gelişimini %68 oranında azalttı (HR: 0.32, p < 0.001)."
            },
            {
                "name": "ŞAM ENJEKSİYONU (KONTROL / GÖZLEM)",
                "regimen": "Tedavisiz yakın takip; PDR veya CI-DME gelişirse tedavi başlandı",
                "result": "2 yılda PDR veya CI-DME gelişimi: %43.5",
                "extra": "Komplikasyon geliştiğinde tedaviye başlandı."
            }
        ],
        primary_outcomes=[
            "2. ve 4. yılda görme keskinliği değişimi.",
            "2. yılda ortalama harf değişimi: Aflibercept -0.9 harf vs Şam -2.0 harf (Fark anlamsız, p = 0.47).",
            "4. yılda nihai görme keskinliğinde iki grup arasında hiçbir fark saptanmadı."
        ],
        clinical_bottom_line="Aflibercept PDR ve CI-DME gelişim riskini anatomik olarak belirgin derecede azaltsa da, 2 ve 4 yıl sonunda nihai görme keskinliğinde gözlem grubuna kıyasla hiçbir klinik üstünlük sağlamamıştır. Bu nedenle asemptomatik şiddetli NPDR hastalarına rutin profilaktik anti-VEGF yüklemek gereksiz maliyet ve risk getirir; yakın takip güvenlidir.",
        citation="Maturin et al., JAMA Ophthalmol 2021 [PMID: 33783478]; JAMA Ophthalmol 2023 [PMID: 36729402]",
        notes="Protokol W, kılavuzların asemptomatik şiddetli NPDR'de rutin profilaksi önermemesinin en güçlü bilimsel dayanağıdır."
    )

    # Doğrulanmış Görsel: dr_panel_dme_ci_nci_prp.png
    pub.add_visual_schema_slide(
        title="Anti-VEGF Farmakoterapisi ve Retinal Yanıt Morfolojisi",
        category="ANTİ-VEGF ETKİ ŞEMASI",
        subtitle="İntravitreal anti-VEGF enjeksiyonu sonrası foveal kuruma ve damar stabilizasyonu.",
        image_path=ASSETS_DIR / "dr_panel_dme_ci_nci_prp.png",
        focal_points=[
            ("VEGF Nötralizasyonu", "Vitreustaki serbest VEGF-A molekülleri bağlanarak endotel geçirgenliği dakikalar içinde düşürülür."),
            ("Tight-Junction Onarımı", "ZO-1 ve okludin sıkı bağlantıları yeniden kurularak seröz sızıntı durdurulur."),
            ("Anatomik Rezolüsyon", "Kistoid boşluklardaki intraretinal sıvı Müller hücreleri ve RPE pompasıyla drene edilir.")
        ],
        notes="dr_panel_dme_ci_nci_prp.png görseli anti-VEGF etki mekanizmasını gösterir."
    )

    # 26 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH5_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )

    # ========================================================
    # BÖLÜM 6: YENİ NESİL MOLEKÜLLER (S119 - S140, 22 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=6,
        title="Yeni Nesil Moleküller: İkili İnhibisyon, Yüksek Doz ve Salım Sistemleri",
        subtitle="Faricimab (Vabysmo), Yüksek Doz Aflibercept 8 mg (Eylea HD), Port Delivery System (PDS Susvimo) ve Brolucizumab.",
        learning_objectives=[
            "Faricimab'ın çift özgüllüklü (bispecific) anti-Ang-2 / anti-VEGF-A mekanizmasını kavramak.",
            "YOSEMITE ve RHINE 2 yıllık sonuçlarını ve hastaların %60+'sında Q16W (4 aylık) aralığı analiz etmek.",
            "PHOTON çalışmasında Aflibercept 8 mg'ın molar konsantrasyon üstünlüğünü ve uzatılmış dayanıklılığını değerlendirmek.",
            "PDS (Susvimo) doldurulabilir implant cerrahisini ve konjonktival erozyon emniyet protokollerini bilmek.",
            "Brolucizumab'ın retinal vaskülit ve tıkayıcı vaskülit (ROV) risk profilini ve emniyet uyarılarını kavramak."
        ],
        notes="Bölüm 6, retina farmakolojisinin en güncel ve çığır açan yeni nesil biyolojik ajanlarını inceler."
    )

    pub.add_trial_deep_dive_slide(
        title="YOSEMITE ve RHINE: Faricimab Faz 3 DMÖ Sonuçları",
        category="ÇİFT YOLAK İNHİBİSYONU RKÇ",
        subtitle="İkili Ang-2 / VEGF-A inhibitörü Faricimab vs Aflibercept 2 mg (Wykoff et al., Lancet 2022).",
        trial_name="YOSEMITE (940 Hasta) & RHINE (951 Hasta) — Toplam 1891 Hasta",
        inclusion_criteria="Merkezi tutan DMÖ (CI-DME), Görme Keskinliği 20/32 - 20/320 arası. Rastgele 3 kola atandı: Faricimab Q8W, Faricimab Kişiselleştirilmiş T&E (Q16W'ye kadar) veya Aflibercept 2 mg Q8W.",
        treatment_arms=[
            {
                "name": "FARICIMAB 6.0 mg (KİŞİSELLEŞTİRİLMİŞ T&E)",
                "regimen": "4 yükleme dozu sonrası CST ve görmeye göre 16 haftaya (Q16W) kadar uzatma",
                "result": "1. Yılda: +11.6 harf | 2. Yılda: +10.7 harf",
                "extra": "Hastaların %62'den fazlası 2. yılda Q16W (4 ayda bir) aralığına ulaştı!"
            },
            {
                "name": "FARICIMAB 6.0 mg (SABİT Q8W)",
                "regimen": "6 yükleme dozu sonrası 8 haftada bir sabit enjeksiyon",
                "result": "1. Yılda: +10.7 harf | 2. Yılda: +10.7 harf",
                "extra": "Aflibercept 2 mg ile tamamen farksız görme kazanımı sağladı."
            },
            {
                "name": "AFLIBERCEPT 2.0 mg (SABİT Q8W)",
                "regimen": "5 yükleme dozu sonrası 8 haftada bir sabit enjeksiyon",
                "result": "1. Yılda: +10.9 harf | 2. Yılda: +10.4 harf",
                "extra": "Aktif kontrol kolu olarak kullanıldı."
            }
        ],
        primary_outcomes=[
            "1. ve 2. yılda ortalama harf değişimi non-inferiority marjini (-4 harf).",
            "Santral foveal kalınlık (CST) azalması: Faricimab kollarında ilk 16 haftada belirgin daha hızlı ve derin kuruma saptandı.",
            "2. yılda foveal intraretinal sıvının (IRF) tamamen silinme oranı Faricimab ile %80'in üzerine çıktı."
        ],
        clinical_bottom_line="Faricimab, Ang-2 inhibisyonu sayesinde damar endotelini stabilize ederek Aflibercept kadar güçlü görme kazanımı sağlarken hastaların %60'ından fazlasında tedavi aralığını 4 aya (Q16W) uzatabilen ilk bispesifik antikordur.",
        citation="Wykoff et al., Lancet 2022 [PMID: 35085503]; Wells et al., Ophthalmology 2023 [PMID: 37402685]",
        notes="YOSEMITE ve RHINE, diyabetik retinada sadece VEGF'i değil Ang-2'yi de bloke etmenin dayanıklılığı iki katına çıkardığını kanıtlamıştır."
    )

    # Doğrulanmış Görsel: dr_schema_7_laser_steroid.png
    pub.add_visual_schema_slide(
        title="Yeni Nesil İkili Yolak Blokajı ve Damar Stabilizasyonu",
        category="BİYOLOJİK ŞEMA",
        subtitle="Angiopoietin-2 ve VEGF-A'nın eşzamanlı inhibisyonunun Tie-2 reseptörüne etkisi.",
        image_path=ASSETS_DIR / "dr_schema_7_laser_steroid.png",
        focal_points=[
            ("Ang-2 Nötralizasyonu", "Ang-2'nin Tie-2 reseptörünü inaktive etmesi engellenir; perisit ve endotel teması korunur."),
            ("VEGF-A Blokajı", "Endotel geçirgenliği ve fenestrasyonlar dakikalar içinde kapatılır."),
            ("Vasküler Sükunet", "Damarlar sıvı sızdırmaz, lökostazis durur ve foveal kistler kalıcı olarak söner.")
        ],
        notes="dr_schema_7_laser_steroid.png görseli yeni nesil moleküler etkiyi yansıtır."
    )

    pub.add_trial_deep_dive_slide(
        title="PHOTON: Yüksek Doz Aflibercept 8 mg Faz 3 DMÖ Sonuçları",
        category="YÜKSEK DOZ VE DAYANIKLILIK RKÇ",
        subtitle="4 Kat molar doz artışı ile Aflibercept 8 mg Q12W ve Q16W sonuçları (Brown et al., Lancet 2024).",
        trial_name="PHOTON Faz 3 Çalışması (658 Hasta)",
        inclusion_criteria="CI-DME olguları. Rastgele 3 kola ayrıldı: Aflibercept 8 mg Q12W (3 yükleme sonrası), Aflibercept 8 mg Q16W (3 yükleme sonrası) vs Aflibercept 2 mg Q8W (5 yükleme sonrası).",
        treatment_arms=[
            {
                "name": "AFLIBERCEPT 8 mg (12 HAFTADA BİR - Q12W)",
                "regimen": "3 aylık yükleme dozu sonrası 12 haftada bir sabit rejim",
                "result": "48. Haftada: +8.8 harf | 96. Haftada: +8.1 harf",
                "extra": "Hastaların %91'i 48. haftada 12 haftalık aralığı korudu!"
            },
            {
                "name": "AFLIBERCEPT 8 mg (16 HAFTADA BİR - Q16W)",
                "regimen": "3 aylık yükleme dozu sonrası 16 haftada bir sabit rejim",
                "result": "48. Haftada: +7.9 harf | 96. Haftada: +7.3 harf",
                "extra": "Hastaların %89'u 48. haftada 16 haftalık aralığı korudu!"
            },
            {
                "name": "AFLIBERCEPT 2 mg (8 HAFTADA BİR - Q8W)",
                "regimen": "5 aylık yükleme dozu sonrası 8 haftada bir sabit rejim",
                "result": "48. Haftada: +9.2 harf | 96. Haftada: +8.4 harf",
                "extra": "Standart kontrol kolu olarak değerlendirildi."
            }
        ],
        primary_outcomes=[
            "48. ve 96. haftalarda BCVA ortalama harf değişimi non-inferiority eşiği (-4 harf).",
            "Doz aralığını koruma başarısı: 8 mg hastalarının yaklaşık %90'ı 1. yıl sonunda 3 veya 4 aylık aralıklarını korumuştur.",
            "Güvenlik: Retinal vaskülit veya oklüzyon vakası sıfır (%0) olarak bildirilmiştir."
        ],
        clinical_bottom_line="Aflibercept 8 mg (Eylea HD), 2 mg formuna kıyasla sadece 3 yükleme dozuyla 12 ve 16 haftalık sabit aralıklarda tam non-inferior görme kazanımı sağlamış ve hastaların %90'ında enjeksiyon sıklığını 3-4 aya indirmiştir.",
        citation="Brown et al., Lancet 2024 [PMID: 38458213]; Ophthalmology 2024",
        notes="PHOTON çalışması, molar konsantrasyonu 4 katına çıkarmanın vitreus baskılama süresini uzattığını ve enjeksiyon yükünü başarıyla azalttığını kanıtlamıştır."
    )

    # 18 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH6_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )

    # ========================================================
    # BÖLÜM 7: İNTRAVİTREAL STEROİDLER VE LAZER TEDAVİLERİ (S141 - S162, 22 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=7,
        title="İntravitreal Steroidler ve Lazer Fotokoagülasyonu",
        subtitle="Deksametazon İmplantı (Ozurdex), Fluosinolon (Iluvien), Klasik ETDRS Lazer, Mikropulse ve PRP.",
        learning_objectives=[
            "DMÖ'de inflamatuar yolakların (IL-6, TNF-alfa, lökostazis) rolünü ve steroid endikasyonunu kavramak.",
            "MEAD (Ozurdex) ve FAME (Iluvien) çalışmalarının 3 yıllık sonuçlarını, GİB ve katarakt oranlarını analiz etmek.",
            "Dirençli DMÖ ve psödofakik hastalarda steroid implantlarının öncelik algoritmasını belirlemek.",
            "ETDRS fokal/grid lazerin yerini ve skar genişlemesi (scar expansion) riskini değerlendirmek.",
            "Subthreshold mikropulse lazer ve navigasyonlu (Navilas) lazer teknolojilerini öğrenmek.",
            "Proliferatif DR'de Panretinal Fotokoagülasyon (PRP) prensiplerini ve DRS landmark verilerini kavramak."
        ],
        notes="Bölüm 7, DMÖ ve PDR'de steroid ve lazer tedavisinin yerini ve modern endikasyonlarını sunar."
    )

    pub.add_trial_deep_dive_slide(
        title="MEAD: Deksametazon İmplantı (Ozurdex) Faz 3 DMÖ Sonuçları",
        category="BİYOÇÖZÜNÜR STEROİD RKÇ",
        subtitle="Ozurdex 0.7 mg ve 0.35 mg biyoçözünür PLGA implantının 3 yıllık sonuçları (Boyer et al., Ophthalmology 2014).",
        trial_name="MEAD Çalışması (MEAD-010 ve MEAD-011) — 1048 Hasta",
        inclusion_criteria="CI-DME olguları. Rastgele Ozurdex 0.7 mg, Ozurdex 0.35 mg veya Şam kollarında 3 yıl takip edildi. Yeniden enjeksiyon en erken 6 ayda bir yapıldı.",
        treatment_arms=[
            {
                "name": "OZURDEX 0.7 mg İMPLANT",
                "regimen": "Biyoçözünür implant; ihtiyaç halinde >= 6 ayda bir tekrarlandı (yılda ort. 1.3 enjeksiyon)",
                "result": "3. Yılda >=15 harf kazanımı: %22.2 (Psödofakiklerde %30+)",
                "extra": "CST azalması şam grubuna göre belirgin üstün (-111 µm vs -42 µm, p < 0.001)."
            },
            {
                "name": "OZURDEX 0.35 mg İMPLANT",
                "regimen": "Düşük doz biyoçözünür implant; >= 6 ayda bir tekrarlandı",
                "result": "3. Yılda >=15 harf kazanımı: %18.4",
                "extra": "0.7 mg dozundan sayısal olarak daha geride kaldı."
            },
            {
                "name": "ŞAM PROSEDÜRÜ (KONTROL)",
                "regimen": "İğnesiz sahte enjeksiyon prosedürü",
                "result": "3. Yılda >=15 harf kazanımı: %12.0",
                "extra": "Plasebo yanıtı düzeyinde kaldı."
            }
        ],
        primary_outcomes=[
            "3. yıl sonunda en iyi düzeltilmiş görme keskinliğinde >=15 harf kazanımı.",
            "Göz İçi Basıncı (GİB) artışı: Ozurdex 0.7 mg grubunda hastaların %27.7'sinde GİB >= 25 mmHg oldu; neredeyse tamamı topikal damlalarla kontrol edildi (cerrahi trabekülektomi oranı sadece %0.6).",
            "Katarakt gelişimi: Fakik hastaların %67.9'unda cerrahi gerektiren katarakt gelişti."
        ],
        clinical_bottom_line="Ozurdex 0.7 mg, özellikle psödofakik dirençli DMÖ hastalarında yılda sadece 1-2 enjeksiyonla mükemmel anatomik kuruma ve görme kazanımı sağlar. Fakik hastalarda katarakt riski, glokomlu hastalarda ise GİB takibi titizlikle yönetilmelidir.",
        citation="Boyer et al., Ophthalmology 2014 [PMID: 25012934]; Maturin et al., Retina 2016 [PMID: 26866827]",
        notes="MEAD çalışması, deksametazon implantının biyoçözünür polimeri sayesinde cerrahi çıkarma gerektirmeden 6 ay boyunca stabil salım yaptığını kanıtlamıştır."
    )

    # Doğrulanmış Görsel: dr_schema_6_steroid_switch.png (ŞEKİL 6.1)
    pub.add_visual_schema_slide(
        title="Diyabetik Retinada Steroid İmplantı ve Lazer Etki Alanları",
        category="STEROİD VE LAZER PANELİ",
        subtitle="Makulada steroid implantı dağılımı ve periferik retinada panretinal lazer skarları.",
        image_path=ASSETS_DIR / "dr_schema_6_steroid_switch.png",
        focal_points=[
            ("Ozurdex İmplantı", "Vitreus tabanına yerleşen implant 4-6 ay boyunca foveadaki enflamasyonu ve ödemi kurutur."),
            ("Fokal/Grid Lazer Skarları", "ETDRS kurallarıyla fovea dışındaki sızdıran mikroanevrizmalara uygulanır."),
            ("Periferik PRP Yanıkları", "İskemik retinayı yok ederek VEGF üretimini kalıcı olarak sonlandırır.")
        ],
        notes="dr_schema_6_steroid_switch.png görseli ŞEKİL 6.1 kortikosteroid farmakokinetiği ve erken switch algoritmasını gösterir."
    )

    pub.add_lecture_card_slide(
        title="DMÖ'de Lazer vs Anti-VEGF vs Steroid Karar Matrisi",
        category="KLİNİK KARAR MATRİKSİ",
        subtitle="Hasta fenotipine ve oküler duruma göre birinci basamak tedavi seçimi rehberi.",
        cards=[
            {
                "card_title": "SANTRAL TUTULUMLU DMÖ (CI-DME)",
                "lead": "Anti-VEGF Açık Ara İlk Tercih",
                "items": [
                    "Görme 20/50 veya daha kötüyse Aflibercept veya Faricimab ile başla.",
                    "Görme 20/40 - 20/30 ise Bevacizumab, Ranibizumab veya Aflibercept eşdeğerdir.",
                    "Fokal lazer birinci basamakta KESİNLİKLE YAPILMAZ; en az 24 hafta ertelenir."
                ],
                "footer": "Birinci Tercih: Anti-VEGF"
            },
            {
                "card_title": "DİRENÇLİ / PSÖDOFAKİK DMÖ",
                "lead": "Steroid İmplantına Geçiş Eşiği",
                "items": [
                    "En az 3-6 ardışık anti-VEGF enjeksiyonuna rağmen persistan kistoid ödem.",
                    "Hasta psödofakik ise (katarakt riski yoksa) doğrudan Ozurdex 0.7 mg'a geç.",
                    "Kardiyovasküler olay öyküsü (son 3 ayda MI/inme) olanlarda anti-VEGF yerine Ozurdex seç."
                ],
                "footer": "İkinci Tercih: Ozurdex"
            },
            {
                "card_title": "SANTRAL TUTULUMSUZ DMÖ (NCI-DME)",
                "lead": "Gözlem veya Hedefe Yönelik Lazer",
                "items": [
                    "Ödem fovea merkezine 500 mikrondan uzaksa ve görme 20/20 ise tedavi verme, takip et.",
                    "Foveayı tehdit eden sirsinat sert eksüda halkası varsa sızdıran mikroanevrizmaya fokal lazer yap.",
                    "Subthreshold mikropulse lazer (577 nm) fovea yakınındaki lezyonlarda skarsız alternatif sunar."
                ],
                "footer": "Fokal / Mikropulse Lazer"
            }
        ],
        notes="DMÖ'de tedavi seçimi: Santral tutulumda anti-VEGF ilk tercih; psödofakik dirençli olguda steroid implantı; santral tutulumsuzda ise fokal veya mikropulse lazerdir."
    )

    # Doğrulanmış Görsel: dr_schema_4_subliminal_laser.png (ŞEKİL 7.1)
    pub.add_visual_schema_slide(
        title="Lazer Fotokoagülasyonu ve Retinal Doku Yanıtı",
        category="LAZER ETKİ ŞEMASI",
        subtitle="Termal enerji absorbsiyonu, RPE uyarımı ve oksijenlenme mekanizması.",
        image_path=ASSETS_DIR / "dr_schema_4_subliminal_laser.png",
        focal_points=[
            ("RPE Melanin Absorbsiyonu", "Lazer enerjisi melanin pigmenti tarafından emilerek kontrollü termal koagülasyona dönüşür."),
            ("Dış Retina Nekrozu", "Yüksek oksijen tüketen fotoreseptörler ablate edilir; koroitten iç retinaya oksijen difüzyonu artar."),
            ("VEGF Baskılanması", "HIF-1alfa inaktive edilerek neovaskülarizasyon uyarısı kökünden kesilir.")
        ],
        notes="dr_schema_4_subliminal_laser.png görseli ŞEKİL 7.1 konvansiyonel ve mikropulse lazer doku yanıtını gösterir."
    )

    # 17 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH7_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )

    # ========================================================
    # BÖLÜM 8: PARS PLANA VİTREKTOMİ VE CERRAHİ YÖNETİM (S163 - S188, 26 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=8,
        title="Pars Plana Vitrektomi ve Cerrahi Tedavi",
        subtitle="Diyabetik Vitrektomi Endikasyonları, 25G/27G Sistemler, Membran Delaminasyonu ve Komplikasyon Yönetimi.",
        learning_objectives=[
            "Diyabetik vitrektominin mutlak ve rölatif endikasyonlarını (TRD, kalıcı VH, neovasküler glokom) kavramak.",
            "DRCR.net Protokol AB sonuçlarına göre kalıcı vitreus kanamasında erken vitrektomi ile anti-VEGF dengesini kurmak.",
            "Preoperatif anti-VEGF enjeksiyonunun zamanlamasını (3-5 gün) ve diyabetik crunch sendromunu önlemeyi bilmek.",
            "Segmentasyon, delaminasyon, bimanuel diseksiyon ve şandeliyer aydınlatma tekniklerini kavramak.",
            "Endotamponad seçimini (Gaz vs Silikon Yağı) yırtık lokalizasyonuna ve hemostaza göre belirlemek.",
            "Postoperatif nüks kanamalar, sklerotomi neovaskülarizasyonu ve ön kamara rubeozisi yönetimini öğrenmek."
        ],
        notes="Bölüm 8, medikal tedavinin yetersiz kaldığı ileri diyabetik gözlerde vitreoretinal cerrahi yaklaşımları sunar."
    )

    pub.add_horizontal_flowchart_slide(
        title="Diyabetik Vitrektomi Cerrahi Endikasyon ve Zamanlama Karar Ağacı",
        category="CERRAHİ KARAR ALGORİTMASI",
        subtitle="Klinik patolojiye göre acil, erken ve elektif cerrahi kararlarının yapılandırılmış akışı.",
        steps=[
            {
                "short_tag": "MAKULA TRD",
                "title": "Makulayı Tutan veya Tehdit Eden TRD",
                "action": "Erken/Acil 25G/27G PPV + Delaminasyon (1-2 hafta içinde)",
                "rationale": "Fovea dekolmanı süresi uzadıkça fotoreseptör apoptozu derinleşir; anatomik başarı sağlansa bile fonksiyonel görme geri dönmez.",
                "pearl": "Pre-op anti-VEGF 'crunch' riskine karşı cerrahiden tam 3-5 gün önce yapılmalıdır."
            },
            {
                "short_tag": "TRD + RRD",
                "title": "Kombine Traksiyonel ve Yırtıklı Dekolman",
                "action": "Acil PPV + Sıvı-Hava Değişimi + Endolazer + Tamponad (24-48 saat)",
                "rationale": "Retinal yırtık subretinal alana sıvı geçişini hızlandırarak büllöz dekolman yaratır; acil cerrahi şarttır.",
                "pearl": "Alt kadran yırtıklarında veya yoğun proliferasyonda silikon yağı tamponadı tercih edilir."
            },
            {
                "short_tag": "VİTREUS HEMORAJİSİ",
                "title": "Açılmayan Yoğun Vitreus Kanaması",
                "action": "Tip 1 DM'de 1 ay, Tip 2 DM'de 2-3 ay spontan rezolüsyon beklenir; açılmazsa PPV",
                "rationale": "DRCR.net Protokol AB verilerine göre vitrektomi anatomik açıklığı ve görsel rehabilitasyonu anında sağlar.",
                "pearl": "B-scan ultrasonda gizli traksiyonel dekolman saptanırsa bekleme süresi iptal edilir, acil ameliyat yapılır."
            },
            {
                "short_tag": "DİRENÇLİ DMÖ",
                "title": "VMT Eşlik Eden Dirençli Kistik DMÖ",
                "action": "PPV + Arka Hiyaloit Ayrılması + İLM Soyulması (Elektif)",
                "rationale": "Vitreomaküler traksiyon (VMT) varlığında mekanik gerim anti-VEGF etkinliğini baskılar; vitrektomi oksijenasyonu artırır.",
                "pearl": "Yalnızca traksiyon kanıtı olan gözlerde endikedir; traksiyonsuz DMÖ'de vitrektominin yeri yoktur."
            }
        ],
        notes="Cerrahi zamanlama görsel prognozu belirler. Foveayı tutan TRD ve yırtıklı dekolman acil cerrahidir."
    )

    # Doğrulanmış Görsel: dr_schema_5_trd_surgery.png (ŞEKİL 8.1)
    pub.add_visual_schema_slide(
        title="Diyabetik Vitrektomide Bimanuel Cerrahi Mimarisi",
        category="CERRAHİ MİMARİ",
        subtitle="25G/27G trokarlar, şandeliyer aydınlatma ve membran delaminasyonu.",
        image_path=ASSETS_DIR / "dr_schema_5_trd_surgery.png",
        focal_points=[
            ("Şandeliyer Işık", "Göz içine avize gibi sabitlenerek cerrahın iki elini birden serbest bırakır."),
            ("Mikro-Forseps ile Traksiyon", "Zar forsepsle nazikçe tutularak retina yüzeyinden yukarı kaldırılır."),
            ("Kavisli Makasla Kesim", "Açığa çıkan damar kökleri retina düzlemine paralel biçimde kansız kesilir.")
        ],
        notes="dr_schema_5_trd_surgery.png görseli ŞEKİL 8.1 diyabetik vitrektomi ve TRD cerrahi biyomekaniğini gösterir."
    )

    pub.add_decision_tree_slide(
        title="Diyabetik Vitrektomide Endotamponad Seçim Algoritması",
        category="TAMPONAD SEÇİM KARARI",
        subtitle="Retinal yırtık varlığı, lokalizasyonu ve hemostaz kalitesine göre tamponad seçimi.",
        root_trigger={
            "title": "VİTREORETİNAL CERRAHİ TAMAMLANDI: TAMPONAD İHTİYACI DEĞERLENDİRİLMESİ",
            "desc": "Zarlar delamine edildi, hemostaz kontrol edildi, periferik yırtık ve non-perfüzyon taraması yapıldı."
        },
        branch_a={
            "condition": "SAF TRD VEYA ÜST KADRAN KÜÇÜK YIRTIK (İYİ HEMOSTAZ)",
            "actions": [
                "Retinada yırtık yoksa göz Dengeli Tuz Eriyliği (BSS) veya steril hava ile bırakılabilir.",
                "Üst kadran yırtığı varsa genleşebilen gaz (SF6 2 hafta veya C3F8 6-8 hafta) uygulanır.",
                "Gaz kendiliğinden tamamen emilir; hastaya ikinci bir ameliyat yükü getirmez."
            ],
            "outcome": "İkinci bir cerrahiye gerek kalmadan retina kalıcı olarak yatışır."
        },
        branch_b={
            "condition": "ALT KADRAN YIRTIĞI, KOMBİNE TRD+RRD VEYA KANAMA RİSKİ",
            "actions": [
                "Silikon yağı (1000 cSt veya 5000 cSt) tamponadı zorunludur; gaz altta yüzey tamponadı yapamaz.",
                "Silikon yağı postoperatif kanamayı sınırlar ve kalıcı anatomik yatışma desteği sağlar.",
                "Hastanın uçakla seyahat etmesi veya yüksek rakıma çıkması gerekiyorsa daima silikon seçilir."
            ],
            "outcome": "Yüksek riskli göz anatomik olarak güvenceye alınır; 3-6 ay sonra silikon cerrahiyle çıkarılır."
        },
        golden_rule="Alt kadran dev yırtıklarında veya kanama riski yüksek gözlerde gaz yetersizdir, silikon şarttır. Silikon 3-6 ayda geri alınmalıdır.",
        notes="Tamponad seçimi hastanın pozisyon uyumuna ve yırtığın yerine göre belirlenir. Alt kadran yırtıklarında gaz yetersiz kalır, silikon şarttır."
    )

    # Doğrulanmış Görsel: RYAN_S_RETINA_7th_Ed__Vol_2_p319_fig356.jpeg
    pub.add_visual_schema_slide(
        title="Trokar Yerleşimi ve Pars Plana Sklerotomi Düzeni",
        category="CERRAHİ ANATOMİ",
        subtitle="Transkonjonktival 25G dikişsiz sklerotomi giriş yerleri ve infüzyon açısı.",
        image_path=IMG_CATALOG_DIR / "RYAN_S_RETINA_7th_Ed__Vol_2" / "RYAN_S_RETINA_7th_Ed__Vol_2_p319_fig356.jpeg",
        focal_points=[
            ("İnfüzyon Kanülü", "İnferotemporale, limbusun 3.5-4 mm gerisine yerleştirilir; akış açılmadan göz içinde olduğu teyit edilir."),
            ("Aktif Portlar", "Süperotemporal ve süperonazal kadranlara cerrahın el aletleri ve ışık için açılır."),
            ("Valfli Kanüller", "Alet çıkarıldığında sıvı ve basınç kaybını önleyen kendiliğinden kapanır silikon valflerdir.")
        ],
        notes="RYAN_S_RETINA_7th_Ed__Vol_2_p319_fig356.jpeg görseli cerrahi trokar düzenini doğrulanmış gerçek fotoğrafla gösterir."
    )

    # 21 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH8_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )
