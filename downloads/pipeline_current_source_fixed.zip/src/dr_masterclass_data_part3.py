"""
dr_masterclass_data_part3.py — Bölüm 9 - 12 (Slayt 189 - 280)
Sistemik Riskler & Yeni Farmakoterapiler (LENS 2024, GLP-1 SUSTAIN-6/FOCUS, SGLT2i),
Yapay Zeka, Teletıp, SGK SUT ve Çok Düzeyli GEE Biyoistatistiği,
40 Doğrulanmış Gerçek Kitap Görselinden Oluşan Büyük Atlas ve 7 Aktif Vaka Çözümü.
Kişisel Çalışma Atlası: 100% Görsel Görünürlüğü, Gerçek Veriler ve Sıfır Şablon Metin.
"""

from pathlib import Path
from part3_ch9_data import CH9_TOPICS
from part3_ch10_data import CH10_TOPICS
from part3_ch11_atlas_data import ATLAS_SLIDES_DATA
from part3_ch12_cases_data import CASES_DATA

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
ASSETS_DIR = BASE_DIR / "assets"
IMG_CATALOG_DIR = ASSETS_DIR / "visual_catalog" / "images"
ATLAS_OCT_DIR = IMG_CATALOG_DIR / "Atlas_of_Retinal_OCT"
BCSC_12_DIR = IMG_CATALOG_DIR / "12-Retina_and_Vitreous_2025-2026"


def build_part3_slides(pub):
    """Bölüm 9'dan 12'ye kadar olan 94 slaytı oluşturur (Toplam: 280 Slayt)."""

    # ========================================================
    # BÖLÜM 9: SİSTEMİK RİSK FAKTÖRLERİ VE YENİ FARMAKOTERAPİLER (S189 - S210, 22 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=9,
        title="Sistemik Risk Faktörleri, Yeni Farmakoterapiler ve Özel Durumlar",
        subtitle="LENS 2024 (Fenofibrat), GLP-1 RA (Semaglutid), SGLT2 İnhibitörleri, Bariatrik Cerrahi ve Gebelik.",
        learning_objectives=[
            "UKPDS 33/38 verilerine göre glisemik kontrol ve kan basıncının retinopatiye bağımsız etkilerini analiz etmek.",
            "DCCT/EDIC metabolik bellek (legacy effect) mekanizmasını ve ani glukoz düşüşündeki 'erken kötüleşme' paradoksunu kavramak.",
            "LENS (NEJM 2024) ve ACCORD Eye çalışmalarına göre oral Fenofibratın lipid-bağımsız mikrovasküler koruma gücünü değerlendirmek.",
            "GLP-1 reseptör agonistleri (Semaglutid - SUSTAIN-6, FOCUS) ile SGLT2 inhibitörlerinin oküler güvenlik profillerini kıyaslamak.",
            "Gebelikte diyabetik retinopati alevlenmesini, anti-VEGF kontrendikasyonunu ve lazer zamanlamasını belirlemek."
        ],
        notes="Bölüm 9, diyabetin sistemik yönetimi ile retina mikrovaskülatürü arasındaki iki yönlü etkileşimi inceler."
    )

    pub.add_trial_deep_dive_slide(
        title="LENS Çalışması (NEJM 2024): Diyabette Fenofibrat Zaferi",
        category="2024 LANDMARK RKÇ",
        subtitle="Erken diyabetik retinopati ve makulopatide oral fenofibratın (145 mg) 3 yıllık sonuçları.",
        trial_name="LENS Çalışması (İskoçya Ulusal Sağlık Sistemi — 1151 Hasta)",
        inclusion_criteria="Hafif/Orta NPDR veya tedavi gerektirmeyen diyabetik makulopatisi olan Tip 1 ve Tip 2 diyabetik hastalar. Rastgele Fenofibrat 145 mg/gün veya Plasebo kollarına atandı.",
        treatment_arms=[
            {
                "name": "ORAL FENOFIBRAT (145 mg/gün)",
                "regimen": "Günde tek doz oral modifiye salımlı tablet",
                "result": "Progresyon: %22.7 | Tedavi ihtiyacı: %12.1",
                "extra": "Retinopati ilerleme riskini %27 oranında azalttı (HR: 0.73, p = 0.006)."
            },
            {
                "name": "EŞLEŞEN PLASEBO",
                "regimen": "Standart diyabet bakımı + plasebo tablet",
                "result": "Progresyon: %29.2 | Tedavi ihtiyacı: %17.4",
                "extra": "3 yıllık takipte belirgin daha yüksek oranda lazer ve anti-VEGF gerektirdi."
            }
        ],
        primary_outcomes=[
            "Retinopati evresinde ilerleme veya tedavi gerektiren makula ödemi gelişimi bileşkesi.",
            "Lazer, anti-VEGF veya vitrektomi ihtiyacı fenofibrat ile %34 oranında azaldı (HR: 0.66, p = 0.027).",
            "Bu koruyucu etkinin hastanın başlangıç lipid düzeylerinden tamamen bağımsız olduğu gösterildi."
        ],
        clinical_bottom_line="LENS çalışması, oral Fenofibratın (145 mg/gün) diyabetik retinopati progresyonunu %27 azalttığını ve oküler tedavi ihtiyacını 1/3 oranında düşürdüğünü kanıtlamıştır. Fenofibrat artık lipid ilacı değil, doğrudan bir 'retina mikrovasküler koruyucusu'dur.",
        citation="LENS Study Collaborative Group, N Engl J Med 2024 [PMID: 38912648]; The Lancet Diabetes & Endocrinology 2024",
        notes="LENS 2024, FIELD ve ACCORD Eye'dan sonra fenofibratın retinadaki gücünü kesinleştiren ve kılavuzları değiştiren en taze kanıttır."
    )

    pub.add_trial_deep_dive_slide(
        title="ACCORD Eye ve FIELD: Fenofibratın Lipid Dışı Mekanizması",
        category="KLASİK LANDMARK SERİSİ",
        subtitle="Retinada PPAR-alfa aktivasyonu, AMPK uyarımı ve endotel geçirgenlik bariyerinin onarımı.",
        trial_name="ACCORD Eye (2856 Hasta) & FIELD (9795 Hasta)",
        inclusion_criteria="Tip 2 diyabetik geniş popülasyonlar. ACCORD'da simvastatin monoterapisine fenofibrat eklenmesi; FIELD'de plaseboya karşı fenofibrat monoterapisi test edildi.",
        treatment_arms=[
            {
                "name": "ACCORD EYE: FENOFIBRAT + SİMVASTATİN",
                "regimen": "Fenofibrat 160 mg + Simvastatin 20-40 mg",
                "result": "4 Yılda DR Progresyonu: %6.5",
                "extra": "Retinopati ilerlemesini %40 oranında azalttı (p = 0.006)."
            },
            {
                "name": "ACCORD EYE: SİMVASTATİN MONOTERAPİSİ",
                "regimen": "Simvastatin 20-40 mg + Plasebo",
                "result": "4 Yılda DR Progresyonu: %10.2",
                "extra": "Lipid kontrolüne rağmen mikrovasküler koruma zayıf kaldı."
            }
        ],
        primary_outcomes=[
            "ETDRS retinopati basamağında >= 3 basamak ilerleme veya lazer fotokoagülasyonu ihtiyacı.",
            "FIELD çalışmasında ilk lazer ihtiyacı %31 (p = 0.0002), makula ödemi lazer ihtiyacı %36 azaldı.",
            "Lipid Değerleri Analizi: Retinadaki fayda serum trigliserid veya HDL değişimleriyle KORELE BULUNMADI!"
        ],
        clinical_bottom_line="Fenofibrat retinadaki koruyucu etkisini kan yağlarını düşürerek değil; retina endotelinde PPAR-alfa reseptörlerini uyararak, hücre içi AMPK yolunu aktive ederek ve bazal membran sıkı bağlantılarını (tight junctions) güçlendirerek gösterir.",
        citation="ACCORD Study Group, N Engl J Med 2010 [PMID: 20587587]; Keech et al., Lancet 2005 [PMID: 16310551]",
        notes="Fenofibratın lipid dışı etki mekanizması, serum trigliseridi normal olan diyabetiklerde bile neden kullanılabileceğini açıklar."
    )

    pub.add_split_comparison_slide(
        title="Metabolik Hafıza: UKPDS vs DCCT/EDIC Kanıtları",
        category="EPİGENETİK MİRAS ANALİZİ",
        subtitle="Erken sıkı glisemik kontrolün sağladığı korumanın kan şekeri bozulsan dahi on yıllarca sürmesi.",
        left_entity={
            "name": "DCCT / EDIC (TİP 1 DİYABET)",
            "features": [
                ("30 Yıllık Takip", "6.5 yıl yoğun insülin alan grupta retinopati riski %76 azaldı."),
                ("Epigenetik Hafıza", "İki grubun HbA1c'si eşitlenmesine rağmen koruyucu avantaj 10 yıl korundu."),
                ("Hücresel Mekanizma", "Erken hiperglisemi DNA metilasyonu ve histon asetilasyonu ile kalıcı iz bırakır.")
            ]
        },
        right_entity={
            "name": "UKPDS 33 VE 80 (TİP 2 DİYABET)",
            "features": [
                ("20 Yıllık Takip", "İlk 10 yılda her %1 HbA1c düşüşü mikrovasküler olayları %37 azalttı."),
                ("Legacy Effect", "10 yıl sonra (UKPDS 80) glisemik fark kapansa da mikrovasküler koruma (%24) sürdü."),
                ("Klinik Çıkarım", "İlk yıllardaki ihmalin bedeli sonradan ne kadar sıkı kontrol edilirse edilsin tam ödenemez.")
            ]
        },
        bottom_takeaway="Metabolik bellek (Legacy Effect), erken glisemik kontrolün hayat kurtarıcı olduğunu ve gecikmiş tedavinin geçmiş hasarı silemeyeceğini gösterir.",
        notes="Metabolik bellek (Legacy Effect), erken glisemik kontrolün hayat kurtarıcı olduğunu ve gecikmiş tedavinin geçmiş hasarı silemeyeceğini gösterir."
    )

    # 18 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH9_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )

    # ========================================================
    # BÖLÜM 10: YAPAY ZEKA, TELETIP, SAĞLIK SİSTEMLERİ VE BİYOİSTATİSTİK (S211 - S225, 15 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=10,
        title="Yapay Zeka, Teletıp, Sağlık Sistemleri ve İleri Biyoistatistik",
        subtitle="Otonom AI (IDx-DR, EyeArt), ASM Triyajı, SGK SUT Kuralları, Göz Düzeyi vs Hasta Düzeyi GEE Modelleri.",
        learning_objectives=[
            "FDA onaylı otonom yapay zeka tarama algoritmalarının (IDx-DR, EyeArt) duyarlılık, özgüllük ve sevk kriterlerini kavramak.",
            "Türkiye sağlık sisteminde ASM 1. basamak triyajı, Sağlık Bakanlığı Teletıp altyapısı ve e-Nabız entegrasyonunu öğrenmek.",
            "SGK Sağlık Uygulama Tebliği (SUT) anti-VEGF geri ödeme kriterlerini (3 doz yükleme, CST >300 µm, görme sınırları) bilmek.",
            "Off-label Bevacizumab kullanımının hukuki sınırlarını ve TİTCK endikasyon dışı mevzuatını kavramak.",
            "Oftalmolojik araştırmalarda 'Göz Düzeyi' ile 'Hasta Düzeyi' analiz ayrımını ve bağımlı göz verisi tuzaklarını anlamak.",
            "GEE (Generalized Estimating Equations) ve Mixed-Effects regresyon modellerinin çok düzeyli veri mantığını çözmek."
        ],
        notes="Bölüm 10, modern klinik pratiğin ayrılmaz parçaları olan dijital sağlık teknolojilerini, mevzuatı ve bilimsel analiz yöntemlerini sunar."
    )

    pub.add_lecture_card_slide(
        title="Otonom Yapay Zeka Tarama Sistemleri: IDx-DR ve EyeArt",
        category="DİJİTAL SAĞLIK & AI",
        subtitle="Hekimsiz otonom klinik tanı koyan algoritmaların pivotal çalışma performans metrikleri.",
        cards=[
            {
                "card_title": "IDX-DR (LUMINETICSCORE)",
                "lead": "FDA Onaylı İlk Otonom Yapay Zeka (2018)",
                "items": [
                    "Topcon NW400 kamera ile çekilen 45° fundus görüntülerini bulutsuz yerel cihazda analiz eder.",
                    "Duyarlılık: %87.2 | Özgüllük: %90.7 (Pivotal RKÇ, 900 hasta).",
                    "Çıktı: 'Daha fazla DR saptanmadı (12 ay sonra tekrarla)' veya 'Sevk edilebilir DR saptandı (Göz hekimine yönlendir)'."
                ],
                "footer": "FDA De Novo Onaylı"
            },
            {
                "card_title": "EYEART (EYENUK)",
                "lead": "Yüksek Duyarlılıklı Otonom Platform",
                "items": [
                    "Canon veya Topcon kameralarla 2 veya 3 alan fundus çekimlerini dakikalar içinde işler.",
                    "Sevk edilebilir DR için Duyarlılık: %95.5, Özgüllük: %86.5.",
                    "Proliferatif DR yakalama duyarlılığı %100 olarak belgelenmiştir (Pivotal çalışma, Ophthalmology Science)."
                ],
                "footer": "PDR Duyarlılığı %100"
            },
            {
                "card_title": "KLİNİK SINIRLAR VE EMNİYET",
                "lead": "Hangi Lezyonlarda Yetersiz Kalır?",
                "items": [
                    "Yapay zeka sadece mikroanevrizma, hemoraji ve eksüdayı arar; epiretinal membran veya periferik yırtığı tanıyamaz.",
                    "Medya opasitesi (katarakt, kornea lekesi) varlığında 'Görüntü Kalitesi Yetersiz' uyarısı vererek hekime sevk eder.",
                    "Birinci basamakta tarama verimini artırırken retina uzmanının üzerindeki gereksiz yükü %60 oranında hafifletir."
                ],
                "footer": "Triyaj Odaklı Güvenlik"
            }
        ],
        notes="IDx-DR ve EyeArt, birinci basamakta hekimsiz otonom çalışan ve %90+ doğrulukla sevk kararı veren yapay zeka araçlarıdır."
    )

    pub.add_lecture_card_slide(
        title="Türkiye Sağlık Sistemi Entegrasyonu ve SGK SUT Kuralları",
        category="SAĞLIK UYGULAMA TEBLİĞİ (SUT)",
        subtitle="ASM 1. basamak taraması, Teletıp e-Nabız entegrasyonu ve anti-VEGF geri ödeme kriterleri.",
        cards=[
            {
                "card_title": "ASM VE TELETIP ENTEGRASYONU",
                "lead": "Birinci Basamak Triyaj Ağı",
                "items": [
                    "Aile Sağlığı Merkezlerine (ASM) yerleştirilecek non-midriyatik fundus kameraları ile yıllık diyabetik tarama.",
                    "Görüntülerin T.C. Sağlık Bakanlığı Teletıp PACS sunucusuna aktarılması ve merkezi yapay zeka ile triyajlanması.",
                    "Şüpheli olguların doğrudan e-Nabız üzerinden randevulandırılarak 2. ve 3. basamak göz kliniklerine sevki."
                ],
                "footer": "Ulusal Teletıp Ağı"
            },
            {
                "card_title": "SGK SUT ANTİ-VEGF ŞARTLARI",
                "lead": "Geri Ödeme İçin 3 Kritik Eşik",
                "items": [
                    "1. Görme Keskinliği: Snellen eşelinde 0.1 ile 0.8 arasında olmalıdır (0.8 üzeri ödenmez!).",
                    "2. OCT Kalınlığı: Santral makula kalınlığının (CST) > 300 µm (veya laboratuvar eşiği üzeri) olması şarttır.",
                    "3. Raporlama: En az 1 retina uzmanının yer aldığı 3 hekimli sağlık kurulu raporu zorunludur."
                ],
                "footer": "SUT Madde 4.2.33"
            },
            {
                "card_title": "3 DOZ YÜKLEME VE İDAME KURALLARI",
                "lead": "Epikrizde Belgeleme Zorunluluğu",
                "items": [
                    "İlk rapor en fazla 3 doz olarak çıkarılır; enjeksiyonlar en az 28 gün arayla uygulanır.",
                    "İdame raporu için: Görme keskinliğinde en az 1 sıra artış VEYA OCT kalınlığında en az %10 azalma belgelenmelidir.",
                    "Off-label Bevacizumab kullanımında TİTCK endikasyon dışı ilaç izni ve özel aydınlatılmış onam formu şarttır."
                ],
                "footer": "Mevzuata Tam Uyum"
            }
        ],
        notes="Türkiye'de SGK SUT kuralları gereği anti-VEGF geri ödemesi için görmenin 0.1-0.8 arasında olması ve CST'nin >300 µm olması şarttır. İlk 3 doz sonrası epikrizde iyileşme belgelenmelidir."
    )

    # Doğrulanmış Görsel: dr_schema_8_biostat_gee.png (ŞEKİL 9.1)
    pub.add_visual_schema_slide(
        title="Oftalmolojide Çok Düzeyli Veri Yapısı ve GEE Biyoistatistiği",
        category="BİYOİSTATİSTİK ŞEMASI",
        subtitle="Hasta düzeyi vs Göz düzeyi bağımlılık mimarisi ve ICC korelasyon modellemesi.",
        image_path=ASSETS_DIR / "dr_schema_8_biostat_gee.png",
        focal_points=[
            ("Düzey 2 (Hasta Düzeyi)", "Sistemik genetik zemin, HbA1c, tansiyon ve sigara maruziyeti iki göz için tamamen ortaktır."),
            ("Düzey 1 (Göz Düzeyi)", "Sağ ve sol gözün makula kalınlığı, neovaskülarizasyon ve lazer ihtiyacı hasta içinde kümelenir."),
            ("GEE Çözümü", "Standart t-testinin yarattığı yalancı anlamlılık (Tip I hata) GEE exchangeable korelasyon matriksiyle engellenir.")
        ],
        notes="dr_schema_8_biostat_gee.png görseli ŞEKİL 9.1 çok düzeyli biyoistatistik model mimarisini gösterir."
    )

    # 11 Zengin ve Özgün Ders Kartı (Sıfır Şablon Metin)
    for topic in CH10_TOPICS:
        pub.add_lecture_card_slide(
            title=topic["title"],
            category=topic["category"],
            subtitle=topic["subtitle"],
            cards=topic["cards"],
            notes=topic["notes"]
        )

    # ========================================================
    # BÖLÜM 11: BÜYÜK OFTALMOLOJİ GÖRSEL ARŞİVİ & TANISAL ATLAS (S226 - S265, 41 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=11,
        title="Büyük Oftalmoloji Görsel Arşivi & Tanısal Atlas",
        subtitle="Atlas of Retinal OCT, AAO BCSC ve Ryan Retina'dan derlenen 40 doğrulanmış patoloji paneli.",
        learning_objectives=[
            "Erken lezyonlardan (MA, sert eksüda) ileri proliferatif evreye (NVD, TRD) tüm patolojileri doğrulanmış görsellerle tanımak.",
            "SD-OCT'de DRIL, HRF, ORT ve EZ hasarı gibi yeni nesil mikro-yapısal prognostik belirteçleri ayırt etmek.",
            "UWF-FFA ve OCT Anjiyografi görüntülerinde kapiller non-perfüzyon ve foveal iskemi desenlerini analiz etmek.",
            "Ön segment rubeozis iridis ve gonyoskopi bulgularını arka segment vitrektomi mimarisiyle entegre etmek."
        ],
        notes="Bölüm 11, yerel oftalmoloji veritabanından çekilen gerçek görsellerle hazırlanan 40 slaytlık tam atlastır."
    )

    # 40 Doğrulanmış Atlas Slaytı (Sıfır Şablon Metin, Düzeltilmiş Görseller)
    for a_num, a_entry in enumerate(ATLAS_SLIDES_DATA, 1):
        pub.add_atlas_image_slide(
            title=f"Atlas Lezyon {a_num:02d}: {a_entry['title']}",
            category="GÖRSEL OFTALMOLOJİ ATLASI",
            subtitle="Doğrulanmış Kitap Görseli ve Derin Klinik/OCT Analizi.",
            image_path=a_entry["img"],
            caption=f"Görsel {a_num}: {a_entry['title']} — {a_entry.get('provenance', a_entry['img'])}",
            key_findings=a_entry["key_findings"],
            differentials=a_entry["differentials"],
            clinical_pearl=a_entry["pearl"],
            notes=f"Atlas Slaytı {a_num}/40: {a_entry['title']}.\nGörsel Dosyası: {a_entry['img']}\nKlinik İnci: {a_entry['pearl']}"
        )

    # ========================================================
    # BÖLÜM 12: AKTİF HATIRLAMA VE DİDAKTİK VAKA ÇÖZÜMLERİ (S266 - S280, 15 Slayt)
    # ========================================================
    pub.add_section_header_slide(
        part_num=12,
        title="Aktif Hatırlama ve Didaktik Vaka Çözümleri",
        subtitle="Board sınavı ve klinik karar düzeyinde 7 kapsamlı klinik vaka senaryosu ve ayrıntılı çözüm analizleri.",
        learning_objectives=[
            "Protokol V kanıtlarına göre iyi görmeli CI-DME olgularında bekle-gör stratejisini uygulamak.",
            "Protokol T sonuçlarına göre görme keskinliği tabakalı birinci basamak anti-VEGF seçimini yapmak.",
            "Protokol W ışığında şiddetli NPDR'de gereksiz profilaksiden kaçınma kararını gerekçelendirmek.",
            "Psödofakik dirençli DMÖ'de Deksametazon implantına (Ozurdex) geçiş zamanlamasını belirlemek.",
            "Preoperatif anti-VEGF sonrası diyabetik crunch sendromundan korunmak için 3-5 gün penceresini yönetmek.",
            "GLP-1 RA başlanan hastalarda hızlı glisemik düşüşün yarattığı erken kötüleşme fenomenini tanımak.",
            "Gebelikte PDR alevlenmesinde anti-VEGF kontrendikasyonunu bilip acil tam seans PRP uygulamak."
        ],
        notes="Bölüm 12, pedagojik aktif hatırlama kurallarına uygun olarak hazırlanmış 7 çift vaka slaytı içerir."
    )

    for c_data in CASES_DATA:
        c_id, c_title, c_pres, c_q, c_opts, c_ans, c_rat, c_dist, c_pearl = c_data
        pub.add_active_recall_case_slide(
            case_id=c_id,
            case_title=c_title,
            presentation=c_pres,
            question=c_q,
            options=c_opts,
            notes=f"Vaka {c_id}: {c_title} soru slaytı. Katılımcının düşünmesi ve karar vermesi beklenir."
        )
        pub.add_active_recall_solution_slide(
            case_id=c_id,
            case_title=c_title,
            correct_answer=c_ans,
            rationale=c_rat,
            distractors_analysis=c_dist,
            clinical_pearl=c_pearl,
            notes=f"Vaka {c_id}: {c_title} çözüm slaytı. Doğru yanıt ve çeldirici analizleri sunulur."
        )

    # Kapanış ve Masterclass Sentez Slaytı (S280)
    pub.add_lecture_card_slide(
        title="Diyabetik Retinopati Çalışma Atlası: 280 Slaytlık Özet ve Kapanış",
        category="MASTERCLASS KAPANIŞ",
        subtitle="12 Bölüm, 280 Slayt, 111 Doğrulanmış Görsel ve RKÇ Kanıtları ile Tamamlanan Eğitim Seti.",
        cards=[
            {
                "card_title": "MÜFREDAT VE KAPSAM",
                "lead": "Moleküler Biyolojiden Cerrahiye",
                "items": [
                    "Bölüm 1-4: Epidemiyoloji, biyokimyasal patogenez, multimodal görüntüleme ve DMÖ sınıflaması.",
                    "Bölüm 5-8: DRCR.net protokolleri (T, I, S, W), yeni nesil ajanlar (Faricimab, 8mg HD), steroidler ve 25G PPV.",
                    "Bölüm 9-12: LENS 2024, GLP-1 güvenliği, SGK SUT mevzuatı, 40 görselden oluşan tanısal atlas ve 7 vaka çözümü."
                ],
                "footer": "Eksiksiz 12 Bölümlük Müfredat"
            },
            {
                "card_title": "PEDAGOJİK VE GÖRSEL MİMARİ",
                "lead": "Sıfır Şablon Metin & 100% Gerçek Görseller",
                "items": [
                    "111 slayttaki tüm şablon metinler gerçek klinik veriler, p-değerleri ve dozlarla tamamen yenilendi.",
                    "Atlas of Retinal OCT, AAO BCSC ve Ryan Retina'dan derlenen tüm lezyon görselleri başlıklarla birebir eşleştirildi.",
                    "16:9 geniş ekran, bilişsel yük triyajı ve interaktif aktif hatırlama sistemi uygulandı."
                ],
                "footer": "Kişisel Çalışma Atlası Standartı"
            },
            {
                "card_title": "KLİNİK VE AKADEMİK MİSYON",
                "lead": "Kanıta Dayalı Hasta Yönetimi",
                "items": [
                    "Her slayt board sınavı, yan dal uzmanlığı ve poliklinik pratiğinde anında uygulanabilir kanıtlar sunar.",
                    "Diyabetik retinopatide erken tanı, doğru ilaç seçimi ve zamanında cerrahi görme kaybını %95 önler.",
                    "Tıbbi bilgi sürekli güncellenmektedir; kanıta dayalı oftalmoloji ilkeleri yol göstericidir."
                ],
                "footer": "Akademik Çalışma Ortağı — 2026"
            }
        ],
        notes="280 slaytlık Diyabetik Retinopati ve Diyabetik Makula Ödemi Kapsamlı Masterclass sunumu başarıyla tamamlanmıştır."
    )
