"""Bounded local retrieval from an explicitly selected PDF page index.

Index: [{"path": "/absolute/book.pdf", "sha256": "...", "pages": [12, 13]}].
No remote access, model calls, full archive scans, or invented excerpts.
"""
import json
import re
from pathlib import Path
from bookgraph.safety import file_hash
from slide_supervisor_schema import SourcePassage


class LocalSlideEvidence:
    def __init__(self, index_path, max_pages=8):
        self.index_path = Path(index_path)
        self.max_pages = max_pages

    def __call__(self, spec, decision):
        import fitz
        records = json.loads(self.index_path.read_text(encoding='utf-8'))
        excluded = {s.source_id for s in spec.sources}
        query = spec.topic_id + ' ' + spec.title
        if decision and decision.search_request:
            query += ' ' + decision.search_request.disease + ' ' + ' '.join(decision.search_request.required_findings)
        terms = set(re.findall(r'\w{3,}', query.casefold()))
        candidates = []
        inspected = 0
        for record in records:
            path = Path(record['path'])
            if not path.is_absolute() or file_hash(path) != record['sha256']:
                continue
            with fitz.open(path) as document:
                for page_no in record['pages']:
                    source_id = f"PDF-{record['sha256']}-p{page_no}"
                    if source_id in excluded or not 1 <= page_no <= len(document):
                        continue
                    if inspected >= self.max_pages:
                        break
                    inspected += 1
                    text = document[page_no - 1].get_text()
                    score = len(terms & set(re.findall(r'\w{3,}', text.casefold())))
                    if score and text.strip():
                        candidates.append((score, SourcePassage(source_id=source_id,
                            citation_ref=f'{path.name}, PDF p.{page_no}', text=text,
                            page_num=page_no, source_path=str(path), document_sha256=record['sha256'])))
            if inspected >= self.max_pages:
                break
        return [source for _, source in sorted(candidates, key=lambda pair: pair[0], reverse=True)[:3]]
