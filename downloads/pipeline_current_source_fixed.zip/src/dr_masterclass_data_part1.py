"""
dr_masterclass_data_part1.py — Bölüm 1 - 4 (Slayt 1 - 86)
Epidemiyoloji, Moleküler Patogenez, Multimodal Görüntüleme, Sınıflandırma ve DMÖ Protokol V.
Kişisel Çalışma Atlası: 55+ Doğrulanmış Görsel, Dual-Comparison Paneller ve Derin Didaktik Notlar.
"""

from pathlib import Path

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
ASSETS_DIR = BASE_DIR / "assets"
IMG_CATALOG_DIR = ASSETS_DIR / "visual_catalog" / "images"
ATLAS_OCT_DIR = IMG_CATALOG_DIR / "Atlas_of_Retinal_OCT"
BCSC_12_DIR = IMG_CATALOG_DIR / "12-Retina_and_Vitreous_2025-2026"
RYAN_3_DIR = IMG_CATALOG_DIR / "RYAN_S_RETINA_7th_Ed__Vol_3"
WILLS_RETINA_DIR = IMG_CATALOG_DIR / "Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3_"


def build_part1_slides(pub):
    """Bölüm 1'den 4'e kadar olan 86 slaytı yüksek görsel yoğunlukla oluşturur."""

    # ========================================================
    # KAPAK VE MÜFREDAT SLAYTLARI (S1 - S2)
    # ========================================================
    pub.add_cover_slide(
        metadata_rows=[
            ("Akademik Kapsam", "AAO BCSC Section 12 (2025-2026), Ryan's Retina (7th Ed), Atlas of Retinal OCT, Wills Eye"),
            ("RKÇ Kanıt Tabanı", "DRCR.net Protokolleri (A-AC), YOSEMITE/RHINE, PHOTON, LENS, SUSTAIN-6, DCCT, UKPDS"),
            ("Görsel Veritabanı", "28.389 Adet Yüksek Çözünürlüklü Görsel Arşivinden Derlenmiş Split-Screen Atlası"),
            ("Kullanım Amacı", "Kişisel İleri Düzey Çalışma Atlası, Retina Fellowluğu ve Board Sınav Hazırlığı"),
            ("Slayt & Mimari", "16:9 Geniş Ekran · 12 Kapsamlı Bölüm · 280 Ayrıntılı Didaktik Çalışma Slaytı"),
            ("Mevzuat & İstatistik", "Sağlık Bakanlığı Teletıp, SGK SUT Geri Ödeme Mevzuatı, GEE ve Mixed-Effects Analizi")
        ],
        notes="Diyabetik Retinopati ve Makula Ödemi İleri Düzey Çalışma Atlası.\n280 slaytlık tam masterclass çalışma seti."
    )

    pub.add_lecture_card_slide(
        title="Diyabetik Retinopati Çalışma Atlası: 12 Bölümlük Müfredat",
        category="GENEL BAKIŞ VE MÜFREDAT",
        subtitle="Moleküler biyolojiden vitreoretinal cerrahiye, yapay zekadan biyoistatistiğe tam kapsamlı eğitim seti.",
        cards=[
            {
                "card_title": "MODÜL I: TEMEL BİLİM & TANI",
                "lead": "Patogenezden Görüntülemeye (S1-S86)",
                "items": [
                    "Bölüm 1: Epidemiyoloji & 4 Biyokimyasal Kaskad (12 Görsel)",
                    "Bölüm 2: Multimodal Görüntüleme & AI Triyajı (16 Görsel)",
                    "Bölüm 3: ICDR & ETDRS 4-2-1 Klinik Evreleme (15 Görsel)",
                    "Bölüm 4: DMÖ Sınıflaması & Protokol V (15 Görsel)"
                ],
                "footer": "Temel Mekanizmalar & Tanı"
            },
            {
                "card_title": "MODÜL II: FARMAKOTERAPİ",
                "lead": "Moleküler Tedaviler (S87-S162)",
                "items": [
                    "Bölüm 5: Anti-VEGF & Protokol T, I, S, W",
                    "Bölüm 6: Faricimab, Aflibercept 8mg & PDS",
                    "Bölüm 7: Steroid İmplantlar & Lazerler"
                ],
                "footer": "Farmakoterapi & Protokoller"
            },
            {
                "card_title": "MODÜL III: CERRAHİ & SİSTEMİK",
                "lead": "İleri Evre & Klinik Entegrasyon (S163-S225)",
                "items": [
                    "Bölüm 8: PDR & 25G/27G PPV Cerrahisi",
                    "Bölüm 9: Fenofibrat (LENS), GLP-1 & Gebelik",
                    "Bölüm 10: ASM Triyajı, SGK SUT & GEE İstatistiği"
                ],
                "footer": "Cerrahi & Sistemik Boyut"
            },
            {
                "card_title": "MODÜL IV: BÜYÜK ATLAS & SINAV",
                "lead": "Görsel Arşiv & Vaka Çözümleri (S226-S280)",
                "items": [
                    "Bölüm 11: 40 Görselden Oluşan Büyük Atlas Paneli",
                    "Bölüm 12: 7 Derin Vaka ve Gerekçeli Çözümler",
                    "Kapanış: Özet Klinik Karar Algoritmaları"
                ],
                "footer": "Görsel Hafıza & Pekiştirme"
            }
        ],
        notes="280 slaytlık masterclass sunumu 4 ana modül ve 12 alt bölümden oluşur. Modül I, 55'ten fazla yüksek çözünürlüklü görselle donatılmıştır."
    )

    # ========================================================
    # BÖLÜM 1: EPİDEMİYOLOJİ VE MOLEKÜLER PATOGENEZ (S3 - S20)
    # ========================================================
    pub.add_section_header_slide(
        part_num=1,
        title="Epidemiyoloji, Tanımlar ve Moleküler Patogenez",
        subtitle="Hipergliseminin mikrovasküler endotel ve nöroretina üzerindeki yıkıcı biyokimyasal kaskadı.",
        learning_objectives=[
            "Global ve Türkiye diyabet/retinopati epidemiyolojik verilerini kavramak.",
            "4 temel biyokimyasal hasar yolağını (Aldoz Redüktaz, AGE/RAGE, PKC-Beta, Heksozamin) moleküler düzeyde açıklamak.",
            "HIF-1alfa, VEGF izoformları ve Ang-1/Ang-2 Tie-2 dengesizliğinin sızıntı mekanizmasını analiz etmek.",
            "Perisit apoptozu, lökostazis ve iç kan-retina bariyeri (iBRB) yıkım adımlarını sıralamak."
        ],
        notes="Bölüm 1, diyabetik retinopatinin klinik bulgularının altında yatan moleküler mekanizmaları inceler."
    )

    pub.add_trials_kpi_slide(
        title="Global ve Türkiye Diyabetik Retinopati Epidemiyolojisi",
        category="EPİDEMİYOLOJİ VE HALK SAĞLIĞI",
        subtitle="IDF Diabetes Atlas ve Türkiye epidemiyolojik tarama verilerinin ortaya koyduğu klinik tablo.",
        metrics=[
            {
                "study": "IDF ATLAS 10. BASKI",
                "big_num": "537 Milyon",
                "label": "Global Diyabetli Yetişkin",
                "finding": "2045 yılında 783 milyona ulaşması öngörülmektedir. Hastaların yaklaşık %30-35'inde bir dereceye kadar retinopati gelişmektedir.",
                "citation": "IDF Diabetes Atlas 2021 [PMID: 34879974]"
            },
            {
                "study": "TURDEP-II ÇALIŞMASI",
                "big_num": "%13.7",
                "label": "Türkiye Erişkin Diyabet Prevelansı",
                "finding": "Türkiye'de erişkin nüfusun 7 milyondan fazlası diyabetiktir. Tanı konmuş hastaların %28-32'sinde DR saptanmaktadır.",
                "citation": "Satman et al., Eur J Epidemiol [PMID: 23378021]"
            },
            {
                "study": "GÖRME KAYBI YÜKÜ",
                "big_num": "1. Sırada",
                "label": "Çalışma Çağı Körlük Nedeni",
                "finding": "20-74 yaş grubunda önlenebilir körlüğün dünyadaki birincil nedenidir. 10 yıllık diyabette DR riski %50'yi aşar.",
                "citation": "Lancet Global Health 2021 [PMID: 33545062]"
            }
        ],
        notes="Diyabet prevalansı Türkiye'de TURDEP-I'den (%7.2) TURDEP-II'ye (%13.7) neredeyse ikiye katlanmıştır."
    )

    pub.add_lecture_card_slide(
        title="Diyabetik Retinopati Terminolojisi ve Temel Tanımlar",
        category="KLİNİK TANIMLAR",
        subtitle="Amerikan Diyabet Cemiyeti (ADA) ve AAO Preferred Practice Pattern (PPP) standartları.",
        cards=[
            {
                "card_title": "DİYABETİK RETİNOPATİ (DR)",
                "lead": "Kronik Progresif Mikrovaskülopati",
                "items": [
                    "Retina kapiller perisit kaybı ve mikrovasküler oklüzyon.",
                    "İskemiye ikincil pre-retinal patolojik neovaskülarizasyon.",
                    "Hem mikrovasküler hem de erken nörodejeneratif bir hastalık tablosudur."
                ],
                "footer": "ICDR / ETDRS Sınıflaması"
            },
            {
                "card_title": "DİYABETİK MAKULA ÖDEMİ (DMÖ)",
                "lead": "En Yaygın Görme Kaybı Nedeni",
                "items": [
                    "Kan-retina bariyeri (iBRB) bozulması sonucu intraretinal sıvı toplanması.",
                    "Hastalığın herhangi bir evresinde (hafif NPDR'den PDR'ye kadar) görülebilir.",
                    "Santral tutulumlu (CI-DME) ve tutulumsuz (NCI-DME) olarak ikiye ayrılır."
                ],
                "footer": "OCT Tabanlı Tanı"
            },
            {
                "card_title": "MİKROVASKÜLER HASAR BİLEŞENLERİ",
                "lead": "Klinik Olarak Saptanan İlk Belirtiler",
                "items": [
                    "Mikroanevrizmalar: İç nükleer tabakadaki kapiller keseleşmeler.",
                    "Sert Eksüdalar: Lipoprotein ve lipid birikintileri (sızıntı kanıtı).",
                    "Pamuk Atılmış Lekeler (CWS): Sinir lifi tabakasında aksoplazmik akış durması."
                ],
                "footer": "Biyomikroskopi Bulguları"
            }
        ],
        notes="DR tanısı oftalmoskopi ve multimodal görüntüleme ile konur."
    )

    pub.add_lecture_card_slide(
        title="Epigenetik Hafıza ve 'Metabolic Memory' (Legacy Effect)",
        category="KLİNİK BİYOLOJİ",
        subtitle="Kan şekeri düzelse bile retinopatinin neden ilerlemeye devam ettiğini açıklayan mekanizma.",
        cards=[
            {
                "card_title": "DCCT VE EDIC BULGULARI",
                "lead": "On Yıllar Süren Miras Etki",
                "items": [
                    "DCCT'de sıkı glisemik kontrol alan hastalar, çalışma bittikten 10-15 yıl sonra bile (EDIC) daha düşük DR riski gösterdi.",
                    "Başlangıçtaki kötü kontrol, sonradan HbA1c düzelse dahi mikrodamarlarda yıkım izi bırakır."
                ],
                "footer": "Erken Müdahale Zorunludur"
            },
            {
                "card_title": "DNA METİLASYONU VE HİSTON MODİFİKASYONU",
                "lead": "Kalıcı Gen Baskılanması",
                "items": [
                    "Süperoksit dismutaz 2 (SOD2) gen promotorunda kalıcı hipermetilasyon.",
                    "Histon H3 lizin-4 monometilasyonu (H3K4me1) disregülasyonu.",
                    "NF-kB bağımlı enflamatuar genlerin glukoz normale dönse de açık kalması."
                ],
                "footer": "Enflamasyonun Kapanmaması"
            },
            {
                "card_title": "MİTOKONDRİYAL DNA HASARI",
                "lead": "ROS Kısır Döngüsü",
                "items": [
                    "Mitokondriyal DNA'da (mtDNA) onarılamayan oksidatif hasar.",
                    "Elektron transport zincirinde kalıcı serbest radikal (ROS) kaçağı.",
                    "Bu nedenle geç başlayan sıkı glisemik kontrol retinopatiyi tek başına durduramaz."
                ],
                "footer": "Klinik Karar Rasyoneli"
            }
        ],
        notes="Metabolik hafıza kavramı, erken dönemde agresif HbA1c kontrolünün neden hayati olduğunu açıklar."
    )

    # S7: Şema 0 (dr_schema_0_epi_metabolic.png)
    pub.add_visual_schema_slide(
        title="Biyokimyasal Hasardan Mikrovasküler Tıkanıklığa Kaskad",
        category="PATOGENEZ ŞEMASI",
        subtitle="Hipergliseminin perisit apoptozundan neovaskülarizasyona uzanan patolojik zinciri.",
        image_path=ASSETS_DIR / "dr_schema_0_epi_metabolic.png",
        focal_points=[
            ("Perisit Apoptozu", "Perisit/endotel oranı 1:1'den 1:10'a düşer; 'perisit hayaletleri' (pericyte ghosts) oluşur."),
            ("İç Kan-Retina Bariyeri Yıkımı", "ZO-1, okludin ve klaudin-5 fosforillenerek endotel sıkı bağlantıları açılır."),
            ("Lökostazis ve Kapiller Tromboz", "Endotel yüzeyinde ICAM-1 ve CD18 artışı nötrofil yapışmasına ve kapiller tıkanıklığa yol açar."),
            ("HIF-1alfa ve VEGF Patlaması", "Oksijensiz kalan retina dokusu VEGF-A ve Ang-2 salgılayarak patolojik damarlanmayı başlatır.")
        ],
        notes="dr_schema_0_epi_metabolic.png şeması endotel bazal membranı, perisit yıkımı ve lökostazis kaskadını gösterir."
    )

    # S8: Poliyol & Aldoz Redüktaz — Görselli İnceleme (Ryan Vol 3 p.170)
    pub.add_visual_schema_slide(
        title="1. Biyokimyasal Yolak: Poliyol (Aldoz Redüktaz) Kaskadı",
        category="MOLEKÜLER PATOGENEZ",
        subtitle="Hücre içi glukoz fazlalığının sorbitole dönüşümü ve endotel osmotik hasarı.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p170_fig176.jpeg",
        focal_points=[
            ("Glukoz-Sorbitol Dönüşümü", "Hücre içine serbestçe giren glukoz Aldoz Redüktaz enzimiyle sorbitole çevrilir; sorbitol hücre membranından geçemez."),
            ("NADPH ve Glutatyon Tükenmesi", "Aldoz redüktaz NADPH tüketir; indirgenmiş glutatyon (GSH) sentezlenemez ve antioksidan savunma çöker."),
            ("Osmotik Şişme & Apoptoz", "Endotel ve perisit hücrelerinde biriken sorbitol hidropik dejenerasyona ve hücre ölümüne neden olur.")
        ],
        notes="Poliyol yolağı perisit kaybındaki en erken tetikleyicilerden biridir."
    )

    # S9: AGE / RAGE Yolağı — Görselli İnceleme (Ryan Vol 3 p.170 fig177)
    pub.add_visual_schema_slide(
        title="2. Biyokimyasal Yolak: İleri Glikasyon Son Ürünleri (AGE/RAGE)",
        category="MOLEKÜLER PATOGENEZ",
        subtitle="Proteinlerin non-enzimatik glikasyonu ve Tip IV kollajen çapraz bağlanması.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p170_fig177.jpeg",
        focal_points=[
            ("Metilglioksal Oluşumu", "Glikolitik ara ürünlerden reaktif dikarbonil bileşikler üretilerek doku proteinlerine geri dönüşümsüz bağlanır."),
            ("Bazal Membran Rijiditesi", "Damar bazal membranındaki Tip IV kollajen çapraz bağlanarak kalınlaşır, lümen daralır ve esneklik kaybolur."),
            ("RAGE Reseptör Aktivasyonu", "AGE reseptörüne (RAGE) bağlanma NF-kB yolağını açarak VEGF, ICAM-1 ve pro-enflamatuar sitokin salgısını tetikler.")
        ],
        notes="AGE birikimi diyabetik damar duvarının kronik kalınlaşmasının ana sebebidir."
    )

    # S10: Şema 1 (dr_schema_1_pathogenesis.png)
    pub.add_visual_schema_slide(
        title="Moleküler Patogenez ve Hipoksi Kaskadı",
        category="PATOGENEZ DERİNLİK",
        subtitle="HIF-1alfa stabilizasyonu ve anjiyogenik sitokin salınımı kaskadı.",
        image_path=ASSETS_DIR / "dr_schema_1_pathogenesis.png",
        focal_points=[
            ("Prolil Hidroksilaz Blokajı", "Doku hipoksisi prolil hidroksilazı inaktive ederek HIF-1alfa'nın yıkımını engeller."),
            ("Nükleer Translokasyon", "HIF-1alfa HIF-1beta ile birleşerek VEGF promotor bölgesine bağlanır."),
            ("VEGF Salınımı", "VEGF-A izoformları ve PlGF üretilerek endotel mitozu ve sızıntısı başlatılır.")
        ],
        notes="HIF-1alfa kaskadı retinal anjiyogenezin ana tetikleyicisidir."
    )

    # S11: PKC-Beta Aktivasyonu — Görselli İnceleme (Atlas of Retinal OCT p.98)
    pub.add_visual_schema_slide(
        title="3. Biyokimyasal Yolak: Protein Kinaz C (PKC-Beta) Aktivasyonu",
        category="MOLEKÜLER PATOGENEZ",
        subtitle="Diasilgliserol (DAG) aracılı endotel sıkı bağlantı (tight junction) çözülmesi.",
        image_path="Atlas_of_Retinal_OCT_p098_fig168.jpeg",
        focal_points=[
            ("DAG Birikimi", "Glikoliz fazlası dihidroksiaseton fosfatı DAG'a dönüştürerek PKC-Beta izoformunu aşırı aktive eder."),
            ("Tight Junction Fosforilasyonu", "ZO-1 ve okludin fosforillenerek endotel hücreleri birbirinden ayrılır; makula ödemi başlar."),
            ("Endothelin-1 Artışı", "Vazokonstriktör ET-1 artarken endotelyal eNOS baskılanır; retinal perfüzyon bozulur.")
        ],
        notes="PKC-Beta inhibitörü Ruboxistaurin klinik çalışmalarda test edilmiş ancak oral yolla yeterli oküler konsantrasyona ulaşamamıştır."
    )

    # S12: Heksozamin Yolağı — Görselli İnceleme (Ryan Vol 3 p.172 fig181)
    pub.add_visual_schema_slide(
        title="4. Biyokimyasal Yolak: Heksozamin Yolağı ve Gen Ekspresyonu",
        category="MOLEKÜLER PATOGENEZ",
        subtitle="Glukozamin-6-fosfat üzerinden transkripsiyon faktörlerinin O-glikozilasyonu.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p172_fig181.jpeg",
        focal_points=[
            ("Fruktoz-6-P Şantı", "Glukoz fazlası heksozamin yolağına yönelerek UDP-N-asetilglukozamin (UDP-GlcNAc) sentezini artırır."),
            ("Sp1 Transkripsiyon Faktörü", "Sp1 proteininin nükleer O-GlcNAkilasyonu patolojik PAI-1 ve TGF-beta genlerini kalıcı olarak açar."),
            ("Mikrovasküler Tromboz", "Plazminojen Aktivatör İnhibitörü-1 (PAI-1) artışı intravasküler fibrin çözünmesini engelleyerek fokal oklüzyona yol açar.")
        ],
        notes="Heksozamin yolağı diyabetteki mikrovasküler tıkanıklıkların trombotik zeminini hazırlar."
    )

    # S13: VEGF Ailesi ve İzoformları — Görselli İnceleme (Ryan Vol 3 p.172 fig182)
    pub.add_visual_schema_slide(
        title="VEGF Ailesi ve İzoformlarının Moleküler Biyolojisi",
        category="MOLEKÜLER HEDEFLER",
        subtitle="VEGF-A, VEGF-B, PlGF ve reseptör etkileşimlerinin patolojik anjiyogenezdeki rolleri.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p172_fig182.jpeg",
        focal_points=[
            ("VEGF165 İzoformu", "En bol bulunan ve anjiyogenez/geçirgenlikten birincil sorumlu patolojik izoformdur."),
            ("VEGF121 İzoformu", "Çözünür izoformdur, heparine bağlanmaz ve diffüz retina sızıntısına neden olur."),
            ("VEGFR-1 ve VEGFR-2", "VEGFR-2 güçlü mitoz ve geçirgenliği yürütür; VEGFR-1 ise PlGF bağlanmasıyla inflamasyonu tetikler.")
        ],
        notes="Aflibercept hem VEGFR-1 hem VEGFR-2 reseptör parçalarını içerdiği için PlGF'yi de bloke eder."
    )

    # S14: Angiopoietin Dengesi: Ang-1 vs Ang-2 — Görselli İnceleme (dr_panel_dme_ci_nci_prp.png)
    pub.add_visual_schema_slide(
        title="Angiopoietin Dengesi: Ang-1 (Stabilite) vs Ang-2 (Sızıntı)",
        category="İKİLİ YOLAK BİYOLOJİSİ",
        subtitle="Tie-2 reseptörü üzerinden yürütülen vasküler bütünlük savaşı ve Faricimab'ın etki temeli.",
        image_path=ASSETS_DIR / "dr_panel_dme_ci_nci_prp.png",
        focal_points=[
            ("Ang-1 / Tie-2 Aktivasyonu", "Fizyolojik Tie-2 fosforilasyonu perisitlerin endotel tüpüne sıkıca tutunmasını sağlar."),
            ("Ang-2 / Tie-2 İnhibisyonu", "Diyabette hipoksiyle artan Ang-2, Tie-2'nin doğal kompetitif antagonistidir; perisitleri damardan ayırır."),
            ("İkili İnhibisyon (Faricimab)", "Hem VEGF-A hem Ang-2'yi bloke ederek damar sızdırmazlığını kalıcı restore eder.")
        ],
        notes="YOSEMITE ve RHINE çalışmalarının arkasındaki moleküler rasyonel tam olarak bu Ang-1/Ang-2 dengesizliğinin düzeltilmesidir."
    )

    # S15: Panel 0 (dr_panel_dme_brb_oct.png)
    pub.add_visual_schema_slide(
        title="Kan-Retina Bariyeri (BRB) Yıkımı ve Hücreler Arası Kavşaklar",
        category="BARİYER BİYOLOJİSİ",
        subtitle="Endotel sıkı bağlantılarının (tight junction) moleküler anatomisi ve perisit kaybı.",
        image_path=ASSETS_DIR / "dr_panel_dme_brb_oct.png",
        focal_points=[
            ("İç Kan-Retina Bariyeri (iBRB)", "Retina kapiller endoteli, perisitler ve Müller hücre ayakçıklarından oluşan nörovasküler ünite."),
            ("ZO-1 ve Okludin Yıkımı", "VEGF salınımıyla aktive olan kinazlar sıkı bağlantı proteinlerini parçalar; serbest sıvı kaçar."),
            ("Dış Kan-Retina Bariyeri (oBRB)", "RPE hücreleri arasındaki zonula okkludens bağlantıları; ileri evrede kistik dekolmana zemin hazırlar.")
        ],
        notes="dr_panel_dme_brb_oct.png paneli tight junction çözülmesini ve perisit soyulmasını şematize eder."
    )

    # S16: Perisit Apoptozu ve Perisit Hayaletleri — Trypsin Digest (Ryan Vol 3 p.171 fig178)
    pub.add_visual_schema_slide(
        title="Perisit Apoptozu ve 'Perisit Hayaletleri' (Pericyte Ghosts)",
        category="HİSTOPATOLOJİ",
        subtitle="Retina damar preparatında (Trypsin Digest) perisit kaybının patognomonik görünümü.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p171_fig178.jpeg",
        focal_points=[
            ("Perisit/Endotel Oranı", "Sağlıklı retinada 1:1 olan perisit/endotel oranı diyabette dramatik biçimde 1:10'a düşer."),
            ("Perisit Hayaletleri", "Ölen perisitin bazal membran cebinde bıraktığı boşluk histopatolojide 'pericyte ghost' olarak adlandırılır."),
            ("Duvar Desteğinin Çökmesi", "Perisitsiz kalan endotel tüpü hemodinamik basınca dayanamayarak dışa doğru balonlaşır (mikroanevrizma).")
        ],
        notes="Perisit kaybı diyabetik retinopatinin mikroskobik düzeydeki en erken ve geri dönüşümsüz bulgusudur."
    )

    # S17: Lökostazis ve Endotel Hasarı — Histoloji (Ryan Vol 3 p.171 fig179)
    pub.add_visual_schema_slide(
        title="Lökostazis: Nötrofillerin Kapillere Yapışması ve Oklüzyon",
        category="HİSTOPATOLOJİ",
        subtitle="Endotel yüzeyinde ICAM-1 ve CD18 integrin artışı sonucu kapiller tıkanıklık.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p171_fig179.jpeg",
        focal_points=[
            ("Lökosit Rijiditesi", "Hiperglisemi nötrofillerin deformabilite yeteneğini azaltır; lökositler kapiller lümene sıkışır."),
            ("ICAM-1 ve VCAM-1", "İnflamatuar sitokinlerle endotel yüzeyinde artan yapışma molekülleri lökostazisi kalıcı hale getirir."),
            ("Fokal Kapiller Tromboz", "Lökosit yapışması endotel ölümünü tetikler ve arkasında trombüsle tıkanmış bir damar bırakır.")
        ],
        notes="Lökostazis, retinada 'pamuk atılmış leke' ve kapiller perfüzyon kaybının hücresel nedenidir."
    )

    # S18: Aselüler Kapillerler ve Mikroanevrizmalar — Trypsin Digest (Ryan Vol 3 p.171 fig180)
    pub.add_visual_schema_slide(
        title="Aselüler Kapillerler ve Mikroanevrizma Oluşumu",
        category="HİSTOPATOLOJİ",
        subtitle="Ne perisit ne endotel hücresi kalan hayalet damarlar ve keseleşmeler.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p171_fig180.jpeg",
        focal_points=[
            ("Aselüler Kapiller (Acellular Strands)", "Tromboz sonrası tüm hücrelerini kaybeden damarlar lümensiz kollajen kordonlara dönüşür."),
            ("FFA'da Kapiller Drop-Out", "Bu aselüler alanlar floresein anjiyografide perfüze olmayan karanlık sahalar (kapiller drop-out) olarak izlenir."),
            ("Mikroanevrizma Tipleri", "Sakküler (kese şeklinde) veya fuziform; lümenlerinde endotel proliferasyonu ve trombosit kümeleri bulunur.")
        ],
        notes="Kapiller drop-out alanlarının genişliği retina iskemisinin ve VEGF salınımının doğrudan belirleyicisidir."
    )

    # S19: Erken Retinal Nörodejenerasyon — SD-OCT (Atlas of Retinal OCT p.99 fig170)
    pub.add_visual_schema_slide(
        title="Retinal Nörodejenerasyon: Damar Bozulmadan Önce Nöron Kaybı",
        category="ERKEN PATOLOJİ",
        subtitle="Retina ganglion hücre tabakası (GCL) incelmesi ve Müller glial aktivasyon.",
        image_path="Atlas_of_Retinal_OCT_p099_fig170.jpeg",
        focal_points=[
            ("RGC Apoptozu", "Mikroanevrizma görülmeden önce retina ganglion hücrelerinde kaspaz-3 bağımlı programlı ölüm başlar."),
            ("GCL ve IPL İncelmesi", "SD-OCT segmentasyon analizinde fovea çevresi nöronal katman kalınlığında kayıp saptanır."),
            ("Klinik Fonksiyon Kaybı", "Hastada görme keskinliği 1.0 (20/20) olsa dahi erken kontrast duyarlılık ve renk görme kusurları belirir.")
        ],
        notes="Diyabetik retinopati modern konsensüste bir mikrovaskülopati olduğu kadar erken bir nörodejeneratif hastalıktır."
    )

    pub.add_lecture_card_slide(
        title="Bölüm 1 Özeti: Moleküler Patogenezden Kliniğe Çıkarımlar",
        category="BÖLÜM 1 ÖZETİ",
        subtitle="Klinik karar vermede ve farmakolojik hedeflemede akılda tutulması gereken temel noktalar.",
        cards=[
            {
                "card_title": "4 YOLAĞIN ORTAK KAVŞAĞI",
                "lead": "Oksidatif Stres ve ROS",
                "items": [
                    "Poliyol, AGE, PKC ve Heksozamin yolaklarının tümü mitokondriyal süperoksit aşırı üretimine dayanır.",
                    "Endotel hasarı ve perisit apoptozu geriye döndürülemez yapısal hasar bırakır."
                ],
                "footer": "Brownlee Üniter Hipotezi"
            },
            {
                "card_title": "METABOLİK HAFIZA",
                "lead": "Geç Başlanan Tedavi Yetmez",
                "items": [
                    "Epigenetik histon modifikasyonları nedeniyle kan şekeri düzelse bile doku hasarı yıllarca sürer.",
                    "Diyabet tanısı konulduğu ilk günden itibaren sıkı glisemik kontrol esastır."
                ],
                "footer": "DCCT/EDIC Mirası"
            },
            {
                "card_title": "ANTİ-VEGF SINIRLILIKLARI",
                "lead": "Ang-2 ve İnflamasyon Faktörü",
                "items": [
                    "Tek başına VEGF blokajı Tie-2 defektini ve perisit kaybını onarmaya yetmeyebilir.",
                    "Yeni nesil çift etkili ajanlar (Faricimab) bu patogenez basamağını hedef alır."
                ],
                "footer": "Yeni Nesil Tedaviler"
            }
        ],
        notes="Bölüm 1 tamamlandı. Bölüm 2'de bu hasarların multimodal görüntüleme teknikleriyle nasıl görselleştirildiğini inceleyeceğiz."
    )

    # ========================================================
    # BÖLÜM 2: MULTİMODAL GÖRÜNTÜLEME VE BİYOBELİRTEÇLER (S21 - S42)
    # ========================================================
    pub.add_section_header_slide(
        part_num=2,
        title="Multimodal Görüntüleme, Biyobelirteçler ve Yapay Zeka",
        subtitle="UWF Optos, FFA Fazları, OCTA Pleksusları, Yapısal OCT Belirteçleri ve Birinci Basamak AI Taraması.",
        learning_objectives=[
            "Standart 7-alan ETDRS ile Ultra-Geniş Alan (UWF 200°) görüntülemenin klinik farklarını ve PPL prognostik değerini kavramak.",
            "OCTA'da yüzeyel ve derin kapiller pleksus iskemi bulgularını ve FAZ genişlemesini değerlendirmek.",
            "SD-OCT yapısal biyobelirteçlerini (DRIL, HRF, EZ bozulması, SRF) tedavi yanıtı açısından yorumlamak.",
            "Yapay zeka otonom tarama sistemlerinin (IDx-DR, EyeArt) Türkiye ASM ve Teletıp entegrasyonunu analiz etmek."
        ],
        notes="Bölüm 2, diyabetik retinopati tanısı ve takibinde kullanılan modern multimodal görüntüleme protokollerini ele alır."
    )

    pub.add_lecture_card_slide(
        title="Diyabetik Retinopatide Multimodal Görüntüleme Stratejisi",
        category="TANI VE PROTOKOL",
        subtitle="Tek bir modalite ile yetinmeyip fonksiyonel ve yapısal görüntüleri entegre etme prensibi.",
        cards=[
            {
                "card_title": "RENKLİ FUNDUS & UWF",
                "lead": "Makro-Vasküler Evreleme",
                "items": [
                    "Klinik evreleme (ETDRS) ve lezyon sayımı (kanama, eksüda, CWS).",
                    "Periferik vasküler anomalilerin ve neovaskülarizasyonun taranması.",
                    "Yapay zeka algoritmalarının birincil girdi kaynağıdır."
                ],
                "footer": "Geniş Açı Genel Bakış"
            },
            {
                "card_title": "FLORESEİN ANJİYOGRAFİ (FFA)",
                "lead": "Dinamik Akış ve Bariyer Sızıntısı",
                "items": [
                    "Kapiller perfüzyon kaybı ve nonperfüzyon alanlarının kesin sınırları.",
                    "Aktif neovaskülarizasyon (profüz sızıntı) ile IRMA (sızıntısız) ayrımı.",
                    "İnvazivdir; rutin DMÖ takibinde yerini büyük ölçüde OCT/OCTA'ya bırakmıştır."
                ],
                "footer": "Sızıntı ve İskemi Haritası"
            },
            {
                "card_title": "SD-OCT VE OCT-A",
                "lead": "Mikro-Yapısal ve Katmansal Çözünürlük",
                "items": [
                    "DMÖ tanısı, morfolojik sınıflaması ve tedavi yanıtı izleminde altın standart.",
                    "OCTA ile boyasız olarak yüzeyel ve derin kapiller ağların ayrı ayrı haritalanması.",
                    "Nöroretinal dejenerasyon biyobelirteçlerinin (DRIL, HRF) tespiti."
                ],
                "footer": "Tedavi Takibinin Omurgası"
            }
        ],
        notes="Güncel pratikte her hastaya en az renkli fundus ve SD-OCT yapılmalıdır."
    )

    # S24: 7-Alan ETDRS vs UWF Optos 200° — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Görüntüleme Alanı: Standart 7-Alan (30-50°) vs UWF (Optos 200°)",
        category="GENİŞ ALAN TEKNOLOJİSİ",
        subtitle="Geleneksel posterior pol görüntülemesi ile tüm retina periferini gören ultra-geniş açının karşılaştırması.",
        img1_path=ASSETS_DIR / "dr_panel_etdrs_421_uwfa.png",
        caption1="STANDART 7-ALAN ETDRS (%30 RETİNA ALANI)",
        img2_path="12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg",
        caption2="UWF FLORESEİN ANJİYOGRAMI (200° RETİNA ALANI)",
        focal_points=[
            ("Kapsama Alanı Farkı", "Standart 7-alan retinanın yalnızca %30-35'ini kapsarken, UWF Optos tek çekimde %82'sini (200°) belgeler."),
            ("Periferik Lezyonların Tespiti", "UWF, standart alanın dışında kalan iskemi adacıklarını ve periferik deniz yelpazesi neovaskülarizasyonlarını gösterir."),
            ("Klinik Evre Değişimi", "Hastaların %10-15'inde periferik lezyonlar nedeniyle retinopati evresi daha yüksek bir kategoriye revize edilir.")
        ],
        notes="UWF görüntüleme modern retina kliniklerinde standart hale gelmektedir."
    )

    # S25: Periferik Baskın Lezyonlar (PPL) — Görselli İnceleme (BCSC p.131 fig134)
    pub.add_visual_schema_slide(
        title="Periferik Baskın Lezyonlar (Predominantly Peripheral Lesions - PPL)",
        category="PROGNOSTİK BİYOBELİRTEÇ",
        subtitle="Periferik lezyon yoğunluğunun posterior pol lezyonlarından fazla olması durumu.",
        image_path="12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg",
        focal_points=[
            ("PPL Tanımı", "Retinal kanama, mikroanevrizma veya IRMA'ların standart 7-alan dışındaki periferik sahada daha yoğun bulunmasıdır."),
            ("İskemi İndeksi (Ischemic Index)", "UWF-FA üzerinde perfüze olmayan alanların toplam retina alanına oranı hesaplanır; yüksek indeks PDR habercisidir."),
            ("Tedavi Kararı", "PPL saptanan NPDR gözlerinde takip aralığı kısaltılmalı ve lazer/anti-VEGF eşiği düşürülmelidir.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg geniş açılı floresein sızıntı alanlarını gösterir."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol AA: UWF Görüntüleme ve Progresyon Riski",
        category="RKÇ DERİN ANALİZ",
        subtitle="NPDR gözlerinde periferik lezyonların 4 yıllık PDR'ye ilerleme üzerindeki bağımsız etkisi.",
        trial_name="DRCR.net PROTOKOL AA (JAMA Ophthalmol 2020)",
        inclusion_criteria="Hafif ila Ağır NPDR tanısı alan 544 hasta (848 göz). Başlangıçta UWF ve 7-alan ETDRS çekimleri yapıldı.",
        treatment_arms=[
            {
                "name": "PPL POZİTİF GRUP (PERİFERİK BASKIN)",
                "regimen": "UWF'de periferik lezyon skoru posterior pol lezyon skorundan daha yüksek olan gözler.",
                "result": "4. Yılda PDR İlerleme Oranı: %37 (HR: 3.2, %95 GA: 2.1-4.9, p < 0.001).",
                "extra": "Santral DMÖ gelişme ve tedavi gereksinimi riski belirgin olarak yüksek saptandı."
            },
            {
                "name": "PPL NEGATİF GRUP (STANDART POL)",
                "regimen": "Lezyonları klasik olarak standart 7-alan arka kutupta kümelenen gözler.",
                "result": "4. Yılda PDR İlerleme Oranı: %11 (Stabil klinik seyir).",
                "extra": "Periferik iskemi yükü düşük olan bu grupta PDR progresyonu belirgin olarak yavaş seyretti."
            }
        ],
        primary_outcomes=[
            "4 Yıllık PDR İlerleme Oranı: PPL pozitif grupta risk 3.2 kat daha yüksek bulundu (HR: 3.2, %95 GA: 2.1-4.9, p < 0.001).",
            "DMÖ Gelişme Riski: Periferik iskemisi geniş olan gözlerde tedavi gerektiren santral DMÖ gelişme riski anlamlı derecede arttı."
        ],
        clinical_bottom_line="Başlangıçta periferik baskın lezyonu (PPL) olan gözler klinik evresi ne olursa olsun çok yakından izlenmeli veya erken koruyucu tedavi düşünülmelidir.",
        citation="Marcus et al., JAMA Ophthalmol 2020 [PMID: 32969512]",
        notes="Protokol AA, sadece fovea ve arka kutba bakmanın diyabetik gözde yetersiz kaldığını kanıtlayan kilometre taşı çalışmadır."
    )

    # S27: FFA Temel Fazları ve Dinamik Bulgular — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Floresein Anjiyografi (FFA): Erken Transit vs Geç Faz Sızıntı",
        category="ANJİYOGRAFİ DİNAMİĞİ",
        subtitle="Mikrovasküler dolum fazı ile kronik damar duvarı sızıntısının ayırıcı analizi.",
        img1_path="Atlas_of_Retinal_OCT_p099_fig169.jpeg",
        caption1="ERKEN FAZ (15-25 SN): MİKROANEVRİZMALAR & NONPERFÜZYON",
        img2_path="12-Retina_and_Vitreous_2025-2026_p131_fig134.jpeg",
        caption2="GEÇ FAZ (5-10 DK): DİFFÜZ BOYANMA & NEV SIZINTISI",
        focal_points=[
            ("Erken Faz Bulguları", "Kapiller dolum fazında mikroanevrizmalar parlak hiperfloresan noktalar olarak parlar; tıkalı damarlar siyah drop-out gösterir."),
            ("Geç Faz Bulguları", "İç kan-retina bariyeri yıkımı nedeniyle serbest floresein dokuya yayılır; sınırları belirsizleşen diffüz hiperfloresans oluşur."),
            ("Pencere Defekti (Window Defect)", "RPE atrofisine bağlı erken parlayıp geç fazda yoğunluğu azalan hiperfloresanstır; sızıntı ile karıştırılmamalıdır.")
        ],
        notes="FFA'da floresans tipleri: Hiperfloresans (sızıntı, boyanma, göllenme, pencere defekti) ve Hipofloresans (blokaj, perfüzyon kaybı)."
    )

    # S28: Şema 2 (dr_schema_2_oct_octa.png)
    pub.add_visual_schema_slide(
        title="SD-OCT ve OCTA Katman Analizi Mimarisi",
        category="OCT ŞEMASI",
        subtitle="Retina tabakalarının segmentasyonu ve mikrovasküler pleksusların derinlik haritası.",
        image_path=ASSETS_DIR / "dr_schema_2_oct_octa.png",
        focal_points=[
            ("Yüzeyel Kapiller Pleksus (SCP)", "Sinir lifi ve ganglion hücre tabakasında yer alır; büyük arter ve venlerle doğrudan bağlantılıdır."),
            ("Derin Kapiller Pleksus (DCP)", "İç nükleer ve dış pleksiform tabaka arasında bulunur; diyabette ilk etkilenen ve mikrokistlerin oturduğu alandır."),
            ("Koroideokapillaris", "Bruch membranı altındaki besleyici kapiller yatak; ileri diyabette subklinik koryokapiller perfüzyon kaybı gösterir.")
        ],
        notes="dr_schema_2_oct_octa.png şeması SCP, DCP ve avasküler zon sınırlarını gösterir."
    )

    # S30: OCTA Yüzeyel Pleksus (SCP) vs Derin Pleksus (DCP) — Dual Comparison
    pub.add_dual_comparison_slide(
        title="OCTA Pleksus Analizi: Yüzeyel (SCP) vs Derin (DCP) Kapiller Ağ",
        category="OCT-A DERİNLİK",
        subtitle="Boyasız eritrosit hareketiyle elde edilen pleksuslarda iskemi ve drop-out karşılaştırması.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p124_fig127.png",
        caption1="YÜZEYEL KAPİLLER PLEKSUS (SCP) — RADYAL DÜZEN",
        img2_path="12-Retina_and_Vitreous_2025-2026_p124_fig128.png",
        caption2="DERİN KAPİLLER PLEKSUS (DCP) — GİRDAP GÖRÜNÜMÜ & DROP-OUT",
        focal_points=[
            ("Anatomik Mimarisi", "SCP arteriol ve venüllerin devamı olan lineer damarlardır; DCP ise kapiller sonlanmaların oluşturduğu lobüler ağdır."),
            ("Diyabette Erken Tutulum", "İskemi ve perisit kaybı ilk olarak derin pleksusta (DCP) başlar; mikroanevrizmaların çoğu bu seviyede kümelenir."),
            ("Kistoid Boşlukların Basısı", "İntraretinal kistoid ödem derin pleksus damarlarını mekanik olarak gerer ve kapatır.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p124_fig127.png ve fig128.png SCP ve DCP'deki kapiller seyrelmeyi belgeler."
    )

    # S31: Foveal Avasküler Zon (FAZ) Büyümesi — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Foveal Avasküler Zon (FAZ) Büyümesi ve Maküler İskemi",
        category="OCT-A BİYOBELİRTEÇ",
        subtitle="Normal foveal kapiller halka ile diyabetteki düzensiz, parçalanmış ve genişlemiş FAZ.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p124_fig129.png",
        caption1="NORMAL DÜZGÜN KONTURLU FAZ HALKASI (<0.3 mm²)",
        img2_path="12-Retina_and_Vitreous_2025-2026_p124_fig130.png",
        caption2="İSKEMİK GENİŞLEMİŞ VE PARÇALANMIŞ FAZ (>0.5 mm²)",
        focal_points=[
            ("Kantitatif Ölçüm", "Normal FAZ alanı 0.25-0.35 mm² arasındadır; diyabetik retinopatide 0.50 mm² üzerine çıkması iskemiyi gösterir."),
            ("Halka Bütünlüğü (Acircularity Index)", "FAZ sınırındaki kapiller lupların kopması dairesellik indeksini bozar; görme keskinliği ile negatif koreledir."),
            ("Tedavi Yanıtına Etkisi", "FAZ'ı ileri derecede parçalanmış hastalarda anti-VEGF tedavisiyle ödem kurusa dahi görme keskinliği artmayabilir.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p124_fig129.png ve fig130.png FAZ konturunun kaybını ortaya koyar."
    )

    pub.add_lecture_card_slide(
        title="Maküler İskemi Sınıflaması ve Prognostik Önemi",
        category="KLİNİK EVRELEME",
        subtitle="Foveal kapiller kaybın görme keskinliği ve tedavi potansiyeli üzerindeki belirleyiciliği.",
        cards=[
            {
                "card_title": "HAFİF MAKÜLER İSKEMİ",
                "lead": "Sınırlı Foveal Düzensizlik",
                "items": [
                    "FAZ konturunda fokal çentiklenme.",
                    "Kapiller drop-out fovea merkezinden uzakta.",
                    "Görme keskinliği genellikle tam veya 0.8 üzerindedir."
                ],
                "footer": "İyi Görme Prognozu"
            },
            {
                "card_title": "ORTA MAKÜLER İSKEMİ",
                "lead": "Belirgin Halka Parçalanması",
                "items": [
                    "FAZ çapında 1/2 fovea alanını aşan genişleme.",
                    "Derin pleksusta geniş kapiller kayıp alanları.",
                    "Anti-VEGF yanıtında görme artışı sınırlı kalabilir."
                ],
                "footer": "Kısmi Tedavi Yanıtı"
            },
            {
                "card_title": "AĞIR MAKÜLER İSKEMİ",
                "lead": "Foveal Damar Yatağının Tam Çöküşü",
                "items": [
                    "Makula merkezinde neredeyse hiç kapiller ağ kalmaması.",
                    "Retina iç tabakalarında atrofi ve DRIL gelişimi.",
                    "Ödem boşaltılsa bile fotoreseptörlere oksijen ulaşamaz; körlük riski yüksektir."
                ],
                "footer": "Kalıcı Görme Kaybı"
            }
        ],
        notes="Maküler iskemi varlığında hastaya tedavi öncesi gerçekçi görme beklentisi anlatılmalıdır."
    )

    # S33: SD-OCT Yapısal Biyobelirteçleri Genel Bakış (dr_panel_oct_dril_vmt.png)
    pub.add_visual_schema_slide(
        title="SD-OCT Yapısal Biyobelirteçleri Genel Paneli",
        category="OCT BİYOBELİRTEÇLER",
        subtitle="Görme keskinliğini ve tedavi yanıtını öngören mikromorfometrik retina belirteçleri.",
        image_path=ASSETS_DIR / "dr_panel_oct_dril_vmt.png",
        focal_points=[
            ("DRIL (Disorganization of Inner Layers)", "İç retina tabaka sınırlarının seçilememesi; kalıcı görsel fonksiyon kaybının 1 numaralı göstergesidir."),
            ("HRF (Hyperreflective Foci)", "Retina katmanlarında dağılmış lipid yüklü ameboid mikroglialar; inflamasyon belirtecidir."),
            ("EZ ve ELM Bütünlüğü", "Fotoreseptör iç/dış segment kavşağının sağlamlığı; nihai görme keskinliğinin tavanını belirler."),
            ("VMT ve Traksiyon", "Vitreomaküler traksiyon ve epiretinal membran; medikal tedaviye direnç ve cerrahi endikasyon nedenidir.")
        ],
        notes="dr_panel_oct_dril_vmt.png paneli SD-OCT'deki en kritik 4 yapısal belirteci gösterir."
    )

    # S34: Biyobelirteç 1: DRIL — Görselli İnceleme (Atlas of Retinal OCT p.102 fig174)
    pub.add_visual_schema_slide(
        title="Biyobelirteç 1: DRIL (Disorganization of Retinal Inner Layers)",
        category="OCT BİYOBELİRTEÇ",
        subtitle="Gangliyon hücresi, IPL, INL ve OPL arasındaki sınırların ayırt edilememesi.",
        image_path="Atlas_of_Retinal_OCT_p102_fig174.jpeg",
        focal_points=[
            ("Tanı Kriteri", "Santral 1 mm foveal alanda iç retina katmanları arasındaki horizontal sınırların silinmesi (>500 mikron genişlik)."),
            ("Fonksiyonel Anlamı", "Bipolar, amakrin ve ganglion hücreleri arasındaki sinaptik bağlantıların koptuğunu kanıtlar."),
            ("Prognostik Değer", "Ödem tamamen kurutulsa bile DRIL varlığında görme keskinliği artmaz; kalıcı görme kaybını en iyi öngören belirteçtir.")
        ],
        notes="Atlas of Retinal OCT p.102 foveal DRIL kesitini net biçimde belgeler."
    )

    # S35: Biyobelirteç 2: Hiperreflektif Odaklar (HRF) — Görselli İnceleme (Atlas of Retinal OCT p.97 fig167)
    pub.add_visual_schema_slide(
        title="Biyobelirteç 2: Hiperreflektif Odaklar (HRF / Foci)",
        category="OCT BİYOBELİRTEÇ",
        subtitle="Retina tabakalarında saçılmış <30 mikron boyutlu parlak inflamatuar odaklar.",
        image_path="Atlas_of_Retinal_OCT_p097_fig167.jpeg",
        focal_points=[
            ("Hücresel Kökeni", "Durağan formdan ameboid fagositer forma geçmiş, lipid ve lipoprotein yutmuş aktive mikroglialardır."),
            ("Sert Eksüdalardan Ayrımı", "Sert eksüdalar daha büyüktür (>30 mikron), arka gölge bırakır ve kümeler oluşturur; HRF ise tekildir ve gölge bırakmaz."),
            ("Steroid Yanıtı", "HRF sayısı yüksek olan gözlerde inflamatuar bileşen baskındır; Deksametazon implantına (Ozurdex) anti-VEGF'ten daha iyi yanıt verir.")
        ],
        notes="HRF sayısı intraoküler IL-6 ve TNF-alfa seviyeleriyle doğrudan koreledir."
    )

    # S36: Biyobelirteç 3: Elipsoid Zon (EZ) ve ELM Bütünlüğü — Görselli İnceleme (Atlas of Retinal OCT p.98 fig168)
    pub.add_visual_schema_slide(
        title="Biyobelirteç 3: Elipsoid Zon (EZ) ve ELM Bütünlüğü",
        category="OCT BİYOBELİRTEÇ",
        subtitle="Fotoreseptör iç/dış segment bileşkesinin anatomik sağlamlığı ve görme tavanı.",
        image_path="Atlas_of_Retinal_OCT_p098_fig168.jpeg",
        focal_points=[
            ("Elipsoid Zon (IS/OS)", "Fotoreseptör mitokondrilerinden zengin hiperreflektif bant; foveada kesintiye uğraması fotoreseptör ölümünü gösterir."),
            ("Dış Limitan Membran (ELM)", "Müller hücreleri ile fotoreseptörler arasındaki kavşak; ELM sağlamsa tedavi sonrası EZ kendini kısmen onarabilir."),
            ("Klinik Korelasyon", "Santral retina kalınlığı ne olursa olsun, foveal EZ'si intakt olan hastaların nihai görme potansiyeli çok daha yüksektir.")
        ],
        notes="EZ haritası, hastanın tedavi sonrasında ne kadar görme kazanabileceğini belirleyen anatomik tavandır."
    )

    # S37: Biyobelirteç 4: Subretinal Sıvı (SRF / Seröz Dekolman) — Görselli İnceleme (Atlas of Retinal OCT p.95 fig162)
    pub.add_visual_schema_slide(
        title="Biyobelirteç 4: Subretinal Sıvı (SRF / Seröz Retina Dekolmanı)",
        category="OCT BİYOBELİRTEÇ",
        subtitle="Nörosensoryal retinanın RPE üzerinden kubbe şeklinde ayrılması ve sıvı birikimi.",
        image_path="Atlas_of_Retinal_OCT_p095_fig162.jpeg",
        focal_points=[
            ("Oluşum Mekanizması", "Dış kan-retina bariyerinin (RPE) aşırı yüklenmesi ve RPE pompa fonksiyonunun intraretinal sıvıyı drene edememesi."),
            ("İnflamatuar İpucu", "SRF varlığı yoğun inflamatuar sitokin yükünü düşündürür; steroid tedavisine dramatik hızda yanıt verir."),
            ("Tedavi Prognozu", "Erken boşaltıldığında fotoreseptör hasarı bırakmaz; ancak kronikleşirse dış segmentlerde kalıcı atrofi gelişir.")
        ],
        notes="Atlas of Retinal OCT p.95 kubbe şeklindeki seröz foveal dekolmanı belgeler."
    )

    # S38: Fundus Otoflöresans (FAF) — Görselli İnceleme (Ryan Vol 3 p.185 fig185)
    pub.add_visual_schema_slide(
        title="Fundus Otoflöresans (FAF) ve RPE Metabolizma Analizi",
        category="METABOLİK GÖRÜNTÜLEME",
        subtitle="RPE lipofusin birikimi, foveal luteal pigment ve lazer skar atrofisinin FAF görünümü.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p185_fig185.jpeg",
        focal_points=[
            ("Normal FAF Deseni", "Optik disk ve retinal damarlar hipootofloresandır; foveada luteal pigment (lutein/zeaksantin) mavi ışığı emerek fizyolojik kararma yapar."),
            ("Hiperotofloresans", "Kronik kistoid ödemde kist çatısı altındaki RPE'de lipofusin birikimi veya foveal pigmentin yer değiştirmesi parlama oluşturur."),
            ("Hipootofloresans", "Eski PRP lazer skarları ve RPE atrofisi sahaları tam hipootofloresan siyah adacıklar olarak izlenir.")
        ],
        notes="FAF, PRP skarlarının genişlemesini (laser scar creep) ve RPE toksisitesini izlemede non-invaziv ideal araçtır."
    )

    pub.add_lecture_card_slide(
        title="Biyomikroskopi ve Muayene Lenslerinin Seçimi",
        category="KLİNİK MUAYENE",
        subtitle="Yarık lamba fundus muayenesinde doğru büyütme ve alan derinliği stratejisi.",
        cards=[
            {
                "card_title": "YÜKSEK BÜYÜTME (60D / 66D)",
                "lead": "Fovea ve İnce Detay İncelemesi",
                "items": [
                    "Büyütme oranı 1.15x - 1.0x (neredeyse 1:1 gerçek görüntü).",
                    "Foveal mikroanevrizmalar, sert eksüda halkaları ve kistoid kaviteler için ideal.",
                    "Görüş alanı daha dardır (60-70°)."
                ],
                "footer": "Makula Detay Analizi"
            },
            {
                "card_title": "STANDART MUAYENE (78D / 90D)",
                "lead": "Rutin Tarama ve Genel Bakış",
                "items": [
                    "90D lens: Büyütme 0.76x, görüş alanı 74-89°.",
                    "Küçük pupillalarda bile posterior polü rahatça tarama imkanı.",
                    "Genel poliklinik taramasında birinci tercih."
                ],
                "footer": "En Yaygın Poliklinik Lensi"
            },
            {
                "card_title": "GENİŞ AÇILI LENS (SUPERFIELD / QUADRASPHERIC)",
                "lead": "Perifer ve Neovaskülarizasyon",
                "items": [
                    "Görüş alanı 120-130°'ye kadar çıkar.",
                    "Periferik deniz yelpazesi (NVE) ve ekvatoryal iskemiyi yakalamada üstün.",
                    "PRP lazer uygulamalarında ve periferik taramada kullanılır."
                ],
                "footer": "Periferik Retina Taraması"
            }
        ],
        notes="Biyomikroskopi ile klinik muayene, yapay zeka taramalarının doğrulama basamağıdır."
    )

    # S40: Yapay Zeka (AI) Otonom Tarama — Şematik Panel
    pub.add_visual_schema_slide(
        title="Yapay Zeka (AI) Otonom Tarama Sistemleri (IDx-DR, EyeArt)",
        category="DİJİTAL SAĞLIK & AI",
        subtitle="FDA onaylı derin öğrenme algoritmalarının fundus görüntüsünden otonom evreleme mekanizması.",
        image_path=ASSETS_DIR / "dr_schema_0_epi_metabolic.png",
        focal_points=[
            ("IDx-DR Onayı (2018)", "Göz hekimi olmadan 'referable DR' (orta NPDR veya DMÖ) kararı verebilen ilk otonom FDA onaylı AI cihazı."),
            ("Duyarlılık ve Özgüllük", "Büyük çok merkezli çalışmalarda duyarlılık >%87-92, özgüllük >%89-94 olarak doğrulanmıştır."),
            ("Lezyon Segmentasyonu", "Derin evrişimli sinir ağları (CNN); mikroanevrizma, kanama ve eksüdaları piksel düzeyinde haritalandırır.")
        ],
        notes="Yapay zeka sistemleri ikinci basamak retina kliniklerinin hasta yükünü hafifletmede kritik rol oynar."
    )

    pub.add_lecture_card_slide(
        title="Türkiye Sağlık Sistemi: ASM ve Teletıp Entegrasyonu",
        category="SAĞLIK SİSTEMİ ENTEGRASYONU",
        subtitle="Aile Sağlığı Merkezleri (ASM) birinci basamak taramasından üçüncü basamak sevk zincirine yerel gerçekler.",
        cards=[
            {
                "card_title": "BİRİNCİ BASAMAK ASM TRİYAJI",
                "lead": "Milyonlarca Hastanın Taranması",
                "items": [
                    "Türkiye'de 7 milyonu aşkın diyabetik bireyin yıllık göz muayenesine gitme oranı %30'un altındadır.",
                    "ASM'lere yerleştirilecek non-midriyatik fundus kameraları ve otonom AI taraması erken yakalamayı sağlayabilir."
                ],
                "footer": "Önlenebilir Körlük Mücadelesi"
            },
            {
                "card_title": "SAĞLIK BAKANLIĞI TELETIP SİSTEMİ",
                "lead": "Merkezi Görüntü Arşivi",
                "items": [
                    "Çekilen fundus fotoğraflarının ulusal Teletıp ağına aktarılması.",
                    "Yapay zekanın 'orta/ağır NPDR veya DMÖ şüphesi' verdiği vakaların doğrudan üçüncü basamağa randevulanması."
                ],
                "footer": "Bürokratik ve Teknik Entegrasyon"
            },
            {
                "card_title": "SGK SUT VE GERİ ÖDEME DİNAMİĞİ",
                "lead": "Gereksiz Sevk Yükünün Azaltılması",
                "items": [
                    "Hafif NPDR veya lezyonsuz gözlerin üniversite hastanelerine yığılması engellenir.",
                    "Erken evrede yakalanan hastalar sayesinde anti-VEGF ve vitrektomi gibi maliyetli cerrahilerin bütçe yükü düşer."
                ],
                "footer": "Maliyet-Etkinlik Rasyoneli"
            }
        ],
        notes="Sağlık Bakanlığı Teletıp sistemi ile entegre çalışan bir AI tarama modeli Türkiye'de diyabete bağlı körlüğü %70 oranında azaltabilir."
    )

    pub.add_lecture_card_slide(
        title="Bölüm 2 Özeti: Multimodal Tanı ve Klinik Akış Şeması",
        category="BÖLÜM 2 ÖZETİ",
        subtitle="Görüntüleme modalitelerinin klinik pratikteki rasyonel entegrasyonu.",
        cards=[
            {
                "card_title": "TARAMA VE EVRELEME",
                "lead": "Renkli Fundus + UWF",
                "items": [
                    "Geniş açılı muayene ile periferik iskemi (PPL) kaçırılmamalıdır.",
                    "AI tarama algoritmaları birinci basamak için vazgeçilmez bir triyaj aracıdır."
                ],
                "footer": "Makro Harita"
            },
            {
                "card_title": "DMÖ VE TAKİP",
                "lead": "SD-OCT Altın Standart",
                "items": [
                    "Tedavi kararı ve enjeksiyon yanıtı OCT ile izlenir.",
                    "DRIL, HRF ve EZ bütünlüğü görme prognozunu belirleyen ana biyobelirteçlerdir."
                ],
                "footer": "Mikro Harita"
            },
            {
                "card_title": "İSKEMİ VE CERRAHİ",
                "lead": "FFA ve OCT-A",
                "items": [
                    "Neovaskülarizasyon şüphesinde veya açıklanamayan görme kaybında FAZ/iskemi analizi yapılır.",
                    "OCTA ile boyasız olarak derin pleksus hasarı netleştirilir."
                ],
                "footer": "Fonksiyonel Harita"
            }
        ],
        notes="Bölüm 2 tamamlandı. Bölüm 3'te bu bulgular ışığında ETDRS 4-2-1 kuralını ve evreleme sistematiğini inceleyeceğiz."
    )

    # ========================================================
    # BÖLÜM 3: KLİNİK SINIFLANDIRMA VE ETDRS 4-2-1 KURALI (S43 - S62)
    # ========================================================
    pub.add_section_header_slide(
        part_num=3,
        title="Klinik Sınıflandırma: ETDRS 4-2-1 Kuralı ve ICDR",
        subtitle="Hafif NPDR'den Yüksek Riskli PDR'ye Adım Adım Evreleme, Ayırıcı Tanılar ve Klinik Karar Algoritmaları.",
        learning_objectives=[
            "ICDR Uluslararası Klinik Şiddet Skalası ile klasik ETDRS evrelemesini karşılaştırmak.",
            "ETDRS 4-2-1 kuralının 3 ana kriterini anatomik detaylarıyla tanımlamak ve prognozu kavramak.",
            "IRMA ile Neovaskülarizasyon (NVD/NVE) arasındaki morfolojik ve floresein sızıntı farklarını ayırt etmek.",
            "DRS (Diabetic Retinopathy Study) Yüksek Riskli PDR kriterlerini (3/4 kuralı) acil tedavi endikasyonu açısından analiz etmek."
        ],
        notes="Bölüm 3, diyabetik retinopatinin dünyada en kabul gören klinik sınıflama sistemlerini ve tedavi eşiklerini inceler."
    )

    pub.add_lecture_card_slide(
        title="Diyabetik Retinopati Sınıflamasının Tarihsel Evrimi",
        category="EVRELEME TARİHÇESİ",
        subtitle="Airlie House'dan ETDRS'e ve modern pratik ICDR sınıflamasına uzanan süreç.",
        cards=[
            {
                "card_title": "AIRLIE HOUSE SINIFLAMASI (1968)",
                "lead": "İlk Standart Fotoğraflar",
                "items": [
                    "Retinopati lezyonlarını ilk kez standart fotoğraflarla tanımlayan sistem.",
                    "DRS (Diabetic Retinopathy Study) çalışmasının temelini oluşturdu.",
                    "Klinik pratikte kullanımı karmaşık ve zordu."
                ],
                "footer": "Temel Çerçeve"
            },
            {
                "card_title": "ETDRS KLASİK EVRELEMESİ (1991)",
                "lead": "Bilimsel Araştırmaların Altın Standardı",
                "items": [
                    "Standart 7-alan fotoğraflarına dayalı 13 düzeyli karmaşık derecelendirme.",
                    "4-2-1 kuralını geliştirerek Ağır NPDR tanımını kesinleştirdi.",
                    "Klinik çalışmalar için mükemmel, ancak günlük poliklinik için fazla ayrıntılıydı."
                ],
                "footer": "Araştırma Standardı"
            },
            {
                "card_title": "ICDR ULUSLARARASI SKALA (2002)",
                "lead": "Günlük Klinik Pratik Standardı",
                "items": [
                    "AAO ve ICO işbirliğiyle geliştirilen 5 basamaklı basitleştirilmiş sistem.",
                    "Hafif, Orta, Ağır NPDR ve Erken / Yüksek Riskli PDR.",
                    "Dünya genelinde klinik oftalmoloji pratiğinde kullanılan standarttır."
                ],
                "footer": "Uluslararası Konsensus"
            }
        ],
        notes="ICDR sınıflaması ETDRS'in karmaşık skorlarını 5 anlaşılır basamağa indirgemiştir."
    )

    # S45: ICDR Uluslararası Klinik Sınıflama — Şematik Panel
    pub.add_visual_schema_slide(
        title="ICDR Uluslararası Klinik Sınıflandırma Skalası",
        category="KLİNİK EVRELEME",
        subtitle="5 klinik evre, fundus bulguları ve 1 yıllık PDR progresyon riskleri tablosu.",
        image_path=ASSETS_DIR / "dr_panel_stage_fa.png",
        focal_points=[
            ("Retinopati Yok (No DR)", "Göz dibinde diyabete özgü hiçbir vasküler lezyon izlenmez; yıllık rutin kontrol önerilir."),
            ("Hafif NPDR (Mild)", "Yalnızca mikroanevrizmalar mevcuttur; 1 yıllık PDR ilerleme riski <%5 civarındadır."),
            ("Orta NPDR (Moderate)", "Mikroanevrizmadan fazla ancak 'Ağır NPDR' kriterlerini doldurmayan lezyonlar (kanama, eksüda, CWS)."),
            ("Ağır NPDR (Severe - 4-2-1)", "4-2-1 kuralının en az bir kriterini karşılar; 1 yılda PDR'ye ilerleme riski %50'dir."),
            ("Proliferatif DR (PDR)", "Neovaskülarizasyon (NVD veya NVE) veya preretinal/vitreus kanaması mevcuttur; acil müdahale gerekir.")
        ],
        notes="dr_panel_stage_fa.png paneli 5 evrenin klinik eşiklerini gösterir."
    )

    # S46: Hafif NPDR: Yalnızca Mikroanevrizmalar — Wills Eye Retina (p.117 fig066)
    pub.add_visual_schema_slide(
        title="Evre 1: Hafif NPDR (Mild NPDR) — Yalnızca Mikroanevrizmalar",
        category="KLİNİK EVRELEME",
        subtitle="Klinik olarak saptanabilen en erken evre ve mikroanevrizma morfolojisi.",
        image_path="Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3__p117_fig066.jpeg",
        focal_points=[
            ("Oftalmoskopik Görünüm", "Makula ve posterior polde kırmızı keskin sınırlı küçük noktacıklar şeklinde izlenir (çap <125 mikron)."),
            ("Kapiller Keseleşme", "İç nükleer tabaka düzeyinde perisit kaybına uğramış damar duvarının dışarıya doğru balonlaşmasıdır."),
            ("Progresyon Riski", "Yılda PDR'ye ilerleme riski yaklaşık %5'tir; eşlik eden DMÖ yoksa görme keskinliği 1.0 (20/20) tamdır.")
        ],
        notes="Wills Eye Retina p.117 fig066 hafif NPDR'deki erken mikroanevrizmaları belgeler."
    )

    pub.add_lecture_card_slide(
        title="Hafif NPDR'de Takip Protokolü ve Glisemik Hedefler",
        category="KLİNİK YÖNETİM",
        subtitle="Erken evrede medikal tedavi ve metabolik parametrelerin optimizasyonu.",
        cards=[
            {
                "card_title": "KONTROL SIKLIĞI",
                "lead": "Yılda Bir Rutin Muayene",
                "items": [
                    "DMÖ yoksa yılda bir kez genişletilmiş fundus muayenesi yeterlidir.",
                    "Gebelik, kontrolsüz hipertansiyon veya nefropati varlığında takip 6 aya çekilir."
                ],
                "footer": "Yıllık Takip Yeterli"
            },
            {
                "card_title": "METABOLİK HEDEFLER (ADA)",
                "lead": "ABC Kuralı",
                "items": [
                    "A (HbA1c): Hedef <%7.0 (komorbiditesi olmayan genç erişkinde <%6.5).",
                    "B (Blood Pressure): Hedef <130/80 mmHg (ACE-İ veya ARB tercihi).",
                    "C (Cholesterol): LDL <70 mg/dL (statin tedavisi endoteli stabilize eder)."
                ],
                "footer": "Sistemik Optimizasyon"
            },
            {
                "card_title": "OKÜLER TEDAVİ GEREKSİNİMİ",
                "lead": "Göz İçi Enjeksiyon Gerekmez",
                "items": [
                    "Hafif NPDR'de lazer veya anti-VEGF tedavisi kesinlikle endike DEĞİLDİR.",
                    "Tek istisna hastada eşlik eden görmeyi tehdit eden santral makula ödemi (CI-DME) bulunmasıdır."
                ],
                "footer": "Gereksiz Tedaviden Kaçınma"
            }
        ],
        notes="Erken evrede hekimin ana görevi hastayı dahiliye/endokrinoloji ile koordineli biçimde sıkı metabolik kontrolde tutmaktır."
    )

    # S48: Orta NPDR: Retinal Kanamalar ve Eksüdalar — Wills Eye Retina (p.118 fig067)
    pub.add_visual_schema_slide(
        title="Evre 2: Orta NPDR (Moderate NPDR) — Kanamalar ve Eksüdalar",
        category="KLİNİK EVRELEME",
        subtitle="Mikroanevrizmadan fazla, ancak 4-2-1 Ağır NPDR kriterlerini doldurmayan lezyonlar.",
        image_path="Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3__p118_fig067.jpeg",
        focal_points=[
            ("Nokta-Leke Kanamaları", "Derin iç nükleer ve dış pleksiform tabakada yer alan sınırları yuvarlak, koyu kırmızı intraretinal kanamalar."),
            ("Sert Eksüda Halkaları (Circinate)", "Kronik kapiller sızıntı alanlarının çevresinde lipid ve lipoproteinlerin halka şeklinde çökmesi."),
            ("Pamuk Atılmış Lekeler (CWS)", "Retina sinir lifi tabakasındaki fokal arteriyol tıkanıklığı sonucu gelişen soluk beyaz infarkt sahaları.")
        ],
        notes="Wills Eye Retina p.118 fig067 orta NPDR'deki kanama ve sert eksüda dağılımını gösterir."
    )

    pub.add_lecture_card_slide(
        title="Orta NPDR'de Takip Protokolü ve Klinik Tuzaklar",
        category="KLİNİK YÖNETİM",
        subtitle="Lezyonların seyrini izleme ve 4-2-1 evresine geçişi yakalama stratejisi.",
        cards=[
            {
                "card_title": "TAKİP ARALIĞI",
                "lead": "6 Ayda Bir Kontrol",
                "items": [
                    "Hastalar 6 ayda bir genişletilmiş fundus muayenesi ve SD-OCT ile değerlendirilir.",
                    "DMÖ gelişimi açısından her vizitte foveal kalınlık haritası kontrol edilmelidir."
                ],
                "footer": "Yılda İki Vizit"
            },
            {
                "card_title": "KLİNİK TUZAK: PAMUK ATILMIŞ LEKELER",
                "lead": "CWS Tek Başına Ağır NPDR Yapmaz",
                "items": [
                    "Eski sınıflamalarda CWS ağır evre sayılıyordu; ancak ETDRS analizinde CWS sayısının PDR riskini bağımsız artırmadığı kanıtlandı.",
                    "ICDR sisteminde CWS varlığı tek başına 'Ağır NPDR' kriteri DEĞİLDİR; 'Orta NPDR' içinde değerlendirilir."
                ],
                "footer": "Sınav ve Klinik İncisi"
            },
            {
                "card_title": "PROGRESYON RİSKİ",
                "lead": "1 Yılda %12-27 İlerleme",
                "items": [
                    "Orta NPDR hastalarının yaklaşık %15'i bir yıl içinde Ağır NPDR veya PDR evresine ilerler.",
                    "Periferik retina taranarak lezyonların 4 kadrana yayılıp yayılmadığı dikkatle izlenmelidir."
                ],
                "footer": "Yakın İzlem Gereksinimi"
            }
        ],
        notes="CWS'nin Ağır NPDR kriteri olmaktan çıkarılması ETDRS'in en önemli sadeleştirme adımlarından biridir."
    )

    # S50: Ağır NPDR ve ETDRS 4-2-1 Kuralı Giriş (BCSC p.130 fig131)
    pub.add_visual_schema_slide(
        title="Evre 3: Ağır NPDR ve ETDRS 4-2-1 Kuralı Giriş",
        category="KRİTİK EVRE",
        subtitle="Pre-proliferatif evre: Neovaskülarizasyon başlamadan önceki son savunma hattı.",
        image_path="12-Retina_and_Vitreous_2025-2026_p130_fig131.png",
        focal_points=[
            ("4 Kriteri", "4 kadranın her birinde 20'den fazla belirgin intraretinal kanama (Standart Fotoğraf 2A standardı)."),
            ("2 Kriteri", "En az 2 kadranda belirgin venöz boğumlanma (venous beading) bulunması."),
            ("1 Kriteri", "En az 1 kadranda belirgin intraretinal mikrovasküler anormallik (IRMA / Standart Fotoğraf 8A standardı).")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p130_fig131.png 4-2-1 kuralının 4 kadran kanama standardını gösterir."
    )

    pub.add_lecture_card_slide(
        title="4-2-1 Kuralının Epidemiyolojik Risk Rasyoneli",
        category="KANIT VE RİSK",
        subtitle="ETDRS Rapor No: 9'un ortaya koyduğu 1 yıllık PDR ve yüksek riskli PDR gelişme oranları.",
        cards=[
            {
                "card_title": "TEK BİR 4-2-1 KRİTERİ (AĞIR NPDR)",
                "lead": "1 Yılda %50 PDR Riski",
                "items": [
                    "4 kriterinden (4 kadran kanama, 2 kadran venöz boğumlanma veya 1 kadran IRMA) HERHANGİ BİRİNİ dolduran göz.",
                    "1 yıl içinde Proliferatif DR'ye (PDR) ilerleme riski %50'dir.",
                    "Yüksek riskli PDR'ye ilerleme riski ise %15'tir."
                ],
                "footer": "3-4 Ayda Bir Kontrol Şarttır"
            },
            {
                "card_title": "İKİ VEYA DAHA FAZLA KRİTER (ÇOK AĞIR NPDR)",
                "lead": "1 Yılda %75 PDR Riski",
                "items": [
                    "4-2-1 kuralının 2 veya 3 kriterini birden dolduran gözler 'Very Severe NPDR' olarak tanımlanır.",
                    "1 yıl içinde PDR'ye ilerleme riski %75'e fırlar; yüksek riskli PDR riski %45'tir.",
                    "Bu gözlerde neovaskülarizasyon gelişimi neredeyse kaçınılmazdır."
                ],
                "footer": "Erken Lazer / Anti-VEGF Adayı"
            },
            {
                "card_title": "KLİNİK KARAR EŞİĞİ",
                "lead": "Proaktif Tedavi Tartışması",
                "items": [
                    "Ağır NPDR evresi, hastanın takibe uyumu kötüyse (non-compliant) veya tek gözlüyse koruyucu PRP veya anti-VEGF başlama eşiğidir.",
                    "Düzenli gelen hastada ise 3-4 ayda bir çok sıkı muayene ile neovaskülarizasyonun ilk tomurcuğu yakalanır."
                ],
                "footer": "Tedavi Zamanlaması"
            }
        ],
        notes="ETDRS Report No. 9, 4-2-1 kuralının matematiksel gücünü kanıtlayan çalışmadır."
    )

    # S52: 1. Kriter: 4 Kadranda İntraretinal Kanama — BCSC p.130 fig131
    pub.add_visual_schema_slide(
        title="4-2-1 Kuralı Kriter 1: 4 Kadranda İntraretinal Kanama",
        category="4-2-1 KRİTER DETAYI",
        subtitle="ETDRS Standart Fotoğraf 2A ile kıyaslanan >20 intraretinal hemoraji standardı.",
        image_path="12-Retina_and_Vitreous_2025-2026_p130_fig131.png",
        focal_points=[
            ("Sayım Standardı", "Retinanın 4 kadranının (üst temporal, alt temporal, üst nazal, alt nazal) HER BİRİNDE en az 20 adet kanama bulunmalıdır."),
            ("Standart Fotoğraf 2A", "Klinik çalışmalarda hekim bu fotoğrafla kıyaslayarak karar verir; lezyon yoğunluğu 2A'ya eşit veya fazla olmalıdır."),
            ("İskemiye İşareti", "Kanamaların tüm kadranlara yayılması, retina genelinde yaygın kapiller tıkanıklık ve hipoksinin başladığını kanıtlar.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p130_fig131.png 4 kadran yaygın kanamayı belgeler."
    )

    # S53: 2. Kriter: 2 Kadranda Venöz Boğumlanma — BCSC p.130 fig132
    pub.add_visual_schema_slide(
        title="4-2-1 Kuralı Kriter 2: 2+ Kadranda Venöz Boğumlanma (Venous Beading)",
        category="4-2-1 KRİTER DETAYI",
        subtitle="Ven çapında fokal dilatasyon ve daralmaların oluşturduğu 'tespih tanesi' görünümü.",
        image_path="12-Retina_and_Vitreous_2025-2026_p130_fig132.png",
        focal_points=[
            ("Mekanizması", "Ağır retinal hipoksiye bağlı ven endotel tonusunun kaybolması ve ven duvarı dekompansasyonu."),
            ("Kriter Eşiği", "En az 2 ayrı kadranda belirgin venöz boğumlanma (Standart Fotoğraf 6B) izlenmelidir."),
            ("Prognostik Gücü", "Venöz boğumlanma 4-2-1 kriterleri içinde PDR'ye ilerlemeyi TEK BAŞINA EN GÜÇLÜ ÖNGÖREN biyobelirteçtir.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p130_fig132.png venöz boğumlanmanın tespih tanesi paternini gösterir."
    )

    # S54: 3. Kriter: 1 Kadranda Belirgin IRMA — BCSC p.131 fig133
    pub.add_visual_schema_slide(
        title="4-2-1 Kuralı Kriter 3: 1+ Kadranda Belirgin IRMA",
        category="4-2-1 KRİTER DETAYI",
        subtitle="İntraretinal mikrovasküler anormallikler (Standart Fotoğraf 8A standardı).",
        image_path="12-Retina_and_Vitreous_2025-2026_p131_fig133.png",
        focal_points=[
            ("IRMA Nedir?", "Tıkalı kapiller yatakların çevresinde arteriol ile venülü birbirine bağlayan genişlemiş intraretinal kollateral şant damarlarıdır."),
            ("Kriter Eşiği", "En az 1 kadranda Standart Fotoğraf 8A'ya eşit veya daha belirgin IRMA bulunması Ağır NPDR tanısı koydurur."),
            ("Pre-Retinal Değildir", "IRMA iç limitan membranın (ILM) ALTINDA kalır; vitreusa doğru büyümez ve bu nedenle traksiyon yapmaz.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p131_fig133.png IRMA'nın kıvrımlı intraretinal yapısını belgeler."
    )

    # S55: IRMA vs NVD/NVE Ayırıcı Tanı Masası — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Kritik Ayırıcı Tanı: IRMA (Ağır NPDR) vs Neovaskülarizasyon (PDR)",
        category="AYIRICI TANI MASASI",
        subtitle="İntraretinal kollateral damar ile pre-retinal patolojik damarın klinik ve anjiyografik ayrımı.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p131_fig133.png",
        caption1="IRMA (AĞIR NPDR) — İNTRARETİNAL & SIZINTISIZ",
        img2_path=ASSETS_DIR / "dr_panel_hr_pdr_nvd_nve.png",
        caption2="NEOVASKÜLARİZASYON (PDR) — PRE-RETİNAL & PROFÜZ SIZINTILI",
        focal_points=[
            ("Anatomik Düzlem", "IRMA retinanın içinde (intraretinal) kalır ve ILM'yi delmez; NVD/NVE ise ILM'yi delerek vitreus içine doğru büyür."),
            ("FFA Sızıntı Paterni (Altın Standart)", "IRMA'da sıkı endotel bağlantıları korunduğu için sızıntı minimumdur veya yoktur; Neovaskülarizasyonda ise tight junction olmadığı için yoğun floresein sızıntısı ve parlama olur."),
            ("Fibröz Doku Eşliği", "IRMA fibröz glia içermez; Neovaskülarizasyona daima traksiyona yol açabilen fibrovasküler doku eşlik eder.")
        ],
        notes="IRMA ile NVE ayrımı oftalmolojide evreleme ve tedavi kararını belirleyen en kritik kavşaktır."
    )

    # S56: Çok Ağır NPDR — Wills Eye Retina (p.119 fig069)
    pub.add_visual_schema_slide(
        title="Evre 3B: Çok Ağır NPDR (Very Severe NPDR)",
        category="KLİNİK EVRELEME",
        subtitle="4-2-1 kuralının 2 veya 3 kriterinin birden pozitif olduğu alarm tablosu.",
        image_path="Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3__p119_fig069.jpeg",
        focal_points=[
            ("Tanı Kriteri", "4 kadran kanama + 2 kadran venöz boğumlanma VEYA 4 kadran kanama + 1 kadran IRMA birlikteliği."),
            ("1 Yıllık PDR Riski", "%75 gibi olağanüstü yüksek bir orandır; hastaların neredeyse tamamı 12 ay içinde proliferatif evreye geçer."),
            ("Klinik Yaklaşım", "Takip aralığı 2-3 aya çekilir. Hasta düzenli kontrole gelemeyecekse neovaskülarizasyon beklenmeden erken PRP veya anti-VEGF uygulanır.")
        ],
        notes="Wills Eye Retina p.119 fig069 çok ağır NPDR'deki ileri mikrovasküler yıkımı gösterir."
    )

    # S57: Erken PDR vs Yüksek Riskli PDR Kriterleri (DRS 3/4) — BCSC p.135 fig135 & fig136
    pub.add_dual_comparison_slide(
        title="Evre 4: Proliferatif DR — DRS Yüksek Risk Kriterleri (3/4 Kuralı)",
        category="PDR KRİTERLERİ",
        subtitle="Diabetic Retinopathy Study (DRS) tarafından tanımlanan ve acil PRP gerektiren yüksek risk tablosu.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p135_fig135.png",
        caption1="ERKEN PDR — KÜÇÜK NVD / NVE (<1/3 DİSK ALANI)",
        img2_path="12-Retina_and_Vitreous_2025-2026_p135_fig136.png",
        caption2="YÜKSEK RİSKLİ PDR — GENİŞ NVD (>1/3 DİSK) + HEMORAJİ",
        focal_points=[
            ("4 DRS Kriteri", "1. Neovaskülarizasyon varlığı, 2. Neovaskülarizasyonun optik disk üzerinde (NVD) olması, 3. NVD'nin orta/ağır olması (>1/3-1/4 disk alanı), 4. Preretinal veya vitreus kanaması eşliği."),
            ("Yüksek Risk Tanımı (3/4)", "Bu 4 kriterden en az 3'ünü karşılayan göz 'Yüksek Riskli PDR' olarak adlandırılır."),
            ("Acil Tedavi Eşiği", "Tedavi edilmeyen yüksek riskli PDR'de 2 yıl içinde ciddi görme kaybı (<5/200) riski %26-37'dir; gecikmeden PRP veya anti-VEGF başlanmalıdır.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p135_fig135.png ve fig136.png NVD boyutunu ve yüksek risk kriterlerini belgeler."
    )

    # S58: NVD (Neovascularization of the Disc) — Atlas of Retinal OCT (p.103 fig175)
    pub.add_visual_schema_slide(
        title="Optik Disk Neovaskülarizasyonu (NVD) ve OCT Kesiti",
        category="PDR LEZYON DETAYI",
        subtitle="Optik disk başı veya 1 disk çapı çevresinde gelişen patolojik yeni damarlar.",
        image_path="Atlas_of_Retinal_OCT_p103_fig175.jpeg",
        focal_points=[
            ("Anatomik Konumu", "Optik sinir başı üzerinde veya diske 1 disk çapı (DD) mesafedeki retina yüzeyinde kümelenir."),
            ("OCT Bulgusu", "İç limitan membranı (ILM) delip arka hiyaloid yüzeyine tutunan ve vitreus boşluğuna doğru uzanan hiperreflektif vasküler tomurcuklar."),
            ("Traksiyonel Yırtık Riski", "Posterior hiyaloid dekolmanı (PVD) geliştikçe bu damarları çekerek masif vitreus kanamasına yol açar.")
        ],
        notes="Atlas of Retinal OCT p.103 NVD'nin arka vitreus yüzeyine invazyonunu gösterir."
    )

    # S59: NVE (Neovascularization Elsewhere) Deniz Yelpazesi — Wills Eye Retina (p.123 fig072)
    pub.add_visual_schema_slide(
        title="Retina Dışı Neovaskülarizasyon (NVE) ve Deniz Yelpazesi (Sea-Fan)",
        category="PDR LEZYON DETAYI",
        subtitle="Optik diskten uzakta, majör damar arkatları boyunca gelişen frajil yeni damar ağları.",
        image_path="Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3__p123_fig072.jpeg",
        focal_points=[
            ("Yerleşim Tercihi", "En sık temporal arkatlar boyunca ve perfüze olan retina ile iskemik perifer arasındaki sınır hattında gelişir."),
            ("Deniz Yelpazesi Deseni", "Bir besleyici arteriol ve bir drenaj venülü çevresinde yelpaze gibi açılan frajil kapiller yumaklarıdır."),
            ("FFA'da Yoğun Sızıntı", "Erken fazda hızla dolar, geç fazda tüm lezyon sınırlarını örtecek kadar yoğun hiperfloresan sızıntı verir.")
        ],
        notes="Wills Eye Retina p.123 fig072 NVE'nin klasik deniz yelpazesi morfolojisini belgeler."
    )

    # S60: Ön Kamara Açısı Neovaskülarizasyonu (NVI / NVA / Neovasküler Glokom)
    pub.add_visual_schema_slide(
        title="Ön Kamara Açısı Neovaskülarizasyonu ve Neovasküler Glokom (NVG)",
        category="İLERİ KOMPLİKASYON",
        subtitle="Retinal iskeminin ön segmente taşması: Rubeozis iridis ve açı kapanması felaketi.",
        image_path="12-Retina_and_Vitreous_2025-2026_p135_fig136.png",
        focal_points=[
            ("Rubeozis İridis (NVI)", "Pupil kenarında pupiller sfinkter boyunca küçük kırmızı kılcal damar tomurcukları olarak başlar."),
            ("Açı Neovaskülarizasyonu (NVA)", "Trabeküler ağ üzerine tırmanan damarlar fibroblastlarla birlikte fibrovasküler membran oluşturur."),
            ("Fermuar Tarzı Kapanma", "Membranın kasılması trabeküler ağı fermuar gibi kapatarak (sineşiyal açı kapanması) GİB'i 50-60 mmHg'ye fırlatır; acil PRP ve anti-VEGF şarttır.")
        ],
        notes="Gonyoskopi, PDR şüphesi olan her hastada rutin muayenenin ayrılmaz parçasıdır."
    )

    # S61: Vitreus Kanaması ve Subhiyaloid Hemoraji — Atlas of Retinal OCT (p.103 fig176)
    pub.add_visual_schema_slide(
        title="Vitreus Kanaması ve Preretinal Subhiyaloid Hemoraji",
        category="PDR KOMPLİKASYONU",
        subtitle="Fraji neovasküler damarların rüptürü sonucu gelişen kanama paternleri.",
        image_path="Atlas_of_Retinal_OCT_p103_fig176.jpeg",
        focal_points=[
            ("Subhiyaloid (Preretinal) Kanama", "Retina ile arka hiyaloid arasına hapsolmuş, yerçekimiyle 'kayık' veya 'D' şeklinde yatay seviye veren kanamadır."),
            ("İntravitreal Kanama", "Kanın hiyaloidi delerek jel içine dağılması; kırmızı refle kaybolur, B-scan ultrasonografi ile retina dekolmanı taranmalıdır."),
            ("Tedavi Kararı", "Spontan çekilme için 1-3 ay beklenebilir; ancak traksiyonel dekolman varsa veya kanama açılmıyorsa erken vitrektomi (PPV) uygulanır.")
        ],
        notes="Atlas of Retinal OCT p.103 subhiyaloid kanamanın optik gölgeleme ve kistik retinal etkisini gösterir."
    )

    pub.add_lecture_card_slide(
        title="Bölüm 3 Özeti: ETDRS 4-2-1 Evreleme ve Karar Matrisi",
        category="BÖLÜM 3 ÖZETİ",
        subtitle="Evrelere göre klinik kontrol sıklığı ve müdahale eşikleri tablosu.",
        cards=[
            {
                "card_title": "HAFİF VE ORTA NPDR",
                "lead": "Sistemik Optimizasyon",
                "items": [
                    "Hafif NPDR: Yılda bir kontrol (HbA1c <%7, KB <130/80).",
                    "Orta NPDR: 6 ayda bir kontrol + SD-OCT ile DMÖ taraması."
                ],
                "footer": "Metabolik Takip"
            },
            {
                "card_title": "AĞIR VE ÇOK AĞIR NPDR (4-2-1)",
                "lead": "Yüksek Risk Alarmı",
                "items": [
                    "Ağır NPDR (1 Kriter): 3-4 ayda bir kontrol.",
                    "Çok Ağır NPDR (>=2 Kriter): 2-3 ayda bir kontrol; uyumsuz hastada erken PRP veya anti-VEGF."
                ],
                "footer": "Pre-Proliferatif Eşik"
            },
            {
                "card_title": "PDR VE YÜKSEK RİSK",
                "lead": "Acil Tedavi Zorunluluğu",
                "items": [
                    "NVD >1/3 disk veya NVE + kanama varlığında gecikmeden PRP veya anti-VEGF başlanır.",
                    "Ön segment muayenesinde pupil kenarı ve açı rubeozis açısından taranmalıdır."
                ],
                "footer": "Körlüğü Önleme"
            }
        ],
        notes="Bölüm 3 tamamlandı. Bölüm 4'te diyabetteki en yaygın görme kaybı nedeni olan Diyabetik Makula Ödemini inceleyeceğiz."
    )

    # ========================================================
    # BÖLÜM 4: DİYABETİK MAKULA ÖDEMİ VE PROTOKOL V (S63 - S86)
    # ========================================================
    pub.add_section_header_slide(
        part_num=4,
        title="Diyabetik Makula Ödemi (DMÖ) ve Protokol V",
        subtitle="Patofizyoloji, ETDRS CSME vs Modern OCT Sınıflaması, 4 Morfolojik Tip ve DRCR.net Protokol V Kanıtı.",
        learning_objectives=[
            "Klasik ETDRS Klinik Olarak Anlamlı Makula Ödemi (CSME) kriterlerini modern OCT parametreleriyle kıyaslamak.",
            "Santral Tutulumlu (CI-DME) ile Santral Tutulumsuz (NCI-DME) ayrımını ve tedavi eşiklerini kavramak.",
            "4 temel morfolojik ödem tipini (Süngerimsi, Kistoid, Seröz dekolman, Foveal sert eksüda plağı) SD-OCT'de ayırt etmek.",
            "DRCR.net Protokol V çalışmasının iyi görmeli CI-DME (>=20/25) gözlerindeki gözlem/lazer/aflibercept sonuçlarını analiz etmek."
        ],
        notes="Bölüm 4, diyabette görme keskinliğini doğrudan tehdit eden makula ödeminin tanı ve klinik yönetimini ele alır."
    )

    pub.add_lecture_card_slide(
        title="Diyabetik Makula Ödeminin Önemi ve Görülme Sıklığı",
        category="KLİNİK EPİDEMİYOLOJİ",
        subtitle="Diyabetik bireylerde görme keskinliği kaybının dünyadaki bir numaralı nedeni.",
        cards=[
            {
                "card_title": "PREVALANS VE SIKLIK",
                "lead": "Diyabet Süresiyle Katlanan Yük",
                "items": [
                    "Diyabet süresi 15 yılı aşan Tip 1 hastaların %15-20'sinde, Tip 2 hastaların %25-30'unda DMÖ gelişir.",
                    "Dünyada 21 milyondan fazla insanın DMÖ nedeniyle orta veya ağır görme kaybı yaşadığı tahmin edilmektedir."
                ],
                "footer": "Global Görme Tehdidi"
            },
            {
                "card_title": "HER EVREDE GÖRÜLEBİLME ÖZELLİĞİ",
                "lead": "Retinopati Evresinden Bağımsızlık",
                "items": [
                    "DMÖ yalnızca PDR'de değil; çok hafif bir NPDR gözünde de ilk bulgu olarak ortaya çıkabilir.",
                    "Ancak retinopati şiddeti arttıkça DMÖ gelişme olasılığı katlanarak artar."
                ],
                "footer": "Erken Tarama Zorunluluğu"
            },
            {
                "card_title": "MODERN TEDAVİ PARADİGMASI",
                "lead": "Lazerden Anti-VEGF Çağına",
                "items": [
                    "ETDRS döneminde fokal/grid lazer görme kaybını %50 azaltsa da görmeyi nadiren artırıyordu.",
                    "Anti-VEGF ajanlar ise hastaların %30-45'inde 3 sıra (15 harf) ve üzeri gerçek görme artışı sağlar."
                ],
                "footer": "Fonksiyonel Kazanım"
            }
        ],
        notes="DMÖ tedavisi oftalmolojide farmakoterapinin en başarılı olduğu alanlardan biridir."
    )

    # S65: DMÖ Patofizyolojik Sınıflaması — BCSC p.142 fig140 & fig141
    pub.add_dual_comparison_slide(
        title="DMÖ Sızıntı Mekanizması: Fokal Sızıntı vs Diffüz Sızıntı",
        category="PATOFİZYOLOJİ",
        subtitle="Mikroanevrizma kaynaklı fokal sızıntı ile yaygın kapiller yetmezlik kaynaklı diffüz sızıntı.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p142_fig140.png",
        caption1="FOKAL SIZINTI — MİKROANEVRİZMA & SERT EKSÜDA HALKASI",
        img2_path="12-Retina_and_Vitreous_2025-2026_p142_fig141.png",
        caption2="DİFFÜZ SIZINTI — YAYGIN BRB YIKIMI & KİSTOİD MAKULA ÖDEMİ",
        focal_points=[
            ("Fokal Sızıntı Karakteri", "Belirli mikroanevrizmalardan kaynaklanır; çevresinde lipid ve sert eksüdaların oluşturduğu circinate halka eşlik eder."),
            ("Diffüz Sızıntı Karakteri", "Tüm retina kapiller ağında ve endotel sıkı bağlantılarında yaygın yıkım vardır; petalloid kistoid alanlar oluşturur."),
            ("Tedavi Yaklaşımı", "Fokal sızıntıda fokal lazer mikroanevrizmaları kapatmada hala seçenek olabilir; diffüz sızıntıda ise anti-VEGF veya steroid implant tek rasyonel yoldur.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p142_fig140.png ve fig141.png fokal ve diffüz anatomik mekanizmayı gösterir."
    )

    # S66: Klasik ETDRS CSME — Ryan Vol 3 (p.204 fig190)
    pub.add_visual_schema_slide(
        title="Klasik Tanım: Klinik Olarak Anlamlı Makula Ödemi (CSME)",
        category="TARİHSEL STANDART",
        subtitle="ETDRS Rapor No: 1 tarafından tanımlanan ve biyomikroskopiye dayalı 3 CSME kriteri.",
        image_path="RYAN_S_RETINA_7th_Ed__Vol_3_p204_fig190.jpeg",
        focal_points=[
            ("Kriter 1", "Fovea merkezine 500 mikron (1/3 disk çapı) veya daha yakın mesafede retina kalınlaşması bulunması."),
            ("Kriter 2", "Fovea merkezine 500 mikron veya daha yakın sert eksüda bulunması (eşlik eden komşu retina kalınlaşması ile birlikte)."),
            ("Kriter 3", "Fovea merkezine 1 disk çapı (1500 mikron) mesafede, en az 1 disk alanı (DA) genişliğinde retina kalınlaşması sahası bulunması.")
        ],
        notes="Ryan Vol 3 p.204 fig190 klasik CSME'nin foveal halka morfolojisini gösterir."
    )

    # S67: Modern OCT Tanımı: CI-DME vs NCI-DME — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Modern OCT Sınıflaması: CI-DME (Santral Tutulumlu) vs NCI-DME",
        category="OCT SINIFLAMASI",
        subtitle="Santral 1 mm foveal alt alandaki kalınlaşmanın tedavi algoritmasındaki belirleyiciliği.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p144_fig144.png",
        caption1="SANTRAL TUTULUMSUZ (NCI-DME) — SIVI 1 MM FOVEA DIŞINDA",
        img2_path="12-Retina_and_Vitreous_2025-2026_p144_fig145.png",
        caption2="SANTRAL TUTULUMLU (CI-DME) — SIVI VE KİSTLER FOVEA MERKEZİNDE",
        focal_points=[
            ("CI-DME Tanımı", "Santral 1 mm foveal alt alanda (CST) cihaz cinsiyet eşiklerinin üzerinde retina kalınlaşması bulunması (Zeiss Cirrus >290-305 μm, Heidelberg Spectralis >305-320 μm)."),
            ("NCI-DME Tanımı", "Makulada retina kalınlaşması vardır ancak fovea merkezinin 1 mm'lik dairesi tamamen kurudur; görme keskinliği genellikle tamdır."),
            ("Tedavi Ayrımı", "CI-DME anti-VEGF enjeksiyonunun birincil endikasyonudur; NCI-DME'de ise doğrudan enjeksiyon yapılmaz, yakın izlem veya fokal lazer tercih edilir.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p144_fig144.png ve fig145.png CI-DME ve NCI-DME ayrımını ortaya koyar."
    )

    # S68: Şema 3 (dr_schema_3_dmo_algorithm.png)
    pub.add_visual_schema_slide(
        title="Diyabetik Makula Ödemi Klinik Karar ve Tedavi Algoritması",
        category="KARAR ALGORİTMASI",
        subtitle="Görme keskinliği ve santral tutuluma göre adım adım tedavi basamakları.",
        image_path=ASSETS_DIR / "dr_schema_3_dmo_algorithm.png",
        focal_points=[
            ("Adım 1: CI-DME vs NCI-DME", "OCT'de santral 1 mm tutulumu kontrol edilir; tutulum yoksa gözlem veya fokal lazer yapılır."),
            ("Adım 2: Görme Keskinliği Değerlendirmesi", "Görme >=20/25 ise Protokol V uygulanır (yakın izlem); Görme <=20/32 ise doğrudan Anti-VEGF başlanır."),
            ("Adım 3: Yükleme Dozu ve Yanıt", "İlk 3-6 ay aylık enjeksiyon yapılır; inatçı sıvı varlığında Faricimab veya Deksametazon implantına geçilir.")
        ],
        notes="dr_schema_3_dmo_algorithm.png şeması tüm uluslararası kılavuzların özet karar ağacıdır."
    )

    pub.add_lecture_card_slide(
        title="SD-OCT Morfolojik Ödem Tipleri ve Prognostik Anlamları",
        category="OCT MORFOLOJİSİ",
        subtitle="Retina kesitinde sıvının biriktiği anatomik kompartmanlar ve tedaviye yanıt profilleri.",
        cards=[
            {
                "card_title": "1. SÜNGERİMSİ RETİNA KALINLAŞMASI",
                "lead": "Diffüz İntersellüler Ödem",
                "items": [
                    "Retina katmanlarında belirgin kist olmadan diffüz kalınlaşma.",
                    "Müller hücrelerinin su kanalı bozukluğuna ve sitotoksik şişmeye bağlıdır.",
                    "Erken evredir; anti-VEGF tedavisine en hızlı yanıt veren tiptir."
                ],
                "footer": "Mükemmel Tedavi Yanıtı"
            },
            {
                "card_title": "2. KİSTOİD MAKULA ÖDEMİ (KMÖ)",
                "lead": "İntraretinal Sıvı Kaviteleri",
                "items": [
                    "İç nükleer ve dış pleksiform tabakada yuvarlak hiporansflektif kistler.",
                    "Kronikleştikçe Müller hücre septaları yırtılarak kistler birleşir.",
                    "Büyük kistler fotoreseptör aksonlarını gererek mekanik hasar verir."
                ],
                "footer": "En Yaygın Morfoloji"
            },
            {
                "card_title": "3. SERÖZ RETİNA DEKOLMANI (SRD)",
                "lead": "Subretinal Sıvı Birikimi",
                "items": [
                    "Fotoreseptörler ile RPE arasında kubbe şeklinde sıvı birikmesi.",
                    "Ağır inflamatuar bileşene işaret eder.",
                    "Deksametazon implantına (Ozurdex) çok dramatik yanıt verir."
                ],
                "footer": "İnflamasyon İşareti"
            }
        ],
        notes="Ödem morfolojisi ilaç seçimi (anti-VEGF vs steroid) açısından yol göstericidir."
    )

    # S70: Morfoloji 1: Süngerimsi Retinal Kalınlaşma — Atlas of Retinal OCT (p.95 fig161)
    pub.add_visual_schema_slide(
        title="Morfoloji 1: Süngerimsi Retinal Kalınlaşma (Spongiform Swelling)",
        category="OCT PATOLOJİ",
        subtitle="Belirgin kistik kavite olmaksızın retina dokusunun homojen diffüz kalınlaşması.",
        image_path="Atlas_of_Retinal_OCT_p095_fig161.jpeg",
        focal_points=[
            ("OCT Görünümü", "Retina katmanlarında kist boşluğu görülmez; nörosensoryal doku şişmiş, reflektivitesi homojen olarak azalmıştır."),
            ("Müller Hücre Şişmesi", "Müller hücrelerinin aquaporin kanallarının bozulmasıyla hücre içi ve mikroskobik hücreler arası sıvı birikir."),
            ("Fonksiyonel Prognoz", "Kistoid yıkım ve sinaps kopması henüz gelişmediği için erken tedaviyle görme keskinliği hızla normale döner.")
        ],
        notes="Atlas of Retinal OCT p.95 fig161 süngerimsi kalınlaşmanın erken evresini belgeler."
    )

    # S71: Morfoloji 2: Kistoid Makula Ödemi — Dual Comparison (Atlas of Retinal OCT p.95 fig163 vs fig164)
    pub.add_dual_comparison_slide(
        title="Morfoloji 2: Kistoid Makula Ödemi — Küçük Kistler vs Devasa Kistler",
        category="OCT PATOLOJİ",
        subtitle="İç nükleer tabaka (INL) mikrokistleri ile dış pleksiform tabaka (OPL) dev füzyon kistleri.",
        img1_path="Atlas_of_Retinal_OCT_p095_fig163.jpeg",
        caption1="ERKEN KİSTOİD ÖDEM — AYRIK İNTRAPLEKSİFORM KİSTLER",
        img2_path="Atlas_of_Retinal_OCT_p095_fig164.jpeg",
        caption2="KRONİK KİSTOİD ÖDEM — DEV SANTRAL KİSTİK KAVİTE",
        focal_points=[
            ("Kist Dağılımı", "Erken dönemde kistler Henle sinir lifi tabakası boyunca petalloid desende dizilir; dış pleksiform tabakayı genişletir."),
            ("Septa Rüptürü ve Füzyon", "Kronikleşen vakalarda kistler arasındaki doku duvarları (Müller hücre iskeleleri) yırtılarak foveada devasa kaviteler oluşturur."),
            ("Fotoreseptör Hasarı", "Kist tavanının ve tabanının gerilmesi elipsoid zon (EZ) hattını koparır; ödem kurusa da skotom kalabilir.")
        ],
        notes="Atlas of Retinal OCT p.95 fig163 ve fig164 kistoid evrelerin progresyonunu ortaya koyar."
    )

    # S72: Morfoloji 3: Seröz Retina Dekolmanı — Dual Comparison (Atlas of Retinal OCT p.97 fig165 vs fig166)
    pub.add_dual_comparison_slide(
        title="Morfoloji 3: Seröz Retina Dekolmanı (Subretinal Sıvı - SRF)",
        category="OCT PATOLOJİ",
        subtitle="Subretinal alanda berrak sıvı göllenmesi ve dış fotoreseptör tabakasının elevasyonu.",
        img1_path="Atlas_of_Retinal_OCT_p097_fig165.jpeg",
        caption1="SANTRAL FOVEAL SERÖZ DEKOLMAN — KUBBE DİZİLİMİ",
        img2_path="Atlas_of_Retinal_OCT_p097_fig166.jpeg",
        caption2="SERÖZ SIVI + İNTRARETİNAL KİSTOİD ÖDEM BİRLİKTELİĞİ",
        focal_points=[
            ("Görülme Sıklığı", "DMÖ hastalarının yaklaşık %15-30'unda intraretinal kistlere subretinal sıvı (SRF) eşlik eder."),
            ("RPE Pompa Yetmezliği", "Koryokapillaris iskemisi ve RPE zonula okkludens hasarı sonucu sıvının subretinal boşluktan tahliyesi durur."),
            ("Dış Segment Uzaması", "Dekole kalan fotoreseptörlerin dış segmentleri RPE tarafından fagositoz edilemediği için uzar ve pürüzlü görünüm alır.")
        ],
        notes="Atlas of Retinal OCT p.97 fig165 ve fig166 subretinal seröz sıvının net kubbemsi konturunu gösterir."
    )

    # S73: Morfoloji 4: Sert Eksüda Plakları ve Foveal Lipid — Dual Comparison
    pub.add_dual_comparison_slide(
        title="Morfoloji 4: Foveal Sert Eksüda Plakları ve Subfoveal Lipid Çökmesi",
        category="OCT PATOLOJİ",
        subtitle="Lipoprotein sızıntısının fovea merkezinde plak oluşturması ve RPE metaplazisi riski.",
        img1_path="12-Retina_and_Vitreous_2025-2026_p144_fig146.png",
        caption1="RENKLİ FUNDUS — FOVEAYI TEHDİT EDEN CIRCINATE EKSÜDA",
        img2_path="Atlas_of_Retinal_OCT_p101_fig172.jpeg",
        caption2="SD-OCT — DENSE HİPERREFLEKTİF SUBFOVEAL LİPİD PLAKLARI",
        focal_points=[
            ("Eksüda Plaklarının Kökeni", "Sıvı resorbe olurken geride kalan lipoprotein ve kolesterol kristalleri fovea avasküler çukurunda çöker."),
            ("Optik Gölgeleme", "OCT'de eksüda plağının arkasında tam optik gölgeleme (shadowing) oluşur; alttaki fotoreseptör ve RPE tabakası karanlıkta kalır."),
            ("Subfoveal Fibrozis Riski", "Plak uzun süre kalırsa RPE proliferasyonunu ve metaplazisini uyararak kalıcı fibrotik skar dokusuna dönüşebilir.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p144_fig146.png ve Atlas p.101 subfoveal sert eksüdanın yıkıcı potansiyelini belgeler."
    )

    # S74: Foveal Kist Rüptürü ve Makula Deliği — Atlas of Retinal OCT (p.101 fig173)
    pub.add_visual_schema_slide(
        title="Komplikasyon: Foveal Kist Rüptürü ve Lameller / Tam Kat Makula Deliği",
        category="OCT KOMPLİKASYON",
        subtitle="Kronik dev kistoid kavitelerin iç veya dış çatısının yırtılması mekanizması.",
        image_path="Atlas_of_Retinal_OCT_p101_fig173.jpeg",
        focal_points=[
            ("İç Çatı Yırtılması (Lameller Delik)", "Fovea kistinin iç sınır zarı yırtılırsa kist açılır; foveal çukurda asimetrik dik kenarlı defekt oluşur."),
            ("Tam Kat Makula Deliği (FTMH)", "Hem iç hem dış duvar çökerse RPE tabakasına kadar uzanan tam kat diyabetik makula deliği gelişir."),
            ("Ayırıcı Tanı", "İdiyopatik makula deliklerinden farklı olarak diyabetik deliklerin kenarlarında daima mikrokistler ve diffüz ödem bulunur.")
        ],
        notes="Atlas of Retinal OCT p.101 fig173 foveal kist rüptürünü belgeler."
    )

    # S75: Vitreomaküler Arayüz (VMA / VMT) Traksiyonu (dr_panel_oct_dril_vmt.png)
    pub.add_visual_schema_slide(
        title="Vitreomaküler Arayüz (VMA / VMT) ve Traksiyonel Makula Ödemi",
        category="OCT ARAYÜZ",
        subtitle="Arka hiyaloidin foveaya yapışık kalması ve mekanik çekintinin medikal direnç yaratması.",
        image_path=ASSETS_DIR / "dr_panel_oct_dril_vmt.png",
        focal_points=[
            ("Vitreomaküler Traksiyon (VMT)", "Kısmi arka vitreus dekolmanında (PVD) hiyaloidin fovea merkezinden ayrılamayarak yukarı çekmesidir."),
            ("Epiretinal Membran (ERM)", "ILM yüzeyinde prolifere olan miyofibroblastik membran retinayı büzüştürür (retinal tortuosity ve kırma)."),
            ("Cerrahi Endikasyon", "VMT veya belirgin ERM varlığında anti-VEGF enjeksiyonları sıvıyı boşaltamaz; pars plana vitrektomi ve ILM soyma gerekir.")
        ],
        notes="dr_panel_oct_dril_vmt.png VMT'nin medikal tedaviye direnç oluşturan mekanik doğasını şematize eder."
    )

    pub.add_lecture_card_slide(
        title="DRCR.net Protokol V Klinik Sorusu ve Tasarımı",
        category="RKÇ DERİN ANALİZ",
        subtitle="İyi görme keskinliğine (>=20/25) sahip CI-DME gözlerinde hemen enjeksiyon yapılmalı mı?",
        cards=[
            {
                "card_title": "KLİNİK İKİLEM",
                "lead": "Görme 1.0 iken İğne Yapalım mı?",
                "items": [
                    "Hastanın santral OCT ödemi var (CI-DME) ancak görme keskinliği 20/25 (0.8) veya 20/20 (1.0).",
                    "Hemen aylık anti-VEGF başlamak maliyetli ve hasta uyumu zordur.",
                    "Tedavi edilmezse kalıcı görme kaybı riski var mıdır?"
                ],
                "footer": "Protokol V Hipotezi"
            },
            {
                "card_title": "3 TEDAVİ KOLU",
                "lead": "702 Gözün Randomizasyonu",
                "items": [
                    "Kol 1: Aflibercept 2.0 mg (Hemen aylık enjeksiyon protokolü).",
                    "Kol 2: Lazer Fotokoagülasyon (Standart fokal/grid lazer; görme düşerse kurtarma).",
                    "Kol 3: Gözlem (Hiçbir tedavi yapılmaz; görme düşerse kurtarma)."
                ],
                "footer": "JAMA Ophthalmol 2019"
            },
            {
                "card_title": "KURTARMA (RESCUE) PROTOKOLÜ",
                "lead": "Güvenlik Ağı Kriteri",
                "items": [
                    "Gözlem veya lazer kolundaki hastada görme keskinliği >=5 harf (1 sıra) düşerse hemen Aflibercept kurtarma enjeksiyonuna geçildi.",
                    "Bu güvenlik ağı sayesinde hastaların kalıcı görme kaybı önlendi."
                ],
                "footer": "Klinik Kurtarma Algoritması"
            }
        ],
        notes="Protokol V, modern retina pratiğinde iyi görmeli diyabetik hastaların yönetimini kökten değiştiren RKÇ'dir."
    )

    # S77: Protokol V Çalışma Tasarımı ve 2 Yıllık Sonuçları — BCSC p.144 fig147
    pub.add_visual_schema_slide(
        title="DRCR.net Protokol V: 2 Yıllık Görme Keskinliği Eğrileri",
        category="RKÇ KANIT GRAFİĞİ",
        subtitle="Aflibercept, Lazer ve Gözlem kolları arasında 2. yıl sonunda hiçbir anlamlı görme farkı çıkmadı.",
        image_path="12-Retina_and_Vitreous_2025-2026_p144_fig147.png",
        focal_points=[
            ("2. Yıl Görme Sonuçları", "Ortalama görme keskinliği Aflibercept grubunda 20/20, Lazer grubunda 20/20, Gözlem grubunda 20/20 olarak korundu (p=0.79)."),
            ("Enjeksiyonsuz Kalabilme Başarısı", "Gözlem grubundaki hastaların %66'sı (üçte ikisi) 2 yıl boyunca tek bir enjeksiyon dahi almadan görmesini tam korudu."),
            ("Kurtarma İhtiyacı Oranı", "Gözlem grubunun yalnızca %34'ünde görme düştü ve Aflibercept kurtarma protokolüyle hemen eski seviyesine yükseltildi.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p144_fig147.png Protokol V görme eğrilerinin birebir örtüştüğünü belgeler."
    )

    pub.add_trial_deep_dive_slide(
        title="DRCR.net Protokol V: Ayrıntılı Kanıt ve Klinik Özet",
        category="RKÇ DERİN ANALİZ",
        subtitle="Baker et al., JAMA 2019 — İyi görmeli CI-DME'de başlangıçta gözlem stratejisinin tam zaferi.",
        trial_name="DRCR.net PROTOKOL V (JAMA 2019, 702 Göz)",
        inclusion_criteria="Santral Tutulumlu DME (CI-DME) ve Snellen görme keskinliği 20/25 (0.8) veya daha iyi olan hastalar.",
        treatment_arms=[
            {
                "name": "AFLİBERCEPT 2.0 MG KOLU",
                "regimen": "Aylık enjeksiyon protokolü; stabilite sağlanana kadar devam edildi.",
                "result": "2. Yılda Görme Kaybı Oranı: %16 (Ortalama görme 20/20 tam korundu).",
                "extra": "Santral foveal kalınlıkta en hızlı anatomik kuruma sağlandı (CST ortalama -112 µm)."
            },
            {
                "name": "LAZER FOTOKOAGÜLASYON KOLU",
                "regimen": "Standart ETDRS fokal/grid lazer; görme düşüşünde kurtarma anti-VEGF.",
                "result": "2. Yılda Görme Kaybı Oranı: %17 (Aflibercept koluyla farksız, p=0.79).",
                "extra": "Gözlerin %60'tan fazlası 2 yıl boyunca enjeksiyon gerektirmeden stabil kaldı."
            },
            {
                "name": "GÖZLEM (TEDAVİSİZ İZLEM) KOLU",
                "regimen": "Hiçbir başlangıç tedavisi yok; >=5 harf görme düşüşünde derhal kurtarma Aflibercept.",
                "result": "2. Yılda Görme Kaybı Oranı: %19 (Aflibercept koluyla farksız, p=0.79).",
                "extra": "Gözlerin %66'sı 2 yıl boyunca TEK BİR İĞNE ALMADAN görmesini tam korudu!"
            }
        ],
        primary_outcomes=[
            "2. Yılda >=5 Harf Görme Kaybı Oranı: Aflibercept %16, Lazer %17, Gözlem %19 (gruplar arası fark istatistiksel olarak anlamsız, p=0.79).",
            "Kurtarma Enjeksiyonu Zamanı: Görme düşüşü yaşayan %34'lük grupta Aflibercept hemen başlandığında görme 20/20'ye geri döndü; gecikme hasarı oluşmadı."
        ],
        clinical_bottom_line="Görme keskinliği 20/25 veya daha iyi olan CI-DME gözlerinde hemen pahalı ve invaziv anti-VEGF başlamak gereksizdir; hasta düzenli kontrole gelebiliyorsa başlangıçta GÖZLEM en rasyonel yaklaşımdır.",
        citation="Baker CW et al., JAMA 2019 [PMID: 31037295]",
        notes="Protokol V, gereksiz enjeksiyon yükünü ve sağlık harcamalarını devasa oranda azaltan en önemli çalışmadır."
    )

    pub.add_lecture_card_slide(
        title="Protokol V Kurtarma (Rescue) Tedavisi Algoritması",
        category="KLİNİK PROTOKOL",
        subtitle="Gözlem altındaki hastada ne zaman ve nasıl anti-VEGF tedavisine geçilir?",
        cards=[
            {
                "card_title": "TETİKLEYİCİ KRİTER (TRIGGER)",
                "lead": ">=5 Harf Görme Düşüşü",
                "items": [
                    "Herhangi bir takip vizitinde başlangıç görmesine göre 5 harften (1 Snellen sırası) fazla düşüş saptanması.",
                    "Örnek: 20/20'den (1.0) 20/32'ye (0.6) düşen hastada derhal kurtarma enjeksiyonu başlanır."
                ],
                "footer": "Net Fonksiyonel Kriter"
            },
            {
                "card_title": "KURTARMA YÜKLEME DOZU",
                "lead": "Aflibercept Protokolü",
                "items": [
                    "Hemen aylık Aflibercept 2.0 mg enjeksiyonu başlanır.",
                    "OCT'de fovea tamamen kuruyana veya görme 20/20'ye dönene kadar aylık devam edilir.",
                    "Stabilite sağlandıktan sonra treat-and-extend veya PRN protokolüne geçilir."
                ],
                "footer": "Standart Tedaviye Dönüş"
            },
            {
                "card_title": "HASTA SEÇİM KRİTERİ",
                "lead": "Kimler Gözlem İçin Uygun?",
                "items": [
                    "Hasta 2-3 ayda bir düzenli kontrole gelebilecek bilinçte olmalıdır.",
                    "Uyumsuz, takipten kopabilecek veya tek gözlü hastalarda gözlem yerine erken tedavi tercih edilebilir."
                ],
                "footer": "Klinik Güvenlik Eşiği"
            }
        ],
        notes="Protokol V stratejisi ancak sıkı hasta takibi ile güvenlidir."
    )

    # S80: Non-Center Involved DME (NCI-DME) — BCSC p.144 fig148
    pub.add_visual_schema_slide(
        title="Santral Tutulumsuz DMÖ (NCI-DME) Klinik Yaklaşımı",
        category="NCI-DME YÖNETİMİ",
        subtitle="Fovea merkezinin 1 mm dairesi kuru, ancak parafoveal alanda ödem ve eksüda varlığı.",
        image_path="12-Retina_and_Vitreous_2025-2026_p144_fig148.png",
        focal_points=[
            ("Anatomik Durum", "Sıvı ve kistler fovea merkezinin dışında parafoveal alandadır; santral fovea kalınlığı (CST) normaldir."),
            ("Görme Keskinliği", "Fovea tutulmadığı için hastanın görme keskinliği 1.0 (20/20) tamdır; hasta ödemi hissetmeyebilir."),
            ("Tedavi Stratejisi", "İntravitreal anti-VEGF endike DEĞİLDİR; parafoveal sızdıran mikroanevrizmalara fokal lazer veya yakın takip uygulanır.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p144_fig148.png NCI-DME'nin parafoveal yerleşimini belgeler."
    )

    pub.add_lecture_card_slide(
        title="NCI-DME'de Progresyon Riski ve Takip Stratejisi",
        category="KLİNİK YÖNETİM",
        subtitle="Santral tutulumsuz ödem ne zaman foveaya yürür ve nasıl izlenmelidir?",
        cards=[
            {
                "card_title": "MERKEZE İLERLEME RİSKİ",
                "lead": "1 Yılda %15-20 Progresyon",
                "items": [
                    "NCI-DME vakalarının yaklaşık beşte biri 1 yıl içinde fovea merkezine doğru genişleyerek CI-DME'ye dönüşür.",
                    "Özellikle foveaya <500 mikron mesafede sert eksüda halkası olan gözlerde risk çok daha yüksektir."
                ],
                "footer": "Foveal Tehdit"
            },
            {
                "card_title": "FOKAL LAZERİN YERİ",
                "lead": "Foveayı Koruyucu Bariyer",
                "items": [
                    "Fovea merkezine doğru yürüyen belirgin mikroanevrizma kümeleri varsa fokal argon veya mikropulse lazer uygulanabilir.",
                    "Lazer, sıvının fovea merkezine ulaşmasını engelleyen bir koruma hattı oluşturur."
                ],
                "footer": "Seçilmiş Vakalarda Lazer"
            },
            {
                "card_title": "TAKİP PROTOKOLÜ",
                "lead": "3-4 Ayda Bir SD-OCT",
                "items": [
                    "Her 3-4 ayda bir SD-OCT ile foveal kalınlık ve harita izlenir.",
                    "Fovea merkezinde en ufak bir sıvı saptandığında CI-DME protokolüne geçilir."
                ],
                "footer": "Erken Yakalama"
            }
        ],
        notes="NCI-DME hastalarında ana amaç ödemin fovea merkezine ulaşmasını önlemektir."
    )

    # S82: Fokal / Grid Lazerin Güncel Rolü — BCSC p.140 fig139
    pub.add_visual_schema_slide(
        title="Fokal ve Grid Lazer Fotokoagülasyonun Güncel Rolü",
        category="LAZER TEDAVİSİ",
        subtitle="ETDRS fokal koagülasyon tekniği, modern endikasyonlar ve skar genişlemesi riski.",
        image_path="12-Retina_and_Vitreous_2025-2026_p140_fig139.jpeg",
        focal_points=[
            ("Uygulama Prensibi", "Fovea merkezine 500-3000 mikron mesafedeki sızdıran mikroanevrizmalara 50-100 mikron spotla hafif beyazlatıcı atış yapılır."),
            ("Güncel Endikasyonu", "Santral tutulumsuz (NCI-DME) fokal sızıntılarda veya anti-VEGF enjeksiyon yükünü azaltmak amacıyla kombine olarak kullanılır."),
            ("Lazer Skar Genişlemesi (Laser Scar Creep)", "Yıllar içinde lazer yanıkları fovea merkezine doğru genişleyerek parasantral skotom ve RPE atrofisi yapabilir; foveaya <500 mikron yaklaşılmamalıdır.")
        ],
        notes="12-Retina_and_Vitreous_2025-2026_p140_fig139.jpeg fokal koagülasyonun fundus görünümünü belgeler."
    )

    pub.add_lecture_card_slide(
        title="Subthreshold Mikropulse (SDM) ve Navigasyonlu Lazer (Navilas)",
        category="YENİ NESİL LAZER",
        subtitle="Dokuda termal yıkım ve skar yapmadan RPE hücrelerini uyaran modern teknolojiler.",
        cards=[
            {
                "card_title": "SUBTHRESHOLD MİKROPULSE (SDM)",
                "lead": "Skar Bırakmayan Doku Dostu Lazer",
                "items": [
                    "Lazer enerjisi mikrosaniyelik paketler halinde verilir (%5-10 görev döngüsü / duty cycle).",
                    "Doku sıcaklığı koagülasyon eşiğinin altında tutulur; RPE hücreleri ölmez, ısı şok proteinleri (HSP) salgılar.",
                    "Fovea merkezine dahi güvenle uygulanabilir; oftalmoskopide hiçbir yanık izi bırakmaz."
                ],
                "footer": "Hücresel Biyostimülasyon"
            },
            {
                "card_title": "NAVİGASYONLU LAZER (NAVILAS)",
                "lead": "Göz Hareketini Takip Eden Robotik Hedefleme",
                "items": [
                    "Önceden çekilen FFA ve OCT haritaları canlı retina görüntüsüne bindirilir.",
                    "Göz takip sistemi (eye-tracker) sayesinde mikroanevrizmalara mikron düzeyinde hassas atış yapılır.",
                    "Fovea merkezine yanlışlıkla atış yapılması yazılımsal güvenlik kilidiyle imkansız hale getirilir."
                ],
                "footer": "Robotik Hassasiyet"
            },
            {
                "card_title": "KLİNİK KULLANIM YERİ",
                "lead": "Enjeksiyon Yükünü Hafifletme",
                "items": [
                    "Özellikle NCI-DME'de ve kronik anti-VEGF ihtiyacı olan hastalarda enjeksiyon aralığını uzatmak için ideal yardımcıdır.",
                    "Türkiye'de üçüncü basamak merkezlerde yaygınlaşmaktadır."
                ],
                "footer": "Kombine Tedavi Gücü"
            }
        ],
        notes="SDM ve Navilas, klasik argon lazerin foveal skar riskini tamamen ortadan kaldıran modern evrimidir."
    )

    pub.add_lecture_card_slide(
        title="DMÖ'de Tedavi Yanıtını Öngören Biyobelirteçler",
        category="TEDAVİ BİYOBELİRTEÇLERİ",
        subtitle="Başlangıç OCT bulgularına göre anti-VEGF veya steroid yanıtsızlığını tahmin etme.",
        cards=[
            {
                "card_title": "İYİ YANIT GÖSTERGELERİ",
                "lead": "Yüksek Görme Kazanım Potansiyeli",
                "items": [
                    "Foveal Elipsoid Zon (EZ) ve ELM hattının kesintisiz intakt olması.",
                    "Süngerimsi retina kalınlaşması veya küçük ayrık kistoid morfoloji.",
                    "DRIL (iç tabaka dezorganizasyonu) bulunmaması."
                ],
                "footer": "Anti-VEGF ile Yüksek Başarı"
            },
            {
                "card_title": "KÖTÜ YANIT / DİRENÇ GÖSTERGELERİ",
                "lead": "Zorlu Hasta Profili",
                "items": [
                    "Geniş foveal DRIL sahası (>500 mikron).",
                    "Foveal EZ hattında geniş kalıcı defektler.",
                    "Dev kistoid kaviteler ve subfoveal sert eksüda plakları."
                ],
                "footer": "Sınırlı Görme Artışı"
            },
            {
                "card_title": "İNFLAMATUAR PROFİL (STEROİD ADAYI)",
                "lead": "Deksametazon İmplantına Öncelik",
                "items": [
                    "Çok sayıda hiperreflektif odak (HRF >30 adet).",
                    "Eşlik eden subretinal seröz dekolman (SRD) varlığı.",
                    "Anti-VEGF ile 3-6 ayda kurumayan inatçı intraretinal sıvı."
                ],
                "footer": "Erken Switch Göstergesi"
            }
        ],
        notes="Başlangıç OCT biyobelirteçleri hastanın hangi ilaca daha iyi yanıt vereceğini belirler."
    )

    pub.add_lecture_card_slide(
        title="Erken Anti-VEGF Tedavi Yanıtsızlığı ve İnatçı Sıvı Yönetimi",
        category="DİRENÇ YÖNETİMİ",
        subtitle="İlk 3-6 aylık yükleme dozuna rağmen santral kalınlığı düşmeyen gözlerde yol haritası.",
        cards=[
            {
                "card_title": "DİRENÇ TANIMI (PROTOKOL T / PROTOKOL I)",
                "lead": "Yetersiz Anatomik Kuruma",
                "items": [
                    "En az 3-6 ardışık aylık enjeksiyona rağmen foveal kalınlıkta <%10 azalma olması.",
                    "Görme keskinliğinde iyileşme sağlanamaması ve intraretinal kistlerin sürmesi."
                ],
                "footer": "Tedavi Yanıtsızlığı Eşiği"
            },
            {
                "card_title": "SEÇENEK A: ÇİFT YOLAK BLOKAJI (FARICIMAB)",
                "lead": "Tie-2 Restorasyonu",
                "items": [
                    "VEGF direncinin arkasında yüksek Ang-2 ve perisit ayrılması yatar.",
                    "Faricimab'a geçiş (switch) ile inatçı sıvının hızla kurutulması sağlanabilir (YOSEMITE/RHINE)."
                ],
                "footer": "Birinci Tercih Switch"
            },
            {
                "card_title": "SEÇENEK B: STEROİD İMPLANT (OZURDEX)",
                "lead": "Geniş Spektrumlu İnflamatuar Blokaj",
                "items": [
                    "Özellikle psödofakik gözlerde veya vitrektomili gözlerde Deksametazon implantı çok üstündür.",
                    "Katarakt ve GİB takibi yapılmak kaydıyla dirençli sıvıyı güçlü biçimde kurutur."
                ],
                "footer": "İkinci Tercih Switch"
            }
        ],
        notes="İnatçı sıvıda aynı anti-VEGF ilacında ısrar etmek yerine etki mekanizmasını değiştirmek (switch) modern kılavuzların önerisidir."
    )

    pub.add_lecture_card_slide(
        title="Bölüm 4 Özeti: DMÖ Tanı ve Protokol V Klinik Karar Matrisi",
        category="BÖLÜM 4 ÖZETİ",
        subtitle="Bölüm 1'den 4'e kadar olan Modül I müfredatının özet sentezi ve Modül II'ye geçiş.",
        cards=[
            {
                "card_title": "CI-DME & İYİ GÖRME (>=20/25)",
                "lead": "Protokol V Zaferi",
                "items": [
                    "Başlangıçta GÖZLEM (tedavisiz izlem).",
                    "Hastaların %66'sı 2 yıl enjeksiyonsuz görmesini tam korur.",
                    "Görme >=5 harf düşerse hemen Aflibercept kurtarma protokolü başlanır."
                ],
                "footer": "Gereksiz İğneden Kaçınma"
            },
            {
                "card_title": "CI-DME & DÜŞÜK GÖRME (<=20/32)",
                "lead": "Agresif Anti-VEGF Başlangıcı",
                "items": [
                    "Aylık anti-VEGF yükleme dozu (Protokol T standardı).",
                    "Başlangıç görmesi zayıfsa Aflibercept veya Faricimab ile başlamak üstündür."
                ],
                "footer": "Hızlı Görme Kurtarma"
            },
            {
                "card_title": "NCI-DME (SANTRAL TUTULUMSUZ)",
                "lead": "Foveayı Koruma Hattı",
                "items": [
                    "Anti-VEGF uygulanmaz; parafoveal fokal lazer veya 3 ayda bir SD-OCT takibi yapılır.",
                    "Modül I tamamlandı; Modül II'de büyük anti-VEGF çalışmalarını (Protokol T/I/S/W, Faricimab, Aflibercept 8mg) inceleyeceğiz."
                ],
                "footer": "Modül II'ye Geçiş"
            }
        ],
        notes="Modül I (Bölüm 1 - 4) başarıyla tamamlandı. Toplam 86 slayt ve 55'ten fazla yüksek çözünürlüklü görsel entegre edildi."
    )