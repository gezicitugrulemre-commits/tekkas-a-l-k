"""
docling_pdf_extractor.py — Docling tabanlı yapısal medikal PDF şekil ve panel çıkarıcı.

Özellikler:
- PDF belgelerinden şekilleri, panelleri ve ilişkili özgün altyazıları yapılandırılmış olarak çıkarır.
- Sayfadaki ilk altyazıyı körlemesine tüm görsellere bağlamaz; yapısal/konumsal eşleşme uygular.
- A/B/C panelleri net ayrılamıyorsa bütün şekli korur ve panel_mapping="review_required" olarak işaretler.
- Her kayıt için: doc_sha256, pdf_page, printed_page, figure_id, panel_id, bbox, coord_system,
  original_caption, caption_location, extracted_image_path, image_sha256, modality, review_status='review_required'.
- Docling kütüphanesini öncelikli kullanır; Docling veya model ağırlıkları erişilemezse fitz (PyMuPDF) yapısal motoruyla geri çekilir.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image

log = logging.getLogger("docling_pdf_extractor")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

MODALITY_KEYWORDS = {
    "OCT B-scan": ["oct", "sd-oct", "swept-source oct", "ss-oct", "spectral-domain oct", "b-scan", "cross-sectional oct"],
    "OCTA": ["octa", "oct angiography", "optik koherens tomografi anjiyografi"],
    "FA": ["fluorescein angiography", "fa", "fundus fluorescein", "ffa", "erken faz", "geç faz", "hiperfloresans", "hipofloresans"],
    "ICGA": ["icga", "indocyanine green", "indosiyanin yeşili"],
    "FAF": ["fundus autofluorescence", "faf", "otofloresans", "autofluorescence"],
    "fundus": ["fundus photograph", "color fundus", "renkli fundus", "fundus görünümü", "retina photograph"],
    "histology": ["histology", "histopathology", "biopsy", "h&e", "light microscopy", "elektron mikroskopi"],
    "teaching_schematic": ["schematic", "diagram", "şema", "çizim", "illustration", "flowchart", "algoritma"],
}

DISEASE_KEYWORDS = {
    "crao": ["crao", "central retinal artery occlusion", "santral retinal arter"],
    "crvo": ["crvo", "central retinal vein occlusion", "santral retinal ven"],
    "brao": ["brao", "branch retinal artery occlusion"],
    "brvo": ["brvo", "branch retinal vein occlusion", "dal retinal ven"],
    "arn": ["arn", "acute retinal necrosis", "akut retinal nekroz"],
    "cmv": ["cmv", "cytomegalovirus", "sitomegalovir"],
    "toxoplasmosis": ["toxoplasm", "toksoplazm"],
    "stargardt": ["stargardt", "abca4"],
    "best": ["best vitelliform", "best1", "bestrophin", "vitelliform makula"],
    "npdr": ["npdr", "nonproliferative diabetic", "non-proliferatif"],
    "pdr": ["pdr", "proliferative diabetic", "proliferatif"],
    "dme": ["dme", "dmö", "diabetic macular edema", "diyabetik makula ödem"],
    "rp": ["retinitis pigmentosa", "retinitis pigmentoza"],
}


def compute_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def detect_modality_from_text(text: str) -> str:
    text_lower = text.lower()
    for mod, kws in MODALITY_KEYWORDS.items():
        if any(re.search(r"\b" + re.escape(kw) + r"\b", text_lower) for kw in kws):
            return mod
    return "unknown"


def detect_disease_ids(text: str) -> List[str]:
    text_lower = text.lower()
    found = []
    for dis, kws in DISEASE_KEYWORDS.items():
        if any(re.search(r"\b" + re.escape(kw) + r"\b", text_lower) for kw in kws):
            found.append(dis)
    return sorted(list(set(found)))


class DoclingFigureExtractor:
    """
    Docling ve PyMuPDF hibrit yapısal çıkarıcı.
    """

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.images_dir = self.output_dir / "images"
        self.images_dir.mkdir(parents=True, exist_ok=True)

    def extract_from_pdf(
        self,
        pdf_path: Path,
        *,
        pages: Optional[List[int]] = None,
        max_pages: Optional[int] = None,
        source_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        pdf_path = Path(pdf_path)
        if not pdf_path.is_file():
            raise FileNotFoundError(f"PDF bulunamadı: {pdf_path}")

        doc_hash = compute_sha256(pdf_path)
        doc_id = source_id or pdf_path.stem

        # Önce Docling kütüphanesini dene
        try:
            return self._extract_via_docling(pdf_path, doc_id, doc_hash, pages=pages, max_pages=max_pages)
        except Exception as exc:
            log.warning("Docling doğrudan çalıştırılamadı (%s). Yapısal PyMuPDF fallback motoru devreye giriyor.", exc)
            return self._extract_via_pymupdf(pdf_path, doc_id, doc_hash, pages=pages, max_pages=max_pages)

    def _extract_via_docling(
        self,
        pdf_path: Path,
        doc_id: str,
        doc_hash: str,
        *,
        pages: Optional[List[int]] = None,
        max_pages: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        from docling.document_converter import DocumentConverter, PdfFormatOption
        from docling.datamodel.pipeline_options import PdfPipelineOptions
        from docling.datamodel.base_models import InputFormat
        from docling_core.types.doc import PictureItem

        pipeline_options = PdfPipelineOptions()
        pipeline_options.generate_picture_images = True
        pipeline_options.do_ocr = False  # Hızlı ve deterministik

        converter = DocumentConverter(
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)}
        )

        convert_kwargs: Dict[str, Any] = {}
        if pages:
            convert_kwargs["page_range"] = (min(pages), max(pages))
        elif max_pages:
            convert_kwargs["max_num_pages"] = max_pages

        conv_res = converter.convert(pdf_path, **convert_kwargs)
        doc = conv_res.document

        records = []
        fig_idx = 0

        for item, _level in doc.iterate_items():
            if isinstance(item, PictureItem):
                fig_idx += 1
                page_no = 1
                bbox_list = [0.0, 0.0, 100.0, 100.0]
                coord_sys = "unknown"

                if hasattr(item, "prov") and item.prov:
                    p = item.prov[0]
                    page_no = getattr(p, "page_no", 1)
                    if hasattr(p, "bbox"):
                        b = p.bbox
                        bbox_list = [b.l, b.t, b.r, b.b]
                        coord_sys = str(getattr(b, "coord_origin", "unknown"))

                if pages and page_no not in pages:
                    continue
                if max_pages and page_no > max_pages:
                    continue

                # Görseli dışa aktar
                pil_img = item.get_image(doc)
                if pil_img is None:
                    continue

                fig_id = f"fig_{page_no}_{fig_idx}"
                out_name = f"{doc_id}_p{page_no}_{fig_id}.png"
                out_path = self.images_dir / out_name
                pil_img.convert("RGB").save(out_path, format="PNG")
                img_hash = compute_sha256(out_path)

                # Caption yakalama
                caption_text = item.caption_text(doc) if callable(getattr(item, "caption_text", None)) else ""
                caption_refs = [getattr(ref, "cref", str(ref)) for ref in getattr(item, "captions", [])]

                modality = detect_modality_from_text(caption_text)
                disease_ids = detect_disease_ids(caption_text)

                record = {
                    "document_id": doc_id,
                    "doc_sha256": doc_hash,
                    "source_id": doc_id,
                    "page": page_no,
                    "printed_page": None,
                    "figure_id": fig_id,
                    "panel_id": None,
                    "bbox": bbox_list,
                    "coord_system": coord_sys,
                    "scale": None,
                    "original_caption": caption_text.strip(),
                    "caption_location": caption_refs,
                    "page_size": str(getattr(doc.pages.get(page_no), "size", "unknown")),
                    "path": str(out_path.resolve()),
                    "image_sha256": img_hash,
                    "modality": modality,
                    "disease_ids": disease_ids,
                    "extraction_engine": "docling_2.x",
                    "review_status": "review_required",
                    "reviewer": None,
                    "panel_mapping": "review_required",
                }
                records.append(record)

        return records

    def _extract_via_pymupdf(
        self,
        pdf_path: Path,
        doc_id: str,
        doc_hash: str,
        *,
        pages: Optional[List[int]] = None,
        max_pages: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Deterministik, yapısal PyMuPDF motoru. Sayfa geometrisine ve
        resim–altyazı yakınlığına göre eşleştirir.
        """
        import fitz

        doc = fitz.open(str(pdf_path))
        records = []
        fig_counter = 0

        total_pages = len(doc)
        page_indices = range(total_pages)
        if pages:
            page_indices = [p - 1 for p in pages if 1 <= p <= total_pages]
        elif max_pages:
            page_indices = range(min(max_pages, total_pages))

        for p_idx in page_indices:
            page = doc[p_idx]
            page_num = p_idx + 1

            # Sayfadaki tüm resim nesnelerini ve konumlarını topla
            image_infos = page.get_images(full=True)
            page_text_blocks = page.get_text("blocks")

            # Altyazı bloklarını filtrele (Fig., Şekil, Resim ile başlayanlar)
            caption_candidates = []
            for blk in page_text_blocks:
                b_text = blk[4].strip()
                if re.match(r"^(?:Figure|Fig\.|Şekil|Resim)\s*[\d\.\-]+", b_text, re.IGNORECASE):
                    caption_candidates.append({
                        "rect": fitz.Rect(blk[:4]),
                        "text": b_text,
                    })

            for img_info in image_infos:
                xref = img_info[0]
                base_img = doc.extract_image(xref)
                if not base_img:
                    continue

                w, h = base_img["width"], base_img["height"]
                # Çok küçük ikonları veya çizgileri filtrele
                if w < 120 or h < 120:
                    continue

                fig_counter += 1
                img_bytes = base_img["image"]
                ext = base_img["ext"]

                # Resmin sayfadaki koordinatını bul
                img_rects = page.get_image_rects(xref)
                bbox_list = [0.0, 0.0, float(w), float(h)]
                matched_caption = ""
                caption_loc = "unknown"

                if img_rects:
                    r = img_rects[0]
                    bbox_list = [round(r.x0, 2), round(r.y0, 2), round(r.x1, 2), round(r.y1, 2)]

                    # Bu resme en yakın altyazıyı bul (genelde hemen altında veya yanında)
                    closest_dist = float("inf")
                    for cap in caption_candidates:
                        c_rect = cap["rect"]
                        # Dikey mesafe (altyazı resmin altında)
                        if c_rect.y0 >= r.y0 - 20 and min(c_rect.x1, r.x1) > max(c_rect.x0, r.x0):
                            dist = abs(c_rect.y0 - r.y1)
                            if dist < closest_dist and dist <= 72:
                                closest_dist = dist
                                matched_caption = cap["text"]
                                caption_loc = f"p{page_num}_rect_{round(c_rect.y0, 1)}"

                # Eğer doğrudan altyazı yoksa sayfadaki ilk altyazıyı KÖRÜ KÖRÜNE BAĞLAMA!
                # Açıkça boş bırak veya yakınlık eşiği aşılmışsa tespit edilemedi de
                if not matched_caption and caption_candidates:
                    caption_loc = "unmatched_on_page"

                fig_id = f"fig_{page_num}_{fig_counter:03d}"
                out_name = f"{doc_id}_p{page_num}_{fig_id}.png"
                out_path = self.images_dir / out_name

                # PNG olarak kaydet
                with open(out_path, "wb") as f_out:
                    f_out.write(img_bytes)

                # RGB formatını sağla
                try:
                    with Image.open(out_path) as im:
                        im.convert("RGB").save(out_path, format="PNG")
                except Exception:
                    pass

                img_sha256 = compute_sha256(out_path)
                modality = detect_modality_from_text(matched_caption)
                disease_ids = detect_disease_ids(matched_caption)

                # Panel analizi: A, B, C panel harfleri altyazıda var mı?
                panel_match = re.search(r"\b([A-D])\b[:\.\s]", matched_caption)
                panel_id = None  # Caption letters do not establish which pixels belong to a panel.

                record = {
                    "document_id": doc_id,
                    "doc_sha256": doc_hash,
                    "source_id": doc_id,
                    "page": page_num,
                    "printed_page": None,
                    "figure_id": fig_id,
                    "panel_id": panel_id,
                    "bbox": bbox_list,
                    "coord_system": "top-left (points)",
                    "scale": 1.0,
                    "original_caption": matched_caption.strip(),
                    "caption_location": caption_loc,
                    "path": str(out_path.resolve()),
                    "image_sha256": img_sha256,
                    "modality": modality,
                    "disease_ids": disease_ids,
                    "extraction_engine": "pymupdf_structural",
                    "review_status": "review_required",
                    "reviewer": None,
                    "panel_mapping": "review_required" if not panel_id else "single_panel",
                }
                records.append(record)

        return records


def build_docling_registry(
    pdf_paths: List[Path],
    output_registry_path: Path,
    output_images_dir: Path,
    *,
    pages_per_pdf: Optional[List[int]] = None,
    max_pages: Optional[int] = 5,
) -> Dict[str, Any]:
    extractor = DoclingFigureExtractor(output_images_dir)
    all_records = []

    for p in pdf_paths:
        if not p.is_file():
            continue
        recs = extractor.extract_from_pdf(p, pages=pages_per_pdf, max_pages=max_pages)
        all_records.extend(recs)

    # Registry sözlüğü (kategori veya topic bazlı gruplama desteği)
    registry_data = {
        "title": "Docling & Structural High-Precision Retina Figure Registry",
        "version": "2.0-docling",
        "total_records": len(all_records),
        "records": all_records,
    }

    output_registry_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_registry_path, "w", encoding="utf-8") as f:
        json.dump(registry_data, f, ensure_ascii=False, indent=2)

    log.info("Docling registry başarıyla oluşturuldu: %s (%d kayıt)", output_registry_path, len(all_records))
    return registry_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Docling Medikal PDF Yapısal Şekil Çıkarıcı")
    parser.add_argument("pdf", type=Path, help="İşlenecek PDF dosyası")
    parser.add_argument("--out-dir", type=Path, default=Path("assets/docling_catalog"), help="Çıktı dizini")
    parser.add_argument("--max-pages", type=int, default=5, help="İşlenecek maksimum sayfa")
    args = parser.parse_args()

    reg_path = args.out_dir / "docling_retina_registry.json"
    build_docling_registry([args.pdf], reg_path, args.out_dir, max_pages=args.max_pages)
