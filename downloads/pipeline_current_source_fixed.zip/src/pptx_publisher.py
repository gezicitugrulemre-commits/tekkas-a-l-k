"""
pptx_publisher.py — Akademik ve Klinik Çalışma Odaklı PowerPoint Dizgi Motoru
Görsel, Akış Şeması, Karar Ağacı ve Aktif Hatırlama Odaklı 16:9 Geniş Ekran Sunum/Çalışma Atlası.

Gelişmiş Özellikler:
1. 16:9 Geniş Ekran (13.333" x 7.5" Widescreen).
2. Görsel ve Akış Şeması Ağırlığı:
   - Adım Adım Cerrahi ve Klinik Süreç Akışları (Horizontal Process Flow with Connectors)
   - Karar Ağaçları ve Algoritma Şemaları (Branching Decision Trees: EVET/HAYIR Dalları)
   - Dinamik Mermaid Akış Şeması Derleyicisi (Mermaid Flowchart to Native PPTX Shapes & Diamonds)
   - Karşılaştırmalı Yan Yana Klinik Kartlar (Split Diagnostic/Procedural Cards)
   - Yüksek Çözünürlüklü Şematik Panel Entegrasyonu (PIL / Vektörel Görseller)
   - Büyük Veri ve RKÇ Metrik Kartları (Landmark Trials KPI Cards)
3. Layout Triage & Bilişsel Yük Geometri Denetçisi (PPTAgent / LangGraph Auditor Standartlarında):
   - Slayt geometri taşmaları (overflow), kutu içi aşırı metin yoğunluğu ve konuşmacı notları denetimi.
4. Bilişsel Yük Yönetimi & Konuşmacı Notları (Speaker Notes):
   - Slayt yüzeyinde gereksiz metin yığını engellenir; temiz, şematik ve odaklı kalır.
   - Derin literatür (AAO BCSC, Wills Eye), PubMed kanıtları ([PMID:...]),
     hasta düzeyi vs göz düzeyi istatistiksel dipnotlar ve GEE modelleri doğrudan konuşmacı notlarına yazılır.
5. Aktif Hatırlama ve Vaka Kartları (Case-Based Flashcards):
   - Slayt A: Vaka Senaryosu + Klinik Soru + İpuçları
   - Slayt B: Gerekçeli Rasyonel + Neden Diğer Seçenekler Elendi? + Klinik İnci
"""

from __future__ import annotations

import os
import sys
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

# Terminal UTF-8
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


# ==========================================
# 1. KURUMSAL VE TIBBİ RENK PALETİ
# ==========================================

class PPTXPalette:
    NAVY = RGBColor(20, 47, 67)          # #142f43 - Başlıklar, Ana Çerçeveler
    BLUE = RGBColor(28, 91, 166)         # #1c5ba6 - Birincil Vurgu, Süreç Adımları
    LIGHT_BLUE = RGBColor(237, 244, 255) # #edf4ff - Zemin Dolguları
    GREEN = RGBColor(8, 125, 108)        # #087d6c - Kanıt, Doğru Seçenek, Güvenli Dal
    LIGHT_GREEN = RGBColor(234, 248, 242)# #eaf8f2
    AMBER = RGBColor(164, 97, 9)         # #a46109 - Dikkat, Kritik İnci, Uyarı
    LIGHT_AMBER = RGBColor(255, 245, 223)# #fff5df
    RED = RGBColor(185, 28, 28)          # #b91c1c - Acil, Kontrendikasyon, Tuzak
    LIGHT_RED = RGBColor(254, 242, 242)  # #fef2f2
    PURPLE = RGBColor(105, 65, 165)      # #6941a5 - Vaka, Mnemonic, Ayırıcı Tanı
    LIGHT_PURPLE = RGBColor(244, 239, 252)# #f4effc
    WHITE = RGBColor(255, 255, 255)
    BG_CANVAS = RGBColor(248, 250, 252)  # #f8fafc - Slayt Arka Planı
    MUTED = RGBColor(71, 97, 116)        # #476174 - Alt Başlıklar, Meta Bilgi
    LINE = RGBColor(205, 220, 232)       # #cddce8 - İnce Kenarlıklar
    DARK_CARD = RGBColor(15, 23, 42)     # #0f172a - Koyu Vurgu Kartları
    TEXT_MAIN = RGBColor(20, 47, 67)     # Metin


# ==========================================
# 2. PPTX STUDY PUBLISHER MOTORU
# ==========================================

class PPTXStudyPublisher:
    """
    Klinik ve cerrahi konuları yüksek görsel/akış şemalı PowerPoint çalışma setine dönüştüren dizgi sınıfı.
    """

    def __init__(self, title: str, subtitle: str, author: str = "Akademik Çalışma Ortağı"):
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        self.blank_layout = self.prs.slide_layouts[6]
        self.deck_title = title
        self.deck_subtitle = subtitle
        self.author = author

    # ----------------------------------------------------
    # Temel Yardımcı Metotlar
    # ----------------------------------------------------

    def _apply_slide_background(self, slide, bg_color: RGBColor = PPTXPalette.BG_CANVAS):
        """Slayta temiz kurumsal zemin ekler."""
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = bg_color
        bg.line.fill.background()

    def _add_slide_header(
        self,
        slide,
        title: str,
        category: str = "KLİNİK ÇALIŞMA MODÜLÜ",
        subtitle: Optional[str] = None,
        category_color: RGBColor = PPTXPalette.BLUE,
        category_bg: RGBColor = PPTXPalette.LIGHT_BLUE
    ):
        """Standart kurumsal başlık, kategori rozeti ve alt başlık bandı ekler."""
        # Kategori Rozeti (Pill)
        pill = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(0.4), Inches(3.2), Inches(0.35))
        pill.fill.solid()
        pill.fill.fore_color.rgb = category_bg
        pill.line.color.rgb = category_color
        pill.line.width = Pt(1)
        tf = pill.text_frame
        tf.word_wrap = False
        p = tf.paragraphs[0]
        p.text = f"●  {category.upper()}"
        p.font.name = "Arial"
        p.font.size = Pt(9.5)
        p.font.bold = True
        p.font.color.rgb = category_color
        p.alignment = PP_ALIGN.CENTER

        # Ana Başlık
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.8), Inches(11.7), Inches(0.6))
        tf_t = title_box.text_frame
        tf_t.word_wrap = True
        p_t = tf_t.paragraphs[0]
        p_t.text = title
        p_t.font.name = "Arial"
        p_t.font.size = Pt(20)
        p_t.font.bold = True
        p_t.font.color.rgb = PPTXPalette.NAVY

        # Varsa Alt Başlık
        if subtitle:
            sub_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.35), Inches(11.7), Inches(0.35))
            tf_s = sub_box.text_frame
            tf_s.word_wrap = True
            p_s = tf_s.paragraphs[0]
            p_s.text = subtitle
            p_s.font.name = "Arial"
            p_s.font.size = Pt(11)
            p_s.font.color.rgb = PPTXPalette.MUTED

        # İnce Bölücü Çizgi
        sep = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.7), Inches(11.733), Inches(0.02))
        sep.fill.solid()
        sep.fill.fore_color.rgb = PPTXPalette.LINE
        sep.line.fill.background()

        # Alt Bilgi (Footer)
        footer = slide.shapes.add_textbox(Inches(0.8), Inches(7.1), Inches(11.733), Inches(0.3))
        tf_f = footer.text_frame
        p_f = tf_f.paragraphs[0]
        p_f.text = f"{self.deck_title}  |  {self.author}  ·  16:9 Görsel Çalışma Atlası"
        p_f.font.name = "Arial"
        p_f.font.size = Pt(8.5)
        p_f.font.color.rgb = PPTXPalette.MUTED

    def _set_speaker_notes(self, slide, notes_text: str):
        """Slayda derin akademik, metodolojik ve PubMed referanslı konuşmacı notlarını gömer."""
        if not notes_text:
            return
        notes_slide = slide.notes_slide
        tf = notes_slide.notes_text_frame
        tf.text = notes_text.strip()

    # ----------------------------------------------------
    # 1. KAPAK VE PROTOKOL SLAYTI
    # ----------------------------------------------------

    def add_cover_slide(
        self,
        metadata_rows: List[Tuple[str, str]],
        notes: str = ""
    ):
        """Büyük kurumsal kapak ve protokol parametreleri slaytı."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide, PPTXPalette.WHITE)

        # Üst Lacivert Banner
        banner = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(2.6))
        banner.fill.solid()
        banner.fill.fore_color.rgb = PPTXPalette.NAVY
        banner.line.fill.background()

        # Kicker
        kicker_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.35), Inches(11.7), Inches(0.4))
        p_k = kicker_box.text_frame.paragraphs[0]
        p_k.text = "AKADEMİK ÇALIŞMA ORTAĞI  |  İLERİ DÜZEY OFTALMOLOJİ ATLASI"
        p_k.font.name = "Arial"
        p_k.font.size = Pt(11)
        p_k.font.bold = True
        p_k.font.color.rgb = RGBColor(219, 234, 254)

        # Ana Başlık
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.75), Inches(11.7), Inches(0.9))
        p_t = title_box.text_frame.paragraphs[0]
        p_t.text = self.deck_title
        p_t.font.name = "Arial"
        p_t.font.size = Pt(28)
        p_t.font.bold = True
        p_t.font.color.rgb = PPTXPalette.WHITE

        # Alt Başlık
        sub_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.7), Inches(11.7), Inches(0.6))
        p_s = sub_box.text_frame.paragraphs[0]
        p_s.text = self.deck_subtitle
        p_s.font.name = "Arial"
        p_s.font.size = Pt(13)
        p_s.font.color.rgb = RGBColor(226, 232, 240)

        # Protokol Tablosu (Alt Kısım)
        left = Inches(0.8)
        top = Inches(2.9)
        width = Inches(11.733)
        height = Inches(3.9)

        rows = len(metadata_rows) + 1
        cols = 2
        table_shape = slide.shapes.add_table(rows, cols, left, top, width, height)
        table = table_shape.table
        table.columns[0].width = Inches(3.2)
        table.columns[1].width = Inches(8.533)

        # Tablo Başlığı
        table.cell(0, 0).fill.solid()
        table.cell(0, 0).fill.fore_color.rgb = PPTXPalette.BLUE
        p0 = table.cell(0, 0).text_frame.paragraphs[0]
        p0.text = "Protokol & Metodolojik Parametre"
        p0.font.name = "Arial"
        p0.font.size = Pt(10)
        p0.font.bold = True
        p0.font.color.rgb = PPTXPalette.WHITE

        table.cell(0, 1).fill.solid()
        table.cell(0, 1).fill.fore_color.rgb = PPTXPalette.BLUE
        p1 = table.cell(0, 1).text_frame.paragraphs[0]
        p1.text = "Akademik Kapsam ve Kanıt Tabanı"
        p1.font.name = "Arial"
        p1.font.size = Pt(10)
        p1.font.bold = True
        p1.font.color.rgb = PPTXPalette.WHITE

        for idx, (param, val) in enumerate(metadata_rows):
            row_idx = idx + 1
            bg_c = PPTXPalette.LIGHT_BLUE if idx % 2 == 0 else PPTXPalette.WHITE
            
            c0 = table.cell(row_idx, 0)
            c0.fill.solid()
            c0.fill.fore_color.rgb = bg_c
            p = c0.text_frame.paragraphs[0]
            p.text = param
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.bold = True
            p.font.color.rgb = PPTXPalette.NAVY

            c1 = table.cell(row_idx, 1)
            c1.fill.solid()
            c1.fill.fore_color.rgb = bg_c
            p = c1.text_frame.paragraphs[0]
            p.text = val
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN

        self._set_speaker_notes(slide, notes or f"Protokol: {self.deck_title}\n{self.deck_subtitle}")

    # ----------------------------------------------------
    # 2. YATAY SÜREÇ VE AKIŞ ŞEMASI SLAYTI (HORIZONTAL PROCESS FLOW)
    # ----------------------------------------------------

    def add_horizontal_flowchart_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        steps: List[Dict[str, str]],
        alert_box: Optional[Dict[str, str]] = None,
        notes: str = ""
    ):
        """
        Adım adım cerrahi veya klinik karar akışını gösteren yatay akış şeması.
        Her adım: Numara, Başlık, Cerrahi Eylem, Patofizyolojik/Klinik Gerekçe.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        num_steps = len(steps)
        canvas_width = 11.733
        gap = 0.25
        card_w = (canvas_width - ((num_steps - 1) * gap)) / num_steps
        card_h = 3.6 if alert_box else 4.8
        top_y = Inches(1.9)

        for i, step in enumerate(steps):
            x = Inches(0.8 + i * (card_w + gap))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1.2)

            # Adım Üst Başlık Şeridi
            badge_h = Inches(0.55)
            badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), badge_h)
            badge.fill.solid()
            badge_color = PPTXPalette.BLUE if i < num_steps - 1 else PPTXPalette.GREEN
            badge.fill.fore_color.rgb = badge_color
            badge.line.fill.background()

            tf_b = badge.text_frame
            tf_b.word_wrap = True
            p_b = tf_b.paragraphs[0]
            p_b.text = f"ADIM {i+1} : {step.get('short_tag', '')}"
            p_b.font.name = "Arial"
            p_b.font.size = Pt(10)
            p_b.font.bold = True
            p_b.font.color.rgb = PPTXPalette.WHITE
            p_b.alignment = PP_ALIGN.CENTER

            # Adım İçeriği
            content_box = slide.shapes.add_textbox(x + Inches(0.12), top_y + Inches(0.65), Inches(card_w - 0.24), Inches(card_h - 0.75))
            tf_c = content_box.text_frame
            tf_c.word_wrap = True

            p_title = tf_c.paragraphs[0]
            p_title.text = step.get("title", "")
            p_title.font.name = "Arial"
            p_title.font.size = Pt(11)
            p_title.font.bold = True
            p_title.font.color.rgb = PPTXPalette.NAVY
            p_title.space_after = Pt(6)

            p_act = tf_c.add_paragraph()
            p_act.text = f"▶ Eylem: {step.get('action', '')}"
            p_act.font.name = "Arial"
            p_act.font.size = Pt(9.5)
            p_act.font.bold = True
            p_act.font.color.rgb = PPTXPalette.BLUE
            p_act.space_after = Pt(5)

            p_desc = tf_c.add_paragraph()
            p_desc.text = step.get("rationale", "")
            p_desc.font.name = "Arial"
            p_desc.font.size = Pt(9)
            p_desc.font.color.rgb = PPTXPalette.TEXT_MAIN
            p_desc.space_after = Pt(5)

            if "pearl" in step:
                p_p = tf_c.add_paragraph()
                p_p.text = f"★ İnci: {step['pearl']}"
                p_p.font.name = "Arial"
                p_p.font.size = Pt(8.5)
                p_p.font.color.rgb = PPTXPalette.AMBER

            # Araya Bağlantı Oku (Son adım hariç)
            if i < num_steps - 1:
                arrow_x = x + Inches(card_w) + Inches(0.04)
                arrow_y = top_y + Inches(card_h / 2) - Inches(0.15)
                arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, arrow_x, arrow_y, Inches(gap - 0.08), Inches(0.3))
                arrow.fill.solid()
                arrow.fill.fore_color.rgb = PPTXPalette.BLUE
                arrow.line.fill.background()

        # Varsa Alt Uyarı Kartı
        if alert_box:
            alert_y = Inches(5.65)
            ab = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), alert_y, Inches(11.733), Inches(1.25))
            ab.fill.solid()
            bg_col = PPTXPalette.LIGHT_RED if alert_box.get("type") == "danger" else PPTXPalette.LIGHT_AMBER
            border_col = PPTXPalette.RED if alert_box.get("type") == "danger" else PPTXPalette.AMBER
            ab.fill.fore_color.rgb = bg_col
            ab.line.color.rgb = border_col
            ab.line.width = Pt(1.2)

            tf_a = ab.text_frame
            tf_a.word_wrap = True
            pa1 = tf_a.paragraphs[0]
            pa1.text = f"⚠️ {alert_box.get('title', 'Kritik Cerrahi ve Klinik Emniyet Uyarısı')}"
            pa1.font.name = "Arial"
            pa1.font.size = Pt(11)
            pa1.font.bold = True
            pa1.font.color.rgb = border_col
            pa1.space_after = Pt(3)

            pa2 = tf_a.add_paragraph()
            pa2.text = alert_box.get("text", "")
            pa2.font.name = "Arial"
            pa2.font.size = Pt(9.5)
            pa2.font.color.rgb = PPTXPalette.NAVY

        self._set_speaker_notes(slide, notes)

    # ----------------------------------------------------
    # 3. KARAR AĞACI VE ALGORİTMA SLAYTI (BRANCHING DECISION TREE)
    # ----------------------------------------------------

    def add_decision_tree_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        root_trigger: Dict[str, str],
        branch_a: Dict[str, Any],  # Yeşil/Uygun Yol (EVET)
        branch_b: Dict[str, Any],  # Kırmızı/Riskli Yol (HAYIR/Alternatif)
        golden_rule: str,
        notes: str = ""
    ):
        """
        Klinik ikilemlerde 'Eğer X ise A protokolü, Eğer Y ise B protokolü' karar ağacı.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # 1. Kök Olay Kutusu (Üst Merkez)
        root = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(3.4), Inches(1.85), Inches(6.5), Inches(0.85))
        root.fill.solid()
        root.fill.fore_color.rgb = PPTXPalette.NAVY
        root.line.color.rgb = PPTXPalette.BLUE
        root.line.width = Pt(1.5)

        tf_r = root.text_frame
        tf_r.word_wrap = True
        pr1 = tf_r.paragraphs[0]
        pr1.text = root_trigger.get("title", "")
        pr1.font.name = "Arial"
        pr1.font.size = Pt(11)
        pr1.font.bold = True
        pr1.font.color.rgb = PPTXPalette.WHITE
        pr1.alignment = PP_ALIGN.CENTER

        pr2 = tf_r.add_paragraph()
        pr2.text = root_trigger.get("desc", "")
        pr2.font.name = "Arial"
        pr2.font.size = Pt(9)
        pr2.font.color.rgb = RGBColor(226, 232, 240)
        pr2.alignment = PP_ALIGN.CENTER

        # 2. Sol Dal (Dal A - Yeşil / EVET / Tercih Edilen)
        branch_w = Inches(5.6)
        branch_h = Inches(3.4)
        top_branch = Inches(2.95)

        card_a = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_branch, branch_w, branch_h)
        card_a.fill.solid()
        card_a.fill.fore_color.rgb = PPTXPalette.LIGHT_GREEN
        card_a.line.color.rgb = PPTXPalette.GREEN
        card_a.line.width = Pt(1.5)

        tf_a = card_a.text_frame
        tf_a.word_wrap = True
        pa_hdr = tf_a.paragraphs[0]
        pa_hdr.text = f"✔ {branch_a.get('condition', 'DURUM A (EVET / UYGUN)')}"
        pa_hdr.font.name = "Arial"
        pa_hdr.font.size = Pt(11.5)
        pa_hdr.font.bold = True
        pa_hdr.font.color.rgb = PPTXPalette.GREEN
        pa_hdr.space_after = Pt(6)

        for step in branch_a.get("actions", []):
            p = tf_a.add_paragraph()
            p.text = f"• {step}"
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.NAVY
            p.space_after = Pt(4)

        if "outcome" in branch_a:
            p_out = tf_a.add_paragraph()
            p_out.text = f"🎯 Sonuç: {branch_a['outcome']}"
            p_out.font.name = "Arial"
            p_out.font.size = Pt(9)
            p_out.font.bold = True
            p_out.font.color.rgb = PPTXPalette.GREEN

        # 3. Sağ Dal (Dal B - Amber/Kırmızı / HAYIR / Alternatif / Komplikasyon)
        card_b = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.933), top_branch, branch_w, branch_h)
        card_b.fill.solid()
        card_b.fill.fore_color.rgb = PPTXPalette.LIGHT_AMBER
        card_b.line.color.rgb = PPTXPalette.AMBER
        card_b.line.width = Pt(1.5)

        tf_b = card_b.text_frame
        tf_b.word_wrap = True
        pb_hdr = tf_b.paragraphs[0]
        pb_hdr.text = f"⚠ {branch_b.get('condition', 'DURUM B (HAYIR / YETERSİZ DESTEK)')}"
        pb_hdr.font.name = "Arial"
        pb_hdr.font.size = Pt(11.5)
        pb_hdr.font.bold = True
        pb_hdr.font.color.rgb = PPTXPalette.AMBER
        pb_hdr.space_after = Pt(6)

        for step in branch_b.get("actions", []):
            p = tf_b.add_paragraph()
            p.text = f"• {step}"
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.NAVY
            p.space_after = Pt(4)

        if "contraindications" in branch_b:
            p_con = tf_b.add_paragraph()
            p_con.text = f"⛔ KONTRENDİKE: {branch_b['contraindications']}"
            p_con.font.name = "Arial"
            p_con.font.size = Pt(9)
            p_con.font.bold = True
            p_con.font.color.rgb = PPTXPalette.RED

        # 4. Altın Kural Şeridi (En Alt)
        golden = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(6.45), Inches(11.733), Inches(0.55))
        golden.fill.solid()
        golden.fill.fore_color.rgb = PPTXPalette.NAVY
        golden.line.fill.background()

        tf_g = golden.text_frame
        tf_g.word_wrap = True
        pg = tf_g.paragraphs[0]
        pg.text = f"💡 ALTIN KLİNİK İLKE: {golden_rule}"
        pg.font.name = "Arial"
        pg.font.size = Pt(10)
        pg.font.bold = True
        pg.font.color.rgb = RGBColor(254, 240, 138)
        pg.alignment = PP_ALIGN.CENTER

        self._set_speaker_notes(slide, notes)

    # ----------------------------------------------------
    # 3B. MERMAID AKIŞ ŞEMASI DERLEYİCİSİ (YEREL DÜZENLENEBİLİR ŞEKİLLER)
    # ----------------------------------------------------

    def add_mermaid_flowchart_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        mermaid_code: str,
        notes: str = ""
    ):
        """
        Mermaid akış şeması kodunu doğrudan yerel, düzenlenebilir PowerPoint şekillerine,
        karar elmaslarına (diamond) ve renkli bağlantı oklarına dönüştürür.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # Mermaid Ayrıştırıcı
        lines = [l.strip() for l in mermaid_code.strip().splitlines() if l.strip()]
        if lines and lines[0].startswith("flowchart"):
            lines = lines[1:]

        nodes: Dict[str, Dict[str, Any]] = {}
        edges: List[Dict[str, str]] = []

        def extract_node(token: str):
            token = token.strip()
            m_diam = re.match(r"^([A-Za-z0-9_]+)\s*\{(.*?)\}$", token)
            if m_diam:
                return m_diam.group(1), m_diam.group(2).strip(), "diamond"
            m_rect = re.match(r"^([A-Za-z0-9_]+)\s*\[(.*?)\]$", token)
            if m_rect:
                return m_rect.group(1), m_rect.group(2).strip(), "rect"
            m_rnd = re.match(r"^([A-Za-z0-9_]+)\s*\((.*?)\)$", token)
            if m_rnd:
                return m_rnd.group(1), m_rnd.group(2).strip(), "round"
            m_id = re.match(r"^([A-Za-z0-9_]+)$", token)
            if m_id:
                return m_id.group(1), None, "rect"
            return None, None, None

        edge_pattern = re.compile(r"^(.*?)\s*-->\s*(?:\|(.*?)\|\s*)?(.*?)$")
        for line in lines:
            m = edge_pattern.match(line)
            if m:
                left_tok, edge_lbl, right_tok = m.group(1), m.group(2) or "", m.group(3)
                src_id, src_lbl, src_type = extract_node(left_tok)
                dst_id, dst_lbl, dst_type = extract_node(right_tok)
                if src_id:
                    if src_id not in nodes or src_lbl:
                        nodes[src_id] = {"label": src_lbl or nodes.get(src_id, {}).get("label", src_id), "type": src_type}
                if dst_id:
                    if dst_id not in nodes or dst_lbl:
                        nodes[dst_id] = {"label": dst_lbl or nodes.get(dst_id, {}).get("label", dst_id), "type": dst_type}
                if src_id and dst_id:
                    edges.append({"from": src_id, "to": dst_id, "label": edge_lbl.strip()})
            else:
                nid, nlbl, ntype = extract_node(line)
                if nid:
                    nodes[nid] = {"label": nlbl or nid, "type": ntype}

        if not nodes:
            return

        # Düğüm Seviyelerini (Rank) BFS ile Hesapla
        in_deg = {nid: 0 for nid in nodes}
        adj = {nid: [] for nid in nodes}
        edge_map = {}
        for e in edges:
            src, dst, lbl = e["from"], e["to"], e.get("label", "")
            if src in adj and dst in in_deg:
                adj[src].append(dst)
                in_deg[dst] += 1
                edge_map[(src, dst)] = lbl

        ranks = {}
        queue = [nid for nid, deg in in_deg.items() if deg == 0]
        if not queue:
            queue = [list(nodes.keys())[0]]

        for q in queue:
            ranks[q] = 0

        visited = set(queue)
        while queue:
            curr = queue.pop(0)
            curr_r = ranks[curr]
            for nbr in adj.get(curr, []):
                ranks[nbr] = max(ranks.get(nbr, 0), curr_r + 1)
                if nbr not in visited:
                    visited.add(nbr)
                    queue.append(nbr)

        levels: Dict[int, List[str]] = {}
        for nid, r in ranks.items():
            levels.setdefault(r, []).append(nid)

        canvas_top = Inches(1.85)
        canvas_h = Inches(4.7)
        total_lvls = len(levels)
        row_h = canvas_h / max(total_lvls, 1)

        node_shapes = {}

        for r in sorted(levels.keys()):
            row_nodes = levels[r]
            n_count = len(row_nodes)
            row_y = canvas_top + (r * row_h) + Inches(0.08)

            card_w = Inches(3.8) if n_count == 1 else Inches(min(4.2, 11.2 / n_count - 0.4))
            card_h = Inches(0.85)
            gap = (Inches(11.733) - (card_w * n_count)) / (n_count + 1)

            for i, nid in enumerate(row_nodes):
                x = Inches(0.8) + gap + (i * (card_w + gap))
                node_data = nodes[nid]
                ntype = node_data.get("type", "rect")
                lbl = node_data.get("label", nid)

                # Şekil Tipi
                shape_t = MSO_SHAPE.DIAMOND if ntype == "diamond" else MSO_SHAPE.ROUNDED_RECTANGLE
                sh = slide.shapes.add_shape(shape_t, x, row_y, card_w, card_h)
                sh.fill.solid()

                # Karar veya Sonuç Durumuna Göre Renkler
                if ntype == "diamond":
                    sh.fill.fore_color.rgb = PPTXPalette.AMBER
                    sh.line.color.rgb = PPTXPalette.NAVY
                    text_col = PPTXPalette.WHITE
                elif any("evet" in edge_map.get((p, nid), "").lower() for p in nodes):
                    sh.fill.fore_color.rgb = PPTXPalette.LIGHT_GREEN
                    sh.line.color.rgb = PPTXPalette.GREEN
                    text_col = PPTXPalette.GREEN
                elif any("hayır" in edge_map.get((p, nid), "").lower() for p in nodes):
                    sh.fill.fore_color.rgb = PPTXPalette.LIGHT_RED
                    sh.line.color.rgb = PPTXPalette.RED
                    text_col = PPTXPalette.RED
                elif r == 0:
                    sh.fill.fore_color.rgb = PPTXPalette.NAVY
                    sh.line.color.rgb = PPTXPalette.BLUE
                    text_col = PPTXPalette.WHITE
                else:
                    sh.fill.fore_color.rgb = PPTXPalette.WHITE
                    sh.line.color.rgb = PPTXPalette.BLUE
                    text_col = PPTXPalette.NAVY

                sh.line.width = Pt(1.5)
                tf = sh.text_frame
                tf.word_wrap = True
                p = tf.paragraphs[0]
                p.text = lbl
                p.font.name = "Arial"
                p.font.size = Pt(10)
                p.font.bold = True
                p.font.color.rgb = text_col
                p.alignment = PP_ALIGN.CENTER

                node_shapes[nid] = (x, row_y, card_w, card_h)

        # Oklar ve Bağlantı Rozetleri
        for e in edges:
            src, dst, lbl = e["from"], e["to"], e.get("label", "")
            if src in node_shapes and dst in node_shapes:
                x1, y1, w1, h1 = node_shapes[src]
                x2, y2, w2, h2 = node_shapes[dst]

                arrow_x = (x1 + w1/2 + x2 + w2/2) / 2 - Inches(0.12)
                arrow_y = y1 + h1 + Inches(0.02)
                arrow_h = max(Inches(0.15), (y2 - (y1 + h1)) - Inches(0.08))

                arr_col = PPTXPalette.GREEN if "evet" in lbl.lower() else (PPTXPalette.RED if "hayır" in lbl.lower() else PPTXPalette.BLUE)
                arrow = slide.shapes.add_shape(MSO_SHAPE.DOWN_ARROW, arrow_x, arrow_y, Inches(0.24), arrow_h)
                arrow.fill.solid()
                arrow.fill.fore_color.rgb = arr_col
                arrow.line.fill.background()

                if lbl:
                    tag_w = Inches(1.8)
                    tag_h = Inches(0.28)
                    tag_x = arrow_x + Inches(0.3)
                    tag_y = arrow_y + (arrow_h / 2) - Inches(0.14)
                    tag = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, tag_x, tag_y, tag_w, tag_h)
                    tag.fill.solid()
                    tag.fill.fore_color.rgb = PPTXPalette.WHITE
                    tag.line.color.rgb = arr_col
                    tag.line.width = Pt(1)
                    p_tag = tag.text_frame.paragraphs[0]
                    p_tag.text = lbl
                    p_tag.font.name = "Arial"
                    p_tag.font.size = Pt(8.5)
                    p_tag.font.bold = True
                    p_tag.font.color.rgb = arr_col
                    p_tag.alignment = PP_ALIGN.CENTER

        self._set_speaker_notes(slide, notes or f"Mermaid Akış Şeması Slaytı: {title}")

    # ----------------------------------------------------
    # 4. YAN YANA KARŞILAŞTIRMALI TANI/İŞLEM SLAYTI (SPLIT COMPARISON)
    # ----------------------------------------------------

    def add_split_comparison_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        left_entity: Dict[str, Any],
        right_entity: Dict[str, Any],
        bottom_takeaway: str,
        notes: str = ""
    ):
        """
        TASS vs Endoftalmi veya Standart vs Reverse Optic Capture gibi yan yana karşılaştırma kartı.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        w = Inches(5.7)
        h = Inches(4.35)
        top_y = Inches(1.9)

        # Sol Kart
        card_l = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, w, h)
        card_l.fill.solid()
        card_l.fill.fore_color.rgb = PPTXPalette.WHITE
        card_l.line.color.rgb = PPTXPalette.BLUE
        card_l.line.width = Pt(1.5)

        banner_l = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, w, Inches(0.55))
        banner_l.fill.solid()
        banner_l.fill.fore_color.rgb = PPTXPalette.BLUE
        banner_l.line.fill.background()
        pl = banner_l.text_frame.paragraphs[0]
        pl.text = left_entity.get("name", "TABLO A").upper()
        pl.font.name = "Arial"
        pl.font.size = Pt(11)
        pl.font.bold = True
        pl.font.color.rgb = PPTXPalette.WHITE
        pl.alignment = PP_ALIGN.CENTER

        tf_l = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.65), w - Inches(0.3), h - Inches(0.75)).text_frame
        tf_l.word_wrap = True
        for idx, (label, val) in enumerate(left_entity.get("features", [])):
            p = tf_l.paragraphs[0] if idx == 0 else tf_l.add_paragraph()
            p.text = f"• {label}: {val}"
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN
            p.space_after = Pt(4)

        # Sağ Kart
        card_r = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.833), top_y, w, h)
        card_r.fill.solid()
        card_r.fill.fore_color.rgb = PPTXPalette.WHITE
        card_r.line.color.rgb = PPTXPalette.RED
        card_r.line.width = Pt(1.5)

        banner_r = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.833), top_y, w, Inches(0.55))
        banner_r.fill.solid()
        banner_r.fill.fore_color.rgb = PPTXPalette.RED
        banner_r.line.fill.background()
        pr = banner_r.text_frame.paragraphs[0]
        pr.text = right_entity.get("name", "TABLO B").upper()
        pr.font.name = "Arial"
        pr.font.size = Pt(11)
        pr.font.bold = True
        pr.font.color.rgb = PPTXPalette.WHITE
        pr.alignment = PP_ALIGN.CENTER

        tf_r = slide.shapes.add_textbox(Inches(6.983), top_y + Inches(0.65), w - Inches(0.3), h - Inches(0.75)).text_frame
        tf_r.word_wrap = True
        for idx, (label, val) in enumerate(right_entity.get("features", [])):
            p = tf_r.paragraphs[0] if idx == 0 else tf_r.add_paragraph()
            p.text = f"• {label}: {val}"
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN
            p.space_after = Pt(4)

        # Alt Özet Bandı
        bot = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(6.35), Inches(11.733), Inches(0.65))
        bot.fill.solid()
        bot.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
        bot.line.color.rgb = PPTXPalette.BLUE
        bot.line.width = Pt(1.2)
        pb = bot.text_frame.paragraphs[0]
        pb.text = f"⚡ AYIRICI TANI KRİTERİ: {bottom_takeaway}"
        pb.font.name = "Arial"
        pb.font.size = Pt(10)
        pb.font.bold = True
        pb.font.color.rgb = PPTXPalette.BLUE
        pb.alignment = PP_ALIGN.CENTER

        self._set_speaker_notes(slide, notes)

    # ----------------------------------------------------
    # 5. YÜKSEK ÇÖZÜNÜRLÜKLÜ ŞEMA VE ANATOMİK PANEL SLAYTI
    # ----------------------------------------------------

    def add_visual_schema_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        image_path: Path | str,
        focal_points: List[Tuple[str, str]],
        notes: str = ""
    ):
        """
        Sol tarafta 1600x620 PIL şematik çizimi, sağ tarafta cerrahi odak noktaları kartları.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        img_p = Path(image_path)
        img_w = Inches(6.8)
        img_h = Inches(4.9)
        top_y = Inches(1.9)

        if img_p.exists():
            slide.shapes.add_picture(str(img_p), Inches(0.8), top_y, width=img_w)
        else:
            fb = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), top_y, img_w, img_h)
            fb.fill.solid()
            fb.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
            fb.line.color.rgb = PPTXPalette.BLUE
            p = fb.text_frame.paragraphs[0]
            p.text = f"[Şema Bulunamadı: {img_p.name}]"
            p.font.name = "Arial"
            p.font.color.rgb = PPTXPalette.NAVY

        # Sağ Panel: Cerrahi/Anatomik İnce Noktalar
        right_x = Inches(7.8)
        right_w = Inches(4.733)
        num_focal = len(focal_points)
        card_h = (4.9 - ((num_focal - 1) * 0.15)) / num_focal

        for i, (fp_title, fp_desc) in enumerate(focal_points):
            y = top_y + Inches(i * (card_h + 0.15))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, right_w, Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1)

            badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, Inches(0.12), Inches(card_h))
            badge.fill.solid()
            badge.fill.fore_color.rgb = PPTXPalette.BLUE
            badge.line.fill.background()

            tf = slide.shapes.add_textbox(right_x + Inches(0.2), y + Inches(0.08), right_w - Inches(0.3), Inches(card_h - 0.15)).text_frame
            tf.word_wrap = True

            p1 = tf.paragraphs[0]
            p1.text = f"{i+1}. {fp_title}"
            p1.font.name = "Arial"
            p1.font.size = Pt(10)
            p1.font.bold = True
            p1.font.color.rgb = PPTXPalette.BLUE
            p1.space_after = Pt(2)

            p2 = tf.add_paragraph()
            p2.text = fp_desc
            p2.font.name = "Arial"
            p2.font.size = Pt(8.5)
            p2.font.color.rgb = PPTXPalette.TEXT_MAIN

        self._set_speaker_notes(slide, notes)

    # ----------------------------------------------------
    # 6. RKÇ & BÜYÜK VERİ KANIT KARTLARI SLAYTI (LANDMARK TRIALS KPI)
    # ----------------------------------------------------

    def add_trials_kpi_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        metrics: List[Dict[str, str]],
        notes: str = ""
    ):
        """
        EUREQUO, PREMED, EVS gibi büyük klinik çalışmaların can alıcı istatistiki bulgularını gösteren KPI kartları.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        num_cards = len(metrics)
        card_w = (11.733 - ((num_cards - 1) * 0.25)) / num_cards
        card_h = 4.8
        top_y = Inches(1.9)

        for i, m in enumerate(metrics):
            x = Inches(0.8 + i * (card_w + 0.25))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1.2)

            tf = card.text_frame
            tf.word_wrap = True

            p_trial = tf.paragraphs[0]
            p_trial.text = m.get("study", "ÇALIŞMA").upper()
            p_trial.font.name = "Arial"
            p_trial.font.size = Pt(11)
            p_trial.font.bold = True
            p_trial.font.color.rgb = PPTXPalette.BLUE
            p_trial.alignment = PP_ALIGN.CENTER
            p_trial.space_after = Pt(8)

            p_num = tf.add_paragraph()
            p_num.text = m.get("big_num", "")
            p_num.font.name = "Arial"
            p_num.font.size = Pt(28)
            p_num.font.bold = True
            p_num.font.color.rgb = PPTXPalette.NAVY
            p_num.alignment = PP_ALIGN.CENTER
            p_num.space_after = Pt(6)

            p_lbl = tf.add_paragraph()
            p_lbl.text = m.get("label", "")
            p_lbl.font.name = "Arial"
            p_lbl.font.size = Pt(10)
            p_lbl.font.bold = True
            p_lbl.font.color.rgb = PPTXPalette.MUTED
            p_lbl.alignment = PP_ALIGN.CENTER
            p_lbl.space_after = Pt(10)

            p_desc = tf.add_paragraph()
            p_desc.text = m.get("finding", "")
            p_desc.font.name = "Arial"
            p_desc.font.size = Pt(9)
            p_desc.font.color.rgb = PPTXPalette.TEXT_MAIN
            p_desc.space_after = Pt(8)

            if "citation" in m:
                p_cite = tf.add_paragraph()
                p_cite.text = m["citation"]
                p_cite.font.name = "Arial"
                p_cite.font.size = Pt(8.5)
                p_cite.font.bold = True
                p_cite.font.color.rgb = PPTXPalette.BLUE
                p_cite.alignment = PP_ALIGN.CENTER

        self._set_speaker_notes(slide, notes)

    # ----------------------------------------------------
    # 7. AKTİF HATIRLAMA / VAKA SINAVI SLAYTI (FLASHCARD SYSTEM)
    # ----------------------------------------------------

    def add_active_recall_case_slide(
        self,
        case_id: str,
        case_title: str,
        presentation: str,
        question: str,
        options: List[str],
        notes: str = ""
    ):
        """Vaka Sorusu Slaytı: Kullanıcıya düşünme alanı tanır (Cevap bu slaytta yer almaz)."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(
            slide,
            f"Vaka {case_id}: {case_title}",
            category="AKTİF HATIRLAMA & KLİNİK SINAV",
            subtitle="Klinik senaryoyu analiz et, kararını ver ve bir sonraki slaytta gerekçeli çözümünü incele.",
            category_color=PPTXPalette.PURPLE,
            category_bg=PPTXPalette.LIGHT_PURPLE
        )

        top_y = Inches(1.9)

        # Sol Panel: Hasta Sunumu
        left_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(5.6), Inches(4.8))
        left_card.fill.solid()
        left_card.fill.fore_color.rgb = PPTXPalette.WHITE
        left_card.line.color.rgb = PPTXPalette.PURPLE
        left_card.line.width = Pt(1.5)

        banner = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(5.6), Inches(0.5))
        banner.fill.solid()
        banner.fill.fore_color.rgb = PPTXPalette.PURPLE
        banner.line.fill.background()
        p = banner.text_frame.paragraphs[0]
        p.text = "👁 HASTA SUNUMU VE ANAMNEZ"
        p.font.name = "Arial"
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = PPTXPalette.WHITE
        p.alignment = PP_ALIGN.CENTER

        tf_pres = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.6), Inches(5.3), Inches(4.0)).text_frame
        tf_pres.word_wrap = True
        p_txt = tf_pres.paragraphs[0]
        p_txt.text = presentation
        p_txt.font.name = "Arial"
        p_txt.font.size = Pt(10)
        p_txt.font.color.rgb = PPTXPalette.TEXT_MAIN

        # Sağ Panel: Klinik Soru ve Seçenekler
        right_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.8), top_y, Inches(5.733), Inches(4.8))
        right_card.fill.solid()
        right_card.fill.fore_color.rgb = PPTXPalette.LIGHT_PURPLE
        right_card.line.color.rgb = PPTXPalette.PURPLE
        right_card.line.width = Pt(1.5)

        tf_q = slide.shapes.add_textbox(Inches(7.0), top_y + Inches(0.2), Inches(5.333), Inches(4.4)).text_frame
        tf_q.word_wrap = True

        pq = tf_q.paragraphs[0]
        pq.text = f"❓ SORU: {question}"
        pq.font.name = "Arial"
        pq.font.size = Pt(11)
        pq.font.bold = True
        pq.font.color.rgb = PPTXPalette.NAVY
        pq.space_after = Pt(10)

        for opt in options:
            p = tf_q.add_paragraph()
            p.text = opt
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.NAVY
            p.space_after = Pt(6)

        p_hint = tf_q.add_paragraph()
        p_hint.text = "👉 Kararını verdikten sonra sonraki slayta geçerek rasyoneli kontrol et."
        p_hint.font.name = "Arial"
        p_hint.font.size = Pt(9)
        p_hint.font.bold = True
        p_hint.font.color.rgb = PPTXPalette.PURPLE

        self._set_speaker_notes(slide, notes or f"Vaka {case_id} Soru Slaytı")

    def add_active_recall_solution_slide(
        self,
        case_id: str,
        case_title: str,
        correct_answer: str,
        rationale: str,
        distractors_analysis: List[Tuple[str, str]],
        clinical_pearl: str,
        notes: str = ""
    ):
        """Vaka Çözüm Slaytı: Doğru cevabı, çeldiricilerin analizi ve klinik inciyi sunar."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(
            slide,
            f"Vaka {case_id} Çözümü: {case_title}",
            category="GEREKÇELİ CEVAP ANAHTARI & RASYONEL",
            subtitle="AAO BCSC, Wills Eye ve landmark çalışmaların doğrulanmış rasyoneli.",
            category_color=PPTXPalette.GREEN,
            category_bg=PPTXPalette.LIGHT_GREEN
        )

        top_y = Inches(1.9)

        # 1. Doğru Cevap Kutusu (Üst Bant)
        ans_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(11.733), Inches(0.95))
        ans_box.fill.solid()
        ans_box.fill.fore_color.rgb = PPTXPalette.LIGHT_GREEN
        ans_box.line.color.rgb = PPTXPalette.GREEN
        ans_box.line.width = Pt(1.5)

        tf_ans = ans_box.text_frame
        tf_ans.word_wrap = True
        p1 = tf_ans.paragraphs[0]
        p1.text = f"✔ DOĞRU YAKLAŞIM: {correct_answer}"
        p1.font.name = "Arial"
        p1.font.size = Pt(12)
        p1.font.bold = True
        p1.font.color.rgb = PPTXPalette.GREEN
        p1.space_after = Pt(2)

        p2 = tf_ans.add_paragraph()
        p2.text = f"Rasyonel: {rationale}"
        p2.font.name = "Arial"
        p2.font.size = Pt(9.5)
        p2.font.color.rgb = PPTXPalette.NAVY

        # 2. Çeldiricilerin Elenme Nedenleri (Orta Panel)
        dist_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(3.0), Inches(11.733), Inches(2.5))
        dist_box.fill.solid()
        dist_box.fill.fore_color.rgb = PPTXPalette.WHITE
        dist_box.line.color.rgb = PPTXPalette.LINE
        dist_box.line.width = Pt(1)

        tf_d = slide.shapes.add_textbox(Inches(0.95), Inches(3.1), Inches(11.4), Inches(2.3)).text_frame
        tf_d.word_wrap = True
        pd_h = tf_d.paragraphs[0]
        pd_h.text = "❌ DİĞER SEÇENEKLER NEDEN YANLIŞTI? (ÇELDİRİCİ ANALİZİ)"
        pd_h.font.name = "Arial"
        pd_h.font.size = Pt(10)
        pd_h.font.bold = True
        pd_h.font.color.rgb = PPTXPalette.RED
        pd_h.space_after = Pt(4)

        for opt_lbl, why_wrong in distractors_analysis:
            p = tf_d.add_paragraph()
            p.text = f"• {opt_lbl}: {why_wrong}"
            p.font.name = "Arial"
            p.font.size = Pt(9)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN
            p.space_after = Pt(3)

        # 3. Klinik İnci ve Sınav Uyarısı (Alt Şerit)
        pearl = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(5.65), Inches(11.733), Inches(1.2))
        pearl.fill.solid()
        pearl.fill.fore_color.rgb = PPTXPalette.LIGHT_AMBER
        pearl.line.color.rgb = PPTXPalette.AMBER
        pearl.line.width = Pt(1.5)

        tf_p = pearl.text_frame
        tf_p.word_wrap = True
        pp1 = tf_p.paragraphs[0]
        pp1.text = "💡 KLİNİK İNCİ VE PRATİK TUZAK"
        pp1.font.name = "Arial"
        pp1.font.size = Pt(10.5)
        pp1.font.bold = True
        pp1.font.color.rgb = PPTXPalette.AMBER
        pp1.space_after = Pt(2)

        pp2 = tf_p.add_paragraph()
        pp2.text = clinical_pearl
        pp2.font.name = "Arial"
        pp2.font.size = Pt(9.5)
        pp2.font.color.rgb = PPTXPalette.NAVY

        self._set_speaker_notes(slide, notes or f"Vaka {case_id} Çözüm Notları")

    # ----------------------------------------------------
    # 8. LAYOUT TRIAGE VE GEOMETRİ DENETÇİSİ (AUDITOR)
    # ----------------------------------------------------

    def audit_slide_deck_layout(self) -> Dict[str, Any]:
        """
        Slaytların geometri sınırlarını, metin kutusu taşmalarını ve bilişsel yükünü denetler.
        PPTAgent ve LangGraph Auditor kalite standartlarını doğrular.
        """
        max_w = self.prs.slide_width
        max_h = self.prs.slide_height

        report = {
            "total_slides": len(self.prs.slides),
            "overflow_issues": [],
            "density_warnings": [],
            "missing_notes": [],
            "passed": True
        }

        for idx, slide in enumerate(self.prs.slides, 1):
            for shape in slide.shapes:
                # 1. Geometri & Taşma Kontrolü
                try:
                    r_edge = shape.left + shape.width
                    b_edge = shape.top + shape.height
                    if r_edge > (max_w + Inches(0.15)) or b_edge > (max_h + Inches(0.15)):
                        report["overflow_issues"].append(
                            f"Slayt {idx}: Şekil sınır dışına taştı ({getattr(shape, 'name', 'Shape')})"
                        )
                except Exception:
                    pass

                # 2. Metin Yoğunluğu (Bilişsel Yük) Kontrolü
                if shape.has_text_frame:
                    words = len(shape.text_frame.text.split())
                    if words > 140:
                        report["density_warnings"].append(
                            f"Slayt {idx}: Kutu içi kelime sayısı yüksek ({words} kelime). Bilişsel yük uyarısı."
                        )

            # 3. Konuşmacı Notları
            notes = ""
            try:
                if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                    notes = slide.notes_slide.notes_text_frame.text.strip()
            except Exception:
                pass

            if not notes:
                report["missing_notes"].append(f"Slayt {idx}: Konuşmacı notu (literatür/kanıt) eksik.")

        if report["overflow_issues"]:
            report["passed"] = False

        return report

    # ----------------------------------------------------
    # 9. ÇIKTIYI KAYDETME
    # ----------------------------------------------------

    def save(self, output_path: Path | str) -> Path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(str(out))
        print(f" -> PowerPoint Çalışma Seti Başarıyla Üretildi: {out.name} ({len(self.prs.slides)} Slayt)")
        return out


# ==========================================
# 3. KATARAKT CERRAHİSİ KOMPLİKASYONLARI İÇİN TAM ÇALIŞMA SETİ OLUŞTURUCU
# ==========================================

def build_cataract_complications_deck(output_pptx_path: Path | str) -> Path:
    """
    Katarakt Cerrahisi Komplikasyonları için zengin akış şemalı, karar ağaçlı, Mermaid motorlu ve aktif hatırlama vaka setli
    tam PowerPoint çalışma destesi oluşturur.
    """
    publisher = PPTXStudyPublisher(
        title="KATARAKT CERRAHİSİ KOMPLİKASYONLARI VE YÖNETİMİ",
        subtitle="AAO BCSC Section 11, Wills Eye Manual & Landmark RKÇ (EUREQUO, PREMED, EVS) Görsel Atlası",
        author="Akademik Çalışma Ortağı (LangGraph Pipeline)"
    )

    assets_dir = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity\assets")
    schema_1 = assets_dir / "schema_1_vitrectomy.png"
    schema_2 = assets_dir / "schema_2_yamane.png"
    schema_3 = assets_dir / "schema_3_optic_capture.png"
    schema_4 = assets_dir / "schema_4_tass_endo.png"

    # ----------------------------------------------------
    # SLAYT 1: KAPAK VE PROTOKOL METAVERİLERİ
    # ----------------------------------------------------
    publisher.add_cover_slide(
        metadata_rows=[
            ("Birincil Veritabanı", "AAO BCSC 2023-2024 Section 11 (Lens & Cataract, Bölüm 10 ve 11); Wills Eye Manual (8. Baskı) [BCSC-11:157-230]"),
            ("PubMed Landmark Kanıt", "EUREQUO Kayıtları (2.8M Olgu), ESCRS PREMED Study (Report 1-2), EVS Trial, Yamane ISHF Trial [PMID: 30122345, 17531689, 28457674]"),
            ("Metodolojik Çerçeve", "Hasta Düzeyi (Patient-Level) vs Göz Düzeyi (Eye-Level) İntra-class Korelasyon Ayrımı, GEE ve Mixed-Effects Regresyon"),
            ("Görsel Panel Kapsamı", "16:9 Geniş Ekran · 4 Adet Yüksek Çözünürlüklü Şematik Panel · 7 Klinik Karar Ağacı ve Süreç Akışı · 10 Aktif Hatırlama Vaka Kartı"),
        ],
        notes=(
            "Katarakt Cerrahisi Komplikasyonları ve Yönetimi Çalışma Atlası.\n"
            "Veritabanı: AAO BCSC 2023-2024 Section 11 & Wills Eye Manual 8th Ed.\n"
            "İstatistiki Kural: İki göz verisi içeren kohortlarda GEE (Generalized Estimating Equations) veya "
            "Linear Mixed Models kullanımı şarttır; bağımsız varsayılan t-testleri Tip I hataya yol açar."
        )
    )

    # ----------------------------------------------------
    # SLAYT 2: MERMAID DİNAMİK AKIŞ ŞEMASI — PCR VE SULKUS/YAMANE KARARI
    # ----------------------------------------------------
    mermaid_pcr = """
    flowchart TD
      A[Fako Sırasında PCR Şüphesi] --> B[Fako Ucunu ASLA Çekme! Pozisyon 1]
      B --> C[Yan Girişten Dispersif OVD Ver]
      C --> D{Ön Kapsüloreksis İntakt mı?}
      D -->|Evet / 360 Sulkus Desteği| E[Sulkusa 3 Parçalı GİL + Optic Capture]
      D -->|Hayır / Kapsül Desteği Yok| F[Yamane 30G Çift İğneli ISHF Protokolü]
    """
    publisher.add_mermaid_flowchart_slide(
        title="Dinamik Karar Algoritması: PCR Anında Cerrahi Yol Ayrımı",
        category="DİNAMİK ŞEMA MOTORU (MERMAID TO PPTX)",
        subtitle="Mermaid akış şeması sözdiziminden üretilen yerel vektörel karar düğümleri ve bağlantı okları.",
        mermaid_code=mermaid_pcr,
        notes=(
            "Mermaid Motoru ile Üretilen Dinamik Cerrahi Karar Ağacı.\n"
            "PCR anında en kritik refleks fako ucunu çıkarmadan önce göz içi basıncını korumak için OVD vermektir.\n"
            "Kapsül desteği analiz edilir: 360 derece ön kapsüloreksis intaktsa sulkus GİL + optic capture birincil seçenektir.\n"
            "Ön kapsül yırtılmışsa Yamane ISHF altın standarttır."
        )
    )

    # ----------------------------------------------------
    # SLAYT 3: YATAY SÜREÇ AKIŞ ŞEMASI — PCR İNTRAOPERATİF ACİL PROTOKOLÜ
    # ----------------------------------------------------
    publisher.add_horizontal_flowchart_slide(
        title="Arka Kapsül Yırtılması (PCR) ve Vitreus Kaybında Adım Adım Protokol",
        category="BÖLÜM 1: İNTRAOPERATİF ACİL YÖNETİM",
        subtitle="Fakoemülsifikasyon sırasında PCR tespit edildiğinde ilk 60 saniyelik cerrahi manevralar dizisi.",
        steps=[
            {
                "short_tag": "DUR VE TAMPONLA",
                "title": "Fako Ucunu ASLA Aniden Çekme!",
                "action": "Ayak pedalını Pozisyon 1'e al. Yan girişten dispersif viskoelastik (OVD) enjekte et.",
                "rationale": "Fako ucunu aniden çekmek ön kamara basıncını sıfırlar; vitreus hızla öne hücum eder ve defekt büyür.",
                "pearl": "Ön kamarayı viskoelastikle doldurmadan aleti çekmek nükleusun düşmesine sebep olur."
            },
            {
                "short_tag": "VİTREKTOMİ AYARI",
                "title": "Bimanual Pars Plana / Korneal Vitrektomi",
                "action": "Koaksiyel vitrektomiden kaçın. Ayrı infüzyon ve vitrektom ucu kullan. Yüksek kesim hızı (3000-5000 cpm), düşük vakum.",
                "rationale": "Yüksek kesim hızı vitreus traksiyonunu minimize eder. Kesici açıklığı daima yukarı bakmalıdır.",
                "pearl": "Korneal insizyondan yapılan kaba kör çekmeler retina yırtığı ve dekolmanına yol açar."
            },
            {
                "short_tag": "TRİAMSİNOLON",
                "title": "Korunmuş Triamsinolon ile Boyama",
                "action": "Korumasız/yıkanmış triamsinolon (Triesence) enjekte ederek şeffaf vitreus bantlarını görünür kıl.",
                "rationale": "Vitreus şeffaftır; insizyon ağzında kalan mikroskopik vitreus iplikleri kronik KMÖ ve endoftalmi riskidir.",
                "pearl": "Triamsinolon partikülleri vitreusa yapışarak 'kar yağışı' görüntüsü verir."
            },
            {
                "short_tag": "GİL SEÇİMİ",
                "title": "Kapsül Desteğine Göre GİL Kararı",
                "action": "İntakt ön kapsül varsa Sulkusa 3 parçalı GİL + Optic Capture; destek yoksa Yamane ISHF.",
                "rationale": "Tek parçalı akrilik GİL sulkusa ASLA konulamaz (UGH sendromu riski).",
                "pearl": "Rule of 9s ile sulkus gücü düzeltilmelidir (+0.5 ila +1.5 D düşülür)."
            }
        ],
        alert_box={
            "type": "danger",
            "title": "KESİNLİKLE KONTRENDİKE EYLEMLER (RED FLAGS)",
            "text": "1. PCR varlığında nükleusu döndürmek için hidrodiseksiyon yapmak (nükleusu doğrudan vitreusa düşürür).\n"
                   "2. Tek parçalı (single-piece) akrilik GİL'i sulkusa implante etmek (kronik UGH sendromu, hifema ve sekonder glokom).\n"
                   "3. Ön kamara vitreusla doluyken fakoemülsifikasyona devam etmek (dev retina yırtığı ve dev diyaliz)."
        },
        notes=(
            "Arka Kapsül Yırtılması (PCR) Protokolü.\n"
            "Kaynak: AAO BCSC Section 11, s. 160-170.\n"
            "EUREQUO Kayıtları (2.8 Milyon Olgu): Ortalama PCR oranı %1.1'dir. Deneyimli cerrahlarda %0.39'a gerilemiştir.\n"
            "En yüksek rölatif risk: Kornea opasiteleri (OR: 3.2), beyaz/matür katarakt (OR: 2.8), PEX ve küçük pupilla.\n"
            "[PMID: 29703417] [BCSC-11:162]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 4: GÖRSEL ŞEMA — BİMANUAL ÖN VİTREKTOMİ PANELİ
    # ----------------------------------------------------
    publisher.add_visual_schema_slide(
        title="Bimanual Ön Vitrektomi ve Triamsinolon Boyama Biyomekaniği",
        category="BÖLÜM 1: ŞEMATİK CERRAHİ PANEL",
        subtitle="İnfüzyon ve kesici uç ayrımı, vitreus traksiyonunu önlemenin yegane altın kuralıdır.",
        image_path=schema_1,
        focal_points=[
            ("Bimanual Ayrım", "İnfüzyon kanülü yan girişten, vitrektom probu zıt yan girişten veya pars planadan girer. Sıvı vitreusu itmez."),
            ("Yüksek Kesim / Düşük Vakum", "3000-5000 cpm kesim hızı. Kesim yapmadan emme yapılmaz (vakum vitreus traksiyonu oluşturur)."),
            ("Triamsinolon Asit (Triesence)", "Koruyucusuz triamsinolon ile ön kamara yıkanır; vitreus iplikleri beyaz kar fırtınası şeklinde boyanır."),
            ("İnsizyon Ağzı Kontrolü", "Ameliyat sonunda insizyon ağzı ve yan girişler Weck-Cel süngerle kontrol edilir; vitreus sıkışması sıfırlanır.")
        ],
        notes=(
            "Şema 1 Açıklaması: Bimanual ön vitrektomi mimarisi.\n"
            "Koaksiyel vitrektomi probu kullanıldığında infüzyon sıvısı vitreusu defektin içine doğru iter ve "
            "yırtığı genişletir. Bimanual yaklaşımda infüzyon akımı vitreustan bağımsızdır.\n"
            "[BCSC-11:165] [Wills Eye Manual: Cataract Complications]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 5: KARAR AĞACI — SULKUS GİL vs YAMANE ISHF SEÇİMİ
    # ----------------------------------------------------
    publisher.add_decision_tree_slide(
        title="Kapsül Desteği Yetersiz Gözde Sekonder GİL Seçim Algoritması",
        category="BÖLÜM 2: DÜŞEN NÜKLEUS VE SEKONDER GİL",
        subtitle="Ön kapsüloreksis bütünlüğü ve zonüler desteğe göre cerrahi yol ayrımı.",
        root_trigger={
            "title": "KAPSÜL VE ZONÜL DESTEĞİNİN İNTRAOPERATİF DEĞERLENDİRİLMESİ",
            "desc": "PCR veya zonülolizis sonrası kalan kapsül dokusu ne kadar sağlam?"
        },
        branch_a={
            "condition": "ÖN KAPSÜL İNTAKT & 360° SULKUS DESTEĞİ VAR",
            "actions": [
                "3 Parçalı GİL sulkusa implante edilir (Tek parçalı KONTRENDİKE).",
                "Sulkus Güç Düzeltmesi (Rule of 9s): Formül gücünden +0.5 ila +1.0 D düşülür.",
                "Optic Capture (Optik Kitleme): Optik, intakt ön kapsüloreksis açıklığından arkaya itilerek torbaya kilitlenir.",
                "Haptikler sulkusta, optik kapsül arkasında sabitlenir."
            ],
            "outcome": "Mükemmel stabilite, tilt/desantrasyon riski sıfıra yakın, minimum kırma kusuru sapması."
        },
        branch_b={
            "condition": "ÖN KAPSÜL YOK VEYA GENİŞ KAPSÜL KAYBI / TOTAL AFAKİ",
            "actions": [
                "Yamane Çift İğneli İntraskleral Haptik Fiksasyonu (ISHF) uygulanır.",
                "30G ince duvarlı iğneler limbusa 2.0 mm mesafeden 20° açıyla skleraya girer.",
                "3 Parçalı PVDF haptikler eksternalize edilir.",
                "Düşük ısı koterle 0.30 mm mantar flanş oluşturulup skleral tünellere gömülür."
            ],
            "contraindications": "PMMA haptikler kırılgan olduğu için flanş yapılamaz; tek parçalı akrilik kesinlikle kullanılamaz."
        },
        golden_rule="Ön kapsüloreksis intakt ise GİL sulkusa konup optik torbaya kilitlenmelidir (Optic Capture). Kapsül yoksa Yamane altın standarttır.",
        notes=(
            "Kapsül desteği olmayan gözlerde GİL seçimi.\n"
            "Sulkus GİL formülü: Rule of 9s.\n"
            "Emmetropi hedeflenen bir gözde kapsül torbası için hesaplanan güç:\n"
            "17.5 D veya altı ise: Değişiklik yok (veya -0.5 D)\n"
            "18.0 - 28.0 D arasında ise: -1.0 D düşülür.\n"
            "28.5 D üzerinde ise: -1.5 D düşülür.\n"
            "[Yamane ISHF: PMID 28457674] [BCSC-11:182]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 6: GÖRSEL ŞEMA — YAMANE ISHF TEKNİĞİ VE GEOMETRİSİ
    # ----------------------------------------------------
    publisher.add_visual_schema_slide(
        title="Yamane Çift İğneli Flanşlı Fiksasyon (ISHF) Geometrisi",
        category="BÖLÜM 2: ŞEMATİK CERRAHİ PANEL",
        subtitle="30G iğne açısı, tünel uzunluğu ve flanş çapı lens tiltini önlemenin anahtarıdır.",
        image_path=schema_2,
        focal_points=[
            ("2.0 mm Limbus Mesafesi", "İğne girişleri limbustan tam 2.0 mm (veya aksiyel uzunluğa göre 2.5 mm) geriden açılır."),
            ("20° Açılı Skleral Tünel", "İğneler skleraya 20° eğik ve skleral yüzeye teğet 1.5-2.0 mm tünel oluşturacak şekilde sokulur."),
            ("Düşük Isı Koter & 0.30 mm Flanş", "Haptik ucu düşük ısı koterle eritilerek haptik çapının 2 katı (0.30 mm) mantar flanş elde edilir."),
            ("Tünel İçine Gömme (Push-back)", "Flanş konjonktiva altında açıkta bırakılmaz; skleral tünel ağzına geri itilerek erozyon önlenir.")
        ],
        notes=(
            "Yamane ISHF Geometrisi.\n"
            "Referans: Yamane S, et al. Ophthalmology 2017; 124(8):1136-1142. PMID: 28457674.\n"
            "En sık hata: Haptiği koterle fazla eritip küreği aşırı büyütmek veya haptiği asimetrik tünelden geçirmektir.\n"
            "Asimetrik tüneller lense 5 dereceden fazla tilt yaptırarak yüksek astigmatizma oluşturur."
        )
    )

    # ----------------------------------------------------
    # SLAYT 7: GÖRSEL ŞEMA — STANDART vs REVERSE OPTIC CAPTURE
    # ----------------------------------------------------
    publisher.add_visual_schema_slide(
        title="Optic Capture Mekaniği: Standart vs Reverse Teknik",
        category="BÖLÜM 2: ŞEMATİK CERRAHİ PANEL",
        subtitle="Ön veya arka kapsül yırtıklarında optiğin sağlam kapsül halkasına kilitlenmesi.",
        image_path=schema_3,
        focal_points=[
            ("Standart Optic Capture", "Haptikler sulkusta, optik ise intakt ön kapsüloreksis kenarlarından arkaya (torbaya) itilerek kilitlenir."),
            ("Reverse Optic Capture", "Arka kapsül geniş yırtıldığında; GİL torbaya konur, ancak optik ön kapsüloreksisin önüne (ön kamaraya) kilitlenir."),
            ("Desantrasyon Bariyeri", "Optik kapsül deliğine sıkıca oturduğu için asimetrik kapsül büzüşmesinde lens asla kaymaz."),
            ("GİL Güç Ayarı", "Optik sulkus düzleminde değil kapsüloreksis düzleminde kaldığı için kırma kusuru sıfıra yakın kalır.")
        ],
        notes=(
            "Optic Capture varyasyonları.\n"
            "Standart capture: PCR varlığında intakt ön kapsüloreksis varsa kullanılır.\n"
            "Reverse capture: Arka kapsül defekti büyük ancak ön reksis küçük ve intakt olduğunda optik öne çekilir.\n"
            "[BCSC-11:185]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 8: KARŞILAŞTIRMALI TANI — TASS vs AKUT ENFEKSİYÖZ ENDOFTALMİ
    # ----------------------------------------------------
    publisher.add_split_comparison_slide(
        title="TASS (Toksik Ön Segment) vs Akut Enfeksiyöz Endoftalmi Ayrımı",
        category="BÖLÜM 4: AYIRICI TANI MATRİSİ",
        subtitle="Postoperatif ön kamara reaksiyonunda saatler ile günler arasındaki ölümcül ayrım.",
        left_entity={
            "name": "TASS (Toksik Ön Segment Sendromu)",
            "features": [
                ("Başlangıç Zamanı", "İlk 12 - 24 saat (Hiperakut başlangıç)"),
                ("Ağrı Düzeyi", "Hafif veya tamamen ağrısız"),
                ("Kornea Tutulumu", "Limbus-to-limbus yaygın endotel ödemi"),
                ("Ön Kamara", "Şiddetli steril fibrinoz reaksiyon, hipopiyon"),
                ("Vitreus Tutulumu", "YOKTUR (Vitreus tamamen berraktır)"),
                ("Etiyoloji", "Otoklav deterjanları, endotoksin, intrakameral ilaç toksisitesi"),
                ("Tedavi Protokolü", "Topikal Deksametazon saat başı + Yakın takip")
            ]
        },
        right_entity={
            "name": "Akut Postoperatif Endoftalmi",
            "features": [
                ("Başlangıç Zamanı", "3. - 7. Gün (Gecikmiş bakteriyel çoğalma)"),
                ("Ağrı Düzeyi", "Şiddetli, zonklayıcı oküler ağrı"),
                ("Kornea Tutulumu", "Fokal kornea ödemi, yara yeri infiltrasyonu"),
                ("Ön Kamara", "İlerleyici hipopiyon, yoğun hücre"),
                ("Vitreus Tutulumu", "VARDIR (Yoğun vitrit, kırmızı refleks kaybı)"),
                ("Etiyoloji", "Bakteriyel enfeksiyon (KNS, S. aureus, Gram negatifler)"),
                ("Tedavi Protokolü", "Acil Tap & Inject (Vanko+Seftazidim) veya EVS PPV")
            ]
        },
        bottom_takeaway="Vitreus şeffaf ve başlangıç < 24 saat ise TASS; vitrit var ve başlangıç > 3 gün ise kesinlikle ENDOFTALMİ kabul edilir!",
        notes=(
            "TASS vs Endoftalmi Ayırıcı Tanısı.\n"
            "Wills Eye Manual Chapter 12.13 ve AAO BCSC Section 11 Chapter 11.\n"
            "TASS şüphesinde bile vitrit varlığı ekarte edilmelidir; şüphede kalınırsa hasta endoftalmi gibi tedavi edilir.\n"
            "Profilakside İntrakameral Sefuroksim (1.0 mg/0.1 mL) veya Moksifloksasin (0.5 mg/0.1 mL) endoftalmiyi 5 kat azaltır.\n"
            "Vankomisin intrakameral profilakside HORV (Hemorajik Oklüzif Retinal Vaskülit) riski nedeniyle KESİNLİKLE YASAKTIR.\n"
            "[PMID: 17531689] [PMID: 28416075]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 9: GÖRSEL ŞEMA — TASS vs ENDOFTALMİ ANATOMİK PANELİ
    # ----------------------------------------------------
    publisher.add_visual_schema_slide(
        title="TASS ve Endoftalmi Patolojilerinin Anatomik Yayılımı",
        category="BÖLÜM 4: ŞEMATİK PATOLOJİ PANELİ",
        subtitle="Toksinin ön kamarada sınırlı kalması ile bakterinin arka segmente invazyonu.",
        image_path=schema_4,
        focal_points=[
            ("TASS Kornea Bariyeri", "Toksik moleküller doğrudan endotel hücre pompalarını felç eder; kornea diffüz buzlu cam halini alır."),
            ("TASS Vitreus Sınırı", "Zonül ve lens-iris diyaframı toksini önde tutar; USG'de vitreus ekosuz ve temizdir."),
            ("Endoftalmi Vitriti", "Bakteri vitreus jelinde çoğalarak yoğun membranlar ve opasiteler oluşturur; kırmızı refleks kaybolur."),
            ("EVS Kriteri (LP vs HM)", "Endoftalmide görme LP (Işık hissi) düzeyine gerilemişse tek kurtuluş ACİL PARS PLANA VİTREKTOMİDİR.")
        ],
        notes=(
            "Şema 4 Anatomik Ayrım.\n"
            "EVS (Endophthalmitis Vitrectomy Study) Sonuçları: Başvuru görmesi LP olan gözlerde acil PPV, "
            "tap & inject yöntemine göre 3 kat daha yüksek görme keskinliği kazancı sağlamıştır.\n"
            "Görmesi El Hareketi (HM) veya daha iyi olanlarda iki yöntem arasında nihai görme farkı yoktur.\n"
            "[EVS Trial: PMID 7487614]"
        )
    )

    # ----------------------------------------------------
    # SLAYT 10: LANDMARK ÇALIŞMALAR KPI METRİK KARTLARI
    # ----------------------------------------------------
    publisher.add_trials_kpi_slide(
        title="Landmark Klinik Çalışmalar ve Büyük Veri Kanıt Tabanı",
        category="BÖLÜM 7 & 8: BÜYÜK VERİ VE RKÇ SONUÇLARI",
        subtitle="Modern katarakt cerrahisinde klinik kararları şekillendiren altın standart kanıtlar.",
        metrics=[
            {
                "study": "EUREQUO Registry",
                "big_num": "2.8M",
                "label": "Katarakt Ameliyatı Analizi",
                "finding": "PCR oranı 10 yılda %1.44'ten %0.39'a gerilemiştir. En büyük bağımsız risk kornea kesifliği (OR: 3.2) ve matür katarakttır.",
                "citation": "[EUREQUO 2008-2018]"
            },
            {
                "study": "ESCRS PREMED",
                "big_num": "%1.5",
                "label": "Kombinasyon KMÖ Oranı",
                "finding": "Topikal Bromfenak + Deksametazon kombinasyonu kistoid makula ödemini monoterapiye göre (%5.1) anlamlı düzeyde düşürmüştür.",
                "citation": "[PMID: 30122345]"
            },
            {
                "study": "ESCRS Endophthalmitis",
                "big_num": "5-6x",
                "label": "Enfeksiyonda Azalma",
                "finding": "İntrakameral Sefuroksim (1.0 mg) kullanımı postoperatif akut endoftalmi insidansını %0.35'ten %0.05'in altına çekmiştir.",
                "citation": "[PMID: 17531689]"
            },
            {
                "study": "EVS Trial",
                "big_num": "3 Kat",
                "label": "LP Görmede PPV Üstünlüğü",
                "finding": "Işık hissi (LP) gören endoftalmi olgularında acil PPV, intravitreal enjeksiyona göre 3 kat daha iyi görme sağlamıştır.",
                "citation": "[PMID: 7487614]"
            }
        ],
        notes=(
            "Landmark Klinik Kanıtlar.\n"
            "EUREQUO: Çok merkezli Avrupa kayıt verisi (2.8 milyon hasta).\n"
            "PREMED Rapor 1 (Diyabetik Olmayanlar): Kombinasyon tedavisi klinik anlamlı KMÖ oranını %1.5'e düşürdü (p < 0.001).\n"
            "PREMED Rapor 2 (Diyabetikler): Subkonjonktival triamsinolon KMÖ'yü azalttı ancak gözlerin %25'inde GİB > 25 mmHg oldu.\n"
            "Anti-VEGF eklenmesi KMÖ insidansını değiştirmedi."
        )
    )

    # ----------------------------------------------------
    # SLAYT 11: İSTATİSTİKSEL METODOLOJİ — HASTA DÜZEYİ vs GÖZ DÜZEYİ
    # ----------------------------------------------------
    publisher.add_split_comparison_slide(
        title="Oftalmolojik Araştırmalarda Kritik İstatistiksel Metodoloji",
        category="BÖLÜM 8: ARAŞTIRMA VE BİYOİSTATİSTİK",
        subtitle="İki gözün bağımlı verisi (Intra-class Correlation) ve GEE modelleme gereksinimi.",
        left_entity={
            "name": "HATALI YAKLAŞIM: Göz Düzeyi Bağımsız Kabulü",
            "features": [
                ("Temel Hata", "Aynı hastanın iki gözünü iki bağımsız birey gibi kabul etmek"),
                ("Kullanılan Testler", "Standart Student t-testi, Pearson Ki-Kare, tek değişkenli ANOVA"),
                ("İstatistiksel Sonuç", "Örneklem büyüklüğü yapay olarak ikiye katlanır, standart hata aşırı daralır"),
                ("Klinik Risk", "Tip I Hata (False Positive): Aslında anlamsız bir fark 'p < 0.05' çıkar"),
                ("Hakem/Dergi Kararı", "Q1 oftalmoloji dergilerinden (Ophthalmology, AJO, Retina) doğrudan RET!")
            ]
        },
        right_entity={
            "name": "DOĞRU YAKLAŞIM: GEE & Mixed-Effects Modelleri",
            "features": [
                ("Metodolojik Standart", "Hasta içi korelasyonu (Intra-class Correlation - ICC) hesaba katmak"),
                ("Kullanılan Yöntemler", "Generalized Estimating Equations (GEE) veya Doğrusal Karma Modeller (LMM)"),
                ("Kovaryat Analizi", "Diyabet süresi, yaş gibi hasta düzeyindeki faktörleri göze kümeleme"),
                ("İstatistiksel Sonuç", "Gerçekçi standart hata, güvenilir p değeri ve tarafsız Odds Ratio (OR)"),
                ("APA / ICMJE Uyumu", "Tüm prestijli dergilerde altın standart kabul edilir")
            ]
        },
        bottom_takeaway="Aynı hastanın iki gözü bağımsız değildir! Analiz birimi hasta düzeyi olmalı veya GEE ile modellenmelidir.",
        notes=(
            "Oftalmoloji İstatistik Standartları.\n"
            "Kullanıcı kuralı: Analizlerde hasta düzeyi (patient-level) ile göz düzeyi (eye-level) analiz birimi ayrımını gözet.\n"
            "İki göz arasındaki korelasyon katsayısı (ICC) genellikle 0.6 - 0.9 arasındadır.\n"
            "Bu korelasyon yok sayıldığında p değerleri yanıltıcı biçimde aşırı küçük çıkar."
        )
    )

    # ----------------------------------------------------
    # SLAYT 12: AKTİF HATIRLAMA VAKA 1 (SORU)
    # ----------------------------------------------------
    publisher.add_active_recall_case_slide(
        case_id="1",
        case_title="PEX'li Hastada İntraoperatif Ani Ön Kamara Derinleşmesi",
        presentation=(
            "74 yaşında psödoeksfoliyasyon (PEX) tanılı erkek hasta matür nükleer katarakt nedeniyle fakoemülsifikasyona alınıyor.\n\n"
            "Nükleus kırma aşamasında aniden ön kamara derinleşiyor, iris diyaframı arkaya doğru çekiliyor ve nükleus kutbu hafifçe yatıyor.\n"
            "Ayak pedalını anında sıfırladınız. Gözde belirgin zonül dializi ve vitreus prolapsusu şüphesi mevcuttur."
        ),
        question="Bu aşamada yapılması gereken İLK ve EN DOĞRU cerrahi manevra hangisidir?",
        options=[
            "A) Nükleusun düşmesini engellemek için hızla yüksek vakumla nükleusu emmek",
            "B) Yan girişten dispersif OVD vererek ön kamarayı tamponlayıp fako ucunu çekmek",
            "C) Nükleus etrafını serbestleştirmek için agresif hidrodiseksiyon yapmak",
            "D) Fako ucunu derhal geri çekip yan girişten BSS ile gözü doldurmak"
        ],
        notes="Vaka 1: İntraoperatif PCR ve Zonülolizis Yönetimi. Fako ucunu aniden çekmek nükleusun anında vitreusa düşmesine yol açar."
    )

    # ----------------------------------------------------
    # SLAYT 13: AKTİF HATIRLAMA VAKA 1 (ÇÖZÜM)
    # ----------------------------------------------------
    publisher.add_active_recall_solution_slide(
        case_id="1",
        case_title="PEX'li Hastada İntraoperatif Ani Ön Kamara Derinleşmesi",
        correct_answer="B) Yan girişten dispersif OVD vererek ön kamarayı tamponlayıp fako ucunu çekmek",
        rationale=(
            "Fako ucu gözün içindeyken ön kamara stabilitesi korunmalıdır. Fako ucu aniden çekilirse göz içi basıncı (GİB) anında sıfırlanır, "
            "arka segmentin pozitif basıncı vitreusu yırtıktan öne iter ve nükleus serbest düşüşle vitreusa düşer. "
            "Yan girişten dispersif OVD verilerek arka kapsül defekti bloke edilmeli ve ön kamara oluşturulduktan sonra fako aleti çıkarılmalıdır."
        ),
        distractors_analysis=[
            ("A Seçeneği (Yüksek vakum)", "Vitreus aspire edilerek masif retina traksiyonuna ve dev yırtıklara sebep olur."),
            ("C Seçeneği (Hidrodiseksiyon)", "Kapsül yırtığında KESİNLİKLE KONTRENDİKEDİR; sıvı dalgası nükleusu vitreusa fırlatır."),
            ("D Seçeneği (Fakoyu hemen çekmek)", "Ön kamaranın çökmesine ve anında suprakoroidal hemoraji/nükleus düşmesine zemin hazırlar.")
        ],
        clinical_pearl="Katarakt cerrahisinde 'Altın Kural': Komplikasyon anında fako ucunu gözden çıkarmadan önce ön kamarayı OVD ile doldur!",
        notes="Vaka 1 Çözüm: AAO BCSC Section 11, Chapter 10."
    )

    # ----------------------------------------------------
    # SLAYT 14: AKTİF HATIRLAMA VAKA 2 (SORU)
    # ----------------------------------------------------
    publisher.add_active_recall_case_slide(
        case_id="2",
        case_title="Postoperatif 1. Günde Ağrısız Yaygın Kornea Ödemi ve Hipopiyon",
        presentation=(
            "68 yaşında kadın hasta, komplikasyonsuz fakoemülsifikasyon ve arka kamara GİL implantasyonu cerrahisinden 18 saat sonra kontrole geliyor.\n\n"
            "Hastanın hiçbir ağrısı veya oküler batması yoktur. Biyomikroskopide: Tüm korneada limbus-to-limbus buzlu cam tarzında difüz ödem, "
            "ön kamarada 1.5 mm steril hipopiyon ve fibrin mevcuttur.\n"
            "B-scan ultrasonografide vitreus homojen, ekosuz ve tamamen berraktır."
        ),
        question="Bu klinik tablonun en olası tanısı ve acil tedavi yaklaşımı ne olmalıdır?",
        options=[
            "A) Akut enfeksiyöz endoftalmi — Acil intravitreal Vankomisin + Seftazidim enjeksiyonu",
            "B) Psödofakik büllöz keratopati — Acil endotelyal keratoplasti (DMEK) planlaması",
            "C) Toksik Ön Segment Sendromu (TASS) — Saat başı topikal yoğun Deksametazon",
            "D) Aköz misdirection (Malign Glokom) — Acil topikal Atropin ve Nd:YAG kapsülotomi"
        ],
        notes="Vaka 2: TASS vs Endoftalmi. Erken başlangıç (18 saat), ağrısız olması, yaygın kornea ödemi ve berrak vitreus TASS'ın tipik özelliğidir."
    )

    # ----------------------------------------------------
    # SLAYT 15: AKTİF HATIRLAMA VAKA 2 (ÇÖZÜM)
    # ----------------------------------------------------
    publisher.add_active_recall_solution_slide(
        case_id="2",
        case_title="Postoperatif 1. Günde Ağrısız Yaygın Kornea Ödemi ve Hipopiyon",
        correct_answer="C) Toksik Ön Segment Sendromu (TASS) — Saat başı topikal yoğun Deksametazon",
        rationale=(
            "Ameliyattan sonraki ilk 12-24 saatte gelişmesi, hastanın şiddetli ağrısının olmaması, korneanın fokal değil total/limbus-to-limbus "
            "ödemli olması ve ultrasonografide vitreusun tamamen berrak kalması TASS'ın patognomonik tablosudur. "
            "Steril enflamatuar endotel hasarı saat başı topikal yoğun steroid (Deksametazon %0.1) ile geriler."
        ),
        distractors_analysis=[
            ("A Seçeneği (Endoftalmi)", "Endoftalmi genellikle postop 3-7. günlerde şiddetli ağrı ve yoğun vitrit ile gelir."),
            ("B Seçeneği (DMEK)", "Akut enflamasyon ve TASS gerilemeden keratoplasti yapılmaz; TASS tedavi edilince kornea düzelebilir."),
            ("D Seçeneği (Malign Glokom)", "Malign glokomda ön kamara difüz sığlaşır ve GİB çok yüksektir; yaygın hipopiyon görülmez.")
        ],
        clinical_pearl="TASS'ta vitreus daima masumdur. Vitreus bulanıksa veya hasta şiddetli zonklayıcı ağrı tarifliyorsa aksi kanıtlanana kadar ENDOFTALMİ kabul edilmelidir.",
        notes="Vaka 2 Çözüm: Wills Eye Manual Chapter 12.13 ve ASCRS TASS Görev Gücü Kılavuzları."
    )

    # ----------------------------------------------------
    # SLAYT 16: AKTİF HATIRLAMA VAKA 3 (SORU)
    # ----------------------------------------------------
    publisher.add_active_recall_case_slide(
        case_id="3",
        case_title="Postop 5. Günde Ani Görme Kaybı ve EVS Tedavi Kararı",
        presentation=(
            "Katarakt cerrahisi sonrası 5. gününde başvuran 70 yaşında erkek hasta; gözünde zonklayıcı dayanılmaz ağrı, kapak ödemi ve ani görme kaybı bildiriyor.\n\n"
            "Muayenede görme keskinliği 'Işık Hissi' (Light Perception - LP) düzeyindedir. Ön kamarada 3 mm yoğun hipopiyon, korneada ödem ve "
            "fundus muayenesinde kırmızı refleksin tamamen kaybolduğu, USG'de yoğun vitrit membranları izleniyor."
        ),
        question="Endophthalmitis Vitrectomy Study (EVS) kılavuzuna göre bu hastada kanıta dayalı altın standart yaklaşım hangisidir?",
        options=[
            "A) Tap & Inject: Ön kamara ve vitreus parasentezi + İntravitreal Vankomisin ve Seftazidim",
            "B) Acil Pars Plana Vitrektomi (PPV) + İntravitreal Antibiyotik Kombinasyonu",
            "C) Yalnızca yüksek doz intravenöz Seftriakson ve oral Florokinolon tedavisi",
            "D) Gözü takip etmek ve 48 saat sonra düzelme olmazsa vitrektomiye almak"
        ],
        notes="Vaka 3: EVS Kriterleri. EVS çalışmasında görmesi LP olan hastalarda acil vitrektomi görme sonucunu 3 kat artırmıştır."
    )

    # ----------------------------------------------------
    # SLAYT 17: AKTİF HATIRLAMA VAKA 3 (ÇÖZÜM)
    # ----------------------------------------------------
    publisher.add_active_recall_solution_slide(
        case_id="3",
        case_title="Postop 5. Günde Ani Görme Kaybı ve EVS Tedavi Kararı",
        correct_answer="B) Acil Pars Plana Vitrektomi (PPV) + İntravitreal Antibiyotik Kombinasyonu",
        rationale=(
            "Endophthalmitis Vitrectomy Study (EVS) landmark çalışması başvuru anındaki görme keskinliğini temel karar metriği yapmıştır. "
            "Başvuru görmesi sadece 'Işık Hissi' (LP) olan hastalarda ACİL VİTREKTOMİ yapılması, yalnızca enjeksiyon (Tap & Inject) "
            "yapılanlara göre 3 kat daha yüksek nihai görme keskinliği (≥ 20/40) sağlamıştır. "
            "Görmesi El Hareketi (HM) veya daha iyi olanlarda Tap & Inject ile PPV arasında fark bulunmamıştır."
        ),
        distractors_analysis=[
            ("A Seçeneği (Tap & Inject)", "Görmesi HM ve üzeri olanlarda yeterlidir; LP olgularında yetersiz kalır ve görme kaybına yol açar."),
            ("C Seçeneği (Yalnızca Sistemik)", "EVS çalışmasında sistemik intravenöz antibiyotiklerin vitreus içi antibiyotiklere ek fayda sağlamadığı kanıtlanmıştır."),
            ("D Seçeneği (Beklemek)", "Bakteriyel toksinler saatler içinde retina fotoreseptörlerini geri dönüşsüz nekroze eder.")
        ],
        clinical_pearl="EVS Formülü: LP = Acil PPV! HM veya Daha İyi = Tap & Inject! LP düzeyinde vitrektomiyi geciktirmek medikolegal bir hatadır.",
        notes="Vaka 3 Çözüm: EVS Trial. Arch Ophthalmol 1995. PMID: 7487614."
    )

    # ----------------------------------------------------
    # SLAYT 18: BİTİŞ VE ÖZET KARTI
    # ----------------------------------------------------
    publisher.add_cover_slide(
        metadata_rows=[
            ("Özetlenen Bölümler", "8 Cerrahi Modül · İntraoperatif Kapsül, Yamane ISHF, Hemoraji, TASS/Endoftalmi, KMÖ, İstatistik"),
            ("Temel Klinik Mesaj", "Ön vitrektomide bimanual yaklaşım ve triamsinolon şarttır. Sulkusa asla tek parçalı akrilik konulmaz."),
            ("Sınav ve Tekrar Önerisi", "Slayt notlarındaki PubMed linklerini (PMID) ve Rule of 9s düzeltme formülünü düzenli tekrar edin."),
            ("Akademik Çıktı Formatı", "16:9 Geniş Ekran Sunum Atlası · Hem Bağımsız PPTX Hem de PDF Boru Hattı ile %100 Uyumlu"),
        ],
        notes="Katarakt Cerrahisi Komplikasyonları Çalışma Atlası Tamamlandı."
    )

    # Layout Triage Denetimi (Auditor)
    audit = publisher.audit_slide_deck_layout()
    print("\n--- PPTX YERLEŞİM VE BİLİŞSEL YÜK DENETİM RAPORU ---")
    print(f"Toplam Slayt: {audit['total_slides']}")
    print(f"Geometri Taşması: {len(audit['overflow_issues'])} adet")
    print(f"Yoğunluk Uyarısı: {len(audit['density_warnings'])} adet")
    print(f"Eksik Konuşmacı Notu: {len(audit['missing_notes'])} adet")
    print(f"Denetim Onayı: {'BAŞARILI (PASSED)' if audit['passed'] else 'DÜZELTME GEREKİYOR'}")

    final_path = publisher.save(output_pptx_path)
    return final_path


# ==========================================
# 4. LANGGRAPH DÜĞÜMÜ (NODE) OLARAK KULLANIM
# ==========================================

def pptx_publisher_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    LangGraph boru hattında 'pptx_publisher' düğümü olarak çağrılabilir.
    State içindeki sentezlenmiş bilgileri okuyarak PPTX dosyasını üretir ve state'e kaydeder.
    """
    print("[PPTX-Publisher] 16:9 Görsel ve Akış Şemalı PowerPoint Çalışma Seti Üretiliyor...")
    out_dir = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
    out_pptx = out_dir / "Katarakt_Cerrahisi_Komplikasyonlari_Calisma_Seti.pptx"

    result_path = build_cataract_complications_deck(out_pptx)
    return {"output_pptx_path": str(result_path)}


if __name__ == "__main__":
    print("=" * 70)
    print("PPTX PUBLISHER — 16:9 GÖRSEL VE AKIŞ ŞEMALI ÇALIŞMA SETİ ÜRETİCİSİ")
    print("=" * 70)
    target = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity\Katarakt_Cerrahisi_Komplikasyonlari_Calisma_Seti.pptx")
    out = build_cataract_complications_deck(target)
    print(f"\nİşlem tamamlandı. Dosya konumu: {out}")
