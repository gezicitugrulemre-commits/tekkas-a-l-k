# Bağımsız denetim sonrası güvenlik düzeltmeleri

Bu paket pipeline_current_source_review.zip üzerine uygulanmış kaynak değişikliklerini içerir.
Orijinal inceleme raporu historical/ altındadır. examples/ ve logs/ eski çalışmalara aittir;
bu kodla yeniden üretilmiş veya klinik olarak doğrulanmış çıktı sayılmamalıdır.

## Değişen davranış

- Supervisor ve builder yapay kaynak/kılavuz/sayfa üretmez. Builder her klinik kart alanını
  başlangıçta unverified sayar. Kaynaksız iş review_required ile biter.
- RETINA_EVIDENCE_INDEX isteğe bağlı bir yerel JSON dosyasıdır:
  [{"path":"/absolute/book.pdf","sha256":"PDF_SHA256","pages":[12,13]}].
  local_slide_evidence.py çağrı başına en fazla 8 belirtilmiş sayfa okur; yalnız gerçek PDF
  metni döndürür; önce getirilen kaynakları dışlar. OCR veya tam arşiv indekslemesi yapmaz.
  Retrieval iddia desteğini otomatik onaylamaz. Canlı reviewer claim_source_links ile
  her iddiayı gerçek kaynak kimliklerine bağlamalıdır. Bu da insan onayı değildir.
- Son güvenlik denetimi reddi kaydetme adımında kabul ile ezilemez.
- Supervisor canlı çağrısı taslak PNG ve kaynak görsel PNG baytlarını içerir.
  PIL çıktısı render_kind=preview'dır; nihai PPTX yerleşim onayı değildir.
- Düzeltme bütçesi tükenince yeni düzeltme yapılmaz; son taslak değerlendirilebilir.
  Offline kurallar kabul veya otomatik tedavi önerisi üretmez.
- Görseller reddedilen kimlikler yanında içerik hash'iyle de dışlanır.
- Builder SQLite checkpoint kullanır. Kimlik içerik, kaynak dosyaları, görsel dosyaları
  ve politikaya bağlıdır. Aynı içerik tamamlandıysa tekrar çağrılmaz. Kesilmiş canlı
  çalışmada ücretli adım sessizce tekrar edilmez; insan incelemesi için hata verilir.
  Dağıtık eşzamanlı tam-once provider çağrısı garantisi verilmez.
- Metin koruması alan/satır/cümle bazında sayı-birim-atıf işaretlerini ve sıralarını
  karşılaştırır. Bu, tam anlamsal/klinik eşdeğerlik kanıtı değildir.
- Görsel provider çağrıları ortak provenance defterinden geçer. Kimlik ve JSON
  doğrulanmadan SUCCESS kaydedilmez. İki aşama ortak run_id taşır.
- PPTX kontrolü render yokluğunu açık raporlar; geometri kontrolünü görsel onay saymaz.
  Kaynak resim ve yerleştirilmiş görünür resim oranı karşılaştırılır. PNG'ler her
  export için yeni dizine yazılır. Build sidecar PPTX/source hash ve supervisor run'larını içerir.
- Docling caption_text(document) kullanır; kökeni kaydeder. Panel ayrılmadan single_panel
  atanmaz. PyMuPDF caption aramasında hizalama ve yakınlık sınırı vardır.
- Phoenix açıkça etkinse model çağrı yolundan başlatılır; otomatik ham giriş/çıkış ve
  görüntüler gizlenir. Token sayaçları korunur, ham belge alanları hash'e çevrilir.
- Eski DeepEval adlı betik sentetik altyazı kural testi olarak etiketlidir; gerçek
  DeepEval metrikleri veya klinik model başarısı iddia etmez. Sentetik live-eval reddedilir.

## Çalıştırma

Uygulama komutları src dizininden çalıştırılır. Kitap CLI'sinde tarif kitap adı değildir:
python -m bookgraph run kitap --recipe oftalmoloji_1000
Bu üretim komutu model çağrısı yapabilir; yerel test için çalıştırmayın.

Retina master taslak yolu:
python retina_master_study_pipeline.py --supervised-slides
Canlı model çağrısı yalnız ayrıca --live-argon verilirse yapılır. Mevcut kişisel Windows
kaynak/çıktı yolları ve gerekli gerçek veri dosyaları hedef makinede sağlanmalıdır.

Nihai sunumun ayrı kontrolü:
python pptx_render_checker.py SUNUM.pptx --out-dir assets/render_audits
Gerçek PNG export Windows PowerPoint COM gerektirir. PNG varlığı görsel uzman onayı değildir.

Testler (paket kökünden):
python -m pytest -q tests
Test conftest'i dış ağ bağlantılarını engeller, telemetriyi kapatır ve geçici çalışma
klasörü kullanır. Kaynak testleri sahte model yanıtları ve küçük sentetik dosyalar kullanır.
requirements-local-tests.txt doğrulamada kullanılan çekirdek test sürümlerini belirtir.

## Doğrulama ve açık sınırlar

Doğrulama sonucu validation/pytest.txt içinde. Canlı model, gerçek Docling model ağırlıkları,
Phoenix exporter/span uçtan uca ve Windows PowerPoint COM çalıştırılmadı. Bu paket
klinik uzman onayı veya üretim yayını değildir. examples/ içindeki “doğru OCT” örneği
şemadır; ilgili tarihsel raporlar doğrulama referansı olarak kullanılmamalıdır.

Eksik özgün modüller geri üretilemedi: part2_ch5_data–part2_ch8_data,
part3_ch9_data, part3_ch10_data, part3_ch12_cases_data, production_worker,
question_bank_pdf_publisher, octa_pdf_publisher. İlgili eski yollar eksikler sağlanmadan
çalışmaz. Büyük PDF/registry/indeks ve gerçek klinik değerlendirme seti pakette yoktur.
Eski fail-closed supervisor yolları bu yama ile başarılı üretim hattına dönüştürülmez.

source_manifest.json teslim dosyalarının güncel boyut/hash listesidir.
CHANGESET.json her değişen kaynak için eski ve yeni hash'i içerir; canlı projeye taşıma
öncesinde yerel değişikliklerin üzerine yazmamak için eski hash ile karşılaştırın.
