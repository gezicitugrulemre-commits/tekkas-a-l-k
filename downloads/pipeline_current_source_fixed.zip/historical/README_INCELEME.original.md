# LangGraph + EDM Medikal İçerik ve Retina PPTX Üretim Sistemi
## Bağımsız Teknik Kod İncelemesi ve Mimari Doğrulama Raporu (README_INCELEME.md)

Bu doküman, LangGraph tabanlı kanıta dayalı medikal içerik üretim hattı (Evidence-Driven Multimodal - EDM), iki aşamalı multimodal görsel doğrulayıcı, Argon slayt denetmeni (Supervisor), Docling yapısal çıkarım adaptörleri, Phoenix/OpenInference izleme katmanı ve PPTX yayınlama altyapısının güncel kaynak kod inceleme rehberidir.

---

## 1. GERÇEK PROJE VE AKTİF GİRİŞ NOKTALARI

### 1.1 Proje Kökü ve Çalışma Dizinleri
- **Kullanılan Proje Kökü:** `C:\Users\gezic\OneDrive\Desktop\Anti Gravity`
- **Birincil Çalışma Dizini:** `C:\Users\gezic\OneDrive\Desktop\Anti Gravity`
- **İkincil Not Kasası (Kod içermez):** `C:\Users\gezic\Obsidian\TEG` (Yalnızca çıktı markdown/obsidian katalogları için hedef kasadır).
- **Python Çalışma Ortamı:** Python 3.13.14 x64 (`.venv\Scripts\python.exe`).

### 1.2 Gerçek Çalıştırma Komutları ve Giriş Noktaları

| Hat / Görev | Giriş Noktası Dosyası | Gerçek Çalıştırma Komutu | Doğrulama Kanıtı (Kod / Log) |
|---|---|---|---|
| **Retina Masterclass PPTX & Supervisor** | `retina_master_study_pipeline.py` | `python retina_master_study_pipeline.py --supervised-slides` | `__main__` bloğu (L44-L70), `run_retina_masterclass_pipeline()`, argparse bayrakları |
| **Retina Vitreus Master PPTX** | `retina_vitreus_master_pptx_pipeline.py` | `python retina_vitreus_master_pptx_pipeline.py` | `__main__` bloğu L1620: `run_pipeline(export_pptx=True, supervisor_enabled=True)` |
| **DR & DMO PPTX Hattı** | `dr_dmo_pptx_pipeline.py` | `python dr_dmo_pptx_pipeline.py` | `__main__` bloğu L780: `build_dr_dmo_graph().invoke(initial_state)` |
| **Kitap Derleme & Orkestrasyon** | `bookgraph/cli.py` | `python -m bookgraph run oftalmoloji_1000` | Click CLI L180-L240, `bookgraph/recipe.py` |
| **DeepEval Multimodal Benchmark** | `run_deepeval_retina_bench.py` | `python run_deepeval_retina_bench.py --live-eval --strict-argon` | `logs_staging/deepeval_retina_bench.log` ve `tests/test_deepeval_retina_evals.py` |
| **PPTX Render & Taşma Denetimi** | `pptx_render_checker.py` | `python pptx_render_checker.py <pptx_path> --out-dir assets/render_audits` | `__main__` L140: `PPTXRenderChecker.audit_presentation()` |
| **LangGraph Mimari Denetçi & Humanizer** | `langgraph_auditor.py` | `python langgraph_auditor.py` | `__main__` L640: `audit_langgraph_pipeline()` |
| **Birim ve Güvenlik Testleri** | `tests/retina_safety_update/` | `pytest -q tests/` | `logs_staging/pytest_run.log` (71 test: 68 passed, 3 skipped) |

### 1.3 Aktif, Deneysel ve Eski Kod Yolları

- **Aktif Kod Yolları:**
  - `argon_slide_supervisor_graph.py` + `slide_supervisor_schema.py`: Slayt denetim döngüsünü LangGraph `StateGraph` ile yürüten ana denetmen.
  - `two_stage_visual_verifier.py`: İki aşamalı multimodal doğrulayıcı. `_offline_verify` ve `_live_api_verify` ayrımını `_assert_argon_identity` ile zorlar.
  - `retina_visual_resolver.py`: Retina atlası ve Docling registry'sinden görsel bağlam hash'i ile eşleme yapar.
  - `pptx_publisher.py` & `retina_study_builder_core.py`: 16:9 widescreen slayt dizgisi, shape, kart ve tipografi motoru.
  - `bookgraph/` paketi: State, router, prompt yükleyici, usage SQLite ve LangGraph 1.x çalışma zamanı.
  - `build_egm_retina_revision.py`, `execute_retina_image_revision.py`: En son çalışmada görsel uyumsuzluklarını düzelten aktif revizyon zinciri.
- **Deneysel Kod Yolları:**
  - `repos/MinerU`: Yerel Llama probe ve ONNX hızlandırma denemeleri (kullanımı isteğe bağlı harici deneysel repo).
  - `retina_pubmed_graph.py` & `cscr_pubmed_langgraph_pipeline.py`: Spesifik araştırma alt grafikleri (modüler olarak çağrılabilir).
- **Eski / Arşiv Kod Yolları:**
  - `retina_ch1_builder.py` - `retina_ch10_builder.py`: Bağımsız tekil bölüm üreticileri (güncel kodda `retina_study_builder_core.py` ve `retina_master_study_pipeline.py` tarafından orkestre edilmektedir).

---

## 2. ÇAĞRI VE VERİ AKIŞLARI (SOMUT VE KOD REFERANSLI)

### A. Kaynak PDF / PubMed -> Kanıt -> İddia/Atıf -> Metin Akışı

```mermaid
flowchart TD
    PDF["Tıp Kitabı PDF / Makale"] --> DOC["Docling / PyMuPDF Çıkarımı\ndocling_pdf_extractor.py: DoclingPDFExtractor.extract_document()\nbatch_extract_all_volumes.py: process_single_pdf()"]
    PM["PubMed E-Utilities"] --> PMC["PubMed İstemcisi\npubmed_client.py: PubMedClient.fetch_abstract_and_metadata()\ndr_dmo_research_sources.py: fetch_pubmed_landmark_evidence_for_module()"]
    DOC --> RAG["Kanıt ve İddia Yapılandırma\nslide_supervisor_schema.py: SourcePassage, ClinicalClaim\nbookgraph/books/retina.py: node_author_facet()"]
    PMC --> RAG
    RAG --> VAL["Atıf Doğrulama ve Denetim\nbookgraph/quality.py: validate_citations()\nbookgraph/safety.py: sanitize_text()"]
    VAL --> HUM["Akademik Türkçe İyileştirme\nlanggraph_auditor.py: academic_turkish_humanizer_node()\nretina_vitreus_master_pptx_pipeline.py: academic_turkish_humanizer_node()"]
    HUM --> SLIDE["Slayt Metin ve Klinik Kart Gövdesi\npptx_publisher.py: add_study_card_slide()"]
```

**Kod Karşılıkları:**
1. **PDF Çıkarımı:** `docling_pdf_extractor.py` içinde `DoclingPDFExtractor.extract_document()` fonksiyonu Docling modelleriyle başlık, gövde, tablo ve şekilleri JSON formatında çıkarır.
2. **PubMed Sorgulama:** `pubmed_client.py` içinde `PubMedClient.search_pmid()` ve `PubMedClient.fetch_abstract_and_metadata()` fonksiyonları NCBI API üzerinden MeSH terimlerini ve yapılandırılmış özetleri çeker.
3. **Kanıt & İddia:** `slide_supervisor_schema.py` içinde `ClinicalClaim(claim_text, evidence_level, citation_keys, verified)` modeli iddiaları yapılandırır.
4. **Atıf Doğrulama:** `bookgraph/quality.py` içinde `validate_citations()` fonksiyonu uydurma atıfları ve bilinmeyen ID'leri reddeder (`test_no_fabricated_fallback_citation`).
5. **Akademik Dil Kapısı:** `langgraph_auditor.py` içinde `academic_turkish_humanizer_node()` fonksiyonu İngilizce çeviri kokusunu temizler, baş-son Türkçe sentaksını uygular.

---

### B. Kaynak Sayfa -> Şekil/Panel -> Görsel Seçimi -> Doğrulama Akışı

```mermaid
flowchart TD
    SRC["Kitap Kaynak Sayfası (PDF)"] --> EXT["Görsel Çıkarım ve Kataloglama\nvisual_catalog_manager.py: LocalImageExtractor.extract_from_books()\nbuild_precise_retina_registry.py: build_registry()"]
    EXT --> REG["Registry ve İndeks\nretina_precise_registry.json\ndocling_retina_image_registry.json"]
    REG --> RES["Görsel Çözümleme ve Hash Kontrolü\nretina_visual_resolver.py: RetinaVisualResolver.resolve_visual()\ncompute_record_context_hash()"]
    RES --> VER["İki Aşamalı Doğrulama Motoru\ntwo_stage_visual_verifier.py: TwoStageVisualVerifier.verify_visual()"]
    VER --> ST1["Aşama 1: Kör Görsel Muayenesi\ntwo_stage_visual_verifier.py: Stage1BlindObservation\n(Yalnızca görsel byte payload; metin/iddia yok)"]
    ST1 --> ST2["Aşama 2: Bağlamsal Klinik Doğrulama\ntwo_stage_visual_verifier.py: Stage2ContextualVerification\n(Görsel + Slayt İddiası + Başlık)"]
    ST2 --> DEC{"Model Kararı ve Uzman Durumu\ntwo_stage_visual_verifier.py: FullVisualAuditRecord"}
    DEC -->|compatible| ACC["Görsel Onaylandı / Kilitlendi"]
    DEC -->|incompatible / review_required| REJ["Karantinaya Al / Alternatif Ara"]
```

**Kod Karşılıkları:**
1. **Görsel Çıkarımı:** `visual_catalog_manager.py` içinde `LocalImageExtractor.extract_from_books()` fonksiyonu PyMuPDF ile PDF sayfalarındaki resimleri kırpar, DPI filtreler ve metadata ile kaydeder.
2. **Görsel Çözümleyici:** `retina_visual_resolver.py` içinde `RetinaVisualResolver.resolve_visual()` fonksiyonu slayt konusuyla eşleşen en yüksek skorlu görseli registry'den bulur.
3. **İki Aşamalı Doğrulama:** `two_stage_visual_verifier.py` içinde:
   - Aşama 1: `Stage1BlindObservation` (görüntünün modalitesi, anatomik yapı, lezyonlar; metin/konu verilmeden kör incelenir).
   - Aşama 2: `Stage2ContextualVerification` (görüntü, slayt başlığı ve klinik iddia birlikte incelenir: `disease_match`, `modality_match`, `panel_match`, `supports_claims`).
   - Karar Filtresi: `validate_model_decision()` fonksiyonunda 4 kontrolün tamamı True değilse karar `compatible` olamaz (`test_compatible_decision_blocked_if_any_check_fails`).

---

### C. Slayt Taslağı -> Render -> Supervisor -> Düzeltme / Ret / Kabul Akışı

```mermaid
flowchart TD
    SPEC["Slayt Spesifikasyonu (SlideSpec)\nslide_supervisor_schema.py: SlideSpec\nretina_study_builder_core.py: supervise_slide_spec()"] --> PREP["Taslak Hazırlama\nargon_slide_supervisor_graph.py: prepare_slide_node()"]
    PREP --> RND["Geçici PNG Rasterizasyonu\nargon_slide_supervisor_graph.py: render_slide_spec_to_png()\nrender_draft_node()"]
    RND --> SUP["Argon Supervisor Değerlendirmesi\nargon_slide_supervisor_graph.py: argon_supervisor_node()\ndecision_router()"]
    SUP --> ROUTE{"Karar Yönlendirici"}
    ROUTE -->|approved| CHK["Nihai Kontroller ve Checkpoint\nargon_slide_supervisor_graph.py: final_checks_node()\nsave_draft_result_node()"]
    ROUTE -->|replace_visual| CAND["Görsel Adayları Çek ve Uygula\nretrieve_visual_candidates_node()\napply_visual_node()"]
    ROUTE -->|request_evidence| EVI["PubMed Kanıtı Getir ve Revize Et\nretrieve_evidence_node()\nrevise_slide_node()"]
    ROUTE -->|revise_layout| REV["Metin ve Düzen Revizyonu\nrevise_slide_node()"]
    ROUTE -->|review_required / rejected| REQ["İnsan İncelemesi Bayrağı\nsave_draft_result_node()\nexpert_review_status='review_required'"]
    CAND --> RND
    EVI --> RND
    REV --> RND
    CHK --> PUB["PPTX Yayını\npptx_publisher.py: PPTXStudyPublisher"]
```

**Kod Karşılıkları:**
1. **SlideSpec Girişi:** `slide_supervisor_schema.py` içindeki `SlideSpec` modeli slayt ID, başlık, klinik iddialar, görsel yolu ve konuşmacı notlarını içerir.
2. **Draft Render:** `argon_slide_supervisor_graph.py` içinde `render_slide_spec_to_png()` fonksiyonu PIL kütüphanesiyle slaytı 16:9 oranında geçici bir PNG dosyasına çizer.
3. **Supervisor Kararı:** `argon_slide_supervisor_graph.py` içinde `argon_supervisor_node()` fonksiyonu canlı API'de multimodal görüntüyü Argon'a gönderir; çevrimdışında `_offline_rules_evaluate()` kurallarını çalıştırır.
4. **Döngü Devre Kesici:** `correction_count >= max_corrections (3)` olduğunda döngü sonlanır ve durum zorunlu olarak `review_required` yapılır (`test_retry_excludes_configuration_loop`).
5. **PPTX Render Kontrolü:** `pptx_render_checker.py` içinde `PPTXRenderChecker.check_presentation()` fonksiyonu metin taşmalarını ve görsel bozulmalarını denetler.

---

### D. Model Seçimi -> Gerçek Provider Çağrısı -> Fallback -> Kullanım Kaydı Akışı

```mermaid
flowchart TD
    REQ["Model Talebi (Spec)\nbookgraph/settings.py: ModelSettings\nbookgraph/llm.py: get_chat_model()"] --> POL{"Argon Zorunlu mu?\nstrict_argon=True?"}
    POL -->|Evet (strict)| ARG_CALL["Argon Çağrısı (Fallback Devre Dışı)\nbookgraph/llm.py: specs = [argon]\nno_fallback=True"]
    POL -->|Hayır (economy)| FLASH_CALL["Flash Çağrısı / Fallback Zinciri\nspecs = [flash, pro, sonnet]\nwith_fallbacks()"]
    ARG_CALL --> PROV["Vertex AI / Google AI Studio API\nChatGoogleGenerativeAI(model='gemini-4-argon', location='global')"]
    FLASH_CALL --> PROV2["Google GenAI API\nChatGoogleGenerativeAI(model='gemini-3.8-flash')"]
    PROV --> ID_CHK["Kimlik Doğrulama Kapısı\nbookgraph/llm.py: _assert_argon_identity()\n(response_metadata['model_name'] == 'gemini-4-argon')"]
    ID_CHK -->|Başarılı| USAGE["Kullanım ve Token Kaydı\nbookgraph/usage.py: record_usage()\nUsageTracker -> bookgraph_usage.sqlite"]
    ID_CHK -->|Model Uyuşmazlığı| ERR["Hata Fırlat / İptal Et\noutcome='MODEL_MISMATCH'\nlog_fallback()"]
    PROV2 --> USAGE
    USAGE --> PHOENIX["Phoenix ve OpenInference Tracing\nphoenix_tracer.py: setup_phoenix_tracer()\nOpenInference OTEL Spans"]
```

**Kod Karşılıkları:**
1. **Model Seçimi:** `bookgraph/llm.py` içinde `get_chat_model()` fonksiyonu model talep listesini alır.
2. **Sessiz Fallback Engeli:** `bookgraph/llm.py` L170-L175: İlk model `gemini-4-argon` ise `strict = True` yapılır; `specs` listesi yalnızca `gemini-4-argon` modellerine indirgenir ve `no_fallback=True` ayarlanır. Böylece pahalı veya kritik görevlerin sessizce Flash'a düşmesi engellenir (`test_argon_no_silent_fallback`).
3. **Kimlik Denetimi:** `bookgraph/llm.py` L136-L158 `_assert_argon_identity()` fonksiyonu: Sağlayıcı yanıtındaki `response_metadata['model_name']` içinde `gemini-4-argon` bulunmazsa `ValueError` fırlatır (`test_provider_reports_flash_for_strict_argon_is_rejected`).
4. **Kullanım Kaydı:** `bookgraph/usage.py` içinde `record_usage()` fonksiyonu girdi/çıktı tokenlarını, maliyet katsayısını ve model adını SQLite (`storage/bookgraph_usage.sqlite`) ve loglara kaydeder.
5. **İzleme:** `phoenix_tracer.py` içinde `setup_phoenix_tracer()` fonksiyonu OpenInference enstrümantasyonu ile Arize Phoenix collector'a span gönderir.

---

## 3. KRİTİK MİMARİ SORULARIN KOD REFERANSLI YANITLARI

### S1. Argon Hangi Düğümlerde Zorunlu?
1. **`argon_slide_supervisor_graph.py` -> `argon_supervisor_node` (L795-L895):**
   - Kod Referansı: L800 `requested_model = "gemini-4-argon"`, L844-L845 `if self.strict_argon: _assert_argon_identity(requested_model, resp)`.
   - Gerçek model çıktısı `gemini-4-argon` içermezse işlem başarısız sayılır (`test_flash_response_for_strict_argon_fails`).
2. **`two_stage_visual_verifier.py` -> `_live_api_verify` (L445, L513-L514, L582-L583):**
   - Kod Referansı: L617-L627: `strict_argon` etkinse Aşama 1 kör muayene ve Aşama 2 bağlamsal doğrulama çağrılarının **her ikisinde de** `gemini-4-argon` kimliği zorunludur. Biri bile eksikse `verified_with_argon = False` kalır.
3. **`langgraph_auditor.py` -> Baş Mimar Düğümü (L50, L502):**
   - Kod Referansı: L50 `MODEL_ARGON = "gemini-4-argon"`. Topoloji, paralel `Send` deadlock taraması ve döngü devre kesicilerinin analizi için zorunludur.

### S2. Hangi Düğümler Flash Kullanıyor?
1. **`langgraph_auditor.py` -> Triage ve Topoloji Düğümü (L49, L501):**
   - `MODEL_FLASH = "gemini-3.8-flash"`. Düğüm, kenar, state alanı ve risk ön taraması için kullanılır.
2. **`langgraph_auditor.py` & `retina_vitreus_master_pptx_pipeline.py` -> `academic_turkish_humanizer_node` (L504, L603):**
   - Akademik Türkçe dilbilimsel filtreleme ve kalıp temizliği `gemini-3.8-flash` ile yürütülür.
3. **`bookgraph/recipes/oftalmoloji_1000.yaml` & `bookgraph/prompts/`:**
   - Hızlı okuma (`reader.md`), atıf ve kanıt tarama (`reviewer.md`), faset çıkarma adımlarında `gemini-3.8-flash` kullanılır.
4. **`two_stage_visual_verifier.py` (L445):**
   - `strict_argon=False` olduğu durumda `requested_model = "gemini-3.8-flash"` olarak ayarlanır.

### S3. Görüntü Hangi Çağrılara Gerçekten İletiliyor?
1. **`two_stage_visual_verifier.py` -> Aşama 1 (Kör Muayene):**
   - Kod Referansı: L185, L222 `encode_image_base64()`, L484 `{"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64_data}"}}`.
   - **Önemli:** Bu çağrıda slayt metni, başlık veya klinik iddia ASLA gönderilmez; model görüntüyü kör olarak muayene eder (`test_offline_positive_caption_no_human_approval`).
2. **`two_stage_visual_verifier.py` -> Aşama 2 (Bağlamsal Doğrulama):**
   - Kod Referansı: L554 `image_url` payload'u bu kez slayt başlığı, klinik iddialar ve faset metniyle birlikte modele iletilir.
3. **`argon_slide_supervisor_graph.py` -> `argon_supervisor_node`:**
   - Kod Referansı: L755-L790 `render_slide_spec_to_png()`. Slayt PIL ile PNG'ye çevrilir ve canlı modda base64 payload olarak Argon'a iletilir.

### S4. Offline Kurallar ile Canlı Model Değerlendirmesi Nasıl Ayrılıyor?
- Kod Referansı: `two_stage_visual_verifier.py` L340-L435 (`_offline_verify`) ve L437-L640 (`_live_api_verify`).
- `use_live_api=False` olduğunda:
  - `_offline_verify` doğrudan çalışır; harici ağ veya model çağrısı yapılmaz.
  - `verified_with_argon = False` (ASLA True olamaz).
  - `actual_model = "offline_rules"` (veya "unknown").
  - `provider_response_id = None`.
  - Kod kanıtı: `test_offline_strict_argon_is_false` testi bu durumu kesin olarak garanti altına alır.
- Canlı modda (`use_live_api=True`):
  - Model sağlayıcısından gerçek `provider_response_id` (ör. `genai-resp-...`) alınır; asla sentetik ID (`lc_run--`) yazılmaz (`test_lc_id_is_never_provider_id`).

### S5. Model Kararı ve İnsan Uzman Onayı Nasıl Ayrılıyor?
- Kod Referansı: `two_stage_visual_verifier.py` L415-L425, `slide_supervisor_schema.py` L110-L150, `test_argon_verification_states.py`.
- **Dört Katmanlı Ayrım:**
  1. `argon_requested` (bool): Politikanın modeli talep ettiğini gösterir.
  2. `verified_with_argon` (bool): Modelin gerçekten çalıştığı ve Argon kimliğinin doğrulandığı kanıtıdır.
  3. `model_decision` (`compatible`, `incompatible`, `review_required`): Modelin klinik içerik kararıdır. `verified_with_argon=True` olsa dahi model görseli reddedebilir (`incompatible`).
  4. `expert_review_status` (`pending`, `approved`, `rejected`): Yalnızca insan hekim tarafından değiştirilebilir (`apply_expert_approval`).
- **Kod Kanıtı:**
  - Model `compatible` dese dahi `expert_review_status` `pending` kalır (`test_model_compatible_does_not_change_expert_status`).
  - Görsel dosyası veya bağlam metni bir byte bile değişirse (`compute_context_hash`), mevcut insan onayı otomatik olarak düşer (`test_context_or_image_change_invalidates_approval`).

---

## 4. TEST VE DEĞERLENDİRME KAYITLARI

- **Pytest Çalıştırma Özeti:**
  - Komut: `pytest -q tests/`
  - Ortam: Python 3.13.14 x64, pytest-9.2.0, Windows 11
  - Sonuç: **68 passed, 3 skipped** (Toplam 71 test, 1.90s).
  - Skipped Testler: `test_update_installer.py` altındaki installer testleri (yalnızca kurulum paketinde geçerli).
- **DeepEval Retina Benchmark Özeti:**
  - Komut: `python run_deepeval_retina_bench.py`
  - Toplam Olgular: 10/10 klinik tuzak olgusu.
  - Yanlış Görsel Kabulü: **0** (CRAO/CRVO, Stargardt/Best uyuşmazlıkları tam yakalandı).
  - Doğru Görsel Reddi: **5/5**.
  - Modalite ve Panel Doğruluğu: **%100**.

---

## 5. DİZİN YAPISI

```
pipeline_current_source_review.zip
├── README_INCELEME.md          # Bu mimari inceleme rehberi
├── source_manifest.json        # Dosya yolları, boyutlar ve SHA256 özetleri
├── missing_items.md            # Eksik / kasıtlı çıkarılmış bileşen listesi
├── src/                        # Aktif kaynak kodlar (bookgraph + modüller)
├── config/                     # Bağımlılıklar, freeze, ortam değişkenleri durumu
├── tests/                      # Birim, güvenlik ve DeepEval testleri
├── examples/                   # SlideSpec, manifest, render ve klinik vaka örnekleri
└── logs/                       # Gerçekleştirilen test ve trace logları
```
