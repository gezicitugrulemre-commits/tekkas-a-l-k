# Eksik ve Kasıtlı Olarak Çıkarılmış Kritik Parçalar (missing_items.md)

Bu belge, bağımsız kod inceleme paketinde yer almayan, projede bulunamayan veya güvenlik / boyut / telif politikaları gereği kasıtlı olarak hariç tutulan parçaları belgeler.

---

## 1. Bulunamayan Bağımlılıklar (Depoda Mevcut Olmayanlar)

- **PPTAgent ve Presenton Adaptörleri:**
  - **Durum:** Bulunamadı (Depoda mevcut değil).
  - **Açıklama:** Projede üçüncü parti PPTAgent veya Presenton araçlarına ait bir adaptör veya kod bulunmamaktadır. Sistem, PPTX üretimi ve denetimi için tamamen kendi geliştirdiği yerel modülleri (pptx_publisher.py, 
etina_study_builder_core.py, dr_masterclass_engine.py, pptx_render_checker.py ve rgon_slide_supervisor_graph.py) kullanmaktadır.
- **Git Versiyon Kontrol Geçmişi (.git):**
  - **Durum:** Bulunamadı.
  - **Açıklama:** Çalışma alanında .git dizini ve işletim sistemi ortamında git CLI bulunmamaktadır. Bu nedenle commit kimliği, dal yapısı ve git diff yerine doğrudan dosya sistemi anlık görüntüsü (snapshot) incelenmiş ve paketlenmiştir.

---

## 2. Güvenlik Nedeniyle Kasıtlı Olarak Çıkarılan Parçalar

- **Gerçek .env Dosyaları ve Kimlik Bilgileri:**
  - **Durum:** Kasıtlı olarak hariç tutuldu.
  - **Açıklama:** Canlı API anahtarları (GEMINI_API_KEY, GOOGLE_API_KEY, VERTEXAI_PROJECT, ANTHROPIC_API_KEY, AWS_*, NCBI_API_KEY, LANGSMITH_API_KEY), OAuth tokenları ve ADC servis hesabı JSON dosyaları güvenlik kuralları uyarınca pakete konulmamıştır.
  - **Alternatif:** config/.env.example, config/.env.multimodal.example ve sır içermeyen config/sample_sanitized_config.json ile config/env_variables_status.json (yalnızca değişken adları ve SET/UNSET durumu) eklenmiştir.
- **Kimliği Belirlenebilir Hasta Bilgileri (PHI):**
  - **Durum:** Kasıtlı olarak hariç tutuldu.
  - **Açıklama:** Tıbbi etik standartları gereğince hasta kimlik verileri pakette yer almaz; atlas görselleri eğitim amaçlı anonimleştirilmiş kaynaklardan alınmıştır.

---

## 3. Boyut ve Depo Verimliliği Nedeniyle Örnekle Sınırlandırılan Parçalar

- **Model Ağırlıkları ve Sanal Ortamlar:**
  - **Durum:** Hariç tutuldu (.venv/, .venv_vision/, 
epos/FLAIR, 
epos/RETFound_MAE).
  - **Açıklama:** Onlarca gigabaytlık ikili ağırlık dosyaları ve derlenmiş kütüphaneler kaynak kodu inceleme paketine dahil edilmemiştir.
- **Tüm Medikal Kitap PDF Arşivi:**
  - **Durum:** Hariç tutuldu (C:/Users/gezic/OneDrive/Desktop/DATABASE/Ophthalmology KİTAPLARI).
  - **Açıklama:** Çok yüksek boyutlu (onlarca GB) tam metin tıp kitapları pakete konulmamış; bunların çıkarım adaptörleri (docling_pdf_extractor.py, atch_extract_all_volumes.py) ve temsilî katalog kayıtları sağlanmıştır.
- **Büyük Vektör ve İndeks Veritabanları:**
  - **Durum:** Hariç tutuldu (storage/chroma_db/, 
etina_visual_index.json ~5.3 MB).
  - **Alternatif:** İnceleme için yeterli küçük örnek manifestolar (examples/slide_supervisor_manifest.json, examples/retina_study_atlas_supervised.review-required.visual-review.json) pakete eklenmiştir.
- **Python Derleme Önbellekleri:**
  - **Durum:** Hariç tutuldu (__pycache__/, *.pyc).
