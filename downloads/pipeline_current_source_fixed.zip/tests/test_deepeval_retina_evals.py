"""
test_deepeval_retina_evals.py — DeepEval & İki Aşamalı Görsel Doğrulama Pytest Entegrasyonu.

Mevcut 45 güvenlik testinin yanına eklenir.
Varsayılan olarak 0 ücretli API çağrısı ile tamamen deterministik / çevrimdışı çalışır.
"""

import tempfile
from pathlib import Path
import pytest
from run_deepeval_retina_bench import run_eval_suite, get_clinical_eval_cases
from two_stage_visual_verifier import TwoStageVisualVerifier


def test_deepeval_full_benchmark_suite_passes():
    """Tüm 10 medikal tuzak senaryosunun beklenen kararları ürettiğini doğrular."""
    report = run_eval_suite(live_eval=False)
    assert report["total_cases"] == 10
    assert report["passed_cases"] == 10
    assert report["false_acceptances"] == 0
    assert report["estimated_cost_usd"] == 0.0


@pytest.mark.parametrize("case_index", range(10))
def test_individual_clinical_trap_case(case_index):
    """Her klinik tuzağı izole olarak doğrular."""
    with tempfile.TemporaryDirectory() as tmp_dir_str:
        tmp_dir = Path(tmp_dir_str)
        cases = get_clinical_eval_cases(tmp_dir)
        c = cases[case_index]
        verifier = TwoStageVisualVerifier(use_live_api=False)

        res = verifier.verify_visual(
            image_path=c["image"],
            target_slide_title=c["target_slide_title"],
            target_disease_id=c["target_disease_id"],
            original_caption=c["original_caption"],
            expected_modality=c["expected_modality"],
        )

        assert res.model_decision == c["expected_decision"], (
            f"{c['case_id']} ({c['name']}) başarısız: beklenen {c['expected_decision']}, alınan {res.model_decision}. "
            f"Gerekçe: {res.stage2.clinical_rationale}"
        )
