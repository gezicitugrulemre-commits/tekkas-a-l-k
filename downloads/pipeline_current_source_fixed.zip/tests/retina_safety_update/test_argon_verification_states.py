"""
test_argon_verification_states.py — Argon Doğrulama Durumları ve İnsan Onayı Ayrımı Regresyon Testleri.

Tüm testler 0 ücretli API çağrısıyla, kontrollü mock yanıtlar ve deterministik kurallarla çalışır:
1. Offline + strict_argon=True -> verified_with_argon=False.
2. Offline olumlu caption -> insan onayı oluşmaz, review_required kalır.
3. Eksik sağlayıcı model kimliği -> actual_model=unknown, verified_with_argon=False.
4. Argon yerine Flash yanıtı -> Argon doğrulaması başarısız.
5. Bir aşama tamamlanmadı -> verified_with_argon=False.
6. İki aşama gerçek Argon yanıtı taklidiyle tamamlandı, karar incompatible -> verified_with_argon=True, model_decision=incompatible.
7. decision=compatible ve herhangi bir zorunlu kontrol False/unknown -> kabul engellenir.
8. Model compatible -> expert_review_status değişmez (review_required).
9. Açık insan onayı -> ayrı ve izlenebilir kaydedilir.
10. Görsel veya bağlam değişti -> eski onay yeni içerik için kullanılmaz.
11. Canlı yol eksik import nedeniyle başlamadan düşmez (_assert_argon_identity mevcut).
12. Normal builder / resolver yolunda model_review ayrı saklanır, reviewer model adıyla ezilmez.
"""

import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image

from bookgraph.safety import file_hash
from bookgraph import llm
from two_stage_visual_verifier import (
    TwoStageVisualVerifier,
    FullVisualAuditRecord,
    compute_context_hash,
    validate_model_decision,
    Stage1BlindObservation,
)
from retina_visual_resolver import RetinaVisualResolver


@pytest.fixture
def sample_image(tmp_path):
    p = tmp_path / "test_retina.png"
    img = Image.new("RGB", (100, 100), color="red")
    img.save(p)
    return p


def mock_response(model="gemini-4-argon", content="{}", response_id="google-resp-123"):
    meta = {}
    if model:
        meta["model_version"] = model
    if response_id:
        meta["response_id"] = response_id
    return SimpleNamespace(
        content=content,
        response_metadata=meta,
        usage_metadata={"input_tokens": 150, "output_tokens": 50},
        id="lc_run--001",
    )


class MockLLM:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def invoke(self, messages):
        self.calls.append(messages)
        if not self.responses:
            raise RuntimeError("Beklenmeyen ek LLM çağrısı")
        resp = self.responses.pop(0)
        if isinstance(resp, Exception):
            raise resp
        return resp


# 1. Offline + strict_argon=True -> verified_with_argon=False
def test_offline_strict_argon_is_false(sample_image):
    verifier = TwoStageVisualVerifier(use_live_api=False, strict_argon=True)
    res = verifier.verify_visual(
        sample_image,
        target_slide_title="CRAO Slaytı",
        target_disease_id="crao",
        original_caption="Color fundus of CRAO with cherry-red spot.",
        expected_modality="fundus",
    )
    assert res.argon_requested is True
    assert res.verified_with_argon is False
    assert res.execution_mode == "offline"
    assert "argon" not in res.actual_model.lower()


# 2. Offline olumlu caption -> insan onayı oluşmaz, review_required kalır
def test_offline_positive_caption_no_human_approval(sample_image):
    verifier = TwoStageVisualVerifier(use_live_api=False, strict_argon=True)
    res = verifier.verify_visual(
        sample_image,
        target_slide_title="Santral Retinal Arter Tıkanıklığı (CRAO)",
        target_disease_id="crao",
        original_caption="Fundus photograph of acute CRAO showing opaque white retina and a prominent cherry-red spot.",
        expected_modality="fundus",
    )
    assert res.model_decision == "review_required"
    assert res.expert_review_status == "review_required"
    assert res.expert_review_status != "approved"
    assert res.stage2.claim_support_check == "not_evaluated"


# 3. Eksik sağlayıcı model kimliği -> actual_model=unknown, verified_with_argon=False
def test_missing_provider_model_identity_sets_unknown(sample_image, monkeypatch):
    stage1_json = json.dumps({"detected_modality": "fundus", "visible_findings": ["cherry-red spot"]})
    stage2_json = json.dumps({
        "disease_check": True, "modality_check": True, "panel_check": True,
        "claim_support_check": True, "decision": "compatible", "clinical_rationale": "Tam uyumlu."
    })
    # model=None -> response_metadata'da model_version yok
    mock_llm = MockLLM([
        mock_response(model=None, content=stage1_json),
        mock_response(model=None, content=stage2_json),
    ])

    verifier = TwoStageVisualVerifier(use_live_api=True, strict_argon=False, llm_factory=lambda _: mock_llm)
    res = verifier.verify_visual(
        sample_image,
        target_slide_title="CRAO Slaytı",
        target_disease_id="crao",
        original_caption="CRAO fundus",
    )
    assert res.actual_model == "unknown"
    assert res.verified_with_argon is False


# 4. Argon yerine Flash yanıtı -> Argon doğrulaması başarısız
def test_flash_response_for_strict_argon_fails(sample_image):
    stage1_json = json.dumps({"detected_modality": "fundus", "visible_findings": ["cherry-red spot"]})
    mock_llm = MockLLM([
        mock_response(model="gemini-3.8-flash", content=stage1_json),
    ])
    verifier = TwoStageVisualVerifier(use_live_api=True, strict_argon=True, llm_factory=lambda _: mock_llm)
    with pytest.raises(ValueError, match="Argon zorunlu işte sağlayıcı yanıtı Argon kimliğini doğrulamadı"):
        verifier.verify_visual(
            sample_image,
            target_slide_title="CRAO Slaytı",
            target_disease_id="crao",
            original_caption="CRAO fundus",
        )


# 5. Bir aşama tamamlanmadı -> verified_with_argon=False
def test_incomplete_stage_fails_argon_verification(sample_image):
    stage1_json = json.dumps({"detected_modality": "fundus", "visible_findings": ["cherry-red spot"]})
    # Aşama 1 başarılı, Aşama 2 hata fırlatıyor
    mock_llm = MockLLM([
        mock_response(model="gemini-4-argon", content=stage1_json),
        RuntimeError("Bağlantı koptu"),
    ])
    verifier = TwoStageVisualVerifier(use_live_api=True, strict_argon=True, llm_factory=lambda _: mock_llm)
    with pytest.raises(RuntimeError, match="Bağlantı koptu"):
        verifier.verify_visual(
            sample_image,
            target_slide_title="CRAO Slaytı",
            target_disease_id="crao",
            original_caption="CRAO fundus",
        )


# 6. İki aşama gerçek Argon yanıtı taklidiyle tamamlandı, karar incompatible
# -> verified_with_argon=True, model_decision=incompatible
def test_argon_completed_with_incompatible_decision(sample_image):
    stage1_json = json.dumps({
        "detected_modality": "fundus",
        "visible_findings": ["vitelliform egg-yolk macular lesion"],
        "readable_panel_letters": [],
        "image_quality_notes": "Yüksek çözünürlük",
        "uncertainties": [],
        "is_compound_pathology": False,
    })
    stage2_json = json.dumps({
        "disease_check": False,
        "modality_check": True,
        "panel_check": True,
        "claim_support_check": False,
        "decision": "incompatible",
        "clinical_rationale": "Görsel Best hastalığı lezyonudur; Stargardt ile uyumsuzdur.",
        "quarantine_reason": "Hastalık uyuşmazlığı.",
    })
    mock_llm = MockLLM([
        mock_response(model="gemini-4-argon", content=stage1_json, response_id="resp-argon-1"),
        mock_response(model="gemini-4-argon", content=stage2_json, response_id="resp-argon-2"),
    ])
    verifier = TwoStageVisualVerifier(use_live_api=True, strict_argon=True, llm_factory=lambda _: mock_llm)
    res = verifier.verify_visual(
        sample_image,
        target_slide_title="Stargardt Hastalığı",
        target_disease_id="stargardt",
        original_caption="Best vitelliform lesion",
        expected_modality="fundus",
    )
    # Argon çalıştı ve doğrulandı:
    assert res.verified_with_argon is True
    assert res.actual_model == "gemini-4-argon"
    assert res.provider_response_id == "resp-argon-2"
    assert res.langchain_run_id == "lc_run--001"
    # Fakat içerik reddedildi:
    assert res.model_decision == "incompatible"
    assert res.expert_review_status == "review_required"


# 7. decision=compatible ve herhangi bir zorunlu kontrol False/unknown -> kabul engellenir
def test_compatible_decision_blocked_if_any_check_fails():
    dummy_s1 = Stage1BlindObservation(
        detected_modality="fundus",
        visible_findings=["lesion"],
        readable_panel_letters=[],
        image_quality_notes="",
        uncertainties=[],
        is_compound_pathology=False,
    )
    # Model 'compatible' dedi fakat modality_check=False
    dec, rat, quar = validate_model_decision(
        suggested_decision="compatible",
        disease_check=True,
        modality_check=False,
        panel_check=True,
        claim_support_check=True,
        stage1=dummy_s1,
    )
    assert dec == "incompatible"
    assert "modality_check" in rat

    # Model 'compatible' dedi fakat claim_support_check='not_evaluated'
    dec2, rat2, quar2 = validate_model_decision(
        suggested_decision="compatible",
        disease_check=True,
        modality_check=True,
        panel_check=True,
        claim_support_check="not_evaluated",
        stage1=dummy_s1,
    )
    assert dec2 == "review_required"
    assert "claim_support_check" in rat2


# 8. Model compatible -> expert_review_status değişmez (review_required)
def test_model_compatible_does_not_change_expert_status(sample_image):
    stage1_json = json.dumps({
        "detected_modality": "fundus",
        "visible_findings": ["cherry-red spot", "pale retina"],
        "readable_panel_letters": [],
        "image_quality_notes": "Net fundus",
        "uncertainties": [],
        "is_compound_pathology": False,
    })
    stage2_json = json.dumps({
        "disease_check": True,
        "modality_check": True,
        "panel_check": True,
        "claim_support_check": True,
        "decision": "compatible",
        "clinical_rationale": "Tam uyumlu saf CRAO.",
    })
    mock_llm = MockLLM([
        mock_response(model="gemini-4-argon", content=stage1_json),
        mock_response(model="gemini-4-argon", content=stage2_json),
    ])
    verifier = TwoStageVisualVerifier(use_live_api=True, strict_argon=True, llm_factory=lambda _: mock_llm)
    res = verifier.verify_visual(
        sample_image,
        target_slide_title="CRAO Slaytı",
        target_disease_id="crao",
        original_caption="Acute CRAO with cherry-red spot",
        target_claim="Foveada cherry-red lekesi görülür",
        expected_modality="fundus",
    )
    assert res.verified_with_argon is True
    assert res.model_decision == "compatible"
    # Model onaylasa dahi uzman inceleme durumu 'approved' OLAMAZ!
    assert res.expert_review_status == "review_required"
    assert res.expert_review_status != "approved"


# 9. Açık insan onayı -> ayrı ve izlenebilir kaydedilir
def test_explicit_human_approval_tracked(sample_image, tmp_path):
    idx_path = tmp_path / "registry.json"
    rec = {
        "path": str(sample_image),
        "disease_ids": ["crao"],
        "original_caption": "Acute CRAO fundus photograph.",
        "review_status": "review_required",
        "reviewer": None,
        "source_id": "BOOK1",
        "page": 10,
        "figure_id": "10.1",
        "panel_id": "A",
        "modality": "fundus",
        "bbox": [0, 0, 10, 10],
        "image_sha256": file_hash(sample_image),
    }
    idx_path.write_text(json.dumps({"registry": {"crao": [rec]}}), encoding="utf-8")
    resolver = RetinaVisualResolver(idx_path, tmp_path / "cache")

    # Başlangıçta insan onayı olmadığı için görsel yerleştirilmez
    vis, _ = resolver.resolve_visual(1, "CRAO Tedavisi", "1.1")
    assert vis is None

    # Açık insan onayı verilir
    ok = resolver.apply_expert_approval(
        str(sample_image),
        reviewer_id="dr_uzman_hekim",
        slide_title="CRAO Tedavisi",
        disease_id="crao",
        caption=rec["original_caption"],
    )
    assert ok is True
    rec_updated = resolver.registry["crao"][0]
    assert rec_updated["expert_review_status"] == "approved"
    assert rec_updated["reviewer"] == "dr_uzman_hekim"
    assert "reviewed_at" in rec_updated
    assert "approved_context_hash" in rec_updated

    # Artık onaylı kayıt olarak yerleştirilir
    vis2, cap2 = resolver.resolve_visual(1, "CRAO Tedavisi", "1.1")
    assert vis2 is not None
    assert "dr_uzman_hekim" not in cap2  # Slayt altyazısına insan ismi sızmaz


# 10. Görsel veya bağlam değişti -> eski onay yeni içerik için kullanılmaz
def test_context_or_image_change_invalidates_approval(sample_image, tmp_path):
    idx_path = tmp_path / "registry.json"
    rec = {
        "path": str(sample_image),
        "disease_ids": ["crao"],
        "original_caption": "Acute CRAO fundus photograph.",
        "review_status": "review_required",
        "reviewer": None,
        "source_id": "BOOK1",
        "page": 10,
        "figure_id": "10.1",
        "panel_id": "A",
        "modality": "fundus",
        "bbox": [0, 0, 10, 10],
        "image_sha256": file_hash(sample_image),
    }
    idx_path.write_text(json.dumps({"registry": {"crao": [rec]}}), encoding="utf-8")
    resolver = RetinaVisualResolver(idx_path, tmp_path / "cache")

    # CRAO için insan onayı ver
    resolver.apply_expert_approval(
        str(sample_image),
        reviewer_id="dr_uzman_hekim",
        slide_title="CRAO Tedavisi",
        disease_id="crao",
        caption=rec["original_caption"],
    )

    # Başlık değişirse (örneğin Stargardt yapılırsa), eski onay yeni bağlam için geçersiz olmalı
    vis, _ = resolver.resolve_visual(1, "Stargardt Hastalığı", "1.1", topic_id="stargardt")
    assert vis is None

    # Görsel dosyası diskte değişirse onay geçersiz olmalı
    Image.new("RGB", (100, 100), color="blue").save(sample_image)
    vis2, _ = resolver.resolve_visual(1, "CRAO Tedavisi", "1.1")
    assert vis2 is None


# 11. Canlı yol eksik import nedeniyle başlamadan düşmez (_assert_argon_identity)
def test_live_path_imports_cleanly():
    from bookgraph.llm import _assert_argon_identity
    resp = mock_response(model="gemini-4-argon")
    actual = _assert_argon_identity("gemini-4-argon", resp)
    assert actual == "gemini-4-argon"

    with pytest.raises(ValueError):
        _assert_argon_identity("gemini-4-argon", mock_response(model="gemini-3.8-flash"))


# 12. Normal builder / resolver yolunda model_review ayrı saklanır, reviewer model adıyla ezilmez
def test_normal_builder_path_preserves_states(sample_image, tmp_path):
    idx_path = tmp_path / "registry.json"
    rec = {
        "path": str(sample_image),
        "disease_ids": ["crao"],
        "original_caption": "Acute CRAO fundus photograph.",
        "review_status": "review_required",
        "reviewer": None,
        "source_id": "BOOK1",
        "page": 10,
        "figure_id": "10.1",
        "panel_id": "A",
        "modality": "fundus",
        "bbox": [0, 0, 10, 10],
        "image_sha256": file_hash(sample_image),
    }
    idx_path.write_text(json.dumps({"registry": {"crao": [rec]}}), encoding="utf-8")
    resolver = RetinaVisualResolver(idx_path, tmp_path / "cache")

    # İki aşamalı verifier ile çağır
    vis, _ = resolver.resolve_visual(1, "CRAO Tedavisi", "1.1", enable_two_stage=True)
    assert vis is None  # İnsan onayı olmadığı için yerleştirilmez
    rec_updated = resolver.registry["crao"][0]
    assert "model_review" in rec_updated
    assert rec_updated.get("reviewer") is None  # Model adı reviewer'a yazılmadı!
    assert rec_updated.get("review_status") == "review_required"  # Otomatik approved yapılmadı!
