"""All tests are local: prevent accidental model calls and telemetry."""
import os
import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
os.environ.update(LANGSMITH_TRACING='false', PHOENIX_ENABLED='false', EXTRA_ENV_FILE='')

@pytest.fixture(autouse=True)
def isolated_test(tmp_path, monkeypatch):
    import socket
    def deny(*args, **kwargs):
        raise RuntimeError('External network disabled in local tests')
    monkeypatch.setattr(socket.socket, 'connect', deny)
    monkeypatch.setattr(socket, 'create_connection', deny)
    monkeypatch.chdir(tmp_path)
