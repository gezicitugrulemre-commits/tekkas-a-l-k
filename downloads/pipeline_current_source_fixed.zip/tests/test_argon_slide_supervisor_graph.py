"""
tests/test_argon_slide_supervisor_graph.py — Argon Slayt Düzeltme Alt Grafiği Entegrasyon Testleri.

Tüm 10 zorunlu senaryoyu (A'dan J'ye) 0 USD maliyetle, ücretli dış çağrı yapmadan doğrular:
A. Yanlış görsel -> replace_visual -> yeni uygun aday -> re-render -> ikinci denetim accept_draft.
B. Eksik kaynak -> retrieve_more -> gerçek kaynak pasajı eklenir -> revise_slide -> accept_draft.
C. Metin hatası -> revise_text -> hedef alan düzeltilir, doz ve kaynaklar korunur.
D. Sonuç bulunamaması -> 2 düzeltme sonunda review_required (otomatik kabul yok).
E. Geçersiz karar -> bilinmeyen görsel kimliği veya şema dışı eylem reddedilir.
F. Döngü güvenliği -> aynı reddedilen adaya veya karara sonsuz döngü engellenir.
G. Argon hatası -> zorunlu Argon çağrısında Flash dönerse hata fırlatılır, sessiz geçilmez.
H. İnsan onayı -> model accept_draft döndürse bile expert_review_status review_required kalır.
I. Checkpoint -> kesinti sonrası aynı thread_id ile devam edildiğinde adımlar korunur.
J. Renderer yokluğu -> render alınamadığında görsel onaylanamaz, review_required olur.
"""

import json
import os
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image

from bookgraph.safety import file_hash
from slide_supervisor_schema import (
    SlideSpec,
    SlideCard,
    ClinicalClaim,
    SourcePassage,
    CandidateVisual,
    SupervisorDecision,
    RevisionInstructions,
    SearchRequest,
)
from argon_slide_supervisor_graph import (
    ArgonSlideSupervisorGraph,
    render_slide_spec_to_png,
)


@pytest.fixture
def test_images(tmp_path):
    """Test için gerçek disk görselleri oluşturur."""
    p_wrong = tmp_path / "img_wrong_crvo.png"
    Image.new("RGB", (100, 100), color="blue").save(p_wrong)

    p_valid = tmp_path / "img_valid_crao.png"
    Image.new("RGB", (100, 100), color="white").save(p_valid)

    p_dme = tmp_path / "img_dme_oct.png"
    Image.new("RGB", (100, 100), color="green").save(p_dme)

    return {
        "wrong": CandidateVisual(
            image_id="IMG-WRONG-CRVO",
            path=str(p_wrong),
            modality="fundus",
            figure_id="1.1",
            original_caption="Combined CRVO and CRAO with hemorrhages",
            image_sha256=file_hash(p_wrong),
            source_id="SRC-ATLAS-01",
            disease_ids=["crvo", "crao"],
        ),
        "valid": CandidateVisual(
            image_id="IMG-VALID-CRAO",
            path=str(p_valid),
            modality="fundus",
            figure_id="1.2",
            original_caption="Acute pure CRAO fundus with classic cherry-red spot",
            image_sha256=file_hash(p_valid),
            source_id="SRC-ATLAS-01",
            disease_ids=["crao"],
        ),
        "dme": CandidateVisual(
            image_id="IMG-DME-OCT",
            path=str(p_dme),
            modality="OCT B-scan",
            figure_id="2.1",
            original_caption="SD-OCT B-scan of diabetic macular edema showing intraretinal cystoid spaces",
            image_sha256=file_hash(p_dme),
            source_id="SRC-ATLAS-02",
            disease_ids=["dme"],
        ),
    }


def create_sample_slide_spec(
    slide_id="SLIDE-CRAO-01",
    topic_id="crao",
    selected_vis=None,
    candidates=None,
    cards=None,
    claims=None,
    sources=None,
    expected_modality="fundus",
) -> SlideSpec:
    return SlideSpec(
        slide_id=slide_id,
        topic_id=topic_id,
        chapter_num=1,
        title="Santral Retinal Arter Tıkanıklığı (CRAO) Tanı ve Tedavisi",
        category="VASKÜLER RETİNA",
        subtitle="Akut iskemik faz ve biyobelirteçler",
        cards=cards or [
            SlideCard(
                card_id="CARD-01",
                title="Klinik Özellikler",
                lead="Akut ağrısız ani görme kaybı tablosudur.",
                items=["Foveada kiraz kırmızısı leke (cherry-red spot) saptanır.", "Retinada yaygın iskemik solukluk mevcuttur."],
                footer="İlk 4-6 saat kritik müdahale penceresidir.",
            )
        ],
        claims=claims or [
            ClinicalClaim(
                claim_id="CLM-01",
                statement="Foveada kiraz kırmızısı leke saptanır.",
                supporting_source_ids=["SRC-GUNCEL-2018"],
            )
        ],
        sources=sources if sources is not None else [
            SourcePassage(
                source_id="SRC-GUNCEL-2018",
                citation_ref="Güncel Retina 2018; 2(2):18-24",
                text="CRAO olgularında foveada kiraz kırmızısı leke ve arteriel daralma görülür.",
                page_num=18,
            )
        ],
        candidate_images=candidates or [],
        selected_visual=selected_vis,
        expected_modality=expected_modality,
    )


# -----------------------------------------------------------------------------
# A. Yanlış görsel -> replace_visual -> yeni uygun aday -> accept_draft
# -----------------------------------------------------------------------------
def test_scenario_a_wrong_visual_replaced_but_requires_review(test_images):
    # Başlangıçta birleşik CRAO+CRVO görseli seçili
    spec = create_sample_slide_spec(
        selected_vis=test_images["wrong"],
        candidates=[test_images["wrong"], test_images["valid"]],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    state = graph.run_supervisor(spec)

    assert state.status == "review_required"
    assert state.correction_count == 1
    assert state.slide_spec.selected_visual.image_id == "IMG-VALID-CRAO"
    assert "IMG-WRONG-CRVO" in state.rejected_candidate_ids

    # Eylem geçmişini doğrula
    actions = [a.action for a in state.action_history]
    assert "replace_visual" in actions
    assert "apply_visual" in actions
    # İnsan uzman onayı model tarafından asla verilmez
    assert state.expert_review_status == "review_required"


# -----------------------------------------------------------------------------
# B. Eksik kaynak -> retrieve_more -> gerçek pasaj eklenir -> accept_draft
# -----------------------------------------------------------------------------
def test_scenario_b_missing_evidence_is_not_fabricated(test_images):
    # İddia var fakat kaynak listesinde karşılığı yok (unsupported)
    unsupported_claim = ClinicalClaim(
        claim_id="CLM-UNSUPPORTED",
        statement="İntravenöz trombolitik tedavi ilk 4.5 saatte uygulanabilir.",
        supporting_source_ids=[],
        status="unsupported",
    )
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
        claims=[unsupported_claim],
        sources=[],  # Kaynak boş
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    state = graph.run_supervisor(spec)

    assert state.status == "review_required"
    assert state.slide_spec.sources == []
    assert state.slide_spec.claims[0].status == "unsupported"
    assert "kan" in state.latest_decision.reason.lower()


# -----------------------------------------------------------------------------
# C. Metin hatası -> revise_text -> hedef alan güncellenir, doz/kaynak korunur
# -----------------------------------------------------------------------------
def test_scenario_c_offline_does_not_invent_treatment(test_images):
    # Kart içeriğinde revizyon etiketi var
    card_with_error = SlideCard(
        card_id="CARD-TEDAVI",
        title="Tedavi Protokolü",
        lead="Acil yaklaşım ilkeleri.",
        items=["[REVISE] Eski hatalı dozaj: 500 mg aspirin verilmez", "Göz masajı ve ön kamara parasentezi uygulanabilir."],
        footer="Dozaj ve endikasyon hekim kontrolündedir.",
    )
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
        cards=[card_with_error],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    state = graph.run_supervisor(spec)

    assert state.status == "review_required"
    assert state.slide_spec.cards[0].items == card_with_error.items
    assert state.verified_with_argon is False


# -----------------------------------------------------------------------------
# D. Sonuç bulunamaması -> 2 düzeltme sonunda review_required (kabul engellenir)
# -----------------------------------------------------------------------------
def test_scenario_d_budget_exhausted_routes_to_review_required(test_images):
    # Yalnızca yanlış görsel var ve başka alternatif aday yok
    spec = create_sample_slide_spec(
        selected_vis=test_images["wrong"],
        candidates=[test_images["wrong"]],  # Başka aday yok
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False, max_corrections=2)
    state = graph.run_supervisor(spec)

    assert state.status == "review_required"
    assert state.expert_review_status == "review_required"
    assert len(state.open_deficiencies) > 0
    # Asla zorunlu veya otomatik kabul edilmedi
    assert state.status != "accepted_draft"


# -----------------------------------------------------------------------------
# E. Geçersiz karar -> bilinmeyen görsel kimliği veya şema dışı karar reddedilir
# -----------------------------------------------------------------------------
def test_scenario_e_invalid_decision_rejected(test_images):
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
    )
    # Taklit LLM bilinmeyen bir görsel kimliği ("IMG-HALLUCINATED-999") talep ediyor
    fake_decision_json = json.dumps({
        "action": "replace_visual",
        "reason": "Uydurma görsel ID'si talep edildi.",
        "target_image_ids": ["IMG-HALLUCINATED-999"],
        "affected_claim_ids": [],
        "target_source_ids": [],
    })

    def fake_factory(model_str):
        return SimpleNamespace(invoke=lambda _: SimpleNamespace(
            content=fake_decision_json,
            response_metadata={"model_version": "gemini-4-argon"},
            usage_metadata={"input_tokens": 100, "output_tokens": 50},
        ))

    graph = ArgonSlideSupervisorGraph(llm_factory=fake_factory, strict_argon=True)
    state = graph.run_supervisor(spec)

    # Bilinmeyen kimlik reddedilerek review_required'a çekilmeli
    assert state.status == "review_required"
    assert any("Geçersiz görsel kimliği" in d for d in state.open_deficiencies)


# -----------------------------------------------------------------------------
# F. Döngü güvenliği -> aynı reddedilen adaya veya karara sonsuz döngü engellenir
# -----------------------------------------------------------------------------
def test_scenario_f_loop_safety_and_no_infinite_recursion(test_images):
    # Birleşik görsel var ve aday listesi boş
    spec = create_sample_slide_spec(
        selected_vis=test_images["wrong"],
        candidates=[],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False, max_corrections=2)
    state = graph.run_supervisor(spec)

    # En fazla max_corrections kadar çalışıp durmalı
    assert state.correction_count <= 2
    assert state.status == "review_required"


# -----------------------------------------------------------------------------
# G. Argon hatası -> zorunlu Argon çağrısında Flash dönerse hata fırlatılır
# -----------------------------------------------------------------------------
def test_scenario_g_strict_argon_rejects_flash_fallback(test_images):
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
    )

    # Sağlayıcı Argon yerine Flash döndürüyor
    def flash_factory(model_str):
        return SimpleNamespace(invoke=lambda _: SimpleNamespace(
            content=json.dumps({"action": "accept_draft", "reason": "Flash onayı"}),
            response_metadata={"model_version": "gemini-3.8-flash"},
            usage_metadata={"input_tokens": 50, "output_tokens": 20},
        ))

    graph = ArgonSlideSupervisorGraph(llm_factory=flash_factory, strict_argon=True)
    with pytest.raises(ValueError, match="Argon zorunlu işte sağlayıcı yanıtı Argon kimliğini doğrulamadı"):
        graph.run_supervisor(spec)


# -----------------------------------------------------------------------------
# H. İnsan onayı -> model accept_draft döndürse bile expert_review_status approved olmaz
# -----------------------------------------------------------------------------
def test_scenario_h_accept_draft_never_grants_human_approval(test_images):
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    state = graph.run_supervisor(spec)

    assert state.status == "review_required"
    # Model kabulü asla insan onayı (approved) sayılamaz
    assert state.expert_review_status == "review_required"
    assert state.expert_review_status != "approved"


# -----------------------------------------------------------------------------
# I. Checkpoint -> kesinti sonrası aynı thread_id ile devam edildiğinde adımlar korunur
# -----------------------------------------------------------------------------
def test_scenario_i_checkpoint_preserves_completed_steps(test_images):
    spec = create_sample_slide_spec(
        slide_id="SLIDE-CHECKPOINT-TEST",
        selected_vis=test_images["wrong"],
        candidates=[test_images["wrong"], test_images["valid"]],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    thread = "thread-ckpt-001"

    # İlk çalıştırma
    state1 = graph.run_supervisor(spec, thread_id=thread)
    assert state1.status == "review_required"
    assert state1.correction_count == 1

    # Checkpointten tekrar çağrıldığında
    state2 = graph.run_supervisor(spec, thread_id=thread)
    assert state2.status == "review_required"
    # Düzeltme sayısı sıfırlanmaz veya gereksiz şişmez
    assert state2.correction_count >= 1


# -----------------------------------------------------------------------------
# J. Renderer yokluğu -> render alınamadığında görsel onaylanamaz, review_required olur
# -----------------------------------------------------------------------------
def test_scenario_j_missing_renderer_blocks_acceptance(test_images, monkeypatch):
    monkeypatch.setenv("SIMULATE_NO_RENDERER", "1")
    spec = create_sample_slide_spec(
        selected_vis=test_images["valid"],
        candidates=[test_images["valid"]],
    )
    graph = ArgonSlideSupervisorGraph(use_live_api=False)
    state = graph.run_supervisor(spec)

    assert state.render_available is False
    assert state.status == "review_required"
    assert any("Render" in d for d in state.open_deficiencies)
