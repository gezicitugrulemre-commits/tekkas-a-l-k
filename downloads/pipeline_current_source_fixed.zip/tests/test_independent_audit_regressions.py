import json
import sys
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image
from pptx import Presentation
from bookgraph.safety import assert_clinical_invariants, file_hash
from slide_supervisor_schema import *
from argon_slide_supervisor_graph import ArgonSlideSupervisorGraph
from pptx_render_checker import PPTXRenderChecker
from phoenix_tracer import sanitize_attributes
from run_deepeval_retina_bench import run_eval_suite


def spec(tmp_path):
    image = tmp_path / 'source.png'
    Image.new('RGB', (60, 60), 'blue').save(image)
    source = tmp_path / 'source.txt'
    source.write_text('Synthetic test evidence, not clinical advice.')
    visual = CandidateVisual(image_id='one', path=str(image), image_sha256=file_hash(image),
        modality='fundus', original_caption='CRAO fundus', disease_ids=['crao'])
    return SlideSpec(slide_id='test', topic_id='crao', title='Synthetic test',
        selected_visual=visual, candidate_images=[visual], expected_modality='fundus',
        claims=[ClinicalClaim(claim_id='c', statement='Synthetic test', status='supported', supporting_source_ids=['s'])],
        sources=[SourcePassage(source_id='s', citation_ref='Synthetic fixture', text=source.read_text(),
            source_path=str(source), document_sha256=file_hash(source))])


def model(action='accept_draft'):
    return SimpleNamespace(invoke=lambda _: SimpleNamespace(content=json.dumps({'action': action, 'reason': 'test'}),
        response_metadata={'model_name': 'gemini-4-argon'}, usage_metadata={}))


def test_final_rejection_survives_real_graph(tmp_path):
    s = spec(tmp_path)
    s.sources = []
    g = ArgonSlideSupervisorGraph(llm_factory=lambda _: model())
    result = g.run_supervisor(s)
    assert result.status == 'review_required'
    assert result.latest_decision.action == 'review_required'


def test_valid_mock_draft_has_no_final_render_or_human_approval(tmp_path):
    g = ArgonSlideSupervisorGraph(llm_factory=lambda _: model())
    result = g.run_supervisor(spec(tmp_path))
    assert result.status == 'accepted_draft'
    assert result.expert_review_status == 'review_required'
    assert result.slide_spec.render_kind == 'preview'


def test_persistent_checkpoint_and_changed_input(tmp_path):
    s = spec(tmp_path)
    path = tmp_path / 'checkpoints.sqlite'
    calls = []
    def factory(_):
        calls.append(1)
        return model()
    g = ArgonSlideSupervisorGraph(llm_factory=factory, checkpoint_path=path)
    first = g.run_supervisor(s)
    g.close()
    g = ArgonSlideSupervisorGraph(llm_factory=factory, checkpoint_path=path)
    assert g.run_supervisor(s).run_id == first.run_id
    assert len(calls) == 1
    s.title = 'Changed'
    assert g.run_supervisor(s).run_id != first.run_id
    assert len(calls) == 2
    g.close()


def test_same_pixels_different_id_are_rejected(tmp_path):
    s = spec(tmp_path)
    s.candidate_images.append(s.selected_visual.model_copy(update={'image_id': 'alias'}))
    g = ArgonSlideSupervisorGraph()
    g.resolver = SimpleNamespace(resolve_visual=lambda **_: (None, None))
    state = SlideSupervisorState(slide_spec=s)
    result = g.retrieve_visual_candidates_node(state)
    assert result['latest_decision'].action == 'review_required'
    assert s.selected_visual.image_sha256 in result['rejected_image_hashes']


def test_retrieved_source_does_not_auto_support_claim(tmp_path):
    s = spec(tmp_path)
    source = s.sources[0]
    s.sources = []
    s.claims[0].status = 'unsupported'
    g = ArgonSlideSupervisorGraph(evidence_retriever=lambda *_: [source])
    result = g.retrieve_evidence_node(SlideSupervisorState(slide_spec=s))
    assert len(result['slide_spec'].sources) == 1
    assert result['slide_spec'].claims[0].status == 'unsupported'


@pytest.mark.parametrize('before,after', [
    ({'a':'A 2 mg','b':'B 4 mg'}, {'a':'A 4 mg','b':'B 2 mg'}),
    ('A 2 mg; B 4 mg','A 4 mg; B 2 mg'),
    ({'a':'A [PMID:1]','b':'B [PMID:2]'}, {'a':'A [PMID:2]','b':'B [PMID:1]'}),
])
def test_clinical_bindings_preserved(before, after):
    with pytest.raises(ValueError):
        assert_clinical_invariants(before, after)


def test_revision_cannot_change_dose(tmp_path):
    s=spec(tmp_path)
    s.cards=[SlideCard(card_id='c', title='Dose', items=['A 2 mg'])]
    state=SlideSupervisorState(slide_spec=s,latest_decision=SupervisorDecision(action='revise_text',reason='test',
        revision_instructions=RevisionInstructions(target_card_id='c',replacement_text='A 4 mg')))
    result=ArgonSlideSupervisorGraph().revise_slide_node(state)
    assert result['latest_decision'].action=='review_required'
    assert s.cards[0].items==['A 2 mg']


def test_missing_png_never_verified(tmp_path, monkeypatch):
    p=tmp_path/'one.pptx';prs=Presentation();prs.slides.add_slide(prs.slide_layouts[6]);prs.save(p)
    c=PPTXRenderChecker(tmp_path/'audit')
    monkeypatch.setattr(c,'export_slides_via_com',lambda _: [])
    result=c.audit_presentation(p)
    assert result['overall_status']=='review_required'
    assert result['render_status']=='unavailable_or_partial'
    assert result['pptx_sha256']==file_hash(p)


def test_masking_preserves_counters_hides_documents():
    clean=sanitize_attributes({'input_tokens':123,'output_tokens':45,'access_token':'secret','document':'private'})
    assert clean['input_tokens']==123 and clean['output_tokens']==45
    assert 'access_token' not in clean and 'document' not in clean


def test_benchmark_not_clinical_accuracy():
    r=run_eval_suite()
    assert r['clinical_model_performance']=='not_evaluated'
    assert r['layout_issues'] is None
    assert 'modality_accuracy_pct' not in r
    with pytest.raises(ValueError):run_eval_suite(live_eval=True)


def test_live_supervisor_payload_contains_two_images(tmp_path,monkeypatch):
    from bookgraph import usage
    monkeypatch.setattr(usage,'record',lambda **_: None)
    captured=[]
    fake=model()
    def invoke(messages):
        captured.extend(messages[0].content)
        return fake.invoke(messages)
    monkeypatch.setitem(sys.modules,'langchain_google_genai',SimpleNamespace(ChatGoogleGenerativeAI=lambda **_: SimpleNamespace(invoke=invoke)))
    g=ArgonSlideSupervisorGraph(use_live_api=True)
    result=g.run_supervisor(spec(tmp_path))
    assert result.status=='accepted_draft'
    images=[c for c in captured if c['type']=='image_url']
    assert len(images)==2
    assert all(c['image_url']['url'].startswith('data:image/png;base64,') for c in images)


def test_empty_stage_json_recorded_invalid(tmp_path,monkeypatch):
    from bookgraph import usage
    from bookgraph.visual_calls import invoke_json
    records=[]
    monkeypatch.setattr(usage,'record',lambda **k: records.append(k))
    fake=SimpleNamespace(invoke=lambda _: SimpleNamespace(content='{}',response_metadata={'model_name':'gemini-4-argon'},usage_metadata={'input_tokens':2,'output_tokens':1}))
    with pytest.raises(ValueError):
        invoke_json(fake,[],requested_model='gemini-4-argon',book='test',unit='test',run_id='r',strict=True,validator=SupervisorDecision.model_validate)
    assert records[-1]['status']=='OUTPUT_INVALID'
    assert records[-1]['input_tokens']==2


def test_local_pdf_retrieval_returns_real_new_passages(tmp_path):
    import fitz
    from local_slide_evidence import LocalSlideEvidence
    pdf=tmp_path/'book.pdf'
    doc=fitz.open()
    for text in ['CRAO first actual source passage.', 'CRAO second actual source passage.']:
        page=doc.new_page();page.insert_text((50,50),text)
    doc.save(pdf);doc.close()
    index=tmp_path/'index.json'
    index.write_text(json.dumps([{'path':str(pdf),'sha256':file_hash(pdf),'pages':[1,2]}]))
    s=SlideSpec(slide_id='local',topic_id='crao',title='CRAO')
    retriever=LocalSlideEvidence(index,max_pages=1)
    first=retriever(s,None)
    assert len(first)==1 and 'first actual' in first[0].text
    s.sources=first
    second=retriever(s,None)
    assert len(second)==1 and 'second actual' in second[0].text
    s.sources+=second
    assert retriever(s,None)==[]


def test_budget_allows_last_review_without_extra_revision(tmp_path):
    s=spec(tmp_path)
    g=ArgonSlideSupervisorGraph(llm_factory=lambda _:model(),max_corrections=0)
    result=g.run_supervisor(s)
    assert result.status=='accepted_draft'
    g=ArgonSlideSupervisorGraph(llm_factory=lambda _:model('revise_text'),max_corrections=0)
    result=g.run_supervisor(s)
    assert result.status=='review_required' and result.correction_count==0
