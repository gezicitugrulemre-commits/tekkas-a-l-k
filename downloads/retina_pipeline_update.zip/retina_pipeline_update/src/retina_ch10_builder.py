# -*- coding: utf-8 -*-
r"""
retina_ch10_builder.py — Bölüm 10: Master Matris, Biyoistatistik, Vaka Bankası ve Kaynakça (28 Slayt)
===================================================================================================
Alt Başlıklar:
  10.1 Kitap Sayfa 280 Hızlı Klinik Başvuru ve Karşılaştırma Matrisi (8 slayt)
  10.2 Oftalmolojide Biyoistatistik Standartları (Patient-level vs Eye-level, ICC, GEE) (5 slayt)
  10.3 Master Uzmanlık Düzeyi Aktif Hatırlama Vaka Bankası (12 slayt)
  10.4 Kaynakça, Resmî Künye ve PubMed Landmark İndeksi (3 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_10(builder: RetinaStudyDeckBuilder):
    """Bölüm 10'a ait 28 slaytı sunuma ekler."""

    # =========================================================================
    # 10.1: KİTAP SAYFA 280 MASTER KARŞILAŞTIRMA MATRİSİ (8 Slayt)
    # =========================================================================

    # Slayt 10.1.1: Master Matris 1: Vasküler Retina Acilleri Karar Özeti
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: VASKÜLER RETİNA ACİLLERİ",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="Diyabetik Retinopati, Damar Tıkanıklıkları ve Prematüre Retinopatisi Klinik Özeti",
        cards=[
            {
                "card_title": "1. Diyabetik Retinopati (DR & DME)",
                "lead": "4-2-1 Kuralı & Treat-and-Extend",
                "items": [
                    "Şiddetli NPDR (4-2-1): 4 kadranda kanama, 2 kadranda venöz boğumlanma, 1 kadranda IRMA [s.280].",
                    "PDR Kriteri: Optik diskte >1/3 DD NVD veya preretinal kanamalı NVE; derhal Panretinal Fotokoagülasyon (PRP).",
                    "Diyabetik Makula Ödemi: Fovea tutulumlu DME'de görme <0.8 ise Aflibercept/Faricimab ilk tercihtir.",
                    "Sistemik Kontrol: HbA1c <%7.0 ve kan basıncı kontrolü olmadan oküler tedavi başarıya ulaşamaz."
                ],
                "footer": "4-2-1 Kuralı -> PRP / DME -> Anti-VEGF"
            },
            {
                "card_title": "2. Retinal Damar Tıkanıklıkları (BRVO / CRVO)",
                "lead": "İskemik vs Non-İskemik Ayrımı",
                "items": [
                    "CRVO İskemi Kriteri: FFA'da >10 disk alanı kapiller non-perfüzyon; 90 gün glokomu riski (%30) [s.280].",
                    "RVO Makula Ödemi: Erken intravitreal Anti-VEGF (Aflibercept/Ranibizumab) veya Deksametazon implantı (Ozurdex).",
                    "CRAO (Arter Tıkanıklığı): Kiraz kırmızısı benek; ilk 4-6 saatte acil inme protokolü ve nöroloji yatışı şarttır.",
                    "Dev Hücreli Arterit (GCA): 50 yaş üstü arter oklüzyonunda sedimantasyon ve CRP acilen bakılmalıdır."
                ],
                "footer": "CRVO (10 DA İskemi) / CRAO (Acil İnme Kodu)"
            },
            {
                "card_title": "3. Prematüre Retinopatisi (ROP)",
                "lead": "ETROP Kriterleri ve Tedavi",
                "items": [
                    "Tip 1 ROP (Tedavi Şart): Zon 1 Plus (+); Zon 1 Evre 3; Zon 2 Evre 2/3 Plus (+) [s.280].",
                    "Tedavi: 48-72 saat içinde avasküler retinaya Lazer Fotokoagülasyon VEYA İntravitreal Anti-VEGF.",
                    "Anti-VEGF Dozu: Yetişkin dozunun yarısı (0.25 mg Ranibizumab veya 0.5 mg Aflibercept) uygulanır.",
                    "Takip: Anti-VEGF sonrası geç nüks riski nedeniyle vaskülarizasyon tamamlanana kadar izlenir."
                ],
                "footer": "Tip 1 ROP -> Acil Lazer / Anti-VEGF (Yarım Doz)"
            }
        ]
    )

    # Slayt 10.1.2: Master Matris 2: Makula Hastalıkları ve YBMD Karar Özeti
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: MAKULA VE YBMD",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="Kuru/Yaş YBMD, Coğrafi Atrofi, Pakikoroid Spektrumu ve VMT Cerrahi Özeti",
        cards=[
            {
                "card_title": "1. Yaşa Bağlı Makula Dejenerasyonu",
                "lead": "Coğrafi Atrofi & Treat-and-Extend",
                "items": [
                    "Kuru YBMD / Coğrafi Atrofi: Kompleman inhibitörleri Pegcetacoplan (C3) ve Avacincaptad pegol (C5) [s.280].",
                    "Yaş YBMD KNV Tipleri: Tip 1 (Sub-RPE/Okült), Tip 2 (Subretinal/Klasik), Tip 3 (RAP - İntraretinal).",
                    "Aktivite Göstergesi: İntraretinal sıvı (IRC - en tehlikeli) ve subretinal sıvı (SRF) takibi.",
                    "Uygulama: Treat-and-Extend (T&E) rejiminde aralıklar 2'şer hafta uzatılarak 12-16 haftaya çıkılır."
                ],
                "footer": "Anti-C3/C5 (Atrofi) / T&E Anti-VEGF (Yaş Tip)"
            },
            {
                "card_title": "2. Pakikoroid Spektrumu (SSKR / PCV)",
                "lead": "Kalın Koroid ve Dilate Haller Damarları",
                "items": [
                    "SSKR (Santral Seröz): Akut olguların %80'i 3 ayda spontan düzelir; kronikleşirse Yarım Doz FDT [s.280].",
                    "PCV (Polipoidal Vaskülopati): Altın standart tanı ICG anjiyografisidir (polip + BVN).",
                    "PCV Tedavisi: Everest ve Planet çalışmalarına göre Verteporfin FDT + İntravitreal Anti-VEGF kombinasyonu.",
                    "Pakikoroid Kuralı: Bu hastalarda kortikosteroidler hastalığı alevlendiren primer risk faktörüdür."
                ],
                "footer": "PCV (ICG Şart / FDT+Anti-VEGF) / Steroid KONTRENDİKE"
            },
            {
                "card_title": "3. Vitreomaküler Arayüz (VMT / FTMH)",
                "lead": "Gass Sınıflaması ve Cerrahi",
                "items": [
                    "VMT: Foveal traksiyon görmeyi düşürürse 25G Pars Plana Vitrektomi ve membran soyma [s.280].",
                    "Tam Kat Makula Deliği (FTMH): >400 μm geniş deliklerde İLM soyma (peeling) + Gaz tamponadı (SF6/C3F8).",
                    "Dev / Miyopik Delikler: Ters İLM Flep (Inverted Flap) tekniği ile delik tabanı kapatılır.",
                    "Postoperatif: Hastaya 3-5 gün yüzüstü (prone) pozisyon verilir."
                ],
                "footer": "FTMH >400 μm -> İLM Soyma + Gaz + Yüzüstü"
            }
        ]
    )

    # Slayt 10.1.3: Master Matris 3: Dekolman ve Periferik Retina Cerrahi Kuralları
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: RETİNA DEKOLMANI",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="RRD, Lincoff Kuralları, Profilaksi, TRD, ERD ve PVR Cerrahi Özeti",
        cards=[
            {
                "card_title": "1. Periferik Lezyonlar & Profilaksi",
                "lead": "Hangi Lezyon Lazerlenmeli?",
                "items": [
                    "Kesin Lazer Endikasyonu: Semptomatik at nalı (flep) yırtıklar derhal 3 sıra bariyerle ora serrataya kilitlenir [s.280].",
                    "Asemptomatik Olgular: İzole lattice dejenerasyonu veya atrofik delikler genellikle tedavi gerektirmez.",
                    "Fellow Eye İstisnası: Diğer gözü dekolmandan kaybedilmişse sağlam gözdeki lattice mutlaka lazerlenir.",
                    "Masum Lezyonlar: Parke taşı (paving-stone) dejenerasyonuna asla lazer atılmaz (delik açar!)."
                ],
                "footer": "Semptomatik Flep = Acil Lazer / Parke Taşı = Dokunma"
            },
            {
                "card_title": "2. Regmatojen Retina Dekolmanı (RRD)",
                "lead": "Lincoff Kuralları ve Cerrahi Seçim",
                "items": [
                    "Lincoff: Sıvının en yüksek olduğu üst kadranın saat 1.5 kadranı içinde primer yırtık aranır [s.280].",
                    "Makula-On Dekolman: Santral görmeyi korumak için ilk 24 saatte acil cerrahi şarttır.",
                    "Cerrahi Seçim: Genç fakik hastada lensi korumak için Sklera Çökertme; psödofakiklerde PPV.",
                    "Pnömatik Retinopeksi: Üst 8 saat kadranında tek yırtıklı, PVR'siz seçilmiş olgularda uygulanır."
                ],
                "footer": "Makula-On (24 Saat Acil) / Fakik (Buckle) / Psödofakik (PPV)"
            },
            {
                "card_title": "3. TRD, ERD ve PVR Kaskadı",
                "lead": "Mekanik, Sıvısal ve Hücresel Süreçler",
                "items": [
                    "TRD: Konkav şekilli, hareketsiz, ora serrataya uzanmaz; fovea tehdidinde bimanüel delaminasyon [s.280].",
                    "ERD: Yırtıksız, büllöz, SHIFTING (yer değiştiren) sıvı; cerrahi KONTRENDİKE, tıbbi tedavi.",
                    "PVR: RRD cerrahi başarısızlığının 1 numaralı nedenidir; RPE göçü ve epiretinal membran kasılması.",
                    "PVR Cerrahisi: Titiz membran soyma, bimanüel makas, gevşetici retinektomi ve Silikon Yağı."
                ],
                "footer": "ERD (Cerrahi Yasak) / PVR (Retinektomi + Silikon)"
            }
        ]
    )

    # Slayt 10.1.4: Master Matris 4: Kalıtsal Retinal ve Koroidal Distrofiler
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: KALITSAL DİSTROFİLER",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="RP, Stargardt, Best, Stickler, XLRS ve Luxturna Gen Tedavisi Özeti",
        cards=[
            {
                "card_title": "1. Retinitis Pigmentosa & Sendromlar",
                "lead": "Çomak-Koni Disfonksiyonu",
                "items": [
                    "Triad: Periferik kemik spikülleri, arteriyoler incelme, mumsu soluk disk [s.280].",
                    "Elektrofizyoloji: Skotopik çomak ERG yanıtı tamamen silinmiştir; FAF'ta Robson halkası.",
                    "Usher Sendromu: RP + Sensörinöral işitme kaybı (Tip 1 derin sağır; Tip 2 pubertede başlar).",
                    "Bardet-Biedl: RP + Polidaktili + Obezite + Hipogonadizm + Böbrek yetmezliği."
                ],
                "footer": "Kemik Spikülleri / Sönük Skotopik ERG / Usher & BBS"
            },
            {
                "card_title": "2. Makuler Distrofiler (Stargardt vs Best)",
                "lead": "A Vitamini Yasağı & EOG Çöküşü",
                "items": [
                    "Stargardt (ABCA4): Balık pulu (pisciform) lekeler; FFA'da patognomonik 'Karanlık Koroid' [s.280].",
                    "Stargardt Uyarısı: A vitamini takviyesi A2E lipofuksin toksisitesini hızlandırdığı için KESİNLİKLE YASAKTIR.",
                    "Best (BEST1): Sahanda yumurta kisti; ERG normal ancak EOG Arden oranı <1.50 çökmüştür.",
                    "XLRS (RS1): Genç erkekte spoke-wheel fovea; negatif ERG (b/a <1); topikal dorzolamid verilir."
                ],
                "footer": "Stargardt (A Vitamini Yasak) / Best (EOG <1.5)"
            },
            {
                "card_title": "3. Koroid Distrofileri & Luxturna",
                "lead": "Jirat, Koroideremi ve FDA Onaylı Gen Tedavisi",
                "items": [
                    "Jirat Atrofi (OAT): Hiperornitinemi; çelenk şeklinde koryoretinal atrofi; Argininsiz diyet + B6 [s.280].",
                    "Stickler (COL2A1): Optik boş vitreus; dev yırtık ve bilateral dekolman riski (%60); 360° profilaksi.",
                    "Luxturna (Voretigene): Çift allelik RPE65 mutasyonlu LCA/RP hastalarında tek doz subretinal gen ilacı.",
                    "Luxturna Şartı: Retinada en az 100 μm kalınlıkta canlı fotoreseptör hücresi (elipsoid zon) bulunmalıdır."
                ],
                "footer": "Jirat (Argininsiz Diyet) / Luxturna (RPE65 Canlı Hücre)"
            }
        ]
    )

    # Slayt 10.1.5: Master Matris 5: Viral ve Paraziter Retinitler İlaç Tablosu
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: ENFEKSİYÖZ RETİNİTLER",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="ARN, PORN, CMV Retiniti, Toksoplazmoz, Sifiliz ve Tüberküloz İlaç Protokolleri",
        cards=[
            {
                "card_title": "1. Viral Retinitler (ARN, PORN, CMV)",
                "lead": "Antiviral İndüksiyon ve Dekolman Kalkanı",
                "items": [
                    "Akut Retinal Nekroz (ARN): İmmünkompetan; periferik nekroz + vitrit; İV Asiklovir + 48. saatte Steroid [s.280].",
                    "PORN: CD4 <50 AIDS; VİTRİT SIFIRDIR; derin sarı nekroz; İV Gansiklovir + Foskarnet çift rejimi.",
                    "CMV Retiniti: Damar arkatlarında 'pizza pie' kanamalı nekroz; Oral Valgansiklovir (900 mg 2x -> 1x).",
                    "Profilaktik Lazer: Viral nekroz sınırına 360° bariyer lazer atılarak dev yırtık dekolmanı önlenir."
                ],
                "footer": "ARN (Vitrit +) / PORN (Vitrit -) / CMV (Valgansiklovir)"
            },
            {
                "card_title": "2. Oküler Toksoplazmozis",
                "lead": "'Sis İçinde Far' ve Tek Başına Steroid Yasağı",
                "items": [
                    "Morfoloji: Eski pigmente koryoretinal skar kenarında taze kabarık sarı-beyaz nekroz + yoğun vitrit [s.280].",
                    "Tedavi: TMP-SMX (160/800 mg 2x1) VEYA Pirimetamin + Sülfadiazin + Folinik Asit (4-6 hafta).",
                    "Kortikosteroid: Antiparaziter tedavinin 48. saatinden sonra oral prednizolon eklenir.",
                    "MUTLAK KURAL: Tek başına steroid veya perioküler enjeksiyon paraziti patlatır; KESİNLİKLE YASAKTIR."
                ],
                "footer": "TMP-SMX + Geç Steroid / Tek Başına Steroid YASAKTIR"
            },
            {
                "card_title": "3. Sifiliz ve Tüberküloz",
                "lead": "Büyük Taklitçiler ve Spesifik Rejimler",
                "items": [
                    "Oküler Sifiliz: 'Büyük taklitçi', plakoid koryoretinit veya panüveit; FTA-ABS pozitifliği [s.280].",
                    "Sifiliz Tedavisi: Nörosifiliz kabul edilir; İntravenöz Kristalize Penisilin G (18-24 MÜ/gün, 14 gün).",
                    "Oküler Tüberküloz: Serpinöz benzeri koroidit veya oklüzif vaskülit; Quantiferon-TB / PPD >15 mm.",
                    "TB Tedavisi: Dörtlü Antitüberküloz (HRZE) 2 ay + HR 7 ay + eşzamanlı sistemik steroid."
                ],
                "footer": "Sifiliz (İV Penisilin G 14 Gün) / TB (4'lü HRZE)"
            }
        ]
    )

    # Slayt 10.1.6: Master Matris 6: Otoimmün Üveitler ve Vaskülitler
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: OTOİMMÜN ÜVEİTLER",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="Behçet Hastalığı, Vogt-Koyanagi-Harada (VKH) ve Oküler Sarkoidoz Yönetimi",
        cards=[
            {
                "card_title": "1. Behçet Hastalığı Vasküliti",
                "lead": "Oklüzif Vaskülit & Biyolojik Devrim",
                "items": [
                    "Klinik: Tekrarlayan non-granülomatöz panüveit, mobil hipopiyon, nekrotizan oklüzif retinal vaskülit [s.280].",
                    "FFA İmzası: Damar duvarlarından yaygın 'eğrelti otu' (fern-like) kaçak ve kapiller non-perfüzyon.",
                    "Akut Atak: İntravenöz Pulse Metilprednizolon (1 g/gün, 3 gün) + Anti-TNF (İnfliksimab / Adalimumab).",
                    "İdame: Azatioprin (2.5 mg/kg/gün) veya İnterferon-alfa; Nöro-Behçet'te Siklosporin KONTRENDİKEDİR."
                ],
                "footer": "Eğrelti Otu FFA / Anti-TNF İnfliksimab / Nöro-Behçet Kuralı"
            },
            {
                "card_title": "2. Vogt-Koyanagi-Harada (VKH)",
                "lead": "Bilateral Eksüdatif Dekolman & Gün Batımı",
                "items": [
                    "Klinik: Nörolojik prodrom (baş ağrısı, tinnitus) sonrası bilateral büllöz seröz retina dekolmanı [s.280].",
                    "Görüntüleme: EDI-OKT'de koroid >800 μm ve fibrinöz septalar; FFA'da 'yıldızlı gökyüzü' pinpoint sızıntı.",
                    "Tedavi: Erken dönemde İV Pulse Metilprednizolon (1 g/gün, 3 gün) -> En az 6-9 aya yayılan oral tapering.",
                    "Travma Kuralı: Geçirilmiş cerrahi/travma öyküsü KESİNLİKLE YOKTUR (varsa Sempatik Oftalmidir)."
                ],
                "footer": "Yıldızlı Gökyüzü FFA / Pulse Steroid / 6-9 Ay Tapering"
            },
            {
                "card_title": "3. Oküler Sarkoidoz",
                "lead": "Granülomatöz Periflebit & Mum Damlaları",
                "items": [
                    "Klinik: Granülomatöz panüveit, koyun yağı keratik presipitatlar, iris Busacca/Koeppe nodülleri [s.280].",
                    "Retina: Retinal venler çevresinde segmental eksüdalar ('Mum Damlası' / Candle-wax drippings periflebiti).",
                    "Tanı: Bilateral hiler lenfadenopati (Toraks BT), yüksek serum ACE ve lysozyme düzeyleri.",
                    "Tedavi: Sistemik kortikosteroidler, Metotreksat ve kistik makula ödeminde intravitreal Ozurdex."
                ],
                "footer": "Koyun Yağı KP / Mum Damlası Periflebiti / Toraks BT"
            }
        ]
    )

    # Slayt 10.1.7: Master Matris 7: Beyaz Nokta Sendromları Multimodal Kılavuzu
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: BEYAZ NOKTA ATLASI",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="MEWDS, APMPPE, Birdshot, MFC, PIC ve Serpinöz Koryoretinopati Özeti",
        cards=[
            {
                "card_title": "1. MEWDS & APMPPE",
                "lead": "Selim Çiçekler vs Serebral İnme Riski",
                "items": [
                    "MEWDS: Genç kadın; viral prodrom; foveal granülarite; FAF hiperotofloresan çiçekler; TEDAVİ GEREKMEZ [s.280].",
                    "APMPPE: Genç erişkin; bilateral plaklar; FFA'da 'Block Early, Stain Late' (erken blokaj, geç boyanma).",
                    "APMPPE Uyarısı: Şiddetli baş ağrısı eşlik ediyorsa acil Kranial MRA çekilmeli ve İV Pulse Steroid verilmelidir (İnme riski!)."
                ],
                "footer": "MEWDS (Selim / FAF Çiçeği) / APMPPE (İnme Riski / MRA)"
            },
            {
                "card_title": "2. Birdshot & Serpinöz",
                "lead": "HLA-A29 Saçmaları vs Yılankavi Yıkım",
                "items": [
                    "Birdshot: HLA-A29 (%99); ICG'de hipofloresan saçma taneleri; ERG 30 Hz flicker latansı uzar (>32 ms) [s.280].",
                    "Birdshot Tedavisi: Yalnızca steroid yetersizdir; erken dönemde Siklosporin A / Mikofenolat Mofetil şarttır.",
                    "Serpinöz: Optik disk peripapiller kenarından foveaya yılankavi psödopodlar; aktif kenar kabarık sarı.",
                    "Serpinöz Kuralı: Tüberküloz (SLC) dışlanmalıdır; klasik formda agresif immünsüpresyon gerekir."
                ],
                "footer": "Birdshot (HLA-A29 / MMF) / Serpinöz (Yılankavi Psödopod)"
            },
            {
                "card_title": "3. Multifokal Koroidit (MFC) vs PIC",
                "lead": "Vitrit Varlığı vs Yokluğu & KNV Tehdidi",
                "items": [
                    "Multifokal Koroidit (MFC): Belirgin VİTRİT (+); orta periferde 150-500 μm zımba deliği skarlar [s.280].",
                    "Punktat İç Koryopati (PIC): VİTRİT KESİNLİKLE YOKTUR; izole arka kutupta 100-200 μm küçük punktat skarlar.",
                    "Ortak Komplikasyon: Her ikisinde de %35-40 oranında subfoveal inflamatuar KNV (iKNV) gelişir.",
                    "iKNV Tedavisi: İntravitreal Anti-VEGF + Eşzamanlı Sistemik Steroid/İmmünomodülasyon kombine verilir."
                ],
                "footer": "MFC (Vitrit +) / PIC (Vitrit Yok) / iKNV (Kombine Tedavi)"
            }
        ]
    )

    # Slayt 10.1.8: Master Matris 8: Oküler Onkoloji ve Travma Acil Kuralları
    builder.add_study_card_slide(
        title="MASTER KARŞILAŞTIRMA MATRİSİ: ONKOLOJİ VE TRAVMA",
        category="BÖLÜM 10.1: KLİNİK ÖZET [p.280]",
        subtitle="Retinoblastom, Koroid Melanomu (TFSOM), Açık Glob ve Endoftalmi Acil İlkeleri",
        cards=[
            {
                "card_title": "1. Retinoblastom & Oküler Onkoloji",
                "lead": "Kalsifikasyon, İAK ve Biyopsi Yasağı",
                "items": [
                    "Retinoblastom: Bebekte lökokori; B-Scan'de kalsifikasyon patognomoniktir; BT ÇEKİLMESİ KESİNLİKLE YASAKTIR [s.280].",
                    "Biyopsi Yasağı: Retinoblastomda ince iğne biyopsisi (İİAB) tümörü saçtığı için KESİNLİKLE KONTRENDİKEDİR.",
                    "Modern Tedavi: Oftalmik arterden İntraarteriyel Kemoterapi (İAK - Melphalan) ile göz korunur.",
                    "Koroid Melanomu: TFSOM kriterleri (Kalınlık >2 mm, Sıvı, Portakal pigmenti, Boş eko, Çap >5 mm) -> Plak Radyoterapi."
                ],
                "footer": "RB (BT & Biyopsi Yasak / İAK) / Melanom (TFSOM / Plak)"
            },
            {
                "card_title": "2. Posterior Travma & Açık Glob",
                "lead": "İlk 24 Saatte Primer Kapatma & MR Yasağı",
                "items": [
                    "Açık Küre (Glob): Sert kalkan takılır; baskılı bandaj yasaktır; ilk 24 saatte acil primer cerrahi kapatma [s.280].",
                    "Radyoloji Kuralı: Metalik yabancı cisim şüphesinde MR ÇEKİLMESİ YASAKTIR; ince kesit orbital BT çekilir.",
                    "Siderozis Bulbi: Demir parçacığının toksisitesi heterokromi, katarakt ve tam alan ERG b-dalga çöküşü yapar.",
                    "Berlin Ödemi: Künt travmada foveal dış segment bulanıklığı; 1-2 haftada kendiliğinden düzelir."
                ],
                "footer": "Açık Glob (İlk 24 Saat / MR Yasak) / İOYC (Siderozis)"
            },
            {
                "card_title": "3. Enjeksiyon Sterilitesi & EVS Protokolü",
                "lead": "%5 Povidon İyot ve Endoftalmi Triyajı",
                "items": [
                    "Sterilite: %5 Povidon İyot konjonktivada en az 3 dk bekletilir; cerrahi maske şarttır; postop antibiyotik YASAKTIR [s.280].",
                    "Endoftalmi Tedavisi (EVS Kuralı): Görme sadece IŞIK HİSSİ (LP) ise Acil Pars Plana Vitrektomi (PPV) şarttır.",
                    "Görme El Hareketi (HM) veya Üzeri ise: Parasentez ile kültür + İntravitreal Vankomisin (1 mg) + Seftazidim (2.25 mg).",
                    "Sistemik intravenöz antibiyotiklerin endoftalmide hiçbir ek faydası kanıtlanmamıştır."
                ],
                "footer": "Povidon İyot / EVS (LP = PPV; HM = İntravitreal Antibiyotik)"
            }
        ]
    )

    # =========================================================================
    # 10.2: OFTALMOLOJİDE BİYOİSTATİSTİK STANDARTLARI (5 Slayt)
    # =========================================================================

    # Slayt 10.2.1: Analiz Birimi: Hasta Düzeyi vs Göz Düzeyi
    builder.add_study_card_slide(
        title="OFTALMOLOJİDE BİYOİSTATİSTİK: HASTA DÜZEYİ vs GÖZ DÜZEYİ",
        category="BÖLÜM 10.2: BİYOİSTATİSTİK",
        subtitle="Analiz Birimi Hatası (Unit-of-Analysis Error), Bağımlı Göz Verisi ve Yalancı p Değeri",
        cards=[
            {
                "card_title": "1. Oftalmolojinin Eşsiz İstatistiki Problemi",
                "lead": "İki Göz Birbirinden Bağımsız DEĞİLDİR",
                "items": [
                    "İnsan bedeninde iki göz aynı genetik yapıyı, aynı kan basıncını, aynı kan şekerini ve çevreyi paylaşır [s.32].",
                    "Aynı hastanın sağ ve sol gözünden elde edilen ölçümler (GİB, foveal kalınlık vb.) birbirine güçlü derecede bağımlıdır.",
                    "Eğer araştırmacı 50 hastanın 100 gözünü sanki 100 ayrı bireymiş gibi bağımsız testlere sokarsa:",
                    "Örneklem büyüklüğü yapay olarak 2 katına çıkarılmış olur ve Tip 1 Hata (Yalancı Pozitiflik) patlar."
                ],
                "footer": "Bağımlı Veri / İki Kat Yapay Örneklem / Tip 1 Hata Patlaması"
            },
            {
                "card_title": "2. Yalancı p Değeri Tehlikesi (False Significance)",
                "lead": "Gerçekte Olmayan Farkın Anlamlı Çıkması",
                "items": [
                    "Standart bağımsız Student's t-testi veya Ki-kare testi tüm gözlemlerin bağımsız olduğunu varsayar [s.33].",
                    "Bağımlı iki göz verisine standart t-testi uygulandığında standart hata (SE) yapay olarak küçük hesaplanır.",
                    "Sonuç: Gerçekte p = 0.12 olan anlamsız bir fark, formülde yapay olarak p = 0.02 (anlamlı) gibi görünür.",
                    "Bu metodolojik hata oftalmoloji makalelerinin hakemlerce reddedilmesinin 1 numaralı biyoistatistik nedenidir."
                ],
                "footer": "Yapay Düşük Standart Hata -> Yalancı Anlamlı p Değeri"
            },
            {
                "card_title": "3. Çözüm Stratejileri",
                "lead": "Tek Göz Seçimi vs İleri Kümeleme Modelleri",
                "items": [
                    "Basit Yaklaşım: Her hastadan yalnızca tek bir gözün analize dahil edilmesi (örneğin sadece sağ göz veya rastgele seçilen tek göz).",
                    "Dezavantajı: Toplanan verinin yarısı çöpe atılır ve istatistiksel güç (power) belirgin şekilde düşer.",
                    "Modern ve Doğru Yaklaşım: Her iki gözün verisini koruyarak hastayı bir 'küme' (cluster) kabul eden ileri modellerin kullanılmasıdır.",
                    "Genelleştirilmiş Tahmin Denklemleri (GEE) ve Doğrusal Karışık Modeller (Linear Mixed Models) altın standarttır."
                ],
                "footer": "Tek Göz (Güç Kaybı) vs İleri Model (GEE / Mixed)"
            }
        ]
    )

    # Slayt 10.2.2: Sınıf İçi Korelasyon Katsayısı (ICC)
    builder.add_study_card_slide(
        title="SINIF İÇİ KORELASYON KATSAYISI (ICC) VE KÜMELEME",
        category="BÖLÜM 10.2: KÜMELEME ETKİSİ",
        subtitle="Intra-Class Correlation (ICC), Küme İçi Benzerlik Ölçümü ve Tasarım Etkisi (Design Effect)",
        cards=[
            {
                "card_title": "1. ICC Tanımı ve Formülü",
                "lead": "Gözler Arasındaki Varyans Payı",
                "items": [
                    "ICC (ρ), hastalar arasındaki varyansın toplam varyansa bölünmesiyle hesaplanır: ICC = σ²_hasta / (σ²_hasta + σ²_göz) [s.33].",
                    "ICC değeri 0 ile 1 arasında değişir:",
                    "ICC = 0 ise: Sağ ve sol göz arasında hiçbir korelasyon yoktur; gözler tamamen bağımsızdır.",
                    "ICC = 1 ise: İki göz birbirinin mükemmel kopyasıdır; ikinci gözden hiçbir yeni bilgi elde edilmez.",
                    "Oftalmolojide GİB için ICC tipik olarak 0.60 – 0.80, foveal kalınlık için 0.70 – 0.85 gibi çok yüksek düzeylerdedir."
                ],
                "footer": "ICC = 0.60 - 0.85 / Çok Yüksek Göz İçi Benzerlik"
            },
            {
                "card_title": "2. Tasarım Etkisi (Design Effect / VIF)",
                "lead": "Etkin Örneklem Boyutunun Hesaplanması",
                "items": [
                    "Kümeleme içeren çalışmalarda Tasarım Etkisi (DE) formülü: DE = 1 + (m - 1) * ICC (burada m = küme büyüklüğü = 2 göz) [s.33].",
                    "Örnek: ICC = 0.70 ise, DE = 1 + (2 - 1) * 0.70 = 1.70 bulunur.",
                    "Bu şu demektir: 50 hastadan toplanan 100 göz verisi, aslında 100 bağımsız göze DEĞİL; yalnızca 100 / 1.70 = 58.8 bağımsız göze eşdeğerdir!",
                    "Araştırmacı örneklem gücü hesaplarken bu tasarım etkisini mutlaka hesaba katmalıdır."
                ],
                "footer": "DE = 1 + (m-1)*ICC / 100 Göz = 59 Bağımsız Göz"
            },
            {
                "card_title": "3. Klinik Karar Kuralı",
                "lead": "ICC Raporlama Zorunluluğu",
                "items": [
                    "Oftalmoloji dergilerine sunulan çalışmalarda iki göz birden dahil edilmişse ICC katsayısının bildirilmesi şarttır [s.34].",
                    "ICC yüksek çıktığında standart bağımsız testlerin geçersiz olduğu açıkça belirtilmelidir.",
                    "Hakemlerin metodolojik denetiminden geçebilmek için ICC'ye göre ayarlanmış p değerleri sunulmalıdır.",
                    "Tıbbi cihaz güvenilirliği (test-retest güvenilirliği) analizlerinde de iki yönlü karma ICC modeli kullanılır."
                ],
                "footer": "Dergilerde ICC Raporlama Zorunluluğu"
            }
        ]
    )

    # Slayt 10.2.3: İleri İstatistik Modelleri: GEE ve Karışık Etkili Modeller
    builder.add_study_card_slide(
        title="İLERİ İSTATİSTİKİ MODELLER: GEE VE MIXED-EFFECTS",
        category="BÖLÜM 10.2: İLERİ MODELLER",
        subtitle="Genelleştirilmiş Tahmin Denklemleri (GEE) ve Doğrusal Karışık Modeller (Linear Mixed-Effects)",
        cards=[
            {
                "card_title": "1. Genelleştirilmiş Tahmin Denklemleri (GEE)",
                "lead": "Küme İçi Korelasyon Matrisini Hesaplayan Yarı-Parametrik Model",
                "items": [
                    "GEE (Generalized Estimating Equations), küme içi korelasyon yapısını (çalışma korelasyon matrisi) modele dahil eder [s.34].",
                    "Popülasyon ortalamasını (population-averaged / marginal model) tahmin eder.",
                    "Sandviç varyans tahmincisi (Huber-White robust standard error) kullanarak standart hataları doğru hesaplar.",
                    "Sağ ve sol göz arasındaki korelasyonu 'Exchangeable' (değiştirilebilir) matris olarak tanımlar.",
                    "Sonuç: Gerçek p değerini verir; Tip 1 hatayı tamamen engeller."
                ],
                "footer": "GEE / Marginal Model / Sandviç Varyans Düzeltmesi"
            },
            {
                "card_title": "2. Doğrusal Karışık Etkili Modeller (LMM / GLMM)",
                "lead": "Bireye Özgü Rastgele Etkiler (Random-Effects)",
                "items": [
                    "Linear Mixed-Effects Models, hem sabit etkileri (tedavi grubu, yaş vb.) hem rastgele etkileri (hasta faktörü) birlikte modeller [s.34].",
                    "Hasta düzeyindeki rastgele kesim noktasını (random intercept) modele ekleyerek hasta varyansını izole eder.",
                    "Tekrarlayan ölçümlerde (örneğin 1., 3., 6., 12. ay OCT ölçümleri) kayıp veri (missing data) varlığında bile çalışır.",
                    "Bireysel hasta gidişatını (subject-specific model) tahmin etmede GEE'den daha esnektir."
                ],
                "footer": "Mixed-Effects / Random Intercept / Kayıp Veri Yönetimi"
            },
            {
                "card_title": "3. Model Seçim Rehberi: GEE mi LMM mi?",
                "lead": "Hangi Klinik Soru İçin Hangi Model?",
                "items": [
                    "Popülasyon düzeyinde bir tedavinin genel etkinliği araştırılıyorsa -> GEE tercih edilir [s.35].",
                    "Bireysel hasta tahmini, zaman içindeki bireysel değişim veya dengesiz kayıp veri varsa -> LMM tercih edilir.",
                    "Kategorik bağımlı değişkenlerde (örneğin dekolman var/yok) -> Lojistik GEE veya Binom GLMM kullanılır.",
                    "Sürekli değişkenlerde (örneğin foveal kalınlık μm) -> Standart LMM veya Doğrusal GEE kullanılır."
                ],
                "footer": "Popülasyon = GEE / Bireysel & Zaman = Mixed-Effects"
            }
        ]
    )

    # Slayt 10.2.4: Çoklu Karşılaştırma Düzeltmeleri ve Örneklem Gücü
    builder.add_study_card_slide(
        title="ÇOKLU KARŞILAŞTIRMA VE ÖRNEKLEM BOYUTU HESAPLAMA",
        category="BÖLÜM 10.2: ÇOKLU TEST & GÜÇ",
        subtitle="Bonferroni Düzeltmesi, Benjamini-Hochberg FDR ve Küme Düzeltmeli Güç Analizi",
        cards=[
            {
                "card_title": "1. Çoklu Karşılaştırma Sorunu (Family-Wise Error)",
                "lead": "Test Sayısı Arttıkça Sahte Anlamlılık Patlaması",
                "items": [
                    "Bir çalışmada 20 farklı biyomarker test edilirse, hiçbir gerçek fark olmasa bile en az birinin şans eseri p < 0.05 çıkma olasılığı %64'tür [s.35].",
                    "Alfa Hatası Enflasyonu: α_toplam = 1 - (1 - α)^k formülüyle k test için hata kümülatif büyür.",
                    "Bonferroni Düzeltmesi: En katı yöntemdir; hedef p eşiği test sayısına bölünür (örneğin 10 test için α = 0.05 / 10 = 0.005).",
                    "Bonferroni aşırı muhafazakardır; Tip 2 Hatayı (gerçek farkı kaçırma) artırabilir."
                ],
                "footer": "Alfa Enflasyonu / Bonferroni (α/k) / Tip 2 Hata Riski"
            },
            {
                "card_title": "2. Modern Alternatif: Benjamini-Hochberg FDR",
                "lead": "Yanlış Keşif Oranı (False Discovery Rate)",
                "items": [
                    "Geniş veri setlerinde (örneğin genetik mikroarray, 50 farklı OKT katmanı analizi) FDR tercih edilir [s.35].",
                    "P değerleri küçükten büyüğe sıralanır ve sıralı rank katsayısına göre düzeltilir.",
                    "Anlamlı bulunan keşifler içindeki sahte pozitiflik oranını sabit bir düzeyde (örneğin %5) sınırlar.",
                    "Bonferroni'ye göre istatistiksel gücü çok daha yüksektir; gerçek klinik farkları maskelemez."
                ],
                "footer": "FDR Kontrolü / Sıralı Rank Düzeltmesi / Yüksek Güç"
            },
            {
                "card_title": "3. Küme Düzeltmeli Örneklem Güç Analizi",
                "lead": "Göz Sayısını Doğru Hesaplama",
                "items": [
                    "Örneklem boyutu hesaplanırken bağımsız örneklem formülüyle bulunan hasta sayısı Tasarım Etkisi (DE) ile çarpılmalıdır [s.36].",
                    "Örnek: Standart güç analizi 60 göze ihtiyaç gösteriyorsa ve ICC = 0.70 ise (DE = 1.70):",
                    "Gereken toplam göz sayısı = 60 * 1.70 = 102 göz (yani 51 hasta) olmalıdır.",
                    "Tasarım etkisi hesaba katılmadan yapılan çalışmalar 'yetersiz örneklem' (underpowered) nedeniyle güvenilmez kalır."
                ],
                "footer": "Gereken Göz = N_bağımsız * DE / Underpowered Çalışmayı Önleme"
            }
        ]
    )

    # Slayt 10.2.5: SPSS ve R Uygulama Adımları, Kodlama ve Tablo Formatı
    builder.add_split_comparison_slide(
        title="BİYOİSTATİSTİK PRATİĞİ: HATALI vs DOĞRU ANALİZ ŞABLONU",
        category="BÖLÜM 10.2: SPSS & R REHBERİ",
        subtitle="Hatalı Bağımsız Test Yaklaşımı vs Doğru Küme Düzeltmeli GEE / Mixed Modeli",
        left_entity={
            "name": "HATALI ANALİZ (HAKEMDEN RED ALIR)",
            "subtitle": "İki Gözü Bağımsız Kabul Eden İlkel Yaklaşım",
            "bullets": [
                "SPSS Menüsü: Analyze -> Compare Means -> Independent Samples T-Test [s.36].",
                "Metodolojik Hata: Her satıra bir göz yazılıp toplam 100 göz bağımsız gibi test edilir.",
                "Sonuç: Standart hata yapay olarak küçük çıkar; p değeri olduğundan çok daha anlamlı görünür (Tip 1 Hata).",
                "Hakem Eleştirisi: 'Analiz birimi hatası mevcuttur; iki göz verisi kümelenmemiştir, derhal reddedildi.'",
                "Yayınlanabilirlik: Q1/Q2 oftalmoloji dergilerinde kesinlikle kabul edilmez [s.36]."
            ]
        },
        right_entity={
            "name": "DOĞRU ANALİZ (STANDART GEE MODELİ)",
            "subtitle": "Kümeyi Hasta Olarak Tanımlayan İleri Model",
            "bullets": [
                "SPSS Menüsü: Analyze -> Generalized Linear Models -> Generalized Estimating Equations (GEE) [s.36].",
                "Model Ayarları: Subject Variables = 'Hasta_ID'; Within-Subject = 'Göz_Yönü (Sağ/Sol)'.",
                "Korelasyon Matrisi: 'Exchangeable' seçilir; Covariance Matrix = 'Robust Estimator'.",
                "R Kodu Karşılığı: geepack::geeglm(GIB ~ Tedavi, id = Hasta_ID, corstr = 'exchangeable', data = df).",
                "Tablo Standardı: APA ve tıbbi dergi formatında 'ICC = 0.72; GEE modelinde beta = -3.4 mmHg, p = 0.008' olarak raporlanır [s.37]."
            ]
        },
        bottom_takeaway="İki gözü dahil eden çalışmalarda SPSS'te 'Independent T-Test' çalıştırmak metodolojik intihardır; mutlaka 'Generalized Estimating Equations (GEE)' çalıştırılmalıdır [s.36]."
    )

    # =========================================================================
    # 10.3: MASTER UZMANLIK DÜZEYİ AKTİF HATIRLAMA VAKA BANKASI (12 Slayt)
    # =========================================================================

    # Slayt 10.3.1: Master Vaka 1: Vasküler — PDR Zemininde Vitreus Kanaması
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 1: PDR VE AKUT VİTREUS KANAMASI",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="54 Yaşında Tip 2 Diyabetik Hastada Ani Görme Kaybı ve Non-Clearing Hemoraji",
        vignette="54 yaşında 15 yıldır tip 2 diyabet ve kontrolsüz hipertansiyonu olan erkek hasta, bu sabah uyandığında sağ gözünün önünde aniden yoğun siyah mürekkep dağılması gibi bir leke oluştuğunu ve görmesinin el hareketleri seviyesine düştüğünü belirterek başvuruyor. Ağrı yoktur. Sağ gözde biyomikroskopide ön kamara sakin, arka vitreusta fundus detaylarını tamamen silen yoğun taze eritrosit birikimi (vitreus hemorajisi) izleniyor. Sol göz muayenesinde optik diskte 1/2 DD genişliğinde aktif NVD, damar arkatlarında yaygın mikroanevrizmalar ve pamuk atığı lekeleri saptanıyor. B-Scan USG'de sağ retinada dekolman izlenmiyor.",
        differentials=[
            "Proliferatif Diyabetik Retinopati Zemininde NVD Kanaması (Sol gözdeki PDR bulguları tanıyı destekler).",
            "Akut Yırtıklı Arka Vitreus Dekolmanı (Sol göz PDR olduğu için diyabetik kanama önceliklidir).",
            "Retinal Ven Dal Tıkanıklığı Kanaması.",
            "Terson Sendromu (Subaraknoid kanama öyküsü yoktur)."
        ],
        decision="1. Sağ Göz Yönetimi: İstirahat ve başı yüksekte yatış verilir; B-Scan USG ile 2 haftada bir retina dekolmanı taranır. 4-6 haftada açılmazsa (non-clearing) 25G Pars Plana Vitrektomi + Endolazer PRP uygulanır.\n2. Sol Göz Acili: Sağ göz kanamışken sol göz de kanama riski altındadır; sol göze AYNI HAFTA Panretinal Fotokoagülasyon (PRP) lazer başlanmalıdır.\n3. Sistemik: HbA1c ve tansiyon regülasyonu için dahiliye konsültasyonu istenir.",
        board_trap="Yalnızca kanayan sağ göze odaklanıp hastanın sağlam görünen sol gözündeki aktif NVD'yi atlamak ve lazerlememek birkaç hafta içinde sol gözün de kanamasına yol açar; PDR bilateral bir hastalıktır [s.98]."
    )

    # Slayt 10.3.2: Master Vaka 2: Vasküler — Akut CRAO ve İnme Protokolü
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 2: AKUT SANTRAL RETİNAL ARTER TIKANIKLIĞI",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="67 Yaşında Erkekte Ağrısız Ani Körlük, Kiraz Kırmızısı Benek ve İnme Acili",
        vignette="67 yaşında sigara içicisi erkek hasta, 2 saat önce televizyon izlerken sol gözünün aniden ve tamamen karardığını belirterek 112 ile acil servise getiriliyor. Gözde ağrı veya kızarıklık yoktur. Sol gözde görme keskinliği yalnızca 'ışık hissi' düzeyindedir; sol gözde belirgin Rölatif Afferent Pupil Defekti (RAPD pozitif) saptanıyor. Biyomikroskopide ön segment doğal. Sol fundus muayenesinde fovea merkezinde parlak kırmızı 'kiraz kırmızısı benek' (cherry-red spot) ve çevresinde tüm arka kutbu saran süt beyazı kaba retinal iskemi ödemi izleniyor. Retinal arterler ipliksi incelmiş ve kan akımı 'sosis dilimleri' (boxcarring) şeklinde kesintili akmaktadır.",
        differentials=[
            "Non-Arteritik Santral Retinal Arter Tıkanıklığı (CRAO - Akut ağrısız körlük, kiraz kırmızısı benek, RAPD).",
            "Arteritik CRAO / Dev Hücreli Arterit (GCA - 50 yaş üstü, saçlı deri hassasiyeti ve çene klodikasyonu sorgulanmalıdır).",
            "Oftalmik Arter Tıkanıklığı (Koryokapillaris de tıkandığı için kiraz kırmızısı benek oluşmaz; tüm retina solar).",
            "Akut Optik Nörit (Retina beyazlaşmaz, kiraz kırmızısı benek görülmez)."
        ],
        decision="1. Zamana Karşı Yarış (İlk 4-6 Saat): Oküler masaj, ön kamara parasentezi ve İV Asetazolamid ile GİB düşürülerek trombüs perifere itilmeye çalışılır.\n2. İnme Protokolü: CRAO oftalmolojik bir acil olduğu kadar 'Akut İskemik İnme Eşdeğeri'dir. Hasta derhal Nöroloji İnme Merkezine sevk edilmeli, Difüzyon Beyin MRG ve Karotis Doppler USG çekilmelidir.\n3. GCA Taraması: Sedimantasyon ve CRP derhal bakılarak Dev Hücreli Arterit dışlanmalıdır.",
        board_trap="CRAO geçiren hastayı sadece göz polikliniğinde muayene edip eve göndermek en ağır malpraktistir; bu hastaların %25'inde ilk 1 haftada majör iskemik serebral inme gelişir; acil nöroloji inme protokolü zorunludur [s.110]."
    )

    # Slayt 10.3.3: Master Vaka 3: Makula — Anti-VEGF Dirençli PCV Olgusu
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 3: POLİPOİDAL KOROYDAL VASKÜLOPATİ (PCV)",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="62 Yaşında Hastada 6 Doz Ranibizumaba Rağmen Kurumayan Subretinal Sıvı ve Kanama",
        vignette="62 yaşında hipertansif kadın hasta, dış merkezde 'Yaş YBMD' tanısıyla son 8 ayda 6 doz intravitreal Ranibizumab enjeksiyonu almasına rağmen sağ gözünde görmenin 0.3'ten 0.1'e gerilediğini belirterek ikinci görüş için başvuruyor. Sağ fundus muayenesinde fovea altında geniş seroanjinöz RPE dekolmanı (koyu turuncu kabarık kubbe), çevresinde taze subretinal kanama ve lipid eksüdasyonu izleniyor. SD-OKT'de fovea altında dik açılı, çentikli yüksek RPE dekolmanı ('başparmak' işareti) ve çift katman (double-layer sign) izleniyor. İstenen İndosiyanin Yeşili Anjiyografisinde (ICG) fovea kenarında üzüm salkımı şeklinde hiperfloresan polipoid nodüller ve dallanan vasküler ağ (BVN) kesin olarak görüntüleniyor.",
        differentials=[
            "Polipoidal Koroidal Vaskülopati (PCV - Anti-VEGF monoterapisine direnç, seroanjinöz PED, ICG polipleri).",
            "Tip 1 Neovasküler YBMD (Anti-VEGF'e kısmen yanıt verir, ICG'de polipoid yumaklar içermez).",
            "Santral Seröz Koryoretinopati (Polip ve masif kanama yapmaz, genç erkeklerde sıktır).",
            "Koroid Melanomu (A-Scan'de düşük eko verir; bu vasküler bir lezyondur)."
        ],
        decision="1. Kesin Teşhis: Sağ Polipoidal Koroidal Vaskülopati (PCV - İki Gözlü Everest Kriterleri Pozitif).\n2. Tedavi Değişikliği: Ranibizumab monoterapisi polipleri kapatmada başarısız olmuştur. Everest-2 ve Planet çalışmalarına göre altın standart tedavi: Verteporfin Fotodinamik Tedavi (PDT) + İntravitreal Aflibercept (2 mg) kombinasyonudur.\n3. Uygulama: ICG kılavuzluğunda poliplerin üzerine tam doz FDT uygulanır ve aynı seansta Aflibercept enjekte edilir; polipler hızla tromboze olarak geriler.",
        board_trap="Tedaviye dirençli yaş YBMD zannedilen hastada ICG çekmeyip ezbere aynı anti-VEGF'i aylarca tekrarlamak masif subretinal kanamaya ve foveanın diskiform skarla tamamen körleşmesine yol açar; dirençli olguda ICG şarttır [s.140]."
    )

    # Slayt 10.3.4: Master Vaka 4: Makula — Kronik SSKR'de Yarım Doz FDT
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 4: KRONİK SANTRAL SERÖZ KORYORETİNOPATİ",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="40 Yaşında Erkek Yöneticide 6 Aydır Geçmeyen Foveal Sıvı ve Subretinal Presipitatlar",
        vignette="40 yaşında üst düzey yönetici erkek hasta, 6 aydır sağ gözünde bilgisayar ekranında eğrilme (metamorfopsi), renklerin soluklaşması ve karanlık bir leke şikayetiyle izlenmektedir. Tip A kişilik yapısına sahiptir ve yoğun stres altındadır. Sağ görme keskinliği 0.5. Ön segment doğal. Sağ fundusta foveayı içine alan 2 disk çapında yuvarlak seröz retina dekolmanı ve yerçekimi çizgileri boyunca uzanan RPE depigmentasyonu izleniyor. SD-OKT'de fovea altında kronik subretinal sıvı ve dış fotoreseptör segmentlerinde uzama/döküntüler (shaggy photoreceptors) izleniyor. EDI-OKT'de koroid kalınlığı 540 μm (pakikoroid). FFA'da foveanın 400 μm üstünde 'mürekkep lekesi' tarzında kronik vasküler sızıntı alanı saptanıyor.",
        differentials=[
            "Kronik Santral Seröz Koryoretinopati (6 aydan uzun süre, foveal sıvı, pakikoroid, RPE döküntüleri).",
            "Akut SSKR (Genellikle ilk 3 ayda spontan düzelir; bu vaka 6 aydır kronikleşmiştir).",
            "Neovasküler Yaş YBMD (OKTA'da KNV akım sinyali yoktur; genç hastadır).",
            "Vogt-Koyanagi-Harada Sendromu (Bilateraldir, vitrit vardır; bu hasta unilateral ve sakindir)."
        ],
        decision="1. Klinik Tanı: Kronik Santral Seröz Koryoretinopati (cCSCR).\n2. Steroid Sorgulaması: Hastanın kullandığı burun spreyi, cilt kremi veya eklem içi steroid enjeksiyonu olup olmadığı titizlikle sorgulanmalı ve varsa DERHAL KESİLMELİDİR.\n3. Altın Standart Tedavi: 6 ayı geçmiş ve foveal fotoreseptör hasarı başlamış olguda birinci basamak tedavi: Yarım Doz (Half-Dose) Verteporfin Fotodinamik Tedavidir (FDT).\n4. Parametre: 3 mg/m2 Verteporfin verilir ve sızıntı alanına 83 saniye 689 nm lazer uygulanır; sıvı 4-6 haftada tamamen kurur.",
        board_trap="SSKR'li hastaya 'gözünde ödem var' diyerek oral veya subtenon kortikosteroid vermek hastalığı büllöz dekolmana ve irreversibl foveal atrofiye sürükler; steroid SSKR'nin 1 numaralı tetikleyicisidir [s.138]."
    )

    # Slayt 10.3.5: Master Vaka 5: Dekolman — Makula-On RRD Zamanlaması
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 5: MAKULA-ON REGMATOJEN RETİNA DEKOLMANI",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="50 Yaşında Miyop Erkekte Saat 11:00 Yırtığı, Görme 1.0 ve Foveaya Doğru İlerleyen Sıvı",
        vignette="50 yaşında -4.00 D miyop erkek hasta, Cuma günü saat 15:30'da acile başvuruyor. Dün gece başlayan şimşek çakmalarını takiben bu sabah sağ gözünün üst dış alanında bir perde fark ettiğini ve perdenin aşağı doğru genişlediğini söylüyor. Sağ görme keskinliği 1.0 tamdır. Biyomikroskopide ön vitreusta serbest tütün tozu pigmentleri (Schaffer pozitif) saptanıyor. Fundus muayenesinde saat 11:00 hizasında ekvatoral geniş at nalı yırtık ve bu yırtıktan sızarak üst temporal kadranda büllöz elevasyon oluşturan subretinal sıvı izleniyor. Sıvının alt öncü sınırı üst damar arkatını aşmış ve foveanın sadece 400 μm yakınına kadar ilerlemiştir; ancak fovea merkezi henüz tamamen yapışıktır (Makula-On).",
        differentials=[
            "Makula-On Regmatojen Retina Dekolmanı (Doğru klinik tanı - Cerrahi Acil!).",
            "Makula-Off Retina Dekolmanı (Fovea tutulsaydı görme parmak saymaya düşerdi; burada 1.0 tamdır).",
            "Dejeneratif Retinoskizis (Schaffer negatiftir, mutlak skotom verir, dalgalanmaz).",
            "Eksüdatif Retina Dekolmanı (Yırtık bulunmaz, shifting sıvı vardır)."
        ],
        decision="1. Aciliyet Derecesi: Makula-On RRD tartışmasız bir cerrahi acildir; 'Pazartesi ameliyat ederiz' denilemez, fovea hafta sonu ayrılırsa görme asla 1.0 düzeyine dönemez.\n2. Yatış ve Pozisyon: Hasta derhal yatırılır; yerçekimiyle sıvının foveaya akmasını durdurmak için sağ şakak aşağıda kalacak şekilde lateral dekübit pozisyonu verilir.\n3. Cerrahi: İlk 24 saat içinde 25G Pars Plana Vitrektomi + Sıvı-Hava Değişimi + Endolazer + Gaz Tamponadı (C3F8/SF6) uygulanmalıdır.",
        board_trap="Hastanın görmesi 1.0 diye ameliyatı elektif günlere ertelemek foveanın dekolle olmasına ve ameliyat başarılı olsa bile kalıcı metamorfopsi ve görme kaybına yol açar; Makula-On bekletilemez [s.165]."
    )

    # Slayt 10.3.6: Master Vaka 6: Dekolman — Nüks Eden İleri PVR Evre C
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 6: NÜKS PVR EVRE C VE RETİNEKTOMİ",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="İki Kez Dekolman Ameliyatı Geçirmiş Gözde Rijit Katlantılar ve Silikon Seçimi",
        vignette="55 yaşında psödofakik erkek hasta, sağ gözünden 2 ay önce RRD nedeniyle sklera çökertme, 1 ay önce ise nüks dekolman nedeniyle PPV ve C3F8 gaz ameliyatı geçirmiştir. Gaz tamamen eridikten 1 hafta sonra hastanın görmesi tekrar el hareketlerine düşüyor. Biyomikroskopide ön vitreusta yaygın pigment kümeleri izleniyor. Fundus muayenesinde arka kutupta 4 saat kadranını saran rijit yıldız katlantılar (star folds), alt retinada retinayı öne doğru büzen kalın bir subretinal bant ve ekvator boyunca retinanın büzüşerek siliyer cisme çekildiği (PVR Evre CA-diffüz ve CP-diffüz) saptanıyor. Retina kaskatı ve hareketsizdir.",
        differentials=[
            "PVR Evre C Zemininde Nüks Regmatojen Retina Dekolmanı (Kısalmış retina ve diffüz traksiyon).",
            "Basit Nüks Dekolman (PVR olmasaydı retina dalgalı ve elastik olurdu; burada taş gibi serttir).",
            "Postoperatif Kronik Endoftalmi (Göz sakin, ağrısız ve hipopiyonsuzdur).",
            "Traksiyonel Diyabetik Dekolman (Diyabet öyküsü yoktur; cerrahi nüksüdür)."
        ],
        decision="1. Cerrahi Strateji: Bu göze bir kez daha basit gaz tamponadı vermek kesin başarısızlıktır; agresif PVR cerrahisi şarttır.\n2. Cerrahi Adımlar: 23G PPV ile girilir; triamsinolon ile tüm epiretinal membranlar boyanarak bimanüel soyulur; subretinal bant retinotomi ile eksize edilir.\n3. Gevşetici Retinektomi: Retina elastikiyetini kaybettiği ve yerine oturmadığı için inferior kadranda 180° geniş gevşetici retinektomi yapılır; doku gerilimi sıfırlanır.\n4. Tamponad: Retina PFCL altında yatıştırılır, retinektomi kenarına 3 sıra endolazer atılır ve uzun süreli 5000 cSt Silikon Yağı verilir.",
        board_trap="PVR Evre C gelişmiş rijit bir gözde membranları soymadan ve retinektomi yapmadan sadece gaz veya silikon basmak retinanın yatışmasını sağlamaz; mekanik gerilim gevşetici retinektomi ile sıfırlanmalıdır [s.176]."
    )

    # Slayt 10.3.7: Master Vaka 7: Distrofi — Çift Allelik RPE65 ve Luxturna
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 7: RPE65 DİSTROFİSİ VE LUXTURNA GEN TEDAVİSİ",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="11 Yaşında Kız Çocuğunda Ağır Gece Körlüğü, Canlı Fotoreseptörler ve AAV2 Tedavisi",
        vignette="11 yaşında kız çocuğu, erken çocukluktan beri alacakaranlıkta göremediği, akşamları sokak lambaları altında dahi yürürken engellere çarptığı ve son yıllarda görme keskinliğinin azaldığı şikayetiyle başvuruyor. Görme keskinliği her iki gözde 0.3. Biyomikroskopi doğal. Fundusta hafif arteriyoler incelme ve periferde silik tuz-biber pigment değişiklikleri izleniyor; belirgin kemik spikülü veya coğrafi atrofi yoktur. SD-OKT'de fovea merkezinde retina kalınlığı 180 μm olup elipsoid zon (canlı fotoreseptör bandı) net olarak korunmuştur. Yapılan tüm ekzom dizilemede (WES) RPE65 geninde her iki ebeveynden aktarılan patojenik çift allelik mutasyon doğrulanıyor.",
        differentials=[
            "RPE65 İlişkili Erken Başlangıçlı Retinitis Pigmentosa (Luxturna adayı).",
            "X'e Bağlı RP (RPGR mutasyonu; kız çocuklarında nadirdir).",
            "Koni-Çomak Distrofisi (Gündüz görmesi ve renkler ön planda bozulur).",
            "Konjenital Stasyoner Gece Körlüğü (CSNB - İlerleyici değildir, retina kalınlığı normal kalır)."
        ],
        decision="1. Endikasyon Değerlendirmesi: Hasta çift allelik RPE65 mutasyonuna sahiptir, yaşı >12 aydır ve SD-OKT'de canlı fotoreseptör tabakası (kalınlık >100 μm, elipsoid zon +) mevcuttur. Hasta tam bir Voretigene Neparvovec (Luxturna) adayıdır.\n2. Cerrahi Tedavi: Ameliyattan 3 gün önce oral prednizon başlanır. 25G PPV ile arka hyaloid ayrılır; 41G kanülle foveayı kapsayacak şekilde 0.3 ml (1.5 x 10^11 vg) subretinal Luxturna büllesi oluşturulur.\n3. İkinci Göz: İlk gözden 10 gün sonra sol göze aynı cerrahi uygulanır; hastanın ışık duyarlılığı 100-1000 kat artar.",
        board_trap="Eğer bu hastanın retinası ileri evre atrofiye gitmiş olsaydı (kalınlık <50 μm, elipsoid zon silinmiş), genetik test RPE65 çıksa dahi Luxturna verilemezdi; ilacın çalışması için canlı hedef hücre şarttır [s.197]."
    )

    # Slayt 10.3.8: Master Vaka 8: Distrofi — 16 Yaş Stargardt ve A Vitamini Tuzağı
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 8: STARGARDT HASTALIĞI VE A VİTAMİNİ YASAĞI",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="16 Yaşında Gençte Tahtayı Görememe, Balık Pulları, Karanlık Koroid ve Reçete Hatası",
        vignette="16 yaşında erkek lise öğrencisi, son 1 yıldır sınıfta tahtayı okuyamadığını, renkleri seçmekte zorlandığını belirterek getiriliyor. Görme keskinliği her iki gözde 0.2'ye düşmüş; gözlükle düzelmiyor. Ön segment tamamen normal. Fundus muayenesinde foveada hafif metalik parlama ('dövülmüş bronz' manzarası) ve arka kutupta foveayı çevreleyen sarımsı-beyaz balık pulu (pisciform) lekeler izleniyor. FFA çekildiğinde tüm retinada koryokapillaris arka plan floresansının tamamen silindiği patognomonik 'Karanlık Koroid' (Silent Choroid) saptanıyor. Hastanın daha önce gittiği bir hekim tarafından 'retinayı güçlendirsin' diye yüksek doz A vitamini ve beta-karoten içeren kapsül reçete edildiği öğreniliyor.",
        differentials=[
            "Stargardt Hastalığı (STGD1 - Genç yaş, foveal bronzlaşma, pisciform fleckler, ABCA4 defekti, karanlık koroid).",
            "Best Vitelliform Makulopati (FFA'da karanlık koroid izlenmez, EOG Arden oranı çöker).",
            "Juvenil Koni Distrofisi (30 Hz flicker ERG çöker, karanlık koroid yapmaz).",
            "Toksik Retinopati (Klorokin kullanımı yoksa dışlanır)."
        ],
        decision="1. Kesin Teşhis: Stargardt Hastalığı (Otozomal Resesif ABCA4 Mutasyonu).\n2. ACİL EYLEM: A vitamini takviyesi DERHAL KESİLMELİDİR. A vitamini görme döngüsünü besleyerek toksik A2E (lipofuksin) birikimini katlar ve körlüğü hızlandırır.\n3. Yaşam Tarzı ve Koruma: Dışarıda %100 UV filtreli koyu güneş gözlüğü kullanımı önerilir; az görenlere yardım cihazları (teleskopik gözlük, dijital büyüteç) reçete edilir.\n4. Genetik: ABCA4 gen dizi analizi ile mutasyon teyit edilir.",
        board_trap="RP'deki eski alışkanlıkla Stargardt hastasına A vitamini takviyesi vermek sınavda sıfır puan, pratikte ise ağır malpraktistir; A vitamini Stargardt'ta kesinlikle kontrendikedir [s.187]."
    )

    # Slayt 10.3.9: Master Vaka 9: Enfeksiyon — İmmünkompetan Bireyde ARN
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 9: AKUT RETİNAL NEKROZ (ARN) VE LAZER",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="44 Yaşında Sağlıklı Erkekte Kızarık Ağrılı Göz, Yoğun Vitrit ve Periferik Nekroz",
        vignette="44 yaşında sağlıklı erkek hasta, sağ gözünde 3 gündür şiddetli ağrı, kanlanma ve görmede ani sislenme ile başvuruyor. Sağ görme keskinliği 0.1, sol görme 1.0 tam. Biyomikroskopide sağ konjonktivada hiperemi, korneada keratik presipitatlar, ön kamarada 2+ hücre ve arka vitreusta fundusu kapatan 3+ yoğun vitrit izleniyor. İndirekt oftalmoskopide temporal periferde başlayıp saat 8:00'den 2:00'ye kadar birleşerek uzanan keskin sınırlı sarımsı-beyaz nekroz sahaları ve komşu damarlarda şiddetli oklüzif arterit izleniyor. Fovea henüz nekrozla tutulmamış.",
        differentials=[
            "Akut Retinal Nekroz (ARN - İmmünkompetan hasta, periferik nekroz, oklüzif vaskülit, yoğun vitrit; HSV-1/VZV).",
            "Progresif Dış Retinal Nekroz (PORN - İmmün yetmezlikte görülür, vitrit SIFIRDIR).",
            "Sitomegalovirüs Retiniti (CD4 <50 HIV hastalarında kanamalı pizza-pie nekrozu yapar).",
            "Oküler Toksoplazmozis (Eski pigmentli skar kenarında fokal nekroz yapar; çevresel nekroz yapmaz)."
        ],
        decision="1. Klinik Teşhis: Sağ Akut Retinal Nekroz (ARN).\n2. Acil Antiviral Tedavi: PCR sonucu beklenmeden derhal İntravenöz Asiklovir (10 mg/kg günde 3 kez) veya Oral Valasiklovir (1000 mg 3x1) başlanmalı; foveayı kurtarmak için AYNI GÜN İntravitreal Gansiklovir (2 mg) enjekte edilmelidir.\n3. Steroid Zamanlaması: Antiviral örtünün 48. saatinde vitriti dindirmek için Oral Prednizolon (1 mg/kg) eklenmelidir.\n4. Profilaktik Bariyer Lazer: Vitrit açılır açılmaz nekroz sınırının hemen gerisindeki sağlam retinaya 360° bariyer lazer atılarak dekolman önlenmelidir.",
        board_trap="Bu hastada yoğun vitriti görüp 'bu şiddetli bir panüveit' diyerek antiviral başlamadan tek başına yüksek doz kortikosteroid vermek retinanın birkaç günde erimesine yol açar; viral nekrozda antiviralsiz steroid yasaktır [s.203]."
    )

    # Slayt 10.3.10: Master Vaka 10: Üveit — Genç Erkekte Behçet Atağı
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 10: BEHÇET HASTALIĞI RETİNAL VASKÜLİTİ",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="28 Yaşında Erkekte Tekrarlayan Ağız Yaraları, Hipopiyon ve Eğrelti Otu Vasküliti",
        vignette="28 yaşında erkek hasta, sol gözünde dünden beri şiddetli görme kaybı ve kızarıklık ile acile başvuruyor. Hastanın özgeçmişinde yılda 5-6 kez çıkan ağrılı oral aftlar ve bacaklarında eritema nodozum lezyonları mevcuttur. Sol görme 0.1 düzeyindedir. Biyomikroskopide ön kamarada 1.5 mm yüksekliğinde mobil hipopiyon izleniyor. Fundus muayenesinde fovea çevresinde retinal damarlarda yaygın beyaz kılıflanma, intraretinal alev kanamalar ve 2+ vitrit izleniyor. Geniş açılı FFA'da damar duvarlarından dışarı sızan diffüz floreseinin tipik 'eğrelti otu' (fern-like) paterni oluşturduğu ve kapiller non-perfüzyon alanları saptanıyor.",
        differentials=[
            "Behçet Hastalığı Oklüzif Retinal Vasküliti ve Panüveit (Doğru klinik tanı).",
            "HLA-B27 İlişkili Ön Üveit (Ön kamarada hipopiyon yapabilir ancak arka segmentte eğrelti otu vasküliti yapmaz).",
            "Oküler Sarkoidoz (Vaskülit oklüzif değildir, mum damlası periflebiti yapar).",
            "Enfeksiyöz Endoftalmi (Cerrahi veya travma öyküsü olmadığı için dışlanır)."
        ],
        decision="1. Klinik Teşhis: Behçet Hastalığı Akut Oklüzif Retinal Vaskülit Atağı.\n2. Acil Tedavi: Hasta derhal yatırılmalı; 3 gün boyunca İntravenöz Pulse Metilprednizolon (1000 mg/gün) uygulanmalıdır.\n3. Biyolojik Tedavi Devrimi: Görmeyi tehdit eden bu tabloda ilk basamakta İntravenöz İnfliksimab (5 mg/kg) veya subkutan Adalimumab başlanmalı, uzun dönem idame için Azatioprin (2.5 mg/kg/gün) eklenmelidir.\n4. İskemi Yönetimi: İnflamasyon yatıştıktan sonra perfüze olmayan sahalara sektörel argon lazer fotokoagülasyon uygulanmalıdır.",
        board_trap="Bu hastada hipopiyonu görüp hastaya sadece topikal steroidli göz damlası verip göndermek arka kutuptaki nekrotizan vaskülitin gözü kalıcı olarak kör etmesine yol açar; Behçet vasküliti acil sistemik biyolojik tedavi gerektirir [s.212]."
    )

    # Slayt 10.3.11: Master Vaka 11: Onkoloji — TFSOM Pozitif Küçük Koroid Melanomu
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 11: KÜÇÜK KOROİD MELANOMU VE PLAK RADYOTERAPİ",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="58 Yaşında Hastada TFSOM Kriterleri Pozitif Pigmente Kitle ve Karaciğer Taraması",
        vignette="58 yaşında kadın hasta, rutin gözlük muayenesinde sağ göz dibinde 'şüpheli bir ben' görülmesi üzerine sevk ediliyor. Hastanın sağ gözünde son haftalarda hafif ışık çakmaları (fotopsi) mevcuttur. Sağ görme 0.8, sol görme 1.0. Sağ fundus muayenesinde foveanın 1.5 disk çapı superiorunda 2.8 mm kabarık, taban çapı 7.5 mm olan kubbe şeklinde koyu kahverengi melanositik kitle izleniyor. Kitlenin yüzeyinde portakal kabuğu renginde lipofuksin pigment kümeleri ve lezyonun alt kenarında sığ subretinal sıvı izleniyor. B-Scan USG'de akustik boşluk ve koroidal ekskavasyon; A-Scan USG'de %40 düzeyinde düşük-orta iç reflektivite izleniyor. FAF'ta portakal pigmentleri parlak hiperotofloresan yanıyor.",
        differentials=[
            "Küçük/Orta Boy Koroid Melanomu (Kalınlık >2 mm, sıvı +, portakal pigmenti +, semptom +, düşük iç eko; TFSOM pozitif).",
            "Büyük Koroid Nevüsü (Kalınlık <2 mm'dir, sıvı ve portakal pigmenti içermez, A-Scan'de yüksek ekolüdür).",
            "Koroid Hemanjiomu (Somon rengidir, A-Scan'de >%90 aşırı yüksek iç reflektivite verir).",
            "RPE Hipertrofisi (CHRPE - Simsiyah, yassı ve keskin sınırlıdır; kalınlık yapmaz)."
        ],
        decision="1. Kesin Teşhis: Sağ Koroid Melanomu (TFSOM kriterlerinin 5 tanesi pozitif - kesin malignite).\n2. Sistemik Metastaz Taraması: Tedavi öncesi karaciğer mikrometastazını dışlamak için Kontrastlı Üst Batın MRG ve Karaciğer Fonksiyon Testleri (AST, ALT, GGT, LDH) çekilmelidir.\n3. Göz Koruyucu Tedavi: COMS çalışması standartlarına göre İyot-125 (I-125) veya Rutenyum-106 Plak Radyoterapisi (Brakiterapi) planlanmalıdır.\n4. Biyopsi: Plak cerrahisi esnasında prognostik genetik analiz (Monozomi 3 ve BAP1) için ince iğne aspirasyon biyopsisi (FNAB) yapılabilir.",
        board_trap="Lezyonun üzerinde subretinal sıvı ve portakal pigmenti varken 'bu bir nevüstür, 1 yıl sonra bakarız' demek hastanın hayatına mal olur; lezyon 5 TFSOM kriteri taşımaktadır ve derhal plak radyoterapi ile tedavi edilmelidir [s.253]."
    )

    # Slayt 10.3.12: Master Vaka 12: Travma/Farmako — Postoperatif Endoftalmi
    builder.add_active_recall_case_slide(
        title="MASTER VAKA 12: AKUT POSTOPERATİF ENDOFTALMİ VE EVS",
        category="BÖLÜM 10.3: VAKA BANKASI",
        subtitle="Katarakt Cerrahisinden 3 Gün Sonra Ağrı, Hipopiyon ve Işık Hissi Düzeyinde Görme",
        vignette="71 yaşında kadın hasta, 3 gün önce sol katarakt cerrahisi geçirmiştir. Dün geceden beri sol gözünde şiddetli zonklayıcı ağrı, kapaklarda şişlik ve görmede ani körleşme ile sabah acile getiriliyor. Sol göz görme keskinliği yalnızca IŞIK HİSSİ (Light Perception - LP) düzeyindedir (el hareketlerini dahi seçemiyor). Biyomikroskopide sol konjonktivada yoğun kemozis, kornea alt yarısında ödem, ön kamarada 2.5 mm seviyesinde fibrinöz hipopiyon ve yoğun hücresel reaksiyon izleniyor. Arka segmentte kırmızı refle tamamen kaybolmuş, fundus vitrit nedeniyle seçilemiyor. B-Scan USG'de vitreus boşluğunda yoğun ekojenik infiltrasyon izleniyor; retina yatışık.",
        differentials=[
            "Akut Postoperatif Bakteriyel Endoftalmi (3. günde başlama, şiddetli ağrı, hipopiyon, vitrit ve yalnızca ışık hissi görme).",
            "Toksik Ön Segment Sendromu (TASS - İlk 24 saatte başlar, vitrit içermez, kırmızı refle kaybolmaz).",
            "Steroid Psödoendoftalmisi (Göz ağrısızdır, katarakt ameliyatında intrakameral steroid yapılmadıysa görülmez).",
            "Şiddetli İridosiklit / Fibrin Reaksiyonu (Vitrit eşlik etmez, kırmızı refle kaybolmaz)."
        ],
        decision="1. Klinik Teşhis: Akut Postoperatif Bakteriyel Endoftalmi.\n2. EVS Kriterine Göre Cerrahi Karar: Hastanın görme keskinliği YALNIZCA IŞIK HİSSİ (LP) düzeyindedir. Endophthalmitis Vitrectomy Study (EVS) landmark kriterlerine göre bu hasta ACİL PARS PLANA VİTREKTOMİ (PPV) ENDİKASYONUDUR.\n3. Cerrahi ve Antibiyotik: Hasta aynı gün acil ameliyathaneye alınır; 25G PPV ile vitreus apsesi mekanik olarak boşaltılır; ameliyat sonunda İntravitreal Vankomisin (1.0 mg) + Seftazidim (2.25 mg) enjekte edilir.\n4. Sistemik Tedavi: EVS çalışmasına göre intravenöz sistemik antibiyotiklerin hiçbir ek faydası yoktur; sistemik antibiyotik verilmez.",
        board_trap="Görme keskinliği yalnızca ışık hissi (LP) olan bir endoftalmi hastasında vitrektomiyi erteleyip sadece poliklinikte antibiyotik iğnesi yapmak EVS kurallarına göre ağır hatadır; LP hastalarında acil vitrektomi görme başarısını 3 kat artırır [s.266]."
    )

    # =========================================================================
    # 10.4: KAYNAKÇA, RESMÎ KÜNYE VE PUBMED LANDMARK İNDEKSİ (3 Slayt)
    # =========================================================================

    # Slayt 10.4.1: Referans Eser Resmî Künyesi ve Kitap Yapısı
    builder.add_study_card_slide(
        title="REFERANS ESER RESMÎ KÜNYESİ VE DERS KİTABI YAPISI",
        category="BÖLÜM 10.4: KÜNYE [p.277]",
        subtitle="280 Sayfalık Temel Eser, 9 Bölüm ve 61 Numaralı Alt Başlığın Müfredat Haritası",
        cards=[
            {
                "card_title": "1. Referans Eser Resmî Künyesi",
                "lead": "Temel Kaynak ve Akademik Çerçeve",
                "items": [
                    "Kitap Başlığı: Retina ve Vitreus: Klinik Yaklaşım, Tanı ve Tedavi Prensipleri [s.277].",
                    "Kapsam: 280 Sayfa, 9 Ana Bölüm, 61 Numaralı Klinik Başlık, 115 Yüksek Çözünürlüklü Şekil ve Atlas.",
                    "Dijital Kaynak: C:\\Users\\gezic\\Drive'ım\\Retina Kitabı\\Retina_ve_Vitreus_Klinik_Yaklasim.pdf.",
                    "Format: 16:9 Geniş Ekran, 446 Slaytlık Kişisel Çalışma Atlası ve Masterclass Compendium."
                ],
                "footer": "280 Sayfa / 9 Bölüm / 115 Görsel / 446 Slayt"
            },
            {
                "card_title": "2. Modüler Müfredat Dağılımı",
                "lead": "Temel Bilimlerden Gelecek Teknolojilere",
                "items": [
                    "Bölüm 1: Temel Bilimler ve Anatomi (s. 3-37) -> 46 Slayt.",
                    "Bölüm 2: Retinal Görüntüleme ve Tanı Yöntemleri (s. 38-90) -> 63 Slayt.",
                    "Bölüm 3: Retinal Vasküler Hastalıklar (s. 91-126) -> 56 Slayt.",
                    "Bölüm 4: Makula Hastalıkları ve YBMD (s. 127-155) -> 52 Slayt.",
                    "Bölüm 5: Retina Dekolmanı ve Periferik Retina (s. 156-177) -> 41 Slayt.",
                    "Bölüm 6: Kalıtsal Retinal ve Koroidal Distrofiler (s. 178-200) -> 39 Slayt."
                ],
                "footer": "Modül 1 - 6 (Slayt 3 - 299)"
            },
            {
                "card_title": "3. İleri Klinik ve Metodolojik Modüller",
                "lead": "Enfeksiyon, Onkoloji, Travma ve Biyoistatistik",
                "items": [
                    "Bölüm 7: Enfeksiyöz ve İnflamatuar Retina Hastalıkları (s. 201-244) -> 62 Slayt.",
                    "Bölüm 8: Retina ve Koroid Tümörleri (s. 245-258) -> 26 Slayt.",
                    "Bölüm 9: Travma, Farmakoterapi, Gelecek ve YZ (s. 259-276) -> 31 Slayt.",
                    "Bölüm 10: Master Matris, Biyoistatistik ve Vaka Bankası (s. 277-280) -> 28 Slayt.",
                    "Toplam Hacim: Kapak (1) + Müfredat (1) + 444 Klinik Slayt = Tam 446 Slayt."
                ],
                "footer": "Modül 7 - 10 (Slayt 300 - 446)"
            }
        ]
    )

    # Slayt 10.4.2: Retina ve Vitreus Landmark Klinik Çalışmalar İndeksi
    builder.add_trials_kpi_slide(
        title="LANDMARK RETİNA KLİNİK ÇALIŞMALARI VE PUBMED İNDEKSİ",
        category="BÖLÜM 10.4: BİBLİYOGRAFYA",
        subtitle="Retina Pratiğini Değiştiren Büyük Kanıta Dayalı Klinik Çalışmalar ve Literatür Sentezi",
        kpis=[
            {"val": "ETDRS", "label": "Diyabetik Retinopati Altın Standardı"},
            {"val": "CATT", "label": "Ranibizumab vs Bevacizumab Eşdeğerliği"},
            {"val": "EVS", "label": "Endoftalmi Vitrektomi Kriteri (LP vs HM)"},
            {"val": "COMS", "label": "Melanom Plak vs Enükleasyon Sağkalımı"}
        ],
        trials_table=[
            {
                "trial": "ETDRS / DRS Landmark Çalışmaları",
                "design": "Erken Tedavi Diyabetik Retinopati Çalışması (Ophthalmology 1991) [s.277]",
                "result": "4-2-1 kuralı tanımlanmış, panretinal fotokoagülasyonun (PRP) şiddetli görme kaybı riskini %50 azalttığı kanıtlanmıştır."
            },
            {
                "trial": "CATT / IVAN / HARBOR Çalışmaları",
                "design": "Yaş YBMD'de Anti-VEGF Molekülleri ve Dozaj Protokolleri Karşılaştırması",
                "result": "Ranibizumab ve Bevacizumab'ın görme keskinliği kazanımında eşdeğer olduğu; Treat-and-Extend rejiminin PRN'den üstün olduğu gösterilmiştir."
            },
            {
                "trial": "EVS (Endophthalmitis Vitrectomy Study)",
                "design": "Postoperatif Endoftalmide Cerrahi vs Antibiyotik Enjeksiyonu RCT (Arch Ophthalmol 1995)",
                "result": "Işık hissi (LP) olanlarda vitrektomi görmeyi 3 kat artırırken; el hareketi (HM) ve üzerinde vitrektominin enjeksiyona üstünlüğü olmadığı kanıtlanmıştır."
            },
            {
                "trial": "COMS (Collaborative Ocular Melanoma Study)",
                "design": "Orta Boy Koroid Melanomunda İyot-125 Plak Radyoterapi vs Enükleasyon RCT",
                "result": "Plak brakiterapisinin enükleasyon ile birebir eşit 5, 10 ve 12 yıllık sistemik metastazsız sağkalım sağladığı kanıtlanarak göz koruma standartlaşmıştır."
            },
            {
                "trial": "Russell et al. (Luxturna Faz 3 - The Lancet 2017)",
                "design": "Çift Allelik RPE65 Mutasyonlu Retinal Distrofide AAV2 Gen Terapisi RCT [s.278]",
                "result": "Voretigene neparvovec enjeksiyonu ile hastaların %65'inde karanlık parkurda (1 Lux) tam fonksiyonel iyileşme sağlanmış ve FDA onayı almıştır."
            }
        ],
        bottom_evidence="Bu ders atlasındaki tüm klinik algoritmalar, dozajlar ve cerrahi zamanlamalar yukarıdaki Faz 3 randomize kontrollü kanıtlara dayandırılmıştır [s.277]."
    )

    # Slayt 10.4.3: Yasal Sorumluluk Reddi ve Akademik Künye
    builder.add_study_card_slide(
        title="YASAL SORUMLULUK REDDİ VE AKADEMİK KÜNYE",
        category="BÖLÜM 10.4: AKADEMİK KÜNYE",
        subtitle="Eğitim ve Board Sınavı Odaklı Kişisel Çalışma Atlası Kullanım İlkeleri",
        cards=[
            {
                "card_title": "1. Akademik Kullanım ve Sorumluluk Reddi",
                "lead": "Kişisel Çalışma ve Uzmanlık Sınavı Rehberi",
                "items": [
                    "Bu çalışma sunumu (atlas), hekimlerin ve asistanların kişisel çalışma, uzmanlık ve board sınavlarına hazırlığı için derlenmiştir [s.280].",
                    "Doğrudan bir hastanın klinik tedavi protokolü olarak kullanılmamalıdır; her vaka kendi klinik parametreleriyle değerlendirilmelidir.",
                    "İlaç dozajları ve endikasyonlar Sağlık Bakanlığı, FDA ve EMA resmî prospektüsleriyle doğrulanmalıdır.",
                    "Tıbbi bilgi ve kanıtlar sürekli güncellenmektedir; hekim güncel kılavuzları takip etmekle yükümlüdür."
                ],
                "footer": "Eğitim Odaklıdır / Kişiselleştirilmiş Tedavi Esastır"
            },
            {
                "card_title": "2. Tasarım ve Teknoloji Mimarisi",
                "lead": "Study-First Widescreen Presentation",
                "items": [
                    "Widescreen 16:9 (13.333 x 7.5 inç) profesyonel retina atlası mimarisi.",
                    "Konuşmacı notuna ihtiyaç duymayan, tüm bilginin slayt kartlarında açıkça sunulduğu 'Study-First' yaklaşımı.",
                    "Sıfır boş sayfa kuralı: Tüm bölüm başları 4 kartlı derin tematik yol haritalarına dönüştürülmüştür.",
                    "Kitaptan çıkarılan 115 adet yüksek çözünürlüklü klinik fundus fotoğrafı ve şema ile görselleştirilmiştir."
                ],
                "footer": "16:9 Geniş Ekran / Study-First / Sıfır Boş Sayfa"
            },
            {
                "card_title": "3. Akademik Başarı Dilekleri",
                "lead": "Retina ve Vitreus Klinik Mükemmeliyeti",
                "items": [
                    "Retina hekimliği derin anatomi, ileri teknolojik görüntüleme ve milimetrik mikrocerrahi sanatıdır.",
                    "446 slayttan oluşan bu kapsamlı atlasın oftalmoloji uzmanlık yolculuğunda kalıcı bir başvuru kaynağı olması hedeflenmiştir.",
                    "Doğru teşhis ve zamanında müdahale edilen her vaka, bir insanın dünyayı görmeye devam etmesi demektir.",
                    "Başarılı çalışmalar ve sınavlar dileriz."
                ],
                "footer": "Retina ve Vitreus: Klinik Yaklaşım Atlası (Tamamlandı)"
            }
        ]
    )

    print(f" -> Bölüm 10 (Master Matris, Biyoistatistik, Vaka Bankası ve Kaynakça) Tamamlandı: 28 Slayt Eklendi.")
