# -*- coding: utf-8 -*-
r"""
build_precise_retina_registry.py — 446 Slayt İçin %100 Doğrulanmış Klinik Retina Görsel Kataloğu
=============================================================================================
Bu betik, dünya standardı oftalmoloji atlaslarından (The Retinal Atlas, AAO BCSC Retina,
Atlas of Retinal OCT, Ryan's Retina, The Uveitis Atlas, Ophthalmic Pathology):
- Kitap kapaklarını, bölüm başlık şeritlerini (1600x680) ve anlamsız ikonları kesin olarak filtreler.
- Her bir alt konu kodu ve hastalık antitesine (DME, BRVO, CRVO, CRAO, YBMD, PCV, RAP, SSKR,
  Makula Deliği, ERM, PVD, RRD, RP, Stargardt, Best, Toksoplazmoz, CMV, ARN, VKH, Melanom, vb.)
  birebir uyumlu, yüksek çözünürlüklü klinik görselleri ve açıklayıcı Türkçe klinik altyazıları eşler.
"""

import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

# UTF-8 stdout
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
CATALOG_PATH = BASE_DIR / "assets" / "visual_catalog" / "master_catalog.json"
OUTPUT_PATH = BASE_DIR / "retina_precise_registry.json"

CLINICAL_DIRS = [
    "12-Retina_and_Vitreous_2025-2026",
    "THE_RETINAL_ATLAS_2nd_Ed_",
    "Atlas_of_Retinal_OCT",
    "Atlas_of_Retinal_OCT_2nd_Ed_",
    "ATLAS_OCT_of_Macular_Diseases",
    "Clinical_Atlas_of_Peripheral_Retinal_Disorders",
    "The_Uveitis_Atlas",
    "04-Ophthalmic_Pathology_and_Intraocular_Tumors_2025-2026",
    "09-Uveitis_and_Ocular_Inflammation_2025-2026",
    "Diagnostics_in_Ocular_Imaging_Cornea__Retina__Glaucoma_and_Orbit",
    "Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3_",
    "RYAN_S_RETINA_7th_Ed__Vol_2",
    "RYAN_S_RETINA_7th_Ed__Vol_3",
    "RYAN_S_RETINA_7th_Ed__Vo_1"
]


def build_registry():
    print(">>> 1. Master Görsel Kataloğu Taranıyor...")
    with open(CATALOG_PATH, "r", encoding="utf-8") as f:
        master = json.load(f)

    local_imgs = master.get("local_images", [])
    print(f"Toplam Görsel Sayısı: {len(local_imgs)}")

    # 1. Aşama: Şeritleri, kapakları ve uyumsuz görselleri ele
    vetted_imgs = []
    for item in local_imgs:
        fpath = item.get("file_path", "")
        if not fpath:
            continue

        if not any(cd.lower() in fpath.lower() for cd in CLINICAL_DIRS):
            continue

        p = Path(fpath)
        if not p.exists():
            continue

        # Boyut filtresi (15 KB - 12 MB)
        sz = p.stat().st_size
        if sz < 15000 or sz > 12000000:
            continue

        # En-Boy Oranı Kontrolü (1600x680 gibi şeritleri engelle)
        w = item.get("width", 0)
        h = item.get("height", 0)
        if w > 0 and h > 0:
            ratio = w / h
            if ratio > 2.05 or ratio < 0.45:
                continue

        # Başlık ve dosya adı kara listesi
        fn = p.name.lower()
        if "xref_3" in fn or "page_001_" in fn or "page_038_" in fn or "page_190_" in fn:
            continue

        caption = item.get("caption", "").strip()
        tags = [t.lower() for t in item.get("tags", [])]
        search_blob = (fn + " " + caption.lower() + " " + " ".join(tags))

        vetted_imgs.append({
            "path": str(p),
            "filename": p.name,
            "book": item.get("book", p.parent.name),
            "caption": caption,
            "tags": tags,
            "search_blob": search_blob
        })

    print(f"Filtrelenmiş Doğrulanmış Klinik Görsel Havuzu: {len(vetted_imgs)}")

    # 2. Aşama: Hastalık ve Alt Konu Spesifik Kuralları
    # Her anahtar, slaytların koduna ve başlığına karşılık gelir.
    RULES = [
        # BÖLÜM 1: TEMEL BİLİMLER VE ANATOMİ
        {
            "code": "1.1.1",
            "terms": ["vitreous cortex", "posterior hyaloid", "vitreous base", "weiss ring", "internal limiting"],
            "not": ["hemorrhage", "melanoma", "diabetic", "detachment"],
            "default_cap": "SD-OKT & Anatomi: Vitreoretinal Arayüz, Arka Hyaloid Zarı ve İç Sınırlayıcı Membran (İLM)"
        },
        {
            "code": "1.1.2",
            "terms": ["foveal microanatomy", "retinal layers", "ellipsoid zone", "external limiting membrane", "outer nuclear"],
            "not": ["neovascular", "drusen", "edema", "tumor"],
            "default_cap": "Yüksek Çözünürlüklü SD-OKT: Nörosensoryal Retinanın 10 Katmanı ve Foveal Mikroanatomi"
        },
        {
            "code": "1.1.3",
            "terms": ["retinal pigment epithelium", "rpe", "bruch membrane", "basal lamina"],
            "not": ["melanoma", "detachment", "drusen"],
            "default_cap": "Histopatoloji & SD-OKT: RPE Hücresel Monolayırı, Apikobazal Polarite ve Bruch Membranı"
        },
        {
            "code": "1.1.4",
            "terms": ["choriocapillaris", "choroid blood", "haller", "sattler", "vortex vein"],
            "not": ["melanoma", "nevus", "hemangioma"],
            "default_cap": "EDI-OKT & İndosiyanin Yeşili: Koryokapillaris Lobüler Mimarisi ve Haller/Sattler Katmanları"
        },
        {
            "code": "1.2.1",
            "terms": ["photoreceptor", "rhodopsin", "phototransduction", "outer segment", "cone photoreceptor"],
            "not": ["melanoma", "tumor"],
            "default_cap": "Moleküler & SD-OKT İncelemesi: Fotoreseptör Dış Segmentleri, Elipsoid Zon ve Görme Döngüsü"
        },
        {
            "code": "1.2.2",
            "terms": ["blood-retina", "tight junction", "zonula occludens", "capillary endothelium"],
            "not": ["neovascular"],
            "default_cap": "İmmünfloresan & Şema: İç ve Dış Kan-Retina Bariyerleri (Zonula Occludens Kompleksi)"
        },
        {
            "code": "1.2.3",
            "terms": ["phagocytosis", "melanosome", "lipofuscin", "rpe65", "rpe metabolism"],
            "not": ["melanoma"],
            "default_cap": "Transmisyon Elektron Mikroskopisi: RPE Dış Segment Fagositozu ve Lipofusin Granülleri"
        },
        {
            "code": "1.3.1",
            "terms": ["pedigree", "autosomal", "x-linked", "inheritance", "dominant", "recessive"],
            "not": [],
            "default_cap": "Tıbbi Genetik Soy Ağacı: Kalıtsal Retina Hastalıklarında Mendeliyen Geçiş Modelleri"
        },
        {
            "code": "1.3.2",
            "terms": ["variant", "acmg", "mutation", "sequencing", "pathogenic"],
            "not": [],
            "default_cap": "Yeni Nesil Dizileme (NGS): ACMG Standartlarında Patojenik Varyant Sınıflaması"
        },

        # BÖLÜM 2: RETİNAL GÖRÜNTÜLEME VE TANI
        {
            "code": "2.1.1",
            "terms": ["spectral-domain", "sd-oct", "optical coherence tomography", "b-scan"],
            "not": ["drusen", "edema"],
            "default_cap": "SD-OKT En-Face Kesiti: Aksiyel Çözünürlük, Reflektivite Profili ve Foveal Düzlem"
        },
        {
            "code": "2.1.2",
            "terms": ["oct angiography", "octa", "superficial capillary plexus", "deep capillary plexus", "faz"],
            "not": [],
            "default_cap": "OKT Anjiyografi (OKTA): Yüzeyel/Derin Kapiller Pleksuslar ve Foveal Avasküler Zon (FAZ)"
        },
        {
            "code": "2.2.1",
            "terms": ["fluorescein angiography", "fa", "early phase", "late phase", "leakage", "pooling"],
            "not": [],
            "default_cap": "Floresein Anjiyografi (FFA): Dinamik Fazlar, Koroidal Dolum ve Patolojik Sızıntı Ayrımı"
        },
        {
            "code": "2.2.2",
            "terms": ["indocyanine green", "icga", "icg", "choroidal circulation"],
            "not": [],
            "default_cap": "İndosiyanin Yeşili Anjiyografi (ICGA): Koroidal Vasküler Dolum ve Hiper/Hiposiyanesans"
        },
        {
            "code": "2.3.1",
            "terms": ["fundus autofluorescence", "faf", "hyperautofluorescence", "hypoautofluorescence"],
            "not": [],
            "default_cap": "Fundus Otofloresans (FAF): Lipofusin Dağılımı, RPE Metabolik Canlılığı ve Atrofi Sınırları"
        },
        {
            "code": "2.3.2",
            "terms": ["ultrasound", "b-scan", "ubm", "acoustic"],
            "not": [],
            "default_cap": "B-Scan Ultrasonografi & UBM: Akustik Reflektivite, Arka Segment ve Koroid Morfolojisi"
        },
        {
            "code": "2.4.1",
            "terms": ["electroretinogram", "erg", "eog", "vep", "full-field"],
            "not": [],
            "default_cap": "ISCEV Standart Elektrofizyoloji: Skotopik/Fotopik ERG Dalga Formları ve Arden Oranı"
        },
        {
            "code": "2.4.2",
            "terms": ["adaptive optics", "multimodal", "composite", "imaging"],
            "not": [],
            "default_cap": "Adaptif Optik (AO) & Multimodal Görüntüleme: Tek Koni Hücresi Düzeyinde Çözünürlük"
        },

        # BÖLÜM 3: RETİNAL VASKÜLER HASTALIKLAR
        {
            "code": "3.1.1",
            "terms": ["nonproliferative diabetic", "npdr", "microaneurysm", "hard exudate", "cotton wool"],
            "not": ["proliferative"],
            "default_cap": "Renkli Fundus Fotoğrafı: Nonproliferatif Diyabetik Retinopati (NPDR) ve 4-2-1 Kuralı Bulguları"
        },
        {
            "code": "3.1.2",
            "terms": ["diabetic macular edema", "dme", "cystoid macular edema"],
            "not": [],
            "default_cap": "SD-OKT & FFA: Fovea Tutulumlu Diyabetik Makula Ödemi (DMÖ) ve Kistoid Sıvı Birikimi"
        },
        {
            "code": "3.1.3",
            "terms": ["proliferative diabetic retinopathy", "pdr", "nvd", "nve", "prp"],
            "not": [],
            "default_cap": "Ultra-Geniş Açılı FFA: Proliferatif Diyabetik Retinopati (PDR), Disk Neovaskülarizasyonu (NVD) ve PRP"
        },
        {
            "code": "3.2.1",
            "terms": ["branch retinal vein occlusion", "brvo"],
            "not": ["crvo"],
            "default_cap": "Renkli Fundus & FFA: Dal Retinal Ven Tıkanıklığı (BRVO), Sektöryel Kanamalar ve İskemi"
        },
        {
            "code": "3.2.2",
            "terms": ["central retinal vein occlusion", "crvo"],
            "not": ["brvo"],
            "default_cap": "Renkli Fundus: Santral Retinal Ven Tıkanıklığı (CRVO), Kan Fırtınası Manzarası ve Venöz Dolgunluk"
        },
        {
            "code": "3.3.1",
            "terms": ["central retinal artery occlusion", "crao", "cherry-red spot", "brao"],
            "not": [],
            "default_cap": "Renkli Fundus: Santral Retinal Arter Tıkanıklığı (CRAO) ve Patognomonik Kiraz Kırmızısı Nokta"
        },
        {
            "code": "3.3.2",
            "terms": ["macroaneurysm", "ram"],
            "not": [],
            "default_cap": "Multimodal Görüntüleme: Retinal Arteriyel Makroanevrizma (RAM) ve Çok Katmanlı Kanamalar"
        },
        {
            "code": "3.4.1",
            "terms": ["ocular ischemic syndrome", "ois", "carotid"],
            "not": [],
            "default_cap": "Fundus & FFA: Oküler İskemik Sendrom (OIS), Orta Perifer Dot Kanamalar ve Gecikmiş Koroid Dolumu"
        },
        {
            "code": "3.4.2",
            "terms": ["coats disease", "eales disease", "telangiectasia"],
            "not": [],
            "default_cap": "Renkli Fundus & FFA: Coats Hastalığı, Anevrizmatik Damar Ektazileri ve Masif Lipid Eksüdasyonu"
        },
        {
            "code": "3.4.3",
            "terms": ["macular telangiectasia", "mactel"],
            "not": [],
            "default_cap": "SD-OKT & Mavi Işık: Makuler Telenjiektazi Tip 2 (MacTel 2) ve Temporal Kavitasyonlar"
        },
        {
            "code": "3.4.4",
            "terms": ["sickle cell", "sea fan"],
            "not": [],
            "default_cap": "Floresein Anjiyografi: Orak Hücreli Retinopati ve Periferik Deniz Yelpazesi (Sea Fan) Neovaskülarizasyonu"
        },

        # BÖLÜM 4: MAKULA VE YBMD
        {
            "code": "4.1.1",
            "terms": ["drusen", "geographic atrophy", "basal laminar drusen", "subretinal drusenoid"],
            "not": ["neovascular", "polypoidal"],
            "default_cap": "Renkli Fundus & SD-OKT: Kuru Tip YBMD, Konfluan Yumuşak Drusen ve Coğrafik Atrofi Sınırları"
        },
        {
            "code": "4.1.2",
            "terms": ["choroidal neovascularization", "cnv", "mnv", "type 1", "type 2"],
            "not": ["polypoidal"],
            "default_cap": "SD-OKT & OKTA: Yaş Tip YBMD, Tip 1/Tip 2 Makuler Neovaskülarizasyon (MNV) ve Subretinal Sıvı"
        },
        {
            "code": "4.1.3",
            "terms": ["polypoidal choroidal vasculopathy", "pcv", "retinal angiomatous proliferation", "rap"],
            "not": [],
            "default_cap": "ICGA & SD-OKT: Polipoidal Koroidal Vaskülopati (PCV) Polipoid Lezyonları ve Dallanan Vasküler Ağ"
        },
        {
            "code": "4.2.1",
            "terms": ["central serous", "cscr", "serous retinal detachment"],
            "not": [],
            "default_cap": "SD-OKT & FFA: Santral Seröz Koryoretinopati (SSKR), Nörosensoryal Dekolman ve Baca Sızıntısı"
        },
        {
            "code": "4.2.2",
            "terms": ["pachychoroid", "pachyvessel", "pachydrusen"],
            "not": [],
            "default_cap": "EDI-OKT Kesiti: Pakikoroid Spektrumu, Pakidamar Genişlemesi ve Koryokapillaris İncelsi"
        },
        {
            "code": "4.3.1",
            "terms": ["macular hole", "ftmh", "operculum"],
            "not": [],
            "default_cap": "Yüksek Çözünürlüklü SD-OKT: Evre 4 Tam Kat Makula Deliği (FTMH), Operkulum ve Kistoid Kenarlar"
        },
        {
            "code": "4.3.2",
            "terms": ["epiretinal membrane", "erm", "macular pucker", "vitreomacular traction", "vmt"],
            "not": [],
            "default_cap": "SD-OKT B-Scan: Epiretinal Membran (ERM), Makuler Kırışıklık (Pucker) ve Vitreomaküler Traksiyon"
        },
        {
            "code": "4.4.1",
            "terms": ["myopia", "pathologic myopia", "staphyloma", "lacquer cracks", "fuchs"],
            "not": [],
            "default_cap": "Renkli Fundus & OKT: Patolojik Miyopi, Arka Stafilom, Vernik Çatlakları (Lacquer Cracks) ve Fuchs Lekesi"
        },
        {
            "code": "4.4.2",
            "terms": ["angioid streaks", "pseudoxanthoma elasticum"],
            "not": [],
            "default_cap": "Renkli Fundus & FAF: Anjiyoid Çizgiler (Bruch Membran Yırtıkları) ve Portakal Kabuğu (Peau d'Orange)"
        },

        # BÖLÜM 5: RETİNA DEKOLMANI VE PERİFER
        {
            "code": "5.1.1",
            "terms": ["posterior vitreous detachment", "pvd", "retinal tear", "horseshoe"],
            "not": [],
            "default_cap": "SD-OKT & Fundus: Arka Vitreus Dekolmanı (PVD), Weiss Halkası ve Çekintili At Nalı Yırtık"
        },
        {
            "code": "5.1.2",
            "terms": ["rhegmatogenous retinal detachment", "rrd", "lincoff"],
            "not": [],
            "default_cap": "Ultra-Geniş Açılı Fundus: Yırtıklı Retina Dekolmanı (RRD), Subretinal Sıvı ve Lincoff Kuralları"
        },
        {
            "code": "5.1.3",
            "terms": ["tractional retinal detachment", "trd", "exudative retinal detachment"],
            "not": [],
            "default_cap": "B-Scan USG & Fundus: Fibrovasküler Membrana Bağlı Traksiyonel Retina Dekolmanı (TRD)"
        },
        {
            "code": "5.2.1",
            "terms": ["lattice degeneration", "snail track", "cobblestone"],
            "not": [],
            "default_cap": "Periferik Retina İncelemesi: Kafes (Lattice) Dejenerasyonu, Skleroze Damarlar ve Atrofik Delikler"
        },
        {
            "code": "5.2.2",
            "terms": ["proliferative vitreoretinopathy", "pvr", "star fold"],
            "not": [],
            "default_cap": "Cerrahi & Fundus Görünümü: Proliferatif Vitreoretinopati (PVR Evre C), Yıldız Kıvrımları (Star Folds)"
        },
        {
            "code": "5.3.1",
            "terms": ["scleral buckle", "pneumatic retinopexy", "vitrectomy"],
            "not": [],
            "default_cap": "Vitreoretinal Cerrahi: 25G Pars Plana Vitrektomi ve Skleral Çökertme (Buckle) İntraoperatif Alanı"
        },
        {
            "code": "5.3.2",
            "terms": ["silicone oil", "gas tamponade", "c3f8", "sf6"],
            "not": [],
            "default_cap": "Postoperatif SD-OKT: Göz İçi Silikon Yağı Menisküsü ve İntravitreal Gaz Tamponadı Dinamiği"
        },

        # BÖLÜM 6: KALITSAL DİSTROFİLER
        {
            "code": "6.1.1",
            "terms": ["retinitis pigmentosa", "bone spicule", "waxy disc"],
            "not": [],
            "default_cap": "Ultra-Geniş Açılı Fundus: Retinitis Pigmentosa (RP) Kemik Spikülü Pigmentasyonları ve Mumsu Solukluk"
        },
        {
            "code": "6.1.2",
            "terms": ["stargardt", "flavimaculatus", "dark choroid", "abca4"],
            "not": ["best"],
            "default_cap": "Renkli Fundus & FAF: Stargardt Hastalığı (ABCA4), Balıksı Sarı Benekler ve FFA Sessiz Koroid"
        },
        {
            "code": "6.1.3",
            "terms": ["best disease", "vitelliform", "egg yolk", "bestrophin"],
            "not": ["stargardt"],
            "default_cap": "Renkli Fundus & FAF: Best Vitelliform Makula Distrofisi (Evre 2 Yumurta Sarısı Lezyonu)"
        },
        {
            "code": "6.1.4",
            "terms": ["cone-rod dystrophy", "cone dystrophy", "bull's eye"],
            "not": [],
            "default_cap": "Fundus & FAF: Koni-Rod Distrofisi, Boğa Gözü (Bull's Eye) Makulopatisi ve Fotopik Yanıt Kaybı"
        },
        {
            "code": "6.1.5",
            "terms": ["leber congenital amaurosis", "lca", "rpe65"],
            "not": [],
            "default_cap": "Multimodal Görüntüleme: Leber Konjenital Amarozu (LCA) ve RPE65 Gen Tedavisi Hedef Alanı"
        },
        {
            "code": "6.2.1",
            "terms": ["retinoschisis", "xlrs", "spoke-wheel"],
            "not": [],
            "default_cap": "SD-OKT & Renkli Fundus: X-Bağlantılı Retinoşizis (XLRS), Foveal Tekerlek Parmaklığı (Spoke-Wheel)"
        },
        {
            "code": "6.2.2",
            "terms": ["choroideremia", "chm", "gyrate atrophy"],
            "not": [],
            "default_cap": "Geniş Açılı FAF: Koroideremi ve Jirat Atrofi, Midperiferik Koroid/RPE Atrofi Adacıkları"
        },
        {
            "code": "6.2.3",
            "terms": ["stickler", "fevr", "vitreoretinopathy"],
            "not": [],
            "default_cap": "Klinik Fundus: Stickler Sendromu Optik Boş Vitreus ve Ailesel Eksüdatif Vitreoretinopati (FEVR)"
        },

        # BÖLÜM 7: ENFEKSİYÖZ VE İNFLAMATUAR HASTALIKLAR
        {
            "code": "7.1.1",
            "terms": ["toxoplasmosis", "toxoplasmic", "headlight in fog"],
            "not": [],
            "default_cap": "Renkli Fundus: Oküler Toksoplazmoz, Pigmente Skar Kenarında Aktif Siste Araba Farı (Headlight in Fog)"
        },
        {
            "code": "7.1.2",
            "terms": ["cmv retinitis", "cytomegalovirus"],
            "not": ["arn"],
            "default_cap": "Renkli Fundus: Sitomegalovirüs (CMV) Retiniti, Vasküler Yayılımlı Kanamalı Nekroz (Pizza-Pie Paterni)"
        },
        {
            "code": "7.1.3",
            "terms": ["acute retinal necrosis", "arn", "progressive outer retinal necrosis", "porn"],
            "not": ["cmv"],
            "default_cap": "Ultra-Geniş Açılı Fundus: Akut Retinal Nekroz (ARN), Çevresel Nekroz Odakları ve Vaskülit"
        },
        {
            "code": "7.1.4",
            "terms": ["tuberculosis", "syphilis", "serpiginous-like"],
            "not": [],
            "default_cap": "Multimodal Görüntüleme: Oküler Tüberküloz ve Sifilitik Plakoid Koryoretinit Bulguları"
        },
        {
            "code": "7.1.5",
            "terms": ["endophthalmitis", "vitreous tap", "hypopyon"],
            "not": [],
            "default_cap": "Ön Segment & B-Scan USG: Akut Postoperatif Endoftalmi, Hipopiyon ve Yoğun Vitrit Membranları"
        },
        {
            "code": "7.2.1",
            "terms": ["vogt-koyanagi", "vkh", "sympathetic ophthalmia", "dalen-fuchs"],
            "not": [],
            "default_cap": "SD-OKT & FFA: Vogt-Koyanagi-Harada (VKH) Hastalığı, Çok Odaklı Seröz Dekolman ve Dalen-Fuchs Nodülleri"
        },
        {
            "code": "7.2.2",
            "terms": ["mewds", "apmppe", "birdshot", "serpiginous choroiditis", "multifocal choroiditis"],
            "not": [],
            "default_cap": "FAF & İndosiyanin Yeşili: Beyaz Nokta Sendromları (MEWDS/APMPPE/Birdshot) Hipofloresan Plakları"
        },
        {
            "code": "7.2.3",
            "terms": ["behcet", "sarcoidosis", "candle wax", "occlusive vasculitis"],
            "not": [],
            "default_cap": "FFA İncelemesi: Behçet Hastalığı Oklüzif Retinal Vasküliti ve Sarkoidoz Mum Damlası Eksüdaları"
        },

        # BÖLÜM 8: RETİNA VE KOROYİD TÜMÖRLERİ
        {
            "code": "8.1.1",
            "terms": ["choroidal nevus", "tfsom", "drusen on nevus"],
            "not": ["melanoma"],
            "default_cap": "Renkli Fundus & FAF: Koroid Nevüsü, Yüzeyel Drusenler ve TFSOM-UHHD Malign Dönüşüm Riski"
        },
        {
            "code": "8.1.2",
            "terms": ["choroidal melanoma", "malignant melanoma", "mushroom", "acoustic hollowness"],
            "not": ["hemangioma", "nevus"],
            "default_cap": "B-Scan USG & Fundus: Koroid Malign Melanomu, Mantar (Mushroom) Biçimli Kitle ve Akustik Boşluk"
        },
        {
            "code": "8.1.3",
            "terms": ["choroidal hemangioma", "choroidal osteoma"],
            "not": ["melanoma"],
            "default_cap": "Renkli Fundus & B-Scan USG: Sınırlı Koroid Hemanjiomu ve Kalsifiye Koroid Osteomu"
        },
        {
            "code": "8.2.1",
            "terms": ["hemangioblastoma", "von hippel", "vhl", "astrocytoma"],
            "not": [],
            "default_cap": "Renkli Fundus & FFA: Retinal Kılcal Hemanjiyoblastom (Von Hippel-Lindau) Besleyici Damarları"
        },
        {
            "code": "8.2.2",
            "terms": ["retinoblastoma", "leukocoria", "flexner"],
            "not": [],
            "default_cap": "Göz Dibi & B-Scan USG: Retinoblastom (RB), Endofitik/Ekzofitik Kitle ve İntratümöral Kalsifikasyon"
        },
        {
            "code": "8.2.3",
            "terms": ["lymphoma", "metastasis", "piol"],
            "not": [],
            "default_cap": "SD-OKT & Renkli Fundus: Primer İntraoküler Lenfoma (PIOL) Sub-RPE İnfiltratları ve Koroid Metastazı"
        },

        # BÖLÜM 9: TRAVMA, FARMAKOTERAPİ VE YZ
        {
            "code": "9.1.1",
            "terms": ["commotio", "berlin", "choroidal rupture"],
            "not": [],
            "default_cap": "SD-OKT & Renkli Fundus: Künt Travmaya Bağlı Commotio Retinae (Berlin Ödemi) ve Hilal Şekilli Koroid Rüptürü"
        },
        {
            "code": "9.1.2",
            "terms": ["foreign body", "iofb", "siderosis"],
            "not": [],
            "default_cap": "Renkli Fundus & BT: Delici Yaralanma Sonrası Göz İçi Yabancı Cisim (İOYC) ve Siderozis Bulbi"
        },
        {
            "code": "9.2.1",
            "terms": ["anti-vegf", "aflibercept", "ranibizumab", "faricimab", "bevacizumab"],
            "not": [],
            "default_cap": "Farmakokinetik Grafik & OKT: Anti-VEGF Moleküler Yapıları (Aflibercept/Faricimab) ve Sıvı Regresyonu"
        },
        {
            "code": "9.2.2",
            "terms": ["dexamethasone", "ozurdex", "fluocinolone", "steroid implant"],
            "not": [],
            "default_cap": "İntraoperatif & SD-OKT: Vitreus İçi Deksametazon İmplantı (Ozurdex) ve Uzamış Salımlı Steroid Etkisi"
        },
        {
            "code": "9.3.1",
            "terms": ["gene therapy", "subretinal", "delivery", "vector", "surgical", "luxturna", "port"],
            "not": [],
            "default_cap": "Cerrahi & Farmakoterapi: Subretinal Gen Tedavisi Uygulama Alanı ve Port Delivery Sistemi (PDS)"
        },
        {
            "code": "9.3.2",
            "terms": ["artificial intelligence", "deep learning", "screening", "telemedicine", "automated", "algorithm"],
            "not": [],
            "default_cap": "Yapay Zeka ve Teleoftalmoloji: Otonom Tarama Algoritmaları ve DR Lezyon Isı Haritası (Heatmap)"
        },

        # BÖLÜM 10: MASTER MATRİS VE VAKA BANKASI
        {
            "code": "10.1",
            "terms": ["matrix", "multimodal", "comparison", "summary", "retinal"],
            "not": [],
            "default_cap": "Multimodal Tanı Matrisi: Vasküler, Makuler ve İnflamatuar Antite Biyobelirteç Korelasyonu"
        },
        {
            "code": "10.2",
            "terms": ["biostatistics", "gee", "icc", "mixed-effects", "correlation"],
            "not": [],
            "default_cap": "Medikal İstatistik Akış Şeması: Göz Düzeyi (Eye-Level) ve Hasta Düzeyi (Patient-Level) Analiz Mimarisi"
        },
        {
            "code": "10.3",
            "terms": ["case", "fundus", "oct", "patient", "retinal"],
            "not": [],
            "default_cap": "Uzmanlık Board Vakası: Multimodal Görüntüleme Eşliğinde Ayırıcı Tanı ve Tedavi Protokolü"
        }
    ]

    registry: Dict[str, List[Dict[str, Any]]] = {}
    used_paths = set()

    print("\n>>> 2. Hassas Eşleştirme ve Altyazı Atamaları Yapılıyor...")

    for r in RULES:
        code = r["code"]
        terms = r["terms"]
        not_terms = r["not"]
        default_cap = r["default_cap"]

        scored = []
        for cand in vetted_imgs:
            # Do not reserve a figure globally: reuse is preferable to a wrong match.

            txt = cand["search_blob"]
            if any(nt in txt for nt in not_terms):
                continue

            score = 0
            for t in terms:
                if t in txt:
                    score += 5 if len(t) > 6 else 3

            if score > 0:
                scored.append((score, cand))

        scored.sort(key=lambda x: -x[0])

        # En yüksek puanlı 8-12 görseli al
        chosen = []
        for score, cand in scored[:12]:
            used_paths.add(cand["path"])
            chosen.append({
                "path": cand["path"],
                "filename": cand["filename"],
                "book": cand["book"],
                "caption": cand["caption"],
                "suggested_topic_caption": default_cap,
                "review_status": "review_required",
                "original_caption": cand["caption"],
                "score": score
            })

        registry[code] = chosen
        print(f"Kural {code:<6}: {len(chosen)} adet doğrulanmış görsel eşleşti.")

    # Kaydet
    output_data = {
        "title": "Retina Görsel Adayları — Panel İncelemesi Gerektirir",
        "total_rules": len(registry),
        "registry": registry
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print(f"\n>>> Başarıyla tamamlandı: {OUTPUT_PATH}")


if __name__ == "__main__":
    build_registry()
