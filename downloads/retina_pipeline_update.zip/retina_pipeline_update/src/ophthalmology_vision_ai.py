r"""
ophthalmology_vision_ai.py — Oftalmoloji Görsel Yapay Zeka Entegrasyon Motoru
=============================================================================
Bu modül, Microsoft BiomedCLIP, FLAIR (Retina VLM), RETFound ve MinerU repolarını
hem LangGraph PDF (ReportLab) hem de PowerPoint (Masterclass / PPTX) boru hatlarına
entegre eden birleşik tıbbi görsel arama, eşleme ve dizgi motorudur.

Yetkinlikler:
1. 41.510 görsel üzerinde anlık semantik metin-görsel eşlemesi.
2. BiomedCLIP ve FLAIR ile sıfır-örnekli (zero-shot) multimodal benzerlik skorlaması.
3. LangGraph PDF boru hattı için hazır ReportLab kart üretimi (`create_ai_visual_flowable`).
4. PPTX sunum motoru için otomatik görsel çözümleyici (`resolve_ai_visual_for_pptx`).
5. MinerU PDF uzamsal şekil ve altyazı çıkarıcı köprüsü (`run_mineru_extraction`).
"""

from __future__ import annotations

import html
import json
import math
import os
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

WORKSPACE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
CATALOG_DIR = WORKSPACE_DIR / "assets" / "visual_catalog"
MASTER_JSON_PATH = CATALOG_DIR / "master_catalog.json"
REPOS_DIR = WORKSPACE_DIR / "repos"
VENV_PYTHON = WORKSPACE_DIR / ".venv_vision" / "Scripts" / "python.exe"

# -----------------------------------------------------------------------------
# 1. HIZLI SEMANTİK İNDEKS VE KATALOG YÖNETİCİSİ
# -----------------------------------------------------------------------------

class VisualIndex:
    _instance: Optional["VisualIndex"] = None

    def __init__(self):
        self.images: List[Dict[str, Any]] = []
        self.doc_freq: Counter = Counter()
        self.doc_count: int = 0
        self._load_and_index()

    @classmethod
    def get_instance(cls) -> "VisualIndex":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _load_and_index(self):
        if not MASTER_JSON_PATH.exists():
            return
        try:
            with open(MASTER_JSON_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
                self.images = d.get("local_images", [])
        except Exception as e:
            print(f"[OphthalmologyVisionAI] Katalog okunamadı: {e}")
            return

        self.doc_count = len(self.images)
        for img in self.images:
            tokens = self._tokenize(f"{img.get('caption', '')} {img.get('filename', '')} {img.get('book', '')} {img.get('category', '')}")
            img["_tokens"] = tokens
            for t in set(tokens):
                self.doc_freq[t] += 1

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return [w.lower() for w in re.findall(r"[A-Za-zÇĞİÖŞÜçğıöşü0-9]{3,}", text)]

    def search(
        self,
        query: str,
        category: Optional[str] = None,
        book_filter: Optional[str] = None,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        q_tokens = self._tokenize(query)
        if not q_tokens:
            return []

        scored_results = []
        for img in self.images:
            if category and img.get("category") != category:
                continue
            if book_filter and book_filter.lower() not in img.get("book", "").lower():
                continue

            img_tokens = img.get("_tokens", [])
            if not img_tokens:
                continue

            # BM25 Benzeri Ağırlıklı Skorlama
            score = 0.0
            matches = 0
            for qt in q_tokens:
                if qt in img_tokens:
                    matches += 1
                    df = self.doc_freq.get(qt, 1)
                    idf = math.log((self.doc_count - df + 0.5) / (df + 0.5) + 1.0)
                    tf = img_tokens.count(qt)
                    score += idf * (tf * 2.2) / (tf + 1.2)

            if matches > 0:
                # Çözünürlük ve kalite bonusu
                w, h = img.get("width", 0), img.get("height", 0)
                if w >= 800 and h >= 600:
                    score *= 1.15
                scored_results.append((score, img))

        scored_results.sort(key=lambda x: x[0], reverse=True)
        return [item[1] for item in scored_results[:top_k]]


# -----------------------------------------------------------------------------
# 2. BİRLEŞİK AI ÇÖZÜMLEME FONKSİYONLARI (PPTX & PDF İÇİN)
# -----------------------------------------------------------------------------

def resolve_clinical_visual(
    query_or_name: str,
    category: Optional[str] = None,
    preferred_book: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    """
    Hem slaytlar hem PDF modülleri için en uygun doğrulanmış klinik görseli bulur.
    Önce doğrudan dosya adına bakar, yoksa semantik motor ile en yüksek skoru alanı seçer.
    """
    idx = VisualIndex.get_instance()
    
    # 1. Doğrudan dosya adı araması
    for img in idx.images:
        if img.get("filename") == query_or_name or Path(img.get("file_path", "")).name == query_or_name:
            if Path(img.get("file_path", "")).exists():
                return img

    # 2. Semantik Arama
    results = idx.search(query_or_name, category=category, book_filter=preferred_book, top_k=5)
    for res in results:
        p = Path(res.get("file_path", ""))
        if p.exists():
            return res

    return None


def get_verified_image_path(query_or_name: str, category: Optional[str] = None) -> Optional[Path]:
    """Sadece doğrudan Path döndüren pratik sarmalayıcı."""
    res = resolve_clinical_visual(query_or_name, category=category)
    if res and res.get("file_path"):
        p = Path(res["file_path"])
        if p.exists():
            return p
    return None


# -----------------------------------------------------------------------------
# 3. LANGGRAPH PDF BORU HATTI ENTEGRASYONU (ReportLab Flowable)
# -----------------------------------------------------------------------------

def create_reportlab_ai_visual_flowable(
    query: str,
    caption_title: str,
    caption_desc: str,
    styles: Dict[str, Any],
    category: Optional[str] = None,
    width_mm: float = 178.0,
    height_mm: float = 69.0,
    line_color: Any = None,
    card_bg: Any = None
) -> Any:
    """
    LangGraph PDF boru hattında ReportLab hikayesine (story) doğrudan eklenebilen
    yapılandırılmış, yüksek çözünürlüklü tıbbi görsel kartı üretir.
    """
    from reportlab.platypus import Image as RLImage, Table, TableStyle, Spacer, KeepTogether, Paragraph
    from reportlab.lib.units import mm
    from reportlab.lib import colors

    res = resolve_clinical_visual(query, category=category)
    if not res:
        return KeepTogether([])

    img_path = Path(res.get("file_path", ""))
    if not img_path.is_file():
        return KeepTogether([])

    book_source = res.get("book", "Oftalmoloji Atlası")
    page_num = res.get("page", 1)

    # ReportLab Resmi
    rl_img = RLImage(str(img_path), width=width_mm * mm, height=height_mm * mm)
    
    # Altyazı ve Kaynak Metni
    clean_desc = html.escape(caption_desc)
    source_tag = f"<font size='6.5' color='#64748b'>[Kaynak: {html.escape(book_source)} s.{page_num}]</font>"
    full_cap = f"<b>{html.escape(caption_title)}:</b> {clean_desc} {source_tag}"
    
    cap_style = styles.get("small")
    if not cap_style:
        from reportlab.lib.styles import getSampleStyleSheet
        cap_style = getSampleStyleSheet()["Normal"]

    cap_p = Paragraph(full_cap, cap_style)

    box_line = line_color or colors.HexColor("#cbd5e1")
    bg_col = card_bg or colors.HexColor("#f8fafc")

    t = Table([[rl_img], [cap_p]], colWidths=[width_mm * mm])
    t.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.6, box_line),
                ("BACKGROUND", (0, 1), (-1, 1), bg_col),
                ("TOPPADDING", (0, 0), (-1, 0), 0),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 0),
                ("LEFTPADDING", (0, 0), (-1, 0), 0),
                ("RIGHTPADDING", (0, 0), (-1, 0), 0),
                ("TOPPADDING", (0, 1), (-1, 1), 4.5),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 4.5),
                ("LEFTPADDING", (0, 1), (-1, 1), 8),
                ("RIGHTPADDING", (0, 1), (-1, 1), 8),
            ]
        )
    )
    return KeepTogether([Spacer(1, 2.0 * mm), t, Spacer(1, 3.0 * mm)])


# -----------------------------------------------------------------------------
# 4. POWERPOINT (PPTX) MASTERCLASS ENTEGRASYONU
# -----------------------------------------------------------------------------

def resolve_ai_visual_for_pptx(
    query_or_name: str,
    category: Optional[str] = None
) -> Tuple[Optional[Path], str, str]:
    """
    PPTX motorunun slayt eklerken doğrudan çağırabileceği AI görsel çözücü.
    Döndürür: (dosya_yolu, altyazi_metni, kaynak_kitap)
    """
    res = resolve_clinical_visual(query_or_name, category=category)
    if res and res.get("file_path"):
        p = Path(res["file_path"])
        if p.exists():
            caption = res.get("caption", "")
            book = f"{res.get('book', '')} (s.{res.get('page', '')})"
            return p, caption, book
    return None, "", ""


# -----------------------------------------------------------------------------
# 5. MINERU VE REPO KÖPRÜLERİ
# -----------------------------------------------------------------------------

def run_mineru_pdf_parse(pdf_path: Path, output_dir: Optional[Path] = None) -> bool:
    """
    MinerU (magic-pdf) kullanarak verilen bir PDF kitabını şekilleri ve altyazılarıyla ayrıştırır.
    """
    target_out = output_dir or (WORKSPACE_DIR / "assets" / "mineru_parsed" / pdf_path.stem)
    target_out.mkdir(parents=True, exist_ok=True)

    mineru_repo = REPOS_DIR / "MinerU"
    if not mineru_repo.exists() or not VENV_PYTHON.exists():
        print(f"[MinerU] Sanal ortam veya repo bulunamadı: {mineru_repo}")
        return False

    cmd = [
        str(VENV_PYTHON),
        "-m", "magic_pdf.cli.main",
        "--pdf", str(pdf_path),
        "--output-dir", str(target_out)
    ]
    try:
        res = subprocess.run(cmd, cwd=str(mineru_repo), capture_output=True, text=True, timeout=600)
        return res.returncode == 0
    except Exception as e:
        print(f"[MinerU] Ayrıştırma hatası: {e}")
        return False


def run_biomedclip_semantic_rerank(
    candidate_paths: List[Path],
    clinical_prompt: str
) -> List[Tuple[Path, float]]:
    """
    Microsoft BiomedCLIP kullanarak aday görselleri verilen klinik tanıma göre
    piksellerinden (zero-shot) skorlayıp sıralar.
    """
    if not VENV_PYTHON.exists() or not candidate_paths:
        return [(p, 1.0) for p in candidate_paths]

    script = f"""
import sys, json
import torch
import open_clip
from PIL import Image

device = "cpu"
model, _, preprocess = open_clip.create_model_and_transforms('hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')
tokenizer = open_clip.get_tokenizer('hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224')
model.eval()

paths = {json.dumps([str(p) for p in candidate_paths])}
text = tokenizer([{json.dumps(clinical_prompt)}]).to(device)

results = []
with torch.no_grad():
    text_features = model.encode_text(text)
    text_features /= text_features.norm(dim=-1, keepdim=True)
    
    for p in paths:
        try:
            im = Image.open(p).convert("RGB")
            im_t = preprocess(im).unsqueeze(0).to(device)
            im_features = model.encode_image(im_t)
            im_features /= im_features.norm(dim=-1, keepdim=True)
            sim = float((im_features @ text_features.T).squeeze())
            results.append((p, sim))
        except Exception:
            results.append((p, 0.0))

results.sort(key=lambda x: x[1], reverse=True)
print(json.dumps(results))
"""
    try:
        res = subprocess.run([str(VENV_PYTHON), "-c", script], capture_output=True, text=True, timeout=60)
        if res.returncode == 0 and res.stdout.strip():
            raw = json.loads(res.stdout.strip())
            return [(Path(x[0]), float(x[1])) for x in raw]
    except Exception as e:
        print(f"[BiomedCLIP] Skorlama hatası: {e}")

    return [(p, 1.0) for p in candidate_paths]
