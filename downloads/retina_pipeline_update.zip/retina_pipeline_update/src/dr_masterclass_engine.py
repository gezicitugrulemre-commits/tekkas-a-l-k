"""
dr_masterclass_engine.py — 282 Slaytlık İleri Düzey Oftalmoloji Masterclass Motoru
Kişisel Çalışma Odaklı 16:9 Geniş Ekran, Yüksek Çözünürlüklü Görsel Atlas ve Denetleyici.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from PIL import Image

# pptx_publisher palet ve temel özelliklerini içe aktar
from pptx_publisher import PPTXPalette, PPTXStudyPublisher

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
ASSETS_DIR = BASE_DIR / "assets"
IMG_CATALOG_DIR = ASSETS_DIR / "visual_catalog" / "images"
ATLAS_OCT_DIR = IMG_CATALOG_DIR / "Atlas_of_Retinal_OCT"
BCSC_12_DIR = IMG_CATALOG_DIR / "12-Retina_and_Vitreous_2025-2026"
RYAN_3_DIR = IMG_CATALOG_DIR / "RYAN_S_RETINA_7th_Ed__Vol_3"
RYAN_2_DIR = IMG_CATALOG_DIR / "RYAN_S_RETINA_7th_Ed__Vol_2"
RYAN_1_DIR = IMG_CATALOG_DIR / "RYAN_S_RETINA_7th_Ed__Vo_1"
WILLS_RETINA_DIR = IMG_CATALOG_DIR / "Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Retina_2__3_"
WILLS_GLAUCOMA_DIR = IMG_CATALOG_DIR / "Color_Atlas___Synopsis_of_Clinical_Ophthalmology_Wills_Eye_Institute_Glaucoma_2"
BCSC_10_DIR = IMG_CATALOG_DIR / "10-Glaucoma_2025-2026"
DIAG_RETINA_DIR = IMG_CATALOG_DIR / "Diagnostics_in_Ocular_Imaging_Cornea__Retina__Glaucoma_and_Orbit"
CACHE_DIR = ASSETS_DIR / "cached_images"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

SEARCH_DIRS = [
    ASSETS_DIR,
    ATLAS_OCT_DIR,
    BCSC_12_DIR,
    BCSC_10_DIR,
    RYAN_3_DIR,
    RYAN_2_DIR,
    RYAN_1_DIR,
    WILLS_RETINA_DIR,
    WILLS_GLAUCOMA_DIR,
    DIAG_RETINA_DIR
]

SCHEMA_MAP = {
    "dr_schema_0": "dr_schema_0_epi_metabolic.png",
    "dr_schema_1": "dr_schema_1_pathogenesis.png",
    "dr_schema_2": "dr_schema_2_oct_octa.png",
    "dr_schema_3": "dr_schema_3_dmo_algorithm.png",
    "dr_schema_4": "dr_schema_4_subliminal_laser.png",
    "dr_schema_5": "dr_schema_5_trd_surgery.png",
    "dr_schema_6": "dr_schema_6_steroid_switch.png",
    "dr_schema_7": "dr_schema_7_nextgen_2026.png",
    "dr_schema_8": "dr_schema_8_biostat_gee.png",
    "dr_panel_0": "dr_panel_dme_brb_oct.png",
    "dr_panel_1": "dr_panel_dme_ci_nci_prp.png",
    "dr_panel_2": "dr_panel_etdrs_421_uwfa.png",
    "dr_panel_3": "dr_panel_hr_pdr_nvd_nve.png",
    "dr_panel_4": "dr_panel_laser_trd.png",
    "dr_panel_5": "dr_panel_octa_faz_dril.png",
    "dr_panel_6": "dr_panel_oct_dril_vmt.png",
    "dr_panel_7": "dr_panel_stage_fa.png",
    "dr_panel_8": "dr_panel_trd_surgery_db.png"
}


def resolve_verified_image(src: Path | str) -> Optional[Path]:
    """Herhangi bir görsel yolunu veya adını yerel diskteki gerçek dosyaya eşler."""
    p = Path(src)
    if p.exists():
        return p
    name = p.name.lower()
    stem = p.stem.lower()

    # 1. Doğrudan arama klasörlerinde tam ad kontrolü
    for d in SEARCH_DIRS:
        if (d / p.name).exists():
            return d / p.name

    # 2. Şema ön eki haritası kontrolü
    for k, v in SCHEMA_MAP.items():
        if k in stem:
            cand = ASSETS_DIR / v
            if cand.exists():
                return cand

    # 3. Klasörler içinde büyük/küçük harf veya uzantı esnek araması
    for d in SEARCH_DIRS:
        if d.exists():
            for f in os.listdir(d):
                if f.lower() == name or Path(f).stem.lower() == stem:
                    return d / f

    # 4. Kısmi alt dize araması
    for f in os.listdir(ASSETS_DIR):
        if stem in f.lower() or f.lower().startswith(stem[:8]):
            return ASSETS_DIR / f

    # 4b. Görsel kataloğu içinde tam ad araması (tüm alt klasörler)
    deep_matches = list(IMG_CATALOG_DIR.glob(f"**/{p.name}"))
    if deep_matches and deep_matches[0].exists():
        return deep_matches[0]

    # 4c. AI Vision Engine ile semantik oftalmoloji görsel eşlemesi (BiomedCLIP / FLAIR kataloğu)
    try:
        from ophthalmology_vision_ai import get_verified_image_path
        ai_match = get_verified_image_path(str(src))
        if ai_match and ai_match.exists():
            return ai_match
    except Exception:
        pass

    # 5. Yedek güvenli görsel (Atlas standart DR foveal kesiti)
    fallback = ATLAS_OCT_DIR / "Atlas_of_Retinal_OCT_p098_fig168.jpeg"
    if fallback.exists():
        return fallback

    return None


def ensure_rgb_cached_image(src_path: Path | str) -> Optional[Path]:
    """CMYK veya uyumsuz formatlardaki görüntüleri RGB PNG formatına dönüştürüp önbelleğe alır."""
    resolved = resolve_verified_image(src_path)
    if not resolved or not resolved.exists():
        return None
    try:
        cached_file = CACHE_DIR / (resolved.stem + ".png")
        if not cached_file.exists():
            im = Image.open(resolved)
            if im.mode != "RGB":
                im = im.convert("RGB")
            im.save(cached_file, "PNG")
        return cached_file
    except Exception as e:
        print(f"Uyarı: Görsel önbelleklenemedi ({resolved.name}): {e}")
        return resolved


class MasterclassPublisher(PPTXStudyPublisher):
    """Kişisel çalışma odaklı 282 slaytlık masterclass için özel yerleşim metotları."""

    def add_section_header_slide(
        self,
        part_num: int,
        title: str,
        subtitle: str,
        learning_objectives: List[str],
        notes: str = ""
    ):
        """Bölüm Geçiş ve Öğrenim Hedefleri Slaytı (Koyu Lacivert / Kurumsal Tasarım)."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        
        # Tam ekran koyu arka plan
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = PPTXPalette.NAVY
        bg.line.fill.background()

        # Bölüm Rozeti
        badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), Inches(0.9), Inches(3.2), Inches(0.45))
        badge.fill.solid()
        badge.fill.fore_color.rgb = PPTXPalette.BLUE
        badge.line.fill.background()
        tf_b = badge.text_frame
        p_b = tf_b.paragraphs[0]
        p_b.text = f"BÖLÜM {part_num:02d}"
        p_b.font.name = "Arial"
        p_b.font.size = Pt(12)
        p_b.font.bold = True
        p_b.font.color.rgb = PPTXPalette.WHITE
        p_b.alignment = PP_ALIGN.CENTER

        # Bölüm Başlığı
        t_box = slide.shapes.add_textbox(Inches(1.0), Inches(1.5), Inches(11.333), Inches(1.2))
        tf_t = t_box.text_frame
        tf_t.word_wrap = True
        p_t = tf_t.paragraphs[0]
        p_t.text = title
        p_t.font.name = "Arial"
        p_t.font.size = Pt(26)
        p_t.font.bold = True
        p_t.font.color.rgb = PPTXPalette.WHITE

        # Alt Başlık
        s_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.75), Inches(11.333), Inches(0.6))
        tf_s = s_box.text_frame
        tf_s.word_wrap = True
        p_s = tf_s.paragraphs[0]
        p_s.text = subtitle
        p_s.font.name = "Arial"
        p_s.font.size = Pt(13)
        p_s.font.color.rgb = RGBColor(191, 219, 254)

        # Öğrenim Hedefleri Kartı
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), Inches(3.5), Inches(11.333), Inches(3.2))
        card.fill.solid()
        card.fill.fore_color.rgb = RGBColor(15, 33, 55)
        card.line.color.rgb = PPTXPalette.BLUE
        card.line.width = Pt(1.5)

        tf_c = card.text_frame
        tf_c.word_wrap = True
        p_ch = tf_c.paragraphs[0]
        p_ch.text = "🎯 BU BÖLÜMDE KAZANILACAK KLİNİK VE ÇALIŞMA YETKİNLİKLERİ"
        p_ch.font.name = "Arial"
        p_ch.font.size = Pt(12)
        p_ch.font.bold = True
        p_ch.font.color.rgb = RGBColor(254, 240, 138)
        p_ch.space_after = Pt(10)

        for obj in learning_objectives:
            p = tf_c.add_paragraph()
            p.text = f"✓ {obj}"
            p.font.name = "Arial"
            p.font.size = Pt(10.5)
            p.font.color.rgb = PPTXPalette.WHITE
            p.space_after = Pt(6)

        self._set_speaker_notes(slide, notes or f"Bölüm {part_num}: {title}\n{subtitle}")

    def add_visual_schema_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        image_path: Path | str,
        focal_points: List[Tuple[str, str]],
        notes: str = ""
    ):
        """
        Kişisel çalışma için optimize edilmiş görsel panel slaytı.
        Sol tarafta geniş ve yüksek çözünürlüklü şema/görsel, sağ tarafta detaylı çalışma kartları.
        Görsel asla kaybolmaz; otomatik çözücü (resolver) ile her zaman gerçek dosya yerleştirilir.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # Görsel Alanı (Sol)
        img_box_x = Inches(0.8)
        img_box_y = Inches(1.9)
        img_box_w = Inches(6.4)
        img_box_h = Inches(4.85)

        cached_img = ensure_rgb_cached_image(image_path)
        if cached_img and cached_img.exists():
            try:
                im = Image.open(cached_img)
                orig_w, orig_h = im.size
                scale = min(img_box_w / Inches(orig_w / 96.0), img_box_h / Inches(orig_h / 96.0))
                disp_w = Inches(orig_w / 96.0) * scale
                disp_h = Inches(orig_h / 96.0) * scale
                
                # Merkezle
                img_x = img_box_x + (img_box_w - disp_w) / 2
                img_y = img_box_y + (img_box_h - disp_h) / 2
                slide.shapes.add_picture(str(cached_img), img_x, img_y, width=disp_w, height=disp_h)
            except Exception as e:
                print(f"Görsel basılamadı: {e}")
        else:
            # Yedek görseli yükle
            fallback = ensure_rgb_cached_image(ATLAS_OCT_DIR / "Atlas_of_Retinal_OCT_p098_fig168.jpeg")
            if fallback and fallback.exists():
                slide.shapes.add_picture(str(fallback), img_box_x, img_box_y, width=img_box_w)

        # Sağ Panel: Klinik ve Çalışma Odak Noktaları
        right_x = Inches(7.4)
        right_w = Inches(5.133)
        num_focal = len(focal_points)
        card_h = (4.85 - ((num_focal - 1) * 0.15)) / max(num_focal, 1)

        for i, (fp_title, fp_desc) in enumerate(focal_points):
            y = img_box_y + Inches(i * (card_h + 0.15))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, right_w, Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1.2)

            # Sol Vurgu Şeridi
            badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, Inches(0.12), Inches(card_h))
            badge.fill.solid()
            badge.fill.fore_color.rgb = PPTXPalette.BLUE
            badge.line.fill.background()

            tf = slide.shapes.add_textbox(right_x + Inches(0.2), y + Inches(0.08), right_w - Inches(0.3), Inches(card_h - 0.15)).text_frame
            tf.word_wrap = True

            p1 = tf.paragraphs[0]
            p1.text = f"{i+1}. {fp_title}"
            p1.font.name = "Arial"
            p1.font.size = Pt(10)
            p1.font.bold = True
            p1.font.color.rgb = PPTXPalette.BLUE
            p1.space_after = Pt(2)

            p2 = tf.add_paragraph()
            p2.text = fp_desc
            p2.font.name = "Arial"
            p2.font.size = Pt(9.0)
            p2.font.color.rgb = PPTXPalette.TEXT_MAIN

        self._set_speaker_notes(slide, notes)

    def add_ai_visual_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        clinical_query: str,
        focal_points: List[Tuple[str, str]],
        notes: str = ""
    ):
        """
        AI Vision Engine (BiomedCLIP / FLAIR kataloğu) ile 41.510 görsel arasından
        en yüksek semantik benzerliğe sahip gerçek klinik görseli otomatik bulup slayta yerleştirir.
        """
        try:
            from ophthalmology_vision_ai import resolve_clinical_visual
            res = resolve_clinical_visual(clinical_query, category=category)
            if res and res.get("file_path"):
                img_p = Path(res["file_path"])
                src_info = f"[Kaynak: {res.get('book', '')} s.{res.get('page', '')}]"
                full_notes = (notes + "\n" if notes else "") + f"AI Eşleşen Görsel: {img_p.name} {src_info}\nAltyazı: {res.get('caption', '')}"
                self.add_visual_schema_slide(
                    title=title,
                    category=category,
                    subtitle=subtitle,
                    image_path=img_p,
                    focal_points=focal_points,
                    notes=full_notes
                )
                return
        except Exception as e:
            print(f"[MasterclassPublisher] AI Görsel çözümlenemedi: {e}")

        # Yedek akış
        self.add_visual_schema_slide(
            title=title,
            category=category,
            subtitle=subtitle,
            image_path=clinical_query,
            focal_points=focal_points,
            notes=notes
        )

    def add_lecture_card_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        cards: List[Dict[str, Any]],
        notes: str = ""
    ):
        """2, 3 veya 4 derin tematik bilgi kartı içeren didaktik klinik anlatım slaytı."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        num_cards = len(cards)
        total_w = 11.733
        gap = 0.22
        card_w = (total_w - ((num_cards - 1) * gap)) / num_cards
        card_h = 4.85
        top_y = Inches(1.9)

        for i, c in enumerate(cards):
            x = Inches(0.8 + i * (card_w + gap))
            
            bg_col = PPTXPalette.WHITE
            line_col = PPTXPalette.LINE
            accent_col = PPTXPalette.BLUE

            if c.get("theme") == "danger":
                line_col = PPTXPalette.RED
                accent_col = PPTXPalette.RED
            elif c.get("theme") == "success":
                line_col = PPTXPalette.GREEN
                accent_col = PPTXPalette.GREEN
            elif c.get("theme") == "warning":
                line_col = PPTXPalette.AMBER
                accent_col = PPTXPalette.AMBER

            card_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
            card_shape.fill.solid()
            card_shape.fill.fore_color.rgb = bg_col
            card_shape.line.color.rgb = line_col
            card_shape.line.width = Pt(1.5)

            # Başlık Bandı
            b_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(0.55))
            b_shape.fill.solid()
            b_shape.fill.fore_color.rgb = accent_col
            b_shape.line.fill.background()

            tf_b = b_shape.text_frame
            tf_b.word_wrap = True
            pb = tf_b.paragraphs[0]
            pb.text = c.get("card_title", "BAŞLIK").upper()
            pb.font.name = "Arial"
            pb.font.size = Pt(10)
            pb.font.bold = True
            pb.font.color.rgb = PPTXPalette.WHITE
            pb.alignment = PP_ALIGN.CENTER

            # İçerik
            tf_c = slide.shapes.add_textbox(x + Inches(0.12), top_y + Inches(0.62), Inches(card_w - 0.24), Inches(card_h - 0.75)).text_frame
            tf_c.word_wrap = True

            lead = c.get("lead", "")
            if lead:
                p_lead = tf_c.paragraphs[0]
                p_lead.text = lead
                p_lead.font.name = "Arial"
                p_lead.font.size = Pt(9.5)
                p_lead.font.bold = True
                p_lead.font.color.rgb = PPTXPalette.NAVY
                p_lead.space_after = Pt(6)

            for idx, item in enumerate(c.get("items", [])):
                p = tf_c.paragraphs[0] if (not lead and idx == 0) else tf_c.add_paragraph()
                p.text = f"• {item}"
                p.font.name = "Arial"
                p.font.size = Pt(8.8)
                p.font.color.rgb = PPTXPalette.TEXT_MAIN
                p.space_after = Pt(4)

            footer_tag = c.get("footer", "")
            if footer_tag:
                p_f = tf_c.add_paragraph()
                p_f.text = f"★ {footer_tag}"
                p_f.font.name = "Arial"
                p_f.font.size = Pt(8.5)
                p_f.font.bold = True
                p_f.font.color.rgb = accent_col

        self._set_speaker_notes(slide, notes)

    def add_atlas_image_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        image_path: Path | str,
        caption: str,
        key_findings: List[str],
        differentials: List[str],
        clinical_pearl: str,
        notes: str = ""
    ):
        """
        Kişisel çalışma için optimize edilmiş görsel atlas slaytı.
        Sol tarafta geniş ve yüksek çözünürlüklü patoloji görseli, sağ tarafta tanısal ve ayırıcı analiz kartı.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # Sol Görsel Çerçevesi
        left_box_x = Inches(0.8)
        left_box_y = Inches(1.9)
        left_box_w = Inches(6.2)
        left_box_h = Inches(4.85)

        img_cached = ensure_rgb_cached_image(image_path)
        if img_cached and img_cached.exists():
            try:
                im = Image.open(img_cached)
                orig_w, orig_h = im.size
                scale = min(left_box_w / Inches(orig_w / 96.0), (left_box_h - Inches(0.55)) / Inches(orig_h / 96.0))
                disp_w = Inches(orig_w / 96.0) * scale
                disp_h = Inches(orig_h / 96.0) * scale
                
                # Görseli merkezle
                img_x = left_box_x + (left_box_w - disp_w) / 2
                img_y = left_box_y + (left_box_h - Inches(0.55) - disp_h) / 2
                slide.shapes.add_picture(str(img_cached), img_x, img_y, width=disp_w, height=disp_h)
            except Exception as e:
                print(f"Atlas görseli yerleştirilemedi: {e}")
        else:
            fallback = ensure_rgb_cached_image(ATLAS_OCT_DIR / "Atlas_of_Retinal_OCT_p098_fig168.jpeg")
            if fallback and fallback.exists():
                slide.shapes.add_picture(str(fallback), left_box_x, left_box_y, width=left_box_w)

        # Görsel Altı Açıklama Bandı
        cap_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left_box_x, left_box_y + left_box_h - Inches(0.5), left_box_w, Inches(0.5))
        cap_box.fill.solid()
        cap_box.fill.fore_color.rgb = PPTXPalette.NAVY
        cap_box.line.fill.background()
        tf_cap = cap_box.text_frame
        tf_cap.word_wrap = True
        p_cap = tf_cap.paragraphs[0]
        p_cap.text = f"📷 {caption}"
        p_cap.font.name = "Arial"
        p_cap.font.size = Pt(8.5)
        p_cap.font.color.rgb = RGBColor(226, 232, 240)
        p_cap.alignment = PP_ALIGN.CENTER

        # Sağ Panel: Klinik ve Biyobelirteç Analizi
        right_x = Inches(7.2)
        right_w = Inches(5.333)
        right_h = left_box_h

        card_r = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, left_box_y, right_w, right_h)
        card_r.fill.solid()
        card_r.fill.fore_color.rgb = PPTXPalette.WHITE
        card_r.line.color.rgb = PPTXPalette.BLUE
        card_r.line.width = Pt(1.5)

        tf_r = slide.shapes.add_textbox(right_x + Inches(0.18), left_box_y + Inches(0.12), right_w - Inches(0.36), right_h - Inches(0.24)).text_frame
        tf_r.word_wrap = True

        p1 = tf_r.paragraphs[0]
        p1.text = "🔍 PATOGNOMONİK VE OCT BULGULARI"
        p1.font.name = "Arial"
        p1.font.size = Pt(10.5)
        p1.font.bold = True
        p1.font.color.rgb = PPTXPalette.BLUE
        p1.space_after = Pt(4)

        for kf in key_findings:
            p = tf_r.add_paragraph()
            p.text = f"• {kf}"
            p.font.name = "Arial"
            p.font.size = Pt(9.0)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN
            p.space_after = Pt(3)

        p2 = tf_r.add_paragraph()
        p2.text = "⚖ AYIRICI TANI DEĞERLENDİRMESİ"
        p2.font.name = "Arial"
        p2.font.size = Pt(10)
        p2.font.bold = True
        p2.font.color.rgb = PPTXPalette.PURPLE
        p2.space_before = Pt(6)
        p2.space_after = Pt(3)

        for diff in differentials:
            p = tf_r.add_paragraph()
            p.text = f"▹ {diff}"
            p.font.name = "Arial"
            p.font.size = Pt(8.8)
            p.font.color.rgb = PPTXPalette.NAVY
            p.space_after = Pt(2)

        if clinical_pearl:
            p3 = tf_r.add_paragraph()
            p3.text = f"💡 ÇALIŞMA / SINAV İNCİSİ: {clinical_pearl}"
            p3.font.name = "Arial"
            p3.font.size = Pt(9.0)
            p3.font.bold = True
            p3.font.color.rgb = PPTXPalette.AMBER
            p3.space_before = Pt(6)

        self._set_speaker_notes(slide, notes)

    def add_dual_comparison_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        img1_path: Path | str,
        caption1: str,
        img2_path: Path | str,
        caption2: str,
        focal_points: List[Tuple[str, str]],
        notes: str = ""
    ):
        """
        İki görüntüyü yan yana karşılaştıran multimodal çalışma slaytı.
        Sol tarafta 2 görsel kutusu (3.1 inç x 4.3 inç), sağ tarafta detaylı çalışma kartları.
        """
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        box_w = Inches(3.05)
        box_h = Inches(4.3)
        top_y = Inches(1.9)

        # 1. Görsel (Sol)
        img1_x = Inches(0.8)
        c1 = ensure_rgb_cached_image(img1_path)
        if c1 and c1.exists():
            try:
                im1 = Image.open(c1)
                w1, h1 = im1.size
                scale1 = min(box_w / Inches(w1 / 96.0), box_h / Inches(h1 / 96.0))
                disp_w1 = Inches(w1 / 96.0) * scale1
                disp_h1 = Inches(h1 / 96.0) * scale1
                slide.shapes.add_picture(str(c1), img1_x + (box_w - disp_w1) / 2, top_y + (box_h - disp_h1) / 2, width=disp_w1, height=disp_h1)
            except Exception as e:
                print(f"Görsel 1 basılamadı: {e}")

        cap1_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, img1_x, top_y + box_h + Inches(0.05), box_w, Inches(0.45))
        cap1_box.fill.solid()
        cap1_box.fill.fore_color.rgb = PPTXPalette.NAVY
        cap1_box.line.fill.background()
        tf1 = cap1_box.text_frame
        tf1.word_wrap = True
        p_c1 = tf1.paragraphs[0]
        p_c1.text = caption1
        p_c1.font.name = "Arial"
        p_c1.font.size = Pt(8.0)
        p_c1.font.bold = True
        p_c1.font.color.rgb = PPTXPalette.WHITE
        p_c1.alignment = PP_ALIGN.CENTER

        # 2. Görsel (Orta)
        img2_x = Inches(3.95)
        c2 = ensure_rgb_cached_image(img2_path)
        if c2 and c2.exists():
            try:
                im2 = Image.open(c2)
                w2, h2 = im2.size
                scale2 = min(box_w / Inches(w2 / 96.0), box_h / Inches(h2 / 96.0))
                disp_w2 = Inches(w2 / 96.0) * scale2
                disp_h2 = Inches(h2 / 96.0) * scale2
                slide.shapes.add_picture(str(c2), img2_x + (box_w - disp_w2) / 2, top_y + (box_h - disp_h2) / 2, width=disp_w2, height=disp_h2)
            except Exception as e:
                print(f"Görsel 2 basılamadı: {e}")

        cap2_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, img2_x, top_y + box_h + Inches(0.05), box_w, Inches(0.45))
        cap2_box.fill.solid()
        cap2_box.fill.fore_color.rgb = PPTXPalette.NAVY
        cap2_box.line.fill.background()
        tf2 = cap2_box.text_frame
        tf2.word_wrap = True
        p_c2 = tf2.paragraphs[0]
        p_c2.text = caption2
        p_c2.font.name = "Arial"
        p_c2.font.size = Pt(8.0)
        p_c2.font.bold = True
        p_c2.font.color.rgb = PPTXPalette.WHITE
        p_c2.alignment = PP_ALIGN.CENTER

        # Sağ Panel: Karşılaştırma ve Analiz Kartları
        right_x = Inches(7.2)
        right_w = Inches(5.333)
        num_focal = len(focal_points)
        card_h = (4.85 - ((num_focal - 1) * 0.15)) / max(num_focal, 1)

        for i, (fp_title, fp_desc) in enumerate(focal_points):
            y = top_y + Inches(i * (card_h + 0.15))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, right_w, Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1.2)

            badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, y, Inches(0.12), Inches(card_h))
            badge.fill.solid()
            badge.fill.fore_color.rgb = PPTXPalette.BLUE
            badge.line.fill.background()

            tf = slide.shapes.add_textbox(right_x + Inches(0.2), y + Inches(0.08), right_w - Inches(0.3), Inches(card_h - 0.15)).text_frame
            tf.word_wrap = True

            p1 = tf.paragraphs[0]
            p1.text = f"{i+1}. {fp_title}"
            p1.font.name = "Arial"
            p1.font.size = Pt(9.5)
            p1.font.bold = True
            p1.font.color.rgb = PPTXPalette.BLUE
            p1.space_after = Pt(2)

            p2 = tf.add_paragraph()
            p2.text = fp_desc
            p2.font.name = "Arial"
            p2.font.size = Pt(8.8)
            p2.font.color.rgb = PPTXPalette.TEXT_MAIN

        self._set_speaker_notes(slide, notes)

    def add_trial_deep_dive_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        trial_name: str,
        inclusion_criteria: str,
        treatment_arms: List[Dict[str, str]],
        primary_outcomes: List[str],
        clinical_bottom_line: str,
        citation: str,
        notes: str = ""
    ):
        """Kişisel çalışma için optimize edilmiş klinik RKÇ derinlemesine metodoloji ve kanıt slaytı."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._apply_slide_background(slide)
        self._add_slide_header(slide, title, category=category, subtitle=subtitle)

        top_y = Inches(1.9)
        w = Inches(11.733)

        # Üst Bilgi Kartı: Dahil Etme & Tasarım
        top_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, w, Inches(0.95))
        top_box.fill.solid()
        top_box.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
        top_box.line.color.rgb = PPTXPalette.BLUE
        top_box.line.width = Pt(1.2)

        tf_top = top_box.text_frame
        tf_top.word_wrap = True
        pt1 = tf_top.paragraphs[0]
        pt1.text = f"📋 ÇALIŞMA ADI VE DİZAYN: {trial_name.upper()}"
        pt1.font.name = "Arial"
        pt1.font.size = Pt(10.5)
        pt1.font.bold = True
        pt1.font.color.rgb = PPTXPalette.BLUE
        pt1.space_after = Pt(2)

        pt2 = tf_top.add_paragraph()
        pt2.text = f"Dahil Etme Kriterleri: {inclusion_criteria}"
        pt2.font.name = "Arial"
        pt2.font.size = Pt(8.8)
        pt2.font.color.rgb = PPTXPalette.NAVY

        # Orta Alan: Tedavi Kolları (Yan Yana)
        num_arms = len(treatment_arms)
        gap = 0.2
        arm_w = (11.733 - ((num_arms - 1) * gap)) / num_arms
        arm_h = 2.4
        arm_y = Inches(2.95)

        for idx, arm in enumerate(treatment_arms):
            ax = Inches(0.8 + idx * (arm_w + gap))
            acard = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, ax, arm_y, Inches(arm_w), Inches(arm_h))
            acard.fill.solid()
            acard.fill.fore_color.rgb = PPTXPalette.WHITE
            acard.line.color.rgb = PPTXPalette.LINE
            acard.line.width = Pt(1.2)

            tf_a = acard.text_frame
            tf_a.word_wrap = True
            
            arm_name = arm.get("name") or arm.get("arm") or f"KOL {idx+1}"
            regimen = arm.get("regimen") or arm.get("desc") or ""
            result = arm.get("result") or ""
            if not result and idx < len(primary_outcomes):
                result = primary_outcomes[idx]
            extra = arm.get("extra") or ""

            pa_h = tf_a.paragraphs[0]
            pa_h.text = arm_name.upper()
            pa_h.font.name = "Arial"
            pa_h.font.size = Pt(10)
            pa_h.font.bold = True
            pa_h.font.color.rgb = PPTXPalette.BLUE
            pa_h.space_after = Pt(4)

            if regimen:
                pa_reg = tf_a.add_paragraph()
                pa_reg.text = f"Rejim: {regimen}"
                pa_reg.font.name = "Arial"
                pa_reg.font.size = Pt(8.5)
                pa_reg.font.color.rgb = PPTXPalette.NAVY
                pa_reg.space_after = Pt(3)

            if result:
                pa_res = tf_a.add_paragraph()
                pa_res.text = f"Sonuç: {result}"
                pa_res.font.name = "Arial"
                pa_res.font.size = Pt(8.8)
                pa_res.font.bold = True
                pa_res.font.color.rgb = PPTXPalette.GREEN
                pa_res.space_after = Pt(2)

            if extra:
                pa_ex = tf_a.add_paragraph()
                pa_ex.text = f"Not: {extra}"
                pa_ex.font.name = "Arial"
                pa_ex.font.size = Pt(8.0)
                pa_ex.font.color.rgb = PPTXPalette.TEXT_MAIN

        # Alt Alan: Birincil Çıkarım & Referans
        bot_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(5.45), w, Inches(1.3))
        bot_box.fill.solid()
        bot_box.fill.fore_color.rgb = PPTXPalette.LIGHT_GREEN
        bot_box.line.color.rgb = PPTXPalette.GREEN
        bot_box.line.width = Pt(1.5)

        tf_bot = bot_box.text_frame
        tf_bot.word_wrap = True
        pb1 = tf_bot.paragraphs[0]
        pb1.text = "🎯 NİHAİ KLİNİK VE ÇALIŞMA ÇIKARIMI"
        pb1.font.name = "Arial"
        pb1.font.size = Pt(10.5)
        pb1.font.bold = True
        pb1.font.color.rgb = PPTXPalette.GREEN
        pb1.space_after = Pt(2)

        pb2 = tf_bot.add_paragraph()
        pb2.text = clinical_bottom_line
        pb2.font.name = "Arial"
        pb2.font.size = Pt(9.0)
        pb2.font.color.rgb = PPTXPalette.NAVY
        pb2.space_after = Pt(2)

        pb3 = tf_bot.add_paragraph()
        pb3.text = f"Kaynak / Doğrulama: {citation}"
        pb3.font.name = "Arial"
        pb3.font.size = Pt(8.0)
        pb3.font.bold = True
        pb3.font.color.rgb = PPTXPalette.MUTED

        self._set_speaker_notes(slide, notes)

