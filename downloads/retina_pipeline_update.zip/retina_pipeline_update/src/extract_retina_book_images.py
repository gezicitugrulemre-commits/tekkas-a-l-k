import sys, pymupdf, pathlib, json

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

p = pathlib.Path('C:/Users/gezic/Drive\'\u0131m/Retina Kitab\u0131/Retina_ve_Vitreus_Klinik_Yaklasim.pdf')
out_dir = pathlib.Path(r'c:\Users\gezic\OneDrive\Desktop\Anti Gravity\extracted_figures\retina_vitreus_kitap')
out_dir.mkdir(parents=True, exist_ok=True)

doc = pymupdf.open(p)
catalog = []
img_count = 0

for page_idx in range(len(doc)):
    page = doc[page_idx]
    image_list = page.get_images(full=True)
    if not image_list:
        continue
    page_text = page.get_text()[:400].replace('\n', ' ')
    for img_info in image_list:
        xref = img_info[0]
        base_img = doc.extract_image(xref)
        img_bytes = base_img['image']
        img_ext = base_img['ext']
        if len(img_bytes) < 4000:  # skip small logos/icons
            continue
        img_name = f'page_{page_idx+1:03d}_xref_{xref}.{img_ext}'
        img_path = out_dir / img_name
        with open(img_path, 'wb') as f:
            f.write(img_bytes)
        img_count += 1
        catalog.append({
            'page': page_idx + 1,
            'name': img_name,
            'path': str(img_path),
            'size': len(img_bytes),
            'preview_text': page_text[:140]
        })

print(f"Extracted {img_count} significant images to {out_dir}")
with open(out_dir / "catalog.json", "w", encoding="utf-8") as f:
    json.dump(catalog, f, ensure_ascii=False, indent=2)

for c in catalog[:15]:
    p_num = c['page']
    fn = c['name']
    sz = c['size']
    txt = c['preview_text']
    print(f"  p.{p_num:03d} {fn} ({sz//1024} KB) | {txt}")
