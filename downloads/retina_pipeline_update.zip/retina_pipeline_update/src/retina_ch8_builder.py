# -*- coding: utf-8 -*-
r"""
retina_ch8_builder.py — Bölüm 8: Retina ve Koroid Tümörleri (26 Slayt)
====================================================================
Kitap Sayfaları: 245 – 258
Alt Başlıklar:
  8.0   Bölüm 8 Çalışma Yol Haritası (1 slayt)
  8.1.1 Retinoblastom (RB1, ICRB, İAK, Enükleasyon) (8 slayt)
  8.1.2 Koroid Melanomu (TFSOM-UHHD, Plak, COMS, BAP1) ve Oküler Lenfoma (9 slayt)
  8.1.3 Koroid Nevüsü, Hemanjiomlar ve Vazoproliferatif Tümörler (8 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_8(builder: RetinaStudyDeckBuilder):
    """Bölüm 8'e ait 26 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 8 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=8,
        title="RETİNA VE KOROİD TÜMÖRLERİ",
        page_range="Sayfa 245 – 258",
        subtitle="Retinoblastom, Koroid Melanomu (TFSOM-UHHD), Oküler Lenfoma, Hemanjiomlar ve VHL",
        cards=[
            {
                "title": "1. Retinoblastom (RB)",
                "color": PPTXPalette.RED,
                "lead": "Knudson İki Vuruş & İAK Devrimi",
                "items": [
                    "Genetik: 13q14 kromozomunda RB1 tümör süpresör gen inaktivasyonu; %40 germline (bilateral).",
                    "Klinik Başvuru: Lökokori (%60 en sık), şaşılık (%20), glokom ve psödo-hipopiyon.",
                    "Görüntüleme İmzası: B-Scan USG ve kranial MRG'de intratümöral kalsifikasyon patognomoniktir.",
                    "Modern Tedavi: İntraarteriyel Kemoterapi (İAK - Melphalan) ile göz koruma oranı >%90'a çıkmıştır."
                ],
                "footer": "RB1 / Lökokori / Kalsifikasyon / İAK"
            },
            {
                "title": "2. Koroid Melanomu",
                "lead": "TFSOM-UHHD Risk Kriterleri",
                "items": [
                    "Erişkinde en sık primer intraoküler malign tümör; B-Scan'de mantar morfolojisi ve düşük iç ekojenite.",
                    "TFSOM-UHHD Kriterleri: Kalınlık >2 mm, Subretinal sıvı, Portakal pigmenti, Boş eko, Çap >5 mm.",
                    "Tedavi: Plak Radyoterapi (I-125 / Ru-106 - COMS çalışması enükleasyonla eşit sağkalım kanıtlamıştır).",
                    "Metastatik Risk: Monozomi 3 ve BAP1 mutasyonu karaciğer metastazı riskini dramatik artırır."
                ],
                "footer": "TFSOM-UHHD / Mantar Şekli / Plak Radyoterapi"
            },
            {
                "title": "3. Primer İntraoküler Lenfoma",
                "lead": "Maskeli Üveit (Masquerade)",
                "items": [
                    "60 yaş üstünde steroide yanıtsız kronik vitrit ve sub-RPE krem rengi infiltratlar.",
                    "SSS lenfoması ile %80 birliktelik; tanısal vitrektomi sitopatolojisi ve IL-10/IL-6 oranı >1.0.",
                    "Genetik Belirteç: B hücrelerinde MYD88 L265P mutasyonu tanıyı doğrular.",
                    "Tedavi: Sistemik ve intratekal kemoterapi + İntravitreal Metotreksat / Rituksimab."
                ],
                "footer": "Maskeli Üveit / IL-10>IL-6 / MYD88 L265P"
            },
            {
                "title": "4. Benign Kitleler & Hemanjiom",
                "lead": "Nevüs, Hemanjiom & VHL",
                "items": [
                    "Koroid Nevüsü: Stabil, drusen içeren, subretinal sıvısız benign melanositik lezyon.",
                    "Koroid Hemanjiomu: Somon-portakal rengi, B-Scan yüksek iç ekojenite; Fotodinamik Tedavi (PDT).",
                    "Diffüz Hemanjiom: Sturge-Weber sendromunda 'domates çorbası fundusu' ve konjenital glokom.",
                    "Retinal Kapiller Hemanjiom: Von Hippel-Lindau (VHL); dev besleyici arter ve drenaj veni."
                ],
                "footer": "Nevüs (Drusen) / Hemanjiom (PDT) / VHL (Büyük Damar)"
            }
        ]
    )

    # =========================================================================
    # 8.1.1: RETİNOBLASTOM (8 Slayt)
    # =========================================================================

    # Slayt 8.1.1.1: Retinoblastom Genetiği: Knudson İki Vuruş ve RB1
    builder.add_study_card_slide(
        title="RETİNOBLASTOM GENETİĞİ VE KNUDSON İKİ VURUŞ MODELİ",
        category="BÖLÜM 8.1.1: GENETİK",
        subtitle="13q14 Kromozomunda RB1 Tümör Süpresör Geni, Germline vs Somatik Mutasyon",
        cards=[
            {
                "card_title": "1. Knudson'ın 'İki Vuruş' (Two-Hit) Hipotezi",
                "lead": "Kanser Biyolojisinin Temel Modeli",
                "items": [
                    "Her iki RB1 alelinin de inaktive olması tümörogenez için şarttır [s.245].",
                    "Herediter / Germline (%40): 1. vuruş sperm veya ovumdan gelir (tüm vücut hücrelerinde mutasyon vardır).",
                    "İkinci vuruş retinoblast hücresinde somatik olarak gerçekleşir; kitle erkendir ve MULTİFOKAL / BİLATERALDİR.",
                    "Sporadik / Non-herediter (%60): Her iki vuruş da aynı tek retinal hücrede somatik olarak oluşur; kitle GEÇTİR ve UNİLATERALDİR."
                ],
                "footer": "Germline (Bilateral/Multifokal) vs Somatik (Unilateral/Tek)"
            },
            {
                "card_title": "2. RB1 Proteini ve Hücre Döngüsü Freni",
                "lead": "E2F Transkripsiyon Faktörünün Kontrolü",
                "items": [
                    "RB1 geni pRb fosfoproteinini kodlar; pRb hücre döngüsünün G1 fazından S fazına geçişini engeller [s.245].",
                    "pRb inaktive olduğunda E2F serbest kalır ve hücreler kontrolsüz DNA replikasyonuna ve bölünmeye girer.",
                    "Retinoblastom nöroepitelyal kökenlidir; fotoreseptör prekürsör hücrelerinden kaynaklanır.",
                    "Histopatolojide patognomonik Flexner-Wintersteiner rozetleri (fotoreseptör diferansiasyonu) izlenir."
                ],
                "footer": "pRb İflası -> Kontrolsüz S-Fazı / Flexner Rozetleri"
            },
            {
                "card_title": "3. Trilateral Retinoblastom ve İkincil Maligniteler",
                "lead": "Germline Hastaların Hayati Riski",
                "items": [
                    "Trilateral Retinoblastom: Bilateral oküler tümöre ek olarak pineal bezde veya suprasellar bölgede intrakranial nöroblastik tümör [s.246].",
                    "Germline mutasyonu olan çocuklar hayatlarının ilerleyen dönemlerinde sekonder malignite riski taşırlar.",
                    "Özellikle osteosarkom, yumuşak doku sarkomu ve melanom gelişme riski çok yüksektir.",
                    "Bu nedenle germline RB hastalarında radyasyondan (eksternal radyoterapi ve gereksiz BT'den) KESİNLİKLE KAÇINILMALIDIR."
                ],
                "footer": "Trilateral (Pineal Tümör) / Osteosarkom Riski"
            }
        ]
    )

    # Slayt 8.1.1.2: Klinik Başvuru Triadı: Lökokori ve Şaşılık
    builder.add_study_card_slide(
        title="RETİNOBLASTOM KLİNİK BULGULARI VE ERKEN TEŞHİS",
        category="BÖLÜM 8.1.1: SEMPTOMATOLOJİ",
        subtitle="Lökokori (%60), Şaşılık (%20), Atipik Ön Kamara Tutulumu ve Orbital İlerleme",
        cards=[
            {
                "card_title": "1. Bir Numaralı Başvuru: Lökokori (%60)",
                "lead": "Fotoğraflarda Beyaz Pupil Yansıması ('Kedi Gözü')",
                "items": [
                    "Pupilladan normalde alınan kırmızı fundus refleksi yerine tebeşir beyazı-sarı yansıma alınmasıdır [s.246].",
                    "Aileler genellikle loş ışıkta veya flaşlı çekilen fotoğraflarda beyaz pupil fark ederek başvurur.",
                    "Tümör vitreus boşluğuna doğru büyüyerek (endofitik) optik aksı kapattığında lökokori belirginleşir.",
                    "Çocukta saptanan her lökokoride aksi kanıtlanana kadar retinoblastom düşünülmelidir."
                ],
                "footer": "Lökokori = Beyaz Pupil Refleksi / En Sık Başvuru"
            },
            {
                "card_title": "2. İkinci En Sık Başvuru: Şaşılık (%20)",
                "lead": "Makula Foveanın Erken Tutulması",
                "items": [
                    "Tümör foveayı tuttuğunda santral fiksasyon bozulur ve sensoryal şaşılık (strabismus) gelişir [s.246].",
                    "İçeri (ezotropya) veya dışarı (ekzotropya) kayma görülebilir.",
                    "Şaşılık muayenesi yapılan her bebeğin pupillası mutlaka dilate edilerek fundus taranmalıdır.",
                    "Şaşılığı 'basit kas tembelliği' zannedip fundus bakmamak tanı gecikmesine ve metastaza yol açar."
                ],
                "footer": "Foveal Kitle -> Fiksasyon Kaybı -> Sensoryal Şaşılık"
            },
            {
                "card_title": "3. Atipik ve İleri Evre Bulguları",
                "lead": "Glokom, Psödo-hipopiyon ve Proptozis",
                "items": [
                    "Neovasküler Glokom ve Buftalmus: İridokorneal açının neovaskülarizasyonla tıkanması sonucu göz küresinde büyüme [s.247].",
                    "Psödo-hipopiyon: Tümör hücrelerinin ön kamaraya dökülerek inflamatuar hipopiyonu taklit etmesi.",
                    "Hifema ve Vitreus Kanaması: Tümör nekrozuna bağlı spontan intraoküler kanamalar.",
                    "Orbital Selülit Taklidi / Proptozis: Sklera perforasyonu ve ekstraoküler yayılım bulgusudur."
                ],
                "footer": "Psödo-hipopiyon / Buftalmus / Orbital Yayılım"
            }
        ]
    )

    # Slayt 8.1.1.3: B-Scan USG ve MR Bulguları: Kalsifikasyon İmzası
    builder.add_study_card_slide(
        title="RETİNOBLASTOMDA RADYOLOJİK TANI VE KALSİFİKASYON",
        category="BÖLÜM 8.1.1: GÖRÜNTÜLEME",
        subtitle="B-Scan Ultrasonografide Yüksek Akustik Kalsiyum Yansıması ve Kranial MR Protokolü",
        cards=[
            {
                "card_title": "1. B-Scan Ultrasonografi İmzası",
                "lead": "Kalsifikasyon Saptamada %95+ Duyarlılık",
                "items": [
                    "B-Scan USG'de kitle içinde kalsiyum depolarına bağlı aşırı parlak (hiperreflektif) eko odakları izlenir [s.247].",
                    "Bu kalsifikasyonların arkasında belirgin akustik gölgelenme (acoustic shadowing) oluşur.",
                    "Cihazın kazanç (gain) ayarı minimuma indirildiğinde bile kalsiyum ekoları parlamaya devam eder.",
                    "Tümör yüksekliği, taban çapı ve eşlik eden eksüdatif retina dekolmanı USG ile milimetrik ölçülür."
                ],
                "footer": "Hiperreflektif Kalsiyum + Akustik Gölge"
            },
            {
                "card_title": "2. Kranial ve Orbital Manyetik Rezonans (MRG)",
                "lead": "Optik Sinir İnvazyonu ve Trilateral Tarama",
                "items": [
                    "Retinoblastomda kranial ve orbital kontrastlı MRG ZORUNLUDUR [s.247].",
                    "Optik sinir tutulumunun lamina kribrozayı geçip geçmediğini (cerrahi sınır) en net MR gösterir.",
                    "Pineal bez taranarak eşzamanlı intrakranial tümör (trilateral retinoblastom) dışlanır.",
                    "T1'de hafif hiperintens, T2'de kalsifikasyona ve hücreselliğe bağlı hipointens görünüm verir."
                ],
                "footer": "Optik Sinir Sınırı / Pineal Bez Taraması / MRG Şart"
            },
            {
                "card_title": "3. MUTLAK KURAL: Bilgisayarlı Tomografi (BT) Yasağı",
                "lead": "İkincil Kanserleri Tetikleyen İatrojenik Tehlike",
                "items": [
                    "BT kalsifikasyonu çok iyi gösterse de YÜKSEK İYONİZE RADYASYON içerir [s.248].",
                    "Germline RB1 mutasyonu taşıyan bebeklerde BT radyasyonu ikincil ölümcül kemik ve yumuşak doku sarkomlarını tetikler.",
                    "Bu nedenle retinoblastom şüphesinde BİLGİSAYARLI TOMOGRAFİ ÇEKİLMESİ KESİNLİKLE YASAKTIR.",
                    "Tanı USG ve MRG ile güvenle konulur; BT radyasyon onkolojisi zorunlu olmadıkça çekilmez."
                ],
                "footer": "⚠️ BİLGİSAYARLI TOMOGRAFİ (BT) KESİNLİKLE YASAKTIR"
            }
        ]
    )

    # Slayt 8.1.1.4: Uluslararası Retinoblastom Sınıflaması (ICRB): Grup A'dan E'ye
    builder.add_study_card_slide(
        title="ULUSLARARASI RETİNOBLASTOM SINIFLAMASI (ICRB)",
        category="BÖLÜM 8.1.1: EVRELEME",
        subtitle="Grup A (Çok Küçük) ile Grup E (Gözü Yok Eden Tümör) Arasında Göz Koruma Kriterleri",
        cards=[
            {
                "card_title": "1. Erken Evreler: Grup A ve Grup B",
                "lead": "Fokal Tedaviye Uygun Küçük Tümörler",
                "items": [
                    "Grup A: Çapı ≤3 mm olan, foveaya >1.5 mm, diske >3 mm mesafede izole küçük tümör [s.248].",
                    "Grup B: Çapı >3 mm olan VEYA makula/disk komşuluğunda VEYA <5 mm subretinal sıvısı olan tümör.",
                    "Grup A ve B'de subretinal veya vitreus tohumlanması (seeding) KESİNLİKLE YOKTUR.",
                    "Göz koruma başarı oranı %95-100'dür; lazer veya sistemik kemoterapi ile kolayca kür sağlanır."
                ],
                "footer": "Grup A (≤3 mm) / Grup B (>3 mm / Makuler) / Tohumlanma Yok"
            },
            {
                "card_title": "2. Orta Evreler: Grup C ve Grup D",
                "lead": "Subretinal ve Vitreus Tohumlanması",
                "items": [
                    "Grup C: Lokalize subretinal veya vitreus tohumlanması (tümörden ≤3 mm mesafede odak) [s.248].",
                    "Grup D: Diffüz subretinal veya vitreus tohumlanması (tümörden >3 mm uzakta, 'kar küresi' tarzı serbest adacıklar).",
                    "Tümör büyük, lobüle ve yaygın eksüdatif dekolman içerebilir.",
                    "Grup D tarihsel olarak enükleasyona giderken, günümüzde İntraarteriyel Kemoterapi (İAK) ile kurtarılmaktadır."
                ],
                "footer": "Grup C (Fokal Tohum ≤3 mm) / Grup D (Diffüz Tohum >3 mm)"
            },
            {
                "card_title": "3. İleri Evre: Grup E (Yıkıcı Tümör)",
                "lead": "Göz Kurtarma Şansı Olmayan Son Evre",
                "items": [
                    "Tümör hacmi göz küresinin >%50'sini kaplamıştır [s.249].",
                    "Neovasküler glokom, korneaya temas, hifema, aseptik orbital selülit veya ön kamara invazyonu eşlik eder.",
                    "Göz fonksiyonel olarak kör ve anatomik olarak parçalanmıştır.",
                    "Grup E'de primer ve tartışmasız tedavi ENÜKLEASYONDUR; gözü korumaya çalışmak metastaza yol açar."
                ],
                "footer": "Grup E = Kürenin >%50'si / Glokom / MUTLAK ENÜKLEASYON"
            }
        ]
    )

    # Slayt 8.1.1.5: Modern Tedavi: İntraarteriyel Kemoterapi (İAK) ve İntravitreal Melphalan
    builder.add_study_card_slide(
        title="RETİNOBLASTOMDA MODERN TEDAVİ DEVRİMİ: İAK VE İNTRAVİTREAL",
        category="BÖLÜM 8.1.1: TEDAVİ DEVRİMİ",
        subtitle="Oftalmik Arter Kateterizasyonu (İAK - Melphalan) ve Güvenlik Protokollü İntravitreal Enjeksiyon",
        cards=[
            {
                "card_title": "1. İntraarteriyel Kemoterapi (İAK / İAÇK)",
                "lead": "Femoral Arterden Oftalmik Artere Mikrokateter",
                "items": [
                    "Girişimsel radyoloji eşliğinde mikrokateter femoral arterden oftalmik arter ağzına kadar yönlendirilir [s.249].",
                    "Doğrudan göz içine yüksek konsantrasyonda Melphalan (± Topotekan / Karboplatin) infüzyonu yapılır.",
                    "Sistemik kemoterapinin (kemik iliği baskılanması, sepsis vb.) toksisitesini sıfıra indirir.",
                    "Grup C ve D olgularda enükleasyonsuz göz koruma oranını %85-90'ın üzerine çıkarmıştır."
                ],
                "footer": "Oftalmik Arter Kateteri / Melphalan / %90 Göz Koruma"
            },
            {
                "card_title": "2. İntravitreal Kemoterapi (Melphalan)",
                "lead": "Vitreus Tohumlanmalarının Kesin Çözümü",
                "items": [
                    "Vitreus avasküler bir kompartıman olduğu için sistemik veya İAK ilaçları vitreusa zor difüze olur [s.249].",
                    "Vitreus tohumlanmaları (seeds) için doğrudan 20-30 μg Melphalan intravitreal enjekte edilir.",
                    "Tümör ekimini önlemek için katı güvenlik protokolü uygulanır:",
                    "İğne giriş yeri mikroskop altında kriyoterapi ile dondurulur ve steril BSS ile yüzey yıkanır."
                ],
                "footer": "İntravitreal 20-30 μg Melphalan / Giriş Yerine Kriyoterapi"
            },
            {
                "card_title": "3. Fokal Konsolidasyon Tedavileri",
                "lead": "Lazer Fotokoagülasyon ve Kriyoterapi",
                "items": [
                    "Kemoterapi ile küçülen tümör artıklarına 532/810 nm Transpupiller Termoterapi (TTT) uygulanır [s.250].",
                    "Periferik küçük tümörlerde transskleral kriyopeksi ile dondurma yapılır.",
                    "Kür sağlandıktan sonra tümör kalsifiye bir 'balık eti' veya peynirimsi inaktif skara dönüşür.",
                    "Çocuklar anestezi altında en az 5 yaşına kadar aylık/üç aylık muayenelerle nüks açısından taranır."
                ],
                "footer": "Lazer TTT / Kriyopeksi / Balık Eti Skarı"
            }
        ]
    )

    # Slayt 8.1.1.6: Enükleasyon Endikasyonları ve Biyopsi KONTRENDİKASYONU
    builder.add_split_comparison_slide(
        title="ENÜKLEASYON KURALLARI VE BİYOPSİ KONTRENDİKASYONU",
        category="BÖLÜM 8.1.1: CERRAHİ GÜVENLİK",
        subtitle="Hangi Göz Feda Edilmeli ve Neden İnce İğne Biyopsisi (İİAB) KESİNLİKLE YASAKTIR?",
        left_entity={
            "name": "ENÜKLEASYON ENDİKASYONLARI",
            "subtitle": "Hayatı Kurtarmak İçin Gözün Alınması",
            "bullets": [
                "Grup E Retinoblastom (Kürenin >%50'sini saran tümör) [s.249].",
                "Ön kamara invazyonu, psödo-hipopiyon ve neovasküler glokom varlığı.",
                "Optik sinir MRG'sinde belirgin retrobulber tümör invazyonu şüphesi.",
                "İAK ve intravitreal kemoterapiye dirençli veya nüks eden dev tümörler.",
                "Cerrahi İlke: Optik sinir mümkün olduğunca geriden (en az 10-15 mm kütükle) kesilmelidir [s.250]."
            ]
        },
        right_entity={
            "name": "BİYOPSİ (İİAB) KESİNLİKLE YASAKTIR!",
            "subtitle": "Metastazı Tetikleyen Ölümcül Cerrahi Hata",
            "bullets": [
                "Retinoblastom şüphesinde tanı için göze iğne sokmak (İİAB / parasentez) KESİNLİKLE YASAKTIR [s.250].",
                "İğne sklerayı deldiği anda yüksek basınçlı tümör hücreleri sklera kanalından orbitaya ve kan dolaşımına ekilir.",
                "Lokalize ve kür şansı %98 olan intraoküler tümör, bir anda mortalitesi %80 olan sistemik metastaza dönüşür.",
                "Tanı klinik muayene, B-Scan USG kalsifikasyonu ve kranial MRG ile %100 doğrulukla konulur.",
                "Patolojik kesin tanı ancak enükleasyon materyalinin incelenmesiyle konulur [s.250]."
            ]
        },
        bottom_takeaway="Retinoblastomda göze biyopsi yapmak veya ön kamara parasentezi almak çocuğun ölüm fermanını imzalamaktır; tanı sadece oftalmoskopi, USG ve MR ile konulmalıdır [s.250]."
    )

    # Slayt 8.1.1.7: Retinoblastom Triyaj ve Tedavi Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="RETİNOBLASTOM KLİNİK PROTOKOLÜ VE TRİYAJ",
        category="BÖLÜM 8.1.1: AKIŞ ŞEMASI",
        subtitle="Lökokorili Bebekte Adım Adım Görüntüleme, Evreleme ve Tedavi Algoritması",
        steps=[
            {
                "num": "1",
                "title": "B-Scan USG ile Kalsifikasyon Tespiti",
                "desc": "Tümör içi kalsiyum ekosu ve akustik gölge saptanır; BT KESİNLİKLE ÇEKİLMEZ [s.247].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Kranial ve Orbital Kontrastlı MRG",
                "desc": "Optik sinir invazyon derinliği ölçülür; pineal bez taranarak trilateral RB dışlanır.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Anestezi Altında Muayene (EUA) & ICRB",
                "desc": "Grup A-D ise kemoterapi protokolü; Grup E veya neovasküler glokom ise acil Enükleasyon [s.248].",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "İAK / İntravitreal Melphalan Uygulaması",
                "desc": "Oftalmik arterden İAK ve fokal TTT lazer ile göz korunur; germline RB1 gen paneli çalışılır.",
                "status": "success"
            }
        ],
        bottom_takeaway="Retinoblastomda birinci amaç hastanın hayatını kurtarmak, ikinci amaç gözü korumak, üçüncü amaç ise görmeyi korumaktır; öncelik sırası asla değiştirilemez [s.249]."
    )

    # Slayt 8.1.1.8: Aktif Hatırlama & Board Sınavı Vakası: 18 Aylık Bebekte Lökokori
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: RETİNOBLASTOM",
        category="BÖLÜM 8.1.1: AKTİF HATIRLAMA",
        subtitle="18 Aylık Erkek Bebekte Flaşlı Fotoğrafta Beyaz Refleks ve Kalsifiye Kitle",
        vignette="18 aylık erkek bebek, annesi tarafından doğum günü fotoğraflarında sağ göz bebeğinde beyaz bir parlama ('kedi gözü' refleksi) fark edilmesi üzerine getiriliyor. Bebeğin gözünde kızarıklık veya ağrı yoktur. Anestezi altında muayenede (EUA) sağ gözde pupilla dilate edildiğinde vitreus boşluğuna doğru uzanan, üzerinde damar genişlemeleri bulunan sarımsı-beyaz kabarık büyük bir kitle (Grup D retinoblastom) ve tümör çevresinde serbest vitreus tohumlanmaları (seeding) izleniyor. Sol göz tamamen normal. B-Scan USG'de kitle içinde yoğun hiperekojenik kalsifikasyon odakları ve arkasında akustik gölgelenme saptanıyor. Çekilen kranial ve orbital MRG'de optik sinir invazyonu saptanmıyor ve pineal bez normal izleniyor.",
        differentials=[
            "Retinoblastom (18 aylık bebek, lökokori, kalsifiye kitle ve vitreus tohumlanması - kesin klinik tablo).",
            "Coats Hastalığı (Kalsifikasyon içermez, geniş lipid eksüdasyonu ve telanjiyektatik ampuller vardır).",
            "Persistan Fetal Vaskülarizasyon (PFV - Mikroftalmi eşlik eder, retrolental kıkırdak zarı vardır, kalsiyum yoktur).",
            "Oküler Toksokariyazis (Genellikle daha büyük çocuklarda tek taraflı granülom ve traksiyonel bant yapar)."
        ],
        decision="1. Kesin Tanı: Sağ Retinoblastom (ICRB Grup D).\n2. Tedavi Stratejisi: Optik sinir temiz olduğu için göz kurtarma şansı vardır. Hastaya İntraarteriyel Kemoterapi (İAK - Oftalmik arterden Melphalan infüzyonu) planlanmalıdır.\n3. Vitreus Tohumları İçin: Güvenlik önlemleri (kriyoterapi desteği) altında İntravitreal Melphalan (20-30 μg) enjeksiyonları eklenmelidir.\n4. Cerrahi Uyarı: Kesinlikle ince iğne biyopsisi veya parasentez YAPILMAZ; BT ÇEKİLMEZ.",
        board_trap="Bu bebekte tanıyı doğrulamak için 'bir iğne biyopsisi alalım' demek tümörün orbitaya ekilmesine ve bebeğin metastazdan ölmesine yol açar; retinoblastomda biyopsi KESİNLİKLE YASAKTIR [s.250]."
    )

    # =========================================================================
    # 8.1.2: KOROİD MELANOMU VE OKÜLER LENFOMA (9 Slayt)
    # =========================================================================

    # Slayt 8.1.2.1: Koroid Melanomu Patogenezi ve Moleküler Genetik: BAP1
    builder.add_study_card_slide(
        title="KOROİD MELANOMU PATOFİZYOLOJİSİ VE MOLEKÜLER GENETİK",
        category="BÖLÜM 8.1.2: MELANOM",
        subtitle="Uveal Melanosit Kökenli Malignite, GNAQ/GNA11 Mutasyonları ve Monozomi 3 / BAP1",
        cards=[
            {
                "card_title": "1. Epidemiyoloji ve Hücre Tipleri",
                "lead": "Erişkinde En Sık Primer İntraoküler Kanser",
                "items": [
                    "Yıllık insidansı milyonda 5-7'dir; en sık 50-70 yaş arası Kafkas ırkta görülür [s.251].",
                    "Uveal koroid stromasındaki melanositlerin malign transformasyonudur.",
                    "Callender Histopatolojik Sınıflaması:",
                    "1. İğsi (Spindle) Hücreli: Daha iyi prognoza sahiptir (Spindle A ve B).",
                    "2. Epiteloid Hücreli: Yüksek metastaz potansiyeli ve kötü sağkalım gösterir; pleomorfik nükleusludur.",
                    "3. Mikst Tip: Hem iğsi hem epiteloid hücrelerin bir arada bulunduğu en sık formdur."
                ],
                "footer": "Spindle (İyi Prognoz) vs Epiteloid (Kötü Prognoz)"
            },
            {
                "card_title": "2. Başlangıç Onkogenleri: GNAQ ve GNA11",
                "lead": "G-Protein Kenetli Reseptör Sinyal Yolağı",
                "items": [
                    "Uveal melanomların >%80'inde GNAQ veya GNA11 genlerinde aktive edici mutasyonlar bulunur [s.251].",
                    "Bu mutasyonlar tümörün erken oluşumunu (tümörogenezi) tetikler ancak tek başına metastaz riskini belirlemez.",
                    "MAPK ve YAP/TAZ sinyal yolakları sürekli aktif kalır.",
                    "Nevüsten melanoma dönüşümde erken tetikleyici mutasyondur."
                ],
                "footer": "GNAQ / GNA11 -> Sürekli Aktif MAPK Yolağı"
            },
            {
                "card_title": "3. Prognostik İmzalar: Monozomi 3 ve BAP1",
                "lead": "Metastaz Riskinin Genetik Şifresi",
                "items": [
                    "Monozomi 3 (Kromozom 3'ün tek kopyasının kaybı): 5 yıl içinde hematojen karaciğer metastazı riskini %50'nin üzerine çıkarır [s.252].",
                    "BAP1 Gen Mutasyonu (3p21 kromozomunda): BRCA1-ilişkili protein-1 inaktivasyonu epiteloid fenotipi ve masif metastazı tetikler.",
                    "Gen Ekspresyon Profili (GEP - Castle Biosciences):",
                    "Sınıf 1 (Düşük risk, %95 beş yıllık sağkalım) vs Sınıf 2 (Yüksek risk, Monozomi 3/BAP1 pozitif, %20-30 sağkalım)."
                ],
                "footer": "Monozomi 3 + BAP1 = Sınıf 2 Yüksek Metastaz Riski"
            }
        ]
    )

    # Slayt 8.1.2.2: B-Scan USG İmzası: Düşük İç Ekojenite ve Mantar Şekli
    builder.add_study_card_slide(
        title="KOROİD MELANOMUNDA B-SCAN VE A-SCAN USG İMZASI",
        category="BÖLÜM 8.1.2: ULTRASONOGRAFİ",
        subtitle="Mantar (Collar-button) Morfolojisi, Düşük İç Ekojenite ve İç Vaskülarite Pulsasyonu",
        cards=[
            {
                "card_title": "1. Mantar (Collar-Button / Düğme) Şekli",
                "lead": "Bruch Zarının Yırtılması",
                "items": [
                    "Melanom başlangıçta koroid içinde kubbe (dome) şeklinde genişler [s.252].",
                    "Büyüyen tümör Bruch zarını delip yırtarak subretinal aralığa doğru fıtıklaşır.",
                    "Bu durum B-Scan USG'de ve oftalmoskopide tipik 'Mantar' veya 'Yaka Düğmesi' (Collar-button) şeklini oluşturur.",
                    "Mantar morfolojisi koroid melanomu için neredeyse patognomoniktir (nevüsler asla mantar şekli almaz)."
                ],
                "footer": "Bruch Yırtılması -> Patognomonik Mantar Şekli"
            },
            {
                "card_title": "2. Standart A-Scan: Düşük-Orta İç Ekojenite",
                "lead": "Homojen Sıkı Hücresel Yapı",
                "items": [
                    "Standart A-Scan USG'de başlangıçtaki yüksek tümör yüzey pikinden sonra iç ekolar hızla alçalır [s.252].",
                    "İç ekojenite <%40-60 seviyesindedir (düşük-orta iç reflektivite).",
                    "A-Scan dalgaları düzenli bir 'açılı merdiven' şeklinde aşağı doğru basamaklanır (Kappa açısı).",
                    "Bu düşük ekojenite, yüksek iç ekojenite veren koroid hemanjiomu ve metastazlardan kesin ayrımı sağlar."
                ],
                "footer": "Düşük-Orta İç Reflektivite (<%50) / Düzenli Basamak"
            },
            {
                "card_title": "3. İç Vaskülarite ve Akustik Boşluk",
                "lead": "Koroideal Ekskavasyon ve Vasküler Spiküller",
                "items": [
                    "Akustik Boşluk (Acoustic hollowing): Tümörün tabanında ses dalgalarının zayıflamasına bağlı sessiz eko kuşağı [s.253].",
                    "Koroidal Ekskavasyon: Tümörün koroid stromasını itmesiyle skleral hatta çukurlaşma oluşması.",
                    "İç Vasküler Pulsasyon: Gerçek zamanlı A-Scan muayenesinde tümör damarlarının sistolik atımları ekranda titreşir.",
                    "Eşlik eden eksüdatif retina dekolmanı B-Scan'de net olarak görüntülenir."
                ],
                "footer": "Akustik Boşluk / Koroidal Ekskavasyon / Vasküler Titreşim"
            }
        ]
    )

    # Slayt 8.1.2.3: TFSOM-UHHD Risk Kriterleri (Shields Kuralı)
    builder.add_study_card_slide(
        title="NEVÜS-MELANOM AYRIMI: TFSOM-UHHD KRİTERLERİ",
        category="BÖLÜM 8.1.2: RİSK KRİTERLERİ",
        subtitle="To Find Small Ocular Melanoma Using Helpful Hints Daily (Shields Konsensüsü)",
        cards=[
            {
                "card_title": "1. İlk Üç Kriter: T - F - S",
                "lead": "Kalınlık, Sıvı ve Semptomlar",
                "items": [
                    "T (Thickness): Ultrasonografide apikal kitle kalınlığının >2.0 mm olması [s.253].",
                    "F (Fluid): SD-OKT'de lezyon üzerinde subretinal sıvı (SRF) göllenmesi.",
                    "S (Symptoms): Hastanın fotopsi, metamorfopsi veya görme alanı defekti tarif etmesi.",
                    "Bu kriterlerin her biri lezyonun malign transformasyon riskini katlar."
                ],
                "footer": "T (>2 mm) / F (Sıvı) / S (Semptom)"
            },
            {
                "card_title": "2. İkinci Üç Kriter: O - M - U",
                "lead": "Portakal Pigmenti, Kenar Mesafesi ve Eko",
                "items": [
                    "O (Orange pigment): Lezyon yüzeyinde Fundus Otofloresansında parlak parlayan lipofuksin kümeleri [s.253].",
                    "M (Margin): Tümör sınırının optik diske ≤3.0 mm (≤2 DD) mesafede olması.",
                    "U (Ultrasound hollowness): A-Scan USG'de iç reflektivitenin düşük olması (akustik boşluk).",
                    "Portakal pigmenti (lipofuksin) RPE metabolik iflasının ve aktif tümör büyümesinin altın göstergesidir."
                ],
                "footer": "O (Lipofuksin) / M (Disk Komşuluğu) / U (Düşük Eko)"
            },
            {
                "card_title": "3. Son İki Kriter: H - D ve Skorlama",
                "lead": "Halo Yokluğu ve Geniş Çap",
                "items": [
                    "H (Halo absence): Lezyon çevresinde selim nevüslerde görülen depigmente dairesel halonun OLMAMASI [s.254].",
                    "D (Diameter): Taban çapının >5.0 mm olması.",
                    "Risk Skorlaması: 0 kriter varlığında malignleşme riski <%1; 3 veya daha fazla kriterde 5 yılda transformasyon riski >%50'dir.",
                    "≥3 kriter taşıyan lezyonlar artık nevüs değil 'küçük koroid melanomu' kabul edilerek tedavi edilmelidir."
                ],
                "footer": "H (Halo Yokluğu) / D (Çap >5 mm) / ≥3 Kriter = Melanom"
            }
        ]
    )

    # Slayt 8.1.2.4: Atlas Görseli: Mantar Şekilli Koroid Melanomu
    p251_img = builder.get_image_for_page(251)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: KOROİD MELANOMU VE B-SCAN İMZASI",
        category="BÖLÜM 8.1.2: ATLAS",
        subtitle="Mantar Morfolojisi, Yüzey Lipofuksin Kümeleri ve Eksüdatif Dekolman",
        image_path=p251_img if p251_img else None,
        caption="Şekil 8.1: Geniş tabanlı, kubbe/mantar şekilli koroid melanomu, yüzeyinde portakal rengi lipofuksin birikimleri ve alt kadranda sekonder seröz retina dekolmanı [Kitap s.251].",
        key_findings=[
            "Retina altında koyu kahverengi-gri renkte, yüksek kubbe oluşturan kabarık koroideal kitle.",
            "Tümörün tepe noktasında portakal kabuğu renginde parlak lipofuksin pigment kümeleri.",
            "Bruch zarını delerek subretinal aralığa doğru genişleyen mantar (collar-button) başı.",
            "B-Scan ultrasonografide düşük iç yansıma, tabanda akustik boşluk ve koroidal ekskavasyon."
        ],
        differentials=[
            "Koroid Melanomu: Mantar şekli, düşük iç ekojenite, akustik boşluk, portakal pigmenti.",
            "Koroid Nevüsü: Düz/hafif kabarık (<2 mm), drusen içerir, sıvı ve portakal pigmenti yoktur.",
            "Koroid Hemanjiomu: Somon rengi, kubbe şekilli, A-Scan'de >%90 YÜKSEK iç ekojenite.",
            "Koroid Metastazı: Sarımsı-krem rengi, lobüle, çok odaklı, A-Scan'de orta-yüksek ekojenite."
        ],
        clinical_pearl="Portakal pigmenti (lipofuksin) FAF çekildiğinde parlak alev gibi parlar; pigmente bir koroid lezyonunun üzerinde FAF'ta hiperotofloresan portakal lekesi görülmesi melanom lehine en güçlü alarmdır [s.251]."
    )

    # Slayt 8.1.2.5: Tedavi Modaliteleri: Plak Radyoterapi vs Enükleasyon (COMS)
    builder.add_split_comparison_slide(
        title="KOROİD MELANOMU TEDAVİSİ: PLAK RADYOTERAPİ vs ENÜKLEASYON",
        category="BÖLÜM 8.1.2: COMS ÇALIŞMASI",
        subtitle="İyot-125 / Rutenyum-106 Brakiterapi vs Cerrahi Enükleasyon (Landmark COMS Verisi)",
        left_entity={
            "name": "PLAK RADYOTERAPİ (BRAKİTERAPİ)",
            "subtitle": "Gözü Koruyan Altın Standart — I-125 / Ru-106",
            "bullets": [
                "Endikasyon: Küçük ve orta boy koroid melanomları (kalınlık ≤10 mm, taban çapı ≤16 mm) [s.254].",
                "Teknik: Skleraya geçici olarak altın taşıyıcı içine yerleştirilmiş İyot-125 veya Rutenyum-106 plağı dikilir.",
                "Radyasyon Dozu: Tümörün tepe noktasına (apeks) 85 Gy radyasyon verilir; 3-5 gün sonra plak çıkarılır.",
                "Lokal Kontrol: Tümörün gerileme ve lokal kontrol oranı %90-95'tir.",
                "Komplikasyonlar: 2-3 yıl sonra radyasyon retinopatisi, katarakt ve optik nöropati riski mevcuttur [s.254]."
            ]
        },
        right_entity={
            "name": "CERRAHİ ENÜKLEASYON",
            "subtitle": "Büyük veya Görme Şansı Olmayan İleri Tümörler",
            "bullets": [
                "Endikasyon: Büyük melanomlar (kalınlık >10 mm, taban çapı >16 mm), optik diski saran kitleler [s.254].",
                "Küre Durumu: Neovasküler glokom gelişmiş, ağrılı, kör ve masif dekolmanlı gözler.",
                "COMS Landmark Sonucu: Orta boy melanomlarda plak radyoterapi ile enükleasyon arasında 5, 10 ve 12 yıllık SİSTEMİK SAĞKALIM EŞİTTİR!",
                "Bu devrimsel kanıt sayesinde gözün feda edilmesi önlenmiş, brakiterapi standart olmuştur.",
                "Cerrahi Kural: Tümör hücrelerini damarlara saçmamak için glob manipülasyonu minimum tutulmalıdır [s.255]."
            ]
        },
        bottom_takeaway="Landmark COMS çalışması plak radyoterapinin enükleasyon kadar sağkalım sağladığını kanıtlamıştır; gözü korumak hastanın metastaz riskini artırmaz [s.254]."
    )

    # Slayt 8.1.2.6: Sistemik Metastaz Taraması ve Biyopsi Protokolü
    builder.add_study_card_slide(
        title="MELANOMDA METASTAZ TARAMASI VE PROGNOSTİK BİYOPSİ",
        category="BÖLÜM 8.1.2: METASTAZ",
        subtitle="Hematojen Karaciğer Yayılımı, İnce İğne Aspirasyon Biyopsisi (FNAB) ve Hedefe Yönelik Tedavi",
        cards=[
            {
                "card_title": "1. Karaciğer Predileksiyonu (%90)",
                "lead": "Uveal Melanomun Hematojen Yayılım Yolu",
                "items": [
                    "Koroidde lenfatik drenaj yoktur; tüm metastazlar doğrudan kan dolaşımı (vortiköz venler) ile yayılır [s.255].",
                    "Metastazların %85-90'ı ilk olarak karaciğere yerleşir; ardından akciğer ve kemik gelir.",
                    "Sistemik Tarama Standartları: 6 ayda bir Kontrastlı Üst Batın MRG (veya USG) + Karaciğer Fonksiyon Testleri (AST, ALT, GGT, LDH).",
                    "Karaciğer MRG mikrometastazları yakalamada batın ultrasonografisine göre çok daha üstündür."
                ],
                "footer": "Vortiköz Ven Yayılımı / %90 Karaciğer / 6 Ayda Bir MRG"
            },
            {
                "card_title": "2. İnce İğne Biyopsisi (FNAB) ve Sitogenetik",
                "lead": "Plak Öncesi Prognostik Örnekleme",
                "items": [
                    "Retinoblastomun aksine, koroid melanomunda plak radyoterapisi takılırken transskleral/transvitreal FNAB güvenle yapılabilir [s.255].",
                    "25G/27G iğne ile alınan hücrelerde Monozomi 3, 8q kazancı ve BAP1 mutasyonu taranır.",
                    "Gen Ekspresyon Profili (GEP Sınıf 1 vs Sınıf 2) belirlenerek hastanın 5 yıllık metastaz riski hesaplanır.",
                    "Sınıf 2 yüksek riskli hastalarda sistemik adjuvan onkolojik protokoller (Tebentafusp) erken başlatılır."
                ],
                "footer": "FNAB Güvenlidir / Monozomi 3 / BAP1 / GEP Sınıflandırması"
            },
            {
                "card_title": "3. Metastatik Melanomda Devrim: Tebentafusp",
                "lead": "HLA-A*02:01 Pozitif Hastalarda İlk Sağkalım Başarısı",
                "items": [
                    "Tebentafusp, gp100 tümör antijenini T-hücre CD3 reseptörüne bağlayan çift özgüllü füzyon proteinidir (BiTE) [s.256].",
                    "HLA-A*02:01 doku grubu taşıyan metastatik uveal melanom hastalarında genel sağkalımı anlamlı uzatan ilk FDA onaylı ilaçtır.",
                    "Karaciğere yönelik lokal tedaviler: Kemoembolizasyon (TACE), radyoembolizasyon (Yttrium-90) ve cerrahi metastazektomi.",
                    "Erken primer tanı hastanın karaciğer metastazına gitmesini önleyen tek fırsattır."
                ],
                "footer": "Tebentafusp (BiTE) / HLA-A*02:01 / Karaciğer TACE"
            }
        ]
    )

    # Slayt 8.1.2.7: Primer Vitreoretinal Lenfoma (PVRL): Maskeli Üveit
    builder.add_study_card_slide(
        title="PRİMER VİTREORETİNAL LENFOMA (PVRL): MASKELİ ÜVEİT",
        category="BÖLÜM 8.1.2: LENFOMA",
        subtitle="Santral Sinir Sistemi İntraoküler Lenfoması, Steroid Dirençli Vitrit ve IL-10/IL-6 Oranı",
        cards=[
            {
                "card_title": "1. 'Maskeli Üveit' (Masquerade) Fenotipi",
                "lead": "60 Yaş Üstü Yaşlılarda Tedaviye Dirençli Tablo",
                "items": [
                    "PVRL, yüksek dereceli Diffüz Büyük B Hücreli Lenfomanın (DLBCL) intraoküler tutulumudur [s.256].",
                    "Genellikle >60 yaş hastalarda persistan, steroide geçici yanıt verip kesilince alevlenen bilateral vitritle başlar.",
                    "Göz hekimi hastayı aylarca 'yaşlılık üveiti' zannederek gereksiz steroid damla ve haplarıyla oyalar.",
                    "Hastaların %65-80'inde süreç içinde primer Santral Sinir Sistemi (SSS) lenfoması gelişir (ölümcül risk!)."
                ],
                "footer": "Maskeli Üveit / >60 Yaş / %80 SSS Tutulum Riski"
            },
            {
                "card_title": "2. Fundus İmzası: Sub-RPE Krem Plaklar",
                "lead": "RPE Altında Tümör Hücresi Göllenmesi",
                "items": [
                    "Biyomikroskopide vitreus içinde kümelenmiş geniş hücresel konglometratlar ('vitreus tabakaları') izlenir [s.256].",
                    "Fundus muayenesinde RPE altında çok odaklı, kabarık, kremsi sarı-beyaz infiltrasyon plakları saptanır.",
                    "SD-OKT'de RPE altında nodüler hiperreflektif birikimler ve RPE dekolmanları görülür.",
                    "FAF'ta taze tümör hücreleri hiperotofloresan parıldarken, eski infiltrat alanları hipootofloresan leopar postu verir."
                ],
                "footer": "Sub-RPE Krem Plaklar / Leopar Postu FAF"
            },
            {
                "card_title": "3. Kesin Tanı Kriterleri ve Tedavi",
                "lead": "Vitrektomi Biyopsisi, IL-10 ve MYD88",
                "items": [
                    "Tanısal 25G Pars Plana Vitrektomi: Alınan vitreus sıvısı taze olarak sitopatolojiye ve akım sitometrisine (flow) gönderilir [s.257].",
                    "IL-10 / IL-6 Oranı: Vitreusta B-hücre kaynaklı İnterlökin-10 düzeyi IL-6'dan belirgin yüksekse (IL-10/IL-6 >1.0) lenfoma lehinedir.",
                    "Moleküler İpucu: B hücrelerinde MYD88 L265P mutasyonu tanıyı kesinleştirir.",
                    "Tedavi: İntravitreal Metotreksat (400 μg) / Rituksimab enjeksiyonları + Sistemik Yüksek Doz İV Metotreksat."
                ],
                "footer": "Vitrektomi Biyopsisi / IL-10>IL-6 / MYD88 L265P"
            }
        ]
    )

    # Slayt 8.1.2.8: Koroid Melanomu Yönetim ve Karar Ağacı
    builder.add_decision_tree_slide(
        title="KOROİD PİGMENTE KİTLE YÖNETİM PROTOKOLÜ",
        category="BÖLÜM 8.1.2: KARAR AĞACI",
        subtitle="Melanositik Lezyon Saptanan Hastada TFSOM Kriterleri ve Tedavi Triyajı",
        root_label="ARKA SEGMENTTE PİGMENTE KOROİD LEZYONU SAPTANDI",
        branches=[
            {
                "label": "1. TFSOM Kriteri 0 (Stabil Selim Nevüs)",
                "criteria": "Kalınlık <2 mm, sıvı yok, semptom yok, portakal pigmenti yok, drusen (+), halo (+) [s.253].",
                "action": "Gözlem ve Fotoğrafik Takip: Tedavi gerekmez; yıllık renkli fundus fotoğrafı ve OKT ile izlenir."
            },
            {
                "label": "2. TFSOM Kriteri ≥3 / Küçük-Orta Melanom",
                "criteria": "Kalınlık 2-10 mm, subretinal sıvı (+), portakal pigmenti (+), A-Scan düşük eko [s.254].",
                "action": "Plak Radyoterapi (Brakiterapi): FNAB ile Monozomi 3 analizi yapılır; I-125 veya Ru-106 plağı uygulanır."
            },
            {
                "label": "3. Büyük Melanom / Ağrılı Kör Göz",
                "criteria": "Kalınlık >10 mm, taban >16 mm, neovasküler glokom, optik sinir invazyonu şüphesi [s.255].",
                "action": "Primer Enükleasyon: Optik sinir geriden kesilerek göz çıkarılır; orbita implantı konulur; karaciğer MRG takibi."
            }
        ],
        bottom_rule="Pigmente bir lezyonun üzerinde SD-OKT ile subretinal sıvı ve FAF ile portakal pigmenti gösterilmişse lezyon artık nevüs değildir; 'bekleyip görelim' denilirse karaciğer metastazı gelişebilir [s.253]."
    )

    # Slayt 8.1.2.9: Aktif Hatırlama & Board Sınavı Vakası: 56 Yaş Melanom Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: KOROİD MELANOMU",
        category="BÖLÜM 8.1.2: AKTİF HATIRLAMA",
        subtitle="56 Yaşında Erkekte Fotopsi, Üst Temporalde Kabarık Kitle ve FAF Portakal Parıltısı",
        vignette="56 yaşında erkek hasta, sağ gözünün alt alanında 2 aydır ışık çakmaları (fotopsi) ve son 2 haftada görme alanında siyah bir gölge hissettiğini belirterek başvuruyor. Sağ görme 0.7, sol görme 1.0. Ön segment doğal. Sağ fundus muayenesinde üst temporal kadranda foveaya 2 disk çapı mesafede, 3.2 mm kabarık, taban çapı 8.5 mm olan kubbe şeklinde koyu kahverengi koroideal kitle izleniyor. Kitlenin üzerinde fokal parlak portakal rengi pigmentler ve lezyonun alt sınırından foveaya doğru uzanan sığ subretinal sıvı izleniyor. B-Scan USG'de akustik boşluk ve koroidal ekskavasyon; A-Scan USG'de %35 düzeyinde düşük iç yansıma izleniyor. FAF'ta portakal pigmentlerine karşılık gelen alanlar parlak hiperotofloresan yanıyor.",
        differentials=[
            "Orta Boy Koroid Melanomu (Kalınlık >2 mm, subretinal sıvı, portakal pigmenti, düşük iç ekojenite - TFSOM tam pozitif).",
            "Büyük Koroid Nevüsü (Kalınlık <2 mm'dir, sıvı ve portakal pigmenti içermez, A-Scan'de yüksek ekolüdür).",
            "Sirkumskript Koroid Hemanjiomu (Somon rengidir, A-Scan'de >%90 yüksek iç reflektivite verir).",
            "Koroid Metastazı (Krem-sarı renklidir, çok odaklıdır, primer kanser öyküsü sıktır)."
        ],
        decision="1. Kesin Tanı: Sağ Orta Boy Koroid Melanomu (TFSOM kriterlerinin 5 tanesi pozitif).\n2. Sistemik Tarama: Tedavi öncesi karaciğer metastazını dışlamak için Kontrastlı Üst Batın MRG ve KCFT tetkikleri istenmelidir.\n3. Tedavi Protokolü: Gözü korumak ve enükleasyonla eşit sağkalım sağlamak için İyot-125 (I-125) Plak Radyoterapisi (Brakiterapi) planlanmalıdır.\n4. Biyopsi: Plak cerrahisi esnasında prognostik Monozomi 3 ve GEP sınıflandırması için FNAB yapılabilir.",
        board_trap="Bu hastada 'henüz görmesi 0.7, 6 ay sonra tekrar ultrasonla bakalım büyüyor mu' demek en ölümcül klinik hatadır; lezyon 5 adet TFSOM kriteri taşımaktadır ve malignite kesindir; büyümesini beklemek karaciğer metastazı riskini katlar [s.253]."
    )

    # =========================================================================
    # 8.1.3: KOROİD NEVÜSÜ, HEMANJİOMLAR VE VAZOPROLİFERATİF TÜMÖRLER (8 Slayt)
    # =========================================================================

    # Slayt 8.1.3.1: Koroid Nevüsü: Benign Özellikler ve Takip
    builder.add_study_card_slide(
        title="KOROİD NEVÜSÜ: BENİGN KRİTERLER VE DOĞAL SEYİR",
        category="BÖLÜM 8.1.3: BENİGN TÜMÖRLER",
        subtitle="Toplumun %5'inde Görülen Melanositik Hamartom, Yüzeyel Drusen ve Güvenlik İşaretleri",
        cards=[
            {
                "card_title": "1. Epidemiyoloji ve Selim Morfoloji",
                "lead": "Erişkinlerin %5-8'inde Rastlantısal Bulgu",
                "items": [
                    "Kafkas ırkta rutin göz muayenelerinde en sık saptanan intraoküler melanositik lezyondur [s.255].",
                    "Genellikle asemptomatiktir; gözlük muayenesinde tesadüfen yakalanır.",
                    "Tipik olarak düz veya hafif kabarıktır (apikal kalınlık <1.5 – 2.0 mm; taban çapı <5 mm).",
                    "Rengi arduvaz grisi, kahverengi veya amelanositik (soluk sarı) olabilir."
                ],
                "footer": "Kalınlık <2 mm / Çap <5 mm / Arduvaz Grisi"
            },
            {
                "card_title": "2. Kronik ve Selim Olma İmzaları",
                "lead": "Drusen ve Halo Güvencesi",
                "items": [
                    "Yüzeyel Drusen: Lezyonun üzerinde sert veya yumuşak drusenlerin bulunması lezyonun yıllardır orada olduğunu gösterir [s.255].",
                    "RPE Değişiklikleri: Kronik RPE atrofisi veya hiperplazi sınırları lezyonun selim stabilitesini destekler.",
                    "Çevresel Halo: Lezyon etrafında depigmente sarı-beyaz bir halkanın bulunması nevüs lehine çok güçlü bir kanıttır.",
                    "Subretinal sıvı ve portakal pigmenti KESİNLİKLE BULUNMAZ."
                ],
                "footer": "Drusen (+) / Çevresel Halo (+) / Sıvı Yok"
            },
            {
                "card_title": "3. Standart Takip Protokolü",
                "lead": "Fotoğrafik ve OKT Tabanlı İzlem",
                "items": [
                    "İlk saptandığında yüksek çözünürlüklü renkli fundus fotoğrafı ve SD-OKT çekilerek arşivlenir [s.255].",
                    "3-6 ay sonra ilk kontrol yapılarak stabilite doğrulanır.",
                    "Daha sonra yılda bir kez fotoğrafik karşılaştırma ile taban çapı ve kalınlık artışı izlenir.",
                    "Malign transformasyon riski yılda 1/8000 civarındadır; gereksiz lazer veya cerrahiden kaçınılmalıdır."
                ],
                "footer": "Fotoğrafik Arşivleme / Yıllık Takip / Transformasyon 1/8000"
            }
        ]
    )

    # Slayt 8.1.3.2: Koroid Hemanjiomu: Sirkumskript vs Diffüz Formlar
    builder.add_study_card_slide(
        title="KOROİD HEMANJİOMU: SİRKUMSKRİPT VE DİFFÜZ FORMLAR",
        category="BÖLÜM 8.1.3: HEMANJİOM",
        subtitle="Vasküler Hamartom, Sturge-Weber Sendromu, 'Domates Çorbası' Fundusu ve B-Scan Yüksek Eko",
        cards=[
            {
                "card_title": "1. Sirkumskript Koroid Hemanjiomu (CCH)",
                "lead": "İzole Soliter Vasküler Kitle",
                "items": [
                    "Sistemik sendrom eşlik etmez; 30-50 yaşlarında görme azalmasıyla ortaya çıkar [s.255].",
                    "Lokalizasyon: Arka kutupta, foveaya veya optik diske yakın yerleşimli, yuvarlak/oval kitle.",
                    "Fundus Rengi: Tipik somon-portakal veya pembe-kırmızı renkli kubbe şeklinde kabarıklık.",
                    "Zamanla tümör damarlarından sızan kronik subretinal sıvı (eksüdatif dekolman) foveayı dekolle ederek görmeyi düşürür."
                ],
                "footer": "Somon-Portakal Rengi / Soliter / Sekonder Seröz Sıvı"
            },
            {
                "card_title": "2. Diffüz Koroid Hemanjiomu (DCH)",
                "lead": "Sturge-Weber Sendromu (Ensefalotrigeminal Anjiyomatozis)",
                "items": [
                    "Trigeminal sinirin V1/V2 trasesinde yüzde şarap lekesi (Nevus Flammeus / Port-wine stain) bulunur [s.256].",
                    "Koroid diffüz olarak aşırı kalınlaşmış, kıpkırmızı ve süngerimsi bir vasküler yatak halini almıştır.",
                    "'Domates Çorbası Fundusu' (Tomato ketchup fundus): Sağlam gözle karşılaştırıldığında göz dibi koyu parlak kırmızı parlar.",
                    "Konjenital veya erken çocukluk glokomu olguların %50'sinde tabloya eşlik eder."
                ],
                "footer": "Sturge-Weber / Şarap Lekesi / Domates Çorbası Fundusu"
            },
            {
                "card_title": "3. Ultrasonografi ve FFA İmzası",
                "lead": "A-Scan'de Yüksek İç Ekojenite (>%95)",
                "items": [
                    "Melanomdan ayıran en kritik test standart A-Scan USG'dir [s.256].",
                    "Hemanjiom geniş vasküler lümenler ve endotel duvarları içerdiğinden A-Scan'de >%95-100 aşırı yüksek iç eko verir.",
                    "FFA'da erken fazda aşırı hızlı koroidal hiperfloresans ve geç fazda lezyon boyanması izlenir.",
                    "ICG anjiyografisinde erken fazda yoğun vasküler parıldama, geç fazda ise tipik 'yıkanma' (wash-out) fenomeni görülür."
                ],
                "footer": "A-Scan Yüksek Eko (>%95) / ICG Wash-out Fenomeni"
            }
        ]
    )

    # Slayt 8.1.3.3: Koroid Hemanjiomunda Tedavi: Fotodinamik Tedavi (PDT)
    builder.add_study_card_slide(
        title="KOROİD HEMANJİOMUNDA TEDAVİ STANDARTLARI",
        category="BÖLÜM 8.1.3: PDT TEDAVİSİ",
        subtitle="Verteporfin Fotodinamik Tedavisi (PDT), Düşük Doz Brakiterapi ve Görme Restorasyonu",
        cards=[
            {
                "card_title": "1. Bir Numaralı Tercih: Fotodinamik Tedavi (PDT)",
                "lead": "Seçici Vasküler Tromboz Mucizesi",
                "items": [
                    "Verteporfin (Visudyne) 6 mg/m2 İV infüzyonu takiben 689 nm nonthermal lazer uygulanır [s.256].",
                    "Lazer hemanjiomun tüm tabanını kapsayacak spot çapında 83 saniye (50 J/cm2) verilir.",
                    "Endotel hücrelerinde reaktif serbest oksijen radikalleri oluşturarak tümör damarlarını seçici olarak pıhtılaştırır.",
                    "Üzerindeki nörosensoriyel retinaya ve fotoreseptörlere termal hasar vermez."
                ],
                "footer": "Verteporfin PDT / Seçici Tromboz / Retinayı Korur"
            },
            {
                "card_title": "2. Tedavi Yanıtı ve Sıvı Emilimi",
                "lead": "Subretinal Sıvının Hızla Çekilmesi",
                "items": [
                    "PDT sonrası tümör damarları hızla oklüde olur ve tümör kalınlığı haftalar içinde belirgin geriler [s.256].",
                    "Eksüdatif subretinal sıvı 1-3 ay içinde RPE pompalarınca tamamen emilir ve makula yatışır.",
                    "Hastaların %80'inden fazlasında görme keskinliğinde 2-4 sıra anlamlı artış sağlanır.",
                    "Yetersiz gerileyen geniş tümörlerde 3 ay sonra ikinci bir seans PDT güvenle tekrarlanabilir."
                ],
                "footer": "Sıvı Tamamen Çekilir / Görme 2-4 Sıra Artar"
            },
            {
                "card_title": "3. Dirençli Olgularda Radyoterapi",
                "lead": "Brakiterapi ve Dış Işınlama",
                "items": [
                    "Çok kalın (>5-6 mm) veya PDT'ye dirençli olgularda düşük doz plak radyoterapi (Ru-106 / I-125) uygulanabilir [s.256].",
                    "Apeks dozu 35-45 Gy düzeyinde tutularak tümör vaskülaritesi skleroze edilir.",
                    "Diffüz formda (Sturge-Weber) tüm koroidi tutan büllöz dekolmanlarda düşük doz eksternal radyoterapi veya proton tedavisi seçenektir.",
                    "Ayrıca oral Propranolol ve intravitreal anti-VEGF enjeksiyonları adjuvan olarak denenebilir."
                ],
                "footer": "Düşük Doz Plak (35-45 Gy) / Oral Propranolol Adjuvanı"
            }
        ]
    )

    # Slayt 8.1.3.4: Retinal Kapiller Hemanjiom (Von Hippel-Lindau / VHL)
    builder.add_study_card_slide(
        title="RETİNAL KAPİLLER HEMANJİOM VE VON HİPPEL-LİNDAU (VHL)",
        category="BÖLÜM 8.1.3: VHL SENDROMU",
        subtitle="VHL Gen Mutasyonu (3p25), Dev Besleyici Arter-Drenaj Veni ve Çoklu Organ Tümörleri",
        cards=[
            {
                "card_title": "1. VHL Geni ve Psödohipoksi Sinyali",
                "lead": "Otozomal Dominant Tümör Süpresör Defekti",
                "items": [
                    "3p25-26 kromozomundaki VHL geni mutasyonu sonucu pVHL proteini sentezlenemez [s.257].",
                    "Normalde HIF-alfa'yı yıkan pVHL olmayınca hücrede yalancı hipoksi (psödohipoksi) oluşur.",
                    "Sürekli ve kontrolsüz VEGF ve PDGF salgılanır; kılcal damarlar glomerüloid yumaklar halinde prolifere olur.",
                    "Sistemik Birliktelikler: Serebellar ve spinal hemanjiyoblastom, renal hücreli karsinom (RCC) ve feokromositoma."
                ],
                "footer": "VHL Geni / HIF-alfa Artışı / Serebellar Kitle / Feokromositoma"
            },
            {
                "card_title": "2. Klasik Oftalmoskopik Triad",
                "lead": "Kırmızı Glomerül ve İki Dev Damar",
                "items": [
                    "1. Kırmızı-Turuncu Yuvarlak Kitle: Periferik retinada sınırları keskin anjiyom nodülü [s.257].",
                    "2. Dilate Kıvrımlı Besleyici Arter: Optik diskten kitleye doğru uzanan dev kalibreli arter.",
                    "3. Tortuöz Drenaj Veni: Kitleden tekrar optik diske dönen aşırı genişlemiş ve kıvrımlı ven.",
                    "Tümörden sızan masif lipid eksüdası foveada toplanarak 'yıldız şeklinde makulopati' ve eksüdatif dekolman yapar."
                ],
                "footer": "Kırmızı Nodül + Dev Arter + Dev Ven Triadı"
            },
            {
                "card_title": "3. Tedavi: Erken Lazer, Kriyo ve Belzutifan",
                "lead": "Tümör Küçücükken Yok Edilmelidir",
                "items": [
                    "Küçük lezyonlar (<1.5 mm): Doğrudan 532 nm yeşil lazer veya sarı lazerle koagüle edilir [s.257].",
                    "Orta boy lezyonlar: Transskleral kriyoterapi veya verteporfin PDT ile kurutulur.",
                    "İleri olgularda intravitreal Anti-VEGF eksüdasyonu azaltmak için cerrahi öncesi uygulanır.",
                    "Modern Sistemik Devrim: HIF-2alfa inhibitörü Belzutifan (Welireg), VHL ile ilişkili tümörleri sistemik olarak küçülten ilk onaylı ilaçtır."
                ],
                "footer": "Lazer / Kriyoterapi / Belzutifan (HIF-2α İnhibitörü)"
            }
        ]
    )

    # Slayt 8.1.3.5: Retinal Vazoproliferatif Tümör (VPTR)
    builder.add_study_card_slide(
        title="RETİNAL VAZOPROLİFERATİF TÜMÖR (VPTR)",
        category="BÖLÜM 8.1.3: VASKÜLER TÜMÖR",
        subtitle="İnferotemporal Periferik Glial-Vasküler Kitle: Primer İdiyopatik vs Sekonder Formlar",
        cards=[
            {
                "card_title": "1. Patolojik Tanım ve Klinik Görünüm",
                "lead": "Benign Glial ve Reaktif Vasküler Proliferasyon",
                "items": [
                    "VHL'deki hemanjiomdan farklıdır; genetik değildir ve dev besleyici damarları yoktur [s.257].",
                    "Fundus muayenesinde pembe-sarı renkli, kabarık, vaskülarize periferik kitle izlenir.",
                    "Lezyonların >%80'i inferotemporal periferik retinada ora serrata komşuluğunda kümelenir.",
                    "Tümör çevresinde masif subretinal lipid eksüdasyonu ve seröz retina dekolmanı gelişir."
                ],
                "footer": "İnferotemporal Perifer / Genetik Değildir / Besleyici Damar Yok"
            },
            {
                "card_title": "2. Primer vs Sekonder Etyoloji",
                "lead": "Geçirilmiş Oküler Hastalık Zemininde Gelişim",
                "items": [
                    "Primer VPTR (%75): Bilinen bir göz hastalığı olmaksızın spontan ortaya çıkar; tek taraflıdır [s.257].",
                    "Sekonder VPTR (%25): Önceden geçirilmiş retina patolojileri zemininde reaktif olarak gelişir:",
                    "Retinitis Pigmentosa, geçirilmiş retina dekolmanı ameliyatı, oküler toksoplazmoz, pars planit veya Coat's.",
                    "Sekonder olgular multipl ve bilateral olma eğilimi taşır."
                ],
                "footer": "Primer (%75 İdiyopatik) vs Sekonder (RP/Dekolman Zemininde)"
            },
            {
                "card_title": "3. Tedavi Yaklaşımı",
                "lead": "Kriyoterapi, PDT ve Anti-VEGF",
                "items": [
                    "Küçük ve semptomsuz lezyonlar foveayı tehdit etmedikçe sadece izlenebilir [s.258].",
                    "Makulaya doğru ilerleyen lipid eksüdasyonu veya sıvı varlığında tedavi şarttır.",
                    "İlk Tercih: Çift dondurma-çözdürme (double freeze-thaw) transskleral kriyoterapidir.",
                    "Alternatifler: PDT veya Rutenyum-106 plak radyoterapisi; eksüdayı azaltmak için intravitreal Anti-VEGF / Deksametazon."
                ],
                "footer": "Çift Döngü Kriyoterapi / PDT / Plak Brakiterapi"
            }
        ]
    )

    # Slayt 8.1.3.6: Benign vs Malign Koroidal Kitleler Karşılaştırmalı Matrisi
    builder.add_split_comparison_slide(
        title="KOROİD KİTLELERİNİN BÜYÜK AYIRICI TANI MATRİSİ",
        category="BÖLÜM 8.1.3: KARŞILAŞTIRMA",
        subtitle="Melanom vs Nevüs vs Hemanjiom vs Koroid Metastazı Karşılaştırması",
        left_entity={
            "name": "KOROİD MELANOMU",
            "subtitle": "Malign Melanositik Kitle",
            "bullets": [
                "Renk & Şekil: Koyu kahve/gri; Bruch'u delerse MANTAR şeklinde [s.251].",
                "A-Scan Ekojenite: DÜŞÜK-ORTA İÇ REFLEKTİVİTE (<%50) ve akustik boşluk.",
                "Yüzey Belirteci: Parlak portakal pigmenti (lipofuksin) ve subretinal sıvı.",
                "Sistemik Risk: %50 Monozomi 3 ile karaciğer metastazı.",
                "Tedavi: Plak Radyoterapi (I-125) veya Enükleasyon [s.254]."
            ]
        },
        right_entity={
            "name": "HEMANJİOM & METASTAZ",
            "subtitle": "Benign Vasküler vs Sekonder Kanser",
            "bullets": [
                "Hemanjiom Rengi: Somon-portakal / pembe-kırmızı parlak kubbe [s.255].",
                "Hemanjiom A-Scan: AŞIRI YÜKSEK İÇ REFLEKTİVİTE (>%95) ve ICG wash-out.",
                "Metastaz Rengi: Krem-sarı, multifokal, lobüle, bilateral; meme/akciğer Ca.",
                "Metastaz A-Scan: Orta-yüksek düzensiz iç reflektivite.",
                "Hemanjiom Tedavi: Verteporfin Fotodinamik Tedavi (PDT) [s.256]."
            ]
        },
        bottom_takeaway="A-Scan ultrasonografide iç ekojenite düşükse Melanom; aşırı yüksekse (>%95) Hemanjiomdur; bu tek akustik ayrım tümör tipini kesinleştirir [s.252]."
    )

    # Slayt 8.1.3.7: Arka Segment Vasküler Tümörleri Karar Ağacı
    builder.add_decision_tree_slide(
        title="ARKA SEGMENT VASKÜLER TÜMÖRLERİ KARAR AĞACI",
        category="BÖLÜM 8.1.3: KARAR AĞACI",
        subtitle="Retina ve Koroidde Kırmızı-Turuncu Kitle Saptanan Hastada Protokol",
        root_label="RETİNA VEYA KOROİDDE VASKÜLER / KIRMIZI-TURUNCU KİTLE SAPTANDI",
        branches=[
            {
                "label": "1. Somon Renkli Koroid Kitlesi / Yüksek Eko",
                "criteria": "A-Scan'de >%95 iç ekojenite, ICG'de wash-out, subretinal sıvı [s.255].",
                "action": "Koroid Hemanjiomu: Verteporfin Fotodinamik Tedavi (PDT) uygulanır; sıvı emilir."
            },
            {
                "label": "2. Kırmızı Retinal Nodül + Dev Arter/Ven",
                "criteria": "Periferik retinada glomerüloid yumak, optik diskten gelen dev besleyici damarlar [s.257].",
                "action": "Retinal Kapiller Hemanjiom (VHL): Acil Lazer/Kriyoterapi; kranial/spinal MRG ve batın BT ile VHL taraması."
            },
            {
                "label": "3. İnferotemporal Sarı-Pembe Kitle + Eksüda",
                "criteria": "Besleyici damar yok, ora serratada, masif lipid eksüdası, RP veya dekolman öyküsü [s.257].",
                "action": "Retinal Vazoproliferatif Tümör (VPTR): Çift döngü transskleral kriyoterapi veya PDT."
            }
        ],
        bottom_rule="Retinal kapiller hemanjiom saptanan bir hastada gözü tedavi etmek yetmez; beyin sapı hemanjiyoblastomu ve böbrek kanseri açısından tüm sistem acilen taranmalıdır [s.257]."
    )

    # Slayt 8.1.3.8: Aktif Hatırlama & Board Sınavı Vakası: Sturge-Weber Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: STURGE-WEBER",
        category="BÖLÜM 8.1.3: AKTİF HATIRLAMA",
        subtitle="7 Yaşında Çocukta Yüzde Şarap Lekesi, Tek Taraflı Glokom ve 'Domates Çorbası' Fundusu",
        vignette="7 yaşında erkek çocuk, sol gözünde son aylarda görme azalması ve göz küresinde hafif büyüme fark edilmesi üzerine getiriliyor. Fizik muayenede sol yüz yarısında trigeminal sinirin V1 ve V2 dallarını tutan koyu kırmızı-mor renkli porto şarabı lekesi (Nevus Flammeus) izleniyor. Sol göz içi basıncı (GİB) 28 mmHg, kornea çapı 12.5 mm (hafif buftalmus). Biyomikroskopide sol episkleral damarlarda belirgin konjesyon izleniyor. Oftalmoskopide sağ göz dibi tamamen normal pembelikteyken, sol göz dibi diffüz olarak aşırı koyu kırmızı renkte parlıyor ('domates çorbası fundusu' - tomato catsup fundus). SD-OKT'de sol fovea altında sığ seröz subretinal sıvı ve koroidde diffüz devasa kalınlaşma saptanıyor. B-Scan USG'de sol koroidin difüz olarak kalınlaştığı ve A-Scan'de iç ekojenitenin %100 yüksek olduğu belgeleniyor.",
        differentials=[
            "Sturge-Weber Sendromuna Bağlı Diffüz Koroid Hemanjiomu ve Sekonder Glokom (Karakteristik triad).",
            "Sirkumskript Koroid Hemanjiomu (Fasiyal hemanjiom eşlik etmez, lezyon soliter ve yuvarlaktır).",
            "Koroid Melanomu (A-Scan'de düşük ekojenite verir, domates çorbası görünümü yapmaz).",
            "Retinoblastom (7 yaşında buftalmus ve domates çorbası fundusu ile gelmez, kalsifiye kitle yapar)."
        ],
        decision="1. Klinik Teşhis: Sturge-Weber Sendromu (Ensefalotrigeminal Anjiyomatozis) zemininde Diffüz Koroid Hemanjiomu ve Glokom.\n2. Nörolojik Değerlendirme: Leptomeningeal anjiyomatozisi ve intrakranial kalsifikasyonları dışlamak için Kontrastlı Kranial MRG çekilmelidir.\n3. Glokom Tedavisi: Aköz dışa akımındaki episkleral venöz basınç artışına yönelik medikal tedavi (Topikal Latanoprost ve Dorzolamid/Timolol) başlanmalı; dirençte cerrahi (Trabekülektomi/Tüp) planlanmalıdır.\n4. Retina Tedavisi: Foveal seröz dekolmanı kurutmak için seçici alanlara Verteporfin Fotodinamik Tedavi (PDT) veya düşük doz radyoterapi düşünülmelidir.",
        board_trap="Yüzünde şarap lekesi olan bir çocukta kırmızı fundus görünümünü 'normal vasküler varyant' sanıp göz ardı etmek sinsice ilerleyen diffüz koroid hemanjiomunu ve konjenital glokomu atlamak anlamına gelir; domates çorbası fundusu Sturge-Weber'in gözdeki patognomonik imzasıdır [s.256]."
    )

    print(f" -> Bölüm 8 (Retina ve Koroid Tümörleri) Tamamlandı: 26 Slayt Eklendi.")
