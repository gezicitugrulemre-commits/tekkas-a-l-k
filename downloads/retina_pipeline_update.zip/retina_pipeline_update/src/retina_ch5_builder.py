# -*- coding: utf-8 -*-
r"""
retina_ch5_builder.py — Bölüm 5: Retina Dekolmanı ve Periferik Retina Patolojileri (41 Slayt)
========================================================================================
Kitap Sayfaları: 156 – 177
Alt Başlıklar:
  5.0   Bölüm 5 Çalışma Yol Haritası (1 slayt)
  5.1.1 Periferik Retina Dejenerasyonları, Lattice, Snail-track, Retinoskizis ve At Nalı Yırtıklar (8 slayt)
  5.1.2 Profilaktik Bariyer Lazer Endikasyonları ve Teknikleri (7 slayt)
  5.2.1 Regmatojen Retina Dekolmanı (RRD), Lincoff Kuralları, Pnömatik, Sklera Çökertme ve PPV (9 slayt)
  5.2.2 Traksiyonel (TRD) ve Eksüdatif (ERD) Retina Dekolmanları (8 slayt)
  5.2.3 Proliferatif Vitreoretinopati (PVR) Hücresel Kaskadı, Evreleme ve Cerrahi Yönetim (8 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_5(builder: RetinaStudyDeckBuilder):
    """Bölüm 5'e ait 41 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 5 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=5,
        title="RETİNA DEKOLMANI VE PERİFERİK RETİNA PATOLOJİLERİ",
        page_range="Sayfa 156 – 177",
        subtitle="Periferik Dejenerasyonlar, Yırtıklar, RRD, Lincoff Kuralları, TRD, ERD ve PVR Cerrahi Kaskadı",
        cards=[
            {
                "title": "1. Periferik Lezyonlar & Yırtıklar",
                "color": PPTXPalette.BLUE,
                "lead": "Traksiyon & Yırtık Dinamiği",
                "items": [
                    "Masum Lezyonlar: Parke taşı dejenerasyonu, periferik kistoid dejenerasyon, jeneralize drusen.",
                    "Yüksek Riskli Lezyonlar: Lattice dejenerasyonu, snail-track, at nalı (flep) yırtıklar.",
                    "Dejeneratif Retinoskizis: İç/dış yaprak yarılması; mutlak skotom ile RRD'den (rölatif) ayrılır.",
                    "Klinik Semptomlar: Ani fotopsi (ışık çakması) ve taze uçuşan cisimler (Schaffer belirtisi)."
                ],
                "footer": "Lattice -> At Nalı Yırtık -> RRD"
            },
            {
                "title": "2. Profilaktik Bariyer Lazer",
                "color": PPTXPalette.AMBER,
                "lead": "Yırtık İzolasyonu & Koruma",
                "items": [
                    "Kesin Endikasyon: Semptomatik at nalı yırtıklar ve diyaliz derhal 360° bariyerlenmelidir.",
                    "Lazer Parametreleri: 532 nm yeşil lazer, 200-300 μm spot, 0.1-0.2 sn, hafif gri-beyaz yanık.",
                    "Bariyer Kuralı: En az 3 sıra birbirine bitişik koagülasyon; anterior sınır ora serrataya dayanmalıdır.",
                    "Asemptomatik Olgular: Yuvarlak atrofik delikler genellikle tedavi gerektirmez (fellow eye hariç)."
                ],
                "footer": "3 Sıra Bariyer -> Ora Serrata Kilidi"
            },
            {
                "title": "3. RRD & Cerrahi Strateji",
                "color": PPTXPalette.RED,
                "lead": "Lincoff Kuralları & Cerrahi",
                "items": [
                    "Lincoff Kuralları: Sıvı konfigürasyonuna göre primer yırtığın saat kadranını %98 doğrulukla bulur.",
                    "Pnömatik Retinopeksi: Tek üst kadranda yırtık, PVR yokluğunda gaz (SF6/C3F8) enjeksiyonu ve pozisyon.",
                    "Sklera Çökertme: Genç, miyop ve fakik hastalarda lensi koruyarak skleral indentasyon sağlar.",
                    "Pars Plana Vitrektomi (PPV): Psödofakik RRD, multiple/posterior yırtıklar ve erken PVR'de altın standart."
                ],
                "footer": "Lincoff -> PR / Buckle / PPV"
            },
            {
                "title": "4. TRD, ERD & PVR Kaskadı",
                "color": PPTXPalette.GREEN,
                "lead": "Hücresel Göç & Yeniden Yapışma",
                "items": [
                    "TRD: PDR zemininde konkav traksiyonel membranlar; ora serrataya uzanmaz; yırtık gelişirse kombine olur.",
                    "ERD: Shifting (yer değiştiren) sıvı; VKH veya tümör kaynaklıdır; RPE pompa bozukluğu esastır.",
                    "PVR Hücresel Kaskadı: RPE göçü, epitelyal-mezenkimal geçiş (EMT), miyofibroblastik kontraksiyon.",
                    "PVR Cerrahisi: Titiz membran soyma, bimanüel diseksiyon, retinektomi ve uzun süreli silikon yağı."
                ],
                "footer": "RPE Göçü -> Star Fold -> Retinektomi"
            }
        ]
    )

    # =========================================================================
    # 5.1.1: PERİFERİK RETİNA DEJENERASYONLARI VE YIRTIKLAR (8 Slayt)
    # =========================================================================

    # Slayt 5.1.1.1: Periferik Retinal Anatomi & Ora Serrata Sınırları
    builder.add_study_card_slide(
        title="PERİFERİK RETİNA ANATOMİSİ VE ORA SERRATA YAPISI",
        category="BÖLÜM 5.1.1: TEMEL ANATOMİ",
        subtitle="Ora Serrata, Dentate Çıkıntılar, Vitreus Tabanı ve Periferik Zayıflık Hatları",
        cards=[
            {
                "card_title": "1. Ora Serrata & Dentate Morfolojisi",
                "lead": "Retina-Siliyer Cisim Geçiş Hattı",
                "items": [
                    "Ora serrata, nörosensoriyel retinanın pars plana siliyer epiteli ile kaynaştığı ön sınırdır [s.156].",
                    "Dentate çıkıntılar nazalde daha belirgindir; temporalde ise ora serrata hattı daha düz seyreder.",
                    "Ora bay (koy) bölgeleri nadiren yırtıkla karışabilir ancak fizyolojik anatomik varyantlardır.",
                    "Ora serrata hizasında retina tek sıra pigmente olmayan siliyer epitele dönüşerek sonlanır."
                ],
                "footer": "Nazal Çıkıntılı / Temporal Düz Hat"
            },
            {
                "card_title": "2. Vitreus Tabanı Sınırları & Dinamiği",
                "lead": "En Güçlü Vitreoretinal Yapışıklık",
                "items": [
                    "Vitreus tabanı, ora serratanın 2 mm anteriorundan 3-4 mm posterioruna uzanan 5-6 mm'lik çemberdir [s.156].",
                    "Kollajen fibriller iç limitan zarı (İLM) delerek Müller hücrelerinin bazal laminasına sıkıca tutunur.",
                    "Arka vitreus dekolmanı (AVD) vitreus tabanının arka sınırında durur; tabanın kendisi dekolle olamaz.",
                    "AVD sırasında vitreus tabanı arka sınırında oluşan aşırı traksiyon, at nalı yırtıkların temel nedenidir."
                ],
                "footer": "Ora ± 2-4 mm / Güçlü Kollajen Kilidi"
            },
            {
                "card_title": "3. Periferik Retinal Kalınlık & Vaskülarizasyon",
                "lead": "Ekstrem Periferin Fizyolojik Kırılganlığı",
                "items": [
                    "Ekvatorun anteriorunda retina kalınlığı 100-120 μm'ye kadar incelir; kapiller ağ belirgin seyrekleşir [s.157].",
                    "Ora serratanın hemen gerisindeki 1 mm'lik bant tamamen avaskülerdir; difüzyonla beslenir.",
                    "Bu avasküler ve ince yapı, periferik retinayı kistik dejenerasyonlara ve atrofik deliklere yatkın kılar.",
                    "İndirekt oftalmoskopi ve sklera depresyonu olmaksızın periferik sınırın tam muayenesi olanaksızdır."
                ],
                "footer": "Avasküler Sınır / Sklera Depresyonu Şart"
            }
        ]
    )

    # Slayt 5.1.1.2: Masum vs Yüksek Riskli Periferik Dejenerasyonlar
    builder.add_split_comparison_slide(
        title="PERİFERİK DEJENERASYONLAR: MASUM vs YÜKSEK RİSKLİ",
        category="BÖLÜM 5.1.1: AYIRICI TANI",
        subtitle="Retina Dekolmanı Riski Taşımayan İntrinsik Lezyonlar vs Bariyer Lazer Adayı Patolojiler",
        left_entity={
            "name": "MASUM DEJENERASYONLAR (TEDAVİ GEREKMEZ)",
            "subtitle": "Dekolman Riski Sıfıra Yakın Olan Periferik Bulgular",
            "bullets": [
                "Parke Taşı (Paving-stone) Dejenerasyonu: Koryokapillaris atrofisine bağlı sınırları pigmente sarı-beyaz adacıklar [s.157].",
                "Periferik Kistoid Dejenerasyon: Ora serrata komşuluğunda mikro-boşluklar; erişkinlerin %100'ünde bulunur.",
                "Drusen & Bal Peteği (Honeycomb) Dejenerasyonu: Periferik yaşlanma bulgusu; vitreus traksiyonu oluşturmaz.",
                "Konjenital RPE Hipertrofisi (CHRPE): Düz, keskin sınırlı hiperpigmente lezyon; halo içerebilir.",
                "Klinik Kural: Bu lezyonlar asla profilaktik lazer veya cerrahi müdahale gerektirmez [s.157]."
            ]
        },
        right_entity={
            "name": "YÜKSEK RİSKLİ DEJENERASYONLAR (TAKİP / LAZER)",
            "subtitle": "Vitreoretinal Traksiyon ve Yırtık Oluşturma Potansiyeli",
            "bullets": [
                "Lattice (Kafes) Dejenerasyonu: Retina incelmesi, sıvılaşmış lakün ve kenarlarda güçlü vitreus yapışıklığı [s.158].",
                "Snail-Track (Salyangoz İzi) Dejenerasyonu: Kar tanesi benzeri parlak kordon; lattice'in erken varyantıdır.",
                "At Nalı (Flep) Yırtık: AVD sırasında flep apeksinden çekilen traksiyonel tam kat yırtık; en riskli antitedir.",
                "Retinal Diyaliz: Ora serrata ayrışması; gençlerde ve künt travmalarda inferotemporalde sık görülür.",
                "Klinik Kural: Semptom varlığında veya fellow eye riskinde mutlaka koruyucu profilaksi gerekir [s.158]."
            ]
        },
        bottom_takeaway="Parke taşı dejenerasyonunda retina RPE'ye sıkıca yapışmıştır, asla dekolmana yol açmaz; lazer uygulamak dokuyu yırtarak iatrojenik dekolman riski doğurur [s.157]."
    )

    # Slayt 5.1.1.3: Lattice Dejenerasyonu Histopatolojisi ve Yırtık Dinamiği
    builder.add_study_card_slide(
        title="LATTİCE (KAFES) DEJENERASYONUNUN HİSTOPATOLOJİSİ",
        category="BÖLÜM 5.1.1: HİSTOPATOLOJİ",
        subtitle="İç Retinal Atrofi, Sklerotik Damarlar ve Kenar Vitreus Traksiyonu Triadı",
        cards=[
            {
                "card_title": "1. Histolojik Değişiklikler & Skleroz",
                "lead": "İç Katman Kaybı ve Glial Doku",
                "items": [
                    "Lattice lezyonu alanında iç retina katmanları aşırı incelmiş ve iç limitan zar (İLM) kaybolmuştur [s.158].",
                    "Lezyon merkezindeki retinal damarlar lümenlerini kaybederek beyaz dallanmış çizgiler (sklerotik kafes) halini alır.",
                    "RPE'de fokal hipertrofi ve hiperpigmentasyon eşlik eder; lezyon sınırları belirginleşir.",
                    "Toplumun %6-8'inde görülür; regmatojen retina dekolmanlarının %30-40'ından sorumludur."
                ],
                "footer": "İLM Yokluğu / Lümen Sklerozu"
            },
            {
                "card_title": "2. Üzerindeki Sıvılaşmış Vitreus Cebi",
                "lead": "Lakün Oluşumu ve İzolasyon Kaybı",
                "items": [
                    "Lattice alanının tam üzerinde vitreus jeli likefiye (sıvılaşmış) bir cep (lakün) oluşturur [s.158].",
                    "Lezyon tabanındaki yuvarlak atrofik deliklerden bu cepteki sıvı sızarak lokal yavaş dekolman yapabilir.",
                    "Ancak bu yuvarlak delikler genellikle aktif vitreus traksiyonu içermez ve sınırlı kalır.",
                    "Genç miyoplarda atrofik delik kaynaklı RRD'ler sinsi seyreder ve subretinal sınır pigment çizgisi geliştirir."
                ],
                "footer": "Likefiye Vitreus Cebi / Atrofik Delik"
            },
            {
                "card_title": "3. Kenar Traksiyonu ve At Nalı Yırtık",
                "lead": "AVD Sırasında Gelişen Felaket",
                "items": [
                    "Lattice lezyonunun sınırlarında (özellikle arka ve yan kenarlarda) vitreus son derece sıkı yapışıktır [s.158].",
                    "Yaşla veya miyopiyle AVD gelişirken, likefiye gövde çöker ancak lattice kenarını kuvvetle çeker.",
                    "Bu traksiyon lattice'in arka sınırında geniş bir U şeklinde at nalı (flep) yırtık oluşturur.",
                    "Semptomatik at nalı yırtık gelişimini takiben gün içinde büllöz ve hızla ilerleyen RRD oluşur."
                ],
                "footer": "Kenar Yapışıklığı -> Flep Yırtığı -> Büllöz RRD"
            }
        ]
    )

    # Slayt 5.1.1.4: Dejeneratif Retinoskizis vs Regmatojen Retina Dekolmanı
    builder.add_split_comparison_slide(
        title="DEJENERATİF RETİNOSKİZİS vs REGMATOJEN RETİNA DEKOLMANI",
        category="BÖLÜM 5.1.1: AYIRICI TANI",
        subtitle="Nörosensoriyel Retinanın Katman Yarılması (Skizis) vs Subretinal Sıvı Dekolmanı (RRD)",
        left_entity={
            "name": "DEJENERATİF RETİNOSKİZİS (SENİL)",
            "subtitle": "Dış Pleksiform Katmanda İntraretinal Yarılma",
            "bullets": [
                "Morfoloji: Hareketsiz, gergin, kubbe şeklinde, şeffaf ve pürüzsüz yüzey [s.159].",
                "Lokalizasyon: %70 inferotemporal perifer; bilateral olma oranı %50-80'dir.",
                "Görme Alanı: Mutlak (absolü) skotom verir (nöronal akson iletimi kalıcı olarak kopmuştur).",
                "Baskı Testi / Lazer: Skizis sahasına lazer atıldığında dış yaprak beyazlaşır (lazer yanıtı pozitiftir).",
                "PVR Gelişimi: Sıfırdır; koroidle vitreus arasında serbest hücre iletişimi yoktur [s.159]."
            ]
        },
        right_entity={
            "name": "REGMATOJEN RETİNA DEKOLMANI (RRD)",
            "subtitle": "Nörosensoriyel Retinanın RPE'den Tam Kat Ayrılması",
            "bullets": [
                "Morfoloji: Dalgalanan (undüle), katlantılı, opak ve göz hareketleriyle sallanan büllöz membran [s.159].",
                "Lokalizasyon: Yırtığın bulunduğu kadrana bağlıdır (Lincoff kuralları).",
                "Görme Alanı: Rölatif skotom verir (ışık yoğunluğu artırıldığında retina yanıt verebilir).",
                "Baskı Testi / Lazer: Subretinal sıvı nedeniyle RPE'ye ısı iletilemez, lazer beyazlaşması oluşmaz.",
                "PVR Gelişimi: Yüksek risk taşır; yırtıktan sızan RPE hücreleri vitreusa dökülür [s.159]."
            ]
        },
        bottom_takeaway="Skizis mutlak skotom ve gergin şeffaf kubbe ile RRD'den ayrılır; skiziste her iki yaprakta da yırtık oluşmadıkça asla cerrahi veya lazer uygulanmaz [s.159]."
    )

    # Slayt 5.1.1.5: Periferik Retina Atlası: At Nalı Yırtık ve Operküllü Delik
    p157_img = builder.get_image_for_page(157)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: PERİFERİK YIRTIK MORFOLOJİLERİ",
        category="BÖLÜM 5.1.1: ATLAS",
        subtitle="At Nalı Flep Yırtığı, Serbest Operküllü Delik ve Vitreus Tabanı Traksiyonu",
        image_path=p157_img if p157_img else None,
        caption="Şekil 5.1: Ekvatoral periferde vitreus traksiyonuna bağlı gelişen flepli at nalı yırtık ve subretinal sıvı sızıntısı [Kitap s.157].",
        key_findings=[
            "At nalı yırtığın apeksi (tepe noktası) merkeze, tabanı ise ora serrataya doğru yönelmiştir.",
            "Vitreus lifleri apekse tutunmaya devam eder; her göz hareketinde yırtığı dinamik olarak açar.",
            "Operküllü delikte ise vitreus traksiyonu o kadar güçlüdür ki doku parçasını tamamen koparıp vitreusa almıştır.",
            "Operkül koptuktan sonra delik kenarındaki aktif traksiyon sona erer; dekolman riski at nalına göre çok daha düşüktür."
        ],
        differentials=[
            "At Nalı Yırtık: Devam eden dinamik traksiyon -> Yüksek RRD riski (%30-50).",
            "Operküllü Delik: Traksiyonsuz serbest delik -> Düşük RRD riski (<%5).",
            "Atrofik Yuvarlak Delik: Vitreus yapışıklığı olmaksızın lezyon içi doku erimesi."
        ],
        clinical_pearl="Hastanın taze ışık çakması (fotopsi) tarif ettiği dönemde saptanan at nalı yırtık bir retina acilidir; saatler içinde subretinal sıvı göllenerek cerrahi dekolmana dönüşür [s.157]."
    )

    # Slayt 5.1.1.6: Semptomatik vs Asemptomatik Yırtık Karşılaştırması
    builder.add_split_comparison_slide(
        title="YIRTIK DİNAMİĞİ: SEMPTOMATİK vs ASEMPTOMATİK",
        category="BÖLÜM 5.1.1: KLİNİK KARŞILAŞTIRMA",
        subtitle="Akut AVD Belirtileri Olan Yırtıklar vs Rutin Muayenede Tesadüfen Yakalanan Delikler",
        left_entity={
            "name": "AKUT SEMPTOMATİK YIRTIK (FOTOPSİ + UÇUŞMA)",
            "subtitle": "Klinik Acil — Yüksek Dekolman Riski",
            "bullets": [
                "Semptomlar: Yeni başlayan şimşek çakması (fotopsi), yüzlerce siyah nokta ve örümcek ağı hissi [s.160].",
                "Fizik Muayene: Schaffer belirtisi (ön vitreusta tütün tozu / serbest pigment hücreleri) mevcuttur.",
                "Doğal Seyir: Tedavi edilmezse 6 hafta içinde %35-50 oranında klinik regmatojen dekolmana ilerler.",
                "Klinik Yaklaşım: Aynı gün içinde 360 derece bariyer lazer fotokoagülasyonu şarttır.",
                "Takip: 1 hafta ve 1 ay sonra lazer skar olgunlaşması kontrol edilmelidir [s.160]."
            ]
        },
        right_entity={
            "name": "ASEMPTOMATİK YIRTIK VEYA DELİK",
            "subtitle": "Kronik Denge — Düşük Dekolman Riski",
            "bullets": [
                "Semptomlar: Hasta tamamen semptomsuzdur; gözlük muayenesinde tesadüfen saptanır [s.160].",
                "Fizik Muayene: Vitreus hücreleri yoktur; lezyon çevresinde pigment halkası (doğal bariyer) olabilir.",
                "Doğal Seyir: Klinik dekolman riski %2-5'in altındadır; çoğu olguda traksiyon sönmüştür.",
                "Klinik Yaklaşım: Genellikle tedavi gerekmez; hastaya AVD ve dekolman semptomları öğretilerek izlenir.",
                "İstisna: Afakik/psödofakik göz, diğer gözde RRD öyküsü veya yüksek miyopi varsa profilaksi uygulanır [s.160]."
            ]
        },
        bottom_takeaway="Akut AVD semptomları ile gelen hastada ön vitreusta tek bir pigment hücresi (Schaffer pozitif) bile görülse, periferde gizli bir yırtık olduğu kabul edilmeli ve sklera depresyonuyla aranmalıdır [s.160]."
    )

    # Slayt 5.1.1.7: Periferik Lezyon Değerlendirme & Triyaj Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="PERİFERİK RETİNAL LEZYON VE YIRTIK YÖNETİM PROTOKOLÜ",
        category="BÖLÜM 5.1.1: AKIŞ ŞEMASI",
        subtitle="Akut Semptomla Başvuran Hastada Adım Adım Muayene ve Girişim Triyajı",
        steps=[
            {
                "num": "1",
                "title": "Genişletilmiş Fundus & Biyomikroskopi",
                "desc": "Tam midriyazis sağlanır; Goldman 3-aynalı lens veya geniş açılı temassız lenslerle perifer taranır [s.160].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Schaffer Belirtisi & Vitreus Taraması",
                "desc": "Ön vitreusta serbest RPE pigmentleri (tütün tozu) veya eritrosit varlığı araştırılır; yırtık lehinedir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "360° Sklera Depresyonu Muayenesi",
                "desc": "İndirekt oftalmoskop eşliğinde ora serrataya kadar tüm perifer çöktürülerek gizli yırtıklar taranır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Acil Bariyer Lazer Uygulaması",
                "desc": "Saptanan at nalı yırtık veya diyalizin etrafı en az 3 sıra bariyer lazerle ora serrataya kilitlenir [s.161].",
                "status": "success"
            }
        ],
        bottom_takeaway="Vitreus kanaması nedeniyle periferi görülemeyen akut AVD hastalarında ultrasonografi (B-Scan) zorunludur; yırtık veya dekolman dışlanamazsa hasta 48 saatte bir USG ile izlenir [s.160]."
    )

    # Slayt 5.1.1.8: Aktif Hatırlama & Board Sınavı Vakası: Genç Miyopta Akut Fotopsi
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: PERİFERİK YIRTIK",
        category="BÖLÜM 5.1.1: AKTİF HATIRLAMA",
        subtitle="26 Yaşında -5.50 D Miyop Hastada Dün Gece Başlayan Şimşek Çakması ve Uçuşmalar",
        vignette="26 yaşında bilgisayar mühendisi erkek hasta, dün akşam sol gözünün temporal periferinde aniden başlayan parlak ışık çakmaları (fotopsi) ve önünde siyah kurum yağması gibi yüzlerce uçuşan nokta şikayetiyle acile başvuruyor. Kırma kusuru her iki gözde -5.50 D miyopi. Görme keskinliği sol gözde 1.0 tam. Biyomikroskopide ön kamarada hücre yok ancak retrolental ön vitreus aralığında 2+ ince kahverengi pigment hücresi (Schaffer belirtisi) saptanıyor. B-Scan USG'de arka vitreus dekolmanı ile uyumlu ekojenik membran izleniyor.",
        differentials=[
            "Akut Semptomatik At Nalı Yırtık (Schaffer pozitifliği ve miyopi zemininde en kuvvetli tanı).",
            "Komplike Olmamış Fizyolojik Arka Vitreus Dekolmanı (Schaffer negatiftir, serbest RPE hücresi görülmez).",
            "İnflamatuar Arka Üveit / Vitrit (Pigment değil inflamatuar lökosit hücreleri bulunur, optik disk hiperemiktir).",
            "Vitreus Kanaması / Retinal Ven Dal Tıkanıklığı (Ön planda eritrositler izlenir, fundusta alev kanamalar vardır)."
        ],
        decision="1. Yaklaşım: Derhal 360 derece sklera depresyonu ile periferik retina muayenesi yapılmalıdır.\n2. Bulgularda: Saat 1:00 hizasında vitreus apekse yapışık taze at nalı flep yırtığı saptandı.\n3. Tedavi: Vakit kaybetmeksizin aynı seansta 532 nm yeşil lazer ile yırtığın etrafına 3 sıra çepeçevre bariyer fotokoagülasyon uygulanmalıdır.",
        board_trap="Bu hastada 'görme 1.0 tam, retinada dekolman yok' diyerek hastayı kontrole çağırmak en ağır malpraktis nedenidir; Schaffer pozitif semptomatik at nalı yırtıklar 24-48 saat içinde büllöz dekolmana ilerler [s.161]."
    )

    # =========================================================================
    # 5.1.2: PROFİLAKTİK BARİYER LAZER ENDİKASYONLARI VE TEKNİKLERİ (7 Slayt)
    # =========================================================================

    # Slayt 5.1.2.1: Profilaktik Tedavi Endikasyonları Matrisi
    builder.add_study_card_slide(
        title="PROFİLAKTİK BARİYER TEDAVİSİ ENDİKASYON MATRİSİ",
        category="BÖLÜM 5.1.2: ENDİKASYONLAR",
        subtitle="Hangi Lezyon Kesin Tedavi Edilmeli, Hangisi Sadece Takip Edilmelidir?",
        cards=[
            {
                "card_title": "1. Kesin Tedavi Endikasyonları",
                "lead": "Derhal Lazer / Kriyo Gerektirenler",
                "items": [
                    "Semptomatik at nalı (flep) yırtıklar (büyüklüğüne bakılmaksızın aynı gün) [s.161].",
                    "Semptomatik veya asemptomatik akut retinal diyalizler.",
                    "Diğer gözünde (fellow eye) dev yırtık veya RRD öyküsü olan gözdeki at nalı yırtık veya lattice.",
                    "Katarakt cerrahisi planlanan yüksek miyop gözdeki semptomatik lezyonlar."
                ],
                "footer": "Semptomatik Flep / Diyaliz / Fellow Eye"
            },
            {
                "card_title": "2. Rölatif (Tartışmalı) Endikasyonlar",
                "lead": "Kişiselleştirilmiş Klinik Karar",
                "items": [
                    "Asemptomatik at nalı yırtıklar (özellikle psödofakik veya yüksek miyop olgularda) [s.161].",
                    "Diğer gözünde RRD hikayesi olan hastanın asemptomatik lattice dejenerasyonu.",
                    "Geniş alana yayılan ve üzerinde subretinal sıvı halkası bulunan atrofik delikler.",
                    "Sağlık merkezine acil ulaşımı kısıtlı olan pilot, dalgıç veya sporcu hastalar."
                ],
                "footer": "Yüksek Riskli Meslek / Psödofaki / Geniş Sıvı"
            },
            {
                "card_title": "3. Tedavi Gerektirmeyen Durumlar",
                "lead": "Gereksiz Lazerden Kaçınılması Gerekenler",
                "items": [
                    "Diğer gözü sağlıklı olan asemptomatik hastadaki izole lattice dejenerasyonu [s.162].",
                    "Asemptomatik operküllü delikler (traksiyon tamamen ortadan kalkmıştır).",
                    "Parke taşı, kistoid dejenerasyon veya CHRPE gibi masum dejenerasyonlar.",
                    "Pigmente sınırla çevrili (demarkasyon hattı oluşmuş) eski stabil atrofik delikler."
                ],
                "footer": "Masum Lezyon / Pigmente Demarkasyon"
            }
        ]
    )

    # Slayt 5.1.2.2: Bariyer Lazer Fotokoagülasyon Parametreleri ve Tekniği
    builder.add_study_card_slide(
        title="BARİYER LAZER FOTOKOAGÜLASYON PARAMETRELERİ VE TEKNİĞİ",
        category="BÖLÜM 5.1.2: CERRAHİ TEKNİK",
        subtitle="532 nm Yeşil Lazer Ayarları, Spot Boyutu, Yanık Yoğunluğu ve Anatomik Kilit",
        cards=[
            {
                "card_title": "1. Cihaz ve Lazer Parametreleri",
                "lead": "RPE Termal Koagülasyon Ayarları",
                "items": [
                    "Dalga Boyu: 532 nm frekansı katlanmış Nd:YAG (yeşil lazer) standarttır [s.162].",
                    "Spot Boyutu: 200 – 300 μm (kontakt lens büyütmesine göre retinada 300-450 μm olur).",
                    "Ekspozisyon Süresi: 0.10 – 0.20 saniye (ağrıyı azaltmak ve kontrollü yanık için).",
                    "Güç Ayarı: 150 – 350 mW (hastanın pigmentasyonuna göre hafif gri-beyaz reaksiyon elde edilecek düzey)."
                ],
                "footer": "532 nm / 200-300 μm / 0.1 sn / Gri-Beyaz"
            },
            {
                "card_title": "2. Uygulama Mimarisi & Sıra Sayısı",
                "lead": "En Az 3 Sıra Kesintisiz Bariyer",
                "items": [
                    "Yırtığın sağlam retina ile birleştiği sınırdan en az 1.5 – 2.0 mm uzaktan başlanmalıdır [s.162].",
                    "En az 3 sıra, ideali 4 sıra birbirinin arasına geçen (tuğla örgüsü şeklinde) koagülasyon atılır.",
                    "Aşırı beyaz ve patlayıcı kavitasyon yanıklarından kaçınılmalıdır (Bruch zarını yırtıp KNV yapabilir).",
                    "Yanıklar arasındaki mesafe yarım spot çapı olmalı; confluent (birleşik) aşırı nekroz yapılmamalıdır."
                ],
                "footer": "3-4 Sıra Tuğla Örgüsü / 1.5 mm Güvenlik"
            },
            {
                "card_title": "3. Anterior Sınır & Ora Serrata Kilidi",
                "lead": "En Sık Yapılan Cerrahi Hata",
                "items": [
                    "Yırtığın yalnızca arka (posterior) kenarını çevrelemek kesinlikle yetersizdir [s.163].",
                    "Lazer bariyeri her iki yan boynuzdan öne doğru uzatılarak mutlaka ora serrataya kadar kilitlenmelidir.",
                    "Ön sınır ora serrataya dayanmazsa, sıvı yanlardan sızarak anterior dekolmana yol açar.",
                    "Skar dokusunun tam yapışma gücüne (koryoretinal adezyon) ulaşması 10-14 gün sürer."
                ],
                "footer": "Ora Serrataya Tam Kilit / 14 Gün Adezyon"
            }
        ]
    )

    # Slayt 5.1.2.3: Kriyoretinopeksi vs Lazer Fotokoagülasyon
    builder.add_split_comparison_slide(
        title="PROFİLAKTİK YÖNTEMLER: LAZER vs KRİYORETİNOPEKSİ",
        category="BÖLÜM 5.1.2: KARŞILAŞTIRMA",
        subtitle="Transpupiller Bariyer Lazer vs Transskleral Dondurma Tedavisi",
        left_entity={
            "name": "BARİYER LAZER FOTOKOAGÜLASYON",
            "subtitle": "Modern İlk Tercih — Transpupiller Yaklaşım",
            "bullets": [
                "Uygulama: Yarık lamba ve temas lensi ile ağrısız, poliklinik şartlarında uygulanır [s.163].",
                "Doku Hasarı: Yalnızca RPE ve dış retinayı hedefler; skleraya ve iç retinaya hasar vermez.",
                "PVR İndüksiyon Riski: Çok düşüktür; kan-retina bariyerini minimal bozar.",
                "Görsel Ortam Şartı: Kornea, lens ve vitreusun berrak olmasını gerektirir.",
                "Adezyon Başlangıcı: 24-48 saatte başlar, 10-14 günde maksimum kuvvete erişir [s.163]."
            ]
        },
        right_entity={
            "name": "TRANSSKLERAL KRİYORETİNOPEKSİ",
            "subtitle": "Opak Ortamlarda ve Ekstrem Periferde Alternatif",
            "bullets": [
                "Uygulama: Konjonktiva üzerinden skleraya prob bastırılarak dondurulur (-70°C, CO2/N2O) [s.163].",
                "Doku Hasarı: Skleradan retinaya tüm katmanları dondurur; Bruch zarını parçalayabilir.",
                "PVR İndüksiyon Riski: Daha yüksektir; serbest RPE hücrelerinin vitreusa salınımını tetikler.",
                "Görsel Ortam Şartı: Hafif katarakt veya vitreus kanaması varlığında bile uygulanabilir.",
                "Klinik Rol: Sklera çökertme cerrahisi sırasında veya aşırı ön perifer yırtıklarında seçilir [s.163]."
            ]
        },
        bottom_takeaway="Optik ortam berraksa profilakside daima lazer tercih edilir; kriyoterapi daha fazla RPE hücresini vitreusa saçarak PVR riskini artırır [s.163]."
    )

    # Slayt 5.1.2.4: Profilaksi Karar Ağacı: Hangi Lezyon Tedavi Edilmeli?
    builder.add_decision_tree_slide(
        title="PERİFERİK LEZYON TEDAVİ KARAR AĞACI",
        category="BÖLÜM 5.1.2: KARAR AĞACI",
        subtitle="Klinik ve Muayene Bulgularına Göre Profilaktik Müdahale Algoritması",
        root_label="PERİFERİK RETİNADA YIRTIK, DELİK VEYA DEJENERASYON SAPTANDI",
        branches=[
            {
                "label": "1. Akut Semptomatik At Nalı Yırtık",
                "criteria": "Fotopsi/uçuşma var, flep üzerinde aktif vitreus traksiyonu izleniyor [s.161].",
                "action": "Acil Tedavi: Aynı gün 532 nm Lazerle 3-4 sıra bariyer; ora serrataya tam kilitleme yapılır."
            },
            {
                "label": "2. Asemptomatik Lattice / Atrofik Delik",
                "criteria": "Semptom yok, traksiyon yok, diğer gözde retina dekolmanı öyküsü bulunmuyor [s.162].",
                "action": "Gözlem ve Eğitim: Tedavi verilmez; hastaya fotopsi/kurum yağması semptomları öğretilir, yıllık takip."
            },
            {
                "label": "3. Yüksek Riskli Asemptomatik Göz",
                "criteria": "Diğer gözde RRD öyküsü (fellow eye), yüksek miyopi (> -6.00 D) veya yaklaşan katarakt cerrahisi.",
                "action": "Seçici Profilaksi: Lezyon asemptomatik olsa dahi sınırlarına koruyucu lazer bariyeri uygulanır [s.162]."
            }
        ],
        bottom_rule="Diğer gözünü regmatojen dekolmandan kaybetmiş bir hastanın sağlam gözündeki lattice lezyonu asemptomatik dahi olsa profilaktik olarak lazerlenmelidir [s.162]."
    )

    # Slayt 5.1.2.5: Lazer Bariyeri Yetersizlikleri & Kaçak Dinamikleri
    builder.add_study_card_slide(
        title="BARİYER LAZER BAŞARISIZLIKLARI VE KAÇAK MEKANİZMALARI",
        category="BÖLÜM 5.1.2: KOMPLİKASYONLAR",
        subtitle="Lazer Sonrası Dekolman Gelişme Nedenleri ve Hatalı Uygulama Kalıpları",
        cards=[
            {
                "card_title": "1. Anterior Sınırın Açık Bırakılması",
                "lead": "En Yaygın Kaçak Yolu",
                "items": [
                    "Lazer yırtığın arkasını hilal şeklinde sarıp ora serrataya bağlanmadığında sıvı yanlardan öne sızar [s.163].",
                    "Ön periferdeki subretinal sıvı yerçekimiyle aşağı doğru akarak sekonder alt kadran RRD oluşturur.",
                    "Çözüm: Lazer çizgisi her iki taraftan ora serrata dişlerine kadar eksiksiz indirilmelidir.",
                    "Sklera depresyonu altında lazer probu veya indirekt oftalmoskop lazeri bu kilidi sağlamada üstündür."
                ],
                "footer": "Açık Ön Sınır -> Yanlardan Sıvı Kaçağı"
            },
            {
                "card_title": "2. Yetersiz Yanık Yoğunluğu veya Sıra",
                "lead": "Zayıf Koryoretinal Adezyon",
                "items": [
                    "Hafif ve silik atılmış lazer yanıkları RPE proliferasyonunu ve fibrotik yapışıklığı tetikleyemez [s.163].",
                    "Yalnızca 1 veya 2 sıra seyrek atılan lazer bariyerleri, vitreus traksiyonu arttığında yırtılarak aşılır.",
                    "Tam yapışma oluşması için gereken 14 günlük sürede hastanın ağır efor yapması kaçağı tetikleyebilir.",
                    "Hasta ilk 2 hafta sarsıntılı sporlardan, ağır yük kaldırmaktan ve travmadan korunmalıdır."
                ],
                "footer": "Yetersiz Yanık / 14 Günlük Risk Penceresi"
            },
            {
                "card_title": "3. Yeni Yırtık Gelişimi (Yeni AVD Odağı)",
                "lead": "Başka Bir Kadranda İkinci Lezyon",
                "items": [
                    "Lazer uygulanan yırtık tamamen güvene alınsa bile, devam eden AVD başka bir kadranda yeni yırtık açabilir [s.163].",
                    "Lazer sonrası dekolman gelişen olguların %50'sinde neden eski yırtığın açılması değil, yeni yırtıktır.",
                    "Bu nedenle lazer sonrası hasta 1. hafta, 1. ay ve 3. ayda 360 derece tüm perifer açısından yeniden taranmalıdır.",
                    "Hastaya yeni ışık çakması veya kurum yağması olursa gün kaybetmeden başvurması tembihlenmelidir."
                ],
                "footer": "Devam Eden AVD / Yeni Kadran Yırtığı"
            }
        ]
    )

    # Slayt 5.1.2.6: Landmark Literatür & Profilaksi Kanıt Düzeyi
    builder.add_trials_kpi_slide(
        title="PROFİLAKTİK LAZER KANIT DÜZEYİ VE LANDMARK VERİLER",
        category="BÖLÜM 5.1.2: KANIT DÜZEYİ",
        subtitle="Semptomatik Yırtıkların Tedavisi vs Asemptomatik Lezyonların İzlemi",
        kpis=[
            {"val": "%35 - 50", "label": "Tedavisiz Akut Yırtıkta RRD Riski"},
            {"val": "< %2", "label": "Lazer Bariyeri Sonrası RRD Oranı"},
            {"val": "%10 - 15", "label": "Fellow Eye RRD Gelişme Riski"},
            {"val": "14 Gün", "label": "Maksimum Koryoretinal Adezyon"}
        ],
        trials_table=[
            {
                "trial": "AAO PPP Retina Dekolmanı Profilaksi Kılavuzu",
                "design": "Kanıta Dayalı Klinik Uygulama Konsensüsü [s.161]",
                "result": "Akut semptomatik at nalı yırtıkların profilaktik tedavisi Seviye 1 (Güçlü Tavsiye) kanıt düzeyindedir."
            },
            {
                "trial": "Byer Landmark Lattice Kohort Çalışması",
                "design": "Asemptomatik Lattice Dejenerasyonu Uzun Dönem Doğal Seyri (n=276 göz, 11 yıl takip)",
                "result": "Asemptomatik lattice olgularında klinik dekolman gelişme riski <%1 bulunmuş; rutin profilaksi önerilmemiştir."
            },
            {
                "trial": "Fellow Eye Retinal Detachment Risk Study",
                "design": "Bir Gözü RRD Olan Hastaların Sağlam Gözlerinin Prospektif Analizi [s.162]",
                "result": "Fellow eye'da lattice veya yırtık varlığında profilaktik lazer, sekonder dekolman riskini %12'den %1.8'e düşürmüştür."
            }
        ],
        bottom_evidence="Asemptomatik genel popülasyonda lattice lazerlemek dekolmanı önlemez; ancak akut semptomatik at nalı yırtıkta lazer körlüğü önleyen en maliyet-etkin oftalmolojik girişimdir [s.161]."
    )

    # Slayt 5.1.2.7: Aktif Hatırlama & Board Sınavı Vakası: Fellow Eye Lattice Yönetimi
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: PROFİLAKSİ",
        category="BÖLÜM 5.1.2: AKTİF HATIRLAMA",
        subtitle="Sağ Gözü RRD Nedeniyle Ameliyat Edilmiş Hastanın Sol Gözünde Asemptomatik Lattice",
        vignette="52 yaşında erkek hasta, sağ gözünden 3 ay önce psödofakik büllöz regmatojen retina dekolmanı nedeniyle pars plana vitrektomi ve gaz tamponadı cerrahisi geçirmiştir. Sol gözün rutin muayenesinde görme 1.0 tam, hasta tamamen semptomsuzdur (ışık çakması veya uçuşma yok). Sol göz periferik muayenesinde saat 1:00 ile 2:30 arasında sklerotik kafes damarları içeren 1.5 saat kadranı genişliğinde lattice dejenerasyonu ve lezyon içinde 2 adet küçük atrofik yuvarlak delik saptanıyor. Subretinal sıvı yoktur.",
        differentials=[
            "Yüksek Riskli Asemptomatik Fellow Eye Lattice (Diğer gözde RRD öyküsü nedeniyle profilaksi adayı).",
            "Standart Düşük Riskli İzole Lattice (Eğer diğer göz sağlıklı olsaydı sadece takip edilirdi).",
            "Lokalize Regmatojen Retina Dekolmanı (Subretinal sıvı olmadığı için dekolman yoktur).",
            "Klinik Dışı Masum Periferik Kistoid Dejenerasyon."
        ],
        decision="1. Risk Değerlendirmesi: Hastanın sağ gözünde RRD öyküsü olması (fellow eye), sol gözündeki lattice'i doğrudan 'yüksek riskli' kategorisine sokar.\n2. Tedavi Kararı: Hasta tamamen asemptomatik olsa dahi, sol gözdeki lattice lezyonunun ve atrofik deliklerin çevresi 532 nm yeşil lazer ile en az 3 sıra bariyerlenmeli ve ora serrataya kilitlenmelidir.\n3. Takip: 2 hafta sonra lazer pigmentasyonu kontrol edilmelidir.",
        board_trap="Eğer bu hastanın sağ gözünde RRD öyküsü olmasaydı, asemptomatik lattice için lazer uygulamak kontrendike olurdu; ancak fellow eye öyküsü kuralı tamamen değiştirir ve profilaksiyi zorunlu kılar [s.162]."
    )

    # =========================================================================
    # 5.2.1: REGMATOJEN RETİNA DEKOLMANI (RRD) VE LİNCOFF KURALLARI (9 Slayt)
    # =========================================================================

    # Slayt 5.2.1.1: RRD Patofizyolojisi ve Sıvı Dinamiği
    builder.add_study_card_slide(
        title="REGMATOJEN RETİNA DEKOLMANI (RRD) PATOFİZYOLOJİSİ",
        category="BÖLÜM 5.2.1: PATOFİZYOLOJİ",
        subtitle="Vitreus Likefaksiyonu, Traksiyon, Tam Kat Defekt ve Subretinal Göllenme Triadı",
        cards=[
            {
                "card_title": "1. Gerekli Olan Üç Temel Faktör",
                "lead": "RRD Gelişimi İçin Eşzamanlı Şartlar",
                "items": [
                    "1. Sıvılaşmış Vitreus: Yaşlanma veya miyopi ile sinerezis sonucu jelin su fazına ayrılması [s.164].",
                    "2. Traksiyonel Güç: Vitreoretinal arayüzde AVD sırasında periferik retinayı çeken dinamik kuvvet.",
                    "3. Tam Kat Retinal Yırtık: Traksiyon noktasında nörosensoriyel retinada defekt açılması.",
                    "Bu 3 faktör bir araya gelmedikçe sıvı subretinal aralığa geçemez ve dekolman oluşamaz."
                ],
                "footer": "Likefaksiyon + Traksiyon + Yırtık"
            },
            {
                "card_title": "2. Sıvı Hareketi & RPE Pompa Yetmezliği",
                "lead": "Fizyolojik Denge Bozulması",
                "items": [
                    "Normalde RPE hücrelerinin Na+/K+ ATPaz pompaları subretinal aralıktaki sıvıyı koroid damarlarına çeker [s.164].",
                    "Göz hareketleri (sakadlar) sırasında yırtıktan içeri giren sıvı akımı, RPE pompasının kapasitesini aşar.",
                    "Sıvı nörosensoriyel retina ile RPE arasındaki potansiyel aralığı genişleterek fotoreseptörleri ayırır.",
                    "Fotoreseptörlerin koryokapillaristen oksijen difüzyonu kopunca hücreler hızla apoptoza sürüklenir."
                ],
                "footer": "RPE Pompa Kapasitesinin Aşılması"
            },
            {
                "card_title": "3. Dekolman Morfolojisi & İlerleme Hızı",
                "lead": "Yerçekimi ve Yırtık Konumu",
                "items": [
                    "Üst kadran yırtıklarında subretinal sıvı yerçekimi desteğiyle hızla foveaya doğru akar (saatler/günler) [s.165].",
                    "Alt kadran yırtıklarında ise sıvı birikimi çok daha yavaştır; haftalarca lokalize kalarak sınır pigmenti yapabilir.",
                    "RRD retinası dalgalı (undüle), katlantılı, opak ve göz hareketleriyle sallanan büllöz bir yapıdadır.",
                    "Makula tutulduğunda santral görme dakikalar içinde parmak sayma veya el hareketine geriler."
                ],
                "footer": "Üst Kadran (Hızlı) / Alt Kadran (Sinsi)"
            }
        ]
    )

    # Slayt 5.2.1.2: Lincoff Kuralları: Yırtık Lokalizasyonunun Matematiksel Tespiti
    builder.add_study_card_slide(
        title="LİNCOFF KURALLARI: YIRTIK LOKALİZASYONUNUN TESPİTİ",
        category="BÖLÜM 5.2.1: TANI PROTOKOLÜ",
        subtitle="Subretinal Sıvının Şekline Göre Primer Yırtığın Yerini %98 Doğrulukla Bulan Geometrik Kurallar",
        cards=[
            {
                "card_title": "1. Üst Temporal / Nazal Kuralı",
                "lead": "Lateralize Üst Kadran Sıvısı",
                "items": [
                    "Subretinal sıvı üst kadranda başlayıp vertikal meridyeni geçerek aşağı iniyorsa [s.165]:",
                    "Primer yırtık, sıvının en yüksek olduğu üst kadranın saat 1.5 kadranı içinde yer alır.",
                    "Örnek: Sıvı saat 11:00'de en yüksek ve saat 6:00'ya akıyorsa, yırtık saat 10:00 - 11:30 arasındadır.",
                    "Sıvı diski aşıp nazale geçmişse, primer delik daima sıvının başladığı taraftadır."
                ],
                "footer": "Kural 1: En Yüksek Seviyenin 1.5 Kadranı"
            },
            {
                "card_title": "2. Vertikal Meridyeni Aşan Üst Sıvı",
                "lead": "Saat 12:00 Meridyen Yırtığı",
                "items": [
                    "Eğer sıvı her iki tarafta (hem nazal hem temporalde) eşit seviyede aşağı iniyorsa [s.165]:",
                    "Primer yırtık tam saat 12:00 vertikal meridyenindedir.",
                    "Sıvı saat 12:00'den her iki yana simetrik olarak dökülür.",
                    "Bu bulgu cerraha tam üst kutupta gizli küçük bir at nalı yırtık araması gerektiğini söyler."
                ],
                "footer": "Kural 2: Simetrik Sıvı -> Saat 12:00 Yırtığı"
            },
            {
                "card_title": "3. Alt Kadran ve Primer Delik Kuralı",
                "lead": "İnferior Başlangıçlı Dekolmanlar",
                "items": [
                    "Sıvı altta toplanmışsa, sıvının daha yüksek olduğu tarafta alt kadranda yırtık aranır [s.166].",
                    "Eğer alt kadran sıvısı her iki tarafta eşitse, yırtık saat 6:00 meridyenindedir.",
                    "Tuzak: Sıvı altta büllöz görünse bile, optik diskin temporalinden yukarı doğru ince bir hat izleniyorsa:",
                    "Yırtık altta değil, üst temporalde küçük asemptomatik bir deliktir; sıvı aşağı akmıştır!"
                ],
                "footer": "Kural 3 & 4: Alt Kadran / Gizli Üst Sızıntı"
            }
        ]
    )

    # Slayt 5.2.1.3: Klinik Muayene, Schaffer Belirtisi ve B-Scan USG
    builder.add_study_card_slide(
        title="RRD KLİNİK MUAYENESİ VE TANI YÖNTEMLERİ",
        category="BÖLÜM 5.2.1: MUAYENE",
        subtitle="İndirekt Oftalmoskopi, Tütün Tozu (Schaffer) ve B-Scan Ultrasonografi Protokolü",
        cards=[
            {
                "card_title": "1. İndirekt Oftalmoskopi & Depresyon",
                "lead": "Tanıda Altın Standart",
                "items": [
                    "20 veya 28 D lens ile binoküler indirekt oftalmoskopi dekolmanın sınırlarını gösterir [s.166].",
                    "Sklera depresyonu yapılarak ora serratadaki tüm küçük yırtıklar, flepler ve diyalizler taranır.",
                    "Retina yüzeyinde PVR belirtileri (sabit katlantılar, yıldız katlantı, damar kıvrımları) not edilir.",
                    "Makulanın durumu (açık/on veya kapalı/off) aciliyet derecesini belirleyen en kritik veridir."
                ],
                "footer": "20 D Lens / Sklera Depresyonu / PVR Taraması"
            },
            {
                "card_title": "2. Schaffer Belirtisi (Tütün Tozu)",
                "lead": "Ön Kamara ve Vitreus İncelemesi",
                "items": [
                    "Yırtık oluştuktan sonra serbest RPE hücreleri subretinal aralıktan vitreus boşluğuna dökülür [s.166].",
                    "Biyomikroskopide retrolental alanda ince kahverengi hücreler (tütün tozu) izlenir.",
                    "Schaffer belirtisi %95 oranında tam kat retinal yırtık veya dekolman varlığına işaret eder.",
                    "Ayrıca dekolmanlı gözde GİB (göz içi basıncı), uveoskleral dışa akım artışı nedeniyle sağlam göze göre 2-4 mmHg düşüktür."
                ],
                "footer": "Tütün Tozu = Yırtık / Hipotoni (2-4 mmHg)"
            },
            {
                "card_title": "3. B-Scan Ultrasonografi Standartları",
                "lead": "Opak Ortamlarda Hayat Kurtarıcı",
                "items": [
                    "Vitreus kanaması veya katarakt nedeniyle arka kutup görülemiyorsa B-Scan USG şarttır [s.167].",
                    "RRD, optik diske ve ora serrataya tutunan yüksek ekojeniteli, kalın ve hareketli membran verir.",
                    "Kazanç (gain) düşürüldüğünde RRD membranı ekosunu korur (vitreus membranları ise silinir).",
                    "Kinetik muayenede taze dekolman dalgalanır; PVR gelişmiş kronik dekolman ise sert ve rijit kalır."
                ],
                "footer": "Diske Tutunan Membran / Düşük Gain Testi"
            }
        ]
    )

    # Slayt 5.2.1.4: Atlas Görseli: Büllöz Regmatojen Retina Dekolmanı
    p165_img = builder.get_image_for_page(165)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: BÜLLÖZ REGMATOJEN RETİNA DEKOLMANI",
        category="BÖLÜM 5.2.1: ATLAS",
        subtitle="Üst Temporal Flep Yırtık Zemininde Gelişen Geniş Subretinal Sıvı ve Makula Tehdidi",
        image_path=p165_img if p165_img else None,
        caption="Şekil 5.2: Üst temporalde geniş at nalı yırtık, büllöz dalgalanan retina ve makulaya uzanan subretinal sıvı hattı [Kitap s.165].",
        key_findings=[
            "Retina pembe-kırmızı koroid zemininden ayrılarak süt beyazı-gri opak bir renge bürünmüştür.",
            "Retinal damarlar dekolman dalgaları üzerinde kıvrımlı ve koyu renkli görünür.",
            "Subretinal sıvı saat 10:30 hizasındaki geniş at nalı yırtıktan sızarak foveanın sınırına dayanmıştır (Makula-On).",
            "Bu vaka makulanın korunabilmesi için ilk 24 saat içinde cerrahiye alınması gereken mutlak bir acildir."
        ],
        differentials=[
            "Regmatojen Retina Dekolmanı: Yırtık izlenir, dalgalı membran, büllöz sıvı.",
            "Traksiyonel Dekolman: Konkav şekilli, PDR membranları çeker, ora serrataya uzanmaz.",
            "Eksüdatif Dekolman: Yırtık yoktur, yer değiştiren (shifting) sıvı mevcuttur."
        ],
        clinical_pearl="Makulası henüz ayrılmamış (Makula-On) RRD cerrahi bir acildir; makula bir kez dekolle olduğunda (Makula-Off) ameliyat başarılı olsa bile fotoreseptör kaybı nedeniyle görme asla 1.0 düzeyine dönemez [s.165]."
    )

    # Slayt 5.2.1.5: Pnömatik Retinopeksi (PR): Endikasyonlar ve Gaz Dinamiği
    builder.add_study_card_slide(
        title="PNÖMATİK RETİNOPEKSİ: ENDİKASYONLAR VE TEKNİK",
        category="BÖLÜM 5.2.1: MİNİMAL İNVAZİV CERRAHİ",
        subtitle="İntravitreal Gaz Enjeksiyonu (SF6 / C3F8), Lazer/Kriyo ve Baş Pozisyonlama Protokolü",
        cards=[
            {
                "card_title": "1. İdeal Hasta Seçim Kriterleri",
                "lead": "Başarı İçin Katı Endikasyonlar",
                "items": [
                    "Üst 8 saat kadranı içinde (saat 8:00 ile 4:00 arası) tek bir yırtık veya 1 saat kadranı içinde kümelenmiş yırtıklar [s.167].",
                    "PVR bulunmaması (Evre A veya B'den ileri olmamalı).",
                    "Medial/lateral aşırı periferik katarakt olmaması (periferik muayene net yapılabilmeli).",
                    "Hastanın en az 5-7 gün boyunca baş pozisyonuna (prone/lateral) kesin uyum sağlayabilmesi şarttır."
                ],
                "footer": "Üst Kadran / PVR Yok / Pozisyon Uyumu"
            },
            {
                "card_title": "2. Gaz Seçimi & Enjeksiyon Tekniği",
                "lead": "SF6 vs C3F8 Gaz Dinamiği",
                "items": [
                    "%100 saf SF6 (0.5 – 0.6 ml) veya saf C3F8 (0.3 ml) gazı pars planadan (limbus gerisi 3.5-4 mm) enjekte edilir [s.167].",
                    "Gaz göz içinde genleşir: SF6 hacmini 2 katına (10-14 gün kalır), C3F8 hacmini 4 katına çıkarır (4-6 hafta kalır).",
                    "Enjeksiyon sırasında 'balık yumurtası' (birden fazla küçük kabarcık) oluşumunu önlemek için iğne tek hamlede sıkılmalıdır.",
                    "GİB kontrolü yapılır; gerekirse ön kamara parasentezi ile göz içi basıncı düşürülür."
                ],
                "footer": "SF6 (2x / 14 gün) / C3F8 (4x / 30 gün)"
            },
            {
                "card_title": "3. Gaz Tamponadı & Retinopeksi",
                "lead": "Yüzey Gerilimi ve Kapatma",
                "items": [
                    "Gaz kabarcığının yüzey gerilimi yırtığı içten tıkar ve subretinal sıvının RPE pompalarınca emilmesini sağlar [s.168].",
                    "Retina 24-48 saatte yapıştıktan sonra yırtık çevresine laser fotokoagülasyon uygulanır.",
                    "Alternatif olarak gaz verilmeden hemen önce transskleral kriyopeksi yapılabilir.",
                    "Pnömatik retinopeksi sonrası başarı oranı seçilmiş olgularda %80-85 düzeyindedir."
                ],
                "footer": "Yüzey Gerilimi Kapatması / %85 Başarı"
            }
        ]
    )

    # Slayt 5.2.1.6: Sklera Çökertme (Buckling) vs Pars Plana Vitrektomi (PPV)
    builder.add_split_comparison_slide(
        title="CERRAHİ SEÇİM: SKLERA ÇÖKERTME vs VİTREKTOMİ (PPV)",
        category="BÖLÜM 5.2.1: CERRAHİ STRATEJİ",
        subtitle="Eksplon/Bant ile Skleral İndentasyon vs 23/25G Pars Plana Vitrektomi ve Gaz/Silikon",
        left_entity={
            "name": "SKLERA ÇÖKERTME (SCLERAL BUCKLING)",
            "subtitle": "Genç, Fakik ve Ön Perifer Yırtıklarında İdeal",
            "bullets": [
                "Endikasyon: Genç hastalar, fakik gözler, retinal diyaliz ve şeffaf lensi koruma amacı [s.168].",
                "Mekanizma: Sklerayı dışarıdan silikon sünger/bant ile çökerterek vitreus traksiyonunu nötralize eder.",
                "Lens Durumu: Katarakt oluşturma riski minimaldir; doğal kristalin lens korunur.",
                "Subretinal Sıvı: Eksternal drenaj ile boşaltılabilir veya spontan emilmeye bırakılır.",
                "Dezavantaj: Miyopik kırma kusuru kayması (-1.5 ila -2.5 D aksiyel uzama) ve diplopi riski [s.168]."
            ]
        },
        right_entity={
            "name": "PARS PLANA VİTREKTOMİ (PPV)",
            "subtitle": "Psödofakik, Posterior ve Komplike Yırtıklarda Altın Standart",
            "bullets": [
                "Endikasyon: Psödofakik RRD, posterior yırtıklar, dev yırtıklar, vitreus hemorajisi ve PVR varlığı [s.168].",
                "Mekanizma: Vitreus traksiyonu içten kesilerek temizlenir; sıvı-hava değişimi ve gaz/silikon verilir.",
                "Lens Durumu: Fakik hastalarda 6-12 ay içinde %80-90 oranında nükleer sklerotik katarakt gelişir.",
                "Görsel Hakimiyet: 360 derece vitreus tabanı tıraşlanır; tüm yırtıklar doğrudan içten görülür.",
                "Dezavantaj: Postoperatif zorunlu yüzüstü baş pozisyonu ve katarakt oluşumu [s.168]."
            ]
        },
        bottom_takeaway="Genç fakik bir miyopta lensi korumak için sklera çökertme öncelikli düşünülmeli; kataraktı zaten alınmış psödofakik bir gözde ise PPV tartışmasız ilk tercihtir [s.168]."
    )

    # Slayt 5.2.1.7: RRD Acil Cerrahi Karar Ağacı: Makula On vs Makula Off
    builder.add_decision_tree_slide(
        title="RRD ACİL CERRAHİ ZAMANLAMA VE KARAR AĞACI",
        category="BÖLÜM 5.2.1: KARAR AĞACI",
        subtitle="Makula Durumuna (On vs Off) Göre Saatlik ve Günlük Müdahale Zamanlaması",
        root_label="HASTADA REGMATOJEN RETİNA DEKOLMANI TEŞHİS EDİLDİ",
        branches=[
            {
                "label": "1. Makula Henüz Tutulmamış (Makula-On)",
                "criteria": "Fovea yapışık, görme 0.8-1.0; subretinal sıvı foveaya doğru ilerliyor [s.165].",
                "action": "Acil Cerrahi (İlk 24 Saat): Hasta derhal yatırılır, baş pozisyonu verilir; aynı gün ameliyata alınarak fovea korunur."
            },
            {
                "label": "2. Makula Yeni Ayrılmış (Makula-Off < 7-10 Gün)",
                "criteria": "Görme parmak saymaya düşmüş; foveal dekolman süresi 1 haftayı aşmamış [s.166].",
                "action": "Yarı-Acil Cerrahi (İlk 72 Saat): İlk 7-10 gün içinde anatomik başarı sağlanırsa görme 0.5 ve üzerine toparlayabilir."
            },
            {
                "label": "3. Kronik Dekolman (Makula-Off > 1-2 Ay)",
                "criteria": "Demarkasyon çizgileri, subretinal kistler ve PVR bantları mevcut; görme el hareketi.",
                "action": "Elektif / Planlı Cerrahi: Cerrahi aciliyet kalmamıştır; PVR temizliği ve silikon yağı tamponadı planlanır [s.166]."
            }
        ],
        bottom_rule="Makula-On bir dekolmanı 'mesai bitti' diye ertesi güne bırakmak foveanın dekolle olmasına ve hastanın kalıcı görme kaybına uğramasına yol açabilir; Makula-On cerrahi bir acildir [s.165]."
    )

    # Slayt 5.2.1.8: RRD Cerrahi Başarı ve Landmark Çalışmalar (SPR ve PIVOT)
    builder.add_trials_kpi_slide(
        title="RRD CERRAHİSİNDE LANDMARK KLİNİK ÇALIŞMALAR",
        category="BÖLÜM 5.2.1: LİTERATÜR",
        subtitle="SPR Study ve PIVOT Trial ile Sklera Çökertme, Vitrektomi ve Pnömatik Karşılaştırması",
        kpis=[
            {"val": "%85 - 90", "label": "Tek Cerrahide Anatomik Başarı"},
            {"val": "%95 - 98", "label": "Nihai (Çoklu) Başarı Oranı"},
            {"val": "%5 - 10", "label": "Postop PVR Gelişme Oranı"},
            {"val": "24 Saat", "label": "Makula-On Müdahale Penceresi"}
        ],
        trials_table=[
            {
                "trial": "SPR Study (Scleral Buckling vs PPV in Rhegmatogenous RD)",
                "design": "Prospektif Randomize Çok Merkezli Avrupa Çalışması (n=681 hasta) [s.168]",
                "result": "Fakik hastalarda sklera çökertme daha iyi görme keskinliği sağlamış ve kataraktı önlemiştir; psödofakiklerde ise PPV anatomik olarak üstün bulunmuştur."
            },
            {
                "trial": "PIVOT Trial (Pneumatic Retinopexy vs PPV)",
                "design": "Randomize Klinik Çalışma: Seçilmiş Tek Üst Yırtıklı Olgularda Pnömatik vs PPV",
                "result": "Pnömatik retinopeksi grubunda 1. yılda görme keskinliği PPV'ye göre istatistiksel olarak daha üstün çıkmış ve katarakt riski çok düşük kalmıştır."
            },
            {
                "trial": "VIPER Study (Vitrectomy with Internal Tamponade in PVR)",
                "design": "İleri Evre RRD ve PVR Olgularında Gaz vs Silikon Yağı Karşılaştırması [s.169]",
                "result": "PVR Evre C olgularında ağır gazlara kıyasla silikon yağı anatomik stabilizasyonda anlamlı üstünlük sağlamıştır."
            }
        ],
        bottom_evidence="Landmark çalışmalar fovea açıkken cerrahi zamanlamanın nihai görme için en kritik bağımsız prognostik faktör olduğunu doğrulamaktadır [s.168]."
    )

    # Slayt 5.2.1.9: Aktif Hatırlama & Board Sınavı Vakası: Makula-On RRD
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: RRD ACİLİ",
        category="BÖLÜM 5.2.1: AKTİF HATIRLAMA",
        subtitle="64 Yaşında Psödofakik Hastada Üst Kadrandan Aşağı İnen Perde ve Makula-On Durumu",
        vignette="64 yaşında 2 yıl önce bilateral komplikesiz fakoemülsifikasyon geçirmiş erkek hasta, dün sabah sol gözünün üst dış alanında siyah bir gölge fark ettiğini, bu sabah ise perdenin genişleyerek görme alanının alt yarısını tamamen kapattığını belirterek saat 16:30'da polikliniğe başvuruyor. Sol görme keskinliği 0.9. Biyomikroskopide arka kamara göz içi lensi santralde stabil. Ön vitreusta serbest pigment hücreleri (Schaffer +) mevcut. Fundus muayenesinde saat 11:00 hizasında geniş bir at nalı yırtık, üst temporalde büllöz subretinal sıvı izleniyor; sıvı foveanın 500 μm yakınına kadar ilerlemiş ancak fovea henüz dekolle olmamış (Makula-On).",
        differentials=[
            "Psödofakik Büllöz Regmatojen Retina Dekolmanı (Makula-On acil cerrahi adayı).",
            "Eksüdatif Retina Dekolmanı (Yırtık bulunmaz, seröz sıvı yer değiştirir).",
            "Eski Sklerotik Dekolman (Demarkasyon hattı yoktur, tablo saatler içinde hızla ilerlemiştir).",
            "Dev Yırtıklı Retina Dekolmanı (Yırtık 3 saat kadranından küçük olduğu için dev yırtık değildir)."
        ],
        decision="1. Klinik Durum: Sol Makula-On Psödofakik RRD.\n2. Eylem: Bu vaka mutlak bir cerrahi acildir; ertesi güne bırakılamaz. Hasta acil ameliyata hazırlanır, foveaya doğru sıvı ilerlemesini durdurmak için başı sol temporal aşağı gelecek şekilde yatırılır.\n3. Cerrahi Yöntem: Psödofakik gözde sklera çökertmenin başarı şansı düşüktür; 25G Pars Plana Vitrektomi (PPV) + Endolazer + Gaz Tamponadı (C3F8 veya SF6) uygulanmalıdır.",
        board_trap="Hastanın görmesi 0.9 diye operasyonu elektif cerrahi listesine ertelemek foveanın dekolle olmasına neden olur; fovea dekolle olursa ameliyat tutsa bile görme kalıcı olarak 0.3-0.4'e düşer [s.165]."
    )

    # =========================================================================
    # 5.2.2: TRAKSİYONEL (TRD) VE EKSÜDATİF (ERD) RETİNA DEKOLMANLARI (8 Slayt)
    # =========================================================================

    # Slayt 5.2.2.1: Traksiyonel Retina Dekolmanı (TRD) Patogenezi
    builder.add_study_card_slide(
        title="TRAKSİYONEL RETİNA DEKOLMANI (TRD) PATOGENEZİ",
        category="BÖLÜM 5.2.2: PATOGENEZ",
        subtitle="Proliferatif Diyabetik Retinopati (PDR), Fibrovasküler Membranlar ve Traksiyonel Güçler",
        cards=[
            {
                "card_title": "1. Fibrovasküler Doku Proliferasyonu",
                "lead": "İskemi Zemininde Gelişen Membranlar",
                "items": [
                    "Retinal hipoksi ve aşırı VEGF salınımı, optik disk ve damar arkatları boyunca neovaskülarizasyon başlatır [s.169].",
                    "Yeni damarlara glial hücreler ve fibroblastlar eşlik ederek fibrovasküler epiretinal membranlara dönüşür.",
                    "Arka hyaloid zarı bu fibrovasküler dokuya sıkıca yapışır ve iskele vazifesi görür.",
                    "Zamanla dokudaki miyofibroblastlar kasılarak retinayı içe ve öne doğru çekmeye başlar."
                ],
                "footer": "VEGF -> Neovaskülarizasyon -> Glial Kasılma"
            },
            {
                "card_title": "2. TRD Morfolojisi ve Sınırları",
                "lead": "Konkav Yüzey ve Yavaş İlerleme",
                "items": [
                    "TRD retinası RRD gibi dalgalı ve büllöz değil; hareketsiz, gergin ve yüzeyi konkav (içbükey) görünümdedir [s.169].",
                    "Dekolmanın tepe noktası daima en güçlü fibrovasküler traksiyon bandının tutunduğu yerdedir.",
                    "Sıvı nadiren ora serrataya kadar uzanır; genellikle vasküler arkatlar ve arka kutupla sınırlı kalır.",
                    "Yırtık açılmadığı sürece subretinal sıvı göllenmesi çok yavaştır; aylar boyunca stabil kalabilir."
                ],
                "footer": "Konkav Yüzey / Arkat Sınırı / Hareketsiz Doku"
            },
            {
                "card_title": "3. Cerrahi Endikasyonlar & Riskler",
                "lead": "Ne Zaman Müdahale Edilmeli?",
                "items": [
                    "Makulayı içine alan veya foveayı doğrudan tehdit eden TRD mutlak cerrahi endikasyondur [s.170].",
                    "Foveayı tehdit etmeyen periferik traksiyonel elevasyonlar cerrahisiz sadece izlenebilir.",
                    "Cerrahide amaç: Arka hyaloidin ayrılması, fibrovasküler membranların delaminasyon ve segmentasyonla kesilmesidir.",
                    "Preoperatif Anti-VEGF: Cerrahiden 3-5 gün önce verilerek kanama azaltılır (daha erken verilirse 'crunch sendromu' ile traksiyonu artırabilir!)."
                ],
                "footer": "Makula Tutulumu / Delaminasyon / Crunch Riski"
            }
        ]
    )

    # Slayt 5.2.2.2: TRD vs RRD Patolojik ve Morfolojik Karşılaştırması
    builder.add_split_comparison_slide(
        title="DEKOLMAN AYIRICI TANISI: RRD vs TRD",
        category="BÖLÜM 5.2.2: KARŞILAŞTIRMA",
        subtitle="Regmatojen (Yırtıklı) vs Traksiyonel (Membran Çekintili) Dekolman Özellikleri",
        left_entity={
            "name": "REGMATOJEN RETİNA DEKOLMANI (RRD)",
            "subtitle": "Yırtık Kaynaklı Sıvı Göllenmesi",
            "bullets": [
                "Yüzey Şekli: Konveks (dışbükey), büllöz, dalgalı ve katlantılı [s.170].",
                "Hareketlilik: Göz hareketleriyle belirgin şekilde dalgalanır (undülasyon gösterir).",
                "Yayılım: Genellikle ora serrataya kadar uzanır; tüm kadranı kaplayabilir.",
                "Yırtık: Tam kat retinal yırtık veya delik mevcuttur.",
                "İlerleme Hızı: Hızlıdır (günler/haftalar içinde total dekolmana gidebilir).",
                "GİB: Sağlam göze göre genellikle 2-4 mmHg daha düşüktür (hipotoni) [s.170]."
            ]
        },
        right_entity={
            "name": "TRAKSİYONEL RETİNA DEKOLMANI (TRD)",
            "subtitle": "Membran Kasılmasına Bağlı Mekanik Çekilme",
            "bullets": [
                "Yüzey Şekli: Konkav (içbükey), düzleşmiş ve gergin görünüm [s.170].",
                "Hareketlilik: Hareketsiz ve rijittir; göz hareketleriyle sallanmaz.",
                "Yayılım: Arkatlarla sınırlıdır; ora serrataya hemen hemen hiç uzanmaz.",
                "Yırtık: Primer yırtık yoktur (yırtık açılırsa kombine mekanizmalı olur).",
                "İlerleme Hızı: Çok yavaştır; aylar boyunca fovea kenarında sabit kalabilir.",
                "GİB: Normal veya neovasküler glokom zemininde yüksektir [s.170]."
            ]
        },
        bottom_takeaway="TRD zemininde aniden konveks büllöz bir alan ve hızlı görme kaybı başlarsa, membran retinayı yırtmış ve 'Kombine Traksiyonel-Regmatojen Dekolman' gelişmiştir; acil cerrahi gerekir [s.170]."
    )

    # Slayt 5.2.2.3: Kombine Mekanizmalı Dekolman: Regmatojen Komponentli TRD
    builder.add_study_card_slide(
        title="KOMBİNE TRAKSİYONEL-REGMATOJEN RETİNA DEKOLMANI",
        category="BÖLÜM 5.2.2: KOMBİNE DEKOLMAN",
        subtitle="Miyofibroblastik Gerginliğin Retinayı Yırtması ve Büllöz Tabloya Dönüşüm",
        cards=[
            {
                "card_title": "1. Yırtık Oluşum Mekanizması",
                "lead": "Statik Çekintinin Dinamik Yırtığa Dönüşmesi",
                "items": [
                    "Kronik PDR hastasında fibrovasküler kordon retinayı çekerken doku gerilme sınırını aşar [s.171].",
                    "Membranın hemen kenarında veya arka vasküler arkat hizasında oval/yarık şeklinde retinal yırtık açılır.",
                    "Yırtık açıldığı anda vitreus boşluğundaki sıvı subretinal aralığa hücum eder.",
                    "Daha önce aylardır sabit duran konkav alan, saatler içinde konveks büllöz bir dekolmana dönüşür."
                ],
                "footer": "Gerilme Sınırının Aşılması -> Sekonder Yırtık"
            },
            {
                "card_title": "2. Klinik Tanı İpuçları",
                "lead": "Konkavdan Konvekse Geçiş",
                "items": [
                    "Hastanın stabil seyreden kronik görme azlığı aniden el hareketine veya ışık hissine geriler [s.171].",
                    "Muayenede rijit fibrovasküler bandın çevresinde dalgalanan ve ora serrataya uzanan yeni sıvı göllenir.",
                    "Fundus anjiyografisinde veya cerrahi esnasında triamsinolon boyaması ile yırtık netleştirilir.",
                    "Kombine dekolmanlar PVR gelişimi açısından en yüksek risk grubunu oluşturur."
                ],
                "footer": "Ani Konveks Değişim / Ora Serrata Yayılımı"
            },
            {
                "card_title": "3. Cerrahi Strateji ve Güçlükler",
                "lead": "Bimanüel Cerrahi ve Tamponad",
                "items": [
                    "Yalnızca gaz vermek yetersizdir; traksiyon devam ettiği sürece yırtık kapanmaz [s.171].",
                    "Cerrahi adımlar: Bimanüel mikrocerrahi makaslarıyla zarların titizlikle soyulması (delaminasyon).",
                    "Tüm traksiyon sıfırlandıktan sonra perflorokarbon (ağır sıvı) ile retina yatıştırılır.",
                    "Yırtık çevresine 360° endolazer uygulanır ve uzun süreli silikon yağı tamponadı verilir."
                ],
                "footer": "Bimanüel Delaminasyon / PFCL / Silikon Yağı"
            }
        ]
    )

    # Slayt 5.2.2.4: Eksüdatif (Seröz) Retina Dekolmanı (ERD) Etyolojisi
    builder.add_study_card_slide(
        title="EKSÜDATİF (SERÖZ) RETİNA DEKOLMANI (ERD)",
        category="BÖLÜM 5.2.2: EKSÜDATİF DEKOLMAN",
        subtitle="Yırtıksız ve Traksiyonsuz Sıvı Birikimi: İnflamasyon, Malignite ve Vasküler Kaçak",
        cards=[
            {
                "card_title": "1. İnflamatuar ve İmmün Nedenler",
                "lead": "Kan-Retina Bariyerinin İflası",
                "items": [
                    "Vogt-Koyanagi-Harada (VKH) Sendromu: Bilateral diffüz koroidit ve multifokal seröz dekolmanlar [s.171].",
                    "Posterior Sklerit: Şiddetli oküler ağrı, T-işareti (B-Scan USG) ve seröz retina elevasyonu.",
                    "Malign Hipertansiyon (Toxemia of Pregnancy / Preeklampsi): Elschnig lekeleri ve seröz dekolman.",
                    "Sarkoidoz ve Sempatik Oftalmi: Granülomatöz koroidal infiltrasyon kaynaklı sıvı kaçağı."
                ],
                "footer": "VKH / Posterior Sklerit / Malign Hipertansiyon"
            },
            {
                "card_title": "2. Neoplastik ve Vasküler Etyoloji",
                "lead": "Tümör Eksüdasyonu ve Bozulmuş Drenaj",
                "items": [
                    "Koroid Melanomu ve Metastazları: Tümör üzerindeki RPE ve damar geçirgenliğinin bozulması [s.172].",
                    "Koroid Hemanjiomu: Aşırı vasküler genişleme ve proteinöz subretinal sıvı göllenmesi.",
                    "Coats Hastalığı: Genç erkek çocuklarda telanjiyektatik damarlardan masif lipid ve seröz eksüdasyon.",
                    "Santral Seröz Koryoretinopati (Büllöz Varyant): Masif subretinal sıvı ile dekolman taklidi yapabilir."
                ],
                "footer": "Melanom / Hemanjiom / Coats Hastalığı"
            },
            {
                "card_title": "3. Patofizyolojik Mekanizma",
                "lead": "RPE Pompasının Aşırı Yüklenmesi",
                "items": [
                    "ERD'de ne yırtık vardır ne de vitreus traksiyonu; sorun koroid veya retinal hidrostatik basınç artışıdır [s.172].",
                    "Koroid damarlarından aşırı sıvı sızar; RPE bariyeri yıkılır ve sıvı subretinal alanda birikir.",
                    "Tedavi kesinlikle cerrahi (vitrektomi veya çökertme) DEĞİLDİR; altta yatan nedene yöneliktir.",
                    "İnflamasyonda sistemik steroid/immünsüpresyon, tümörde radyoterapi veya fotodinamik tedavi uygulanır."
                ],
                "footer": "Cerrahi KONTRENDİKE / Tıbbi & Etiyolojik Tedavi"
            }
        ]
    )

    # Slayt 5.2.2.5: ERD Klinik Belirteci: Değişken (Shifting) Sıvı Dinamiği
    builder.add_study_card_slide(
        title="ERD'NİN ALTIN BULGUSU: DEĞİŞKEN (SHIFTING) SIVI DİNAMİĞİ",
        category="BÖLÜM 5.2.2: TANI BELİRTECİ",
        subtitle="Yerçekimi ile Konum Değiştiren Subretinal Sıvının Klinik ve USG Özellikleri",
        cards=[
            {
                "card_title": "1. Shifting Sıvı Fizyolojisi",
                "lead": "Yerçekimine Tam Bağımlılık",
                "items": [
                    "ERD'de subretinal sıvı proteinden zengin, serbest ve berrak bir eksüdadır [s.172].",
                    "Yırtık olmadığı için sıvı bir odaktan pompalanmaz; göz küresinin en alt noktasına yerçekimiyle akar.",
                    "Hasta ayakta veya oturur pozisyondayken sıvı dakikalar içinde alt retinaya çöker ve büllöz elevasyon yapar.",
                    "Hasta sırtüstü (supin) yattığında ise sıvı yerçekimiyle fovea ve arka kutba doğru yer değiştirir."
                ],
                "footer": "Ayakta (Alt Kadran) / Supin (Arka Kutup)"
            },
            {
                "card_title": "2. Pozisyon Değiştirme Muayenesi",
                "lead": "Klinikte Uygulanan Ayırıcı Tanı Testi",
                "items": [
                    "Oturur pozisyonda fundus muayenesinde alt kadranda dekolman izlenen hastaya 30 dk supin yatış verilir [s.172].",
                    "Yeniden bakıldığında alt dekolmanın düzleştiği, sıvının makulaya ve optik disk çevresine kaydığı görülür.",
                    "Bu dinamik yer değiştirme (shifting fluid) yalnızca eksüdatif dekolmanlara özgüdür.",
                    "RRD'de sıvı yırtığa bağlı olduğu için ve TRD'de membranlar tuttuğu için sıvı bu şekilde yer değiştirmez."
                ],
                "footer": "30 Dk Supin Testi / RRD ve TRD'de Olmaz"
            },
            {
                "card_title": "3. Tanısal Değer ve Tuzaklar",
                "lead": "Gereksiz Cerrahinin Önlenmesi",
                "items": [
                    "Alt kadranda büllöz elevasyon gören deneyimsiz hekim 'yırtıksız RRD' zannedip acil ameliyata alabilir [s.173].",
                    "ERD olgusuna vitrektomi veya sklera çökertme yapmak tabloyu ağırlaştırır ve iatrojenik hasar verir.",
                    "B-Scan USG'de koroid kalınlığı artışı, skleral kalınlaşma veya kitle aranmalıdır.",
                    "Shifting sıvı saptandığında ilk adım romatolojik/üveitik ve onkolojik tarama olmalıdır."
                ],
                "footer": "Gereksiz Vitrektomiyi Önler / Sistemik Tarama"
            }
        ]
    )

    # Slayt 5.2.2.6: Dekolman Tipleri Karşılaştırmalı Ayırıcı Tanı Atlası
    builder.add_study_card_slide(
        title="ÜÇ DEKOLMAN TİPİNİN BÜYÜK KARŞILAŞTIRMA MATRİSİ",
        category="BÖLÜM 5.2.2: SENTEZ",
        subtitle="Regmatojen (RRD) vs Traksiyonel (TRD) vs Eksüdatif (ERD) Ayırıcı Tanı Kriterleri",
        cards=[
            {
                "card_title": "1. Regmatojen (RRD)",
                "lead": "Yırtık + Vitreus Sıvısı",
                "items": [
                    "Patogenez: Tam kat yırtık + likefiye vitreus geçişi [s.170].",
                    "Konfigürasyon: Konveks, dalgalı, ora serrataya kadar uzanır.",
                    "Sıvı Özelliği: Berrak, göz hareketleriyle dalgalanır, shifting YOKTUR.",
                    "Tedavi: Cerrahi şart (Pnömatik, Sklera Çökertme veya PPV)."
                ],
                "footer": "Konveks / Yırtık (+) / Cerrahi Şart"
            },
            {
                "card_title": "2. Traksiyonel (TRD)",
                "lead": "Fibrovasküler Membran Çekintisi",
                "items": [
                    "Patogenez: PDR/PVR membranlarının mekanik kontraksiyonu [s.170].",
                    "Konfigürasyon: Konkav, gergin, arkatlarla sınırlı, hareketsiz.",
                    "Sıvı Özelliği: Minimal subretinal sıvı, tepe noktası membrandadır.",
                    "Tedavi: Fovea tutulursa Cerrahi (PPV + Membran Soyma)."
                ],
                "footer": "Konkav / Membran Çekintisi / Seçici PPV"
            },
            {
                "card_title": "3. Eksüdatif (ERD)",
                "lead": "Damar Kaçağı / Bozulmuş Pompa",
                "items": [
                    "Patogenez: Koroid neoplazisi, VKH, posterior sklerit, hipertansiyon [s.171].",
                    "Konfigürasyon: Çok büllöz, pürüzsüz yüzey, katlantı/undülasyon yok.",
                    "Sıvı Özelliği: Proteinden zengin, SHIFTING (yer değiştiren) sıvı (+).",
                    "Tedavi: Tıbbi/Etiyolojik (Steroid, İmmünsüpresif, Radyoterapi)."
                ],
                "footer": "Büllöz / Shifting (+) / Tıbbi Tedavi"
            }
        ]
    )

    # Slayt 5.2.2.7: Non-Regmatojen Dekolman Yönetim Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="NON-REGMATOJEN RETİNA DEKOLMANI KLİNİK ALGORİTMASI",
        category="BÖLÜM 5.2.2: AKIŞ ŞEMASI",
        subtitle="Yırtık Saptanmayan Dekolmanlarda Adım Adım Etyolojik ve Tedavi Triyajı",
        steps=[
            {
                "num": "1",
                "title": "Yırtık Dışlama ve Yüzey Analizi",
                "desc": "360° muayene ile yırtık olmadığı kesinleştirilir; konveks/konkav morfoloji değerlendirilir [s.172].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Shifting Sıvı Testi (Supin Pozisyon)",
                "desc": "Hasta 30-45 dk yatırılarak sıvının yerçekimiyle makulaya kayıp kaymadığı kontrol edilir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Multimodal Görüntüleme & USG",
                "desc": "B-Scan USG (T-sign, kitle, kalınlaşma), EDI-OKT ve FFA/ICG ile koroidal patoloji taranır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Hedefe Yönelik Tedavi Başlanması",
                "desc": "VKH/Skleritte yüksek doz pulse steroid; tümörde onkolojik protokol; TRD'de foveal vitrektomi.",
                "status": "success"
            }
        ],
        bottom_takeaway="Yırtığı gösterilemeyen ve shifting sıvı veren bir hastada ameliyathaneye girmek yerine romatoloji veya onkoloji konsültasyonu istemek hastanın gözünü kurtarır [s.172]."
    )

    # Slayt 5.2.2.8: Aktif Hatırlama & Board Sınavı Vakası: VKH Eksüdatif Dekolman
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: EKSÜDATİF DEKOLMAN",
        category="BÖLÜM 5.2.2: AKTİF HATIRLAMA",
        subtitle="32 Yaşında Kadın Hastada Şiddetli Baş Ağrısı, Kulak Çınlaması ve İki Taraflı Büllöz Sıvı",
        vignette="32 yaşında kadın hasta, 1 haftadır devam eden şiddetli baş ağrısı, kulak çınlaması (tinnitus) ve son 3 günde her iki gözde ani görme azalması şikayetiyle başvuruyor. Görme keskinliği sağda 0.1, solda 0.2. Biyomikroskopide her iki gözde ön kamarada 1+ hücre ve arka vitreusta hafif pus izleniyor. Göz dibi muayenesinde her iki gözde arka kutupta ve alt kadranda çok sayıda kabarıklık oluşturan, pürüzsüz yüzeyli, büllöz seröz retina dekolmanı odakları izleniyor; periferde yırtık veya delik saptanmıyor. B-Scan USG'de diffüz koroid kalınlaşması mevcut. Hasta 30 dakika supin yatırıldığında alt kadrandaki sıvının fovea altına kaydığı (shifting fluid) gözleniyor.",
        differentials=[
            "Vogt-Koyanagi-Harada (VKH) Sendromu (Bilateral eksüdatif dekolman, baş ağrısı, tinnitus ve koroid kalınlaşması).",
            "Bilateral Regmatojen Retina Dekolmanı (Yırtık yoktur, shifting sıvı RRD'de görülmez).",
            "Malign Hipertansiyona Bağlı Eksüdatif Dekolman (Tansiyon normalse dışlanır).",
            "Santral Sinir Sistemi Lenfoması (Hücresel infiltrat ön plandadır)."
        ],
        decision="1. Tanı: Akut Vogt-Koyanagi-Harada (VKH) Sendromuna bağlı Bilateral Eksüdatif Retina Dekolmanı.\n2. Tedavi: Kesinlikle cerrahi uygulanmaz. Derhal hospitalize edilerek 3 gün boyunca İntravenöz Yüksek Doz Pulse Metilprednizolon (1000 mg/gün) başlanmalı, ardından oral steroid ve immünsüpresif (Azatioprin/Siklosporin) ile idameye geçilmelidir.\n3. Yanıt: Uygun steroid dozu ile 48-72 saatte subretinal sıvı tamamen emilir ve retina anatomik olarak yatışır.",
        board_trap="Bu hastada 'dekolman var' diyerek hastayı acil ameliyata (vitrektomiye) almak felaketle sonuçlanır; inflamasyon patlar ve göz fitizise gider; eksüdatif dekolmanın tedavisi cerrahi değil tıbbidir [s.171]."
    )

    # =========================================================================
    # 5.2.3: PROLİFERATİF VİTREORETİNOPATİ (PVR), EVRELEME VE CERRAHİ (8 Slayt)
    # =========================================================================

    # Slayt 5.2.3.1: PVR Patofizyolojisi: RPE Göçü ve EMT Kaskadı
    builder.add_study_card_slide(
        title="PROLİFERATİF VİTREORETİNOPATİ (PVR) PATOFİZYOLOJİSİ",
        category="BÖLÜM 5.2.3: PATOFİZYOLOJİ",
        subtitle="RRD Cerrahisi Başarısızlığının 1 Numaralı Nedeni: RPE Göçü ve Epitelyal-Mezenkimal Geçiş",
        cards=[
            {
                "card_title": "1. Hücresel Dağılım & Göç",
                "lead": "Yırtıktan Vitreusa RPE Kaçışı",
                "items": [
                    "Retinada tam kat yırtık açıldığında RPE hücreleri tek katlı epitel diziliminden kopar [s.173].",
                    "Kopup serbestleşen RPE hücreleri sıvı akımıyla vitreus boşluğuna ve retina iç yüzeyine göç eder.",
                    "Vitreustaki sitokinler (TGF-beta, PDGF, FGF, IL-6) hücreleri uyararak kontrolsüz çoğalmayı başlatır.",
                    "Bu nedenle geniş yırtıklar, dev yırtıklar ve aşırı kriyoterapi yapılmış gözler en büyük PVR adaylarıdır."
                ],
                "footer": "Yırtık -> RPE Göçü -> Sitokin Fırtınası"
            },
            {
                "card_title": "2. Epitelyal-Mezenkimal Geçiş (EMT)",
                "lead": "Epitelden Kasılabilen Hücreye Dönüşüm",
                "items": [
                    "RPE hücreleri TGF-beta etkisiyle epitelyal fenotiplerini kaybedip mezenkimal kök hücreye dönüşür [s.173].",
                    "Alfa-SMA (düz kas aktini) sentezlemeye başlayarak 'miyofibroblast' karakteri kazanırlar.",
                    "Miyofibroblastlar hücre dışı matrise bol miktarda fibronektin ve tip I/III kollajen salgılar.",
                    "Böylece retina yüzeyinde ve subretinal aralıkta kasılma yeteneği olan fibrotik membranlar örülür."
                ],
                "footer": "RPE -> Miyofibroblast (Alfa-SMA) -> Membran"
            },
            {
                "card_title": "3. Kasılma ve Retinal Rijidite",
                "lead": "Yıldız Katlantılar ve Huni Şekli",
                "items": [
                    "Oluşan membranlar kasıldıkça retinayı buruşturur ve yıldız katlantılar (star folds) oluşturur [s.174].",
                    "Retina elastikiyetini tamamen kaybederek sert, rijit ve kalın bir tabaka halini alır.",
                    "Zamanla anterior PVR vitreus tabanını öne çeker, posterior PVR ise retinayı kapalı bir huni (closed funnel) yapar.",
                    "RRD ameliyatı sonrası nükslerin %75'inden tek başına PVR gelişimi sorumludur."
                ],
                "footer": "Kasılma -> Star Fold -> Kapalı Huni"
            }
        ]
    )

    # Slayt 5.2.3.2: PVR Güncellenmiş Sınıflaması: Evre A, B, C
    builder.add_study_card_slide(
        title="GÜNCELLENMİŞ PVR EVRELEME SİSTEMİ (RETİNA DERNEĞİ)",
        category="BÖLÜM 5.2.3: EVRELEME",
        subtitle="Evre A (Minimal), Evre B (Orta), Evre C (İleri - Fokal, Diffüz, Subretinal ve Anterior)",
        cards=[
            {
                "card_title": "1. Evre A ve Evre B (Erken Evreler)",
                "lead": "Geri Dönüşümlü Hücresel Faz",
                "items": [
                    "Evre A (Minimal): Vitreus pusu, serbest RPE pigment kümeleri (tütün tozu) [s.174].",
                    "Retina yüzeyinde henüz belirgin membran veya katlantı oluşmamıştır.",
                    "Evre B (Orta): Retina iç yüzeyinde kırışıklıklar, damar kıvrımlaşması, yırtık kenarlarının kıvrılması.",
                    "Retina hareketliliği hafif azalmıştır ancak henüz rijit sabit katlantı yoktur."
                ],
                "footer": "Evre A (Pus/Pigment) / Evre B (Kırışıklık/Kıvrılma)"
            },
            {
                "card_title": "2. Evre C Posterior (CP)",
                "lead": "Ekvator Gerisindeki Rijit Katlantılar",
                "items": [
                    "Fokal (CP-1): Ekvator gerisinde izole yıldız katlantı (star fold) [s.174].",
                    "Diffüz (CP-2): Ekvator gerisindeki tüm retinayı saran birleşik, kalın membranlar; huni konfigürasyonu.",
                    "Subretinal (CP-3): Subretinal aralıkta retinayı tentür gibi çeken kordonlar veya çamaşır ipi (clothesline) bantları.",
                    "Saat kadranı sayısı ile derecelendirilir (örn: CP-diffüz 6 saat kadranı)."
                ],
                "footer": "CP-Fokal / CP-Diffüz / CP-Subretinal Bant"
            },
            {
                "card_title": "3. Evre C Anterior (CA)",
                "lead": "Vitreus Tabanı ve Siliyer Cisim Traksiyonu",
                "items": [
                    "Fokal (CA-1): Ekvator önünde vitreus tabanını çeken lokalize katlantılar [s.174].",
                    "Diffüz (CA-2): Vitreus tabanını 360 derece çevreleyen sirkumferensiyal kasılma bandı.",
                    "Anterior Yer Değiştirme (CA-3): Retinanın ora serratadan öne siliyer cisme ve lens arkasına çekilmesi.",
                    "Anterior PVR cerrahi olarak temizlenmesi en zor ve hipotoni riski en yüksek formdur."
                ],
                "footer": "CA-Sirkumferensiyal / Siliyer Traksiyon"
            }
        ]
    )

    # Slayt 5.2.3.3: PVR İleri Evre Morfolojisi: Yıldız Katlantılar ve Subretinal Bantlar
    builder.add_study_card_slide(
        title="PVR KLİNİK PATOLOJİLERİ: YILDIZ KATLANTILAR VE BANTLAR",
        category="BÖLÜM 5.2.3: MORFOLOJİ",
        subtitle="Star Fold, Subretinal 'Çamaşır İpi' Kordonları ve Anterior Halka Kasılması",
        cards=[
            {
                "card_title": "1. Yıldız Katlantı (Star Fold) Mimarisi",
                "lead": "Merkezkaç Epiretinal Kasılma",
                "items": [
                    "Bir epiretinal miyofibroblast odağının kasılarak çevresindeki retinayı tek bir merkeze çekmesidir [s.175].",
                    "Ortada sarımsı-beyaz fibrotik bir düğüm, etrafında ise ışınsal katlantı çizgileri izlenir.",
                    "Retina damarları bu düğümün içine doğru bükülür ve kıvrılır.",
                    "Cerrahide amaç: Bu düğümün merkezini mikro-forceps ile yakalayıp retinadan radyal soymaktır."
                ],
                "footer": "Epiretinal Düğüm / Işınsal Katlantı / Soyma"
            },
            {
                "card_title": "2. Subretinal Bantlar (Clothesline)",
                "lead": "Retina Altında Kordon Oluşumu",
                "items": [
                    "RPE hücreleri subretinal aralıkta lineer hatlar boyunca prolifere olup organize olur [s.175].",
                    "Beyaz, kalın bir ip gibi uzanan bu bantlar retinayı RPE tabanından yukarı doğru çadırlaştırır.",
                    "Bazen tek bir bant tüm arka kutbu baştan başa geçerek retinanın yatışmasını mekanik olarak engeller.",
                    "Epiretinal membranlar soyulsa bile subretinal bant kesilmedikçe retina düzleşmez."
                ],
                "footer": "Çadırlaşma / Mekanik Blokaj / Retinotomiyle Kesme"
            },
            {
                "card_title": "3. Ön Halka (Anterior Ring) Kasılması",
                "lead": "Vitreus Tabanının Daralması",
                "items": [
                    "Vitreus tabanı boyunca sirkumferensiyal (çembersel) büzülme retinanın çapını daraltır [s.175].",
                    "Retina koroid yüzeyine göre 'küçük' kalır ve küre yüzeyine oturamaz.",
                    "Siliyer cisim traksiyonu aköz salgısını baskılayarak derin oküler hipotoniye ve fitizise yol açar.",
                    "Bu durum geliştiğinde retinanın yatışabilmesi için geniş gevşetici retinektomi kaçınılmazdır."
                ],
                "footer": "Çap Daralması / Hipotoni / Gevşetici Retinektomi"
            }
        ]
    )

    # Slayt 5.2.3.4: PVR İçin Cerrahi Teknikler: Membran Soyma ve Retinektomi
    builder.add_study_card_slide(
        title="PVR CERRAHİ STRATEJİSİ: SOYMA, PFCL VE RETİNEKTOMİ",
        category="BÖLÜM 5.2.3: CERRAHİ TEKNİK",
        subtitle="23/25G Bimanüel Vitrektomi, Triamsinolon, Ağır Sıvı ve 360° Gevşetici Retinektomi",
        cards=[
            {
                "card_title": "1. Membran Tespiti ve Titiz Soyma",
                "lead": "Mikro-Forseps ve Bimanüel Diseksiyon",
                "items": [
                    "Kromovitrektomi: Triamsinolon veya parlak mavi (BBG) ile membranların sınırları belirginleştirilir [s.175].",
                    "ILM forsepsleri veya mikro-makaslar kullanılarak yıldız katlantıların merkezindeki zarlar soyulur.",
                    "Geniş membranlarda traksiyonu rahatlatmak için önce 'segmentasyon' (araları kesme), sonra 'delaminasyon' yapılır.",
                    "Tek bir küçük membran odağı bile bırakılırsa postoperatif 3 haftada nüks PVR geliştirir."
                ],
                "footer": "Kromovitrektomi / Segmentasyon / Delaminasyon"
            },
            {
                "card_title": "2. Perflorokarbon Sıvı (PFCL) Desteği",
                "lead": "Mekanik Sıvı Manivelası",
                "items": [
                    "Optik disk üzerine kontrollü enjekte edilen PFCL (ağır sıvı), yüksek özgül ağırlığıyla retinayı arkadan öne yatıştırır [s.176].",
                    "Retinayı gergin tutarak ön periferdeki membranların güvenle soyulmasına zemin hazırlar.",
                    "Subretinal sıvıyı yırtıklardan öne doğru sıkarak tahliye eder.",
                    "Membran soyulduktan sonra PFCL hava ile değiştirilirken lazer fotokoagülasyon uygulanır."
                ],
                "footer": "Ağır Sıvı / Arkadan Öne Yatıştırma / Stabilizasyon"
            },
            {
                "card_title": "3. Gevşetici Retinektomi (Retinotomi)",
                "lead": "Kısalmış Retinayı Serbestleştirme",
                "items": [
                    "Tüm membranlar soyulmasına rağmen retina anterior traksiyon nedeniyle koroid tabanına oturmuyorsa [s.176]:",
                    "Diyatermi eşliğinde büzüşmüş periferik retina 180° ila 360° boyunca kesilerek eksize edilir (retinektomi).",
                    "Retina gerilimi sıfırlanır ve kalan vital retina dokusu PFCL altında tamamen yatışır.",
                    "Yeni oluşturulan retinektomi sınırına 3-4 sıra sıkı endolazer atılır."
                ],
                "footer": "Gerilimi Sıfırlama / 360° Kesim / Sınır Endolazer"
            }
        ]
    )

    # Slayt 5.2.3.5: Tamponad Seçimi: Silikon Yağı vs Gaz Tamponadı
    builder.add_split_comparison_slide(
        title="PVR'DE İÇ TAMPONAD SEÇİMİ: SİLİKON YAĞI vs GAZ",
        category="BÖLÜM 5.2.3: TAMPONAD",
        subtitle="Uzun Süreli Stabilizasyon Sağlayan Silikon Yağı vs Rezorbe Olan Genleşici Ağır Gazlar",
        left_entity={
            "name": "SİLİKON YAĞI (1000 cSt / 5000 cSt)",
            "subtitle": "PVR Cerrahisinde Tartışmasız İlk Tercih",
            "bullets": [
                "Tamponad Süresi: Rezorbe olmaz; aylarca (3-6 ay veya kalıcı) göz içinde kalarak retinayı yerinde tutar [s.176].",
                "PVR İnhibisyonu: Serbest sitokinlerin ve RPE hücrelerinin alt kadranda toplanmasını fiziksel olarak sınırlar.",
                "Uçak / Rakım Uyumu: Gaz gibi genleşmez; hasta uçak yolculuğu yapabilir, rakım kısıtlaması yoktur.",
                "Vizkozite: 1000 cSt kolay enjekte edilir/çıkarılır; 5000 cSt emülsifikasyona daha dirençlidir.",
                "Dezavantaj: İkinci bir cerrahiyle çıkarılması gerekir; keratopati ve emülsifiye glokom riski taşır [s.176]."
            ]
        },
        right_entity={
            "name": "GENLEŞİCİ AĞIR GAZLAR (C3F8 / SF6)",
            "subtitle": "Yalnızca Minimal PVR (Evre A/B) Olgularında Seçenek",
            "bullets": [
                "Tamponad Süresi: Kendiliğinden rezorbe olur (SF6 2 hafta, C3F8 6-8 hafta); ikinci ameliyat gerektirmez [s.176].",
                "Yüzey Gerilimi: Silikon yağına göre daha yüksek yüzey gerilimi sağlar; yırtığı mükemmel kapatır.",
                "PVR Riski: İleri PVR'de gaz eridikçe nüks oranı %60'ın üzerindedir; uzun süreli rijiditeyi yenemez.",
                "Uçak / Rakım Kısıtlaması: Gözde gaz varken uçağa binmek veya yüksek rakıma çıkmak KESİNLİKLE YASAKTIR.",
                "Klinik Rol: PVR Evre C olgularında gaz yerine daima silikon yağı tercih edilmelidir [s.176]."
            ]
        },
        bottom_takeaway="İleri PVR cerrahisinde gaz tamponadı verilmesi yüksek nüks riski taşır; retinektomi yapılmış veya star fold soyulmuş olgularda en az 3-6 ay silikon yağı bırakılması altın kuraldır [s.176]."
    )

    # Slayt 5.2.3.6: PVR Rekürrens Önleme ve Farmakoterapi
    builder.add_study_card_slide(
        title="PVR ADJUVAN FARMAKOTERAPİSİ VE GELECEK PERSPEKTİFLER",
        category="BÖLÜM 5.2.3: FARMAKOTERAPİ",
        subtitle="Hücre Proliferasyonunu Baskılama Arayışları: Metotreksat, Steroidler ve 5-FU/Heparin",
        cards=[
            {
                "card_title": "1. İntravitreal Metotreksat (MTX)",
                "lead": "Antimetabolit ile Hücre Bölünmesini Durdurma",
                "items": [
                    "Metotreksat, folat antagonizması yaparak prolifere olan RPE ve glial hücrelerin DNA sentezini engeller [s.177].",
                    "Cerrahi sırasında infüzyon sıvısına katılarak veya postoperatif tekrarlayan enjeksiyonlar (haftalık) şeklinde verilir.",
                    "Son klinik serilerde tekrarlayan PVR oranlarını %30-40 oranında azalttığı bildirilmiştir.",
                    "Göz içi dokulara toksisitesi düşüktür; silikon yağı varken de uygulanabilir."
                ],
                "footer": "Folat Antagonisti / Haftalık Enjeksiyon"
            },
            {
                "card_title": "2. Kortikosteroidler (Deksametazon / TA)",
                "lead": "Sitokin Fırtınasını Baskılama",
                "items": [
                    "Triamsinolon asetonid (TA) cerrahide membranları boyamanın yanı sıra antienflamatuar etki gösterir [s.177].",
                    "Yavaş salınımlı deksametazon implantı (Ozurdex) silikon yağı ile birlikte kombine edilerek denenmektedir.",
                    "Kan-retina bariyerini stabilize eder ve TGF-beta / PDGF salınımını sınırlar.",
                    "Steroid ilişkili GİB artışı silikonlu gözlerde dikkatle izlenmelidir."
                ],
                "footer": "Ozurdex / Triamsinolon / Sitokin Blokajı"
            },
            {
                "card_title": "3. 5-FU ve Düşük Molekül Ağırlıklı Heparin",
                "lead": "Tarihsel Kombinasyon Protokolleri",
                "items": [
                    "5-Fluorourasil (antimetabolit) ve Heparin (hücre göçü ve fibrin inhibitörü) kombinasyonu uzun yıllar araştırılmıştır [s.177].",
                    "Bazı çalışmalarda nüksü azalttığı gösterilse de kornea epitel toksisitesi ve kanama riskini artırabilmektedir.",
                    "Günümüzde yerini daha güvenli moleküller olan intravitreal Metotreksat ve biyolojik ajanlara bırakmaktadır.",
                    "PVR'de kesin ve evrensel kabul görmüş tek bir farmakolojik ajan henüz yoktur; titiz cerrahi esastır."
                ],
                "footer": "Toksisite Riski / Cerrahi Temizliğin Önemi"
            }
        ]
    )

    # Slayt 5.2.3.7: PVR Cerrahi Algoritması ve Triyaj
    builder.add_decision_tree_slide(
        title="PVR CERRAHİ YÖNETİM PROTOKOLÜ VE TRİYAJ",
        category="BÖLÜM 5.2.3: ALGORİTMA",
        subtitle="Evreye ve Traksiyonun Yönüne Göre Adım Adım Cerrahi Karar Ağacı",
        root_label="REGMATOJEN RETİNA DEKOLMANI ZEMİNİNDE PVR SAPTANDI",
        branches=[
            {
                "label": "1. PVR Evre B veya Fokal Evre C",
                "criteria": "1-2 kadranda hafif kıvrılma veya tek bir izole yıldız katlantı [s.174].",
                "action": "Standart PPV + Membran Soyma: Forseps ile membran soyulur, PFCL ile yatıştırılır, endolazer ve Gaz/Silikon verilir."
            },
            {
                "label": "2. Diffüz Posterior PVR (CP-diffüz)",
                "criteria": "Tüm arka kutbu saran birleşik membranlar, rijit kıvrımlar, huni morfolojisi [s.175].",
                "action": "Kapsamlı Bimanüel Diseksiyon: Kromovitrektomi desteğiyle tüm zarlar delamine edilir; en az 3-6 ay Silikon Yağı."
            },
            {
                "label": "3. Anterior PVR / Kısalmış Retina",
                "criteria": "Vitreus tabanı büzüşmüş, retina siliyer cisme çekilmiş; membran soyulsa da retina oturmuyor [s.176].",
                "action": "Gevşetici Retinektomi + Silikon: Traksiyon hattı boyunca 180-360° retinektomi yapılır; PFCL altında endolazer ve 5000 cSt Silikon."
            }
        ],
        bottom_rule="Anterior PVR'de retinanın elastikiyeti kaybolmuşsa retinayı zorla koroid yüzeyine çekmeye çalışmak yırtıkları büyütür; tek çözüm cesurca geniş gevşetici retinektomi yapmaktır [s.176]."
    )

    # Slayt 5.2.3.8: Aktif Hatırlama & Board Sınavı Vakası: Nüks PVR Evre C Dekolmanı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: İLERİ EVRE PVR",
        category="BÖLÜM 5.2.3: AKTİF HATIRLAMA",
        subtitle="4 Hafta Önce RRD Cerrahisi Geçirmiş Hastada Gaz Erirken Gelişen Rijit Nüks Dekolman",
        vignette="58 yaşında erkek hasta, 4 hafta önce sağ göz psödofakik RRD nedeniyle 23G PPV ve %14 C3F8 gaz tamponadı ameliyatı geçirmiştir. Ameliyatın 2. haftasında retinası yatışık olan hastada, gaz kabarcığı %20 seviyesine gerilediğinde görme tekrar el hareketine düşüyor. Biyomikroskopide ön kamarada 2+ flare, retrolental alanda bol serbest RPE pigmenti izleniyor. Fundus muayenesinde ekvator gerisinde 3 farklı kadranda belirgin yıldız katlantılar (star fold), inferior retinada çamaşır ipi şeklinde kalın subretinal bant ve retinanın tamamen rijit, büzüşmüş huni şeklinde yeniden dekolle olduğu (PVR Evre CP-diffüz) saptanıyor.",
        differentials=[
            "PVR Evre CP-Diffüz Zemininde Nüks Regmatojen Retina Dekolmanı (Doğru klinik tanı).",
            "Gaz Tamponadının Erken Erimesine Bağlı Basit Nüks (PVR olmasaydı retina dalgalı olurdu, burada rijit katlantılar var).",
            "Postoperatif Endoftalmi (Göz ağrısızdır, hipopiyon yoktur, tablo enfeksiyöz değil proliferatiftir).",
            "Subretinal Kanamaya Bağlı Dekolman."
        ],
        decision="1. Klinik Tanı: PVR Evre C Zemininde Nüks Retina Dekolmanı.\n2. Cerrahi Planlama: Hasta vakit kaybetmeden revizyon vitrektomisine alınmalıdır.\n3. Cerrahi Adımlar: Kalan gaz boşaltılır; triamsinolon ile tüm epiretinal membranlar boyanarak mikro-forsepslerle soyulur; subretinal banda retinotomi yapılarak bant eksize edilir; retina PFCL ile yatıştırılır; yırtık ve retinotomi kenarlarına 360° endolazer uygulanır ve gaz KESİNLİKLE KULLANILMAYARAK 5000 cSt Silikon Yağı verilir.",
        board_trap="PVR Evre C gelişmiş bir göze 'bir kez daha gaz verelim' demek kesin cerrahi başarısızlıkla sonuçlanır; bu aşamada tek güvenilir uzun dönemli tamponad silikon yağıdır [s.176]."
    )

    print(f" -> Bölüm 5 (Retina Dekolmanı ve Periferik Retina) Tamamlandı: 41 Slayt Eklendi.")
