r"""
batch_extract_all_volumes.py — 56 Ciltlik Oftalmoloji Kütüphanesini Toplu Tarama ve Görsel Bankası Oluşturma
=========================================================================================================
Bu betik `C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI` klasöründeki tüm PDF'leri
(AAO BCSC 2025-2026 serisi, Ryan's Retina, Wills Eye Atlasları, Diagnostics in Ocular Imaging vb.)
tarar; yalnızca gerçek klinik, cerrahi ve şematik görselleri (küçük ikon ve süslemeleri eleyerek)
ayıklar, alt yazılarını yakalar ve Obsidian ile uyumlu Master Kataloğu günceller.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import pymupdf

# Terminal UTF-8
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

LOCAL_DB_DIR = Path(r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI")
WORKSPACE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
CATALOG_DIR = WORKSPACE_DIR / "assets" / "visual_catalog"
IMAGE_BANK_DIR = CATALOG_DIR / "images"
MASTER_JSON_PATH = CATALOG_DIR / "master_catalog.json"
OBSIDIAN_CATALOG_PATH = Path(r"C:\Users\gezic\Obsidian\TEG\Oftalmoloji_Gorsel_Katalogu.md")
DESKTOP_MD_PATH = WORKSPACE_DIR / "OPHTHALMOLOGY_VISUAL_CATALOG.md"


def classify_category_by_book_and_text(book_name: str, caption_text: str) -> str:
    """Kitap adına ve şekil alt yazısına göre oftalmoloji alt branşını belirler."""
    name_l = book_name.lower()
    cap_l = caption_text.lower()
    combined = f"{name_l} {cap_l}"

    if "11-lens" in name_l or "cataract" in combined or "phaco" in combined or "iol" in combined:
        return "Lens & Cataract Surgery"
    elif "12-retina" in name_l or "ryan" in name_l or "retina" in combined or "macula" in combined or "oct" in combined:
        return "Retina & Vitreous"
    elif "10-glaucoma" in name_l or "glaucoma" in combined or "perimetry" in combined or "visual field" in combined:
        return "Glaucoma & Optic Nerve"
    elif "08-external" in name_l or "cornea" in combined or "topography" in combined or "refractive" in combined:
        return "Cornea, External Disease & Refractive"
    elif "09-uveitis" in name_l or "uveitis" in combined or "endophthalmitis" in combined or "inflamm" in combined:
        return "Uveitis & Ocular Inflammation"
    elif "05-neuro" in name_l or "neuro" in combined:
        return "Neuro-Ophthalmology"
    elif "06-pediatric" in name_l or "pediatric" in combined or "strabismus" in combined:
        return "Pediatric Ophthalmology & Strabismus"
    elif "07-oculofacial" in name_l or "oculoplastic" in combined or "orbit" in combined:
        return "Oculoplastics & Orbit"
    elif "04-ophthalmic pathology" in name_l or "pathology" in combined or "tumor" in combined:
        return "Ophthalmic Pathology & Oncology"
    elif "03- clinical optics" in name_l or "optics" in combined:
        return "Clinical Optics & Refraction"
    elif "diagnostics" in name_l or "imaging" in combined:
        return "Multimodal Ocular Diagnostics"
    else:
        return "Comprehensive Ophthalmology & Atlases"


def process_single_pdf(
    pdf_path: Path,
    output_dir: Path,
    min_w: int = 340,
    min_h: int = 240,
    min_bytes: int = 15_000
) -> List[Dict[str, Any]]:
    """Tek bir PDF dosyasındaki yüksek kaliteli görselleri ayıklar."""
    entries = []
    book_slug = re.sub(r"[^A-Za-z0-9_-]", "_", pdf_path.stem)
    target_book_dir = output_dir / book_slug
    target_book_dir.mkdir(parents=True, exist_ok=True)

    seen_xrefs: Set[int] = set()

    try:
        doc = pymupdf.open(str(pdf_path))
    except Exception as e:
        print(f"  [HATA] Dosya açılamadı ({pdf_path.name}): {e}")
        return []

    total_pages = len(doc)
    img_counter = 0

    for page_num in range(total_pages):
        try:
            page = doc[page_num]
            images = page.get_images(full=True)
            if not images:
                continue

            page_text = page.get_text()

            for info in images:
                xref = info[0]
                if xref in seen_xrefs:
                    continue  # Mükerrer görseli atla
                seen_xrefs.add(xref)

                try:
                    base = doc.extract_image(xref)
                except Exception:
                    continue

                w, h = base["width"], base["height"]
                img_data = base["image"]

                # Boyut ve kalite filtresi
                if w < min_w or h < min_h:
                    continue
                if len(img_data) < min_bytes:
                    continue
                ratio = w / float(h)
                if ratio < 0.18 or ratio > 5.5: # Aşırı ince çizgi veya şeritleri ele
                    continue

                img_counter += 1
                ext = base["ext"]
                img_filename = f"{book_slug}_p{page_num+1:03d}_fig{img_counter:03d}.{ext}"
                dest_file = target_book_dir / img_filename

                with open(dest_file, "wb") as f:
                    f.write(img_data)

                # Şekil alt yazısı yakalama
                captions = re.findall(r"(?:Figure|Fig\.|Şekil|Resim)\s*[\d\.\-]+[^\n\r]+", page_text)
                cap_text = " | ".join(captions[:2]) if captions else f"{pdf_path.name} (s.{page_num+1})"

                category = classify_category_by_book_and_text(pdf_path.name, "")

                entry = {
                    "id": f"LOC_{book_slug[:18]}_{img_counter:04d}",
                    "source_type": "local_database",
                    "book": pdf_path.name,
                    "page": page_num + 1,
                    "category": category,
                    "filename": img_filename,
                    "file_path": str(dest_file),
                    "width": w,
                    "height": h,
                    "caption": "",
                    "page_captions_unaligned": captions,
                    "review_status": "review_required",
                    "tags": [w.lower() for w in re.findall(r"[A-Za-zÇĞİÖŞÜçğıöşü]{4,}", "")]
                }
                entries.append(entry)
        except Exception:
            continue

    return entries


def run_full_library_extraction():
    """Tüm PDF kitaplarını tarar ve ana kataloğu üretir."""
    print("=" * 70)
    print("TÜM OFTALMOLOJİ CİLTLERİ TOPLU GÖRSEL ÇIKARMA VE İNDEKSLEME BORU HATTI")
    print("=" * 70)

    if not LOCAL_DB_DIR.exists():
        print(f"HATA: Kitaplık dizini bulunamadı: {LOCAL_DB_DIR}")
        return

    pdf_files = sorted(list(LOCAL_DB_DIR.glob("*.pdf")), key=lambda p: p.name)
    total_books = len(pdf_files)
    print(f"Tespit Edilen Toplam Kitap Sayısı: {total_books}")

    # Mevcut çevrimiçi veritabanlarını yükle
    online_dbs = []
    if MASTER_JSON_PATH.exists():
        try:
            with open(MASTER_JSON_PATH, "r", encoding="utf-8") as f:
                existing_data = json.load(f)
                online_dbs = existing_data.get("online_databases", [])
        except Exception:
            pass

    all_extracted_images: List[Dict[str, Any]] = []
    start_time = time.time()

    for idx, pdf_p in enumerate(pdf_files, 1):
        print(f"[{idx}/{total_books}] Taranıyor: {pdf_p.name} ({pdf_p.stat().st_size / (1024*1024):.1f} MB)...")
        t0 = time.time()
        book_images = process_single_pdf(pdf_p, IMAGE_BANK_DIR)
        t_elapsed = time.time() - t0
        all_extracted_images.extend(book_images)
        print(f"   -> {len(book_images)} görsel ayıklandı ({t_elapsed:.1f} sn). Kümülatif: {len(all_extracted_images)}")

    total_time = time.time() - start_time
    print("\n" + "=" * 70)
    print(f"TARAMA TAMAMLANDI! Toplam {len(all_extracted_images)} görsel çıkarıldı ({total_time:.1f} sn)")
    print("=" * 70)

    # Master JSON Güncellemesi
    master_dict = {
        "title": "Akademik Çalışma Ortağı — Oftalmoloji Görsel ve Şema Master Kataloğu (Tam Arşiv)",
        "last_updated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_local_images": len(all_extracted_images),
        "total_source_books": total_books,
        "online_databases": online_dbs,
        "local_images": all_extracted_images
    }

    MASTER_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(MASTER_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(master_dict, f, ensure_ascii=False, indent=2)
    print(f" -> Master JSON kaydedildi: {MASTER_JSON_PATH.name} ({len(all_extracted_images)} görsel)")

    # Markdown Kataloglarını Güncelle
    generate_markdown_catalogs(master_dict)


def generate_markdown_catalogs(master_dict: Dict[str, Any]):
    """Obsidian kasasına ve masaüstüne kapsamlı master Markdown tablosu yazar."""
    images = master_dict.get("local_images", [])
    total_imgs = len(images)
    total_books = master_dict.get("total_source_books", 0)

    # Kategorilere göre say
    by_category: Dict[str, List[Dict[str, Any]]] = {}
    for img in images:
        cat = img.get("category", "Diğer")
        by_category.setdefault(cat, []).append(img)

    lines = []
    lines.append("# 👁️ OFTALMOLOJİ GÖRSEL VE ŞEMA MASTER KATALOĞU (TAM ARŞİV)")
    lines.append("> **Akademik Çalışma Ortağı — İleri Düzey Görsel Veritabanı ve 56 Ciltlik Klinik Atlas İndeksi**")
    lines.append(f"> *Güncelleme: {master_dict.get('last_updated')} | Toplam Kitap: {total_books} | Arşivlenen Yüksek Çözünürlüklü Görsel: {total_imgs:,}*")
    lines.append("\n---\n")

    lines.append("## 📊 KATEGORİK DAĞILIM VE ÖZET TABLOSU")
    lines.append("| Alt Branş / Uzmanlık Alanı | Görsel Sayısı | Kapsanan Anahtar Kaynaklar |")
    lines.append("|:---|:---:|:---|")

    for cat_name in sorted(by_category.keys()):
        cat_items = by_category[cat_name]
        sample_books = list(set(it["book"] for it in cat_items))[:3]
        books_str = ", ".join([b[:28] + ".." for b in sample_books])
        lines.append(f"| **{cat_name}** | **{len(cat_items):,}** | {books_str} |")

    lines.append(f"| **GENEL TOPLAM** | **{total_imgs:,}** | **56 Kitaplık Arşivin Tümü** |")
    lines.append("\n---\n")

    lines.append("## 📌 1. BÖLÜM: AÇIK ERİŞİMLİ KÜRESEL OFTALMOLOJİ VERİTABANLARI")
    lines.append("Telif sorunu olmayan açık erişimli platformlar ve doğrudan arama derin linkleri:\n")

    for db in master_dict.get("online_databases", []):
        lines.append(f"### 🌐 [{db.get('name', 'Veritabanı')}]({db.get('base_url', '#')})")
        lines.append(f"- **Sağlayıcı:** {db.get('organization', '')}")
        lines.append(f"- **Lisans:** `{db.get('license', '')}`")
        lines.append(f"- **Kapsam:** {db.get('scope', '')}")
        lines.append(f"- **Doğrudan Arama Şablonu:** `{db.get('search_pattern', '')}`")
        if "categories" in db:
            lines.append("- **Kategori Linkleri:** " + " · ".join([f"[{k}]({v})" for k, v in db["categories"].items()]))
        if "direct_articles" in db:
            lines.append("- **Önemli Cerrahi Makaleler:** " + " · ".join([f"[{k}]({v})" for k, v in db["direct_articles"].items()]))
        lines.append("")

    lines.append("---\n")
    lines.append("## 📂 2. BÖLÜM: YEREL ARŞİVDEN ÖRNEK KLİNİK VE CERRAHİ GÖRSELLER")
    lines.append("Her alt branştan öne çıkan yüksek çözünürlüklü (2000+ px) klinik ve şematik görsel örnekleri (Tümüne `master_catalog.json` üzerinden erişilebilir):\n")

    for cat_name in sorted(by_category.keys()):
        cat_items = by_category[cat_name]
        lines.append(f"### 📁 {cat_name} (Toplam: {len(cat_items):,} Görsel)")
        lines.append("| ID | Kitap | Sayfa | Boyut | Açıklama | Bağlantı |")
        lines.append("|:---|:---|:---:|:---:|:---|:---|")

        for item in cat_items[:10]: # İlk 10'unu tabloda listele
            f_link = f"file:///{item['file_path'].replace(os.sep, '/')}"
            cap = (item['caption'][:60] + "...") if len(item['caption']) > 60 else item['caption']
            lines.append(f"| `{item['id']}` | {item['book'][:25]}... | s.{item['page']} | {item['width']}×{item['height']} | {cap} | [Aç]({f_link}) |")

        if len(cat_items) > 10:
            lines.append(f"| *...* | *Kalan {len(cat_items)-10:,} görsel diskte ve JSON kataloğunda kayıtlıdır* | - | - | - | - |")
        lines.append("")

    lines.append("---\n")
    lines.append("## 🔍 3. BÖLÜM: HIZLI ARAMA VE ENTEGRASYON KODU")
    lines.append("```python")
    lines.append("import sys")
    lines.append("sys.path.append(r'c:\\Users\\gezic\\OneDrive\\Desktop\\Anti Gravity')")
    lines.append("from visual_catalog_manager import VisualCatalogManager")
    lines.append("")
    lines.append("mgr = VisualCatalogManager()")
    lines.append("# Retina OCTA ve fovea ile ilgili görselleri ara")
    lines.append("res = mgr.search('octa', category='Retina & Vitreous')")
    lines.append("print(f\"Bulunan görsel sayısı: {res['matched_local_count']}\")")
    lines.append("```")

    full_md = "\n".join(lines)

    # 1. Masaüstü Kopyası
    with open(DESKTOP_MD_PATH, "w", encoding="utf-8") as f:
        f.write(full_md)
    print(f" -> Masaüstü Markdown Kataloğu Güncellendi: {DESKTOP_MD_PATH.name}")

    # 2. Obsidian Kasası Kopyası
    OBSIDIAN_CATALOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OBSIDIAN_CATALOG_PATH, "w", encoding="utf-8") as f:
        f.write(full_md)
    print(f" -> Obsidian Kataloğu Güncellendi: {OBSIDIAN_CATALOG_PATH}")


if __name__ == "__main__":
    run_full_library_extraction()
