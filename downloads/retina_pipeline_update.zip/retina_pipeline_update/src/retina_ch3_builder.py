# -*- coding: utf-8 -*-
r"""
retina_ch3_builder.py — Bölüm 3: Retinal Vasküler Hastalıklar (56 Slayt)
========================================================================
Kitap Sayfaları: 91 – 126
Alt Başlıklar:
  3.0   Bölüm 3 Çalışma Yol Haritası (1 slayt)
  3.1.1 Diyabetik Retinopati (NPDR, PDR) ve Patogenez (8 slayt)
  3.1.2 Diyabetik Makula Ödemi (DMÖ) Tipleri ve Algoritmalar (8 slayt)
  3.1.3 Anti-VEGF Protokolleri, Steroid İmplantlar ve Lazer (8 slayt)
  3.2.1 Retinal Ven Tıkanıklıkları (BRVO, CRVO) (8 slayt)
  3.2.2 Retinal Arter Tıkanıklıkları (CRAO, BRAO) (7 slayt)
  3.3.1 Hipertansif Retinopati, RAM ve Coats Hastalığı (8 slayt)
  3.3.2 Prematüre Retinopatisi (ROP - ICROP 3) (8 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_3(builder: RetinaStudyDeckBuilder):
    """Bölüm 3'e ait 56 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 3 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=3,
        title="RETİNAL VASKÜLER HASTALIKLAR",
        page_range="Sayfa 91 – 126",
        subtitle="Diyabetik Retinopati (ETDRS 4:2:1), DMÖ Protokolleri, RVO, RAO, RAM ve ICROP-3 ROP",
        cards=[
            {
                "title": "1. Diyabetik Retinopati & DMÖ",
                "color": PPTXPalette.BLUE,
                "lead": "ETDRS 4:2:1 & Landmark Kanıt",
                "items": [
                    "ETDRS 4:2:1 Kuralı: Ağır NPDR tanısı koyduran ve 1 yılda %50 PDR riski taşıyan eşik kriter.",
                    "DMÖ Triyajı: Santral tutulumlu (CI-DME) vs non-santral (NCI-DME); görme keskinliği eşiği (20/32 - 20/40).",
                    "DRCR.net Protokolleri: Protokol T (Aflibercept üstünlüğü), Protokol V (iyi görmede gözlem), Protokol W.",
                    "Yeni Nesil Tedaviler: Faricimab (Ang-2/VEGF-A) ve Yüksek Doz Aflibercept 8 mg (PHOTON çalışması)."
                ],
                "footer": "ETDRS 4:2:1 & DRCR.net Kanıtı"
            },
            {
                "title": "2. Damar Tıkanıklıkları (RVO/RAO)",
                "color": PPTXPalette.RED,
                "lead": "Ven ve Arter Acilleri",
                "items": [
                    "Retinal Ven Tıkanıklığı (BRVO/CRVO): İskemik CRVO kriteri (>10 disk çapı non-perfüzyon, rölatif afferent pupil defekti).",
                    "100 Gün Glokomu: İskemik CRVO'da ön segment neovaskülarizasyonu ve neovasküler glokom (NVG) riski.",
                    "Retinal Arter Tıkanıklığı (CRAO): Acil inme eşdeğeri; kiraz kırmızısı benek (cherry-red spot) ve sitotoksik ödem.",
                    "Sistemik Triyaj: Acil karotis doppler USG, ekokardiyografi ve dev hücreli arterit (GCA) sedimantasyon taraması."
                ],
                "footer": "RVO 100 Gün Glokomu & CRAO İnme Eşdeğeri"
            },
            {
                "title": "3. RAM, Coats & Hipertansiyon",
                "color": PPTXPalette.AMBER,
                "lead": "Özel Vasküler Patolojiler",
                "items": [
                    "Retinal Arter Makroanevrizması (RAM): Yaşlı hipertansif kadınlarda çok katmanlı kum saati (hourglass) kanaması.",
                    "Coats Hastalığı: Genç erkek çocuklarda idiyopatik retinal telanjiektaziler, masif lipid eksüdasyonu ve büllöz RD.",
                    "Malign Hipertansiyon: Grade 4 retinopati (optik disk ödemi), Elschnig lekeleri ve Siegrist çizgileri.",
                    "Ayırıcı Tanı: Coats ile retinoblastom ayrımında USG'de kalsifikasyon olmaması kritiktir."
                ],
                "footer": "Kum Saati Kanaması & Masif Lipid Eksüdasyonu"
            },
            {
                "title": "4. Prematüre Retinopatisi (ROP)",
                "color": PPTXPalette.PURPLE,
                "lead": "ICROP-3 Uluslararası Konsensusu",
                "items": [
                    "Tarama Kriterleri: ≤32 gebelik haftası veya ≤1500 gram doğum ağırlığı (Türkiye standardı).",
                    "Zon ve Evreleme: Zon I (en tehlikeli), Zon II, Zon III; Evre 1 (demarkasyon) - Evre 5 (total RD).",
                    "Plus Hastalık: Arka kutup arteriollerinde kıvrıntılanma (tortuosity) ve venüllerde genişleme (dilatasyon).",
                    "Tedavi Modaliteleri: Tip 1 ROP'ta diyot lazer fotokoagülasyon vs İntravitreal Anti-VEGF (Ranibizumab 0.2 mg)."
                ],
                "footer": "ICROP-3 Standardı & Tip 1 ROP Lazer/Anti-VEGF"
            }
        ]
    )

    # =========================================================================
    # KONU 3.1.1: DİYABETİK RETİNOPATİ VE PATOGENEZ (8 SLAYT)
    # =========================================================================
    # Slayt 3.1.1.1: Biyokimyasal Patogenez
    builder.add_study_card_slide(
        title="DİYABETİK MİKROANJİYOPATİ BİYOKİMYASAL PATOGENEZİ",
        category="BÖLÜM 3.1.1: DİYABETİK RETİNOPATİ",
        subtitle="Kronik Hiperglisemi, Poliol Yolağı, AGE Birikimi, PKC Aktivasyonu ve Heksosamin",
        cards=[
            {
                "card_title": "4 KLASİK HİPERGLİSEMİK YOLAK",
                "lead": "Brownlee Mitokondriyal Süperoksit Hipotezi",
                "items": [
                    "1. Poliol Yolağı: Aldoz redüktaz aşırı glukozu sorbitole çevirir; NADPH tükenir, hücre içi ozmotik stres ve katarakt gelişir [s.92].",
                    "2. İleri Glikasyon Son Ürünleri (AGE): Proteinlere glukoz bağlanır; RAGE reseptörü ile NF-κB inflamasyon kaskadını tetikler.",
                    "3. Protein Kinaz C (PKC-β): Diyasilgliserol (DAG) artışı PKC'yi uyarır; endotel geçirgenliği artar ve bazal membran kalınlaşır.",
                    "4. Heksosamin Yolağı: Fruktoz-6-fosfat şantı TGF-β ve PAI-1 üretimini artırarak vasküler oklüzyonu besler."
                ],
                "footer": "Mitokondriyal Süperoksit Aşırı Üretimi"
            },
            {
                "card_title": "PERİSİT HİPOPLAZİSİ VE APOPTOZ",
                "lead": "Retinal Kapillerlerin İlk Kurbanı",
                "items": [
                    "Normal Göz: Endotel başına 1 perisit düşer (1:1 oran) [s.93].",
                    "Erken Diyabetik Hasar: Perisitler endotelden çok daha önce apoptoza gider (pericyte ghosting).",
                    "Destek Kaybı: Perisitsiz kalan kapiller duvarı lümen içi hidrostatik basınca dayanamaz.",
                    "Mikroanevrizma Oluşumu: Zayıflayan kapiller duvarının dışa doğru fokal balonlaşması (saküler dilatasyon)."
                ],
                "footer": "Perisit Kaybı = Mikroanevrizma Başlangıcı"
            },
            {
                "card_title": "LÖKOSTAZ VE VASKÜLER OKLÜZYON",
                "lead": "Kapiller Tıkanıklık ve Doku İskemisi",
                "items": [
                    "Lökosit Adezyonu (Lökostaz): İnflamasyonla endotelde ICAM-1 ve VCAM-1 adezinleri artar [s.93].",
                    "Rijit Nötrofiller: Esnekliğini yitirmiş lökositler kapiller lümene yapışarak kan akımını mekanik olarak tıkar.",
                    "Asellüler Kapillerler: Tıkanan damarlarda endotel de ölür; geriye içi boş kollajen tüpler (hayalet damar) kalır.",
                    "Lokal Hipoksi: Kapiller kapanması doku iskemisini başlatır; HIF-1α stabilize olarak VEGF patlamasına yol açar."
                ],
                "footer": "ICAM-1 -> Lökostaz -> Asellüler Kapiller"
            }
        ]
    )

    # Slayt 3.1.1.2: ETDRS Sınıflaması ve Doğal Seyir
    builder.add_study_card_slide(
        title="ETDRS DİYABETİK RETİNOPATİ SINIFLAMA BASAMAKLARI",
        category="BÖLÜM 3.1.1: DİYABETİK RETİNOPATİ",
        subtitle="Hafif, Orta, Ağır ve Çok Ağır NPDR'den Proliferatif Evreye Geçiş",
        cards=[
            {
                "card_title": "HAFİF VE ORTA NPDR",
                "lead": "Mikroanevrizmalardan Eksüdalara",
                "items": [
                    "Hafif NPDR: Retinada yalnızca en az bir adet mikroanevrizma bulunmasıdır [s.93].",
                    "Orta NPDR: Yalnızca mikroanevrizmadan daha fazla, ancak ağır NPDR kriterlerini doldurmayan lezyonlar.",
                    "Klinik Bulgular: Çizgisel ve alev şeklinde kanamalar, sert eksüdalar, pamuk atılmış lekeler (CWS).",
                    "Takip: Hafif NPDR yıllık; orta NPDR 6 ayda bir dilate fundus muayenesiyle izlenir."
                ],
                "footer": "Hafif (1 Yıl) | Orta (6 Ay Takip)"
            },
            {
                "card_title": "AĞIR VE ÇOK AĞIR NPDR",
                "lead": "Preproliferatif Alarm Evresi",
                "items": [
                    "Ağır NPDR: ETDRS 4:2:1 kuralının HERHANGİ BİR kriterini karşılayan tablodur [s.94].",
                    "Çok Ağır NPDR: ETDRS 4:2:1 kuralının EN AZ İKİ kriterini karşılayan tablodur.",
                    "1 Yıllık PDR Riski: Ağır NPDR'de 1 yılda PDR'ye dönüşüm riski %50; Çok Ağırda %75'tir [RV2:pdf310].",
                    "Yakın Takip: Hastalar 2-3 ay arayla çok sıkı izlenmeli veya profilaktik lazer/anti-VEGF düşünülmelidir."
                ],
                "footer": "1 Yılda %50-75 PDR Gelişme Riski"
            },
            {
                "card_title": "PROLİFERATİF DR (PDR)",
                "lead": "Neovaskülarizasyon Filizlenmesi",
                "items": [
                    "Tanım: Retina yüzeyinde veya optik disk üzerinde yeni kırılgan damarların (NVD/NVE) belirmesidir [s.94].",
                    "İç Sınırlayıcı Membranın Delinmesi: Yeni damarlar İLM'yi delerek vitreus korteksi boyunca büyür.",
                    "Fibröz Doku Eşliği: Damarların etrafında fibroblast ve glial hücreler fibrovasküler zarlar oluşturur.",
                    "Komplikasyonlar: Vitreus kanaması, preretinal kanama, traksiyonel retina dekolmanı (TRD) ve NVG."
                ],
                "footer": "İLM Dışı Neovaskülarizasyon = PDR"
            }
        ]
    )

    # Slayt 3.1.1.3: ETDRS 4:2:1 Kuralı
    builder.add_study_card_slide(
        title="ETDRS 4:2:1 KURALI VE AĞIR NPDR KRİTERLERİ",
        category="BÖLÜM 3.1.1: DİYABETİK RETİNOPATİ",
        subtitle="4 Kadran Kanama, 2 Kadran Venöz Boğumlanma ve 1 Kadran İRMA Analizi",
        cards=[
            {
                "card_title": "4 KADRAN: KANAMA / MA",
                "lead": "Tüm 4 Kadranda Belirgin Kanama",
                "items": [
                    "Kriter: 4 kadranın her birinde Standard Fotoğraf 2A'dan daha yoğun derin kanama/MA olması [s.94].",
                    "Nokta ve Leke Kanamaları: Derin INL/OPL tabakasında toplanan yuvarlak, koyu kırmızı kanamalar.",
                    "Yaygın İskemi Göstergesi: 4 kadranın tamamının tutulması kapiller yatağın global çöktüğünü kanıtlar.",
                    "Ekarte Edilecek: Yalnızca tek veya iki kadranda yoğun kanama bu kriteri karşılamaz."
                ],
                "footer": "4/4 Kadranda >Std 2A Kanama"
            },
            {
                "card_title": "2 KADRAN: VENÖZ BOĞUMLANMA",
                "lead": "Venous Beading (VB)",
                "items": [
                    "Kriter: En az 2 kadranda belirgin venöz boğumlanma (tespih tanesi görünümü) bulunması [s.94].",
                    "Patoloji: Ven duvarı iskemisi ve endotel disfonksiyonuna bağlı düzensiz lokal dilatasyon ve daralmalar.",
                    "Diğer Venöz Anomaliler: Venöz halkalanma (loops) ve duplikasyonlar eşlik edebilir.",
                    "Yüksek Risk: Venöz boğumlanma proliferasyona geçişin en güçlü bağımsız habercisidir."
                ],
                "footer": "≥2 Kadranda Venöz Boğumlanma"
            },
            {
                "card_title": "1 KADRAN: İRMA",
                "lead": "İntraretinal Mikrovasküler Anomali",
                "items": [
                    "Kriter: En az 1 kadranda Standard Fotoğraf 8A'dan daha belirgin İRMA bulunması [s.95].",
                    "Tanım: Non-perfüze alanlar arasında şant yapan intraretinal dilate kıvrıntılı kollateral damarlardır.",
                    "NVE'den Farkı: İntraretinal yerleşimlidir; İLM'yi delmez ve FA'da belirgin floresein sızıntısı yapmaz.",
                    "Kritik Alarm: 1 kadranda dahi belirgin İRMA varlığı gözü doğrudan 'Ağır NPDR' sınıfına sokar."
                ],
                "footer": "≥1 Kadranda >Std 8A İRMA"
            }
        ]
    )

    # Slayt 3.1.1.4: NVD vs NVE ve Yüksek Riskli PDR Kriterleri
    builder.add_split_comparison_slide(
        title="PDR NEOVASKÜLARİZASYONLARI VE YÜKSEK RİSK KRİTERLERİ",
        category="BÖLÜM 3.1.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="NVD (Optik Diskte) vs NVE (Retina Yüzeyinde) ve Acil PRP Endikasyonları",
        left_entity={
            "name": "NEOVASKÜLARİZASYON TİPLERİ",
            "features": [
                ("NVD (Neovascularization of Disc)", "Optik sinir başında veya 1 disk çapı (DD) mesafesinde yerleşir [s.95]."),
                ("NVE (Elsewhere)", "Vasküler arkadlar boyunca veya arka kutup/perifer retinada yerleşir."),
                ("İLM İhlali", "Her iki lezyon da İLM'yi delerek vitreus korteksine tutunur; traksiyona açıktır."),
                ("FA Dinamiği", "FA erken fazında dantela benzeri ağ, geç fazda masif floresein sızıntısı verir."),
                ("Kırılganlık", "Eritrositler ve plazma kontrolsüz sızar; spontan kanama riski aşırı yüksektir.")
            ]
        },
        right_entity={
            "name": "ETDRS YÜKSEK RİSKLİ PDR KRİTERLERİ",
            "features": [
                ("Kriter 1", "Hafif dahi olsa preretinal veya vitreus kanamasının eşlik ettiği NVD varlığı [s.95]."),
                ("Kriter 2", "Vitreus kanaması olmasa bile büyüklüğü >1/4 - 1/3 disk alanını aşan NVD varlığı."),
                ("Kriter 3", "Preretinal veya vitreus kanamasının eşlik ettiği >1/2 disk alanı büyüklüğünde NVE varlığı."),
                ("Doğal Seyir", "Tedavi edilmezse 2 yıl içinde %30-40 oranında ağır kalıcı görme kaybı riski taşır."),
                ("Cerrahi Eylem", "ACİL Panretinal Fotokoagülasyon (PRP) lazer ve/veya Anti-VEGF enjeksiyonu şarttır.")
            ]
        },
        bottom_takeaway="Yüksek riskli PDR saptandığı anda bekleme süresi sıfırdır; hasta en geç 48-72 saat içinde lazer fotokoagülasyona alınmalıdır [s.95]."
    )

    # Slayt 3.1.1.5: Atlas Görseli: PDR, NVD ve İRMA Atlası
    img_p92 = builder.get_image_for_page(92)
    builder.add_atlas_image_slide(
        title="DİYABETİK RETİNOPATİ İLERİ BULGULAR ATLASI",
        category="BÖLÜM 3.1.1: GÖRSEL ATLAS",
        subtitle="ETDRS 4:2:1 Kriterleri, NVD/NVE Filizlenmesi ve İntraretinal Mikrovasküler Anomaliler",
        image_path=img_p92 or "dr_panel_3",
        caption="Referans Eser Sayfa 92: Yüksek Riskli PDR'de Optik Disk Neovaskülarizasyonu (NVD) ve Pre-retinal Kanama",
        key_findings=[
            "Optik Diskte NVD: Disk sınırlarını aşan, vitreusa doğru uzanan ince kalibreli vasküler ağ [s.92].",
            "Preretinal Kanama (Subhyaloid): Arka hyaloid altında kayık şeklinde sınır veren taze parlak kırmızı kan.",
            "Venöz Boğumlanma: Üst temporal ven trasesinde sosis benzeri boğumlanma ve lümen düzensizliği.",
            "Yaygın Derin Kanamalar: Retina dış tabakalarında kümelenmiş 'leke' biçimli çok odaklı hemorajiler."
        ],
        differentials=[
            "İRMA vs NVE: İRMA düz ve intraretinaldir, sızdırmaz; NVE kabarık ve vitreusadır, masif sızdırır.",
            "Retinal Kollateral Damarlar: CRVO sonrası diske oturan şant damarlarıdır; sızıntı yapmaz.",
            "Optik Disk Tüberkülomu: Üveitik granulom; kitle görünümündedir, vasküler yumak içermez."
        ],
        clinical_pearl="İki kadranda venöz boğumlanma (venous beading) görülen bir göz, neovaskülarizasyon henüz başlamamış olsa dahi 'saatli bomba' gibi kabul edilmeli; 2-3 aydan uzun süre takipsiz bırakılmamalıdır [RV2:pdf310]."
    )

    # Slayt 3.1.1.6: Karşılaştırmalı Analiz: İRMA vs NVE
    builder.add_split_comparison_slide(
        title="KRİTİK AYIRICI TANI: İRMA VS NVE AYRIMI",
        category="BÖLÜM 3.1.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="İntraretinal Şant Damarları (İRMA) vs Preretinal Neovaskülarizasyon (NVE)",
        left_entity={
            "name": "İRMA (İNTRARETİNAL ŞANT)",
            "features": [
                ("Anatomik Düzlem", "Kesinlikle retina tabakaları içinde sınırlıdır; İLM'yi aşmaz [s.94]."),
                ("Damar Çapı & Şekli", "Geniş, kıvrıntılı, fokal dallanmalar; uçları kör sonlanmaz, şant yapar."),
                ("FA Floresein Sızıntısı", "Geç fazda boyanabilir ancak serbest doku aralığına SIZDIRMAZ."),
                ("Vitreus İlişkisi", "Vitreus korteksi ile yapışıklığı yoktur; traksiyonel kanama yapmaz."),
                ("Evreleme Rolü", "Ağır NPDR göstergesidir; PDR tanısı KOYDURMAZ.")
            ]
        },
        right_entity={
            "name": "NVE (PRERETİNAL YENİ DAMAR)",
            "features": [
                ("Anatomik Düzlem", "İLM'yi yırtarak retina yüzeyine ve vitreus korteksine tırmanır [s.95]."),
                ("Damar Çapı & Şekli", "Çok ince, kırılgan, dantela benzeri kapiller filizlenmeler (sprouts)."),
                ("FA Floresein Sızıntısı", "Erken fazdan itibaren fırtına gibi MASİF SIZINTI yapar."),
                ("Vitreus İlişkisi", "Vitreus korteksine sıkıca kilitlenir; PVD sırasında yırtılarak kanar."),
                ("Evreleme Rolü", "Varlığı kesin olarak Proliferatif DR (PDR) tanısı koydurur.")
            ]
        },
        bottom_takeaway="FA'da geç fazda sızıntı yapmayan kıvrıntılı damar İRMA'dır (Ağır NPDR); sınırları belirsizleşip parlak sızıntı yayan damar NVE'dir (PDR) [s.95]."
    )

    # Slayt 3.1.1.7: Akış Şeması: ETDRS Risk Stratifikasyonu ve Takip Sıklığı
    builder.add_horizontal_flowchart_slide(
        title="DİYABETİK RETİNOPATİ KLİNİK TAKİP VE TRİYAJ KASKADI",
        category="BÖLÜM 3.1.1: AKIŞ ŞEMASI",
        subtitle="Hastalık Ağırlığına Göre Kontrol Aralıkları ve Lazer/Enjeksiyon Karar Eşikleri",
        steps=[
            {
                "num": "1",
                "title": "Retinopati Yok",
                "desc": "Tip 1 DM'de tanıdan 5 yıl sonra; Tip 2 DM'de tanı anında ilk muayene -> Yıllık takip [s.93].",
                "status": "success"
            },
            {
                "num": "2",
                "title": "Hafif / Orta NPDR",
                "desc": "Yalnızca mikroanevrizmalar ve hafif kanamalar -> 6 - 12 ay arayla dilate fundus muayenesi.",
                "status": "info"
            },
            {
                "num": "3",
                "title": "Ağır NPDR (4:2:1)",
                "desc": "4:2:1 kuralının 1 kriteri pozitif -> 2 - 4 ay arayla çok sıkı izlem; yüksek riskte erken PRP.",
                "status": "warning"
            },
            {
                "num": "4",
                "title": "Erken PDR",
                "desc": "Yüksek risk kriteri olmayan NVE/NVD varlığı -> Panretinal Fotokoagülasyon (PRP) planlaması.",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Yüksek Riskli PDR",
                "desc": "Geniş NVD veya vitreus kanamalı NVE -> Acil PRP lazer + İntravitreal Anti-VEGF.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Gebelik diyabetik retinopati progresyonunu dramatik hızlandırır; gebe kalan diyabetik kadınlar her trimesterde mutlaka fundus muayenesiyle taranmalıdır [s.94]."
    )

    # Slayt 3.1.1.8: Aktif Hatırlama & Board Sınavı Vakası
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: DİYABETİK RETİNOPATİ",
        category="BÖLÜM 3.1.1: AKTİF HATIRLAMA",
        subtitle="54 Yaşında Tip 2 Diyabetik Hastada 4 Kadranda Kanama ve İntraretinal Anomaliler",
        vignette="54 yaşında 12 yıllık Tip 2 diyabet hastası (HbA1c: %9.2) rutin kontrole geliyor. Görme keskinliği her iki gözde 10/10. Dilate fundus muayenesinde optik diskte veya vitreusta kanama/neovaskülarizasyon izlenmiyor. Ancak 4 kadranın tamamında Standard Fotoğraf 2A'dan daha yoğun retinal kanamalar, alt ve üst temporalde belirgin venöz boğumlanma (venous beading) ve nazal kadranda İRMA odakları saptanıyor. Makula kuru.",
        differentials=[
            "Çok Ağır Non-Proliferatif Diyabetik Retinopati (ETDRS 4:2:1 kuralının 3 kriteri de pozitif).",
            "Orta NPDR (Kanamaların şiddeti ve venöz boğumlanma atlanırsa yapılacak fahiş hata).",
            "Erken Proliferatif Retinopati (NVD/NVE henüz başlamadığı için PDR değildir).",
            "İskemik Santral Retinal Ven Tıkanıklığı (asimetrik tek taraflı olsaydı düşünülebilirdi)."
        ],
        decision="1. Tanı: Çok Ağır NPDR (1 yılda %75 PDR'ye dönüşüm riski).\n2. Yönetim: Hasta görmesi 10/10 diye 1 yıl sonraya ertelenemez; 2 ay sonra yakın kontrole çağrılmalıdır.\n3. Tedavi Alternatifi: Takibe uyum sağlayamayacak hastada gecikmeden profilaktik Panretinal Fotokoagülasyon (PRP) veya Anti-VEGF başlanmalıdır.",
        board_trap="Hastanın görmesinin 10/10 olması hekimi asla rehavete sürüklememelidir; ETDRS 4:2:1 kuralının 2 veya 3 kriterini dolduran gözler aylar içinde masif vitreus kanamasıyla körlük tablosuna girebilir [RV2:pdf310]."
    )

    # =========================================================================
    # KONU 3.1.2: DİYABETİK MAKULA ÖDEMİ (DMÖ) VE TEDAVİ ALGORİTMASI (8 SLAYT)
    # =========================================================================
    # Slayt 3.1.2.1: DMÖ Patofizyolojisi ve Sınıflaması
    builder.add_study_card_slide(
        title="DİYABETİK MAKULA ÖDEMİ (DMÖ) PATOFİZYOLOJİSİ VE SINIFLAMASI",
        category="BÖLÜM 3.1.2: DİYABETİK MAKULA ÖDEMİ",
        subtitle="Vazojenik Sızıntı, İç B-RB Yıkımı, CI-DME vs NCI-DME ve Anatomik Dağılım",
        cards=[
            {
                "card_title": "İÇ B-RB YIKIMI VE SIZINTI",
                "lead": "VEGF ve İnflamatuar Sitokinler",
                "items": [
                    "DMÖ diyabetik retinopatide orta ve ileri evre görme kaybının en sık nedenidir [s.96].",
                    "İç B-RB Çöküşü: Endotelyal sıkı bağlantıların (claudin-5, occludin) çözülmesiyle plazma retinaya sızar.",
                    "Sıvı Göllenmesi: Sızan seröz sıvı öncelikle Henle lif tabakasında ve iç nükleer tabakada (INL) toplanır.",
                    "Sert Eksüdalar: Sıvı RPE tarafından emilirken geride kalan lipoprotein ve lipid çökeltileridir."
                ],
                "footer": "B-RB Çözülmesi -> Henle Liflerinde Sıvı"
            },
            {
                "card_title": "MODERN OKT SINIFLAMASI",
                "lead": "CI-DME vs NCI-DME Ayrımı",
                "items": [
                    "Santral Tutulumlu DMÖ (CI-DME): Santral 1 mm foveal alt alanda kalınlaşma ve kist varlığı [s.96].",
                    "Santral Tutulumsuz DMÖ (NCI-DME): Makuler ödem parafoveal alandadır; fovea merkezi kurudur.",
                    "Klinik Önemi: Eski ETDRS 'Klinik Olarak Anlamlı Makula Ödemi' (CSME) kavramı yerini OKT merkezli CI-DME'ye bırakmıştır.",
                    "Tedavi Ayrımı: CI-DME primer anti-VEGF adayı iken, NCI-DME gözlem veya fokal lazer adayıdır."
                ],
                "footer": "CI-DME (Foveal Kist) vs NCI-DME (Parafoveal)"
            },
            {
                "card_title": "SIVI KOMPARTMANLARI",
                "lead": "İntraretinal vs Subretinal Sıvı",
                "items": [
                    "İntraretinal Kistler (IRC): Nörosensoryal retina içinde süngerimsi veya petalloid kaviteler [s.97].",
                    "Subretinal Sıvı (SRF): Fovea altında RPE ile nörosensoryal retina arasında seröz ayrılma (%20-30 vaka).",
                    "İnflamatuar Belirteç: SRF varlığı inflamatuar sitokin (IL-6, ICAM-1) yüksekliğini yansıtır.",
                    "Steroid Yanıtı: SRF içeren DMÖ olguları deksametazon implanta (Ozurdex) dramatik iyi yanıt verir."
                ],
                "footer": "SRF Varlığı = Güçlü İnflamatuar Bileşen"
            }
        ]
    )

    # Slayt 3.1.2.2: Görme Keskinliğine Göre Başlangıç Triyajı
    builder.add_study_card_slide(
        title="GÖRME KESKİNLİĞİNE GÖRE CI-DME BAŞLANGIÇ TEDAVİ TRİYAJI",
        category="BÖLÜM 3.1.2: DİYABETİK MAKULA ÖDEMİ",
        subtitle="DRCR.net Protokol V ve Protokol T Kanıtları Eşliğinde Klinik Eşikler",
        cards=[
            {
                "card_title": "İYİ GÖRME (BCVA ≥ 20/25 / ≥0.8)",
                "lead": "DRCR.net Protokol V Bulguları",
                "items": [
                    "Klinik Tablo: OKT'de foveayı tutan CI-DME var ancak hasta harflerin tamamını okuyabiliyor [s.97].",
                    "Protokol V Sonucu: Acil anti-VEGF, fokal lazer veya yakın gözlem arasında 2 yıllık görme farkı saptanmamıştır [RV2:pdf312].",
                    "Birincil Yaklaşım: GÖZLEM (aktif takip) veya hafif fokal lazer.",
                    "Tedavi Başlama Eşiği: Takipte görme keskinliği 1 sıra (5 harf) veya daha fazla düşerse anti-VEGF başlanır."
                ],
                "footer": "Protokol V: Görme İyiyse İzle"
            },
            {
                "card_title": "HAFİF KAYIP (20/32 - 20/40)",
                "lead": "Eşit Etkinlik Alanı",
                "items": [
                    "Klinik Tablo: Hasta 20/32 ile 20/40 (yaklaşık 0.5 - 0.6) bandında harf kaçırıyor [s.97].",
                    "Protokol T Karşılaştırması: Aflibercept, Ranibizumab ve Bevacizumab arasında 1. ve 2. yılda görme kazanımı benzerdir (~8 harf).",
                    "Maliyet-Etkinlik: Üç ajan da eşdeğer başarı sağladığından maliyet-etkin ilk tercih (Bevacizumab veya Ranibizumab) kullanılabilir.",
                    "İstisna: Anatomik kuruma hızı aflibercept ile bir miktar daha yüksektir."
                ],
                "footer": "Protokol T: 3 Ajan da Eşit Başarılı"
            },
            {
                "card_title": "BELİRGİN KAYIP (BCVA ≤ 20/50 / ≤0.4)",
                "lead": "Aflibercept Üstünlüğü",
                "items": [
                    "Klinik Tablo: Görme keskinliği 20/50 veya daha kötü (ağır foveal tutulum) [s.98].",
                    "Protokol T 1. Yıl Sonucu: Aflibercept (+18.9 harf), Ranibizumab (+14.2 harf) ve Bevacizumab'dan (+11.8 harf) istatistiksel olarak ÜSTÜNDÜR.",
                    "Anatomik Kuruma: Aflibercept foveayı kurutmada ve retinal kalınlığı azaltmada açık ara liderdir.",
                    "Klinik Konsensus: Başlangıç görmesi ≤20/50 olan CI-DME'de ilk tercih yüksek afiniteli anti-VEGF (Aflibercept/Faricimab) olmalıdır."
                ],
                "footer": "Görme ≤20/50 ise Aflibercept İlk Tercih"
            }
        ]
    )

    # Slayt 3.1.2.3: Traksiyonel vs Non-Traksiyonel DMÖ Ayrımı
    builder.add_split_comparison_slide(
        title="DMÖ'DE TRAKSİYONEL VS VAZOJENİK AYRIMI",
        category="BÖLÜM 3.1.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Vitreomaküler Traksiyon / ERM Varlığı vs İzole Vasküler Hiperpermeabilite",
        left_entity={
            "name": "VAZOJENİK (NON-TRAKSİYONEL) DMÖ",
            "features": [
                ("Patofizyoloji", "Primer İç B-RB endotel aralığı yıkımı ve aşırı VEGF/Ang-2 salınımı [s.98]."),
                ("OKT Morfolojisi", "Kubbe biçimli foveal kalınlaşma, seröz intraretinal kistler; İLM düzgündür."),
                ("Vitreus Arayüzü", "Arka hyaloid ayrılmıştır (PVD) veya foveaya teğetsel traksiyon yapmaz."),
                ("Birincil Tedavi", "Farmakoterapi: Aylık intravitreal anti-VEGF veya Deksametazon implant."),
                ("Cerrahi Yanıt", "Primer cerrahi endikasyonu YOKTUR; vitrektomi gereksizdir.")
            ]
        },
        right_entity={
            "name": "TRAKSİYONEL DMÖ (VMT / ERM EŞLİKLİ)",
            "features": [
                ("Patofizyoloji", "Vitreoretinal arayüzde kalın hiperreflektif membran ve mekanik dikey/teğetsel çekinti [s.98]."),
                ("OKT Morfolojisi", "Foveada asimetrik dik çekilme kuleleri, İLM kırışıklığı veya psödodelik görünümü."),
                ("Vitreus Arayüzü", "Arka korteks foveaya kilitlidir veya yüzeyde kalın ERM tabakası izlenir."),
                ("Anti-VEGF Yanıtı", "Anti-VEGF enjeksiyonlarına DİRENÇLİDİR; sıvı çekilmez veya hızla nükseder."),
                ("Birincil Tedavi", "Pars Plana Vitrektomi (PPV) + Arka Hyaloid Dekolmanı + İLM Soyulması.")
            ]
        },
        bottom_takeaway="Traksiyonel komponenti olan DMÖ olgularına inatla aylarca anti-VEGF yapmak zaman ve görme kaybıdır; OKT'de foveayı çeken belirgin hyaloid/ERM varsa çözüm cerrahi dekompresyondur [RV2:pdf312]."
    )

    # Slayt 3.1.2.4: Anti-VEGF'e Dirençli DMÖ ve Steroid Switch Kriterleri
    builder.add_study_card_slide(
        title="ANTİ-VEGF DİRENÇLİ DMÖ VE ERKEN STEROİD SWITCH STRATEJİSİ",
        category="BÖLÜM 3.1.2: DİYABETİK MAKULA ÖDEMİ",
        subtitle="Yetersiz Yanıt Tanımı, İnflamatuar Yolağın Aktivasyonu ve Deksametazon İmplant (Ozurdex)",
        cards=[
            {
                "card_title": "DİRENÇ TANIMI VE KRİTERLERİ",
                "lead": "3-6 Doz Sonrası Değerlendirme",
                "items": [
                    "Suboptimal Yanıt: Düzenli 3-6 aylık anti-VEGF enjeksiyonuna rağmen santral kalınlığın <%10-20 azalması [s.99].",
                    "Persistan Sıvı: Foveal intraretinal veya subretinal sıvının kurutulamaması ve görmenin artmaması.",
                    "Protokol I Analizi: 12. haftada erken yanıt vermeyen gözlerin 3. yılda da kötü seyrettiği kanıtlanmıştır.",
                    "Konsensus: İnflamatuar kaskada takılıp kalmış gözlerde aynı anti-VEGF ile yıllarca ısrar edilmemelidir."
                ],
                "footer": "3-6 Dozda Yanıt Yoksa = Dirençli DMÖ"
            },
            {
                "card_title": "İNFLAMATUAR YOLAK VE STEROİD",
                "lead": "Çoklu Sitokin Baskılaması",
                "items": [
                    "VEGF Dışı Sitokinler: Kronikleşen DMÖ'de ortamda IL-6, IL-8, MCP-1, TNF-α ve ICAM-1 baskındır [s.99].",
                    "Deksametazon İmplant (Ozurdex): 0.7 mg yavaş salınımlı intravitreal implant; tüm inflamatuar sitokinleri susturur.",
                    "İç B-RB Onarımı: Endotelyal sıkı bağlantıları doğrudan stabilize eder; lökostazı durdurur.",
                    "HRF ve SRF Klirensi: Yoğun hiperreflektif odakları ve subretinal sıvıyı anti-VEGF'ten daha hızlı temizler."
                ],
                "footer": "IL-6, TNF-α, ICAM-1'i Komple Susturur"
            },
            {
                "card_title": "SWITCH ZAMANLAMASI VE GÜVENLİK",
                "lead": "Psödofakik vs Fakik Tercihi",
                "items": [
                    "Psödofakik Gözler: Katarakt riski olmadığı için erken switch (3-4. doz sonrası) için en ideal adaylardır [s.100].",
                    "Fakik Gözler: 1-2 yıl içinde %60-70 katarakt progresyonu gelişir; hastaya önceden anlatılmalıdır.",
                    "Göz İçi Basıncı (GİB): Hastaların yaklaşık %15-20'sinde GİB artışı izlenir; topikal damlalarla kontrol edilir.",
                    "Enjeksiyon Aralığı: Tek bir Ozurdex implantı yaklaşık 4 - 6 ay boyunca terapötik etkiyi sürdürür."
                ],
                "footer": "Psödofakikte Erken Switch | 4-6 Ay Etki"
            }
        ]
    )

    # Slayt 3.1.2.5: Atlas Görseli: Kistoid DMÖ ve Sert Eksüda Halkası
    img_p98 = builder.get_image_for_page(98)
    builder.add_atlas_image_slide(
        title="DİYABETİK MAKULA ÖDEMİ OKT VE FUNDUS ATLASI",
        category="BÖLÜM 3.1.2: GÖRSEL ATLAS",
        subtitle="Petalloid İntraretinal Kistler, Subretinal Sıvı ve Sirsine Sert Eksüdalar",
        image_path=img_p98 or "dr_panel_0",
        caption="Referans Eser Sayfa 98: Ağır CI-DME Kesitinde Foveal Kistoid Boşluklar, Subretinal Sıvı ve HRF Dağılımı",
        key_findings=[
            "Dev Kistoid Kaviteler: Dış pleksiform ve iç nükleer tabakayı ayıran geniş hiporeflektif kistler [s.98].",
            "Foveal Kontur Kaybı: Santral retinal kalınlığın 650 μm'ye ulaşması ve foveal çukurun ters kubbeleşmesi.",
            "Subretinal Sıvı Cebi: Foveola altında RPE üzerine oturmuş optik olarak anekoik berrak sıvı tabakası.",
            "Sirsine Eksüda Halkası: Fovea temporalinde kapiller kaçak odaklarını çevreleyen parlak sarı halkasal çökeltiler."
        ],
        differentials=[
            "Psödofakik Kistoid Ödem (Irvine-Gass): Tipik petalloid kistler vardır ancak retinal kanama ve eksüda içermez.",
            "Retinal Ven Tıkanıklığı: Tek kadranda yoğun alev kanamaları ve ven trasesinde kistoid ödem.",
            "Retinoskizis: İç katmanlarda horizontal sütunlarla ayrılmış yarıklar; floresan sızıntısı vermez."
        ],
        clinical_pearl="Kistoid DMÖ'de fovea altındaki subretinal sıvı (SRF) tablosu inflamatuar yükün habercisidir; steroid implantlara dramatik ve hızla yanıt verir [s.99]."
    )

    # Slayt 3.1.2.6: Karar Ağacı: DMÖ Klinik Yönetim Algoritması
    builder.add_decision_tree_slide(
        title="DİYABETİK MAKULA ÖDEMİ (DMÖ) KAPSAMLI TEDAVİ ALGORİTMASI",
        category="BÖLÜM 3.1.2: KARAR AĞACI",
        subtitle="Santral Tutulum, Görme Keskinliği ve Yanıt Durumuna Göre Adım Adım Protokol",
        root_label="OKT'DE RETİNAL KALINLAŞMA VE DİYABETİK MAKULA ÖDEMİ",
        branches=[
            {
                "label": "1. Non-Santral DMÖ (NCI-DME)",
                "criteria": "Fovea merkezi kuru; ödem parafoveal alanda; görme 10/10 düzeyinde korunmuş [s.96].",
                "action": "Karar: Gözlem veya kaçak yapan mikroanevrizmalara fokal lazer -> Anti-VEGF gerekmez."
            },
            {
                "label": "2. CI-DME + İyi Görme (≥20/25)",
                "criteria": "Santral 1 mm foveal kist var ancak hasta harflerin tamamını okuyor (Protokol V) [s.97].",
                "action": "Karar: Yakın Gözlem (aylık OKT) -> Görme 5 harf düşerse anti-VEGF yüklemesine geç."
            },
            {
                "label": "3. CI-DME + Düşük Görme (≤20/32)",
                "criteria": "Foveal kistoid ödem ve görme kaybı mevcut; traksiyonel membran yok [s.98].",
                "action": "Karar: Aylık Anti-VEGF Yüklemesi (≤20/50 ise Aflibercept/Faricimab) -> 3-6 dozda yanıtsızsa Steroid İmplant switch."
            }
        ],
        bottom_rule="Eğer OKT'de vitreomaküler traksiyon (VMT) veya kalın ERM eşlik ediyorsa primer tedavi farmakoterapi değil, Pars Plana Vitrektomi ve İLM soyulmasıdır [s.98]."
    )

    # Slayt 3.1.2.7: Akış Şeması: Anti-VEGF Tedavi Rejimleri (PRN vs T&E)
    builder.add_horizontal_flowchart_slide(
        title="DMÖ ANTİ-VEGF UYGULAMA REJİMLERİ: PRN VS TREAT-AND-EXTEND",
        category="BÖLÜM 3.1.2: AKIŞ ŞEMASI",
        subtitle="Yükleme Dozundan İdame Fazına Enjeksiyon Aralığı Belirleme Kriterleri",
        steps=[
            {
                "num": "1",
                "title": "Yükleme Fazı",
                "desc": "Aylık aralıklarla en az 3-5 doz anti-VEGF enjeksiyonu uygulanması (maksimum kuruluk hedeflenir) [s.100].",
                "status": "danger"
            },
            {
                "num": "2",
                "title": "Maksimum Yanıt Kontrolü",
                "desc": "Fovea tamamen kuru ve görme stabil ise idame stratejisine karar verilir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Treat-and-Extend (T&E)",
                "desc": "Her vizitte MUTLAKA enjeksiyon yapılır; fovea kuruysa aralık 2'şer hafta uzatılır (6 -> 8 -> 10 -> 12 -> 16 hf).",
                "status": "success"
            },
            {
                "num": "4",
                "title": "PRN (Gerektiğinde)",
                "desc": "Hasta her ay muayene edilir; yalnızca sıvı nüks ettiğinde enjeksiyon yapılır (klinik yükü ağırdır).",
                "status": "info"
            },
            {
                "num": "5",
                "title": "Nüks Yönetimi",
                "desc": "T&E fazında sıvı nüks ederse aralık bir önceki başarılı süreye kısaltılır ve sabitlenir.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Treat-and-Extend (T&E) rejimi proaktif bir yaklaşımdır; sıvının nüksetmesini beklemeden enjeksiyon yaparak görme kazanımlarını PRN rejimine göre çok daha iyi korur [s.100]."
    )

    # Slayt 3.1.2.8: Landmark Çalışmalar: DRCR.net Protokol T, V ve W Karşılaştırması
    builder.add_trials_kpi_slide(
        title="DMÖ LANDMARK ÇALIŞMALARI: DRCR.NET PROTOKOL T, V VE W",
        category="BÖLÜM 3.1.2: KANIT TABANI",
        subtitle="Randomize Klinik Çalışmalarda Ajan Karşılaştırması, Görme Eşikleri ve Progresyon",
        kpis=[
            {"val": "+18.9 Harf", "label": "Protokol T Aflibercept (≤20/50 Görme)"},
            {"val": "%66", "label": "Protokol V Gözlemle 2 Yıl Sıvısız/Kayıpsız"},
            {"val": "%68 Azalma", "label": "Protokol W ile PDR Gelişim Riski Düşüşü"},
            {"val": "16 Hafta", "label": "PHOTON / YOSEMITE Maksimum Enjeksiyon Aralığı"}
        ],
        trials_table=[
            {
                "trial": "DRCR.net Protokol T (NEJM 2015)",
                "design": "660 hasta; Aflibercept 2mg vs Ranibizumab 0.3mg vs Bevacizumab 1.25mg.",
                "result": "Başlangıç görmesi ≤20/50 olanlarda Aflibercept anlamlı üstün (+18.9 vs +14.2 vs +11.8 harf); iyi görmede üç ajan eşdeğer."
            },
            {
                "trial": "DRCR.net Protokol V (JAMA 2019)",
                "design": "702 hasta; CI-DME ve iyi görme (≥20/25); Aflibercept vs Lazer vs Gözlem.",
                "result": "2 yılda görme kaybı oranları farksız (%16 vs %17 vs %19); iyi görmeli CI-DME'de yakın gözlem güvenlidir."
            },
            {
                "trial": "DRCR.net Protokol W (JAMA Ophthalmol 2021)",
                "design": "Ağır NPDR'de DMÖ yokken profilaktik Aflibercept vs Sahte Enjeksiyon.",
                "result": "Profilaktik anti-VEGF PDR gelişimini %68 azalttı ancak 2. ve 4. yılda nihai görme keskinliğini değiştirmedi."
            },
            {
                "trial": "YOSEMITE / RHINE (Lancet 2022)",
                "design": "1891 hasta; Çift etkili Faricimab (Anti-VEGF-A / Anti-Ang-2) 6 mg vs Aflibercept 2 mg.",
                "result": "Faricimab hastaların %60'ından fazlasında 16 haftalık enjeksiyon aralığına başarıyla ulaştı; kuruma hızı üstün."
            }
        ],
        bottom_evidence="Seviye 1A Kanıt: Görmesi zayıf (≤20/50) CI-DME'de Aflibercept ilk tercihtir; iyi görmede gözlem güvenlidir; Faricimab dayanıklılık süresini 4 aya uzatmaktadır [s.101]."
    )

    # =========================================================================
    # KONU 3.1.3: ANTİ-VEGF, STEROİD VE LAZER UYGULAMALARI (8 SLAYT)
    # =========================================================================
    # Slayt 3.1.3.1: İntravitreal Anti-VEGF Ajanlarının Biyolojisi
    builder.add_study_card_slide(
        title="İNTRAVİTREAL ANTİ-VEGF MOLEKÜLLERİNİN FARMAKOLOJİSİ",
        category="BÖLÜM 3.1.3: FARMACOTERAPİ",
        subtitle="Bevacizumab, Ranibizumab, Aflibercept (2mg/8mg), Brolucizumab ve Faricimab",
        cards=[
            {
                "card_title": "MONOKLONAL ANTİKORLAR",
                "lead": "Bevacizumab ve Ranibizumab",
                "items": [
                    "Bevacizumab (Avastin - 1.25 mg): Tam boy (149 kDa) rekombinant insanlaşmış IgG1 antikoru; off-label kullanılır [s.101].",
                    "Ranibizumab (Lucentis - 0.5 mg): Fab fragmanı (48 kDa); Fc bölgesi olmadığı için sistemik yarı ömrü çok kısadır.",
                    "Bağlanma Profili: Yalnızca serbest VEGF-A izoformlarını (VEGF165, VEGF121 vb.) bağlar.",
                    "Klinik Etki: Oküler yarı ömür yaklaşık 7-9 gün; enjeksiyon aralığı 4-8 haftadır."
                ],
                "footer": "Tam Antikor (Avastin) vs Fab (Lucentis)"
            },
            {
                "card_title": "TUZAK RESEPTÖR (FUSION PROTEIN)",
                "lead": "Aflibercept 2 mg ve Aflibercept 8 mg (PHOTON)",
                "items": [
                    "Aflibercept (Eylea - 2 mg): VEGFR-1 ve VEGFR-2 hücre dışı alanlarının insan IgG1 Fc ile füzyonudur (115 kDa) [s.102].",
                    "Geniş Spektrum: Hem VEGF-A hem VEGF-B hem de PIGF'i (Plasental Büyüme Faktörü) bağlar.",
                    "Yüksek Afinite: Ranibizumab'dan yaklaşık 100 kat daha yüksek VEGF bağlama afinitesine sahiptir.",
                    "Aflibercept 8 mg (PHOTON / PULSAR): 4 kat molar doz; göz içinde 16-20 haftaya varan kuruluk sağlar."
                ],
                "footer": "VEGF-A + VEGF-B + PlGF Füzyon Tuzağı"
            },
            {
                "card_title": "BİSPESİFİK DUAL İNHİBİSYON",
                "lead": "Faricimab (Vabysmo) ve Tie-2 Yolağı",
                "items": [
                    "Dünyanın İlk Bispesifik Antikoru: Eşzamanlı olarak hem VEGF-A'yı hem Angiopoietin-2'yi (Ang-2) nötralize eder [s.102].",
                    "Tie-2 Reseptörünün Açılması: Ang-2 baskılandığında Ang-1 Tie-2'yi aktive eder; damar sızıntısı kalıcı kilitlenir.",
                    "İnflamasyon Karşıtı Etki: Yalnızca anjiyogenezi değil, vasküler inflamasyonu ve lökostazı da durdurur.",
                    "YOSEMITE/RHINE Kanıtı: Hastaların %60'ında 4 ayda bir (16 hafta) tek doz enjeksiyonla mükemmel kuruluk."
                ],
                "footer": "Anti-VEGF-A + Anti-Ang-2 Bispesifik Antikor"
            }
        ]
    )

    # Slayt 3.1.3.2: Deksametazon ve Fluosinolon İmplantları
    builder.add_study_card_slide(
        title="İNTRAVİTREAL KORTİKOSTEROİD İMPLANTLARI",
        category="BÖLÜM 3.1.3: FARMACOTERAPİ",
        subtitle="Deksametazon (Ozurdex 0.7 mg) vs Fluosinolon Asetonid (Iluvien 0.19 mg)",
        cards=[
            {
                "card_title": "DEKSAMETAZON İMPLANT (OZURDEX)",
                "lead": "Biyobozunur (Biodegradable) Polimer",
                "items": [
                    "Bileşim: 0.7 mg deksametazon içeren PLGA (poli-laktik-ko-glikolik asit) katı polimer matris [s.103].",
                    "Biyobozunurluk: Göz içinde su ve karbondioksite tamamen erir; cerrahi çıkarma gerektirmez.",
                    "Salınım Profili: İlk 2 ay yüksek tepe dozu, ardından 4-6 aya kadar azalan terapötik salınım.",
                    "Enjeksiyon Sistemi: 22-gauge özel iğne aplikatörüyle pars planadan doğrudan vitreus içine bırakılır."
                ],
                "footer": "PLGA Matris / Biyobozunur / 4-6 Ay Etki"
            },
            {
                "card_title": "FLUOSİNOLON İMPLANT (ILUVIEN)",
                "lead": "3 Yıllık Kesintisiz Mikrodos Salınımı",
                "items": [
                    "Bileşim: 0.19 mg fluosinolon asetonid içeren poliamid tüp implant [s.103].",
                    "Bozunmaz Matris: İskelet erimez; ömür boyu vitreus tabanında inert olarak kalır.",
                    "Mikro-Dozlama: Günde yaklaşık 0.2 μg son derece düşük sabit doz salgılar.",
                    "Etki Süresi: Tek bir enjeksiyonla tam 36 AY (3 YIL) boyunca sürekli ödem kontrolü sağlar.",
                    "Endikasyon: Önceden steroid yanıtı doğrulanmış, nüks eden kronik psödofakik DMÖ olguları."
                ],
                "footer": "Bozunmaz Poliamid / 36 Ay Sürekli Etki"
            },
            {
                "card_title": "STEROİD YAN ETKİ YÖNETİMİ",
                "lead": "Katarakt ve Glokom Riski",
                "items": [
                    "Katarakt: Fakik hastalarda 1-2 yıl içinde posterior subkapsüler katarakt kaçınılmazdır [s.104].",
                    "Oküler Hipertansiyon: Hastaların yaklaşık %15-20'sinde trabeküler ağ direnci artışıyla GİB yükselir.",
                    "Steroid Yanıtı Testi: Önceden topikal steroid damlasıyla hastanın basınç duyarlılığı kontrol edilebilir.",
                    "Medikal Kontrol: Basınç artışlarının %95'i tek veya ikili topikal antiglokomatöz damlayla kontrol edilir."
                ],
                "footer": "GİB Artışı (%20) & Fakiklerde Katarakt"
            }
        ]
    )

    # Slayt 3.1.3.3: Panretinal Fotokoagülasyon (PRP) Teknikleri
    builder.add_study_card_slide(
        title="PANRETİNAL FOTOKOAGÜLASYON (PRP) UYGULAMA PROTOKOLÜ",
        category="BÖLÜM 3.1.3: LAZER UYGULAMALARI",
        subtitle="Konvansiyonel Argon Lazer vs Çok Noktalı PASCAL / Navigasyonlu NAVILAS",
        cards=[
            {
                "card_title": "BİYOLOJİK ETKİ MEKANİZMASI",
                "lead": "İskemik Retinanın Feda Edilmesi",
                "items": [
                    "Mantık: Oksijensiz kalıp feryat eden iskemik fotoreseptörlerin lazerle yakılarak yok edilmesidir [s.104].",
                    "Oksijen Dengesi: Yanan alanlarda oksijen talebi sıfırlanır; koryokapillaris oksijeni iç retinaya difüze olur.",
                    "VEGF Çöküşü: Dokuda VEGF üretimi kalıcı olarak tabana vurur; neovaskülarizasyonlar kurur ve regrese olur.",
                    "Hedef Alan: Vasküler arkadların dışından ora serrataya kadar tüm periferik retina taranır."
                ],
                "footer": "Fotoreseptör Yıkımı -> O2 Talebi Azalır -> VEGF Çöker"
            },
            {
                "card_title": "KONVANSİYONEL LAZER PARAMETRELERİ",
                "lead": "ETDRS Klasik Standartları",
                "items": [
                    "Dalga Boyu: 532 nm yeşil lazer (RPE melanini tarafından güçlü emilir) [s.104].",
                    "Spot Çapı: Korneada 500 μm (kontakt lens büyütmesine göre retinada 200-300 μm).",
                    "Süre ve Güç: 100 - 200 ms pulse süresi; hafif grimsi-beyaz yanık elde edilecek güç (200-400 mW).",
                    "Toplam Yanık Sayısı: 2-3 seansta toplam 1500 - 2000 spot uygulanır; yanıklar arası 1 spot boşluk bırakılır."
                ],
                "footer": "500 μm / 100-200 ms / 1500-2000 Spot"
            },
            {
                "card_title": "ÇOK NOKTALI (PASCAL) VE NAVİGASYON",
                "lead": "Kısa Süreli Pattern Lazer Devrimi",
                "items": [
                    "Pattern Scanning Laser (PASCAL): Tek pedal basışıyla 4×4 veya 5×5 kare matris halinde 16-25 spot atar [s.105].",
                    "Kısa Pulse (20-30 ms): Termal enerjinin çevre dokuya yayılmasını engeller; ağrı son derece düşüktür.",
                    "Uygulama Hızı: 2000 spotluk tam PRP tek veya iki seansta 10-15 dakikada tamamlanabilir.",
                    "NAVILAS: Göz hareketlerini takip eden (eye-tracking) robotik navigasyonlu lazer sistemidir."
                ],
                "footer": "PASCAL (20 ms / Ağrısız) & NAVILAS Takip"
            }
        ]
    )

    # Slayt 3.1.3.4: Subliminal Mikropulse Lazer ve Fokal/Grid Tedavi
    builder.add_study_card_slide(
        title="SUBLİMİNAL MİKROPULSE LAZER VE FOKAL FOTOKOAGÜLASYON",
        category="BÖLÜM 3.1.3: LAZER UYGULAMALARI",
        subtitle="Doku Hasarsız RPE Uyarımı (Mikropulse) vs Klasik Modifiye Grid Lazer",
        cards=[
            {
                "card_title": "SUBLİMİNAL MİKROPULSE PRENSİBİ",
                "lead": "Sıfır Termal Skar / RPE Resetleme",
                "items": [
                    "Mikro-Atım (Micropulse): Lazer enerjisi sürekli değil; mikrosaniyelik açma-kapama paketleri (duty cycle %5-10) halinde verilir [s.105].",
                    "Soğuma Süresi: Atımlar arasındaki dinlenme fazında ısı çevre dokuya dağılır; sıcaklık RPE koagülasyon eşiğini aşmaz.",
                    "Sıfır Skar: Tedavi alanında ne klinik muayenede ne de FAF'ta hiçbir yanık izi veya skar görülmez.",
                    "Hücresel Reset: Isı şok proteinlerini (HSP70) uyararak RPE hücrelerinin pompa fonksiyonunu yeniden başlatır."
                ],
                "footer": "%5-10 Duty Cycle / Sıfır Termal Yanık Skarı"
            },
            {
                "card_title": "KLASİK FOKAL / MODİFİYE GRİD",
                "lead": "Mikroanevrizmaların Kapatılması",
                "items": [
                    "Fokal Lazer: Foveaya 500 - 3000 μm mesafedeki sızıntı yapan tekil mikroanevrizmaların gövdesine uygulanır [s.105].",
                    "Spot Boyutu: 50 - 100 μm minik spot; mikroanevrizmada hafif renk solması veya beyazlaşma hedeflenir.",
                    "Grid Lazer: Diffüz sızıntı alanlarına seyrek aralıklı hafif yanıklar dizilir.",
                    "Tarihsel Yer Değişimi: CI-DME'de yerini bütünüyle anti-VEGF'e bırakmıştır; günümüzde yalnızca NCI-DME'de kullanılır."
                ],
                "footer": "Yalnızca Fovea Dışı NCI-DME'de Kullanılır"
            },
            {
                "card_title": "KOMPLİKASYONLAR VE GÜVENLİK",
                "lead": "Foveal İhlal ve Skar Genişlemesi",
                "items": [
                    "Skar Progresyonu (Laser Creep): Klasik termal lazer skarları yıllar içinde foveaya doğru genişleyebilir [s.106].",
                    "Foveal Avasküler Zon İhlali: Foveaya 500 μm'den daha yakın lazer atılması kalıcı santral skotom yaratır.",
                    "Bruch Membran Yırtığı: Aşırı yüksek güç kullanımı Bruch zarını yırtarak iyatrojenik KNV tetikleyebilir.",
                    "Mikropulse Üstünlüğü: Fovea merkezine dahi sıfır skar riskiyle güvenle uygulanabilmesi en büyük avantajıdır."
                ],
                "footer": "Skar Genişlemesi Riski vs Mikropulse Güvenliği"
            }
        ]
    )

    # Slayt 3.1.3.5: Atlas Görseli: PRP Lazer Skarları ve Lazer Yanıkları
    img_p103 = builder.get_image_for_page(103)
    builder.add_atlas_image_slide(
        title="PANRETİNAL LAZER (PRP) VE SKAR PATERNLERİ ATLASI",
        category="BÖLÜM 3.1.3: GÖRSEL ATLAS",
        subtitle="Taze Gri-Beyaz Yanıklar, Matür Pigmente Skarlar ve Geniş Açılı Fundus Dağılımı",
        image_path=img_p103 or "dr_panel_4",
        caption="Referans Eser Sayfa 103: PDR Tedavisinde Dairesel PRP Skarları ve Regrese Olmuş NVD Ağı",
        key_findings=[
            "Pigmente PRP Skarları: Vasküler arkadların dışından periferiye doğru muntazam dizilmiş yuvarlak atrofik odaklar [s.103].",
            "NVD Regresyonu: Başlangıçtaki aktif neovasküler yumakların tamamen kuruyarak fibröz kalıntıya dönmesi.",
            "Korunmuş Arka Kutup: Fovea ve vasküler arkadların içi lazerden korunmuş, santral görme kurtarılmıştır.",
            "Taze vs Eski Skar: Taze lazer gri-beyaz ödemlidir; aylar sonra melanin birikimiyle koyu kahverengi-siyah hal alır."
        ],
        differentials=[
            "Kriptik Koroidit Skarları: Düzensiz, asimetrik ve coğrafi dağılımlıdır; PRP gibi cetvelle dizilmez.",
            "Retinitis Pigmentosa: Kemik spikülü pigmentasyonu damar boyunca kümelenir; yuvarlak spotlar içermez.",
            "Koroideremi: Yaygın sklera çıplaklığı vardır; lazer izi değil doku kaybıdır."
        ],
        clinical_pearl="Başarılı bir PRP tedavisinin en objektif kanıtı, optik diskteki NVD damarlarının saniyeler içinde kan akımını kaybedip incelmesi ve fibröz beyaz kordonlara dönüşmesidir [s.104]."
    )

    # Slayt 3.1.3.6: Karşılaştırmalı Analiz: Anti-VEGF vs PRP Monoterapisi
    builder.add_split_comparison_slide(
        title="PDR TEDAVİSİNDE SEÇİM: ANTİ-VEGF VS PRP FOTOKOAGÜLASYON",
        category="BÖLÜM 3.1.3: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="DRCR.net Protokol S Bulguları Eşliğinde İki Tedavi Stratejisinin Karşılaştırılması",
        left_entity={
            "name": "İNTRAVİTREAL ANTİ-VEGF (PROTOKOL S)",
            "features": [
                ("Etki Mekanizması", "Serbest VEGF'i bağlar; damar regresyonunu hızla başlatır [s.104]."),
                ("Görme Alanı Korunumu", "Periferik görme alanı ve gece görmesi mükemmel düzeyde korunur."),
                ("Makula Ödemi Yararı", "Eşlik eden DMÖ varsa aynı anda tek enjeksiyonla tedavi edilir."),
                ("Uyum Bağımlılığı", "HAYATİ TEHLİKE: Hasta takibi aksatırsa (lost-to-follow-up) masif kanama ve körlük gelişir."),
                ("Maliyet & Süreç", "Yıllar boyu süren, yüksek maliyetli düzenli enjeksiyon bağımlılığı.")
            ]
        },
        right_entity={
            "name": "PANRETİNAL LAZER (PRP) STANDARDI",
            "features": [
                ("Etki Mekanizması", "İskemik dokuyu kalıcı yok eder; VEGF üretimini temelden söndürür [s.104]."),
                ("Kalıcılık", "Kalıcı ve geri dönüşsüz tedavidir; hasta takibe gelmese dahi koruyuculuk sürer."),
                ("Maliyet & Süreç", "2-3 seansta tamamlanır; sonrasında sürekli enjeksiyon gerektirmez."),
                ("Görme Alanı Kaybı", "Periferik görme alanında daralma, gece görmesinde zayıflama ve kontrast kaybı."),
                ("DMÖ Alevlenmesi", "Lazer sonrası geçici makula ödemi alevlenebilir (anti-VEGF ile kombine edilir).")
            ]
        },
        bottom_takeaway="Protokol S'e göre takibine güvenilmeyen, kırsal bölgede yaşayan veya randevularına sadık kalamayacak PDR hastalarında ALTIN STANDART tartışmasız Panretinal Lazer Fotokoagülasyondur (PRP) [s.104]."
    )

    # Slayt 3.1.3.7: Akış Şeması: Lazer Sonrası Nüks ve Cerrahi Karar
    builder.add_horizontal_flowchart_slide(
        title="PDR'DE LAZER SONRASI NÜKS VE VİTREKTOMİ ENDİKASYONLARI",
        category="BÖLÜM 3.1.3: AKIŞ ŞEMASI",
        subtitle="Maksimum PRP'ye Rağmen Dirençli Kanamalarda ve Traksiyonda Cerrahi Basamaklar",
        steps=[
            {
                "num": "1",
                "title": "Tamamlayıcı Lazer",
                "desc": "Nüks eden NVE/NVD varlığında atlanmış periferik alanlara ek lazer spotları uygulanması [s.104].",
                "status": "warning"
            },
            {
                "num": "2",
                "title": "Anti-VEGF Desteği",
                "desc": "Kanamayı yatıştırmak ve neovasküler damarları büzüştürmek için 1-2 doz yükleme anti-VEGF.",
                "status": "info"
            },
            {
                "num": "3",
                "title": "1-3 Ay Bekleme Kuralı",
                "desc": "İzole vitreus kanamasında retina yatışıksa (B-scan ile teyit) spontan açılma için 1-3 ay beklenir.",
                "status": "info"
            },
            {
                "num": "4",
                "title": "Vitrektomi Endikasyonu",
                "desc": ">1 aydır açılmayan yoğun vitreus kanaması VEYA foveayı tehdit eden traksiyonel dekolman (TRD).",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Preoperatif Anti-VEGF",
                "desc": "Cerrahiden 3 - 5 gün önce tek doz bevacizumab/aflibercept ile intraoperatif kanama riskinin sıfırlanması.",
                "status": "success"
            }
        ],
        bottom_takeaway="Preoperatif anti-VEGF cerrahiden en az 3, en fazla 7 gün önce yapılmalıdır; >10 gün gecikirse fibrovasküler zarlarda 'crunch sendromu' (traksiyonun aniden şiddetlenmesi ve yırtık) gelişebilir [RV2:pdf315]."
    )

    # Slayt 3.1.3.8: Klinik İpuçları: Enjeksiyon Güvenliği ve Protokoller
    builder.add_study_card_slide(
        title="İNTRAVİTREAL ENJEKSİYON TEKNİK VE GÜVENLİK STANDARTLARI",
        category="BÖLÜM 3.1.3: FARMACOTERAPİ",
        subtitle="Sterilite Protokolü, Povidon İyot Önemi, Giriş Mesafeleri ve Basınç Kontrolü",
        cards=[
            {
                "card_title": "POVİDON İYOT (%5)",
                "lead": "Kanıtlanmış Tek Antiseptik Standart",
                "items": [
                    "Konjonktiva Kesesi: Enjeksiyondan önce konjonktiva kesesine %5 povidon iyot damlatılır ve 2-3 dakika beklenir [s.106].",
                    "Cilt Temizliği: Kapak kenarları ve kirpik dipleri %10 povidon iyot ile silinir.",
                    "Topikal Antibiyotik YASAĞI: Enjeksiyon öncesi veya sonrası profilaktik antibiyotik damla KULLANILMAZ.",
                    "Direnç Riski: Rutin antibiyotik kullanımı floradaki bakterileri dirençli kılar; endoftalmi riskini artırır."
                ],
                "footer": "%5 Povidon İyot Şart / Rutin Antibiyotik Yasak"
            },
            {
                "card_title": "ANATOMİK GİRİŞ MESAFESİ",
                "lead": "Limbus Merkezli Güvenli Alan",
                "items": [
                    "Fakik Gözler: Korneal limbustan tam 3.5 - 4.0 mm geriden girilir (lense temas engellenir) [s.106].",
                    "Psödofakik Gözler: Limbustan 3.0 - 3.5 mm geriden girilir.",
                    "Kadran Tercihi: Genellikle üst-temporal veya alt-temporal kadran tercih edilir.",
                    "İğne Kalibresi: 30-gauge veya 32-gauge ince iğne; skleraya dik veya hafif oblik tünelize batırılır."
                ],
                "footer": "Fakik: 3.5-4.0 mm | Psödofakik: 3.0-3.5 mm"
            },
            {
                "card_title": "ENJEKSİYON SONRASI GÜVENLİK",
                "lead": "Santral Arter Perfüzyonu ve Takip",
                "items": [
                    "Işık Algısı Kontrolü: Enjeksiyondan hemen sonra hastanın parmak sayma veya el hareketi gördüğü teyit edilir [s.106].",
                    "CRAO Riski: 0.05 ml sıvı enjeksiyonu GİB'i geçici olarak 40-60 mmHg'ye fırlatabilir.",
                    "Parasentez İhtiyacı: Görme kararması 2-3 dakikayı aşarsa acil ön kamara parasentezi ile basınç düşürülür.",
                    "Hasta Eğitimi: İlk 3-5 günde artan ağrı, kızarıklık ve görme düşüşü (endoftalmi alarmı) acil başvuru sebebidir."
                ],
                "footer": "Işık Algısı Teyidi & Endoftalmi Eğitimi"
            }
        ]
    )

    print(f" -> Bölüm 3 (Diyabetik Retinopati ve DMÖ) Kısım 1 Tamamlandı.")

    # =========================================================================
    # KONU 3.2.1: RETİNAL VEN TIKANIKLIKLARI (BRVO, CRVO) (8 SLAYT)
    # =========================================================================
    # Slayt 3.2.1.1: Retinal Ven Tıkanıklıklarının Etyopatogenezi
    builder.add_study_card_slide(
        title="RETİNAL VEN TIKANIKLIKLARI (RVO) ETYOPATOGENEZİ",
        category="BÖLÜM 3.2.1: VEN TIKANIKLIKLARI",
        subtitle="Arteriyovenöz Çaprazlaşma, Lamina Kribroza Sıkışması ve Virchow Triadı",
        cards=[
            {
                "card_title": "BRVO VE A/V ÇAPRAZLAŞMASI",
                "lead": "Ortak Adventisya Kılıfı Mekanizması",
                "items": [
                    "Branş Retinal Ven Tıkanıklığı (BRVO): Neredeyse her zaman arter ile venin kesiştiği A/V çaprazında oluşur [s.107].",
                    "Ortak Kılıf: Arter ve ven A/V noktasında ortak bir adventisya kılıfı içine sıkışmıştır.",
                    "Arteriyosklerotik Bası: Sertleşmiş kalın arter duvarı altındaki ince ven lümenini ezer.",
                    "Türbülans ve Trombüs: Yassılaşan ven lümeninde türbülan akım endotel hasarı ve venöz trombüs yaratır."
                ],
                "footer": "Ortak Adventisya Basısı -> BRVO"
            },
            {
                "card_title": "CRVO VE LAMİNA KRİBROZA",
                "lead": "Dar Skleral Halka ve Trombüs",
                "items": [
                    "Santral Retinal Ven Tıkanıklığı (CRVO): Santral retinal venin lamina kribrozayı geçtiği tünelde tıkanmasıdır [s.107].",
                    "Rijit Skleral Halka: Optik sinir kılıfı ve lamina kribroza esnemeyen dar bir koridordur.",
                    "Sistemik ve Lokal Faktörler: Hipertansiyon, açık açılı glokom (artan GİB lümeni büker), hiperlipidemi.",
                    "Tromboembolik Risk: Yaşlıda ateroskleroz; <50 yaş genç hastada antifosfolipid ve trombofili paneli taranmalıdır."
                ],
                "footer": "Lamina Kribroza Sıkışması -> CRVO"
            },
            {
                "card_title": "GERİ AKIM VE HEMORAJİK FIRTINA",
                "lead": "Masif Hidrostatik Basınç Artışı",
                "items": [
                    "Geriye Basınç İletimi: Tıkanan venin gerisindeki tüm kapiller yatakta basınç fırlar [s.108].",
                    "Alev ve Leke Kanamaları: Kapillerler patlar; sinir lifi boyunca alev, derin katmanda leke kanamaları dolar.",
                    "Dramatik Kistoid Ödem: İç B-RB tamamen çöker; foveada masif kistoid boşluklar ve subretinal sıvı göllenir.",
                    "İskemik Kapanma: Basınç perfüzyon basıncını aştığında kapiller dolaşım durur; doku iskemisi başlar."
                ],
                "footer": "Hidrostatik Basınç -> Kanamalar & Kistoid Ödem"
            }
        ]
    )

    # Slayt 3.2.1.2: İskemik vs Non-İskemik CRVO Ayrımı
    builder.add_split_comparison_slide(
        title="CRVO'DA KRİTİK AYRIM: İSKEMİK VS NON-İSKEMİK CRVO",
        category="BÖLÜM 3.2.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="10 Disk Çapı Non-Perfüzyon Kuralı, RAPD Varlığı ve 100 Gün Glokomu Riski",
        left_entity={
            "name": "NON-İSKEMİK CRVO (PERFÜZE)",
            "features": [
                ("Görsel Keskinlik", "Genellikle 20/200'den iyidir (çoğunlukla 20/40 - 20/80) [s.108]."),
                ("Rölatif Afferent Pupil (RAPD)", "RAPD negatiftir veya çok hafiftir (<0.3 log ünite)."),
                ("FA Non-Perfüzyon", "Kapiller kapanma alanı <10 disk alanıdır; retina perfüzedir."),
                ("Fundus Görünümü", "Orta derecede kanama ve venöz dolgunluk; pamuk atılmış leke azdır."),
                ("Neovaskülarizasyon Riski", "Ön segment neovaskülarizasyonu ve NVG riski son derece düşüktür (<%1-2).")
            ]
        },
        right_entity={
            "name": "İSKEMİK CRVO (NON-PERFÜZE)",
            "features": [
                ("Görsel Keskinlik", "Ağır kayıp: Genellikle parmak sayma veya el hareketi (<20/400) [s.108]."),
                ("Rölatif Afferent Pupil (RAPD)", "POZİTİF RAPD: Belirgin afferent pupil defekti mevcuttur."),
                ("FA Non-Perfüzyon", "Kapiller kapanma alanı ≥10 disk alanıdır (geniş iskemik alan)."),
                ("Fundus Görünümü", "4 kadranda 'domates sosu' gibi masif kanamalar, sayısız pamuk atılmış leke."),
                ("100 Gün Glokomu", "İlk 3-4 ayda rubeozis iridis ve kör edici Neovasküler Glokom (NVG) riski %60-70!")
            ]
        },
        bottom_takeaway="İskemik CRVO hastaları ilk 3-4 ay boyunca ayda bir mutlaka biyomikroskopta pupil kenarı ve gonyoskopi ile açı neovaskülarizasyonu (rubeozis) açısından taranmalıdır [s.109]."
    )

    # Slayt 3.2.1.3: RVO İlişkili Makula Ödeminde Anti-VEGF Kanıtları
    builder.add_study_card_slide(
        title="RVO MAKULA ÖDEMİNDE ANTİ-VEGF PROTOKOLLERİ",
        category="BÖLÜM 3.2.1: VEN TIKANIKLIKLARI",
        subtitle="BRAVO, CRUISE, VIBRANT ve COPERNICUS/GALILEO Landmark Çalışmaları",
        cards=[
            {
                "card_title": "BRVO VE ANTİ-VEGF KANITI",
                "lead": "BRAVO ve VIBRANT Çalışmaları",
                "items": [
                    "BRAVO Çalışması: Ranibizumab 0.5 mg ile 6. ayda +18.3 harf kazanımı; sahte kolda yalnızca +7.3 harf [s.109].",
                    "VIBRANT Çalışması: Aflibercept 2 mg lazer kontrol koluna karşı +17.0 harf kazanımıyla ezici üstünlük sağladı.",
                    "Lazerin Rolü: Fokal lazer tek başına yetersizdir; ancak anti-VEGF'e yanıt vermeyen rezidüel kistlerde tamamlayıcıdır.",
                    "Hızlı Başlangıç: Tıkanıklıktan sonraki ilk 1-2 ay içinde başlanan tedavi maksimum görme kurtarır."
                ],
                "footer": "Ranibizumab & Aflibercept = +18 Harf Kazanımı"
            },
            {
                "card_title": "CRVO VE ANTİ-VEGF KANITI",
                "lead": "CRUISE ve COPERNICUS / GALILEO",
                "items": [
                    "CRUISE (Ranibizumab) & COPERNICUS (Aflibercept): Aylık enjeksiyonla hastaların %60'ından fazlası ≥15 harf kazandı [s.110].",
                    "Ödem Rezolüsyonu: Santral retinal kalınlık ilk enjeksiyonla 700 μm'den 250 μm'ye dramatik biçimde geriler.",
                    "NVG Koruyuculuğu: Düzenli anti-VEGF alan iskemik CRVO gözlerinde ön segment neovaskülarizasyonu gelişimi baskılanır.",
                    "Uzatma Protokolü: Treat-and-Extend ile 2. yılda enjeksiyon aralıkları 8-12 haftaya uzatılabilir."
                ],
                "footer": "≥15 Harf Kazanım Oranı >%60"
            },
            {
                "card_title": "KORTİKOSTEROİD SEÇENEĞİ (GENEVA)",
                "lead": "Ozurdex İmplantın Yeri",
                "items": [
                    "GENEVA Çalışması: 0.7 mg Deksametazon implantı BRVO ve CRVO makula ödeminde hızlı görme artışı sağladı [s.110].",
                    "Kardiyovasküler Güvenlik: Yakın zamanda inme veya kalp krizi geçirmiş hastalarda anti-VEGF yerine ilk tercihtir.",
                    "Psödofakik Avantajı: Katarakt riski taşımayan psödofakik RVO olgularında enjeksiyon yükünü 4-5 aya indirir.",
                    "GİB Takibi: 2. ve 3. aylarda basınç piki kontrolü zorunludur."
                ],
                "footer": "GENEVA: İnme Öyküsünde Güvenli Alternatif"
            }
        ]
    )

    # Slayt 3.2.1.4: 100 Gün Glokomu ve Ön Segment Neovaskülarizasyonu
    builder.add_study_card_slide(
        title="100 GÜN GLOKOMU VE NEOVASKÜLER GLOKOM (NVG) YÖNETİMİ",
        category="BÖLÜM 3.2.1: VEN TIKANIKLIKLARI",
        subtitle="Rubeozis İridis, Ön Kamara Açısı Fibrovasküler Kapanması ve Acil Müdahale",
        cards=[
            {
                "card_title": "NİÇİN 100 GÜN GLOKOMU?",
                "lead": "Kronolojik Neovaskülarizasyon Penceresi",
                "items": [
                    "İskemik CRVO sonrası göz içi VEGF seviyeleri zirveye ulaşır; ortalama 3. ayda (90-100 gün) rubeozis başlar [s.110].",
                    "Rubeozis İridis: İris pupil kenarında minik kılcal damar yumaklarının belirmesi.",
                    "Açıya Göç: Yeni damarlar trabeküler ağa doğru ilerler; endotelyal ve fibröz bir membranla açıyı örter.",
                    "Açı Kapanması: Fibröz zar büzüşerek periferik anterior sineşilere (PAS) ve fermuar gibi açı kapanmasına yol açar."
                ],
                "footer": "90-100. Günde İris ve Açı Damarlanması"
            },
            {
                "card_title": "KLİNİK TABLO VE AĞRILI KÖRLÜK",
                "lead": "Refrakter GİB >50-60 mmHg",
                "items": [
                    "Açı tamamen kapandığında göz içi basıncı aniden 50-60 mmHg'ye fırlar [s.111].",
                    "Semptomlar: Şiddetli zonklayıcı baş/göz ağrısı, kornea epitel ödemi, bulantı ve kusma.",
                    "Pupil Deformitesi: İrisin arkaya çekilmesiyle ektropion uvea gelişir; pupil ışığa yanıtsız fiks kalır.",
                    "Optik Sinir Yıkımı: İskemik optik sinir birkaç hafta içinde terminal çukurluğa ve tam körlüğe gider."
                ],
                "footer": "Ağrılı Kırmızı Göz + GİB >50 mmHg"
            },
            {
                "card_title": "ACİL TEDAVİ PROTOKOLÜ",
                "lead": "Anti-VEGF + PRP + Cerrahi",
                "items": [
                    "1. Acil Anti-VEGF: İntravitreal bevacizumab/aflibercept 24-48 saat içinde açı damarlarını dramatik büzüştürür [s.111].",
                    "2. Acil PRP: Kornea berraklaşır berraklaşmaz tüm retinaya tam doz Panretinal Lazer Fotokoagülasyon.",
                    "3. Medikal GİB Düşürme: Topikal beta-bloker, alfa-2 agonist ve karbonik anhidraz inhibitörü (prostaglandin kontrendikedir!).",
                    "4. Glokom Drenaj İmplantı: Açı kapalıysa trabekülektomi başarısız olur; Ahmed Valv tüp cerrahisi şarttır."
                ],
                "footer": "Acil Anti-VEGF + PRP + Ahmed Valv"
            }
        ]
    )

    # Slayt 3.2.1.5: Atlas Görseli: BRVO ve CRVO Fundus Atlası
    img_p106 = builder.get_image_for_page(106)
    builder.add_atlas_image_slide(
        title="RETİNAL VEN TIKANIKLIKLARI FUNDUS VE ANJİYOGRAFİ ATLASI",
        category="BÖLÜM 3.2.1: GÖRSEL ATLAS",
        subtitle="Üst Temporal BRVO Alev Kanamaları, İskemik CRVO Fırtınası ve Optik Disk Ödemi",
        image_path=img_p106 or "dr_panel_7",
        caption="Referans Eser Sayfa 106: Akut İskemik CRVO'da 'Fırtınalı Gün Batımı' Fundus Manzarası ve Masif Kanamalar",
        key_findings=[
            "Domates Sosu Retinası: 4 kadranın tamamına saçılmış alev, nokta ve leke şeklinde kanama fırtınası [s.106].",
            "Kıvrıntılı Dilate Venler: Tıkanıklığın gerisindeki venlerin koyu mor renkli ve genişlemiş seyri.",
            "Optik Sinir Başı Ödemi: Hiperemik ve sınırları silinmiş optik disk.",
            "Pamuk Atılmış Lekeler: İskemik CRVO'da yaygın aksoplazmik akım durması odakları."
        ],
        differentials=[
            "Diyabetik Retinopati: Tipik olarak iki taraflıdır; CRVO akut ve ezici çoğunlukla tek taraflıdır.",
            "Oküler İskemi Sendromu (OİS): Karotis darlığı; kanamalar periferdedir, venler kıvrıntılı değil düzgündür.",
            "Hipertansif Kriz: Bilateral grade 4 retinopati ve makuler yıldız ile seyreder."
        ],
        clinical_pearl="Tek taraflı masif retinal kanama ve optik disk ödemi aksi kanıtlanana kadar Santral Retinal Ven Tıkanıklığıdır; bilateral CRVO tablosunda Waldenström makroglobulinemisi veya lösemi gibi hiperviskozite sendromları aranmalıdır [s.107]."
    )

    # Slayt 3.2.1.6: Karşılaştırmalı Analiz: BRVO vs Hemisentral vs CRVO
    builder.add_study_card_slide(
        title="RETİNAL VEN TIKANIKLIĞI ANATOMİK TİPLERİ VE ÖZELLİKLERİ",
        category="BÖLÜM 3.2.1: VEN TIKANIKLIKLARI",
        subtitle="Branş (BRVO), Hemisentral (HRVO) ve Santral (CRVO) Tıkanıklıklarının Kıyaslaması",
        cards=[
            {
                "card_title": "BRANŞ VEN TIKANIKLIĞI (BRVO)",
                "lead": "Tek Bir Kadran Tutulumu (%60 Üst Temporal)",
                "items": [
                    "Lokalizasyon: En sık üst temporal kadranda A/V çaprazında görülür (arter venin önündedir) [s.107].",
                    "Görsel Seyir: Makulayı etkileyen üst temporal dalda görme düşer; nazal BRVO semptomsuz kalabilir.",
                    "Neovaskülarizasyon: İris rubeozisi nadirdir (<%1); ancak retinada NVE gelişme riski yüksektir (%30).",
                    "Tedavi: Anti-VEGF + rezidüel ödemde kadrana sınırlı sektöryel grid lazer."
                ],
                "footer": "Kadrana Sınırlı / NVE Riski Var"
            },
            {
                "card_title": "HEMİSENTRAL VEN TIKANIKLIĞI (HRVO)",
                "lead": "Retinanın Tam Yarısının Tutulumu",
                "items": [
                    "Anatomik Varyasyon: Gözlerin %20'sinde santral ven retinaya girmeden önce iki ana gövdeye ayrılır [s.108].",
                    "Tutulum Alanı: Üst veya alt yarıkürenin tamamında kanama ve venöz konjesyon.",
                    "Klinik Davranış: Ağırlık olarak BRVO ile CRVO arasındadır; %40 oranında iskemik olabilir.",
                    "NVG Riski: İskemik HRVO olgularında açı neovaskülarizasyonu riski yaklaşık %10-15'tir."
                ],
                "footer": "Yarım Küre / Çift Gövde Varyasyonu"
            },
            {
                "card_title": "SANTRAL VEN TIKANIKLIĞI (CRVO)",
                "lead": "Tüm Retinanın 4 Kadran Tutulumu",
                "items": [
                    "Lokalizasyon: Lamina kribroza içi ana gövde tıkanıklığı [s.108].",
                    "Tutulum Alanı: 4 kadranın tamamı, arka kutup ve perifer kanama gölüne döner.",
                    "İskemi Ayrımı: İskemik ve non-iskemik ayrımı prognoz ve yaşam kalitesi için hayatidir.",
                    "NVG Riski: İskemik formda %70 rubeozis iridis ve kör edici 100 gün glokomu.",
                    "Tedavi: Acil anti-VEGF yüklemesi + iskemik formda erken profilaktik PRP."
                ],
                "footer": "Global Tutulum / %70 NVG Riski"
            }
        ]
    )

    # Slayt 3.2.1.7: Akış Şeması: Akut RVO Acil Yönetim Algoritması
    builder.add_horizontal_flowchart_slide(
        title="AKUT RETİNAL VEN TIKANIKLIĞI KLİNİK YÖNETİM ALGORİTMASI",
        category="BÖLÜM 3.2.1: AKIŞ ŞEMASI",
        subtitle="İlk Başvurudan İskemi Tayinine, Anti-VEGF Enjeksiyonuna ve Açı Takibine",
        steps=[
            {
                "num": "1",
                "title": "İlk Değerlendirme",
                "desc": "BCVA, rölatif afferent pupil (RAPD) testi, biyomikroskopi ve gonyoskopi ile açı muayenesi [s.108].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "OKT ile Ödem Teyidi",
                "desc": "Santral foveal kalınlık ölçümü; subretinal sıvı ve kistoid kavitelerin kaydedilmesi.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Anti-VEGF Yüklemesi",
                "desc": "Görme kaybı ve ödem varsa beklemeden aylık Aflibercept veya Ranibizumab başlanması.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "FA ile İskemi Tayini",
                "desc": "Kanamalar hafiflediğinde (2-3. ay) FA çekilerek non-perfüzyon alanının (>10 DD) ölçülmesi.",
                "status": "warning"
            },
            {
                "num": "5",
                "title": "İskemik CRVO Takibi",
                "desc": "İskemik ise ilk 4 ay boyunca ayda bir gonyoskopi; rubeozis başlarsa acil PRP lazer.",
                "status": "danger"
            }
        ],
        bottom_takeaway="RVO hastalarında kanama açılmadan ilk günlerde yapılan FA kanamaların maskelemesi nedeniyle güvenilmezdir; iskemi tayini için kanamaların rezorbe olduğu 2-3. ay beklenmelidir [s.109]."
    )

    # Slayt 3.2.1.8: Aktif Hatırlama & Board Sınavı Vakası
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: RETİNAL VEN TIKANIKLIĞI",
        category="BÖLÜM 3.2.1: AKTİF HATIRLAMA",
        subtitle="68 Yaşında Ani Görme Kaybı, Pozitif RAPD ve 4 Kadranda Yaygın Kanamalar",
        vignette="68 yaşında hipertansif erkek hasta sol gözde sabah uyanınca fark ettiği ani ve ağrısız görme kaybıyla başvuruyor. Görme keskinliği sol gözde parmak sayma 1 metreden, sağ gözde 10/10. Sol gözde belirgin Rölatif Afferent Pupil Defekti (RAPD) pozitif. Dilate fundusta optik disk ödemli, retinal venler aşırı kıvrıntılı ve koyu, tüm 4 kadranda yaygın alev ve leke kanamaları ile sayısız pamuk atılmış leke izleniyor. Makula SD-OCT'de santral kalınlık 780 μm.",
        differentials=[
            "İskemik Santral Retinal Ven Tıkanıklığı (Ağır görme kaybı, pozitif RAPD ve yaygın CWS ile kesin tanı).",
            "Non-İskemik CRVO (Görme daha iyidir, RAPD negatiftir, pamuk atılmış leke azdır).",
            "Oküler İskemi Sendromu (Tek taraflı karotis tıkanıklığı; kanamalar orta periferdedir, venler düzdür).",
            "Proliferatif Diyabetik Retinopati (Bilateraldir; tek taraflı akut kriz beklenmez)."
        ],
        decision="1. Tanı: İskemik Santral Retinal Ven Tıkanıklığı (İskemik CRVO).\n2. Tedavi: Acil İntravitreal Anti-VEGF (Aflibercept/Ranibizumab) yüklemesi başlanmalı.\n3. Yaşamsal Uyarı: Hasta '100 gün glokomu' açısından uyarılmalı; ilk 4 ay boyunca aylık biyomikroskopi ve gonyoskopi ile açı taranmalı; ilk rubeozis belirtisinde acil PRP uygulanmalıdır.",
        board_trap="İskemik CRVO'da hasta yalnızca anti-VEGF enjeksiyonlarına bırakılıp açı muayenesi (gonyoskopi) ihmal edilirse, enjeksiyon aralığı uzatıldığında hasta aniden göz içi basıncı 60 mmHg olan ağrılı neovasküler glokomla gelebilir [s.111]."
    )

    # =========================================================================
    # KONU 3.2.2: RETİNAL ARTER TIKANIKLIKLARI (CRAO, BRAO) (7 SLAYT)
    # =========================================================================
    # Slayt 3.2.2.1: CRAO Patofizyolojisi ve Emboli Türleri
    builder.add_study_card_slide(
        title="SANTRAL RETİNAL ARTER TIKANIKLIĞI (CRAO) PATOGENEZİ",
        category="BÖLÜM 3.2.2: ARTER TIKANIKLIKLARI",
        subtitle="İç Retina İskemik Nekrozu, Emboli Tipleri ve Zaman Penceresi (Time is Tissue)",
        cards=[
            {
                "card_title": "İÇ RETİNA SİTOTOKSİK ENFARKTÜSÜ",
                "lead": "Opak Beyazlaşma ve Kiraz Kırmızısı Nokta",
                "items": [
                    "Santral Retinal Arter (CRA): Oftalmik arterin ilk dalıdır; retinanın iç 2/3 katmanını besler [s.111].",
                    "Akut Oklüzyon: Tıkanma anında iç retinada (RNFL, GCL, IPL) dakikalar içinde sitotoksik ödem başlar.",
                    "Bulanık Beyazlaşma: Aksonal akım durur (aksoplazmik staz); retina opak tebeşir beyazı renk alır.",
                    "Kiraz Kırmızısı Benek (Cherry-Red Spot): Foveolada iç retina tabakaları bulunmadığı için alttaki sağlıklı kırmızı koroid parıldar."
                ],
                "footer": "İç Retina İskemisi = Tebeşir Beyazı + Cherry-Red"
            },
            {
                "card_title": "3 KLASİK RETİNAL EMBOLİ TÜRÜ",
                "lead": "Kolesterol, Kalsiyum ve Trombosit Plakları",
                "items": [
                    "1. Kolesterol (Hollenhorst Plağı - %75): Karotis bifurkasyonundan kopar; parlak, sarı, yassı, bifürkasyonlarda oturur [s.112].",
                    "2. Kalsiyum Plağı (Kalsifik - %15): Kalsifiye kalp kapakçıklarından kopar; mat beyaz, büyük, proksimalde tıkar; en yıkıcı embolidir.",
                    "3. Trombosit-Fibrin Plağı (%10): Karotis duvar trombüsünden kopar; uzun, donuk gri-beyaz, damar boyunca hareket edebilir."
                ],
                "footer": "Hollenhorst (Karotis) vs Kalsifik (Kalp Kapak)"
            },
            {
                "card_title": "ZAMAN PENCERESİ: TIME IS TISSUE",
                "lead": "Primat Deneyleri ve 240 Dakika Eşiği",
                "items": [
                    "Haywood Primat Modeli: Tam retina arter oklüzyonunda kalıcı hasar 90-100 dakikada başlar [s.112].",
                    "240 Dakika (4 Saat): 4 saatten sonra fotoreseptör ve ganglion hücrelerinde irreversibl total nekroz gelişir.",
                    "Akut İnme Eşdeğeri: CRAO gözün iskemik inmesidir; kardiyoloji ve nöroloji acil koduyla yönetilmelidir.",
                    "Spontan Rekanalizasyon: Olguların bir kısmında emboli kırılarak perifere kayar veya litik enzimlerle çözülür."
                ],
                "footer": "<240 Dakika: Kurtarılabilir İskemik Eşik"
            }
        ]
    )

    # Slayt 3.2.2.2: Silioretinal Arterin Hayat Kurtarıcı Rolü
    builder.add_study_card_slide(
        title="SİLİORETİNAL ARTER VARLIĞI VE FOVEANIN KORUNMASI",
        category="BÖLÜM 3.2.2: ARTER TIKANIKLIKLARI",
        subtitle="Koroid Dolaşımından Köken Alan Koruyucu Arter Varyasyonu ve Görsel Sonuçlar",
        cards=[
            {
                "card_title": "ANATOMİK VARYASYON VE KÖKEN",
                "lead": "Popülasyonun Yaklaşık %20 - 30'unda Bulunur",
                "items": [
                    "Köken: Santral retinal arterden değil, kısa posterior siliyer arterlerden (koroid dolaşımı) doğar [s.112].",
                    "Giriş Yolu: Optik disk kenarından kanca şeklinde kıvrılarak foveaya doğru uzanır.",
                    "Bağımsız Perfüzyon: CRA tamamen tıkansa dahi, koroid dolaşımı çalıştığı sürece silioretinal arter kanlanmaya devam eder.",
                    "Görsel Koruma: Makula ve foveal fotoreseptörleri canlı tutarak hastanın santral görmesini kurtarır."
                ],
                "footer": "Koroid Kökenli / CRA'dan Bağımsız Arter"
            },
            {
                "card_title": "CRAO İLE SİLİORETİNAL ARTER BİRLİKTELİĞİ",
                "lead": "Tebeşir Beyazı Retinada Pembe Fovea Adası",
                "items": [
                    "Klinik Manzara: Tüm retina tebeşir beyazı enfarkt içindeyken, fovea çevresinde canlı pembe bir ada kalır [s.113].",
                    "Görme Keskinliği: Hasta tüm periferik görmesini kaybetmiş (tübüler görme) olsa da santral görme 10/10 olabilir!",
                    "FA Görünümü: Arka kutup ve perifer dolmazken, silioretinal arter ve beslediği makula yatağı erken ve normal dolar.",
                    "Uzun Dönem: Hasta teleskopik borudan bakar gibi yaşar; santral görme korunur ancak perifer tamamen ölüdür."
                ],
                "footer": "Perifer Kör / Santral Görme 10/10 Korunabilir"
            },
            {
                "card_title": "İZOLE SİLİORETİNAL ARTER TIKANIKLIĞI",
                "lead": "Nadir Bir Klinik Tablo",
                "items": [
                    "Tek Başına Tıkanma: Bazen CRA açıkken yalnızca silioretinal arter emboliyle tıkanabilir [s.113].",
                    "Klinik Tablo: Periferik retina tamamen pembe ve normalken, fovea merkezinde fokal beyaz enfarkt alanı izlenir.",
                    "Ağır Santral Skotom: Hasta ani santral körlükle gelir; periferik görme alanı ise kusursuzdur.",
                    "CRVO Birlikteliği: Ağır CRVO'da artan venöz basınç bazen sekonder silioretinal arter tıkanıklığı yapabilir."
                ],
                "footer": "Yalnızca Fovea İskemik / Perifer Normal"
            }
        ]
    )

    # Slayt 3.2.2.3: CRAO'da Konservatif Acil Tedavi Yöntemleri
    builder.add_study_card_slide(
        title="AKUT CRAO ACİL MÜDAHALE VE PROTOKOLLERİ",
        category="BÖLÜM 3.2.2: ARTER TIKANIKLIKLARI",
        subtitle="Göz İçi Basıncını Düşürme, Oküler Masaj, Parasentez ve Trombolitik Tartışması",
        cards=[
            {
                "card_title": "HİDROSTATİK BASINÇ MANİPÜLASYONU",
                "lead": "Emboliyi Perifere İtme Stratejisi",
                "items": [
                    "Oküler Masaj: Goldmann üç aynalı lens veya parmakla 10-15 saniye bası ve ani bırakma döngüsü [s.113].",
                    "GİB Dalgalanması: Ani basınç düşüşü arteriyel perfüzyon gradyanını fırlatarak tıkayıcı emboliyi perifere fırlatır.",
                    "Ön Kamara Parasentezi: 30G iğne ile korneal limbustan 0.1-0.2 ml aköz drene edilerek GİB saniyede sıfırlanır.",
                    "İntravenöz Asetazolamid: 500 mg IV ve topikal damlalarla aköz üretimi durdurulur."
                ],
                "footer": "Masaj + Parasentez = Emboliyi İtme"
            },
            {
                "card_title": "VAZODİLATASYON VE OKSİJENASYON",
                "lead": "Karbogen Solutma ve Dilatasyon",
                "items": [
                    "Karbogen (%95 O2 + %5 CO2): CO2 serebral ve retinal arterleri dilate eder; O2 difüzyonu artırır [s.114].",
                    "Alternatif: Kese kağıdına solutma (kanda pCO2 artırılarak retinal vazodilatasyon uyarılır).",
                    "Hiperbarik Oksijen (HBOT): İlk 8-12 saatte uygulanabilirse koryokapillaristen retinanın iç katmanlarına O2 difüzyonunu sağlar.",
                    "Dilatör İlaçlar: Dilaltı izosorbid dinitrat veya nitrogliserin denenebilir."
                ],
                "footer": "Karbogen (%5 CO2) / Hiperbarik O2"
            },
            {
                "card_title": "TROMBOLİTİK TEDAVİ VE KANITLAR",
                "lead": "EAGLE Çalışması ve İntraarteriyel tPA",
                "items": [
                    "İntraarteriyel / İntravenöz tPA: Oftalmik artere mikrokateterle girilerek doku plazminojen aktivatörü verilmesi [s.114].",
                    "EAGLE Çalışması: Erken dönem randomize çalışmada lokal tPA görmeyi artırmış ancak intrakraniyal kanama riskini katlamıştır.",
                    "Güncel Nörolojik Yaklaşım: İnme merkezlerinde ilk 4.5 saatte başvuran seçilmiş vakalarda IV tromboliz tartışılmaktadır.",
                    "Realite: Konservatif tedavilerin hiçbirinin randomize çalışmalarda kanıtlanmış mutlak üstünlüğü yoktur."
                ],
                "footer": "Kanıt Düşük / İnme Merkezi İşbirliği Şart"
            }
        ]
    )

    # Slayt 3.2.2.4: Sistemik İnceleme: Karotis ve Kardiyak Triyaj
    builder.add_study_card_slide(
        title="CRAO SONRASI ZORUNLU SİSTEMİK VE NÖROLOJİK TRİYAJ",
        category="BÖLÜM 3.2.2: ARTER TIKANIKLIKLARI",
        subtitle="Karotis Doppler USG, Ekokardiyografi, Holter EKG ve İnme Önleme Protokolü",
        cards=[
            {
                "card_title": "İLK 2-4 HAFTADA İNME PATLAMASI",
                "lead": "CRAO Sonrası %5 - 10 Serebral İskemi",
                "items": [
                    "CRAO geçiren bir hastanın ilk 2-4 hafta içinde ölümcül bir iskemik inme geçirme riski %5 - 10'dur [s.114].",
                    "Aynı Vasküler Havza: Retinal arter oftalmik arter aracılığıyla doğrudan internal karotis artere (ICA) bağlıdır.",
                    "Acil Nöroloji Konsültasyonu: Hasta göz kliniğinden acil inme ünitesine (Stroke Center) transfer edilmelidir.",
                    "Serebral Diffüzyon MRG: Akut CRAO hastalarının %25'inde beyinde semptomsuz sessiz enfarkt odakları saptanır."
                ],
                "footer": "İlk 1 Ayda İskemik İnme Riski %5-10"
            },
            {
                "card_title": "KAROTİS VE KARDİYAK ARAŞTIRMA",
                "lead": "Emboli Kaynağının Tespiti",
                "items": [
                    "Karotis Doppler USG: İpsilateral internal karotiste darlık (stenoz) ve ülsere aterom plağı taranır [s.115].",
                    "Karotis Endarterektomisi (CEA): >%70 semptomatik darlık saptandığında acil CEA veya stent hayat kurtarır.",
                    "Ekokardiyografi (TTE / TEE): Sol atriyal trombüs, patent foramen ovale (PFO), kapak vejetasyonları.",
                    "24-48 Saatlik Ritim Holter: Paroksismal atriyal fibrilasyon (AF) tespiti ve oral antikoagülan başlanması."
                ],
                "footer": "Karotis Doppler + Eko + Holter EKG"
            },
            {
                "card_title": "DEV HÜCRELİ ARTERİT (GCA) DIŞLANMASI",
                "lead": "Arteritik CRAO Acili (>50 Yaş)",
                "items": [
                    "Olguların %5'i embolik değil, Temporal Arterit (Dev Hücreli Arterit) zemininde gelişir [s.115].",
                    "Acil Kan Testleri: Sedimantasyon (ESR), C-Reaktif Protein (CRP) ve Trombosit sayısı.",
                    "Sorgulama: Baş ağrısı, şakak hassasiyeti, çene kladikasyosu, kilo kaybı ve polimiyaljiya romatika.",
                    "Tedavi: GCA şüphesinde biyopsi sonucu beklenmeden ACİL 1000 mg IV Metilprednizolon başlanır (karşı gözü korumak için!)."
                ],
                "footer": "ESR/CRP Yüksekse = Acil IV Steroid"
            }
        ]
    )

    # Slayt 3.2.2.5: Atlas Görseli: CRAO, BRAO ve Hollenhorst Plağı
    img_p113 = builder.get_image_for_page(113)
    builder.add_atlas_image_slide(
        title="RETİNAL ARTER TIKANIKLIKLARI FUNDUS ATLASI",
        category="BÖLÜM 3.2.2: GÖRSEL ATLAS",
        subtitle="Tebeşir Beyazı İskemi, Cherry-Red Spot, Hollenhorst Kolesterol Embolisi ve BRAO",
        image_path=img_p113 or "dr_schema_2",
        caption="Referans Eser Sayfa 113: Akut CRAO Kesitinde Kiraz Kırmızısı Benek ve Arter Bifürkasyonunda Hollenhorst Plağı",
        key_findings=[
            "Tebeşir Beyazı Opasifikasyon: İç retina tabakalarının sitotoksik ödemine bağlı soluk, sütsü beyaz görünüm [s.113].",
            "Kiraz Kırmızısı Benek (Cherry-Red Spot): Foveola merkezinde kontrast yaratan parlak kırmızı çukurluk.",
            "Hollenhorst Kolesterol Plağı: Arter dallanma noktasında parıldayan refraktil, sarı-altın renkli emboli.",
            "Segmenter Kan Akımı (Box-carring): Arter lümeninde eritrositlerin vagon vagon kesik kesik dizilmesi."
        ],
        differentials=[
            "Tay-Sachs Hastalığı: Bebekte bilateral cherry-red spot; metabolik gangliozid birikimidir.",
            "Commotio Retinae (Berlin Ödemi): Künt travma öyküsü; dış retina fotoreseptör mekanik hasarıdır.",
            "Kinin Toksisitesi: Akut zehirlenmede bilateral retina beyazlaşması ve aşırı arter daralması."
        ],
        clinical_pearl="Akut CRAO'da fundustaki kiraz kırmızısı benek birkaç hafta içinde kaybolur; yerini balmumu renginde soluk atrofik optik diske ve incecik ipliksi sklerotik damarlara bırakır [s.114]."
    )

    # Slayt 3.2.2.6: Branş Retinal Arter Tıkanıklığı (BRAO)
    builder.add_study_card_slide(
        title="BRANŞ RETİNAL ARTER TIKANIKLIĞI (BRAO) VE SEKTÖRYEL İSKEMİ",
        category="BÖLÜM 3.2.2: ARTER TIKANIKLIKLARI",
        subtitle="Kama Biçimli Sektörel İnfarkt, Kalıcı Görme Alanı Skotomu ve Sistemik Risk",
        cards=[
            {
                "card_title": "SEKTÖRYEL İNFARKT MORFOLOJİSİ",
                "lead": "Tıkanan Arter Dağılımında Tebeşir Beyazı",
                "items": [
                    "Tanım: Santral arterin ana dallarından birinin (en sık üst temporal dal) emboliyle tıkanmasıdır [s.115].",
                    "Kama Biçimli Sınır: İskemik ödem tıkanan arterin besleme alanıyla sınırlı keskin geometrik sınır çizer.",
                    "Görünür Emboli: Olguların %60-70'inde bifurkasyona oturmuş parlak Hollenhorst plağı çıplak gözle görülür.",
                    "Foveal Katılım: Eğer tıkanan dal foveolayı besleyen kapillerleri içeriyorsa santral görme aniden çöker."
                ],
                "footer": "Kama Biçimli Sektörel Beyazlaşma"
            },
            {
                "card_title": "GÖRME ALANI VE PROGNOZ",
                "lead": "Kalıcı Absolü Alt/Üst Alt Skotom",
                "items": [
                    "Alt Kadranda Tıkanıklık: Hastada keskin sınırlı kalıcı üst görme alanı kaybı (altitudinal defekt) yaratır [s.115].",
                    "Kalıcı Skotom: Sitotoksik nöron nekrozu nedeniyle görme alanındaki defekt ömür boyu kalıcıdır.",
                    "Santral Görme: Fovea korunmuşsa hastanın görmesi 10/10 kalabilir; ancak hasta 'perde inmesi' tarifler.",
                    "Takip: Haftalar içinde ödem çözülür; yerini sektörel RNFL atrofisine bırakır."
                ],
                "footer": "Kalıcı Altitudinal Alan Kaybı"
            },
            {
                "card_title": "SİSTEMİK YAKLAŞIM AYNI DERECEDE ACİLDİR",
                "lead": "Küçük Emboli = Büyük Uyarı",
                "items": [
                    "Aynı Sistemik Risk: BRAO geçiren hasta da CRAO hastasıyla birebir aynı inme ve kardiyak riski taşır [s.116].",
                    "Acil Karotis Taraması: Hollenhorst plağı saptanan her hastada karotis doppler ve kardiyak EKO zorunludur.",
                    "Antiagregan Tedavi: Nöroloji ile konsülte edilerek derhal Aspirin veya Klopidogrel başlanmalıdır.",
                    "Trombolitik Gerekmez: BRAO'da sistemik trombolitik endikasyonu yoktur; konservatif izlenir."
                ],
                "footer": "BRAO da Acil İnme Taraması Gerektirir"
            }
        ]
    )

    # Slayt 3.2.2.7: Karar Ağacı: CRAO Acil İnme ve GCA Triyaj Algoritması
    builder.add_decision_tree_slide(
        title="AKUT CRAO BAŞVURUSUNDA ACİL SİSTEMİK TRİYAJ PROTOKOLÜ",
        category="BÖLÜM 3.2.2: KARAR AĞACI",
        subtitle="Time is Tissue: GCA Dışlanması, İnme Ünitesi Transferi ve Konservatif Müdahale",
        root_label="ANİ AĞRISIZ GÖRME KAYBI + SÜTSÜ BEYAZ RETİNA + CHERRY-RED SPOT",
        branches=[
            {
                "label": "1. Yaş >50 + Sistemik Belirtiler (ESR/CRP Yüksek)",
                "criteria": "Baş ağrısı, şakak hassasiyeti, çene kladikasyosu; sedimentasyon >50-70 mm/saat [s.115].",
                "action": "Tanı: Arteritik CRAO (GCA) -> Acil IV 1000 mg Metilprednizolon + Temporal Arter Biyopsisi."
            },
            {
                "label": "2. Erken Başvuru (<4 Saat) + Non-Arteritik",
                "criteria": "GCA bulgusu yok; görme kaybı 4 saatten taze; hasta yürüyebilir durumda [s.113].",
                "action": "Eylem: Oküler Masaj + Ön Kamara Parasentezi + Acil İnme Ünitesine (Stroke Team) Transfer."
            },
            {
                "label": "3. Geç Başvuru (>12 - 24 Saat)",
                "criteria": "Retina enfarktı oturmuş; doku nekrozu tamamlanmış; görme kurtarılamaz [s.114].",
                "action": "Eylem: Göze agresif müdahale etme -> Acil Karotis Doppler + Kardiyak EKO + Antiagregan başlanması."
            }
        ],
        bottom_rule="CRAO geçiren bir hastanın ilk 1 ayda ölümcül felç geçirme riski %10'dur; hastayı yalnızca göz damlasıyla eve göndermek malpraktistir, acil nöroloji inme taraması zorunludur [s.114]."
    )

    # =========================================================================
    # KONU 3.3.1: HİPERTANSİF RETİNOPATİ, RAM VE COATS (8 SLAYT)
    # =========================================================================
    # Slayt 3.3.1.1: Hipertansif Retinopati Evrelemesi (Keith-Wagener-Barker)
    builder.add_study_card_slide(
        title="HİPERTANSİF RETİNOPATİ VE DAMARSAL PATOFİZYOLOJİ",
        category="BÖLÜM 3.3.1: HİPERTANSİYON VE RAM",
        subtitle="Vazokonstriksiyon, Arteriyoskleroz, Keith-Wagener-Barker Evreleri ve Malign Kriz",
        cards=[
            {
                "card_title": "DAMARSAL PATOFİZYOLOJİK EVRELER",
                "lead": "Spazm, Skleroz ve Eksüdasyon",
                "items": [
                    "1. Vazokonstriktif Faz: Akut tansiyon yükselmesine otoregülatuvar yanıt; yaygın arteriyoler daralma [s.116].",
                    "2. Sklerotik Faz: Kronik basınç damar duvarında medial hipertrofi, hyalin dejenerasyonu ve elastik doku kaybı yapar.",
                    "3. Eksüdatif Faz: Basınç endoteli yırtar; kan-retina bariyeri çöker, kanama, sert eksüda ve ödem başlar.",
                    "4. Malign Faz: İskemik optik disk ödemi (papilödem) ve koryokapillaris nekrozu eklenir."
                ],
                "footer": "Spazm -> Skleroz -> Eksüdasyon -> Malign Faz"
            },
            {
                "card_title": "KEITH-WAGENER-BARKER SINIFLAMASI",
                "lead": "Grade 1'den Grade 4'e Klinik İlerleme",
                "items": [
                    "Grade 1: Hafif, yaygın retinal arterioler incelme ve parlaklık artışı [s.116].",
                    "Grade 2: Belirgin arterioler daralma + A/V çaprazlaşma belirtileri (Salus ve Gunn belirtileri).",
                    "Grade 3: Bakır/Gümüş tel manzarası + alev kanamaları + pamuk atılmış lekeler + sert eksüdalar (makuler yıldız).",
                    "Grade 4: Grade 3 bulgularına ek olarak BİLATERAL OPTİK DİSK ÖDEMİ (Malign Hipertansiyon)."
                ],
                "footer": "Grade 4 = Disk Ödemi (Malign Hipertansiyon)"
            },
            {
                "card_title": "A/V ÇAPRAZLAŞMA FENOMENLERİ",
                "lead": "Salus, Gunn ve Bonnet Belirtileri",
                "items": [
                    "Gunn Belirtisi: Sertleşmiş arterin üzerinden geçtiği venin her iki ucunda konik incelme ve silinme [s.117].",
                    "Salus Belirtisi: Sklerotik arterin venin yönünü saptırması; venin dik açıyla (S şeklinde) sapması.",
                    "Bonnet Belirtisi: Kesişme yerinin hemen distalinde ven lümeninde fokal dilatasyon ve göllenme.",
                    "Klinik Anlamı: A/V çaprazlaşma derecesi hastanın sistemik ateroskleroz süresinin en objektif kanıtıdır."
                ],
                "footer": "Gunn (İncelme) & Salus (Saptırma)"
            }
        ]
    )

    # Slayt 3.3.1.2: Hipertansif Koroidopati ve Nöropati
    builder.add_study_card_slide(
        title="HİPERTANSİF KOROİDOPATİ VE OPTİK NÖROPATİ",
        category="BÖLÜM 3.3.1: HİPERTANSİYON VE RAM",
        subtitle="Elschnig Lekeleri, Siegrist Çizgileri, Makuler Yıldız ve Gebelik Preeklampsisi",
        cards=[
            {
                "card_title": "HİPERTANSİF KOROİDOPATİ",
                "lead": "Elschnig Lekeleri ve Siegrist Çizgileri",
                "items": [
                    "Akut Malign Yükselme: Koroid damarlarında sempatik vazokonstriksiyon koryokapillaris infarktına yol açar [s.117].",
                    "Elschnig Lekeleri: Fokal koryokapillaris infarktı; akut fazda sarı-beyaz kabarık, kronik fazda pigmente halkalı benekler.",
                    "Siegrist Çizgileri: Koroid arteriolleri boyunca lineer dizilmiş hiperpigmente çizgilenmeler.",
                    "Eksüdatif Retina Dekolmanı: Ağır koroid iskemisinde RPE bariyeri çöker; alt kadranda büllöz seröz RD gelişebilir."
                ],
                "footer": "Elschnig (Nodül) & Siegrist (Çizgi)"
            },
            {
                "card_title": "HİPERTANSİF OPTİK NÖROPATİ",
                "lead": "Malign Krizde Optik Disk Ödemi",
                "items": [
                    "Mekanizma: Posterior siliyer arterlerin iskemisi ve kafa içi basınç artışına bağlı aksoplazmik akım durması [s.117].",
                    "Klinik Tablo: Bilateral, hiperemik, sınırları silinmiş ödemli optik diskler.",
                    "Makuler Yıldız (Macular Star): Optik diskten sızan lipitlerin Henle lif tabakasında radyal dizilmesiyle oluşan yıldız deseni.",
                    "Ayırıcı Tanı: İntrakraniyal kitleye bağlı papilödemde retina kanamaları ve eksüda diske yakındır; tansiyon normaldir."
                ],
                "footer": "Bilateral Disk Ödemi + Makuler Yıldız"
            },
            {
                "card_title": "PREEKLAMPSİ VE EKLAMPSİ",
                "lead": "Gebelikte Toksik Vazospazm",
                "items": [
                    "Patoloji: Plasental iskemi sonucu salınan sFlt-1 faktörünün endoteli felç etmesi ve yaygın vazospazm [s.118].",
                    "Semptomlar: Görme bulanıklığı, skotomlar, fotopsi ve kortikal körlük.",
                    "Fundus Bulgusu: Sıklıkla bilateral multifokal eksüdatif retina dekolmanı ve arteriolar daralma izlenir.",
                    "Tedavi: Doğumun acilen gerçekleştirilmesi; doğumdan sonra retina dekolmanları hızla spontan yatışır."
                ],
                "footer": "Preeklampsi = Bilateral Eksüdatif RD"
            }
        ]
    )

    # Slayt 3.3.1.3: Retinal Arter Makroanevrizması (RAM)
    builder.add_study_card_slide(
        title="RETİNAL ARTER MAKROANEVRİZMASI (RAM) PATOLOJİSİ",
        category="BÖLÜM 3.3.1: HİPERTANSİYON VE RAM",
        subtitle="Hipertansif Yaşlı Kadınlar, Arteriyel Duvar Ektazisi ve Çok Katmanlı Kanama",
        cards=[
            {
                "card_title": "DEMOGRAFİ VE PATOGENEZ",
                "lead": "Yaşlı Hipertansif Kadın Hastalığı",
                "items": [
                    "Tipik Profil: 60-80 yaş arası, kronik kontrolsüz sistemik hipertansiyonu olan kadın hastalar (%75-80) [s.118].",
                    "Lokalizasyon: İlk üç sıra retinal arteriol bifurkasyonlarında veya A/V çaprazlaşma noktalarında gelişir.",
                    "Damar Ektazisi: Arter duvarında elastik lamina kaybı ve hyalinize incelme sonucu 100-250 μm'lik sakküler veya füziform genişleme.",
                    "Tetikleyici Faktör: Ani sistolik kan basıncı piki makroanevrizmanın patlamasına yol açar."
                ],
                "footer": "Yaşlı Hipertansif Kadın / Arteriyoler Ektazi"
            },
            {
                "card_title": "ÇOK KATMANLI KUM SAATİ KANAMASI",
                "lead": "Hourglass Hemorrhage Paternı",
                "items": [
                    "Patlama Dinamiği: Yüksek basınçlı arteriyel kan aynı anda birden fazla retinal kompartmana fışkırır [s.118].",
                    "1. Subretinal Kanama: RPE ile fotoreseptörler arasına yayılan derin kanama gölü.",
                    "2. İntraretinal Kanama: Retina katmanları içine dağılan yoğun kanama.",
                    "3. Preretinal / Subhyaloid Kanama: İLM veya arka hyaloid altında biriken kayık biçimli taze kan.",
                    "Kum Saati Manzarası: Subretinal ve preretinal kanamaların ortada retina dokusuyla boğumlanarak kum saati oluşturması."
                ],
                "footer": "Subretinal + İntraretinal + Preretinal Kanama"
            },
            {
                "card_title": "DOĞAL SEYİR VE SPONTAN TROMBÜS",
                "lead": "Kendi Kendini Sınırlayan Patoloji",
                "items": [
                    "Spontan Tromboz: Patlama sonrası lümen içinde spontan trombüs gelişir; anevrizma kendiliğinden kapanır [s.119].",
                    "Eksüdatif Form: Bazen patlamaz; kronik plazma sızıntısıyla foveayı saran devasa sirsine lipid halkası yapar.",
                    "Görsel Tehdit: Fovea altına kan veya yoğun lipid çökerse fotoreseptör toksisitesi kalıcı görme kaybı yaratır.",
                    "Tedavi Endikasyonu: Yalnızca foveayı tehdit eden eksüdasyon veya persistan kanama varlığında müdahale edilir."
                ],
                "footer": "Spontan Tromboz vs Foveal Lipid Tehdidi"
            }
        ]
    )

    # Slayt 3.3.1.4: RAM Tedavi Protokolleri
    builder.add_study_card_slide(
        title="RETİNAL ARTER MAKROANEVRİZMASI (RAM) TEDAVİ SEÇENEKLERİ",
        category="BÖLÜM 3.3.1: HİPERTANSİYON VE RAM",
        subtitle="Gözlem, Lazer Fotokoagülasyon, Anti-VEGF, YAG Hiyaloidotomi ve Pnömatik Deplasman",
        cards=[
            {
                "card_title": "GÖZLEM VS DİREKT LAZER",
                "lead": "Fovea Dışı Lezyonlarda Bekle-Gör",
                "items": [
                    "Konservatif İzlem: Foveayı tehdit etmeyen hemorajilerde ilk tercih gözlemdir; kanama aylar içinde rezorbe olur [s.119].",
                    "Direkt Lazer: Anevrizma gövdesine düşük enerjili geniş spotlu (200-500 μm) hafif koagülasyon uygulanır.",
                    "Lazer Riski: Aşırı güç anevrizma duvarını patlatarak masif taze vitreus kanamasına yol açabilir.",
                    "İndirekt Lazer: Anevrizmanın etrafındaki sızıntı alanına dairesel koruyucu spotlar dizilmesi daha güvenlidir."
                ],
                "footer": "Fovea Dışı: Gözlem | Lazerde Patlama Riskine Dikkat"
            },
            {
                "card_title": "ANTİ-VEGF ENJEKSİYONLARI",
                "lead": "Modern Farmakoterapötik Yaklaşım",
                "items": [
                    "Mekanizma: RAM primer anjiyogenik değildir ancak kanda VEGF seviyesi lokal eksüdasyonu artırır [s.119].",
                    "Ödem Kontrolü: İntravitreal anti-VEGF (Bevacizumab/Aflibercept) foveal ödemi ve eksüdasyonu hızla kurutur.",
                    "Damar Büzüşmesi: Anevrizma lümenini daraltarak spontan trombozu kolaylaştırır.",
                    "Güvenlik: Lazere bağlı yırtılma ve skar riski taşımadığı için günümüzde foveaya yakın RAM'lerde ilk tercihtir."
                ],
                "footer": "Foveaya Yakın Lezyonda Güvenli Anti-VEGF"
            },
            {
                "card_title": "SUBRETİNAL KANAMA DEPLASMANI",
                "lead": "Pnömatik Deplasman ve tPA",
                "items": [
                    "Subfoveal Masif Kanama: Fovea altında kalın kan tabakası 7-10 günde fotoreseptörleri demir toksisitesiyle öldürür [s.120].",
                    "Pnömatik Deplasman: İntravitreal gaz (C3F8 veya SF6) enjeksiyonu + hastaya yüzüstü pozisyon verdirilmesi.",
                    "Subretinal tPA: Kan pıhtısını eritmek için intravitreal/subretinal tPA ile kombine edilir.",
                    "YAG Hiyaloidotomi: Makulayı örten kalın subhyaloid kanama varlığında Nd:YAG lazerle hyaloid delinerek kan vitreusa akıtılır."
                ],
                "footer": "Gaz Deplasmanı + YAG Hiyaloidotomi"
            }
        ]
    )

    # Slayt 3.3.1.5: Coats Hastalığı Patofizyolojisi ve Evreleme
    builder.add_study_card_slide(
        title="COATS HASTALIĞI PATOLOJİSİ VE KLİNİK EVRELERİ",
        category="BÖLÜM 3.3.1: COATS HASTALIĞI",
        subtitle="İdiyopatik Telanjiektaziler, Masif Lipid Eksüdasyonu, Genç Erkek Tercihi ve Sigelman Sınıflaması",
        cards=[
            {
                "card_title": "ETYOLOJİ VE KLİNİK PROFİL",
                "lead": "Tek Taraflı Genç Erkek Hastalığı",
                "items": [
                    "Demografi: Olguların %85'i erkektir; ortalama tanı yaşı 5 - 10 yaş arasındadır [s.120].",
                    "Tek Taraflılık: %95 oranında tek taraflıdır; bilateral vakalarda genetik sendromlar (FACS vb.) aranır.",
                    "Kalıtımsızdır: Ailesel geçiş göstermez; somatik NDP geni mutasyonları suçlanmaktadır.",
                    "Başvuru Bulgusu: Çocukta strabismus (şaşılık) veya sarımsı lökokori (pupilde sarı-beyaz parıltı) ile fark edilir."
                ],
                "footer": "%85 Erkek Çocuk / %95 Tek Taraflı / Lökokori"
            },
            {
                "card_title": "MİKROVASKÜLER PATOLOJİ",
                "lead": "Işık Ampulü (Light-Bulb) Telanjiektazileri",
                "items": [
                    "Primer Kusur: Retinal kapiller endotelinin perisitlerini kaybetmesi ve dev anevrizmal dilatasyonlar [s.121].",
                    "Işık Ampulü Görünümü: Temporal periferde ampul gibi parlayan devasa vasküler ektaziler.",
                    "Masif Eksüdasyon: Plazma proteinleri ve kolesterol kristalleri kontrolsüz sızarak makulaya göllenir.",
                    "Lipid Makulopatisi: Foveada santral kütle oluşturan devasa sarı lipid plakları ve subretinal kolesterol kristalleri."
                ],
                "footer": "Işık Ampulü Telanjiektazi + Masif Lipid"
            },
            {
                "card_title": "SİGELMAN / SHIELDS EVRELEMESİ",
                "lead": "Evre 1'den Evre 5 Terminal Glokoma",
                "items": [
                    "Evre 1: Yalnızca periferik retinal telanjiektaziler (eksüdasyon henüz yoktur) [s.121].",
                    "Evre 2: Telanjiektaziler + Eksüdasyon (2A: Ekstramakuler eksüda / 2B: Foveal masif lipid).",
                    "Evre 3: Eksüdatif Retina Dekolmanı (3A: Subtotal dekolman / 3B: Total büllöz dekolman).",
                    "Evre 4: Total retina dekolmanı + İkincil Neovasküler Glokom (ağrılı göz).",
                    "Evre 5: Görmesi olmayan, fitizis bulbili veya kalsifiye son dönem göz."
                ],
                "footer": "Evre 1 (Telanjiektazi) -> Evre 3 (RD) -> Evre 5 (Fitizis)"
            }
        ]
    )

    # Slayt 3.3.1.6: Atlas Görseli: Coats ve RAM Fundus Atlası
    img_p118 = builder.get_image_for_page(118)
    builder.add_atlas_image_slide(
        title="COATS HASTALIĞI VE RETİNAL MAKROANEVRİZMA ATLASI",
        category="BÖLÜM 3.3.1: GÖRSEL ATLAS",
        subtitle="Makulada Masif Sarı Lipid Eksüdasyonu, Işık Ampulü Damarlar ve RAM Kanaması",
        image_path=img_p118 or "dr_schema_3",
        caption="Referans Eser Sayfa 118: Coats Hastalığında Makulayı Dolduran Devasa Kolesterol Plakları ve Periferik Telanjiektazi",
        key_findings=[
            "Masif Lipid Birikimi: Makulada santral görmeyi yok eden sarı-yeşil parlak kolesterol ve fibrin kitlesi [s.118].",
            "Işık Ampulü Ektazileri: Periferik vasküler arkad boyunca ampul gibi dizilmiş saküler damar yumakları.",
            "Eksüdatif Sıvı Dalgası: Ağır vakalarda alt retinayı kubbe gibi kaldıran berrak seröz dekolman.",
            "Normal Karşı Göz: Diğer gözün fundusu tamamen sağlıklı ve avasküler periferden uzaktır."
        ],
        differentials=[
            "Retinoblastom: Çocukta lökokorinin 1 numaralı ölümcül nedeni; USG'de yoğun kalsifikasyon içerir.",
            "Prematüre Retinopatisi (ROP): Prematüre öyküsü ve bilateral tutulum vardır; Coats tek taraflıdır.",
            "Persistan Fetal Vaskülatür (PFV): Mikroftalmi ve lense yapışık retrolental kıkırdaksı kordon izlenir."
        ],
        clinical_pearl="Çocukta sarı lökokori görüldüğünde USG ve BT'de KALSİFİKASYON YOKLUĞU Coats hastalığını destekler; kalsifikasyon varlığı aksi kanıtlanana kadar Retinoblastomdur [s.121]."
    )

    # Slayt 3.3.1.7: Karşılaştırmalı Analiz: Coats vs Retinoblastom Ayrımı
    builder.add_split_comparison_slide(
        title="HAYATİ AYIRICI TANI: COATS HASTALIĞI VS RETİNOBLASTOM",
        category="BÖLÜM 3.3.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Çocukluk Çağı Lökokorisinde Yanlış Tanıyı ve Hayati Riskleri Önleme Rehberi",
        left_entity={
            "name": "COATS HASTALIĞI (BENİGN VASKÜLER)",
            "features": [
                ("Demografi", "Ortalama yaş 5-10 yaş; %85 erkek çocuk; kesinlikle tek taraflı [s.121]."),
                ("Lökokori Rengi", "Tipik olarak sarımsı-altın (xanthocoria); masif subretinal lipidden kaynaklanır."),
                ("Kalsifikasyon", "Ultrasonografi ve BT'de kalsifikasyon KESİNLİKLE YOKTUR."),
                ("Göz Boyutu", "Göz küresi boyutu (aksiyel uzunluk) tamamen normaldir."),
                ("Retina Damarları", "Periferde 'ışık ampulü' telanjiektazileri ve anevrizmalar çıplaktır."),
                ("Hayatta Kalım", "Benign vasküler hastalıktır; metastaz veya ölüm riski yoktur.")
            ]
        },
        right_entity={
            "name": "RETİNOBLASTOM (ÖLÜMCÜL TÜMÖR)",
            "features": [
                ("Demografi", "Ortalama yaş 1-2 yaş (bebeklik); kız/erkek eşit; %30-40 bilateral (herediter)."),
                ("Lökokori Rengi", "Tebeşir beyazı, pembe-gri renkli tümör kitlesi yansıması."),
                ("Kalsifikasyon", "USG ve BT'de patognomonik YOĞUN KALSİFİKASYON ve akustik gölge (%95)."),
                ("Göz Boyutu", "Göz küresi boyutu normaldir (mikroftalmi yoktur)."),
                ("Retina Damarları", "Tümör kitlesini besleyen ve içine dalan anormal tümöral damarlar."),
                ("Hayatta Kalım", "Malign nöroblastik tümördür; acil tedavi edilmezse optik sinirle beyne yayılır ve öldürür.")
            ]
        },
        bottom_takeaway="Lökokorili çocukta USG'de intraoküler kalsifikasyon saptanırsa, tanı aksi kanıtlanana dek Retinoblastomdur; asla biyopsi yapılmaz, derhal oküler onkolojiye sevk edilir [s.122]."
    )

    # Slayt 3.3.1.8: Coats Hastalığı Tedavi Basamakları
    builder.add_horizontal_flowchart_slide(
        title="COATS HASTALIĞI TEDAVİ VE GÖZ KURTARMA KASKADI",
        category="BÖLÜM 3.3.1: AKIŞ ŞEMASI",
        subtitle="Evreye Göre Lazer, Kriyoterapi, Anti-VEGF ve Cerrahi Drenaj Protokolü",
        steps=[
            {
                "num": "1",
                "title": "Ablatif Lazer",
                "desc": "Evre 1 ve 2A: Telanjiektazik damarlara direkt ve çevreleyen dokuya 532 nm yeşil lazer [s.121].",
                "status": "success"
            },
            {
                "num": "2",
                "title": "Kriyoterapi",
                "desc": "Uzak periferik lezyonlarda veya hafif sıvı altında lazere ulaşılamayan alanlara transskleral çift dondurma.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Anti-VEGF Desteği",
                "desc": "Masif eksüda ve ödemi kurutmak için ablasyonla kombine intravitreal Ranibizumab/Aflibercept.",
                "status": "info"
            },
            {
                "num": "4",
                "title": "Subretinal Sıvı Drenajı",
                "desc": "Evre 3B: Büllöz dekolmanda ablasyon yapılamaz; transskleral iğne ile sıvı boşaltılıp retina yatıştırılır.",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Enükleasyon (Son Çare)",
                "desc": "Evre 4-5: Ağrılı neovasküler glokom, fitizis veya retinoblastom şüphesinin ekarte edilemediği gözler.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Coats hastalığında periferik telanjiektaziler lazer veya kriyoterapi ile kapatıldığında, makuladaki masif kolesterol eksüdasyonu aylar içinde kendi kendine emilerek temizlenir [s.122]."
    )

    # =========================================================================
    # KONU 3.3.2: PREMATÜRE RETİNOPATİSİ (ROP - ICROP 3) (8 SLAYT)
    # =========================================================================
    # Slayt 3.3.2.1: ROP Patogenezi ve İki Fazlı Hipotez
    builder.add_study_card_slide(
        title="PREMATÜRE RETİNOPATİSİ (ROP) İKİ FAZLI PATOGENEZİ",
        category="BÖLÜM 3.3.2: PREMATÜRE RETİNOPATİSİ",
        subtitle="Vaskülogenez, Anjiyogenez, Hiperoksik Damar Durması (Faz 1) ve Hipoksik Proliferasyon (Faz 2)",
        cards=[
            {
                "card_title": "NORMAL RETİNAL VASKÜLARİZASYON",
                "lead": "Optik Diskten Ora Serrataya Büyüme",
                "items": [
                    "Başlangıç: Gebeliğin 16. haftasında mezenkimal kök hücreler optik diskten çevreye doğru göç eder [s.122].",
                    "Nazal Tamamlanma: Nazal retina vaskülarizasyonu gebeliğin 36. haftasında ora serrataya ulaşır.",
                    "Temporal Tamamlanma: Fovea temporalde kaldığı için temporal perifer ancak termde (40. hafta) tamamlanır.",
                    "Prematüre Riski: Erken doğan bebekte temporal perifer avasküler ve iskemiye açık kalır."
                ],
                "footer": "Nazal: 36. Hafta | Temporal: 40. Hafta"
            },
            {
                "card_title": "FAZ 1: HİPEROKSİK GERİLEME",
                "lead": "Doğumdan 30-32. Haftaya Kadar",
                "items": [
                    "Rahim İçi Hipoksi: İntrauterin ortam fizyolojik olarak hipoksiktir (pO2: 25-30 mmHg) [s.123].",
                    "Kuvöz Hiperoksisi: Prematüre bebek doğup ek oksijen aldığında retinal pO2 aniden fırlar.",
                    "VEGF Baskılanması: Yüksek oksijen retinal VEGF üretimini tamamen durdurur.",
                    "Damar Büzüşmesi ve Ölümü: Filizlenen narin kapillerler büzüşür ve apoptoza gider (vazoobliterasyon)."
                ],
                "footer": "Hiperoksi -> VEGF Sıfırlanır -> Damar Durması"
            },
            {
                "card_title": "FAZ 2: HİPOKSİK PROLİFERASYON",
                "lead": "32-34. Gebelik Haftasından Sonra",
                "items": [
                    "Metabolik Talep Artışı: Bebeğin gözü büyüdükçe avasküler periferik retinanın oksijen talebi patlar [s.123].",
                    "Göreceli İskemi: Ortam oksijeni azaldığında avasküler doku şiddetli hipoksiye girer.",
                    "VEGF ve Eritropoetin Fırtınası: Hipoksik retina aşırı miktarda VEGF ve EPO salgılar.",
                    "Patolojik Neovaskülarizasyon: Perfüze retina sınırında retinayı terk eden kırılgan damarlar filizlenir."
                ],
                "footer": "Hipoksi -> Aşırı VEGF -> Neovaskülarizasyon"
            }
        ]
    )

    # Slayt 3.3.2.2: Tarama Kriterleri ve Muayene Zamanlaması
    builder.add_study_card_slide(
        title="ROP TARAMA PROTOKOLÜ VE ZAMANLAMA STANDARTLARI",
        category="BÖLÜM 3.3.2: PREMATÜRE RETİNOPATİSİ",
        subtitle="Türkiye ve Uluslararası Kriterler, İlk Muayene Zamanı ve Pupil Dilatasyonu",
        cards=[
            {
                "card_title": "TÜRKİYE ROP TARAMA KRİTERLERİ",
                "lead": "Sağlık Bakanlığı Ulusal Konsensusu",
                "items": [
                    "Kriter 1: Doğum ağırlığı ≤1500 gram olan tüm prematüre bebekler [s.123].",
                    "Kriter 2: Gebelik haftası ≤32 hafta olan tüm prematüre bebekler.",
                    "Kriter 3 (Riskli Bebekler): >32 hafta veya >1500 gram olup kardiyopulmoner destek alan, sepsis geçiren, kan transfüzyonu yapılan riskli bebekler.",
                    "Tarama Sorumluluğu: Yenidoğan yoğun bakım (YYBÜ) uzmanı ile göz hastalıkları uzmanı ortak sorumludur."
                ],
                "footer": "≤32 Hafta VEYA ≤1500 Gram"
            },
            {
                "card_title": "İLK MUAYENE ZAMANLAMASI",
                "lead": "Postmenstrüel 31. Hafta Kuralı",
                "items": [
                    "Kural: Postmenstrüel yaş (PMA) ile kronolojik yaşın kombinasyonu kullanılır [s.123].",
                    "Erken Doğanlar (<27 Hafta): Kronolojik 4. haftadan önce taranmaz; PMA 31. haftada ilk muayene yapılır.",
                    "Geç Doğanlar (≥27 Hafta): Doğumdan sonraki kronolojik 4. haftada ilk muayene yapılır.",
                    "Altın Prensip: Bebek ne kadar erken doğarsa doğsun, ilk tarama postmenstrüel 31. haftadan önce yapılmaz."
                ],
                "footer": "PMA 31. Hafta VEYA Doğum Sonrası 4. Hafta"
            },
            {
                "card_title": "MUAYENE HAZIRLIĞI VE GÜVENLİK",
                "lead": "Pupil Dilatasyonu ve Monitorizasyon",
                "items": [
                    "Dilatasyon Damlası: %0.5 Siklopentolat + %2.5 Fenilefrin (veya %0.5 Tropikamid) 10 dk arayla 2-3 kez [s.124].",
                    "Sistemik Yan Etki Riski: %10'luk fenilefrin KESİNLİKLE YASAKTIR (ölümcül hipertansiyon yapabilir).",
                    "Okülokardiyak Refleks: Göz kapak spekulumu (blefarostat) ve indentör basısı bradikardi ve apne tetikleyebilir.",
                    "Monitörizasyon: Muayene sırasında bebeğin kalp atımı ve oksijen satürasyonu sürekli izlenmelidir."
                ],
                "footer": "%2.5 Fenilefrin Güvenli / Monitorizasyon Şart"
            }
        ]
    )

    # Slayt 3.3.2.3: ICROP-3 Zon ve Evreleme Sistemi
    builder.add_study_card_slide(
        title="ICROP-3 ULUSLARARASI ROP SINIFLAMASI: ZONLAR VE EVRELER",
        category="BÖLÜM 3.3.2: PREMATÜRE RETİNOPATİSİ",
        subtitle="3 Konsantrik Zon, Posterior Zon II Tanımı ve Evre 1'den Evre 5'e Anatomik Basamaklar",
        cards=[
            {
                "card_title": "3 ANATOMİK ZON (ZONES)",
                "lead": "Optik Disk Merkezli Daireler",
                "items": [
                    "Zon I: Optik disk merkezli, disk-fovea mesafesinin 2 katı yarıçaplı iç dairedir (en tehlikeli zon) [s.124].",
                    "Zon II: Zon I sınırından nazal ora serrataya kadar uzanan konsantrik halkadır.",
                    "Posterior Zon II (ICROP-3 Yeniliği): Zon I sınırından sonraki 2 disk çaplık yüksek riskli geçiş kuşağı.",
                    "Zon III: Nazal retina damarlandıktan sonra yalnızca temporal periferde kalan hilal biçimli avasküler artık."
                ],
                "footer": "Zon I (Santral) -> Zon II -> Zon III (Perifer)"
            },
            {
                "card_title": "EVRE 1, 2 VE 3 (PROLİFERASYON)",
                "lead": "Çizgiden Sırt ve Fibrovasküler Dokuya",
                "items": [
                    "Evre 1 (Demarkasyon Hattı): Vasküler ve avasküler retina arasında ince, beyaz, düz yapısal sınır çizgisi [s.124].",
                    "Evre 2 (Sırt / Ridge): Demarkasyon çizgisinin üç boyutlu kabararak pembe-beyaz bir sedde dönüşmesi.",
                    "Evre 3 (Ekstraretinal Proliferasyon): Sırt üzerinden vitreus içine doğru büyüyen patolojik neovasküler püsküller.",
                    "Popcorn Regresyonu: Sırt üzerinde izole küçük neovasküler adacıklar."
                ],
                "footer": "Evre 1 (Hat) -> Evre 2 (Sırt) -> Evre 3 (Vitreus Damarı)"
            },
            {
                "card_title": "EVRE 4 VE 5 (RETİNA DEKOLMANI)",
                "lead": "Subtotal ve Total Traksiyonel Dekolman",
                "items": [
                    "Evre 4A: Foveayı İÇERMEYEN ekstramakuler traksiyonel retina dekolmanı [s.125].",
                    "Evre 4B: Foveayı İÇEREN subtotal traksiyonel retina dekolmanı (cerrahi acil).",
                    "Evre 5: Total huni biçimli retina dekolmanı (5A: Açık huni / 5B: Dar huni / 5C: Kapalı ön ve arka huni).",
                    "Görsel Felaket: Evre 5'e ulaşan gözlerde cerrahiye rağmen faydalı görme şansı son derece düşüktür."
                ],
                "footer": "4A (Fovea Korunmuş) / 4B (Fovea Tutulmuş) / 5 (Total)"
            }
        ]
    )

    # Slayt 3.3.2.4: Plus ve Pre-Plus Hastalık Biyobelirteçleri
    builder.add_study_card_slide(
        title="PLUS VE PRE-PLUS HASTALIK: HEMODİNAMİK ALARM",
        category="BÖLÜM 3.3.2: PREMATÜRE RETİNOPATİSİ",
        subtitle="Arka Kutup Arteriyoler Kıvrıntılanma (Tortuosity) ve Venöz Genişleme (Dilatation)",
        cards=[
            {
                "card_title": "PLUS HASTALIK TANIMI",
                "lead": "Arka Kutupta Şiddetli Vasküler Engorjman",
                "items": [
                    "Tanım: Arka kutuptaki en az 2 kadranda arteriollerde belirgin kıvrıntılanma VE venüllerde dilatasyon olmasıdır [s.125].",
                    "Standart Fotoğraf: ICROP konsensus fotoğrafından daha şiddetli damar dolgunluğu aranır.",
                    "Hemodinamik Anlamı: Göz içinde muazzam miktarda anjiyojenik faktör (VEGF) biriktiğini kanıtlar.",
                    "Kritik Rol: Plus hastalık varlığı evreyi anında 'tedavi gerektiren' yüksek riskli kategoriye fırlar."
                ],
                "footer": "≥2 Kadranda Tortuozite + Dilatasyon"
            },
            {
                "card_title": "PRE-PLUS HASTALIK",
                "lead": "Normal ile Plus Arasındaki Gri Kuşak",
                "items": [
                    "Tanım: Damarlar normalden daha dolgun ve kıvrıntılıdır ancak tam Plus kriterlerini doldurmaz [s.125].",
                    "Erken Uyarı: Pre-plus saptanan bir bebek gün içinde hızla tam Plus hastalığa ilerleyebilir.",
                    "Takip Sıklığı: Muayene aralığı derhal haftada bire (bazen 3-4 günde bire) indirilmelidir.",
                    "Tedavi: Pre-plus tek başına lazer endikasyonu değildir; ancak alarm durumudur."
                ],
                "footer": "Pre-Plus = Yakın Takip Alarmı"
            },
            {
                "card_title": "ÖN SEGMENT PLUS BELİRTİLERİ",
                "lead": "İris Damarları ve Rijit Pupil",
                "items": [
                    "İris Damar Engorjmanı: İris yüzeyindeki damarların belirginleşmesi ve kıvrıntılanması [s.125].",
                    "Tunica Vasculosa Lentis Kalıntısı: Lens kapsülü üzerindeki embriyolojik damarların açık kalması.",
                    "Zayıf Pupil Dilatasyonu: İris sfinkter iskemisi nedeniyle pupillanın damlalarla genişlememesi (rijit pupil).",
                    "Bulanık Kornea: Ön kamara sığlaşması ve endotel dekompansasyonu."
                ],
                "footer": "İris Damarlanması & Dilate Olmayan Pupil"
            }
        ]
    )

    # Slayt 3.3.2.5: Tip 1 ROP ve Erken Tedavi Kriterleri (ETROP)
    builder.add_study_card_slide(
        title="ETROP ÇALIŞMASI VE TİP 1 ROP TEDAVİ KRİTERLERİ",
        category="BÖLÜM 3.3.2: PREMATÜRE RETİNOPATİSİ",
        subtitle="Erken Tedavi Gerektiren Eşik Kriterleri vs Yakın Takip Edilecek Tip 2 ROP",
        cards=[
            {
                "card_title": "TİP 1 ROP (ACİL TEDAVİ ŞART)",
                "lead": "72 Saat İçinde Müdahale Edilmeli",
                "items": [
                    "Kriter 1: Zon I, Herhangi bir Evre + PLUS Hastalık [s.125].",
                    "Kriter 2: Zon I, Evre 3 (Plus olmasa dahi acil tedavi gerektirir!).",
                    "Kriter 3: Zon II, Evre 2 veya 3 + PLUS Hastalık.",
                    "Zaman Penceresi: Tip 1 ROP tanısı konulduğu andan itibaren en geç 72 SAAT içinde tedavi uygulanmalıdır."
                ],
                "footer": "Tip 1 ROP = 72 Saat İçinde Lazer/Anti-VEGF"
            },
            {
                "card_title": "TİP 2 ROP (YAKIN GÖZLEM)",
                "lead": "Haftalık Sıkı Takip Kriteri",
                "items": [
                    "Kriter 1: Zon I, Evre 1 veya 2 (Plus Hastalık YOK) [s.126].",
                    "Kriter 2: Zon II, Evre 3 (Plus Hastalık YOK).",
                    "Tedavi: Acil tedavi gerekmez; ancak 3 - 7 gün arayla muayene tekrarlanmalıdır.",
                    "Progresyon Riski: Tip 2 ROP olgularının yaklaşık %40-50'si Tip 1'e ilerleyerek tedaviye girer."
                ],
                "footer": "Tip 2 ROP = 3-7 Günde Bir Muayene"
            },
            {
                "card_title": "AGGRESSIVE ROP (A-ROP)",
                "lead": "Eski AP-ROP / Yıldırım Seyirli Form",
                "items": [
                    "ICROP-3 Tanımı: Klasik evreleri (1-2-3) beklemeden hızla dekolmana ilerleyen ağır atipik form [s.126].",
                    "Belirteçler: Aşırı şiddetli Plus hastalık, intraretinal şantlar, 360 derece avasküler Zon I tutulumu.",
                    "Genellikle Çok Küçük Bebekler: <26 hafta ve <750 gram bebeklerde sık görülür.",
                    "Acil Tedavi: 24-48 saat içinde anti-VEGF enjeksiyonu ilk basamak hayat kurtarıcı tercihtir."
                ],
                "footer": "A-ROP = Evresiz Hızlı Şiddetli Progresyon"
            }
        ]
    )

    # Slayt 3.3.2.6: Atlas Görseli: ROP Zonları, Sırt ve Plus Hastalık
    img_p124 = builder.get_image_for_page(124)
    builder.add_atlas_image_slide(
        title="PREMATÜRE RETİNOPATİSİ (ROP) RETCAM VE FUNDUS ATLASI",
        category="BÖLÜM 3.3.2: GÖRSEL ATLAS",
        subtitle="Zon I Demarkasyonu, Evre 3 Sırt Neovaskülarizasyonu ve Şiddetli Plus Hastalık",
        image_path=img_p124 or "dr_schema_5",
        caption="Referans Eser Sayfa 124: RetCam Geniş Açılı Görüntüde Zon II Evre 3 Plus ROP Tablosu",
        key_findings=[
            "Geniş Avasküler Perifer: Temporal retinada damarsız, soluk grimsi avasküler retina sahası [s.124].",
            "Evre 3 Sırt Dokusu: Vasküler sınırda vitreus içine kabarmış parlak kırmızı neovasküler sed.",
            "Plus Hastalık: Optik disk çevresindeki arteriollerin aşırı yılankavi (tortuoz) ve venlerin genişlemiş görünümü.",
            "İntraretinal Kanamalar: Sırt boyunca ve fovea çevresinde dağınık stres kanamaları."
        ],
        differentials=[
            "FEVR (Ailesel Eksüdatif Vitreoretinopati): Term doğum öyküsü ve otozomal dominant aile hikayesi.",
            "İnkontinensiya Pigmenti: Kız bebeklerde cilt lezyonları ile birlikte periferik avasküler retina.",
            "Coats Hastalığı: Tek taraflıdır, prematüre öyküsü yoktur, masif kolesterol eksüdasyonu içerir."
        ],
        clinical_pearl="Zon I Evre 3 ROP'ta 'Plus hastalık henüz yok' diye tedavi ertelenemez; Zon I Evre 3 tek başına Tip 1 ROP'tur ve 72 saat içinde tedavi şarttır [s.125]."
    )

    # Slayt 3.3.2.7: Lazer Fotokoagülasyon vs İntravitreal Anti-VEGF
    builder.add_split_comparison_slide(
        title="ROP TEDAVİ MODALİTELERİ: LAZER VS ANTİ-VEGF",
        category="BÖLÜM 3.3.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="BEAT-ROP ve RAINBOW Çalışmaları Kanıtları Eşliğinde İki Yöntemin Kıyaslanması",
        left_entity={
            "name": "DİYOT LAZER FOTOKOAGÜLASYON",
            "features": [
                ("Etki Mekanizması", "Avasküler retinanın tamamını yakarak VEGF fabrikasını kalıcı söndürür [s.126]."),
                ("Nüks Riski", "Nüks riski çok düşüktür; avasküler doku kalmadığı için tedavi tek seferde biter."),
                ("Görsel Alan & Kırma Kusuru", "Periferik görme alanı kalıcı kaybedilir; yüksek miyopi (-6 ila -10 D) gelişir."),
                ("Genel Anestezi", "Uzun sürer (1-2 saat); entübe bebekte genel anestezi gerektirir."),
                ("İdeal Alan", "Zon II hastalıklarında altın standarttır.")
            ]
        },
        right_entity={
            "name": "İNTRAVİTREAL ANTİ-VEGF (RANİBİZUMAB)",
            "features": [
                ("Etki Mekanizması", "Göz içi VEGF'i nötralize eder; damarların normal periferik büyümesini sürdürür [s.126]."),
                ("Nüks Riski", "GEÇ NÜKS RİSKİ: 8-16 hafta sonra damarlanma durup tekrar alevlenebilir; PMA 60'a dek takip şarttır!"),
                ("Görsel Alan & Kırma Kusuru", "Periferik retina damarlanır; miyopi riski son derece düşüktür."),
                ("Uygulama Kolaylığı", "Yatak başında topikal anesteziyle saniyeler içinde uygulanır."),
                ("İdeal Alan", "Zon I ve Aggressive ROP (A-ROP) vakalarında tartışmasız ilk tercihtir.")
            ]
        },
        bottom_takeaway="Anti-VEGF yapılan prematüre bebekler lazer yapılanlara göre çok daha uzun süre (en az postmenstrüel 60-70. haftaya kadar) periferik nüks açısından düzenli muayene edilmelidir [s.126]."
    )

    # Slayt 3.3.2.8: Akış Şeması: ICROP-3 Triyaj ve Tedavi Protokolü
    builder.add_horizontal_flowchart_slide(
        title="PREMATÜRE RETİNOPATİSİ (ROP) KLİNİK KARAR VE TAKİP ŞEMASI",
        category="BÖLÜM 3.3.2: AKIŞ ŞEMASI",
        subtitle="Doğumdan Taramaya, Tip 1 Kararına ve Lazer/Anti-VEGF Müdahalesine",
        steps=[
            {
                "num": "1",
                "title": "Doğum & Tarama Kararı",
                "desc": "≤32 hafta veya ≤1500 gr bebek -> Postmenstrüel 31. haftada ilk indirekt oftalmoskopi [s.123].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Avasküler Perifer",
                "desc": "Retinopati yoksa 2-3 haftada bir; Zon I'de ise 1-2 haftada bir takip.",
                "status": "info"
            },
            {
                "num": "3",
                "title": "Tip 2 ROP Gelişimi",
                "desc": "Zon I Evre 1-2 veya Zon II Evre 3 (Plus yok) -> Haftalık sıkı gözlem kaskadı.",
                "status": "warning"
            },
            {
                "num": "4",
                "title": "Tip 1 ROP / A-ROP",
                "desc": "Zon I Evre 3 VEYA Plus hastalık belirdi -> En geç 72 saat içinde acil tedavi kararı.",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Tedavi Seçimi",
                "desc": "Zon I veya A-ROP ise İntravitreal Anti-VEGF (Ranibizumab 0.2 mg); Zon II ise Diyot Lazer.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Bebekte retinal damarlar ora serrataya tam ulaştığında (temporal vaskülarizasyon tamamlandığında) ROP taraması güvenle sonlandırılır [s.126]."
    )

    print(f" -> Bölüm 3 (Retinal Vasküler Hastalıklar) Tamamlandı: 56 Slayt Eklendi.")
