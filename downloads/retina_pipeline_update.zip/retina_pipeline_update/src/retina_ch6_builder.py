# -*- coding: utf-8 -*-
r"""
retina_ch6_builder.py — Bölüm 6: Kalıtsal Retinal ve Koroidal Distrofiler (39 Slayt)
==================================================================================
Kitap Sayfaları: 178 – 200
Alt Başlıklar:
  6.0   Bölüm 6 Çalışma Yol Haritası (1 slayt)
  6.1.1 Retinitis Pigmentosa (RP) ve İlişkili Sendromlar (Usher, Bardet-Biedl) (8 slayt)
  6.1.2 Koni ve Koni-Çomak Distrofileri (6 slayt)
  6.1.3 Stargardt Hastalığı (ABCA4), Best Vitelliform Makula Distrofisi ve Pattern Distrofiler (8 slayt)
  6.2.1 Koroideremi, Jirat Atrofi, Stickler Sendromu, FEVR ve X'e Bağlı Retinoskizis (8 slayt)
  6.2.2 Retinal Gen Tedavileri: Luxturna (RPE65), Voretigene Neparvovec ve Devam Eden Fazlar (8 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_6(builder: RetinaStudyDeckBuilder):
    """Bölüm 6'ya ait 39 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 6 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=6,
        title="KALITSAL RETİNAL VE KOROİDAL DİSTROFİLER",
        page_range="Sayfa 178 – 200",
        subtitle="RP, Koni Distrofileri, Stargardt, Best, Vitreoretinopatiler ve Luxturna Gen Tedavisi",
        cards=[
            {
                "title": "1. Retinitis Pigmentosa & Sendromlar",
                "color": PPTXPalette.BLUE,
                "lead": "Çomak-Koni Disfonksiyonu",
                "items": [
                    "Klinik Triad: Periferik kemik spikülü pigmentasyonu, arteriyoler incelme, mumsu disk solukluğu.",
                    "Semptom Sırası: Niktalopi (gece körlüğü) -> Halka skotom -> Tünel görme -> Makula tutulumu.",
                    "Sistemik Birliktelikler: Usher sendromu (sensörinöral işitme kaybı), Bardet-Biedl (polidaktili, obezite).",
                    "Elektrofizyoloji: Skotopik rod yanıtları tamamen silinmiştir; FAF'ta hiperotofloresan Robson halkası."
                ],
                "footer": "Niktalopi -> Kemik Spikülü -> Tünel Görme"
            },
            {
                "title": "2. Makuler Distrofiler",
                "color": PPTXPalette.AMBER,
                "lead": "ABCA4 & BEST1 Yolağı",
                "items": [
                    "Stargardt (ABCA4): Lipofuksin birikimi, balık pulu (pisciform) lekeler; FFA'da 'karanlık koroid' patognomonik.",
                    "Stargardt Uyarısı: A vitamini takviyesi lipofuksin toksisitesini (A2E) hızlandırdığı için KESİNLİKLE YASAKTIR.",
                    "Best Hastalığı (BEST1): EOG Arden oranı <1.5 anormal; ERG normal; sahanda yumurta görünümü.",
                    "Pattern Distrofiler: PRPH2 mutasyonu; erişkinde başlar; benign seyir gösterir; normal EOG/ERG."
                ],
                "footer": "Stargardt (A Vitamini Yasak) / Best (EOG <1.5)"
            },
            {
                "title": "3. Koroid & Vitreoretinopatiler",
                "color": PPTXPalette.RED,
                "lead": "Koroideremi, Jirat, Stickler & XLRS",
                "items": [
                    "Koroideremi (CHM): X'e bağlı geçiş; sklera görünür hale gelir; foveal ada en son korunur.",
                    "Jirat (Gyrate) Atrofi (OAT): Hiperornitinemi; çelenk şeklinde atrofi; argininsiz diyet + B6 vitamini.",
                    "Stickler Sendromu: Tip 2 kollajen defekti; optik boş vitreus; dev yırtık ve RRD riski çok yüksektir.",
                    "X'e Bağlı Retinoskizis (RS1): Foveal tekerlek (spoke-wheel); ERG'de 'negatif dalga' (b/a oranı <1)."
                ],
                "footer": "Jirat (Argininsiz Diyet) / XLRS (Negatif ERG)"
            },
            {
                "title": "4. Retinal Gen Terapisi (Luxturna)",
                "color": PPTXPalette.GREEN,
                "lead": "Voretigene Neparvovec & Fazlar",
                "items": [
                    "FDA Onaylı İlk Gen İlacı: Luxturna (AAV2 vektörü ile çift allelik RPE65 mutasyonlu LCA/RP tedavisi).",
                    "Temel Şart: Retinada yeterli sayıda canlı fotoreseptör hücresi (OKT'de elipsoid zon) bulunmalıdır.",
                    "Uygulama: 25G PPV sonrası subretinal enjeksiyonla bülle oluşturularak RPE içine gen aktarılır.",
                    "Gelecek Perspektifler: XLRP (RPGR), Stargardt ve Koroideremi gen faz çalışmaları hızla sürmektedir."
                ],
                "footer": "RPE65 -> AAV2 Subretinal Bülle -> Luxturna"
            }
        ]
    )

    # =========================================================================
    # 6.1.1: RETİNİTİS PİGMENTOSA (RP) VE İLİŞKİLİ SENDROMLAR (8 Slayt)
    # =========================================================================

    # Slayt 6.1.1.1: RP Genetik Heterojenitesi & Kalıtım Modelleri
    builder.add_study_card_slide(
        title="RETİNİTİS PİGMENTOSA (RP) GENETİK MİMARİSİ",
        category="BÖLÜM 6.1.1: GENETİK",
        subtitle="Otozomal Dominant, Resesif ve X'e Bağlı Kalıtım Modelleri ve Klinik Ağırlık",
        cards=[
            {
                "card_title": "1. Otozomal Dominant RP (adRP)",
                "lead": "%30-40 Olguyu Oluşturur",
                "items": [
                    "En sık mutasyona uğrayan gen RHO (Rodopsin genidir, %25-30) [s.178].",
                    "Klinik seyir genellikle diğer kalıtım formlarına kıyasla en hafifidir.",
                    "Semptom başlangıcı 20-30'lu yaşlara sarkar; santral görme 60 yaşına kadar korunabilir.",
                    "Aile ağacında (pedigree) kuşak atlamaksızın dikey geçiş izlenir."
                ],
                "footer": "RHO Geni / En Hafif Klinik Seyir"
            },
            {
                "card_title": "2. Otozomal Resesif RP (arRP)",
                "lead": "%50-60 Olguyu Oluşturur (En Sık)",
                "items": [
                    "Akraba evliliklerinin sık olduğu toplumlarda (Türkiye dahil) en yaygın formdur [s.178].",
                    "Genetik olarak aşırı heterojendir (USH2A, PDE6A, PDE6B, RPE65 vb. 60'tan fazla gen).",
                    "Çocukluk çağında niktalopi ile başlar; ergenlikte belirgin görme alanı daralması gelişir.",
                    "Anne-baba taşıyıcıdır ancak fenotipik olarak sağlıklıdır; kardeşlerde %25 risk vardır."
                ],
                "footer": "Akraba Evliliği / USH2A / Erken Başlangıç"
            },
            {
                "card_title": "3. X'e Bağlı RP (xlRP)",
                "lead": "%10-15 (En Ağır ve Yıkıcı Form)",
                "items": [
                    "Sorumlu ana genler: RPGR (%70-80) ve RP2 (%10-20) [s.179].",
                    "Yalnızca erkeklerde görülür; kadınlar taşıyıcıdır (taşıyıcı kadında altın parıltılı refleks olabilir).",
                    "Klinik seyir en agresif olanıdır; hastalar 20-30 yaşlarında tünel görmeye ve legal körlüğe girer.",
                    "Erkek çocuktan erkek çocuğa geçiş yoktur (babadan oğula geçmez)."
                ],
                "footer": "RPGR Geni / En Ağır Seyir / Erken Körlük"
            }
        ]
    )

    # Slayt 6.1.1.2: Klasik RP Klinik Triadı ve Semptom Kaskadı
    builder.add_study_card_slide(
        title="KLASİK RP KLİNİK TRİADI VE DOĞAL SEYİR KASKADI",
        category="BÖLÜM 6.1.1: SEMPTOMATOLOJİ",
        subtitle="Gece Körlüğünden Tünel Görmeye ve Terminal Makula Tutulumuna İlerleme",
        cards=[
            {
                "card_title": "1. Birincil Semptom: Niktalopi",
                "lead": "Çomak (Rod) Hücrelerinin Erken Kaybı",
                "items": [
                    "Hastaların ilk ve evrensel şikayeti alacakaranlıkta veya loş ışıkta görememedir (niktalopi) [s.179].",
                    "Sinemada koltuğunu bulamama, gece araba kullanamama çocukluk/ergenlik çağında başlar.",
                    "Çomak fotoreseptörleri orta periferde yoğun olduğundan ilk hasar orta periferde halka skotomla başlar.",
                    "Gündüz görmesi ve renkli görme (foveal koniler) uzun yıllar boyunca 1.0 tam kalabilir."
                ],
                "footer": "İlk Semptom: Loş Işıkta Görememe"
            },
            {
                "card_title": "2. Klasik Oftalmoskopik Triad",
                "lead": "Tanı Koyduran Üç Temel Bulgu",
                "items": [
                    "1. Kemik Spikülü (Bone-Spicule) Pigmentasyonu: Ekvatoral periferde perivasküler pigment birikimi [s.179].",
                    "2. Retinal Damar İncelmesi (Arteriolar Attenuation): Retinal arteriollerde diffüz ipliksi daralma.",
                    "3. Mumsu Soluk Optik Disk (Waxy Pallor): Glial doku hiperplazisine bağlı sarı-mumsu disk görünümü.",
                    "Bu triad ekvatoral retinadan başlayıp yıllar içinde hem periferiye hem merkeze doğru ilerler."
                ],
                "footer": "Kemik Spikülleri + İnce Damar + Mumsu Disk"
            },
            {
                "card_title": "3. Görme Alanı Kaybı & Tünel Görme",
                "lead": "Santral 5-10 Dereceye Sıkışma",
                "items": [
                    "Orta periferdeki halka skotom zamanla genişleyerek dış periferi tamamen siler [s.180].",
                    "Hastada yalnızca santral foveal adayı kapsayan 5-10 derecelik tüp/tünel görme (tunnel vision) kalır.",
                    "Hasta iğne deliğinden bakar gibi görür; düz yolda yürürken engellere çarpar ancak gazete okuyabilir.",
                    "Terminal evrede foveal koniler de apoptoza uğradığında santral görme de tamamen kaybolur."
                ],
                "footer": "Halka Skotom -> Tünel Görme -> Foveal Kayıp"
            }
        ]
    )

    # Slayt 6.1.1.3: RP Elektrofizyolojisi (ERG) ve FAF Bulguları
    builder.add_study_card_slide(
        title="RP TANI YÖNTEMLERİ: ERG VE FUNDUS OTOFLORESANS",
        category="BÖLÜM 6.1.1: ELEKTROFİZYOLOJİ & FAF",
        subtitle="Erken Dönemde Düzleşen (Non-Recordable) Skotopik ERG ve Robson Hiperotofloresan Halkası",
        cards=[
            {
                "card_title": "1. Tam Alan (Full-Field) ERG",
                "lead": "Hastalığın En Erken ve Kesin Tanı Aracı",
                "items": [
                    "Fundusta henüz kemik spikülü görülmeyen erken evrede bile ERG tanı koydurur [s.180].",
                    "Skotopik (Karanlığa adapte) çomak yanıtı tamamen sönmüştür (extinguished / non-recordable).",
                    "Kombine maksimal yanıtta b-dalgası aşırı çökmüştür.",
                    "Fotopik (koni) yanıtlar erken evrede korunabilir ancak latansları uzamış ve amplitüdleri düşmüştür."
                ],
                "footer": "Skotopik Yanıt Silinmesi / Altın Standart"
            },
            {
                "card_title": "2. FAF: Robson Hiperotofloresan Halkası",
                "lead": "Aktif Fotoreseptör Yıkım Sınırı",
                "items": [
                    "Makula çevresinde foveayı çevreleyen parlak bir hiperotofloresan halka izlenir (Robson halkası) [s.180].",
                    "Bu halka, dış fotoreseptör segmentlerinin çöktüğü ve aşırı lipofuksin yüklenen RPE sınırını temsil eder.",
                    "Halkanın içi: Canlı ve çalışan fotoreseptörleri (korunmuş santral görme adası) gösterir.",
                    "Halkanın dışı: Kalıcı fotoreseptör atrofisi ve hipootofloresan skotom sahasıdır; halka yıllarla daralır."
                ],
                "footer": "Robson Halkası / Canlı Alan Sınırı"
            },
            {
                "card_title": "3. SD-OKT: Elipsoid Zon (EZ) Genişliği",
                "lead": "Hastalık Progresyonunun Takip Biyomarkeri",
                "items": [
                    "Fovea merkezinde elipsoid zon (fotoreseptör iç/dış segment bileşkesi) bandı korunmuştur [s.181].",
                    "Perifere doğru gidildikçe EZ bandı aniden kesintiye uğrar ve dış nükleer katman çöker.",
                    "Yıllık takiplerde korunmuş EZ genişliğinin mikron cinsinden kısalması objektif ilerleme hızı verir.",
                    "Gen tedavisi ve kök hücre klinik deneylerinde birincil yapısal sonlanım noktasıdır."
                ],
                "footer": "EZ Genişliği / Yapısal İlerleme Ölçütü"
            }
        ]
    )

    # Slayt 6.1.1.4: Atlas Görseli: Klasik Retinitis Pigmentosa
    p179_img = builder.get_image_for_page(179)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: RETİNİTİS PİGMENTOSA FONOFİTİ",
        category="BÖLÜM 6.1.1: ATLAS",
        subtitle="Ekvatoral Kemik Spikülü Pigmentasyonu, İpliksi Arterioller ve Mumsu Disk Solukluğu",
        image_path=p179_img if p179_img else None,
        caption="Şekil 6.1: Genç erişkin RP hastasında periferik perivasküler kemik spikülü pigment göçü ve diffüz arteriyoler incelme [Kitap s.179].",
        key_findings=[
            "Retina periferinde ve ekvatorunda siyah, dallanmış kemik spikülü (bone spicule) pigment agregatları.",
            "Retinal arter ve ven kalibrelerinde belirgin diffüz daralma (ipliksi damar yapısı).",
            "Optik disk sınırları silikleşmiş ve rengi sarı-balmumu görünümüne (waxy pallor) dönmüştür.",
            "Santral makula fovea alanı şimdilik nispeten korunmuş ancak kistik makula ödemi riski altındadır."
        ],
        differentials=[
            "Retinitis Pigmentosa: Bilateral, simetrik, ERG sönük, genetik mutasyon.",
            "Sifilitik Koryoretinit (Psödo-RP): Unilateral/asimetrik, treponema serolojisi pozitif, ERG kısmen korunur.",
            "Klorokin / Hidroksiklorokin Retinopatisi: Boğa gözü görünümü ön plandadır, ilaç öyküsü mevcuttur."
        ],
        clinical_pearl="Tipik kemik spikülü pigmentasyonu olmasa dahi ('RP sine pigmento'), gece körlüğü ve sönük skotopik ERG varlığında kesin RP tanısı konulur; pigment varlığı şart değildir [s.179]."
    )

    # Slayt 6.1.1.5: RP ile İlişkili Sistemik Sendromlar: Usher vs Bardet-Biedl
    builder.add_split_comparison_slide(
        title="SİNDROMİK RP AYIRICI TANISI: USHER vs BARDET-BIEDL",
        category="BÖLÜM 6.1.1: SENDROMLAR",
        subtitle="En Sık İki Sistemik RP Sendromunun Genetik, Odyolojik ve Dismorfik Bulguları",
        left_entity={
            "name": "USHER SENDROMU (RP + İŞİTME KAYBI)",
            "subtitle": "Körlük ve Sağırlığın En Sık Genetik Nedeni (%50)",
            "bullets": [
                "Kalıtım: Otozomal Resesif (MYO7A, USH2A, CLRN1 genleri) [s.181].",
                "Tip 1 (En Ağır): Konjenital derin sağırlık + vestibüler arefleksi (geç yürüme) + erken çocuklukta RP.",
                "Tip 2 (En Sık): Konjenital orta/ağır sensörinöral işitme kaybı + NORMAL vestibüler sistem + pubertede RP.",
                "Tip 3 (Progresif): Doğumda normal/hafif işitme; erişkinde ilerleyici işitme kaybı + değişken vestibülopatili RP.",
                "Klinik Kural: RP tanısı alan her çocuğa mutlaka saf ses odyometrisi ve KBB konsültasyonu şarttır [s.181]."
            ]
        },
        right_entity={
            "name": "BARDET-BIEDL SENDROMU (BBS - SİLİYOPATİ)",
            "subtitle": "Multisistemik Bazal Cisimcik ve Siliyer Bozukluk",
            "bullets": [
                "Kalıtım: Otozomal Resesif (BBS1-BBS21 genleri; siliyer protein kaskadı) [s.182].",
                "Klinik Pentad: 1. Erken başlangıçlı atipik RP (makula erken tutulur).",
                "2. Polidaktili (postaksiyel el/ayak parmak fazlalığı).",
                "3. Santral Obezite (erken çocuklukta başlayan gövdesel kilo artışı).",
                "4. Hipogonadizm / Genital Hipoplazi ve kısırlık.",
                "5. Renal Disfonksiyon / Kistik Böbrek (mortalitenin 1 numaralı nedenidir) ve öğrenme güçlüğü [s.182]."
            ]
        },
        bottom_takeaway="Bardet-Biedl sendromunda hastayı ölüme götüren primer neden böbrek yetmezliğidir; polidaktili ve obezitesi olan RP'li çocukta nefroliferatif tarama hayati önem taşır [s.182]."
    )

    # Slayt 6.1.1.6: RP İlişkili Kistik Makula Ödemi (KME) ve Tedavisi
    builder.add_study_card_slide(
        title="RP'DE KİSTİK MAKULA ÖDEMİ (KME) VE OKÜLER KOMPLİKASYONLAR",
        category="BÖLÜM 6.1.1: KOMPLİKASYONLAR",
        subtitle="Hastaların %10-20'sinde Gelişen KME Yönetimi, Posterior Subkapsüler Katarakt ve Glokom",
        cards=[
            {
                "card_title": "1. RP İlişkili KME Mekanizması",
                "lead": "Müller Hücre Disfonksiyonu ve Bariyer Bozulması",
                "items": [
                    "RP hastalarında santral görmeyi erken bozan en önemli komplikasyon kistik makula ödemidir [s.182].",
                    "Diyabetten farklı olarak traksiyonel veya neovasküler değildir; kan-retina bariyeri ve RPE pompa sızıntısıdır.",
                    "SD-OKT'de iç ve dış nükleer katmanlarda kistik hiporeflektif boşluklar izlenir.",
                    "FFA'da klasik kistoid sızıntı görülebileceği gibi, bazı olgularda minimal anjiyografik sızıntı ile kistler bulunur."
                ],
                "footer": "Bariyer Bozulması / OKT Kistleri / RPE Sızıntısı"
            },
            {
                "card_title": "2. Medikal Tedavi: Karbonik Anhidraz İnhibitörleri",
                "lead": "İlk Tercih: Oral Asetazolamid veya Topikal Dorzolamid",
                "items": [
                    "RPE'deki apikal Na+/K+/HCO3- kotransportörlerini uyararak subretinal ve intraretinal sıvıyı çeker [s.182].",
                    "Topikal %2 Dorzolamid veya %1 Brinzolamid günde 3 kez ilk basamak tedavidir.",
                    "Yanıtsız olgularda düşük doz Oral Asetazolamid (125-250 mg/gün) dramatik sıvı çekilmesi sağlayabilir.",
                    "Dirençli olgularda intravitreal Deksametazon implantı (Ozurdex) seçilmiş vakalarda uygulanabilir."
                ],
                "footer": "Topikal Dorzolamid / Oral Asetazolamid İlk Seçenek"
            },
            {
                "card_title": "3. Eşlik Eden Diğer Patolojiler",
                "lead": "Katarakt ve Glokom Yönetimi",
                "items": [
                    "Posterior Subkapsüler Katarakt (PSK): Hastaların %40-50'sinde genç yaşta gelişir ve santral görmeyi aniden düşürür [s.183].",
                    "PSK cerrahisi fakoemülsifikasyonla yapıldığında görme dramatik artar ancak postop KME alevlenmesine dikkat edilmelidir.",
                    "Açı Kapanması Glokomu: Küçük hipermetropik küreli RP olgularında sığ ön kamara ve pupil bloğu sıktır.",
                    "Epiretinal Membran (ERM): Kronik RPE inflamasyonuna bağlı vitreoretinal yüzeyde kırışıklık gelişebilir."
                ],
                "footer": "PSK Katarakt / KME Alevlenme Riski / Dar Açı"
            }
        ]
    )

    # Slayt 6.1.1.7: RP Teşhis ve Genetik Danışmanlık Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="RETİNİTİS PİGMENTOSA KLİNİK TANI VE YÖNETİM AKIŞI",
        category="BÖLÜM 6.1.1: AKIŞ ŞEMASI",
        subtitle="Gece Körlüğü Şikayetiyle Başvuran Hastada Adım Adım Fenotipik ve Genetik Protokol",
        steps=[
            {
                "num": "1",
                "title": "Ayrıntılı Pedigree ve Klinik Muayene",
                "desc": "En az 3 kuşaklık aile ağacı çizilir; periferik fundusta kemik spikülü ve damar kalibresi incelenir [s.183].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Tam Alan ERG ve FAF Görüntüleme",
                "desc": "Skotopik ve fotopik yanıtlar ölçülür; FAF'ta Robson hiperotofloresan halkası ve santral ada tespit edilir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Sistemik Sendrom Taraması (KBB/Böbrek)",
                "desc": "Odyometri ile sensörinöral işitme kaybı (Usher) ve batın USG/böbrek testleri (BBS) dışlanır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Yeni Nesil Genetik Panel (NGS)",
                "desc": "Hedefe yönelik retinal distrofi NGS paneli ile sorumlu gen (RPE65, USH2A, RPGR) saptanarak gen tedavisi planlanır.",
                "status": "success"
            }
        ],
        bottom_takeaway="Genetik analiz artık sadece akademik bir lüks değil, FDA onaylı gen tedavisi (Luxturna) veya devam eden faz çalışmalarına uygunluk için zorunlu bir standarttır [s.183]."
    )

    # Slayt 6.1.1.8: Aktif Hatırlama & Board Sınavı Vakası: 18 Yaşında Usher Tip 2
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: SENDROMİK RP",
        category="BÖLÜM 6.1.1: AKTİF HATIRLAMA",
        subtitle="18 Yaşında Doğuştan İşitme Cihazı Kullanan Erkekte Yeni Başlayan Gece Körlüğü",
        vignette="18 yaşında erkek üniversite öğrencisi, çocukluğundan beri orta derecede çift taraflı sensörinöral işitme kaybı nedeniyle işitme cihazı kullanmaktadır. Son 1 yıldır akşamları hava karardığında sokakta yürürken yön bulmakta zorlandığını, sinemada basamakları göremediğini ve son aylarda yanlardan gelen nesneleri fark edemediğini belirterek başvuruyor. Görme keskinliği her iki gözde 0.9. Biyomikroskopide bilateral hafif posterior subkapsüler katarakt mevcut. Fundusta ekvator boyunca yaygın kemik spikülü pigmentasyonu ve arteriyoler incelme izleniyor. Makula SD-OKT'sinde fovea korunmuş ancak kistik makula ödemi saptanıyor. Tam alan ERG'de skotopik yanıtlar tamamen silinmiş.",
        differentials=[
            "Usher Sendromu Tip 2 (Konjenital orta işitme kaybı + normal vestibüler fonksiyon + pubertede RP; USH2A mutasyonu).",
            "Usher Sendromu Tip 1 (Hasta bebeklikten beri derin sağır ve dilsiz olurdu, vestibüler yetmezlikle geç yürürdü; bu hastaya uymaz).",
            "Bardet-Biedl Sendromu (Polidaktili, obezite ve böbrek anomalisi eşlik etmediği için dışlanır).",
            "Konjenital Rubella Retinopatisi (Tuz-biber fundusu vardır ancak progresif değildir ve ERG genellikle normaldir)."
        ],
        decision="1. Klinik Tanı: Usher Sendromu Tip 2 zemininde Kistik Makula Ödemi.\n2. Makula Tedavisi: Santral görmeyi korumak için topikal %2 Dorzolamid günde 3 kez başlanmalıdır.\n3. Genetik Doğrulama: Hastadan periferik kan alınarak USH2A gen mutasyonu için NGS paneli istenmeli ve genetik danışmanlık verilmelidir.\n4. Sistemik İzlem: Odyoloji kontrolü sürdürülmeli, meslek ve eğitim planlaması daralan görme alanına göre yapılmalıdır.",
        board_trap="İşitme kaybı olan genç bir hastada 'bu sadece basit bir katarakt' diyerek ameliyata almak ve RP'yi atlamak ciddi malpraktistir; işitme cihazı kullanan birinde gece körlüğü doğrudan Usher sendromunu düşündürmelidir [s.181]."
    )

    # =========================================================================
    # 6.1.2: KONİ VE KONİ-ÇOMAK DİSTROFİLERİ (6 Slayt)
    # =========================================================================

    # Slayt 6.1.2.1: Koni ve Koni-Çomak Distrofileri Patofizyolojisi
    builder.add_study_card_slide(
        title="KONİ VE KONİ-ÇOMAK DİSTROFİLERİ PATOFİZYOLOJİSİ",
        category="BÖLÜM 6.1.2: PATOFİZYOLOJİ",
        subtitle="Erken Santral Görme Kaybı, Fotofobi ve Diskromatopsi ile Başlayan Fotoreseptör Yıkımı",
        cards=[
            {
                "card_title": "1. Hücresel Hasar Sırası",
                "lead": "RP'nin Tam Tersine Gelişen Kaskad",
                "items": [
                    "Retinitis pigmentosada önce çomaklar, sonra koniler ölürken; koni distrofilerinde önce koniler apoptoza uğrar [s.183].",
                    "Fovea ve makulada koni yoğunluğu maksimum olduğundan hasar doğrudan santral görmeyi vurur.",
                    "Saf Koni Distrofisi (CD): Çomak hücreleri ömür boyu normal kalır; sadece gündüz görmesi bozulur.",
                    "Koni-Çomak Distrofisi (COD): İlerleyen evrelerde çomaklar da yıkıma katılır ve gece körlüğü tabloya eklenir."
                ],
                "footer": "Koni Hasarı -> Santral Kayıp -> İkincil Çomak Yıkımı"
            },
            {
                "card_title": "2. Klasik Klinik Semptom Triadı",
                "lead": "Gündüz Işığında Görememe",
                "items": [
                    "1. Fotofobi ve Gündüz Körlüğü (Hemeralopi): Hasta parlak gün ışığında gözlerini açamaz, loşta daha rahat görür [s.184].",
                    "2. Erken ve İlerleyici Santral Görme Kaybı: Çocuklukta veya genç erişkinlikte bilateral görme düşüşü.",
                    "3. Şiddetli Renk Körlüğü (Diskromatopsi): Hem kırmızı-yeşil hem sarı-mavi ekseninde erken renk ayrımı kaybı.",
                    "Hasta okulda tahtayı görememe ve renkleri ayırt edememe şikayetiyle başvurur."
                ],
                "footer": "Fotofobi + Erken Görme Kaybı + Diskromatopsi"
            },
            {
                "card_title": "3. Genetik Heterojenite",
                "lead": "Sorumlu Genler ve Sinyal İletimi",
                "items": [
                    "Otozomal Dominant: GUCY2D, CRX (transkripsiyon faktörü; erken ve şiddetli başlangıç) [s.184].",
                    "Otozomal Resesif: ABCA4 (Stargardt ile ortak aleller), CNGB3, CNGA3 (akromatopsi genleri).",
                    "X'e Bağlı: RPGR (ekzon ORF15 mutasyonları hem RP hem koni-çomak distrofisi yapabilir).",
                    "Genetik tanı, gelecekteki koni hedefli AAV gen terapileri için kritik önemdedir."
                ],
                "footer": "CRX / GUCY2D / ABCA4 / RPGR"
            }
        ]
    )

    # Slayt 6.1.2.2: Koni Distrofisi vs Retinitis Pigmentosa Karşılaştırması
    builder.add_split_comparison_slide(
        title="DİSTROFİ KARŞILAŞTIRMASI: KONİ DİSTROFİSİ vs RP",
        category="BÖLÜM 6.1.2: KARŞILAŞTIRMA",
        subtitle="Koni Hücre Hasarı (Gündüz Körlüğü) vs Çomak Hücre Hasarı (Gece Körlüğü)",
        left_entity={
            "name": "KONİ DİSTROFİSİ (CD / COD)",
            "subtitle": "Santral ve Fotopik Sistem Yıkımı",
            "bullets": [
                "İlk Semptom: Fotofobi, hemeralopi (gündüz körlüğü) ve renk görme kaybı [s.184].",
                "Santral Görme: Çok erken yaşta bilateral olarak bozulur (0.1 - 0.2 seviyesine iner).",
                "Gece Görmesi: Başlangıçta tamamen normaldir; alacakaranlıkta görme daha iyidir.",
                "Görme Alanı: Santral skotom mevcuttur; periferik alan uzun süre korunur.",
                "Fundus Görünümü: Boğa gözü (Bull's eye) makulopatisi veya foveal atrofi.",
                "ERG: 30 Hz flicker yanıtı ve tek parıltı fotopik ERG silinmiştir; skotopik yanıt normaldir [s.184]."
            ]
        },
        right_entity={
            "name": "RETİNİTİS PİGMENTOSA (RP)",
            "subtitle": "Periferik ve Skotopik Sistem Yıkımı",
            "bullets": [
                "İlk Semptom: Niktalopi (gece körlüğü) ve karanlığa adapte olamama [s.179].",
                "Santral Görme: Çok geç evreye (terminal döneme) kadar 1.0 tam korunabilir.",
                "Gece Görmesi: Erken çocukluktan itibaren ağır şekilde bozulmuştur.",
                "Görme Alanı: Halka skotom ve periferik daralma; tünel görme oluşur.",
                "Fundus Görünümü: Periferik kemik spikülleri, ince damarlar, mumsu soluk disk.",
                "ERG: Skotopik çomak ERG'si tamamen silinmiştir; fotopik yanıt uzun süre kaydedilir [s.180]."
            ]
        },
        bottom_takeaway="Koni distrofisi gündüzü ve merkezi vurur (santral skotom); RP ise geceyi ve periferi vurur (tünel görme); ikisi taban tabana zıt fonksiyonel ayna görüntüleridir [s.184]."
    )

    # Slayt 6.1.2.3: FAF ve OKT Bulguları: Boğa Gözü (Bull's Eye) Makulopatisi
    builder.add_study_card_slide(
        title="KONİ DİSTROFİSİNDE GÖRÜNTÜLEME: BOĞA GÖZÜ MAKULOPATİSİ",
        category="BÖLÜM 6.1.2: GÖRÜNTÜLEME",
        subtitle="Fundus Otofloresansında Halka Konsantrik Atrofi ve OKT Foveal Kavitasyon",
        cards=[
            {
                "card_title": "1. Boğa Gözü (Bull's Eye) Fenotipi",
                "lead": "Konsantrik RPE Atrofi Çemberi",
                "items": [
                    "Fovea merkezinde küçük korunmuş bir RPE adası bulunur [s.185].",
                    "Bu adanın çevresinde konsantrik, çember şeklinde hipopigmente RPE atrofi halkası yer alır.",
                    "En dışta ise normal pigmente retina dokusu çemberi tamamlar; hedef tahtası / boğa gözü manzarası doğar.",
                    "Zamanla merkezdeki ada da atrofiye uğrayarak geniş coğrafi makula atrofisine dönüşür."
                ],
                "footer": "Merkezi Korunma + Halka Atrofi"
            },
            {
                "card_title": "2. Fundus Otofloresans (FAF) Özellikleri",
                "lead": "Bozulmuş Metabolizmanın Haritalanması",
                "items": [
                    "FAF'ta merkezdeki foveal ada normal veya hafif hipootofloresandır [s.185].",
                    "Çevresindeki atrofik çemberde RPE kaybına bağlı koyu hipootofloresans izlenir.",
                    "Atrofi çemberinin dış kenarında aktif fotoreseptör döküntüsünü gösteren ince parlak hiperotofloresan halka bulunur.",
                    "FAF, fundus muayenesinde henüz boğa gözü seçilemeyen erken olgularda lezyonu netleştirir."
                ],
                "footer": "Koyu Hipootofloresan Halka / Aktif Dış Sınır"
            },
            {
                "card_title": "3. SD-OKT ve Foveal Kavitasyon",
                "lead": "Fotoreseptör İç/Dış Segment Kaybı",
                "items": [
                    "Erken dönemde fovea altında elipsoid zon (EZ) ve interdigitasyon zonunda seçici kayıp başlar [s.185].",
                    "İleri evrede foveada nörosensoriyel retina aşırı incelir; dış nükleer katman tamamen silinir.",
                    "Bazı olgularda fovea altında optik boşluk oluşturan 'optik olarak boş foveal kavitasyon' izlenir.",
                    "RPE atrofisi geliştikçe koroid damarlarında hipertransmisyon (ışık penetrasyonu artışı) izlenir."
                ],
                "footer": "EZ Kaybı / Foveal Kavitasyon / Hipertransmisyon"
            }
        ]
    )

    # Slayt 6.1.2.4: Elektrofizyolojik Ayrım: Full-field ERG vs Pattern ERG
    builder.add_study_card_slide(
        title="KONİ DİSTROFİSİNDE ELEKTROFİZYOLOJİK ALTIN STANDART",
        category="BÖLÜM 6.1.2: ELEKTROFİZYOLOJİ",
        subtitle="30 Hz Flicker ERG Çökmesi, Tek Parıltı Fotopik Yanıt Kaybı ve Normal Skotopik Eğri",
        cards=[
            {
                "card_title": "1. 30 Hz Flicker Yanıtı (Fotopik İzolasyon)",
                "lead": "Koni Sisteminin Hız Testi",
                "items": [
                    "Çomak fotoreseptörleri saniyede 30 kez çakan flaşa yetişemez; yalnızca koniler yanıt verebilir [s.185].",
                    "Koni distrofisinde 30 Hz flicker yanıtının amplitüdü aşırı düşer ve dalga tepesi gecikir (latans uzaması).",
                    "Hastalığın en erken elektrofizyolojik belirtecidir; fundus tamamen normalken bile 30 Hz flicker bozulur.",
                    "Koni-çomak distrofisinde zamanla skotopik eğriler de düşmeye başlar."
                ],
                "footer": "30 Hz Flicker: Düşük Amplitüd / Uzamış Latans"
            },
            {
                "card_title": "2. Tek Parıltı Fotopik ERG (Light-Adapted)",
                "lead": "Aydınlığa Adapte Konik Sinyal",
                "items": [
                    "Beyaz arka plan ışığı altında çomaklar doydurulur ve tek bir güçlü flaş verilir [s.185].",
                    "Normalde belirgin a- ve b-dalgaları elde edilirken, koni distrofisinde dalgalar düzleşir.",
                    "Buna karşılık 20 dakikalık karanlık adaptasyonu sonrası kaydedilen skotopik çomak ERG'si tamamen normaldir.",
                    "Bu elektrofizyolojik disosiasyon (koni çökmüş, çomak sağlam) patognomoniktir."
                ],
                "footer": "Fotopik Düz / Skotopik Normal Disosiasyonu"
            },
            {
                "card_title": "3. Desen (Pattern) ERG ve Multifokal ERG",
                "lead": "Foveal Fonksiyonun Topografik Haritası",
                "items": [
                    "Multifokal ERG (mfERG), makulanın santral 30 derecesindeki koni yanıtlarını petek şeklinde haritalar [s.186].",
                    "Koni distrofisinde santral foveal tepe yanıtı tamamen çöker (santral depresyon).",
                    "Pattern ERG'de P50 dalgası makula koni disfonksiyonunu yansıtarak silinir.",
                    "Psikojenik/fonksiyonel görme kaybı şüphesi olan çocuklarda objektif tanı koydurur."
                ],
                "footer": "mfERG Santral Çöküş / P50 Dalgası Kaybı"
            }
        ]
    )

    # Slayt 6.1.2.5: Koni Distrofisi Tanı ve Triyaj Algoritması
    builder.add_decision_tree_slide(
        title="BOĞA GÖZÜ MAKULOPATİSİ VE KONİ DİSTROFİSİ TRİYAJI",
        category="BÖLÜM 6.1.2: KARAR AĞACI",
        subtitle="Makulada Halka Atrofi Saptanan Hastada Ayırıcı Tanı ve Elektrofizyolojik Protokol",
        root_label="GENÇ HASTADA BİLATERAL GÖRME AZALMASI VE BOĞA GÖZÜ MAKULOPATİSİ",
        branches=[
            {
                "label": "1. İlaç Toksisitesi Sorgulaması",
                "criteria": "Romatolojik hastalık, >5 yıl Klorokin / Hidroksiklorokin kullanımı, kümülatif doz aşımı [s.184].",
                "action": "Toksik Retinopati Tanısı: İlaç derhal romatoloji ile görüşülerek kesilir; multifokal ERG takibi yapılır."
            },
            {
                "label": "2. 30 Hz Flicker ERG Çökmüş / Skotopik Normal",
                "criteria": "Fotofobi var, renk görme bozuk, aile öyküsü pozitif; periferik görme alanı sağlam [s.185].",
                "action": "Koni Distrofisi (CD): Renkli filtreli kırmızı/kahverengi güneş gözlüğü, az görenlere yardım cihazları, NGS gen paneli."
            },
            {
                "label": "3. Hem Fotopik Hem Skotopik ERG Bozuk",
                "criteria": "Gündüz görme azlığına ek olarak hafif gece körlüğü ve periferik daralma başlamış [s.184].",
                "action": "Koni-Çomak Distrofisi (COD): Kapsamlı genetik tarama (CRX, RPGR, ABCA4); yıllık görme alanı izlemi."
            }
        ],
        bottom_rule="Boğa gözü makulopatisi olan bir hastada elektrofizyoloji (ERG) yapılmadan koni distrofisi ile Stargardt veya hidroksiklorokin toksisitesi birbirinden güvenle ayırt edilemez [s.185]."
    )

    # Slayt 6.1.2.6: Aktif Hatırlama & Board Sınavı Vakası: 22 Yaşında Fotofobi ve Boğa Gözü
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: KONİ DİSTROFİSİ",
        category="BÖLÜM 6.1.2: AKTİF HATIRLAMA",
        subtitle="22 Yaşında Üniversite Öğrencisinde Şiddetli Güneş Işığı Hassasiyeti ve Renk Körlüğü",
        vignette="22 yaşında erkek mimarlık öğrencisi, güneşli günlerde dışarı çıktığında gözlerini açamadığını (fotofobi), renk tonlarını ayırt etmekte zorlandığını ve her iki gözünde görmenin son 2 yılda kademeli olarak 0.2 düzeyine indiğini belirterek başvuruyor. Hasta akşamları ve loş ışıkta gündüze göre çok daha rahat gördüğünü ifade ediyor. İlaç kullanım öyküsü yok. Görme keskinliği her iki gözde 0.2. Renk görme testinde (Farnsworth D-15) tüm eksenlerde ağır renk ayrım kusuru saptanıyor. Fundus muayenesinde her iki foveada merkezi korunmuş, konsantrik hipopigmente atrofi halkası (klasik Boğa Gözü manzarası) izleniyor. Periferik retina ve damar kalibreleri tamamen normal.",
        differentials=[
            "Progresif Koni Distrofisi (Fotofobi, gündüz görmeme, diskromatopsi, boğa gözü ve genç yaş).",
            "Hidroksiklorokin Retinopatisi (Klinik görünüm benzerdir ancak ilaç kullanım hikayesi kesinlikle yoktur).",
            "Stargardt Hastalığı (Karanlık koroid ve balık pulu sarı lekeler beklenir; hemeralopi ön planda değildir).",
            "Santral Areolar Koroidal Distrofi (Genellikle 40'lı yaşlardan sonra başlar, foveada tam coğrafi atrofi yapar)."
        ],
        decision="1. Tanısal Test: Hastaya Tam Alan Elektrofizyoloji (ISCEV standart ERG) yapılmalıdır.\n2. Beklenen Bulgular: 30 Hz flicker yanıtı tamamen düzleşmiş ve fotopik tek flaş yanıtı çökmüş olmalı; skotopik çomak ERG'si ise tamamen normal bulunmalıdır.\n3. Yönetim: Koni Distrofisi tanısı konur; fotofobiyi kırmak için %90 absorbsiyonlu kırmızı/amber renkli özel filtreli gözlük verilir; CRX ve GUCY2D gen paneli çalışılır.",
        board_trap="Bu hastaya gece körlüğü sorulup 'gece iyi görüyorum' yanıtı alınınca retinal distrofi ihtimali elenirse büyük hata yapılır; koni distrofisinde gece görmesi sağlamdır, patoloji gündüz sistemindedir [s.184]."
    )

    # =========================================================================
    # 6.1.3: STARGARDT, BEST VE PATTERN DİSTROFİLER (8 Slayt)
    # =========================================================================

    # Slayt 6.1.3.1: Stargardt Hastalığı (STGD1): ABCA4 ve A2E Toksisitesi
    builder.add_study_card_slide(
        title="STARGARDT HASTALIĞI (STGD1) PATOGENEZİ VE ABCA4 DEFEKTİ",
        category="BÖLÜM 6.1.3: PATOGENEZ",
        subtitle="ATP-Bağlayıcı Kaset Taşıyıcı Eksikliği, Toksik A2E Birikimi ve A Vitamini Kontrendikasyonu",
        cards=[
            {
                "card_title": "1. ABCA4 Geni ve Flippaz Fonksiyonu",
                "lead": "Tüm-Trans Retinalin Dışarı Pompalanamaması",
                "items": [
                    "ABCA4 proteini, fotoreseptör dış segment disk membranlarında yerleşmiş bir ATP-bağımlı flippazdır [s.186].",
                    "Görevi: Işık uyarısı sonrası oluşan tüm-trans-retinal-fosfatidiletanolamin (N-ret-PE) kompleksini disk lümeninden sitoplazmaya atmaktır.",
                    "ABCA4 mutasyonunda bu kompleks disk içinde birikir ve hızla toksik A2E (piridinyum bisretinoid) molekülüne dönüşür.",
                    "A2E, RPE hücrelerince fagositoz edildiğinde lizozomları tıkayarak sindirilemeyen lipofuksin granüllerine dönüşür."
                ],
                "footer": "ABCA4 Mutasyonu -> Flippaz İflası -> Toksik A2E"
            },
            {
                "card_title": "2. RPE ve Fotoreseptör Hücre Ölümü",
                "lead": "Lipofuksin Zehirlenmesi ve Apoptoz",
                "items": [
                    "Lizozomları A2E ile dolan RPE hücreleri otofaji yapamaz, membran bütünlüğü bozulur ve hücre ölür [s.186].",
                    "RPE ölünce üzerindeki foveal fotoreseptörler trofik desteğini kaybederek sekonder olarak dökülür.",
                    "Makulada 'dövülmüş bronz' (beaten bronze) görünümü ve santral coğrafi atrofi gelişir.",
                    "Periferik retinada sarı-beyaz balık pulu (pisciform flecks) şeklinde lipofuksin odakları saçılır."
                ],
                "footer": "A2E Lizozom Zehirlenmesi -> RPE Ölümü -> Dövülmüş Bronz"
            },
            {
                "card_title": "3. MUTLAK KURAL: A Vitamini Yasağı",
                "lead": "Hastalığı Agrese Eden İatrojenik Tuzak",
                "items": [
                    "Stargardt hastalarına yüksek doz A vitamini (retinol) takviyesi verilmesi KESİNLİKLE YASAKTIR [s.187].",
                    "Dışarıdan alınan her molekül A vitamini, görme döngüsüne girerek A2E üretimini ve lipofuksin birikimini katlar.",
                    "RP hastalarında bazen kullanılan A vitamini protokolü Stargardt'ta verilirse makula hızla körleşir.",
                    "Güneş ışığı maruziyeti de A2E fotooksidasyonunu artırdığından UV koruyucu gözlük şarttır."
                ],
                "footer": "⚠️ A VİTAMİNİ KESİNLİKLE KONTRENDİKEDİR"
            }
        ]
    )

    # Slayt 6.1.3.2: Stargardt Klinik Görünümü ve Karanlık Koroid Belirtisi
    builder.add_study_card_slide(
        title="STARGARDT TANI BELİRTEÇLERİ: BALIK PULLARI VE KARANLIK KOROD",
        category="BÖLÜM 6.1.3: TANI BELİRTEÇLERİ",
        subtitle="Pisciform Flecks, Dövülmüş Bronz Fovea ve FFA'da Patognomonik 'Silent Choroid'",
        cards=[
            {
                "card_title": "1. Balık Pulu (Pisciform Flecks) Lekeler",
                "lead": "RPE Düzeyinde Lipofuksin Agregatları",
                "items": [
                    "Arka kutup ve orta periferde balık pulu, virgül veya yıldız şeklinde sarı-beyaz lekeler görülür [s.187].",
                    "Bu lekeler zamanla merkezden çevreye doğru yayılır; yaşlandıkça silinip arkasında atrofi bırakabilir.",
                    "FAF'ta taze fleck'ler yoğun hiperotofloresan verir; atrofiye uğrayanlar ise hipootofloresan siyah benek halini alır.",
                    "Çocuklarda bazen fleck'ler henüz çıkmamışken bile foveal görme kaybı başlayabilir."
                ],
                "footer": "Pisciform Fleck / FAF Hiperotofloresansı"
            },
            {
                "card_title": "2. Karanlık Koroid (Dark / Silent Choroid)",
                "lead": "Floresein Anjiyografisinin İmzası (%85 Olguda)",
                "items": [
                    "FFA yapıldığında normalde izlenen koroid arka plan floresansı tamamen karanlık kalır [s.187].",
                    "Retinal damarlar ve optik disk parıldarken, koroid dolaşımı sanki hiç kanlanmıyormuş gibi siyahtır.",
                    "Mekanizma: Tüm RPE hücrelerine homojen yayılan aşırı lipofuksin, 488 nm mavi uyarı ışığını absorbe eder.",
                    "Böylece koryokapillarisin floresansı retinaya geçemez (blokaj); Stargardt için neredeyse patognomoniktir."
                ],
                "footer": "FFA'da Koroid Floresansının Blokajı"
            },
            {
                "card_title": "3. Fundus Otofloresans ve OKT Bulguları",
                "lead": "Non-İnvaziv Evreleme Araçları",
                "items": [
                    "FAF: Makula merkezinde coğrafi atrofiye karşılık gelen santral siyah (hipootofloresan) ada izlenir [s.188].",
                    "Bu adanın çevresinde parlak hiperotofloresan fleck fırtınası mevcuttur.",
                    "SD-OKT: Foveada dış nükleer katman ve elipsoid zonda tam kayıp, foveal incelme saptanır.",
                    "RPE atrofisi sahasında koryokapillarise doğru artmış ışık geçirgenliği (hipertransmisyon) izlenir."
                ],
                "footer": "Santral Siyah Ada / Foveal Çöküş / Hipertransmisyon"
            }
        ]
    )

    # Slayt 6.1.3.3: Best Vitelliform Makula Distrofisi (BEST1 / VMD2) ve Evreleri
    builder.add_study_card_slide(
        title="BEST VİTELLİFORM MAKULA DİSTROFİSİ VE BEŞ EVRESİ",
        category="BÖLÜM 6.1.3: BEST HASTALIĞI",
        subtitle="Bestrofin-1 Klor Kanalı Kusuru, Sahanda Yumurta Fenotipi ve EOG Patolojisi",
        cards=[
            {
                "card_title": "1. Patogenez ve Bestrofin-1 Proteini",
                "lead": "Otozomal Dominant BEST1 Mutasyonu",
                "items": [
                    "Bestrofin-1, RPE'nin bazolateral membranında yerleşik Ca2+ bağımlı bir klor kanalıdır [s.188].",
                    "İyon dengesi bozulunca subretinal sıvı ve dış segment metabolitleri RPE ile fotoreseptör arasında göllenir.",
                    "İlginç Özellik: Foveada devasa sarı bir lezyon olmasına rağmen hastanın görmesi uzun yıllar 0.8-1.0 kalır!",
                    "Görme ancak lezyon parçalanıp (vitellirüptif) atrofi veya KNV geliştiğinde düşer."
                ],
                "footer": "BEST1 / Klor Kanalı / Korunmuş Görme Paradoksu"
            },
            {
                "card_title": "2. Best Hastalığının 5 Klasik Evresi",
                "lead": "Previtelliformdan Atrofiye Seyir",
                "items": [
                    "Evre 1 (Previtelliform): Fundus tamamen normaldir; ancak EOG testi anormaldir (Arden <1.5) [s.188].",
                    "Evre 2 (Vitelliform): Foveada 1-2 disk çapında parlak sarı, homojen 'sahanda yumurta' kisti (görme mükemmeldir).",
                    "Evre 3 (Psödohipopiyon): Sarı lipofuksin içeriği yerçekimiyle kistin alt yarısına çöker; üst yarı berraklaşır.",
                    "Evre 4 (Vitellirüptif): Kist çatlar, 'çırpılmış yumurta' manzarası oluşur; görme bu evrede düşmeye başlar.",
                    "Evre 5 (Atrofik / KNV): RPE atrofisi veya subretinal KNV gelişir; santral diskiform skar oluşur."
                ],
                "footer": "Previtelliform -> Yumurta -> Hipopiyon -> Çırpılmış -> Atrofi"
            },
            {
                "card_title": "3. Tanısal Altın Standart: EOG",
                "lead": "Arden Oranının Çökmesi",
                "items": [
                    "Elektrookülografi (EOG): RPE'nin transepitelyal potansiyelini ölçer [s.189].",
                    "Normalde ışık pikinin karanlık çukuruna oranı (Arden Oranı) >1.85 (en az >1.70) olmalıdır.",
                    "Best hastalarında Arden oranı <1.50 (genellikle 1.10 - 1.20 düzeyine) çöker.",
                    "KRİTİK KURAL: EOG'si normal olan bir hastada asla Best hastalığı tanısı konulamaz!"
                ],
                "footer": "EOG Arden Oranı <1.50 ŞARTTIR"
            }
        ]
    )

    # Slayt 6.1.3.4: Stargardt vs Best Hastalığı Karşılaştırmalı Matrisi
    builder.add_split_comparison_slide(
        title="MAKULER DİSTROFİ AYRIMI: STARGARDT vs BEST",
        category="BÖLÜM 6.1.3: KARŞILAŞTIRMA",
        subtitle="ABCA4 vs BEST1 Mutasyonu Zemininde İki Büyük Distrofinin Ayırıcı Tanı Kriterleri",
        left_entity={
            "name": "STARGARDT HASTALIĞI (STGD1)",
            "subtitle": "Otozomal Resesif — ABCA4 Mutasyonu",
            "bullets": [
                "Kalıtım: Otozomal Resesif (%95) [s.186].",
                "Görme Keskinliği: Erken yaşta belirgin ve kalıcı olarak düşer (0.1 - 0.2).",
                "Fundus Lezyonu: Dövülmüş bronz fovea + periferik pisciform sarı balık pulları.",
                "FFA Bulgusu: %85 olguda 'Karanlık Koroid' (Silent choroid) patognomoniktir.",
                "EOG Testi: Normal veya hafif subnormaldir; Arden oranı tanısal değildir.",
                "ERG Testi: Erken dönemde normal; ileri evrede fotopik/skotopik amplitüd düşebilir.",
                "Tedavi Yasağı: Yüksek doz A vitamini takviyesi KESİNLİKLE YASAKTIR [s.187]."
            ]
        },
        right_entity={
            "name": "BEST VİTELLİFORM MAKULOPATİ (VMD2)",
            "subtitle": "Otozomal Dominant — BEST1 Mutasyonu",
            "bullets": [
                "Kalıtım: Otozomal Dominant (değişken ekspresyon) [s.188].",
                "Görme Keskinliği: Büyük lezyona rağmen uzun yıllar şaşırtıcı şekilde iyidir (0.8 - 1.0).",
                "Fundus Lezyonu: İzole foveal 'sahanda yumurta' / psödohipopiyon kisti; perifer temizdir.",
                "FFA Bulgusu: Koroid normaldir; kist sahasında blokaj, kist eriyince hiperfloresans.",
                "EOG Testi: ARDEN ORANI <1.50 DÜZEYİNE ÇÖKER (Tanısal altın standart).",
                "ERG Testi: Tam alan ERG tamamen normaldir (RPE spesifik hasar).",
                "Komplikasyon: Evre 5'te KNV gelişirse anti-VEGF enjeksiyonuna mükemmel yanıt verir [s.189]."
            ]
        },
        bottom_takeaway="Stargardt'ta FFA karanlık koroid verirken EOG normaldir; Best'te ise FFA normal koroid verirken EOG Arden oranı mutlaka çökmüştür [s.188]."
    )

    # Slayt 6.1.3.5: Erişkin Başlangıçlı Foveomaküler Vitelliform Distrofi (AOFVD)
    builder.add_study_card_slide(
        title="ERİŞKİN BAŞLANGIÇLI VİTELLİFORM DİSTROFİ (AOFVD)",
        category="BÖLÜM 6.1.3: PATTERN DİSTROFİLER",
        subtitle="30-50 Yaşında Başlayan PRPH2 Mutasyonlu Psödo-Best Tablosu ve Normal EOG",
        cards=[
            {
                "card_title": "1. Klinik Tanım ve Yaş Farkı",
                "lead": "Genç Best'ten Ayrılan Erişkin Tablo",
                "items": [
                    "AOFVD, genellikle 30-50 yaşları arasında rutin muayenede veya hafif görme azalmasıyla yakalanır [s.189].",
                    "Fovea merkezinde Best hastalığına benzeyen küçük, yuvarlak, 1/3 - 1/2 disk çapında sarı lezyon bulunur.",
                    "Lezyon Best'e göre çok daha küçüktür ve merkezinde genellikle küçük bir pigment noktası taşır.",
                    "Sıklıkla yaşa bağlı makula dejenerasyonu (kuru YBMD druseni) ile karıştırılarak yanlış tanı alır."
                ],
                "footer": "30-50 Yaş / Küçük Sarı Lezyon / YBMD Taklidi"
            },
            {
                "card_title": "2. Genetik ve EOG Ayrımı",
                "lead": "PRPH2 (Periferin/RDS) Mutasyonu",
                "items": [
                    "Olguların önemli bir kısmında PRPH2 geni mutasyonu saptanır; nadiren BEST1 mutasyonu eşlik eder [s.189].",
                    "EOG Testi: Klasik Best hastalığının aksine AOFVD'de EOG ARDEN ORANI NORMALDİR (veya sınırdadır).",
                    "EOG'nin normal olması bu antiteyi infantil Best vitelliform distrofisinden ayıran en kesin kanıttır.",
                    "Ayrıca elektroretinogram (tam alan ERG) da tamamen normal sınırlardadır."
                ],
                "footer": "PRPH2 Geni / EOG Normal / ERG Normal"
            },
            {
                "card_title": "3. SD-OKT Görünümü ve Doğal Seyir",
                "lead": "Subretinal Hiperreflektif Materyal",
                "items": [
                    "SD-OKT'de fotoreseptörler ile RPE arasında kubbe şeklinde hiperreflektif materyal birikimi izlenir [s.190].",
                    "Materyal genellikle RPE'nin üzerindedir (subretinal drusenoid depozit ile benzer katmanda).",
                    "Doğal seyir oldukça yavaş ve selimdir; hastalar görmelerini uzun yıllar 0.6-0.8 seviyesinde korur.",
                    "Sarı materyal zamanla rezorbe olup yerini hafif foveal RPE atrofisine bırakabilir; nadiren KNV gelişir."
                ],
                "footer": "Subretinal Kubbe / Selim Seyir / Nadir KNV"
            }
        ]
    )

    # Slayt 6.1.3.6: Atlas Görseli: Stargardt Hastalığında Karanlık Koroid ve FAF
    p186_img = builder.get_image_for_page(186)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: STARGARDT HASTALIĞINDA KARANLIK KOROİD",
        category="BÖLÜM 6.1.3: ATLAS",
        subtitle="FFA'da Silent Choroid Maskelenmesi, FAF'ta Pisciform Fleckler ve Makula Atrofisi",
        image_path=p186_img if p186_img else None,
        caption="Şekil 6.2: 16 yaşında Stargardt hastasında FFA'da izlenen klasik karanlık koroid ve foveada coğrafi RPE atrofisi [Kitap s.186].",
        key_findings=[
            "Floresein anjiyografisinde koroidal dolaşım tamamen karanlıktır; retinal damarlar siyah zemin üzerinde parlar.",
            "Fovea merkezinde RPE atrofisine bağlı 'pencere defekti' (window defect) hiperfloresansı izlenir.",
            "Perifere doğru uzanan balık pulu (pisciform) sarı lezyonlar erken evrede blokaj, geç evrede boyanma gösterir.",
            "FAF incelemesinde santral foveal alanda siyah hipootofloresan atrofi alanı ve çevresinde parlak fleck'ler mevcuttur."
        ],
        differentials=[
            "Stargardt Hastalığı: Karanlık koroid (+), FAF fleck'leri (+), ABCA4 mutasyonu.",
            "Koni-Çomak Distrofisi: Karanlık koroid yoktur, 30 Hz flicker ERG çökmüştür.",
            "Coğrafi Atrofi (YBMD): İleri yaşta görülür, drusen eşlik eder, karanlık koroid izlenmez."
        ],
        clinical_pearl="Ergenlik çağında sebebi açıklanamayan bilateral görme azalması olan bir çocukta fundus normal görünse bile mutlaka FFA çekilmelidir; karanlık koroid tespiti Stargardt'ı anında yakalar [s.186]."
    )

    # Slayt 6.1.3.7: Makuler Distrofilerde Biyomarker ve Genetik Test Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="MAKULER DİSTROFİ AYIRICI TANI VE TEST PROTOKOLÜ",
        category="BÖLÜM 6.1.3: AKIŞ ŞEMASI",
        subtitle="Erken Başlangıçlı Makulopatide Adım Adım Elektrofizyolojik ve Genetik Doğrulama",
        steps=[
            {
                "num": "1",
                "title": "Fundus Otofloresans (FAF) & OKT",
                "desc": "Santral atrofi, hiperotofloresan fleck'ler (Stargardt) veya subretinal sarı materyal (Best/AOFVD) taranır [s.187].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "FFA ile 'Karanlık Koroid' Taraması",
                "desc": "Anjiyografide koroid floresansının homojen bloke olup olmadığı kontrol edilir; varsa Stargardt lehinedir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "EOG ve Tam Alan ERG İncelemesi",
                "desc": "EOG Arden oranı <1.50 ise Best; ERG 30 Hz flicker bozuksa Koni distrofisi; EOG normal ise Stargardt/AOFVD.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Hedefe Yönelik NGS Gen Paneli",
                "desc": "ABCA4, BEST1 veya PRPH2 mutasyonu doğrulanır; Stargardt ise A vitamini yasağı kesin olarak bildirilir [s.187].",
                "status": "success"
            }
        ],
        bottom_takeaway="Stargardt teşhisi konulan hastanın reçetesine yanlışlıkla A vitamini içeren multivitamin yazılması geri dönüşsüz toksik körlüğü tetikler [s.187]."
    )

    # Slayt 6.1.3.8: Aktif Hatırlama & Board Sınavı Vakası: 15 Yaşında Stargardt ve A Vitamini Tuzağı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: STARGARDT",
        category="BÖLÜM 6.1.3: AKTİF HATIRLAMA",
        subtitle="15 Yaşında Kız Öğrencide Okul Başarısında Düşme, FFA'da Karanlık Koroid ve Multivitamin Tuzağı",
        vignette="15 yaşında lise öğrencisi kız hasta, son 1 yıldır sınıfta tahtayı net göremediğini, kitap okurken harflerin ortasının silindiğini belirterek başvuruyor. Görme keskinliği her iki gözde 0.2'ye düşmüş; gözlükle düzeltilemiyor. Ön segment tamamen doğal. Fundus muayenesinde foveada hafif metalik refleks ('dövülmüş bronz' manzarası) ve arka kutupta foveayı çevreleyen birkaç adet soluk sarı-beyaz virgül şeklinde lezyon (pisciform flecks) izleniyor. FFA yapıldığında tüm retinada arka plan koroid floresansının tamamen silindiği (Karanlık Koroid / Silent Choroid) ve foveada pencere defekti izleniyor. Aile, önceki hekimin 'gözü beslesin' diye yüksek doz A vitamini ve lutein içeren multivitamin başladığını söylüyor.",
        differentials=[
            "Stargardt Hastalığı (STGD1 - Genç yaş, foveal bronzlaşma, pisciform fleckler ve karanlık koroid).",
            "Best Vitelliform Makulopati (FFA'da karanlık koroid olmaz, lezyon sahanda yumurta şeklindedir).",
            "Juvenil Koni Distrofisi (Karanlık koroid izlenmez; fotofobi ve renk körlüğü çok daha baskındır).",
            "Fonksiyonel / Psikojenik Görme Kaybı (FFA'daki karanlık koroid organik kanıttır)."
        ],
        decision="1. Kesin Tanı: Stargardt Hastalığı (Otozomal Resesif ABCA4 Mutasyonu).\n2. Acil Eylem: Ailenin başladığı A vitamini içeren takviye DERHAL KESİLMELİDİR. Hastaya A vitamininin A2E lizozomal toksisitesini hızlandırdığı açıkça anlatılmalıdır.\n3. Koruyucu Önlemler: Dış ortamda %100 UV filtreli güneş gözlüğü takması önerilmeli, az görenlere yardım cihazları (teleskopik gözlük/dijital büyüteç) reçete edilmelidir.\n4. Genetik Analiz: ABCA4 gen dizi analizi yapılmalıdır.",
        board_trap="RP'deki eski literatür alışkanlığıyla Stargardt hastasına A vitamini takviyesi vermek sınavda sıfır puan, pratikte ise ağır malpraktis nedenidir; A vitamini Stargardt'ta kesinlikle kontrendikedir [s.187]."
    )

    # =========================================================================
    # 6.2.1: KOROİDEREMİ, JİRAT ATROFİ, STICKLER, FEVR VE XLRS (8 Slayt)
    # =========================================================================

    # Slayt 6.2.1.1: Koroideremi (CHM): Klinik Seyir ve Foveal Ada Korunması
    builder.add_study_card_slide(
        title="KOROİDEREMİ: PATOFİZYOLOJİ VE KLİNİK BULGULAR",
        category="BÖLÜM 6.2.1: KOROİD DİSTROFİSİ",
        subtitle="X'e Bağlı CHM Geni (REP-1 Eksikliği), Yaygın Koryoretinal Atrofi ve Korunan Santral Ada",
        cards=[
            {
                "card_title": "1. Genetik ve REP-1 Proteini",
                "lead": "Rab Esort Protein-1 Yetersizliği",
                "items": [
                    "Koroideremi, Xq21 kromozomundaki CHM gen mutasyonu sonucu gelişen X'e bağlı resesif bir hastalıktır [s.191].",
                    "CHM geni, hücre içi veziküler trafiği yöneten Rab eskort protein-1'i (REP-1) kodlar.",
                    "REP-1 eksikliği RPE ve koryokapillaris hücrelerinde erken dejenerasyona ve hücre ölümüne yol açar.",
                    "Yalnızca erkeklerde tam klinik tablo oluşur; taşıyıcı kadınlarda fundusta mozaik pigmentasyon görülür."
                ],
                "footer": "CHM Geni / REP-1 Defekti / X'e Bağlı"
            },
            {
                "card_title": "2. Klinik Seyir ve Fundus Morfolojisi",
                "lead": "Çıplak Sklera Manzarası",
                "items": [
                    "Çocukluk çağında gece körlüğü (niktalopi) ile başlar; ergenlikte orta periferde koryoretinal atrofi gelişir [s.191].",
                    "RPE ve koryokapillaris tamamen eridiğinde altındaki parlak beyaz sklera dokusu çıplak olarak izlenir.",
                    "Retina damarları ve büyük derin koroid damarları beyaz sklera üzerinde adacıklar halinde yüzer.",
                    "Tipik RP'deki gibi yoğun kemik spikülü pigmentasyonu görülmez; ana tablo yaygın doku kaybıdır."
                ],
                "footer": "Çıplak Sklera / RPE-Koryokapillaris Erimesi"
            },
            {
                "card_title": "3. Foveal Santral Adanın Korunması",
                "lead": "50-60 Yaşına Kadar Kalan 1.0 Görme",
                "items": [
                    "Tüm arka kutup bembeyaz skleraya dönüşse dahi fovea merkezinde küçük kırmızı bir retina adası kalır [s.192].",
                    "Bu foveal ada sayesinde hastalar 50-60'lı yaşlarına kadar 1.0 tam santral görmelerini koruyabilirler.",
                    "Ancak görme alanı ileri derecede daralmıştır (aşırı tüp görme).",
                    "Foveal ada da nihayetinde çöktüğünde ani ve tam körlük gelişir; AAV gen tedavisi klinik fazları bu adayı korumayı hedefler."
                ],
                "footer": "Korunan Foveal Ada / Geç Terminal Kayıp"
            }
        ]
    )

    # Slayt 6.2.1.2: Jirat (Gyrate) Atrofi (OAT): Hiperornitinemi ve Diyet
    builder.add_study_card_slide(
        title="JİRAT (GYRATE) ATROFİ: OAT EKSİKLİĞİ VE DİYET TEDAVİSİ",
        category="BÖLÜM 6.2.1: METABOLİK DİSTROFİ",
        subtitle="Ornitin Aminotransferaz Defekti, Çelenk Şeklinde Atrofi ve Argininsiz Beslenme Protokolü",
        cards=[
            {
                "card_title": "1. Biyokimyasal Mekanizma",
                "lead": "Kanda Toksik Ornitin Birikimi (10-20 Kat)",
                "items": [
                    "Otozomal resesif OAT geni mutasyonu sonucu ornitin aminotransferaz enzimi çalışmaz [s.192].",
                    "Plazma, idrar ve aközde ornitin düzeyleri 10-20 kat artar (hiperornitinemi).",
                    "Aşırı ornitin RPE hücreleri ve koryokapillaris için doğrudan sitotoksiktir.",
                    "Tedavi edilebilir nadir genetik retina distrofilerinden biridir; erken diyet koryoretinal yıkımı durdurur."
                ],
                "footer": "OAT Eksikliği / Hiperornitinemi / Toksik RPE"
            },
            {
                "card_title": "2. Çelenk (Gyrate) Şekilli Atrofi Odakları",
                "lead": "Periferden Merkeze İlerleyen Çemberler",
                "items": [
                    "Erken dönemde periferik retinada keskin sınırlı, yuvarlak/oval koryoretinal atrofi adacıkları başlar [s.192].",
                    "Bu adacıklar zamanla birleşerek çelenk veya taraklı bayrak (scalloped margins) şeklinde dev bantlar oluşturur.",
                    "Atrofi alanlarında sklera tamamen açığa çıkar; lezyon sınırlarında koyu pigment birikimleri bulunur.",
                    "Erken yaşta yüksek miyopi (-6 ila -10 D) ve erken posterior subkapsüler katarakt eşlik eder."
                ],
                "footer": "Çelenk Şekilli Atrofi / Yüksek Miyopi / PSK Katarakt"
            },
            {
                "card_title": "3. Tedavi: Argininsiz Diyet & B6 Vitamini",
                "lead": "Retina Tıbbının Diyetle Tedavi Edilen Hastalığı",
                "items": [
                    "1. Argininden Kısıtlı Diyet: Ornitin argininden sentezlendiği için protein kısıtlaması yapılır [s.193].",
                    "Et, süt, yumurta, balık ve kuruyemiş kesilerek plazma ornitin düzeyi <200 μmol/L hedefine indirilir.",
                    "2. Piridoksin (B6 Vitamini) Denemesi: Hastaların %5-10'u B6 vitaminine yanıt verir (OAT koenzimidir).",
                    "3. L-Lizin ve L-Karnitin takviyesi idrarla ornitin atılımını desteklemek için eklenebilir."
                ],
                "footer": "Argininsiz Diyet / B6 Vitamini / <200 μmol/L Hedef"
            }
        ]
    )

    # Slayt 6.2.1.3: Koroideremi vs Jirat Atrofi Karşılaştırması
    builder.add_split_comparison_slide(
        title="KOROİDAL DİSTROFİ AYRIMI: KOROİDEREMİ vs JİRAT ATROFİ",
        category="BÖLÜM 6.2.1: KARŞILAŞTIRMA",
        subtitle="REP-1 Eksikliği (Koroideremi) vs OAT Enzim Eksikliği (Jirat Atrofi)",
        left_entity={
            "name": "KOROİDEREMİ (CHM / REP-1)",
            "subtitle": "X'e Bağlı — Yapısal Koroid ve RPE Kaybı",
            "bullets": [
                "Kalıtım: X'e Bağlı Resesif (Sadece erkekler tam etkilenir) [s.191].",
                "Biyokimya: Plazma ornitin düzeyi tamamen NORMALDİR.",
                "Fundus Lezyonu: Diffüz, sınırları belirsiz çıplak sklera; foveada küçük kırmızı ada uzun süre korunur.",
                "Eşlik Eden Durum: Yüksek miyopi şart değildir; katarakt geç evrededir.",
                "Tedavi: Diyet tedavisi YOKTUR; AAV2-REP-1 gen tedavisi klinik fazlardadır [s.192]."
            ]
        },
        right_entity={
            "name": "JİRAT ATROFİ (OAT DEFEKTİ)",
            "subtitle": "Otozomal Resesif — Toksik Metabolik Hastalık",
            "bullets": [
                "Kalıtım: Otozomal Resesif (Her iki cinsiyette eşit) [s.192].",
                "Biyokimya: Plazma ornitin düzeyi 10-20 KAT ARTMIŞTIR (Hiperornitinemi).",
                "Fundus Lezyonu: Periferde başlayan, keskin sınırlı, birleşen 'çelenk' şeklinde dairesel atrofi odakları.",
                "Eşlik Eden Durum: Çok erken yaşta yüksek miyopi (-8.00 D) ve ergenlikte PSK katarakt.",
                "Tedavi: DİYETLE TEDAVİ EDİLEBİLİR (Düşük argininli diyet + B6 Vitamini) [s.193]."
            ]
        },
        bottom_takeaway="Jirat atrofide plazma ornitin seviyesine bakılarak anında kesin tanı konur ve ömür boyu argininsiz diyet ile hastanın kör olması engellenebilir [s.193]."
    )

    # Slayt 6.2.1.4: Stickler Sendromu: Optik Boş Vitreus ve Dev Yırtık Riski
    builder.add_study_card_slide(
        title="STİCKLER SENDROMU (HERİDİTER ARTRO-OFTALMOPATİ)",
        category="BÖLÜM 6.2.1: VİTREORETİNOPATİ",
        subtitle="Tip 2/11 Kollajen Mutasyonları (COL2A1), Optik Boş Vitreus ve Dev Yırtık Dekolmanı",
        cards=[
            {
                "card_title": "1. Kollajen Defekti ve Genetik",
                "lead": "COL2A1 ve COL11A1 Mutasyonları",
                "items": [
                    "Otozomal dominant geçişli en sık herediter vitreoretinopatidir [s.193].",
                    "Gözün ve eklem kıkırdağının ana iskeleti olan Tip II kollajen (COL2A1, Tip 1 Stickler) sentezlenemez.",
                    "Tip 2 Stickler'da ise COL11A1 mutasyonu sorumludur.",
                    "Sistemik bulgular: Düz yüz (orta yüz hipoplazisi), mikrognati, yarık damak (Pierre Robin sekansı) ve erken artroz."
                ],
                "footer": "COL2A1 / Tip II Kollajen / Yarık Damak"
            },
            {
                "card_title": "2. Oküler Bulgular: Optik Boş Vitreus",
                "lead": "Vitreus Jelinin Tamamen Çökmesi",
                "items": [
                    "Biyomikroskopide vitreus boşluğu jel yapısını kaybetmiş, su gibi berrak ve 'optik olarak boş' görünür [s.193].",
                    "Lensin hemen arkasında ince bir retroretinal zar (vestijiyal membran) dışında fibril izlenmez.",
                    "Konjenital yüksek miyopi (-8 ila -18 D) ve katarakt hemen hemen tüm olgularda mevcuttur.",
                    "Periferik retinada yaygın radyal perivasküler lattice dejenerasyonu kuşakları izlenir."
                ],
                "footer": "Optik Boş Vitreus / Radyal Lattice / Konjenital Miyopi"
            },
            {
                "card_title": "3. Felaket: Dev Yırtık ve RRD Riski",
                "lead": "Hastaların %50-60'ında Dekolman Gelişir",
                "items": [
                    "Vitreus tabanının zayıflığı nedeniyle dev yırtıklar (giant retinal tear >90°) gelişme riski aşırı yüksektir [s.194].",
                    "Dekolman genellikle bilateraldir ve erken çocuklukta fark edilmeyip ağır PVR ile sonlanır.",
                    "Profilaksi Protokolü: Yırtık olmasa dahi 360 derece ora serrata çevresine 3 sıra koruyucu bariyer lazer (veya kriyopeksi) atılması önerilir.",
                    "Erken profilaksi, Stickler hastalarında körlüğü önleyen en kritik cerrahi kuraldır."
                ],
                "footer": "Dev Yırtık Riski (%60) / 360° Koruyucu Bariyer Lazer"
            }
        ]
    )

    # Slayt 6.2.1.5: Familial Eksüdatif Vitreoretinopati (FEVR)
    builder.add_study_card_slide(
        title="FAMİLİAL EKSÜDATİF VİTREORETİNOPATİ (FEVR)",
        category="BÖLÜM 6.2.1: VİTREORETİNOPATİ",
        subtitle="Wnt Sinyal Yolağı Bozukluğu (FZD4 / LRP5), Avasküler Perifer ve ROP Benzeri Tablo",
        cards=[
            {
                "card_title": "1. Wnt / Norrin Sinyal İletim Defekti",
                "lead": "Retinal Vaskülarizasyonun Durması",
                "items": [
                    "Retinal damarların embriyolojik gelişimini kontrol eden Wnt reseptör kompleksi bozuktur [s.194].",
                    "Sorumlu genler: FZD4 (Frizzled-4), LRP5, TSPAN12 ve NDP (Norrie hastalığı geni).",
                    "Sonuç: Temporal periferik retina hiçbir zaman damarlanamaz ve ömür boyu avasküler kalır.",
                    "ROP'a çok benzer; ANCAK prematüre doğum ve oksijen maruziyeti öyküsü KESİNLİKLE YOKTUR (zamanında doğmuştur)."
                ],
                "footer": "FZD4 / LRP5 / Zamanında Doğum (ROP Değil!)"
            },
            {
                "card_title": "2. Klinik Evreleme ve Bulgular",
                "lead": "Avasküler Periferden Falciform Katlantıya",
                "items": [
                    "Evre 1: Asemptomatik avasküler temporal perifer (FFA'da tarak şeklinde avasküler sınır) [s.194].",
                    "Evre 2: Avasküler sınırda neovaskülarizasyon ve eksüdasyon gelişimi (ROP Evre 3 benzeri).",
                    "Evre 3: Eksüdatif veya traksiyonel retina dekolmanı (foveayı tehdit etmeyen periferik elevasyon).",
                    "Evre 4 & 5: Foveal traksiyonel/regmatojen dekolman, falciform retinal katlantı veya total retrolental kitle."
                ],
                "footer": "Avasküler Perifer -> Neovaskülarizasyon -> Dekolman"
            },
            {
                "card_title": "3. Tedavi ve Profilaksi İlkeleri",
                "lead": "Avasküler Periferin Lazer Fotokoagülasyonu",
                "items": [
                    "Evre 1-2 olgularda avasküler temporal sahaya acil 532 nm diyot/yeşil lazer fotokoagülasyon uygulanır [s.195].",
                    "İskemik alan lazerle yok edilerek VEGF salınımı durdurulur ve traksiyonel dekolman gelişimi önlenir.",
                    "Dekolman gelişmiş olgularda 25G lens koruyucu vitrektomi ve skleral bant uygulanır.",
                    "Hastalık otozomal dominant olabileceğinden anne, baba ve kardeşlerin genişletilmiş FFA ile taranması zorunludur."
                ],
                "footer": "Avasküler Sahaya Lazer / Aile FFA Taraması"
            }
        ]
    )

    # Slayt 6.2.1.6: X'e Bağlı Retinoskizis (XLRS): RS1 ve Negatif ERG
    builder.add_study_card_slide(
        title="X'E BAĞLI JUVENİL RETİNOSKİZİS (XLRS)",
        category="BÖLÜM 6.2.1: SKİZİS",
        subtitle="Retinoskizin (RS1) Eksikliği, Tekerlek Parmakları Foveal Skizis ve Patognomonik 'Negatif ERG'",
        cards=[
            {
                "card_title": "1. Retinoskizin Proteini ve Yapışıklık Kaybı",
                "lead": "RS1 Geni ve Hücreler Arası Bağlantı",
                "items": [
                    "Xp22 kromozomundaki RS1 geni, fotoreseptör ve bipolar hücrelerce salgılanan retinoskizin proteinini kodlar [s.195].",
                    "Retinoskizin, hücre adezyonunu ve sinaptik organizasyonu sağlayan bir 'hücreler arası yapıştırıcıdır'.",
                    "Eksikliğinde retina hücreleri birbirinden ayrılır; sinir lifi ve iç nükleer katmanlarda mikrokistik yarıklar açılır.",
                    "Yalnızca genç erkek çocuklarda görülür; okul çağında görme azlığı (0.2-0.5) ile teşhis edilir."
                ],
                "footer": "RS1 Geni / Hücresel Yapışma Kaybı / Genç Erkekler"
            },
            {
                "card_title": "2. Foveal Skizis: Tekerlek Parmakları Manzarası",
                "lead": "Foveadan Etrafa Işınsal Çizgiler (%98-100 Olguda)",
                "items": [
                    "Biyomikroskopide fovea merkezinden çevreye ışınsal uzanan mikrokistik çizgiler (spoke-wheel) izlenir [s.195].",
                    "SD-OKT'de iç nükleer ve iç pleksiform katmanlarda intraretinal dev şeffaf kistik yarıklar (skizis) görülür.",
                    "Hastaların %50'sinde periferik retinada da skizis bulunur; iç yaprak yırtılarak serbest damarlar vitreusa asılabilir.",
                    "Bu damarların yırtılması çocukta tekrarlayan masif vitreus kanamalarına yol açabilir."
                ],
                "footer": "Tekerlek Parmakları (Spoke-wheel) / OKT İç Katman Kistleri"
            },
            {
                "card_title": "3. Patognomonik Elektrofizyoloji: Negatif ERG",
                "lead": "Seçici B-Dalgası Kaybı (b/a Oranı <1.0)",
                "items": [
                    "Maksimal skotopik yanıtta a-dalgası (fotoreseptör kökenli) tamamen NORMALDİR [s.196].",
                    "Ancak b-dalgası (Müller ve bipolar hücre kökenli) derin bir çöküş gösterir; a-dalgasının altına iner.",
                    "Bu elektrofizyolojik görünüme 'Elektro-Negatif ERG' (b/a < 1.0) denir ve XLRS için patognomoniktir.",
                    "Medikal Tedavi: Topikal Karbonik Anhidraz İnhibitörü (Dorzolamid), foveal kistleri anlamlı düzeyde küçültür."
                ],
                "footer": "Negatif ERG (b/a <1.0) / Topikal Dorzolamid Yanıtı"
            }
        ]
    )

    # Slayt 6.2.1.7: Vitreoretinopatiler Ayırıcı Tanı ve Karar Ağacı
    builder.add_decision_tree_slide(
        title="VİTREORETİNOPATİ VE PEDİATRİK RETİNA KARAR AĞACI",
        category="BÖLÜM 6.2.1: KARAR AĞACI",
        subtitle="Genç Erkek Çocukta Makuler Kist, Yırtık veya Avasküler Periferde Triyaj",
        root_label="GENÇ HASTADA BİLATERAL PERİFERİK/SANTRAL RETİNAL PATOLOJİ SAPTANDI",
        branches=[
            {
                "label": "1. Foveada Tekerlek Parmakları + Negatif ERG",
                "criteria": "Erkek çocuk, OKT'de iç katman skizisi, tam alanda b-dalgası çökük [s.195].",
                "action": "X'e Bağlı Retinoskizis (XLRS): Topikal %2 Dorzolamid başlanır; periferik vitreus kanaması ve yırtık izlenir."
            },
            {
                "label": "2. Yüksek Miyopi + Optik Boş Vitreus + Yarık Damak",
                "criteria": "Bilateral konjenital miyopi (-10 D), kıkırdak/eklem anomalisi, ailede dekolman öyküsü [s.193].",
                "action": "Stickler Sendromu (COL2A1): Dev yırtık riskine karşı derhal 360° profilaktik bariyer lazer veya kriyoretinopeksi."
            },
            {
                "label": "3. Zamanında Doğan Bebekte Avasküler Perifer",
                "criteria": "Prematürelik yok, temporal perifer avasküler, eksüda ve traksiyonel membranlar [s.194].",
                "action": "FEVR (Wnt Defekti): Avasküler sahaya acil 532 nm yeşil lazer; tüm birinci derece akrabalara FFA taraması."
            }
        ],
        bottom_rule="Stickler sendromlu bir çocukta yırtık oluşmasını beklemek felakettir; dev yırtık geliştikten sonra cerrahi başarı şansı çok düşer, erken 360° profilaksi hayat kurtarır [s.194]."
    )

    # Slayt 6.2.1.8: Aktif Hatırlama & Board Sınavı Vakası: 8 Yaşında Erkek Çocukta XLRS
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: RETİNOSKİZİS",
        category="BÖLÜM 6.2.1: AKTİF HATIRLAMA",
        subtitle="8 Yaşında Erkek Çocukta Okul Taramasında Görme Azlığı, Foveada Tekerlek Manzarası",
        vignette="8 yaşında erkek ilkokul öğrencisi, okul taramasında her iki gözde görme keskinliğinin 0.3 olduğu saptanarak sevk ediliyor. Doğum öyküsü miadında ve sorunsuzdur. Gözlükle görmesi artmıyor. Ön segment muayenesi tamamen normal. Biyomikroskopik fundus muayenesinde her iki foveada foveoladan çevreye doğru ışınsal dağılan ince kistik çizgiler ('bisiklet tekerleği parmakları' - spoke-wheel) izleniyor. İnferotemporal periferde retinanın iç yaprağında hafif kabarıklık ve damar gölgeleri mevcut. SD-OKT'de foveada iç nükleer katman boyunca uzanan intraretinal sütunlar ve kistik yarıklar izleniyor. Tam alan ERG'de skotopik a-dalgası normal amplitüddeyken, b-dalgası a-dalgasının altına inmiş (b/a oranı 0.6; Elektro-Negatif ERG).",
        differentials=[
            "X'e Bağlı Juvenil Retinoskizis (Erkek çocuk, spoke-wheel fovea, iç katman OKT kistleri ve negatif ERG).",
            "Kistik Makula Ödemi (Üveit veya vaskülit kaynaklı; kistler dış nükleer katmandadır, negatif ERG vermez).",
            "Best Vitelliform Makulopati (EOG anormaldir, ERG normaldir; spoke-wheel görünümü yoktur).",
            "Goldmann-Favre Sendromu (Artozomal resesiftir, gece körlüğü çok erkendir ve katarakt eşlik eder)."
        ],
        decision="1. Kesin Tanı: X'e Bağlı Juvenil Retinoskizis (XLRS - RS1 gen mutasyonu).\n2. Medikal Tedavi: Foveal kistleri ve intraretinal sıvıyı azaltmak için Topikal Karbonik Anhidraz İnhibitörü (%2 Dorzolamid günde 3 kez) başlanmalıdır.\n3. Yaşam Tarzı Kısıtlaması: Periferik skizis zemininde vitreus kanaması ve yırtık riskini önlemek için temas sporları (boks, karate, güreş vb.) yasaklanmalıdır.\n4. Genetik: RS1 mutasyonu çalışılmalı ve anneye genetik danışmanlık verilmelidir.",
        board_trap="Bu hastada OKT'deki kistleri görüp 'bu kistik makula ödemidir' diyerek intravitreal Anti-VEGF veya steroid enjekte etmek ağır bir hatadır; XLRS intraretinal mekanik yarıktır, tek etkili damla karbonik anhidraz inhibitörüdür [s.196]."
    )

    # =========================================================================
    # 6.2.2: RETİNAL GEN TEDAVİLERİ: LUXTURNA VE FAZ ÇALIŞMALARI (8 Slayt)
    # =========================================================================

    # Slayt 6.2.2.1: Retinal Gen Terapisi Prensipleri ve AAV Vektörleri
    builder.add_study_card_slide(
        title="RETİNAL GEN TERAPİSİ PRENSİPLERİ VE AAV VEKTÖRLERİ",
        category="BÖLÜM 6.2.2: GEN TEDAVİSİ",
        subtitle="Gözün İmmün Ayrıcalığı, Adeno-Assosiye Virüs (AAV) Biyolojisi ve Subretinal Hedefleme",
        cards=[
            {
                "card_title": "1. Gözün İmmün Ayrıcalığı (Immune Privilege)",
                "lead": "Gen Tedavisi İçin Mükemmel Organ",
                "items": [
                    "Kan-retina bariyeri, göz içi immünsüpresif mikroçevre ve lenfatik drenaj yokluğu immün yanıtı sınırlar [s.196].",
                    "Küçük bir hacimde (150-300 μl) yüksek vektör konsantrasyonu elde edilebilir; sistemik yayılım minimaldir.",
                    "Hedef doku doğrudan oftalmoskopi ve OKT ile non-invaziv olarak hücresel düzeyde izlenebilir.",
                    "Bir kez başarılı aktarım sağlandığında bölünmeyen nöronal retina hücrelerinde ekspresyon ömür boyu sürebilir."
                ],
                "footer": "İmmün Ayrıcalık / Minimal Sistemik Risk / Kalıcı Ekspresyon"
            },
            {
                "card_title": "2. Adeno-Assosiye Virüs (AAV) Vektörleri",
                "lead": "Güvenli ve Etkin DNA Taşıyıcıları",
                "items": [
                    "AAV'ler patojenik olmayan, konak genomuna entegre olmadan episomal kalan tek sarmallı DNA virüsleridir [s.196].",
                    "AAV2 Serotipi: RPE hücrelerini ve fotoreseptörleri enfekte etmede en yüksek tropizme sahiptir.",
                    "Taşıma Kapasitesi: Yaklaşık 4.7 kilobaz (kb) DNA kasetini paketleyebilir (küçük/orta genler için idealdir).",
                    "Büyük genler (ABCA4, USH2A >5-6 kb) tek AAV'ye sığmaz; bunlar için çift-AAV veya lentivirüs gerekir."
                ],
                "footer": "AAV2 Tropizmi / 4.7 kb Sınırı / Episomal Güvenlik"
            },
            {
                "card_title": "3. İntravitreal vs Subretinal Uygulama",
                "lead": "Bariyerleri Aşma Mücadelesi",
                "items": [
                    "İntravitreal Enjeksiyon: Kolaydır ancak iç limitan zar (İLM) virüsün dış retinaya geçişini bloke eder [s.197].",
                    "Subretinal Enjeksiyon: Pars plana vitrektomi sonrası 38-41G kanülle RPE ile fotoreseptör arasına verilir.",
                    "Hedef hücreler (RPE ve elipsoid zon) virüsle doğrudan temas eder; transduksiyon verimi %95'in üzerindedir.",
                    "Dezavantajı: Geçici iatrojenik foveal dekolman oluşturulmasını ve mikrocerrahi uzmanlığını gerektirir."
                ],
                "footer": "Subretinal Enjeksiyon: Maksimum RPE Transduksiyonu"
            }
        ]
    )

    # Slayt 6.2.2.2: Luxturna (Voretigene Neparvovec): RPE65 İçin İlk Onaylı Gen Kürü
    builder.add_study_card_slide(
        title="VORETİGENE NEPARVOVEC (LUXTURNA): RPE65 GEN TEDAVİSİ",
        category="BÖLÜM 6.2.2: LUXTURNA",
        subtitle="FDA ve EMA Onaylı İlk Gen İlacı: Çift Allelik RPE65 Mutasyonlu Leber Konjenital Amarozu ve RP",
        cards=[
            {
                "card_title": "1. RPE65 Enzimi ve Görme Döngüsü",
                "lead": "İzomerohidrolaz Enziminin İflası",
                "items": [
                    "RPE65, RPE'de tüm-trans retinil esterlerini 11-sis-retinole dönüştüren kritik izomerohidrolazdır [s.197].",
                    "RPE65 yokluğunda 11-sis retinal üretilemez; rodopsin rejenerasyonu durur ve fotoreseptörler körleşir.",
                    "Bebekler doğuştan görmez (Leber Konjenital Amarozu - LCA) veya erken çocuklukta ağır RP geliştirir.",
                    "Luxturna, sağlıklı RPE65 gen kopyasını AAV2 vektörü ile RPE hücrelerine teslim ederek enzim üretimini yeniden başlatır."
                ],
                "footer": "RPE65 İkamesi -> 11-sis Retinal Üretimi Başlar"
            },
            {
                "card_title": "2. Tedavi İçin Gerekli Katı Şartlar",
                "lead": "Canlı Retinal Hücre Varlığı (Viability)",
                "items": [
                    "1. Genetik Doğrulama: Her iki kopyada da patojenik RPE65 mutasyonu (çift allelik) belgelenmelidir [s.197].",
                    "2. Yeterli Canlı Hücre: SD-OKT'de en az 100 μm kalınlığında retina ve elipsoid zon adası bulunmalıdır.",
                    "3. Yaş Kriteri: En az 12 aylık veya daha büyük çocuk ve erişkin hastalar.",
                    "Tamamen atrofiye gitmiş ve hücresi kalmamış göze gen verilse bile etki edecek hücre olmadığı için fayda sağlamaz."
                ],
                "footer": "Çift Allelik RPE65 + Canlı RPE/Fotoreseptör Şartı"
            },
            {
                "card_title": "3. Klinik Başarı ve Görsel Kazanım",
                "lead": "Karanlıkta Yürüme Yeteneğinin Kazanılması",
                "items": [
                    "Tedavi sonrası hastaların ışık duyarlılığı 100 ila 1000 kat artar [s.198].",
                    "Daha önce loş ışıkta tamamen kör olan çocuklar akşamları tek başına yürüyebilir, yıldızları görebilir hale gelir.",
                    "Görme keskinliği tablosunda (Snellen) artış sınırlı olsa bile fonksiyonel görme ve yaşam kalitesi dramatik düzelir.",
                    "Etkinliğin tek doz enjeksiyon sonrası en az 7-10 yıl boyunca stabil korunduğu gösterilmiştir."
                ],
                "footer": "1000 Kat Işık Duyarlılığı / Kalıcı Fonksiyonel İyileşme"
            }
        ]
    )

    # Slayt 6.2.2.3: Luxturna Landmark Faz 3 Çalışması (Russell et al.)
    builder.add_trials_kpi_slide(
        title="LUXTURNA LANDMARK FAZ 3 KLİNİK ÇALIŞMASI (RUSSELL ET AL.)",
        category="BÖLÜM 6.2.2: LANDMARK ÇALIŞMA",
        subtitle="Çift Allelik RPE65 Mutasyonlu Hastalarda Faz 3 Randomize Kontrollü Çok Merkezli Çalışma",
        kpis=[
            {"val": "%65", "label": "En Düşük Işıkta Parkuru Tamamlama"},
            {"val": "1 Lux", "label": "Tedavi Sonrası Geçilen Işık Seviyesi"},
            {"val": "2 Yıl+", "label": "Faz 3 Stabil Takip Süresi"},
            {"val": "1.5 x 10¹¹", "label": "Vektör Genomu / Doz (0.3 ml)"}
        ],
        trials_table=[
            {
                "trial": "Russell et al. (The Lancet 2017)",
                "design": "Faz 3 Prospektif Randomize Kontrollü Açık Etiketli Çalışma (n=31 hasta; 21 aktif, 10 kontrol) [s.198]",
                "result": "Luxturna alan hastaların %65'i 1. yılda en karanlık ışık seviyesinde (1 Lux) engelli parkuru hatasız tamamlamıştır (p=0.001)."
            },
            {
                "trial": "MLMT (Multi-Luminance Mobility Test)",
                "design": "FDA Onaylı Fonksiyonel Görme Parkuru (1 Lux ile 400 Lux arası 7 farklı aydınlatma düzeyi)",
                "result": "Aktif grupta ortalama 1.8 lüks basamağı iyileşme sağlanmış; kontrol grubu ise hiçbir ilerleme gösterememiştir."
            },
            {
                "trial": "FST (Full-Field Stimulus Threshold)",
                "design": "Beyaz, Mavi ve Kırmızı Işık Uyarısına Karşı Tüm Alan Retinal Duyarlılık Eşiği Ölçümü",
                "result": "Luxturna enjeksiyonundan sonraki 30. günde retinal ışık duyarlılığında 2 logaritmik birimden fazla (100 kat) artış kaydedilmiştir."
            }
        ],
        bottom_evidence="Russell Faz 3 çalışması, genetik körlükte ilk kez insan genomuna fonksiyonel bir gen aktarılarak klinik fonksiyonun restore edilebileceğini kanıtlamıştır [s.198]."
    )

    # Slayt 6.2.2.4: Subretinal Cerrahi Uygulama Protokolü
    builder.add_study_card_slide(
        title="LUXTURNA SUBRETİNAL CERRAHİ UYGULAMA PROTOKOLÜ",
        category="BÖLÜM 6.2.2: CERRAHİ PROTOKOL",
        subtitle="25G Vitrektomi, Ön Enjeksiyon, 41G Subretinal Kanül ve Dozaj Güvenliği",
        cards=[
            {
                "card_title": "1. Preoperatif Hazırlık ve İmmünsüpresyon",
                "lead": "AAV Kapsidine Karşı Reaksiyonu Önleme",
                "items": [
                    "Viral vektöre karşı enflamasyonu baskılamak için ameliyattan 3 gün önce Oral Prednizon (1 mg/kg) başlanır [s.198].",
                    "Steroid tedavisi operasyon sonrası 7 gün tam doz sürdürülür ve 10 gün içinde kademeli azaltılarak kesilir.",
                    "İki göz aynı gün ameliyat edilmez; aralarında en az 6-14 gün güvenlik süresi bırakılmalıdır.",
                    "Göz içi basıncı ve enfeksiyon parametreleri ameliyat sabahı titizlikle doğrulanır."
                ],
                "footer": "Oral Prednizon Profilaksisi / İki Göz Arasında 7-14 Gün"
            },
            {
                "card_title": "2. Cerrahi Adımlar: Bülle Oluşturma",
                "lead": "38G/41G Teflon Kanülle Subretinal Giriş",
                "items": [
                    "Standart 25G Pars Plana Vitrektomi yapılır; arka hyaloid zarı foveadan tamamen soyulur [s.199].",
                    "Önce BSS ile küçük bir test deliği açılarak subretinal aralık doğrulanabilir.",
                    "Ardından 0.3 ml hacmindeki voretigene neparvovec süspansiyonu (1.5 x 10^11 vg) yavaşça enjekte edilir.",
                    "Foveayı ve damar arkatlarını içine alan kubbe şeklinde şeffaf bir nörosensoriyel retina büllesi oluşur."
                ],
                "footer": "0.3 ml (1.5x10¹¹ vg) / Foveayı İçeren Subretinal Bülle"
            },
            {
                "card_title": "3. Cerrahi Komplikasyonlar ve Yönetim",
                "lead": "İatrojenik Makula Deliği ve Foveal İncelme",
                "items": [
                    "Enjeksiyon basıncı aşırı yüksek olursa fovea yırtılarak makula deliği gelişebilir (yavaş sıkılmalıdır) [s.199].",
                    "Oluşan subretinal sıvı 24-48 saat içinde RPE pompalarınca emilir ve fovea kendiliğinden yatışır.",
                    "Hava veya gaz tamponadı gerekmez; vitreus BSS ile dolu bırakılır.",
                    "Geç dönemde foveal incelme (%10-15) gelişebileceğinden hasta düzenli SD-OKT ile takip edilir."
                ],
                "footer": "Düşük Basınçlı Enjeksiyon / 24 Saatte Spontan Yatışma"
            }
        ]
    )

    # Slayt 6.2.2.5: Devam Eden Retinal Gen Tedavisi Faz Çalışmaları
    builder.add_trials_kpi_slide(
        title="BORU HATTINDAKİ RETİNAL GEN TEDAVİSİ KLİNİK FAZLARI",
        category="BÖLÜM 6.2.2: GELECEK FAZLAR",
        subtitle="XLRP (RPGR), Koroideremi (CHM), Stargardt ve Akromatopsi Gen Deneyleri",
        kpis=[
            {"val": "Faz 3", "label": "XLRP (AAV5-RPGR) Klinik Aşaması"},
            {"val": "Faz 3", "label": "Koroideremi (AAV2-REP1) Düzeyi"},
            {"val": "Çift-AAV", "label": "Stargardt (ABCA4) Vektör Çözümü"},
            {"val": "CRISPR", "label": "CEP290 İn Vivo Gen Düzenleme"}
        ],
        trials_table=[
            {
                "trial": "XLRP Gen Tedavisi (XIRCL / Beacon Faz 3)",
                "design": "AAV5-RPGR (Botaretigene sparoparvovec) Subretinal Enjeksiyonu [s.199]",
                "result": "Faz 1/2'de mikrometre görme alanında anlamlı artış ve foveal kavitasyon stabilizasyonu kanıtlanmış; Faz 3 sürmektedir."
            },
            {
                "trial": "Koroideremi Gen Tedavisi (STAR Study)",
                "design": "AAV2-REP1 (Timrepigene emparvovec) ile Sağlıklı CHM Geni Aktarımı",
                "result": "Foveal santral adanın korunması ve görme keskinliğinde iyileşme sağlanmış; anatomik stabilizasyon izlenmektedir."
            },
            {
                "trial": "Stargardt Çift-AAV ve Lentiviral Denemeleri",
                "design": "ABCA4 Geni (6.8 kb) İçin Çift Vektörlü Rekombinasyonel Yaklaşım [s.200]",
                "result": "Gen iki parçaya bölünerek iki ayrı AAV'ye paketlenmekte ve hücre içinde birleşerek tam protein sentezlemektedir."
            }
        ],
        bottom_evidence="AAV gen tedavileri monogenik hastalıklarda standart tedavi haline gelme yolundadır; genetik tanı konulması hastanın bu çalışmalara dahil edilebilmesi için birincil koşuldur [s.199]."
    )

    # Slayt 6.2.2.6: Optogenetik Tedavi ve Gen Düzenleme (CRISPR/Cas9)
    builder.add_study_card_slide(
        title="İLERİ UFUKLAR: OPTOGENETİK TEDAVİ VE CRISPR DÜZENLEME",
        category="BÖLÜM 6.2.2: İLERİ TEKNOLOJİ",
        subtitle="Hücresi Kalmamış Terminal Retina İçin Optogenetik Işık Duyarlılığı ve İn Vivo Gen Kurgusu",
        cards=[
            {
                "card_title": "1. Optogenetik Tedavi Prensipleri",
                "lead": "Gangliyon Hücrelerini Fotoreseptöre Dönüştürme",
                "items": [
                    "Tüm çomak ve konileri ölmüş terminal körlük evresindeki hastalarda standart gen tedavisi işe yaramaz [s.200].",
                    "Optogenetik: Alg ve bakterilerden izole edilen ışığa duyarlı iyon kanalları (ChrimsonR / Channelrhodopsin) kullanılır.",
                    "AAV vektörü ile yaşayan retinal gangliyon hücrelerine (RGC) veya bipolar hücrelere bu gen aktarılır.",
                    "RGC'ler ışık algılayan yapay fotoreseptörlere dönüşür; özel stimülatör gözlükler (goggles) görüntüyü retinaya projekte eder."
                ],
                "footer": "Kanalrodopsin / Gangliyon Hücresi Işıklandırma / Biyonik Gözlük"
            },
            {
                "card_title": "2. Sahel et al. Landmark Optogenetik Başarısı",
                "lead": "Dünyada İlk Kez Kör Hastada Kısmi Görme İyileşmesi",
                "items": [
                    "Nature Medicine (2021): Son evre RP nedeniyle sadece ışık hissi olan 58 yaşında hastaya AAV2-ChrimsonR verildi [s.200].",
                    "Işık dönüştürücü gözlük yardımıyla hasta masadaki nesneleri algılamış, saymış ve dokunabilmiştir.",
                    "Beyin EEG'sinde oksipital korteksin görsel uyarılara yeniden senkronize olduğu doğrulanmıştır.",
                    "Mutasyondan bağımsız (mutation-agnostic) bir tedavi olduğu için her türlü körlükte uygulanabilme potansiyeline sahiptir."
                ],
                "footer": "Nature Medicine 2021 / Mutasyondan Bağımsız Çözüm"
            },
            {
                "card_title": "3. CRISPR/Cas9 İn Vivo Gen Düzenleme",
                "lead": "Bozuk Mutasyonun Retinada Düzeltilmesi (EDIT-101)",
                "items": [
                    "Gen eklemek yerine, hastanın kendi DNA'sındaki zararlı mutasyonun kesilerek çıkarılmasıdır [s.200].",
                    "EDIT-101 (BRILLIANCE Çalışması): CEP290 genindeki IVS26 derin intronik mutasyonunu hedefleyen CRISPR ilacıdır.",
                    "Subretinal enjeksiyonla Cas9 enzimi bozuk splicing bölgesini kesip atarak doğru protein sentezini sağlamıştır.",
                    "İn vivo gen düzenlemenin insandaki ilk başarılı klinik kanıtıdır."
                ],
                "footer": "EDIT-101 / CEP290 Kurgusu / İlk İn Vivo CRISPR"
            }
        ]
    )

    # Slayt 6.2.2.7: Genetik Tedavi Uygunluk ve Triyaj Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="GEN TEDAVİSİ UYGUNLUK VE HASTA SEÇİM PROTOKOLÜ",
        category="BÖLÜM 6.2.2: AKIŞ ŞEMASI",
        subtitle="Retinal Distrofili Hastanın Gen Terapisine Uygunluğunun Değerlendirilmesi",
        steps=[
            {
                "num": "1",
                "title": "Kapsamlı NGS Genomik Paneli",
                "desc": "Tüm ekzom veya distrofi paneli ile mutasyon doğrulanır; çift allelik patojenik RPE65 varlığı araştırılır [s.197].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Hücresel Canlılık Analizi (SD-OKT)",
                "desc": "Retina kalınlığının >100 μm olduğu ve foveal/makuler alanda elipsoid zon adasının korunduğu belgelenir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Fonksiyonel Eşik Testleri (FST & MLMT)",
                "desc": "Tüm alan uyarı eşiği (FST) ve çoklu ışık düzeyinde yürüme parkuru (MLMT) ile bazal görme haritalanır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Cerrahi Uygulama ve İmmünsüpresyon",
                "desc": "Oral steroid koruması altında 25G PPV + 0.3 ml Subretinal Luxturna enjeksiyonu uygulanır [s.198].",
                "status": "success"
            }
        ],
        bottom_takeaway="Gen tedavisi için hastada canlı fotoreseptör hücresi bulunması şarttır; son evre atrofiye gitmiş gözlerde standart gen tedavisi uygulanamaz [s.197]."
    )

    # Slayt 6.2.2.8: Aktif Hatırlama & Board Sınavı Vakası: 9 Yaşında LCA ve Luxturna
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: GEN TEDAVİSİ",
        category="BÖLÜM 6.2.2: AKTİF HATIRLAMA",
        subtitle="9 Yaşında Ağır Gece Körlüğü Olan Çocukta RPE65 Mutasyonu ve Luxturna Kararı",
        vignette="9 yaşında kız çocuğu, bebekliğinden beri loş ışıkta göremediği, akşamları odasından çıkamadığı ve görme keskinliğinin azaldığı şikayetiyle getiriliyor. Görme keskinliği her iki gözde 0.3. Nistagmus saptanmıyor. Fundus muayenesinde her iki gözde hafif periferik pigment düzensizlikleri ve retinal damarlarda hafif incelme mevcut; makulada belirgin coğrafi atrofi izlenmiyor. SD-OKT incelemesinde foveal retina kalınlığı 165 μm ve fovea altında net elipsoid zon (canlı fotoreseptör tabakası) izleniyor. Yapılan yeni nesil dizileme (NGS) genetik testinde RPE65 geninde birleşmiş çift allelik patojenik mutasyon (c.430T>C ve c.1444C>T) doğrulanıyor.",
        differentials=[
            "RPE65 İlişkili Erken Başlangıçlı Retinitis Pigmentosa / Leber Konjenital Amarozu (Luxturna adayı).",
            "X'e Bağlı RP (RPGR mutasyonu; kız çocuklarında nadiren tam klinik tablo yapar).",
            "Stargardt Hastalığı (ABCA4 mutasyonudur; gece körlüğü değil santral görme kaybı ön plandadır).",
            "Koni-Çomak Distrofisi (Gündüz görme kaybı ve fotofobi ön plandadır)."
        ],
        decision="1. Endikasyon Değerlendirmesi: Hasta çift allelik RPE65 mutasyonuna sahiptir, yaşı >12 aydır ve SD-OKT'de foveal kalınlık >100 μm olup elipsoid zon canlıdır. Hasta tam bir Voretigene Neparvovec (Luxturna) adayıdır.\n2. Cerrahi Tedavi: Preoperatif 3 gün önce oral prednizon başlanır. 25G PPV eşliğinde foveayı kapsayacak şekilde 0.3 ml subretinal Luxturna enjekte edilir.\n3. Diğer Göz: İlk ameliyattan 10 gün sonra ikinci göze aynı protokol uygulanır.",
        board_trap="Eğer bu hastanın SD-OKT'sinde retina kağıt gibi incelmiş (örneğin 40 μm) ve tüm hücreler ölmüş olsaydı, genetik mutasyon RPE65 olsa dahi Luxturna verilemezdi; ilacın çalışması için canlı hedef hücre şarttır [s.197]."
    )

    print(f" -> Bölüm 6 (Kalıtsal Retinal ve Koroidal Distrofiler) Tamamlandı: 39 Slayt Eklendi.")
