# -*- coding: utf-8 -*-
r"""
retina_ch1_builder.py — Bölüm 1: Temel Bilimler ve Anatomi (46 Slayt)
=====================================================================
Kitap Sayfaları: 3 – 37
Alt Başlıklar:
  1.0   Bölüm 1 Çalışma Yol Haritası (1 slayt)
  1.1.1 Vitreus yapısı, korteks, taban ve vitreoretinal arayüz (5 slayt)
  1.1.2 Nörosensoryal retina katmanları ve foveal mikroanatomi (5 slayt)
  1.1.3 Retina pigment epiteli (RPE) ve Bruch membranı kompleksi (5 slayt)
  1.1.4 Koryokapillaris ve koroide ait vasküler mimari (5 slayt)
  1.2.1 Fototransdüksiyon kaskadı ve retinoid/görme döngüsü (5 slayt)
  1.2.2 Kan-retina bariyerleri (iç ve dış B-RB) ve transport mekanizmaları (5 slayt)
  1.2.3 RPE metabolik fonksiyonları ve fagositoz (5 slayt)
  1.3.1 Kalıtsal retinal hastalıklarda genetik geçiş modelleri (5 slayt)
  1.3.2 Genetik test stratejileri ve varyant yorumlama (5 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_1(builder: RetinaStudyDeckBuilder):
    """Bölüm 1'e ait 46 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1 (TOPLAM SLAYT 3): BÖLÜM 1 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=1,
        title="TEMEL BİLİMLER VE ANATOMİ",
        page_range="Sayfa 3 – 37",
        subtitle="Vitreoretinal Arayüz, Foveal Katmanlar, RPE/Bruch Kompleksi, Fototransdüksiyon ve Genetik",
        cards=[
            {
                "title": "1. Çekirdek Patofizyoloji",
                "color": PPTXPalette.BLUE,
                "lead": "Vitreus & Katman Mimarisi",
                "items": [
                    "Vitreus jelinin %98-99'u su, iskeleti Tip II/IX heterotipik kollajen ve HA ağıdır.",
                    "İLM: Müller hücre ayaksı çıkıntılarının bazal membranı olup Tip IV kollajenden zengindir.",
                    "Nörosensoryal retina 10 katmandan oluşur; foveolada iç katmanlar yana itilmiştir.",
                    "RPE bazolateral zarı ve Bruch membranı 5 tabakası dış retina dengesini kurar."
                ],
                "footer": "Yapısal Bütünlük İlkeleri"
            },
            {
                "title": "2. Biyokimya & Bariyer",
                "color": PPTXPalette.GREEN,
                "lead": "Görme Döngüsü & B-RB",
                "items": [
                    "Fototransdüksiyon: 11-cis retinalin fotonla all-trans retinale izomerizasyonudur.",
                    "Hız kısıtlayıcı basamak: RPE'deki RPE65 izomerohidrolaz enzimidir.",
                    "İç B-RB: Retinal kapiller endotel hücrelerinin sıkı bağlantıları (zonula occludens).",
                    "Dış B-RB: RPE hücreleri arasındaki apikolateral zonula occludens kompleksidir."
                ],
                "footer": "Metabolik ve Fizyolojik Denge"
            },
            {
                "title": "3. Klinik Korrelasyon",
                "color": PPTXPalette.AMBER,
                "lead": "Multimodal Biyobelirteçler",
                "items": [
                    "Elipsoid Zon (EZ): Fotoreseptör iç/dış segment bileşkesi metabolik canlığı gösterir.",
                    "Dış Sınırlayıcı Membran (ELM): Fotoreseptör-Müller bağlantısı, rejenerasyon göstergesidir.",
                    "Koryokapillaris lobüler yapısı: Foveada bağımsız heksagonal beslenme sağlar.",
                    "FAZ çapı: Sağlıklı bireylerde 0.25 - 0.40 mm² olup foveal iskemiyle genişler."
                ],
                "footer": "Görüntüleme Temelleri"
            },
            {
                "title": "4. Board & Sınav İpuçları",
                "color": PPTXPalette.PURPLE,
                "lead": "Yüksek Getirili Noktalar",
                "items": [
                    "Vitreus tabanı ora serratayı 2 mm anteriora, 3-4 mm posteriora aşar; en güçlü yapışıklıktır.",
                    "Henle lif tabakası foveada oblik seyreder; kistoid ödem ve sert eksüda petalloid dizilir.",
                    "MERTK mutasyonları RPE fagositozunu bozar ve erken başlangıçlı RP yapar.",
                    "ACMG sınıflamasında varyantlar 5 sınıfta değerlendirilir; VUS klinik kararda tek başına kullanılamaz."
                ],
                "footer": "Sınav Tuzakları & Landmarklar"
            }
        ]
    )

    # =========================================================================
    # KONU 1.1.1: VİTREUS YAPISI, KORTEKS, TABAN VE VİTREORETİNAL ARAYÜZ (5 SLAYT)
    # =========================================================================
    # Slayt 1.1.1.1: Vitreus Biyokimyasal İskeleti
    builder.add_study_card_slide(
        title="VİTREUS JELİNİN BİYOKİMYASAL VE YAPISAL İSKELETİ",
        category="BÖLÜM 1.1.1: VİTREORETİNAL ANATOMİ",
        subtitle="Su, Kollajen Ağı, Hyaluronan ve Yaşlanma Sürecinde Biyofiziksel Değişimler",
        cards=[
            {
                "card_title": "BİYOKİMYASAL MATRİS",
                "lead": "%98-99 Su ve Makromoleküller",
                "items": [
                    "Vitreus ağırlığının %98-99'unu su oluşturur; geri kalan kısmı kollajen ve hyaluronandır [s.4].",
                    "Kollajen Fibrilleri: Baskın olarak Tip II kollajen (%65-75), Tip IX ve Tip V/XI içerir [RV1:pdf569].",
                    "Hyaluronan (HA): Negatif yüklü glikozaminoglikan olup suyu bağlayarak hidrojel yapısını kurar.",
                    "Optik Saydamlık: Fibriller arasındaki düzenli mesafe görünür ışığın saçılmasını önler."
                ],
                "footer": "Tip II/IX/V Kolajen + HA Ağı"
            },
            {
                "card_title": "ANATOMİK BÖLGELER",
                "lead": "Korteks, Taban ve Kloquet Kanalı",
                "items": [
                    "Vitreus Korteksi: Retinaya komşu 100-300 μm kalınlığında yoğun kollajen tabakasıdır.",
                    "Vitreus Tabanı: Ora serrataya sıkı yapışan, önde pars planaya, arkada retinaya uzanan bölgedir [s.5].",
                    "Kloquet Kanalı: Primer vitreusun (hyaloid arter) embriyolojik kalıntısıdır.",
                    "Martegiani Alanı: Optik disk üzerindeki prepapiller potansiyel boşluktur (Weiss halkası alanı)."
                ],
                "footer": "Yoğun Korteks & Prepapiller Arayüz"
            },
            {
                "card_title": "SENİL BİYOFİZİKSEL DÖNÜŞÜM",
                "lead": "Sinerezis ve Sinkizis Kaskadı",
                "items": [
                    "Sinerezis: Yaşlanmayla hyaluronan-kollajen etkileşimi zayıflar, kollajen fibrilleri kümeler oluşturur [s.6].",
                    "Sinkizis: Jel yapısı sıvılaşır; merkezde lakün adı verilen sıvı cepleri gelişir.",
                    "Görsel Belirti: Sıvılaşan ceplerdeki fibril yumakları hastada 'uçuşan cisimler' (myodesopsia) oluşturur.",
                    "Yırtık Riski: Sıvılaşmış vitreus korteksteki defektten subhyaloid alana girerek PVD'yi tetikler."
                ],
                "footer": "Sıvılaşma -> Lakün -> PVD Kaskadı"
            }
        ]
    )

    # Slayt 1.1.1.2: Vitreoretinal Arayüz ve İLM
    builder.add_study_card_slide(
        title="VİTREORETİNAL ARAYÜZ VE İÇ SINIRLAYICI MEMBRAN (İLM)",
        category="BÖLÜM 1.1.1: VİTREORETİNAL ANATOMİ",
        subtitle="Müller Ayaksı Çıkıntıları, Tip IV Kollajen, Adezyon Molekülleri ve Cerrahi Soyma",
        cards=[
            {
                "card_title": "İLM MİKROANATOMİSİ",
                "lead": "Müller Hücre Bazal Membranı",
                "items": [
                    "İLM, tüm nörosensoryal retinanın iç yüzünü örten gerçek bir bazal membrandır [s.4].",
                    "Kompozisyon: Tip IV kollajen, laminin, fibronektin ve heparan sülfat proteoglikanlar [RV1:pdf570].",
                    "Kalınlık Dağılımı: Periferde ince (~0.5 μm), arka kutupta kalın (~2.5 μm), foveola merkezinde en incedir (~10-20 nm).",
                    "Vitreal Yüz: Pürüzsüzdür; retinal yüz ise Müller hücre ayaklarına uyumlu girintilidir."
                ],
                "footer": "Tip IV Kollajen & Laminin Matrisi"
            },
            {
                "card_title": "ADEZYON MEKANİZMASI",
                "lead": "Fibronektin ve İntegrin Bağları",
                "items": [
                    "Vitreus korteksi ile İLM arasında moleküler 'yapıştırıcı' proteinler bulunur [s.5].",
                    "Fibronektin ve Laminin: Vitreus kollajen fibrillerini İLM integrin reseptörlerine kilitler.",
                    "En Güçlü Yapışma Alanları: 1. Vitreus tabanı (en güçlü), 2. Optik disk kenarı, 3. Fovea, 4. Retinal damar boyları.",
                    "Klinik Çıkarım: Bu alanlarda PVD ayrılması sırasında traksiyonel retina yırtığı ve kanama riski en yüksektir."
                ],
                "footer": "Taban > Disk > Fovea > Damarlar"
            },
            {
                "card_title": "CERRAHİ İLM SOYMA (PEELING)",
                "lead": "Mekanik ve Biyolojik Etkiler",
                "items": [
                    "Kullanım Alanı: Makula deliği (FTMH), epiretinal membran (ERM) ve traksiyonel makulopati cerrahisi [s.6].",
                    "Cerrahi Amaç: Teğetsel (tanjansiyel) traksiyonu tamamen ortadan kaldırmak ve nüks miyofibroblast göçünü önlemek.",
                    "Boya Ajanı: Brilliant Blue G (BBG) İLM'yi seçici boyar; İndosiyanin yeşili (ICG) fototoksik risk taşır.",
                    "Biyobelirteç: İLM soyulması sonrası inner retinal dimpling (DONFL) gelişebilir, ancak santral görmeyi etkilemez."
                ],
                "footer": "BBG Boyama & Traksiyon Giderimi"
            }
        ]
    )

    # Slayt 1.1.1.3: Vitreus Tabanı ve Cerrahi Sınırlar
    builder.add_study_card_slide(
        title="VİTREUS TABANI ANATOMİSİ VE CERRAHİ GİRİŞ MESAFELERİ",
        category="BÖLÜM 1.1.1: VİTREORETİNAL ANATOMİ",
        subtitle="Ora Serrata İlişkisi, Pars Plana Boyutları ve Trokar Giriş Güvenlik Alanları",
        cards=[
            {
                "card_title": "VİTREUS TABANI GEOMETRİSİ",
                "lead": "Ora Serratayı Aşan 3 Boyutlu Halka",
                "items": [
                    "Genişlik: Ora serratanın 1.5 - 2.0 mm anterioruna (pars plana) uzanır [s.5].",
                    "Posterior Sınır: Ora serratanın 3.0 - 4.0 mm posterioruna (nazalde daha dar, temporaldedaha geniştir).",
                    "Fibril Dağılımı: Kollajen lifleri doğrudan bazal lamina içine gömülüdür; mekanik olarak ayrılamaz.",
                    "Cerrahi Prensip: Taban traksiyonu hiçbir zaman çekerek soyulamaz; yüksek kesim hızıyla tıraşlanmalıdır."
                ],
                "footer": "2 mm Anterior / 4 mm Posterior"
            },
            {
                "card_title": "PARS PLANA VE SKLEROTOMİ",
                "lead": "Limbus Merkezli Güvenli Giriş",
                "items": [
                    "Erişkin Fakik Gözler: Limbustan 3.5 - 4.0 mm geriden girilir (lens hasarını önlemek için) [RV1:pdf572].",
                    "Psödofakik / Afakik Gözler: Limbustan 3.0 - 3.5 mm geriden sklerotomi yapılır.",
                    "Pars Plicata: Limbustan ilk 2 mm'lik siliyer çıkıntılar bölgesidir; kanama riski nedeniyle delinmez.",
                    "Pars Plana: Limbustan 2.0 - 6.0 mm arası avasküler güvenli cerrahi koridordur."
                ],
                "footer": "Fakik: 3.5-4.0 mm | Psödofakik: 3.0-3.5 mm"
            },
            {
                "card_title": "KLİNİK PATOLOJİ KORRELASYONU",
                "lead": "Taban Sınırında Yırtık Dinamiği",
                "items": [
                    "Akut PVD sırasında ayrılma vitreus tabanının arka kenarında durur [s.7].",
                    "Tanjansiyel ve dinamik vektörel kuvvetler taban arka kenarında yoğunlaşır.",
                    "At Nalı Yırtık (Horseshoe Tear): Apeksi merkeze, tabanı vitreus tabanına bakan traksiyonel yırtıktır.",
                    "Diyaliz: Ora serrata boyunca retina yapışıklığının ayrılmasıdır; genellikle künt travma kökenlidir."
                ],
                "footer": "Taban Arka Kenarı = Yırtık Hattı"
            }
        ]
    )

    # Slayt 1.1.1.4: Atlas Görseli: Normal Vitreoretinal Arayüz
    img_p4 = builder.get_image_for_page(4)
    builder.add_atlas_image_slide(
        title="VİTREORETİNAL ARAYÜZ VE MAKULA MİKROANATOMİSİ ATLASI",
        category="BÖLÜM 1.1.1: GÖRSEL ATLAS",
        subtitle="SD-OKT Yüksek Çözünürlüklü Foveal Kesit, İLM Hattı ve Dış Retina Reflektivitesi",
        image_path=img_p4 or "dr_schema_1",
        caption="Referans Eser Sayfa 4: Normal Vitreoretinal Arayüz, Foveal Çukurluk ve Dış Retina Bantları",
        key_findings=[
            "Foveal Çukurluk (Foveal Pit): Eğimli kenarlarla iç retina tabakalarının foveoladan çekildiği izlenir [s.4].",
            "İLM Reflektivitesi: Vitreus boşluğu ile nörosensoryal retina arasında ince, düzgün hiperreflektif çizgi.",
            "Henle Lif Tabakası (HFL): Koni aksonlarının oblik uzanımına bağlı fovea çevresinde kalınlaşan bant.",
            "Dış Retina Dörtlüsü: ELM, Elipsoid Zon (EZ), İnterdigitasyon Zonu (IZ) ve RPE/Bruch kompleksi."
        ],
        differentials=[
            "VMT: Arka hyaloid foveaya yapışık olup çekinti ve foveal kist oluşturur.",
            "ERM: İLM yüzeyinde dalgalı, kalın hiperreflektif membran ve kırışıklık izlenir.",
            "Tam Kat Makula Deliği: Fovea merkezinde tüm katmanların anatomik defekti mevcuttur."
        ],
        clinical_pearl="İLM üzerindeki teğetsel traksiyon fovea mimarisini bozsa bile, ELM ve EZ bütünlüğü korunuyorsa cerrahi sonrası görsel prognoz mükemmeldir [RV1:pdf469]."
    )

    # Slayt 1.1.1.5: Karşılaştırmalı Analiz: Fizyolojik vs Anormal PVD
    builder.add_split_comparison_slide(
        title="ARKA VİTREUS DEKOLMANI (PVD) PATOLOJİK AYRIMI",
        category="BÖLÜM 1.1.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Fizyolojik Komplikasyonsuz PVD vs Anormal PVD ve Vitreoretinal Traksiyon Sendromları",
        left_entity={
            "name": "FİZYOLOJİK TAM PVD",
            "features": [
                ("Ayrılma Süreci", "Vitreus korteksi retinadan ve optik diskten bütünüyle, kalıntı bırakmadan ayrılır [s.6]."),
                ("Weiss Halkası", "Prepapiller glial dokuyu içeren serbest hareketli anüler opasite mevcuttur."),
                ("Retina Bütünlüğü", "Retinada yırtık, traksiyon, delik veya kanama gelişmez; retina yatışıktır."),
                ("Semptomatoloji", "Uçuşan noktacıklar ve geçici periferik ışık çakmaları (fotopsi) hızla geriler."),
                ("Yönetim", "İlk muayenede ve 4-6 hafta sonra genişletilmiş indirekt oftalmoskopi ile perifer kontrolü.")
            ]
        },
        right_entity={
            "name": "ANORMAL PVD (VITREOSCHISIS / VMT)",
            "features": [
                ("Ayrılma Süreci", "Korteks arka tabakası ayrılamaz; vitreoschisis veya makulaya inatçı fokal adezyon kalır [s.7]."),
                ("Vektörel Çekinti", "Ön-arka ve teğetsel kuvvetler foveada kistoid ödeme veya traksiyona yol açar."),
                ("Retinal Hasar", "At nalı yırtık, retina dekolmanı, vitreus kanaması veya makula deliği gelişebilir."),
                ("Semptomatoloji", "Metamorfopsi, santral skotom, ani görme kaybı veya persistan yoğun fotopsi."),
                ("Yönetim", "Yakın OKT takibi, pars plana vitrektomi ve İLM soyulması veya pnömatik vitreolizis.")
            ]
        },
        bottom_takeaway="Akut semptomatik PVD hastalarının yaklaşık %10-15'inde retina yırtığı bulunur; pigment varlığı (Shafer belirtisi) yırtık olasılığını %90'ın üzerine çıkarır [RV1:pdf571]."
    )

    # =========================================================================
    # KONU 1.1.2: NÖROSENSORYAL RETİNA KATMANLARI VE FOVEAL MİKROANATOMİ (5 SLAYT)
    # =========================================================================
    # Slayt 1.1.2.1: 10 Retina Katmanı ve Hücresel Mimarisi
    builder.add_study_card_slide(
        title="NÖROSENSORYAL RETİNANIN 10 TABAKASI VE HÜCRESEL MİMARİSİ",
        category="BÖLÜM 1.1.2: RETİNA KATMANLARI",
        subtitle="İçten Dışa Nöral Tabakalanma, Sinaptik İstasyonlar ve Glial Destek Elemanları",
        cards=[
            {
                "card_title": "İÇ RETİNA (VİTREAL TARAF)",
                "lead": "İLM'den İç Pleksiform Tabakaya",
                "items": [
                    "1. İç Sınırlayıcı Membran (İLM): Müller bazal zarı [s.7].",
                    "2. Sinir Lifi Tabakası (RNFL): Ganglion hücrelerinin miyelinsiz aksonları; arka kutupta kalındır.",
                    "3. Ganglion Hücre Katmanı (GCL): İkinci sıra nöronlar; fovea kenarında 6-8 hücre kalınlığına ulaşır.",
                    "4. İç Pleksiform Tabaka (IPL): Ganglion hücre dendritleri ile bipolar ve amakrin akson sinapsları."
                ],
                "footer": "Projeksiyon Nöronları & Aksonlar"
            },
            {
                "card_title": "ORTA RETİNA (İNTERMEDİYER)",
                "lead": "İç Nükleerden Dış Pleksiforma",
                "items": [
                    "5. İç Nükleer Tabaka (INL): Bipolar hücreler, horizontal hücreler, amakrin hücreler ve Müller çekirdekleri [s.8].",
                    "6. Dış Pleksiform Tabaka (OPL): Fotoreseptör sferül/pedikülleri ile bipolar ve horizontal hücre sinapsları.",
                    "Henle Lif Tabakası (HFL): Foveal koni aksonlarının OPL içindeki oblik uzanımıdır.",
                    "Klinik Önemi: Kistoid makula ödeminde sıvı esas olarak HFL ve INL tabakalarında toplanır."
                ],
                "footer": "Bipolar, Horizontal & Müller Gövdeleri"
            },
            {
                "card_title": "DIŞ RETİNA (KORAL TARAF)",
                "lead": "Dış Nükleerden RPE Katmanına",
                "items": [
                    "7. Dış Nükleer Tabaka (ONL): Koni ve çomak fotoreseptörlerinin çekirdekleri [s.8].",
                    "8. Dış Sınırlayıcı Membran (ELM): Fotoreseptörler ile Müller apikal uçları arasındaki zonula adherens.",
                    "9. Fotoreseptör Katmanı (IS/OS): İç segment (mitokondri zengin EZ) ve dış segment (diskler).",
                    "10. Retina Pigment Epiteli (RPE): Monokatman nöroektodermal epitel; Bruch üzerine oturur."
                ],
                "footer": "Fotoreseptör Çekirdek & Diskleri"
            }
        ]
    )

    # Slayt 1.1.2.2: Foveal Zonlar ve Boyutları
    builder.add_study_card_slide(
        title="FOVEAL MİKROANATOMİK BÖLGELER VE GEOMETRİK SINIRLAR",
        category="BÖLÜM 1.1.2: RETİNA KATMANLARI",
        subtitle="Umbo, Foveola, Fovea, Parafovea ve Perifovea Sınırlarının Klinik Önemi",
        cards=[
            {
                "card_title": "FOVEOLA VE UMBO",
                "lead": "0.35 mm Çap / Saf Koni Alanı",
                "items": [
                    "Foveola: 0.35 mm (350 μm) çapında merkezi çukurluk tabanıdır [s.8].",
                    "Umbo: Foveolanın tam merkezindeki minik mikro-çöküntüdür (foveal ışık refleksi buradan doğar).",
                    "Yalnızca Koniler: Çomak fotoreseptörü içermez; yaklaşık 200.000 koni/mm² yoğunluk vardır [RV1:pdf412].",
                    "İç Katman Yokluğu: Ganglion, bipolar ve amakrin hücreler yana itilmiştir; ışık doğrudan dış segmente ulaşır."
                ],
                "footer": "0.35 mm Çap / Saf Koni Yoğunluğu"
            },
            {
                "card_title": "FOVEA VE PARAFOVEA",
                "lead": "1.5 mm Fovea / 2.5 mm Parafovea",
                "items": [
                    "Fovea (Santral Makula): 1.5 mm çapındadır (yaklaşık 1 optik disk çapı).",
                    "Foveal Eğim (Clivus): Foveola çevresindeki eğimli kenarlardır; Henle lifleri burada belirginleşir [s.9].",
                    "Parafovea: Foveayı çevreleyen 0.5 mm genişliğinde halkadır (toplam çap 2.5 mm).",
                    "Maksimum Hücre Tabakası: GCL (6-8 sıra) ve INL parafoveada en kalın düzeyindedir."
                ],
                "footer": "Fovea: 1.5 mm | Parafovea: 2.5 mm"
            },
            {
                "card_title": "PERİFOVEA VE MAKULA LUTEA",
                "lead": "5.5 mm Makula / Lutein Pigmenti",
                "items": [
                    "Perifovea: Parafoveayı çevreleyen 1.5 mm genişliğindeki dış halkadır (toplam makula çapı 5.5 mm) [s.9].",
                    "Çomak Tepe Noktası: Fovea merkezinden 3-5 mm uzakta çomak fotoreseptör yoğunluğu zirveye ulaşır.",
                    "Makuler Karotenoidler: Lutein ve zeaksantin Henle lif tabakasında ve iç retinada yoğunlaşır.",
                    "Mavi Işık Filtresi: Ksantofil pigmenti 400-500 nm mavi ışığı emerek foveayı fototoksik hasardan korur."
                ],
                "footer": "Makula Çapı: 5.5 mm | Lutein/Zeaksantin"
            }
        ]
    )

    # Slayt 1.1.2.3: Foveal Avasküler Zon (FAZ)
    builder.add_study_card_slide(
        title="FOVEAL AVASKÜLER ZON (FAZ) VE MİKROVASKÜLER DİNAMİK",
        category="BÖLÜM 1.1.2: RETİNA KATMANLARI",
        subtitle="Yüzeyel ve Derin Kapiller Ağlar, Difüzyon Mesafesi ve İskemik Değişiklikler",
        cards=[
            {
                "card_title": "FAZ GEOMETRİSİ",
                "lead": "Sağlıklı Sınırlar ve Boyutlar",
                "items": [
                    "Sağlıklı FAZ Alanı: OKTA ölçümlerinde ortalama 0.25 - 0.40 mm² arasındadır [s.9].",
                    "Sınır Belirleyicisi: İç retinadaki kapiller arkadın foveola kenarında sonlanmasıyla oluşur.",
                    "Derin Pleksus Sınırı: Derin kapiller ağ foveaya yüzeyel ağdan biraz daha yakın sonlanır.",
                    "Bireysel Değişkenlik: Foveal çukurluğun derinliği ve retinal kalınlıkla ters orantılıdır."
                ],
                "footer": "0.25 - 0.40 mm² Normal Aralık"
            },
            {
                "card_title": "OKSİJENASYON VE BESLENME",
                "lead": "Koryokapillaristen Difüzyon",
                "items": [
                    "Foveola tamamen avasküler olduğu için oksijen ve besinini koryokapillaristen diffüzyonla alır [s.10].",
                    "Difüzyon Sınırı: Retinal kalınlık foveolada 150-180 μm'ye iner; bu koryokapillaris difüzyonu için idealdir.",
                    "İskemiye Hassasiyet: Retinal damar tıkanıklığında FAZ çevresi kapillerler kapanarak foveal beslenme riskine girer.",
                    "Müller Konisi: Foveola merkezindeki Müller hücreleri özelleşmiş yapısal destek sağlar."
                ],
                "footer": "Koryokapillaris Oksijen Difüzyonu"
            },
            {
                "card_title": "KLİNİK PATOLOJİ KORRELASYONU",
                "lead": "FAZ Genişlemesi ve Düzensizliği",
                "items": [
                    "Diyabetik Makulopati: İskemik DMÖ'de FAZ sınırları silinir, kırıklı ve genişlemiş hal alır [RV1:pdf490].",
                    "Retinal Ven Tıkanıklığı: Derin kapiller pleksustaki kapiller silinme FAZ asimetrisi oluşturur.",
                    "Prognostik Değer: FAZ alanı >0.50 mm² olduğunda görsel keskinlik potansiyeli anlamlı düzeyde düşer.",
                    "Takip Parametresi: OKTA sirkülarite indeksi (circularity) foveal iskemi takibinde altın standarttır."
                ],
                "footer": "FAZ Genişlemesi = İskemik Makulopati"
            }
        ]
    )

    # Slayt 1.1.2.4: Atlas Görseli: SD-OCT Foveal Katman Kesiti
    img_p8 = builder.get_image_for_page(8)
    builder.add_atlas_image_slide(
        title="SD-OKT FOVEAL KATMAN BİYOBELİRTEÇLERİ VE YANSIMA ATLASI",
        category="BÖLÜM 1.1.2: GÖRSEL ATLAS",
        subtitle="Hiperreflektif ve Hiporeflektif Tabakalanma, EZ Bütünlüğü ve ELM Hattı",
        image_path=img_p8 or "dr_schema_2",
        caption="Referans Eser Sayfa 8: SD-OKT Yüksek Çözünürlüklü Fovea Anatomisi ve Dış Retina Bantları",
        key_findings=[
            "RNFL/GCL Kompleksi: Fovea clivusunda belirginleşen iç retina hiperreflektif ve hiporeflektif bantları [s.8].",
            "Dış Sınırlayıcı Membran (ELM): Dış nükleer tabakanın hemen altında ince, kesintisiz hiperreflektif çizgi.",
            "Elipsoid Zon (EZ): Fotoreseptör iç segmentindeki yoğun mitokondrileri temsil eden parlak hiperreflektif bant.",
            "İnterdigitasyon Zonu (IZ): Fotoreseptör dış segment uçlarının RPE mikrovillusları içine girdiği temas hattı."
        ],
        differentials=[
            "EZ Bozulması (Disruption): Makula deliği, solar retinopati veya kloroquin toksisitesinde fokal kayıp.",
            "DRIL (Disorganization of Retinal Inner Layers): DMÖ'de iç katman sınırlarının tamamen silinmesi.",
            "HRF (Hiperreflektif Odaklar): Aktif inflamasyon veya lipid yüklü mikrogliaları temsil eden noktalar."
        ],
        clinical_pearl="Klinik çalışmalarda en iyi düzeltilmiş görme keskinliğinin (BCVA) en güçlü anatomik belirleyicisi foveal Elipsoid Zon (EZ) bütünlüğüdür [RV1:pdf411]."
    )

    # Slayt 1.1.2.5: Karşılaştırmalı Analiz: Koni vs Çomak Fotoreseptörleri
    builder.add_split_comparison_slide(
        title="FOTORESEPTÖR HÜCRE DİNAMİĞİ: KONİLER VS ÇOMAKLAR",
        category="BÖLÜM 1.1.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Sayısal Dağılım, Pigment Biyokimyası, Işık Duyarlılığı ve Hastalık Tercihi",
        left_entity={
            "name": "KONİ FOTORESEPTÖRLERİ (CONES)",
            "features": [
                ("Toplam Sayı & Dağılım", "Retinada yaklaşık 6-7 milyon koni bulunur; en yoğun foveoladadır [s.8]."),
                ("Fotopigmentler", "Opsin: Kırmızı (L-koni), Yeşil (M-koni), Mavi (S-koni) opsinleri içerir."),
                ("Işık Ortamı & Çözünürlük", "Fotopik (aydınlık) görme; yüksek mekansal çözünürlük ve renkli görme."),
                ("Adaptasyon & Kinetik", "Hızlı yanıt verir ve hızla toparlanır; doyması zordur."),
                ("Hedef Hastalıklar", "Koni distrofileri, Stargardt, YBMD (geç evre foveal tutulum).")
            ]
        },
        right_entity={
            "name": "ÇOMAK FOTORESEPTÖRLERİ (RODS)",
            "features": [
                ("Toplam Sayı & Dağılım", "Retinada yaklaşık 120 milyon çomak bulunur; foveadan 20° uzakta pik yapar [s.9]."),
                ("Fotopigmentler", "Rodopsin (11-cis retinal + skotopsin proteini)."),
                ("Işık Ortamı & Çözünürlük", "Skotopik (karanlık) görme; tek bir fotonu dahi algılayabilen aşırı duyarlılık."),
                ("Adaptasyon & Kinetik", "Yavaş yanıt verir; aydınlıkta hızla doygunluğa ulaşır (bleaching)."),
                ("Hedef Hastalıklar", "Retinitis Pigmentosa (erken niktalopi), Vitamin A eksikliği, CSNB.")
            ]
        },
        bottom_takeaway="Foveola merkezinde çomak bulunmaz; bu nedenle niktalopi (gece körlüğü) ile başlayan hastalıklarda (ör. RP) santral görme hastalığın çok geç evrelerine kadar korunur [RV1:pdf412]."
    )

    # =========================================================================
    # KONU 1.1.3: RETİNA PİGMENT EPİTELİ (RPE) VE BRUCH MEMBRANI (5 SLAYT)
    # =========================================================================
    # Slayt 1.1.3.1: RPE Hücresel Mimarisi ve Polaritesi
    builder.add_study_card_slide(
        title="RETİNA PİGMENT EPİTELİ (RPE) HÜCRESEL MİMARİSİ",
        category="BÖLÜM 1.1.3: RPE VE BRUCH",
        subtitle="Heksagonal Polarite, Apikal Mikrovilluslar, Melanozomlar ve Sıkı Bağlantılar",
        cards=[
            {
                "card_title": "HEKSAGONAL MONOKATMAN",
                "lead": "4-6 Milyon Hücrelik Epitel Örtü",
                "items": [
                    "RPE nöroektodermden köken alan tek katlı, düzenli heksagonal hücre tabakasıdır [s.10].",
                    "Hücre Yoğunluğu: Makulada hücreler daha uzun ve dardır (~14 μm); periferde geniş ve basıktır.",
                    "Mitotik Aktivite: Erişkinde RPE hücreleri G0 evresindedir; bölünmezler, ölen hücrelerin yerini komşular genişleyerek kapatır [RV1:pdf475].",
                    "Melanin Granülleri: Işığı emerek intraoküler saçılmayı önler ve serbest radikalleri nötralize eder."
                ],
                "footer": "Bölünmeyen Heksagonal Epitel"
            },
            {
                "card_title": "APİKAL VE BAZAL POLARİTE",
                "lead": "Mikrovilluslar ve Katlantılar",
                "items": [
                    "Apikal Yüz: Fotoreseptör dış segmentlerini saran uzun mikrovilluslar içerir [s.11].",
                    "Subretinal Boşluk: Gerçek bir boşluk değildir; glikozaminoglikanlardan zengin interforeseptör matris (IPM) bulunur.",
                    "Bazal Yüz: Bruch zarına oturan karmaşık bazolateral membran katlantıları (infoldings) içerir.",
                    "Yüzey Alanı: Bazal katlantılar sıvı ve iyon transportu için yüzey alanını 30 kat artırır."
                ],
                "footer": "Apikal Mikrovillus & Bazal Katlantı"
            },
            {
                "card_title": "ZONULA OCCLUDENS KOMPLEKSİ",
                "lead": "Dış Kan-Retina Bariyeri (Dış B-RB)",
                "items": [
                    "RPE hücreleri apikolateral sınırlarında zonula occludens (tight junction) ile kenetlenir [s.11].",
                    "Protein İskeleti: Claudin-1, Claudin-19, Occludin ve ZO-1 proteinlerinden oluşur.",
                    "Bariyer Görevi: Koryokapillaristen gelen protein ve büyük moleküllerin subretinal alana geçişini engeller.",
                    "Bozulma Tablosu: RPE bariyeri çöktüğünde subretinal sıvı toplanır (ör. SSKR, VKH, KNV sızıntısı)."
                ],
                "footer": "Claudin/Occludin = Dış B-RB"
            }
        ]
    )

    # Slayt 1.1.3.2: Bruch Membranının 5 Tabakası
    builder.add_study_card_slide(
        title="BRUCH MEMBRANININ 5 TABAKASI VE MOLEKÜLER YAPISI",
        category="BÖLÜM 1.1.3: RPE VE BRUCH",
        subtitle="RPE ile Koryokapillaris Arasındaki Asellüler Elek ve Yaşa Bağlı Değişimler",
        cards=[
            {
                "card_title": "5 ANATOMİK TABAKA",
                "lead": "2-4 μm Kalınlığında Asellüler Zar",
                "items": [
                    "1. RPE Bazal Membranı: Tip IV kollajen, laminin ve heparan sülfat [s.11].",
                    "2. İç Kollajenöz Tabaka: Tip I, III ve V kollajen liflerinden oluşan ağ.",
                    "3. Elastik Tabaka: Merkezde yer alan, elastinden zengin gözenekli iskelet.",
                    "4. Dış Kollajenöz Tabaka: Koryokapillarise bakan kollajen ağı.",
                    "5. Koryokapillaris Bazal Membranı: Fenestre endotelin bazal lamina örtüsü."
                ],
                "footer": "RPE Bazal - İç Kol. - Elastik - Dış Kol. - Koryo Bazal"
            },
            {
                "card_title": "FİZYOLOJİK ELEK FONKSİYONU",
                "lead": "Sıvı ve Besin Geçirgenliği",
                "items": [
                    "Bruch membranı koryokapillaristen RPE'ye besin ve oksijen difüzyonuna izin veren yarı geçirgen filtredir [s.12].",
                    "Atık Uzaklaştırma: RPE fagositoz metabolitleri ve laktat Bruch üzerinden koroid venöz sistemine geçer.",
                    "Kalsifikasyon Riski: Elastik tabaka yaşla birlikte kalsifiye olur ve lipid birikimiyle kalınlaşır.",
                    "Hidrofobik Bariyer: Biriken nötral lipidler Bruch membranını hidrofobik hale getirerek sıvı transportunu engeller."
                ],
                "footer": "Yarı Geçirgen Filtre -> Yaşla Lipidleşme"
            },
            {
                "card_title": "PATOLOJİK YIKIM VE KNV",
                "lead": "Elastik Kırıklar ve Neovaskülarizasyon",
                "items": [
                    "MMP Salınımı: İskemik RPE ve makrofajlar matriks metalloproteinazları (MMP-2, MMP-9) salgılar [s.12].",
                    "Bruch Çatlağı: Sindirilen Bruch membranında kırıklar oluşur (Angioid streaks, lak çatlakları).",
                    "KNV Girişi: Koryokapillaris endoteli bu yarıklardan geçerek RPE altına (Tip 1) veya nörosensoryal retina altına (Tip 2) ilerler.",
                    "Klinik Çıkarım: Bruch membranı bütünlüğü koroideal neovaskülarizasyona karşı en kritik mekanik kalkandır."
                ],
                "footer": "MMP Yıkımı -> Bruch Kırığı -> KNV"
            }
        ]
    )

    # Slayt 1.1.3.3: RPE İyon Kanalları ve Sıvı Pompası
    builder.add_study_card_slide(
        title="RPE İYON VE SIVI TRANSPORT MEKANİZMALARI",
        category="BÖLÜM 1.1.3: RPE VE BRUCH",
        subtitle="Na+/K+ ATPaz Pompası, Bestrofin-1 Kanalları ve Subretinal Boşluğun Kuru Kalması",
        cards=[
            {
                "card_title": "SIVI POMPALAMA SİSTEMİ",
                "lead": "Apikalden Bazale Net Akış",
                "items": [
                    "RPE subretinal alandaki sıvıyı sürekli olarak koroid yönüne doğru aktif olarak pompalar [s.12].",
                    "Pompalama Kapasitesi: Günlük yaklaşık birkaç mililitre sıvı subretinal aralıktan emilir [RV1:pdf476].",
                    "Retina Adezyonu: Bu negatif hidrostatik çekim retina dekolmanını önleyen temel fizyolojik kuvvettir.",
                    "Hipoksi Etkisi: ATP yetersizliğinde pompa yavaşlar ve subretinal sıvı birikme eğilimine girer."
                ],
                "footer": "Aktif Pompalama = Retinal Yatışıklık"
            },
            {
                "card_title": "İYON KANALLARI VE TRANSPORTERLAR",
                "lead": "Na+/K+ ATPaz ve Cl- Kanalları",
                "items": [
                    "Na+/K+ ATPaz: RPE'nin apikal membranında yer alır (çoğu epitelin aksine atipik lokalizasyon) [s.13].",
                    "K+ Kanalları (Kir7.1): Apikal membranda subretinal K+ konsantrasyonunu dengeler.",
                    "Na+/K+/2Cl- Kotransporterı (NKCC1): Apikal yüzde iyonları hücre içine taşır.",
                    "Bazolateral Cl- Çıkışı: Klor iyonunun bazolateral zardan koroid tarafına geçişi suyun transselüler akışını sürükler."
                ],
                "footer": "Apikal Na/K Pompa & Klor Akımı"
            },
            {
                "card_title": "BESTROFİN-1 VE EOG İLİŞKİSİ",
                "lead": "BEST1 Geni ve Klorür İletimi",
                "items": [
                    "Bestrofin-1 proteini RPE bazolateral membranında lokalize Ca2+ bağımlı klorür kanalıdır [s.13].",
                    "Elektrookülografi (EOG): Işık pikini oluşturan transepitelyal potansiyel değişimini bestrofin-1 yönetir.",
                    "Arden Oranı: Işık tepe / karanlık dip oranı sağlıklı bireylerde >%180-185 düzeyindedir.",
                    "Best Hastalığı: BEST1 mutasyonunda EOG Arden oranı belirgin düşer (<%150), yumurta sarısı lezyon gelişir."
                ],
                "footer": "BEST1 Mutasyonu -> Düşük Arden Oranı"
            }
        ]
    )

    # Slayt 1.1.3.4: Atlas Görseli: RPE ve Drusen Patogenezi
    img_p11 = builder.get_image_for_page(11)
    builder.add_atlas_image_slide(
        title="RPE DEKOLMANI, DRUSEN VE BRUCH BİRİKİMLERİ ATLASI",
        category="BÖLÜM 1.1.3: GÖRSEL ATLAS",
        subtitle="Sert Drusen, Yumuşak Drusen, Retiküler Psödodrusen ve PED Spektrumu",
        image_path=img_p11 or "dr_panel_0",
        caption="Referans Eser Sayfa 11: RPE Bazal Membranı Altında Drusen Birikimi ve PED Tipleri",
        key_findings=[
            "Sert Drusen: Bruch membranı iç tabakasında küçük (<63 μm), keskin sınırlı nodüler birikimler [s.11].",
            "Yumuşak Drusen: RPE bazal laminası altında biriken, >125 μm çaplı, silik sınırlı lipid ve protein göllenmeleri.",
            "Retiküler Psödodrusen (SDDs): RPE'nin apikal yüzünde, subretinal alanda toplanan hiperreflektif koniler.",
            "Drusenoid PED: Geniş confluent drusenlerin RPE tabakasını kubbemsi biçimde yukarı kaldırması."
        ],
        differentials=[
            "Seröz PED: Pakikoroid spektrumunda berrak sıvı içeren hiporeflektif RPE elevasyonu.",
            "Vaskülarize (Fibrovasküler) PED: Tip 1 KNV içeren, heterojen iç yansımalı çentikli PED.",
            "Kütiküler Drusen: FA erken fazında 'yıldızlı gökyüzü' (stars in the sky) manzarası veren sayısız minik drusen."
        ],
        clinical_pearl="Yumuşak drusenler Bruch membranını hidrofobikleştirirken, retiküler psödodrusenler koryokapillaris hipoperfüzyonunu yansıtır ve coğrafi atrofi riskini 3-4 kat artırır [RV1:pdf480]."
    )

    # Slayt 1.1.3.5: Akış Şeması: Senil Bruch Dejenerasyonundan KNV'ye
    builder.add_horizontal_flowchart_slide(
        title="BRUCH MEMBRANI YIKIMI VE KNV OLUŞUM BASAMAKLARI",
        category="BÖLÜM 1.1.3: AKIŞ ŞEMASI",
        subtitle="Biyokimyasal Lipid Birikiminden Endotelyal Filizlenmeye ve Eksüdasyona İlerleme",
        steps=[
            {
                "num": "1",
                "title": "Lipid Birikimi",
                "desc": "RPE atıklarının Bruch iç tabakasında birikmesi; hidrofobik bariyer oluşumu [s.12].",
                "status": "warning"
            },
            {
                "num": "2",
                "title": "İskemi & İnflamasyon",
                "desc": "Difüzyonun tıkanması; RPE'de hipoksi, kompleman aktivasyonu ve makrofaj göçü.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "VEGF & MMP Salınımı",
                "desc": "RPE'nin aşırı VEGF salgılaması ve matriks metalloproteinazlar ile Bruch perforasyonu.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Koryo. Filizlenme",
                "desc": "Koryokapillaris kapillerlerinin Bruch yarığından geçerek RPE altına girmesi (Tip 1 KNV).",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Eksüdasyon & Skar",
                "desc": "Kırılgan damarlardan sub-RPE/subretinal kanama, seröz sıvı ve son dönem disiform skar.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Anti-VEGF tedavisi anjiyogenezi ve vasküler permeabiliteyi baskılar; ancak altta yatan Bruch membran defektini ve koryokapillaris atrofisini tamir etmez [RV1:pdf544]."
    )

    # =========================================================================
    # KONU 1.1.4: KORYOKAPİLLARİS VE KOROİD VASKÜLER MİMARİSİ (5 SLAYT)
    # =========================================================================
    # Slayt 1.1.4.1: Koroid Damar Tabakalanması
    builder.add_study_card_slide(
        title="KOROİD VASKÜLER MİMARİSİ VE TABAKALANMA SİSTEMİ",
        category="BÖLÜM 1.1.4: KOROİD ANATOMİSİ",
        subtitle="Haller, Sattler ve Koryokapillaris Tabakaları, Damar Çapları ve Otonom İnnervasyon",
        cards=[
            {
                "card_title": "HALLER TABAKASI (DIŞ)",
                "lead": "Büyük Çaplı Koroid Damarları",
                "items": [
                    "Sklera tarafında yer alan en dış koroid tabakasıdır [s.13].",
                    "Damar Çapı: 100 - 300 μm arasında geniş çaplı venöz ve arteryel damarlar içerir.",
                    "Pakikoroid Değişikliği: Pakikoroid spektrumunda Haller damarları fokal veya diffüz genişler (pakivessel).",
                    "İç Tabakalara Bası: Genişleyen Haller venleri üzerindeki Sattler ve koryokapillarisi inceltir."
                ],
                "footer": "Büyük Damarlar (Pakivessel Alanı)"
            },
            {
                "card_title": "SATTLER TABAKASI (ORTA)",
                "lead": "Orta Çaplı Damar ve Arterioller",
                "items": [
                    "Haller ile koryokapillaris arasında yer alan ara tabakadır [s.14].",
                    "Damar Çapı: 20 - 100 μm çapında prekapiller arterioller ve toplayıcı venülleri barındırır.",
                    "Direnç Damarları: Koroid kan akımının mikrovasküler basınç regülasyonunda rol oynar.",
                    "Atrofi Süreci: Yaşlanma ve miyopide ilk incelen ve silinen tabaka genellikle Sattler tabakasıdır."
                ],
                "footer": "Orta Çaplı Besleyici Arterioller"
            },
            {
                "card_title": "KORYOKAPİLLARİS (İÇ)",
                "lead": "Tek Katlı Fenestre Kapiller Ağı",
                "items": [
                    "Bruch membranının hemen altında yer alan anastomotik dev kapiller tabakasıdır [s.14].",
                    "Geniş Lümen: 20 - 40 μm lümen çapı (eritrositlerin yan yana 2-3 sıra geçebileceği genişlikte) [RV1:pdf477].",
                    "Yüksek Fenestrasyon: Endotelyal pencereler (diyaframlı fenestralar) Bruch yönüne bakar.",
                    "Vücudun En Yüksek Akımı: Gram doku başına vücuttaki en yüksek kan akım hızına sahip yataktır."
                ],
                "footer": "20-40 μm Lümen & Yüksek Fenestrasyon"
            }
        ]
    )

    # Slayt 1.1.4.2: Koryokapillaris Lobüler Mimarisi
    builder.add_study_card_slide(
        title="KORYOKAPİLLARİS LOBÜLER MİMARİSİ VE SUBFOVEAL BESLENME",
        category="BÖLÜM 1.1.4: KOROİD ANATOMİSİ",
        subtitle="Heksagonal Fonksiyonel Üniteler, Merkezi Besleyici Arteriol ve Periferik Drenaj",
        cards=[
            {
                "card_title": "LOBÜLER ORGANİZASYON",
                "lead": "Heksagonal Fonksiyonel Adacıklar",
                "items": [
                    "Koryokapillaris homojen bir örtü değil; bağımsız lobüllerden oluşan heksagonal mozaiktir [s.14].",
                    "Santral Besleme: Her lobülün merkezinden tek bir terminal arteriol girer [RV1:pdf478].",
                    "Periferik Toplama: Kan lobülün çevresindeki halkasal venöz kanallara radyal olarak dağılır.",
                    "Lobül Çapı: Foveada küçük ve yoğun (~200 μm), periferde geniş ve gevşektir (~600-1000 μm)."
                ],
                "footer": "Merkezi Arteriol -> Çevresel Venül"
            },
            {
                "card_title": "SUBFOVEAL KORUYUCU DİNAMİK",
                "lead": "Yüksek Perfüzyon ve Termoregülasyon",
                "items": [
                    "Oksijen Ekstraksiyonu: Koroid kan akımı o kadar hızlıdır ki arteriyo-venöz O2 farkı yalnızca %3-5'tir [s.15].",
                    "Fovea Oksijenasyonu: Yüksek debi foveola için difüzyon basıncını sürekli maksimumda tutar.",
                    "Termoregülasyon (Soğutma Kulesi): Foveada toplanan yoğun ışık enerjisinin yarattığı ısıyı koroid kanı dağıtır.",
                    "İskemiye Direnç: Tek bir lobül tıkandığında yan lobüllerden sınırlı kollateral akım sağlanabilir."
                ],
                "footer": "Düşük O2 Ekstraksiyonu (%3-5) & Isı Dağıtımı"
            },
            {
                "card_title": "KLİNİK PATOFİZYOLOJİ",
                "lead": "Lobüler İskemi ve Enfarktlar",
                "items": [
                    "Elschnig Lekeleri: Malign hipertansiyonda tekil koryokapillaris lobül enfarktına bağlı gelişen lezyonlardır [s.15].",
                    "Siegrist Çizgileri: Arteryel skleroz boyunca koroid damarlarını izleyen pigmente çizgilenmelerdir.",
                    "SSKR Patogenezi: Lobüler venöz konjesyon ve koryokapillaris hiperpermeabilitesi RPE'yi patlatır.",
                    "OKTA Tespiti: Akım boşlukları (flow voids) koryokapillaris iskemi veya dökülmesini doğrudan gösterir."
                ],
                "footer": "Lobül Enfarktı = Elschnig / Flow Void"
            }
        ]
    )

    # Slayt 1.1.4.3: Vorteks Venleri ve Venöz Drenaj
    builder.add_study_card_slide(
        title="VORTİKOZ VEN SİSTEMİ VE KOROYİDAL VENÖZ DRENAJ",
        category="BÖLÜM 1.1.4: KOROİD ANATOMİSİ",
        subtitle="4 Kadran Vorteks Ampullaları, Ekvator Mesafeleri ve Cerrahi Koruma",
        cards=[
            {
                "card_title": "4 KADRAN DRENAJ SİSTEMİ",
                "lead": "Ampulla ve Çıkış Delikleri",
                "items": [
                    "Koroidin tüm venöz kanı 4 (bazen 5-8) ana vorteks veniyle drene edilir [s.15].",
                    "Kadran Ayrımı: Üst-temporal, alt-temporal, üst-nazal ve alt-nazal vorteks venleri.",
                    "Ampulla Yapısı: Ekvatorun hemen arkasında venöz kanalların genişleyerek oluşturduğu toplanma havuzudur.",
                    "Çıkış Yolu: Sklera içinde oblik tüneller (emissary) geçerek oftalmik vene dökülürler."
                ],
                "footer": "4 Kadran / Ekvator Arkası Ampullalar"
            },
            {
                "card_title": "CERRAHİ ANATOMİK LANDMARK",
                "lead": "Ekvatordan 2.5 - 3.5 mm Geride",
                "items": [
                    "Sklera Çökertme Cerrahisi: Bant ve plöjet yerleştirilirken vorteks ven çıkışları zedelenmemelidir [s.16].",
                    "Mesafe: Vorteks ven çıkışları rektus kas insersiyonlarının yaklaşık 6-8 mm gerisinde yer alır.",
                    "Bası Komplikasyonu: Aşırı sıkı dairesel serklaj bantları vorteks venlerini tıkayabilir.",
                    "Sonuç: Koroidal effüzyon, ön segment iskemisi ve refrakter yüksek göz içi basıncı gelişebilir."
                ],
                "footer": "Serklajda Ven Tıkanıklığı Riski"
            },
            {
                "card_title": "PAKİKORİD VE ASİMETRİK DRENAJ",
                "lead": "Venöz Anastomoz Gelişimi",
                "items": [
                    "Yeni Bilimsel Konsensus: Pakikoroid hastalıklarında primer sorun vorteks ven çıkış darlığıdır [s.16].",
                    "Konjesyon: Üst veya alt vorteks veni tıkandığında kadranlar arası kompansatuar kollateraller açılır.",
                    "Optik Disk ve Makula Üzerinden Geçiş: Genişlemiş koroid venleri watershed zonunu aşarak şant yapar.",
                    "Geniş Açılı İndosiyanin (UWF-ICG): Bu venöz aşırı yükü ve tıkanıklıkları net biçimde kanıtlar."
                ],
                "footer": "Vorteks Ven Konjesyonu -> Pakikoroid"
            }
        ]
    )

    # Slayt 1.1.4.4: Atlas Görseli: Koroid Vasküler Katmanları ve EDI-OKT
    img_p16 = builder.get_image_for_page(16)
    builder.add_atlas_image_slide(
        title="EDI-OKT İLE KOROİD DAMAR TABAKALARININ ANALİZİ",
        category="BÖLÜM 1.1.4: GÖRSEL ATLAS",
        subtitle="Enhanced Depth Imaging (EDI) ile Koroid Kalınlığı ve Subfoveal Vasküler İndeks",
        image_path=img_p16 or "dr_schema_0",
        caption="Referans Eser Sayfa 16: EDI-OKT Kesitinde Haller, Sattler ve Koryokapillaris Ayrımı",
        key_findings=[
            "Subfoveal Koroid Kalınlığı (SFCT): Genç erişkinde ortalama 250 - 350 μm arasındadır [s.16].",
            "Koryo-Skleral Bileşke: EDI-OKT ile koroid damarlarının bittiği iç sklera sınırı net izlenir.",
            "Lümen/Stroma Oranı: Koroidal vaskülarite indeksi (CVI) ortalama %65 civarındadır.",
            "Fizyolojik Değişkenlik: Aksiyel uzunluk arttıkça (miyopi) ve yaş ilerledikçe koroid belirgin incelir."
        ],
        differentials=[
            "Pakikoroid (>350-400 μm): Genişlemiş Haller venleri ve koryokapillaris incelmesi izlenir.",
            "Miyopik Koroid (<100 μm): Koryosikleral sınır neredeyse RPE'ye bitişir; damar tabakaları seçilemez.",
            "Vogt-Koyanagi-Harada: Diffüz stromal inflamasyona bağlı koroid kalınlığı 800-1000 μm'ye fırlar."
        ],
        clinical_pearl="Subfoveal koroid kalınlığı diurnal ritim gösterir; sabah saatlerinde en kalın, akşam saatlerinde yaklaşık 20-30 μm daha incedir [RV1:pdf479]."
    )

    # Slayt 1.1.4.5: Karşılaştırmalı Analiz: Retinal Damarlar vs Koryokapillaris
    builder.add_split_comparison_slide(
        title="RETİNAL KAPİLLERLER VS KORYOKAPİLLARİS VASKÜLER DİNAMİĞİ",
        category="BÖLÜM 1.1.4: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Endotelyal Geçirgenlik, Otonom İnnervasyon, Otoregülasyon ve Patolojik Yanıtlar",
        left_entity={
            "name": "RETİNAL KAPİLLERLER (İÇ SİSTEM)",
            "features": [
                ("Endotel Mimarisi", "Fenestrasız endotel hücreleri; zonula occludens ile sıkı kenetlidir [s.16]."),
                ("Perisit Dağılımı", "1:1 perisit/endotel oranı; endoteli çepeçevre sararak destekler."),
                ("Otoregülasyon", "Mükemmel otoregülasyon; pO2 ve pCO2 değişimlerine göre damar çapı ayarlanır."),
                ("Otonom Sinir Sistemi", "Otonom innervasyonu yoktur; kan akımını lokal retinal metabolizma yönetir."),
                ("Bariyer Özelliği", "İç Kan-Retina Bariyerini (İç B-RB) kurar; floresein sızdırmaz.")
            ]
        },
        right_entity={
            "name": "KORYOKAPİLLARİS (DIŞ SİSTEM)",
            "features": [
                ("Endotel Mimarisi", "Yüksek oranda fenestredir; 60-80 nm çaplı pencereler Bruch zarına bakar [s.16]."),
                ("Perisit Dağılımı", "Perisitler seyrektir ve yalnızca damarın sklera tarafında yer alır."),
                ("Otoregülasyon", "Otoregülasyonu son derece zayıftır; kan akımı perfuzyon basıncına bağımlıdır."),
                ("Otonom Sinir Sistemi", "Sempatik (vazokonstriksiyon) ve parasempatik (vazodilatasyon) yoğun innervasyon."),
                ("Bariyer Özelliği", "Bariyer özelliği yoktur; protein ve floreseine serbestçe geçirgendir.")
            ]
        },
        bottom_takeaway="Floresein anjiyografisinde koroid saniyeler içinde parlak hiperflöresans verirken (koroidal dolum), retinal damarların sızıntı yapmaması bu yapısal bariyer farkının doğrudan sonucudur [RV1:pdf480]."
    )

    # =========================================================================
    # KONU 1.2.1: FOTOTRANSDÜKSİYON KASKADI VE GÖRME DÖNGÜSÜ (5 SLAYT)
    # =========================================================================
    # Slayt 1.2.1.1: Karanlık Akımı ve Biyofiziksel Denge
    builder.add_study_card_slide(
        title="FOTORESEPTÖR KARANLIK AKIMI VE MEMBRAN POLARİZASYONU",
        category="BÖLÜM 1.2.1: RETİNA BİYOKİMYASI",
        subtitle="cGMP Bağımlı Katyon Kanalları, Na+/Ca2+ Akımı ve İstirahat Depolarizasyonu",
        cards=[
            {
                "card_title": "KARANLIKTA DEPOLARİZASYON",
                "lead": "-40 mV İstirahat Membran Potansiyeli",
                "items": [
                    "Çoğu nöronun aksine, fotoreseptörler karanlıkta uyarılmış (depolarize) durumdadır [s.17].",
                    "İstirahat Potansiyeli: Yaklaşık -40 mV düzeyindedir (diğer nöronlara göre daha pozitif).",
                    "cGMP Varlığı: Sitoplazmada yüksek konsantrasyonda cGMP bulunur.",
                    "Açık Kanallar: cGMP dış segment membranındaki CNG (siklik nükleotid kapılı) katyon kanallarını açık tutar."
                ],
                "footer": "Karanlık = Yüksek cGMP & Açık Kanallar"
            },
            {
                "card_title": "KARANLIK AKIMI DÖNGÜSÜ",
                "lead": "Na+ Girişi ve ATPaz Tahliyesi",
                "items": [
                    "Katyon Girişi: Açık CNG kanallarından sürekli Na+ ve Ca2+ iyonları dış segmente akar [s.17].",
                    "İç Segment Pompası: Giren Na+ iyonları iç segmentteki Na+/K+ ATPaz pompasıyla dışarı atılır.",
                    "Sürekli Devridaim: Bu döngüye fotoreseptör 'karanlık akımı' (dark current) adı verilir.",
                    "Enerji Tüketimi: Karanlık akımını sürdürmek muazzam ATP tüketir; mitokondriler bu yüzden iç segmentte yoğunlaşmıştır."
                ],
                "footer": "Muazzam Enerji Tüketen Sürekli Akım"
            },
            {
                "card_title": "SÜREKLİ GLUTAMAT SALINIMI",
                "lead": "Tersine Sinaptik İletim Prensibi",
                "items": [
                    "Karanlıkta depolarize kalan fotoreseptör sinapsından sürekli glutamat nörotransmitteri salgılanır [s.18].",
                    "İki Tip Bipolar Hücre: ON-bipolarlar mGluR6 ile glutamat tarafından inhibe edilir.",
                    "OFF-bipolarlar: İyonotropik reseptörlerle glutamat tarafından aktive edilir.",
                    "Işık Uyarısı: Işık düştüğünde glutamat salınımı kesilir; böylece ON-bipolarlar üzerindeki fren kalkar."
                ],
                "footer": "Karanlık: Glutamat Var | Işık: Glutamat Yok"
            }
        ]
    )

    # Slayt 1.2.1.2: Biyokimyasal Kaskad: Foton Absorpsiyonundan Kapanmaya
    builder.add_study_card_slide(
        title="FOTOTRANSDÜKSİYON BİYOKİMYASAL AMPLİFİKASYON KASKADI",
        category="BÖLÜM 1.2.1: RETİNA BİYOKİMYASI",
        subtitle="Rodopsin İzoformları, Transdusin (Gt), Fosfodiesteraz-6 (PDE6) ve Hiperpolarizasyon",
        cards=[
            {
                "card_title": "FOTON ABSORPSİYONU",
                "lead": "11-cis Retinalden all-trans Retinale",
                "items": [
                    "Foton rodopsin içindeki 11-cis retinale çarpar; pikosaniyeler içinde all-trans retinale izomerize olur [s.18].",
                    "Konformasyonel Değişim: Opsin proteini şekil değiştirerek aktif ara ürün Metarodopsin II'ye dönüşür.",
                    "Amplifikasyon 1: Tek bir Metarodopsin II molekülü yüzlerce transdusin (Gt) G-proteinini aktive eder.",
                    "Klinik Önemi: Biyokimyasal sinyal basamaklı amplifikasyonla devasa boyuta ulaştırılır."
                ],
                "footer": "Foton -> Meta II -> Yüzlerce Gt"
            },
            {
                "card_title": "PDE6 VE cGMP HİDROLİZİ",
                "lead": "Saniyede Binlerce cGMP Yıkımı",
                "items": [
                    "Aktif Transdusin α-alt birimi fosfodiesteraz-6'nın (PDE6) inhibitör γ-alt birimini serbest bırakır [s.18].",
                    "PDE6 Aktivasyonu: Aktifleşen PDE6 saniyede binlerce cGMP molekülünü 5'-GMP'ye hidrolize eder.",
                    "cGMP Düşüşü: Sitoplazmadaki serbest cGMP konsantrasyonu hızla tabana vurur.",
                    "Genetik Defekt: PDE6B mutasyonları otozomal resesif Retinitis Pigmentosanın klasik nedenidir."
                ],
                "footer": "Aktif PDE6 -> cGMP Düşüşü"
            },
            {
                "card_title": "KANAL KAPANMASI VE HİPERPOLARİZASYON",
                "lead": "-70 mV'a Kayma ve Sinyal İletimi",
                "items": [
                    "cGMP ayrılan CNG katyon kanalları hızla kapanır [s.19].",
                    "Na+ ve Ca2+ Girişinin Durması: Hücre içine pozitif iyon girişi kesilirken K+ çıkışı sürer.",
                    "Hiperpolarizasyon: Hücre içi potansiyeli -40 mV'tan -70 mV'a doğru hiperpolarize olur.",
                    "Sonuç: Sinapstaki voltaj-kapılı kalsiyum kanalları kapanır ve glutamat salınımı durur."
                ],
                "footer": "Kanal Kapanması -> -70 mV Hiperpolarizasyon"
            }
        ]
    )

    # Slayt 1.2.1.3: Klasik Retinoid Görme Döngüsü
    builder.add_study_card_slide(
        title="RETİNOİD (GÖRME) DÖNGÜSÜ VE ENZİMATİK BASAMAKLAR",
        category="BÖLÜM 1.2.1: RETİNA BİYOKİMYASI",
        subtitle="Fotoreseptör Dış Segmenti ile RPE Arasındaki Karşılıklı Vitamin A Metabolizması",
        cards=[
            {
                "card_title": "FOTORESEPTÖR FAZI",
                "lead": "all-trans Retinalden Retinole",
                "items": [
                    "Işıkla ayrılan all-trans retinal disk lümenine geçer [s.19].",
                    "ABCA4 Transporterı: All-trans retinali disk zarından sitoplazmaya pompalayan ATP-bağımlı 'flippase'dir.",
                    "İndirgenme: all-trans retinal dehidrogenaz (RDH8) ile all-trans retinole (Vitamin A) indirgenir.",
                    "Taşınma: IRBP (İnterfotoreseptör Retinoid Bağlayıcı Protein) eşliğinde subretinal aralıktan RPE'ye taşınır."
                ],
                "footer": "ABCA4 Flippase -> all-trans Retinol"
            },
            {
                "card_title": "RPE FAZI (ENZİMATİK)",
                "lead": "LRAT ve RPE65 İzomerohidrolaz",
                "items": [
                    "Esterifikasyon: RPE içine giren retinol LRAT enzimiyle all-trans retinil esterlere dönüştürülür [s.20].",
                    "Depolama: Retinil esterler RPE'de retinozom adı verilen lipit damlacıklarında depolanır.",
                    "İzomerizasyon (RPE65): Retinil esterleri 11-cis retinole çeviren hız kısıtlayıcı anahtar enzimdir.",
                    "Oksidasyon: 11-cis retinol RDH5 ile 11-cis retinale oksitlenir ve fotoreseptöre geri gönderilir."
                ],
                "footer": "LRAT -> RPE65 -> RDH5 -> 11-cis Retinal"
            },
            {
                "card_title": "KLİNİK GENETİK BOZUKLUKLAR",
                "lead": "Döngü Enzimlerinin Hastalıkları",
                "items": [
                    "ABCA4 Mutasyonu: All-trans retinal diskte birikir, toksik A2E ve lipofuskine dönüşür -> Stargardt Hastalığı [s.20].",
                    "RPE65 Mutasyonu: 11-cis retinal üretilemez; rodopsin yenilenemez -> Leber Konjenital Amaurozu (LCA2).",
                    "Gen Tedavisi: Voretigene neparvovec (Luxturna) doğrudan sağlam RPE65 genini RPE'ye iletir.",
                    "RDH5 Mutasyonu: 11-cis retinol oksitlenemez -> Fundus Albipunctatus (gece körlüğü)."
                ],
                "footer": "ABCA4: Stargardt | RPE65: LCA2 (Luxturna)"
            }
        ]
    )

    # Slayt 1.2.1.4: Atlas Görseli: Retinoid Döngüsü ve Biyokimya
    img_p19 = builder.get_image_for_page(19)
    builder.add_atlas_image_slide(
        title="GÖRME DÖNGÜSÜ ENZİM KASKADI VE MOLEKÜLER ŞEMA ATLASI",
        category="BÖLÜM 1.2.1: GÖRSEL ATLAS",
        subtitle="Fotoreseptör-RPE Transselüler Trafiği, IRBP Taşıyıcılığı ve Toksik Yan Ürünler",
        image_path=img_p19 or "dr_schema_1",
        caption="Referans Eser Sayfa 19: Retinoid Döngüsü, RPE65 Enzimatik Dönüşümü ve A2E Birikimi",
        key_findings=[
            "Transselüler Mekik: 11-cis retinal ve all-trans retinolün IPM üzerinden çift yönlü hareketi [s.19].",
            "ABCA4 Fonksiyonu: Zardaki fosfatidiletanolamin (PE) ile birleşen N-retiniliden-PE kompleksini çevirir.",
            "RPE65 Lokalizasyonu: RPE düz endoplazmik retikulumunda konuşlu 65 kDa ağırlığında enzim.",
            "A2E Oluşumu: ABCA4 yetmezliğinde serbest kalan retinal moleküllerinin birleşmesiyle oluşan bisretinoid."
        ],
        differentials=[
            "Stargardt: FAF'ta makulada hiper/hipootofloresan benekler (flecks) ve santral atrofi.",
            "LCA2: Erken çocuklukta nistagmus, amaurozis ve tamamen sönük ERG dalgaları.",
            "Vitamin A Eksikliği: Serum retinol düşüklüğüne bağlı rodopsin rejenerasyon durması ve Bitot lekeleri."
        ],
        clinical_pearl="Voretigene neparvovec (Luxturna) onay alan ilk in vivo insan gen tedavisidir; hastada yeterli canli retinal hücre (OCT'de korunmuş retina kalınlığı >100 μm) varlığında uygulanabilir [s.21]."
    )

    # Slayt 1.2.1.5: Karşılaştırmalı Analiz: Çomak vs Koni Görme Döngüsü
    builder.add_split_comparison_slide(
        title="GÖRME DÖNGÜSÜ YOLAKLARI: KANONİK (RPE) VS ALTERNATİF (MÜLLER)",
        category="BÖLÜM 1.2.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Çomakların Yavaş RPE Döngüsü vs Konilerin Hızlı Müller Hücre Destekli İntraretinal Döngüsü",
        left_entity={
            "name": "ÇOMAK KANONİK DÖNGÜSÜ (RPE BAĞIMLI)",
            "features": [
                ("Hücresel Ortak", "Yalnızca RPE hücreleri ile fotoreseptör arasında gerçekleşir [s.20]."),
                ("Kinetik Hız", "Yavaştır; tam karanlık adaptasyonu yaklaşık 30-45 dakika sürer."),
                ("Kilit Enzim", "RPE65 izomeraz enzimine mutlak bağımlıdır."),
                ("Taşıyıcı Protein", "IRBP interfotoreseptör matriste difüzyonu sağlar."),
                ("Işık Rejimi", "Skotopik (gece) görme ve düşük ışık koşullarında esastır.")
            ]
        },
        right_entity={
            "name": "KONİ ALTERNATİF DÖNGÜSÜ (MÜLLER BAĞIMLI)",
            "features": [
                ("Hücresel Ortak", "Müller glial hücreleri ile koni fotoreseptörleri arasındadır [s.21]."),
                ("Kinetik Hız", "Çok hızlıdır; parlak ışıkta konilerin saniyeler içinde toparlanmasını sağlar."),
                ("Kilit Enzim", "RPE65 gerektirmez; Müller hücresindeki koni izomerazı kullanılır."),
                ("Taşınan Molekül", "11-cis retinol olarak salınır, koni hücresi içinde 11-cis retinale oksitlenir."),
                ("Işık Rejimi", "Sürekli fotopik aydınlıkta konilerin doymadan (bleaching) çalışmasını sürdürür.")
            ]
        },
        bottom_takeaway="Konilerin Müller hücreleri üzerinden çalışan bağımsız bir görme döngüsüne sahip olması, RPE65 mutasyonu olan hastalarda koni fonksiyonlarının neden çomaklara göre daha uzun süre korunduğunu açıklar [RV1:pdf412]."
    )

    # =========================================================================
    # KONU 1.2.2: KAN-RETİNA BARİYERLERİ (B-RB) VE TRANSPORT (5 SLAYT)
    # =========================================================================
    # Slayt 1.2.2.1: İç Kan-Retina Bariyeri (İç B-RB)
    builder.add_study_card_slide(
        title="İÇ KAN-RETİNA BARİYERİ (İÇ B-RB) VE ENDOTELYAL KENETLENME",
        category="BÖLÜM 1.2.2: KAN-RETİNA BARİYERLERİ",
        subtitle="Endotel Sıkı Bağlantıları, Perisit Bütünlüğü, Astrosit Ayakları ve Bozulma Mekanizmaları",
        cards=[
            {
                "card_title": "SIKI BAĞLANTI (TIGHT JUNCTION)",
                "lead": "Claudin-5, Occludin ve ZO-1",
                "items": [
                    "İç B-RB retinal kapiller endotel hücrelerinin apikal kenetlenmesiyle kurulur [s.22].",
                    "Claudin-5: Paraselüler iyon ve küçük molekül geçişini engelleyen birincil bariyer proteinidir.",
                    "Occludin ve ZO-1: Zardaki claudinleri aktin hücre içi iskeletine bağlayan adaptörlerdir.",
                    "Elektriksel Direnç: Retinal endotel kan-beyin bariyeri gibi son derece yüksek transepitelyal dirence sahiptir."
                ],
                "footer": "Claudin-5 / Occludin Kenetlenmesi"
            },
            {
                "card_title": "NÖROVASKÜLER ÜNİTE",
                "lead": "Perisitler ve Glial Ayaklar",
                "items": [
                    "Perisitler: Retinal kapillerlerde endotel başına 1 perisit düşer (tüm vücuttaki en yüksek oran) [s.22].",
                    "PDGF-B/PDGFR-β Yolağı: Perisitlerin damar duvarına tutunmasını ve bariyer stabilitesini yönetir.",
                    "Astrosit ve Müller Ayakları: Damarı dıştan çepeçevre sararak bazal laminayı ve bariyeri destekler.",
                    "Mikroglial Gözetim: Nörovasküler ünite çevresinde immünolojik nöbet tutar."
                ],
                "footer": "1:1 Perisit Oranı & Glial Destek"
            },
            {
                "card_title": "BARİYER BOZULMASI VE SIZINTI",
                "lead": "VEGF, Angiopoietin ve İnflamasyon",
                "items": [
                    "VEGF-A: VEGFR-2 üzerinden Occludin ve VE-cadherin fosforilasyonunu tetikleyerek sıkı bağlantıları çözer [s.23].",
                    "Perisit Kaybı: Diyabette erken perisit apoptozu mikroanevrizma ve sızıntı odaklarını başlatır.",
                    "Angiopoietin Dengesi: Ang-1 bariyeri stabilize ederken, Ang-2 Tie-2 reseptörünü bloke ederek sızıntıyı artırır.",
                    "Klinik Tablo: Plazma proteinleri ve suyun retinaya sızması kistoid makula ödemi (DMÖ, RVO) ile sonuçlanır."
                ],
                "footer": "VEGF-A / Ang-2 -> Sıkı Bağlantı Çözülmesi"
            }
        ]
    )

    # Slayt 1.2.2.2: Dış Kan-Retina Bariyeri (Dış B-RB)
    builder.add_study_card_slide(
        title="DIŞ KAN-RETİNA BARİYERİ (DIŞ B-RB) VE RPE İZOLASYONU",
        category="BÖLÜM 1.2.2: KAN-RETİNA BARİYERLERİ",
        subtitle="RPE Zonula Occludens Kompleksi, Koryokapillaristen İzolasyon ve Bozulma Sonuçları",
        cards=[
            {
                "card_title": "RPE APİKOLATERAL KENETLENME",
                "lead": "Paraselüler Geçirimsiz Kuşak",
                "items": [
                    "Dış B-RB, monokatman RPE hücrelerinin apikolateral zarındaki zonula occludens kompleksidir [s.23].",
                    "Moleküler Yapı: Claudin-1, Claudin-19, JAM (Junctional Adhesion Molecules) ve Occludin [RV1:pdf476].",
                    "Fenestre Koryo Koruyucusu: Koryokapillaristen serbestçe sızan zengin plazma sıvısının retinaya geçişini durdurur.",
                    "Seçici Geçirgenlik: Besinler ve iyonlar yalnızca transselüler (taşıyıcılar ve pompalarla) geçebilir."
                ],
                "footer": "Claudin-19 & Occludin Zonu"
            },
            {
                "card_title": "BARİYERİN YIKILMA MEKANİZMASI",
                "lead": "İskemi, İnflamasyon ve Mekanik Yırtılma",
                "items": [
                    "Koryokapillaris Hiperfüzyonu: Pakikoroid durumunda hidrostatik basınç RPE bariyerini zorlar [s.24].",
                    "Sitokin Fırtınası: TNF-α ve IFN-γ RPE sıkı bağlantı proteinlerinin ekspresyonunu baskılar (ör. VKH, üveit).",
                    "RPE Mikroyırtığı: Basınç artışıyla zonula occludens açıldığında 'patlama bacası' (smokestack) sızıntısı başlar.",
                    "Subretinal Göllenme: Nörosensoryal retina ile RPE arasındaki potansiyel boşluğa seröz sıvı dolar."
                ],
                "footer": "Basınç / İnflamasyon -> Sızıntı Bacası"
            },
            {
                "card_title": "KLİNİK ENTİTELER VE KORRELASYON",
                "lead": "SSKR, VKH ve Neovaskülarizasyon",
                "items": [
                    "Santral Seröz Koryoretinopati (SSKR): Fokal Dış B-RB kırılmasına bağlı nörosensoryal dekolman [s.24].",
                    "Vogt-Koyanagi-Harada (VKH): Diffüz RPE bariyer çöküşüyle çok odaklı büllöz eksüdatif retina dekolmanı.",
                    "Tip 2 KNV: Neovasküler damarlar Dış B-RB'yi fiziksel olarak delip subretinal alana ulaşmıştır.",
                    "FA Patern: Dış B-RB hasarında erken fazda fokal parlak nokta, geç fazda subretinal alana göllenme (pooling)."
                ],
                "footer": "SSKR & VKH = Dış B-RB Yıkımı"
            }
        ]
    )

    # Slayt 1.2.2.3: Retinal Glukoz ve Metabolit Transportu
    builder.add_study_card_slide(
        title="RETİNAL GLUKOZ, SU VE AMİNOASİT TRANSPORT SİSTEMLERİ",
        category="BÖLÜM 1.2.2: KAN-RETİNA BARİYERLERİ",
        subtitle="GLUT-1 Taşıyıcılığı, Aquaporin-4 (AQP4) Su Kanalları ve Laktat Klirensi",
        cards=[
            {
                "card_title": "GLUT-1 GLUKOZ TAŞIYICISI",
                "lead": "Yüksek Enerji Talebinin Karşılanması",
                "items": [
                    "Retina beyin dokusundan bile daha yüksek glukoz tüketim hızına sahiptir [s.24].",
                    "GLUT-1 Dağılımı: Retinal kapiller endotelinin hem lümen hem ablümen zarında yoğun eksprese edilir.",
                    "RPE GLUT-1: Koryokapillaristen gelen glukoz RPE bazalinden apikaline GLUT-1 ile taşınır.",
                    "Kolaylaştırılmış Difüzyon: Enerji harcamadan konsantrasyon farkına göre sürekli glukoz akışı sağlanır."
                ],
                "footer": "Endotel & RPE'de Çift Taraflı GLUT-1"
            },
            {
                "card_title": "AQUAPORİN SU KANALLARI (AQP4)",
                "lead": "Müller Hücresi Su Tahliye Pompası",
                "items": [
                    "Aquaporin-4 (AQP4): Müller hücrelerinin retinal damarlara ve İLM'ye bakan ayaklarında kümelenir [s.25].",
                    "Osmotik Su Hareketi: Retinada metabolik aktivite sonucu üretilen su AQP4 kanallarıyla damarlara aktarılır.",
                    "Potasyum Eşlenmesi (Kir4.1): Su atılımı Kir4.1 potasyum kanallarıyla fonksiyonel olarak kenetlidir.",
                    "İskemik Şişme: İskemide Kir4.1/AQP4 dengesi bozulur, Müller hücreleri sitotoksik olarak şişer."
                ],
                "footer": "AQP4 & Kir4.1 = Sıvı/Potasyum Dengesi"
            },
            {
                "card_title": "WARBURG ETKİSİ VE LAKTAT",
                "lead": "Aerobik Glikoliz ve Klirens",
                "items": [
                    "Fotoreseptörler bol oksijen varlığında dahi glukozu laktata fermente eder (aerobik glikoliz / Warburg etkisi) [s.25].",
                    "Monokarboksilat Taşıyıcıları (MCT): MCT1 ve MCT3 RPE hücrelerinde laktat taşınmasını yönetir.",
                    "Metabolik İşbölümü: Fotoreseptörlerin ürettiği laktatı RPE yakıt olarak kullanarak glukozu retinaya bırakır.",
                    "Doku Asidozu: İskemide laktat birikimi hücre içi pH'yı düşürerek apoptozu tetikler."
                ],
                "footer": "Warburg Etkisi & MCT Laktat Klirensi"
            }
        ]
    )

    # Slayt 1.2.2.4: Atlas Görseli: B-RB Yıkımı ve Floresein Sızıntısı
    img_p24 = builder.get_image_for_page(24)
    builder.add_atlas_image_slide(
        title="KAN-RETİNA BARİYER YIKIMI VE FLORESEİN SIZINTI ATLASI",
        category="BÖLÜM 1.2.2: GÖRSEL ATLAS",
        subtitle="İç B-RB Bozulması (Vasküler Kaçak) vs Dış B-RB Bozulması (Subretinal Göllenme)",
        image_path=img_p24 or "dr_panel_1",
        caption="Referans Eser Sayfa 24: İç ve Dış B-RB Bozulmasında Floresein Kaçak ve Boyanma Dinamiği",
        key_findings=[
            "Retinal Kapiller Kaçağı: İç B-RB yıkımında floresanın damar dışına diffüz sızması ve dokuyu boyaması [s.24].",
            "Petalloid Sızıntı: Foveada Henle lif tabakasının anatomik yönelimine bağlı kistoid kavitelerde yıldızsı patern.",
            "Subretinal Göllenme (Pooling): Dış B-RB hasarında anatomik potansiyel boşluğu dolduran belirgin sıvı sınırı.",
            "Pencere Defekti (Window Defect): RPE atrofisinde sızıntı olmaksızın alttaki koroid parıltısının erken fazda görünmesi."
        ],
        differentials=[
            "DMÖ (İç B-RB): Mikroanevrizmalardan ve kapiller ağdan geç fazda artan diffüz sızıntı.",
            "SSKR (Dış B-RB): RPE düzeyinde tekil sızıntı noktası ve subretinal alanda sınırları net sıvı birikimi.",
            "Üveitik Ödem: Optik disk hiperflöresansı ve vaskülitik damar kılıflanması eşlik eder."
        ],
        clinical_pearl="Floresein anjiyografisinde 'sızıntı' (leakage) boyut ve parlaklığın zamana bağlı artmasıdır; 'pencere defekti' ise erken parlak olup geç fazda sönümlenir, boyut büyümez [s.25]."
    )

    # Slayt 1.2.2.5: Karar Ağacı: Vazojenik vs Sitotoksik Makula Ödemi
    builder.add_decision_tree_slide(
        title="MAKULA ÖDEMİ KLİNİK VE PATOLOJİK AYIRICI TANI ALGORİTMASI",
        category="BÖLÜM 1.2.2: KARAR AĞACI",
        subtitle="Bariyer Bozulmasına Bağlı Vazojenik Sıvı vs Hücresel Şişmeye Bağlı Sitotoksik Ödem",
        root_label="OKT'DE MAKULER KALINLAŞMA VE HİPOREFLEKTİF ALANLAR",
        branches=[
            {
                "label": "1. Ekstraselüler Sıvı (Vazojenik)",
                "criteria": "İç/Dış B-RB yıkımı; kistoid boşluklar ve subretinal sıvı mevcut; FA'da belirgin sızıntı var [s.24].",
                "action": "Etiyoloji: DMÖ, RVO, KNV, Üveit -> Birincil Tedavi: Anti-VEGF enjeksiyonu veya Kortikosteroid implant."
            },
            {
                "label": "2. İntraselüler Şişme (Sitotoksik)",
                "criteria": "Bariyer intakt veya sekonder; Müller ve nöron hücresel şişmesi; FA'da erken fazda sızıntı yok [s.25].",
                "action": "Etiyoloji: Akut Santral Retinal Arter Tıkanıklığı (CRAO), Commotio -> Acil perfüzyon artırıcı müdahale."
            },
            {
                "label": "3. Traksiyonel Ödem (Mekanik)",
                "criteria": "Vitreoretinal arayüzde hiperreflektif membran veya yapışıklık; foveal kistoid yarıklar [s.6].",
                "action": "Etiyoloji: Epiretinal Membran, VMT -> Tedavi: Pars Plana Vitrektomi ve İLM soyulması (Anti-VEGF etkisiz)."
            }
        ],
        bottom_rule="Vazojenik ödem farmakoterapiye (anti-VEGF/steroid) dramatik yanıt verirken, mekanik traksiyonel ödemde cerrahi dekompresyon tek çözümdür [RV1:pdf469]."
    )

    # =========================================================================
    # KONU 1.2.3: RPE METABOLİK FONKSİYONLARI VE FAGOSİTOZ (5 SLAYT)
    # =========================================================================
    # Slayt 1.2.3.1: Fotoreseptör Dış Segment Disk Fagositozu
    builder.add_study_card_slide(
        title="RPE DİSK FAGOSİTOZU VE SİRKADİYEN DÖNGÜ DİNAMİĞİ",
        category="BÖLÜM 1.2.3: RPE METABOLİZMASI",
        subtitle="MERTK ve αvβ5 İntegrin Reseptörleri, Günlük Yük ve Lizozomal Sindirim",
        cards=[
            {
                "card_title": "GÜNLÜK DEVASA YÜK",
                "lead": "Günde ~4000 Disk Fagositozu",
                "items": [
                    "Her bir RPE hücresi yaklaşık 30-45 fotoreseptörün dış segmentiyle temas halindedir [s.25].",
                    "Günlük Tüketim: Tek bir RPE hücresi günde yaklaşık 2000 - 4000 yaşlanmış membran diskini yutar.",
                    "Sirkadiyen Ritim: Çomak diskleri sabah ışık açıldığında; koni diskleri ise akşam karanlıkta dökülür.",
                    "Ömür Boyu Başarı: RPE vücutta metabolik olarak en aktif ve en çok fagositoz yapan hücre türüdür."
                ],
                "footer": "30-45 Fotoreseptör / Hücre Başına"
            },
            {
                "card_title": "RESEPTÖR MEKANİZMASI",
                "lead": "αvβ5 Bağlanma ve MERTK Yutma",
                "items": [
                    "Bağlanma Evresi: Dış segment apoptozunda beliren fosfatidilserin αvβ5 integrin reseptörünce tanınır [s.26].",
                    "Yutma Evresi (İçselleştirme): Gas6 ve Protein S ligandları MERTK reseptör tirozin kinazı aktive eder.",
                    "Fagozom Oluşumu: Disk parçası aktin iskeletiyle sarılarak hücre içine fagozom olarak alınır.",
                    "Lizozomal Füzyon: Fagozom fago-lizozoma dönüşerek asit hidrolazlarla sindirilir."
                ],
                "footer": "αvβ5 (Tanıma) + MERTK (Yutma)"
            },
            {
                "card_title": "KLİNİK GENETİK MUTASYON",
                "lead": "MERTK İlişkili Retinit",
                "items": [
                    "MERTK Mutasyonu: RPE diskleri bağlar ancak hücre içine alamaz [s.26].",
                    "Enkaz Yığılması: Subretinal aralıkta sindirilemeyen dış segment enkazı birikir.",
                    "Fotoreseptör Ölümü: Biriken atık koryokapillaris difüzyonunu keserek fotoreseptör apoptozunu tetikler.",
                    "Fenotip: Şiddetli erken başlangıçlı otozomal resesif Retinitis Pigmentosa gelişir."
                ],
                "footer": "MERTK Kusuru = Erken Başlangıçlı RP"
            }
        ]
    )

    # Slayt 1.2.3.2: Lipofuskin Oluşumu ve A2E Sitotoksisitesi
    builder.add_study_card_slide(
        title="LİPOFUSKİN OLUŞUMU, A2E TOKSİSİTESİ VE OTOFLÖRESANS",
        category="BÖLÜM 1.2.3: RPE METABOLİZMASI",
        subtitle="Lizozomal Sindirim Artıkları, Bisretinoidler, Mavi Işık Reaktivitesi ve FAF",
        cards=[
            {
                "card_title": "LİPOFUSKİN NEDİR?",
                "lead": "Sindirilamayan Yaşlanma Pigmenti",
                "items": [
                    "Lipofuskin RPE lizozomlarında sindirilemeyen lipid ve retinoid polimerlerinin birikimidir [s.26].",
                    "Yaşla Artış: 80 yaşına gelen bir bireyde RPE sitoplazma hacminin %20'sini lipofuskin kaplar [RV1:pdf477].",
                    "Floresan Özellik: Mavi ışık (488 nm) ile uyarıldığında kendiliğinden sarı-yeşil ışık yayar.",
                    "FAF Görüntüleme: Fundus Otoflöresansının (FAF) temel kaynağı RPE içindeki lipofuskindir."
                ],
                "footer": "Sitoplazmanın %20'si = Lipofuskin"
            },
            {
                "card_title": "A2E BİYOMOLEKÜLÜ VE ZEHİRİ",
                "lead": "Piridinyum Bisretinoid Bileşiği",
                "items": [
                    "A2E lipofuskinin en iyi karakterize edilmiş toksik florofor bileşenidir [s.27].",
                    "Deterjan Etkisi: Lizozom zarını delerek lizozomal enzimleri sitoplazmaya döker.",
                    "Fototoksisite: Mavi ışığı emdiğinde reaktif oksijen radikalleri (ROS) ve tekli oksijen üretir.",
                    "Kompleman Aktivasyonu: A2E kompleman regülatörlerini (Faktör H) inhibe ederek lokal atağı artırır."
                ],
                "footer": "A2E = Lizozom Delen Fototoksik Molekül"
            },
            {
                "card_title": "FAF VE COĞRAFİK ATROFİ",
                "lead": "Hiperotoflöresanstan Hipootoflöresansa",
                "items": [
                    "Aşırı Birikim (Hiper-FAF): Hücre ölümü öncesi hasta RPE'de lipofuskin birikimi parlak izlenir [s.27].",
                    "Hücre Ölümü (Hipo-FAF): RPE öldüğünde ve döküldüğünde FAF sinyali tamamen söner (zifiri siyah alan).",
                    "Atrofi Sınırı: Coğrafi atrofi odaklarının kenarındaki hiper-FAF halkası atrofın büyüme yönünü haber verir.",
                    "Klinik Takip: Coğrafi atrofi ilerleme hızını ölçmede FAF hipootoflöresan alan ölçümü altın standarttır."
                ],
                "footer": "Hiper-FAF (Stres) -> Hipo-FAF (Ölüm)"
            }
        ]
    )

    # Slayt 1.2.3.3: RPE Trofik Faktör Polaritesi
    builder.add_study_card_slide(
        title="RPE TROFİK VE ANJİYOJENİK FAKTÖR SALINIM POLARİTESİ",
        category="BÖLÜM 1.2.3: RPE METABOLİZMASI",
        subtitle="Bazolateral VEGF, Apikal PEDF Salınımı ve Damarsal Homeostaz Dengesi",
        cards=[
            {
                "card_title": "BAZOLATERAL VEGF SALINIMI",
                "lead": "Koryokapillarisin Can Damarı",
                "items": [
                    "Sağlıklı RPE sürekli olarak bazolateral membranından koroid tarafına VEGF salgılar [s.27].",
                    "Fenestrasyonun Korunması: Koryokapillaris endotelinin fenestre kalabilmesi için bu bazal VEGF şarttır.",
                    "RPE Atrofisi Etkisi: RPE öldüğünde bazal VEGF kesilir; koryokapillaris saniyeler içinde atrofiye gider.",
                    "Fizyolojik Doz: Fizyolojik VEGF anjiyogenez yapmaz; yalnızca damar sağlığını korur."
                ],
                "footer": "Bazolateral VEGF = Koryo Canlılığı"
            },
            {
                "card_title": "APİKAL PEDF SALINIMI",
                "lead": "Pigment Epithelium-Derived Factor",
                "items": [
                    "RPE apikal yüzünden nörosensoryal retina tarafına yoğun PEDF salgılar [s.28].",
                    "Güçlü Anti-Anjiyojenik: PEDF bilinen en güçlü endojen anjiyogenez inhibitörlerinden biridir.",
                    "Nöroproteksiyon: Fotoreseptörlerin ve retinal nöronların apoptozdan korunmasını destekler.",
                    "Retinal Avaskülerlik: Nörosensoryal retinanın dış katmanlarının avasküler kalmasını sağlayan güçtür."
                ],
                "footer": "Apikal PEDF = Nöroproteksiyon & Anti-VEGF"
            },
            {
                "card_title": "VEGF / PEDF DENGESİNİN BOZULMASI",
                "lead": "Neovaskülarizasyon Patogenezi",
                "items": [
                    "Hipoksi ve İskemi: Hipoksik RPE aşırı miktarda VEGF salgılarken PEDF üretimini düşürür [s.28].",
                    "Denge Kırılması: VEGF / PEDF oranı VEGF lehine saptığında anjiyogenik anahtar açılır.",
                    "KNV İlerlemesi: Koryokapillaristen filizlenen yeni damarlar Bruch'u delerek retinaya doğru büyür.",
                    "Tedavi Prensibi: İntravitreal anti-VEGF enjeksiyonları bu patolojik dengeyi yeniden tesis eder."
                ],
                "footer": "VEGF/PEDF Oran Kayması = KNV"
            }
        ]
    )

    # Slayt 1.2.3.4: Atlas Görseli: FAF ve Lipofuskin Paternleri
    img_p27 = builder.get_image_for_page(27)
    builder.add_atlas_image_slide(
        title="FUNDUS OTOFLÖRESANSINDA (FAF) LİPOFUSKİN VE ATROFİ ATLASI",
        category="BÖLÜM 1.2.3: GÖRSEL ATLAS",
        subtitle="Normal FAF Dağılımı, Santral Hipootoflöresans ve Patolojik Fenotipler",
        image_path=img_p27 or "dr_panel_2",
        caption="Referans Eser Sayfa 27: FAF Paternleri, Coğrafi Atrofi Sınırları ve Fleck Dağılımı",
        key_findings=[
            "Normal Foveal Kararma: Lutein ve zeaksantin mavi ışığı emdiğinden normal fovea merkezde hipootofloresandır [s.27].",
            "Optik Disk Kararması: Optik sinir başında RPE bulunmadığı için tamamen sinyalsiz (zifiri karanlık) izlenir.",
            "Retinal Damarlar: İçlerindeki hemoglobin mavi ışığı emdiği için damar gölgeleri hipootofloresan çizgilerdir.",
            "Arka Plan Floresansı: Arka kutup orta düzeyde homojen gri bir otoflöresans sinyali verir."
        ],
        differentials=[
            "Stargardt (Karanlık Koroid / Flecks): FAF'ta yaygın hiperotofloresan benekler ve peripapiller korunma.",
            "Best Hastalığı: Vitelliform evrede devasa homojen hiperotofloresan yuvarlak foveal kitle.",
            "Coğrafi Atrofi: Keskin sınırlı, harita benzeri total hipootoflöresan atrofi adaları."
        ],
        clinical_pearl="FAF görüntülemesinde optik disk druzeni kalsiyum içeriği nedeniyle 'otoflöresans' verir; flöresein boyası verilmeden dahi çıplak gözle parlar [s.28]."
    )

    # Slayt 1.2.3.5: Akış Şeması: MERTK Mutasyonundan Retinitis Pigmentosaya
    builder.add_horizontal_flowchart_slide(
        title="RPE FAGOSİTOZ YETMEZLİĞİNDEN RETİNAL DEJENERASYONA",
        category="BÖLÜM 1.2.3: AKIŞ ŞEMASI",
        subtitle="MERTK Gen Kusurundan Fotoreseptör Hücre Apoptozuna İlerleyen Biyolojik Zincir",
        steps=[
            {
                "num": "1",
                "title": "MERTK Mutasyonu",
                "desc": "RPE apikal yüzeyinde fonksiyonel tirozin kinaz reseptörünün üretilememesi [s.26].",
                "status": "danger"
            },
            {
                "num": "2",
                "title": "Fagositoz Durması",
                "desc": "Günde dökülen binlerce dış segment diskinin RPE tarafından yutulamaması.",
                "status": "danger"
            },
            {
                "num": "3",
                "title": "Subretinal Enkaz",
                "desc": "Fotoreseptör ile RPE arasında kalın toksik debris tabakasının birikmesi.",
                "status": "warning"
            },
            {
                "num": "4",
                "title": "Koryo Difüzyon Kaybı",
                "desc": "Besin ve oksijen akışının kesilmesi; fotoreseptörlerde metabolik boğulma.",
                "status": "warning"
            },
            {
                "num": "5",
                "title": "Çomak/Koni Apoptozu",
                "desc": "Progresif fotoreseptör ölümü, niktalopi, tübüler görme ve klasik RP fenotipi.",
                "status": "danger"
            }
        ],
        bottom_takeaway="RPE fagositoz disfonksiyonu primer bir fotoreseptör mutasyonu olmaksızın dış retinayı tamamen yok edebilen en dramatik patogenetik modeldir [RV1:pdf476]."
    )

    # =========================================================================
    # KONU 1.3.1: KALITSAL RETİNAL HASTALIKLARDA GENETİK GEÇİŞ MODELLERİ (5 SLAYT)
    # =========================================================================
    # Slayt 1.3.1.1: Mendel Kalıtım Modelleri (AD, AR, XL)
    builder.add_study_card_slide(
        title="KALITSAL RETİNA DİSTROFİLERİNDE MENDEL KALITIM MODELLERİ",
        category="BÖLÜM 1.3.1: GENETİK TEMELLER",
        subtitle="Otozomal Dominant, Otozomal Resesif ve X'e Bağlı Geçiş Dinamikleri ve Örnek Genler",
        cards=[
            {
                "card_title": "OTOZOMAL DOMİNANT (AD)",
                "lead": "%50 Aktarım / Kuşak Atlamaz",
                "items": [
                    "Etkilenen bireyin her çocuğuna hastalığı geçirme riski %50'dir [s.29].",
                    "Dikey Geçiş: Kuşak atlamaz; aile ağacında her nesilde etkilenmiş birey izlenir.",
                    "Değişken Ekspresyon: Aynı mutasyonu taşıyan aile bireylerinde klinik ağırlık farklı olabilir.",
                    "Örnek Genler: RHO (Rodopsin - en sık AD RP), PRPF31, BEST1 (Best Hastalığı)."
                ],
                "footer": "RHO, PRPF31, BEST1 (%50 Risk)"
            },
            {
                "card_title": "OTOZOMAL RESESİF (AR)",
                "lead": "%25 Risk / Akraba Evliliği",
                "items": [
                    "Anne ve baba taşıyıcıdır; çocukta hastalık ortaya çıkma riski her gebelikte %25'tir [s.30].",
                    "Yatay Dağılım: Ebeveynler genellikle sağlıklıdır; kardeşler arasında görülür.",
                    "Akraba Evliliği: Nadir resesif mutasyonların bir araya gelme olasılığını katbekat artırır.",
                    "Örnek Genler: USH2A (en sık AR RP & Usher), ABCA4 (Stargardt), RPE65 (LCA2)."
                ],
                "footer": "USH2A, ABCA4, RPE65 (%25 Risk)"
            },
            {
                "card_title": "X'E BAĞLI (X-LINKED)",
                "lead": "Erkekler Hasta / Kadınlar Taşıyıcı",
                "items": [
                    "Hastalık geni X kromozomundadır; erkeklerde tek X olduğu için tam klinik tablo gelişir [s.30].",
                    "Babadan Oğula Geçmez: Hasta erkek tüm kızlarına mutant geni aktarır (hepsi zorunlu taşıyıcı).",
                    "Lyonizasyon: Taşıyıcı kadınlarda rastgele X inaktivasyonuna bağlı hafif fundus bulgusu olabilir.",
                    "Örnek Genler: RPGR (XL RP - en ağır form), CHM (Koroideremi), RS1 (Retinoskizis)."
                ],
                "footer": "RPGR, CHM, RS1 (Erkek Ağırlıklı)"
            }
        ]
    )

    # Slayt 1.3.1.2: Mitokondriyal ve Maternal Kalıtım
    builder.add_study_card_slide(
        title="MİTOKONDRİYAL KALITIM VE EPİGENETİK DİNAMİKLER",
        category="BÖLÜM 1.3.1: GENETİK TEMELLER",
        subtitle="Maternal Aktarım, Heteroplazmi, Eşik Değeri ve Leber Herediter Optik Nöropatisi",
        cards=[
            {
                "card_title": "MATERNAL KALITIM İLKESİ",
                "lead": "Yalnızca Anneden Çocuklara",
                "items": [
                    "Spermatozoon mitokondrileri döllenme sırasında yumurtaya girmez veya hızla yok edilir [s.31].",
                    "Maternal Aktarım: Mitokondriyal DNA (mtDNA) mutasyonları yalnızca anne tarafından aktarılır.",
                    "Tüm Çocuklar Etkilenir: Hasta kadının tüm çocukları mutant mtDNA'yı devralır.",
                    "Erkekler İletemez: Hasta bir erkek hastalığı hiçbir çocuğuna aktaramaz."
                ],
                "footer": "Yalnızca Anne Tarafından İletilir"
            },
            {
                "card_title": "HETEROPLAZMİ VE EŞİK DEĞERİ",
                "lead": "Mutant ve Normal mtDNA Karışımı",
                "items": [
                    "Tek bir hücrede yüzlerce mitokondri ve binlerce mtDNA kopyası bulunur [s.31].",
                    "Homoplazmi: Tüm kopyaların mutant veya sağlıklı olması durumudur.",
                    "Heteroplazmi: Mutant ve normal mtDNA'ların aynı hücrede bir arada bulunmasıdır.",
                    "Eşik Değeri (Threshold): Dokuda klinik disfonksiyon başlaması için mutant oranının belli bir eşiği (%60-80) aşması gerekir."
                ],
                "footer": "Mutant Oranı > Eşik Değeri = Hastalık"
            },
            {
                "card_title": "KLİNİK MİTOKONDRİYAL HASTALIKLAR",
                "lead": "LHON, NARP ve MIDD",
                "items": [
                    "LHON: Leber Herediter Optik Nöropatisi (m.11778G>A, m.3460G>A, m.14484T>C) genç erkeklerde ani bilateral körlük [s.32].",
                    "NARP: Nöropati, Ataksi ve Retinitis Pigmentosa (ATPaz 6 mutasyonu).",
                    "Kearns-Sayre Sendromu: Progresif eksternal oftalmopleji, pigmenter retinopati ve kalp bloğu.",
                    "MIDD: Maternally Inherited Diabetes and Deafness (makulada pattern benzeri atrofi)."
                ],
                "footer": "LHON, NARP, Kearns-Sayre, MIDD"
            }
        ]
    )

    # Slayt 1.3.1.3: Genetik Heterojenite: Allelik vs Lokus
    builder.add_study_card_slide(
        title="GENETİK HETEROJENİTE: ALLELİK VS LOKUS HETEROJENİTESİ",
        category="BÖLÜM 1.3.1: GENETİK TEMELLER",
        subtitle="Aynı Gende Farklı Fenotipler (Allelik) vs Farklı Genlerde Aynı Fenotip (Lokus)",
        cards=[
            {
                "card_title": "LOKUS HETEROJENİTESİ",
                "lead": "Farklı Genler -> Aynı Klinik Tablo",
                "items": [
                    "Tanım: Tamamen farklı kromozomlardaki farklı gen mutasyonlarının aynı klinik fenotipi doğurmasıdır [s.32].",
                    "Örnek: Retinitis Pigmentosaya yol açan 100'den fazla farklı gen tanımlanmıştır.",
                    "Klinik Zorluk: Hastaya yalnızca klinik muayeneyle 'RP' denebilir, ancak sorumlu gen tahmin edilemez.",
                    "Gereksinim: Bu nedenle geniş genetik paneller (NGS panelleri) tek gen dizilemenin yerini almıştır."
                ],
                "footer": "100+ Farklı Gen = Tek Fenotip (RP)"
            },
            {
                "card_title": "ALLELİK HETEROJENİTE",
                "lead": "Aynı Gendeki Mutasyonlar -> Farklı Tablolar",
                "items": [
                    "Tanım: Aynı gendeki farklı mutasyon türlerinin tamamen farklı klinik hastalıklara yol açmasıdır [s.32].",
                    "Örnek Gen: ABCA4 mutasyonları klinik ağırlığa göre çok farklı fenotipler yaratır [RV1:pdf411].",
                    "Hafif Mutasyon: Geç başlangıçlı pattern benzeri distrofi veya kuru YBMD benzeri tablo.",
                    "Orta Mutasyon: Klasik çocukluk çağı Stargardt Hastalığı.",
                    "Ağır/Null Mutasyon: Şiddetli Koni-Çomak distrofisi veya Retinitis Pigmentosa 19."
                ],
                "footer": "ABCA4: Stargardt vs Koni-Çomak vs RP"
            },
            {
                "card_title": "PLEİOTROPİ VE DİGENİK KALITIM",
                "lead": "Çoklu Organ Tutulumu ve İki Gen Etkileşimi",
                "items": [
                    "Pleiotropi: Tek bir gen mutasyonunun vücutta ilgisiz birden çok organ sistemini etkilemesidir [s.33].",
                    "Sendromik Örnek: BBS genleri hem retinayı (RP) hem böbrek, parmak (polidaktili) ve obeziteyi etkiler.",
                    "Digenik Kalıtım: Hastalığın ortaya çıkması için iki farklı gende eşzamanlı heterozigot mutasyon gerekir.",
                    "Klasik Model: ROM1 ve PRPH2 (RDS) heterozigot birlikteliği digenik RP tablosu yaratır."
                ],
                "footer": "BBS Sendromu & ROM1/PRPH2 Digenik RP"
            }
        ]
    )

    # Slayt 1.3.1.4: Atlas Görseli: Genetik Pedigri ve Fenotip Şemaları
    img_p29 = builder.get_image_for_page(29)
    builder.add_atlas_image_slide(
        title="GENETİK AİLE AĞACI (PEDİGRİ) VE AKTARIM ATLASI",
        category="BÖLÜM 1.3.1: GÖRSEL ATLAS",
        subtitle="Soy Ağacı Çizim Standartları, Konsanguinite Sembolleri ve Kalıtım Tespiti",
        image_path=img_p29 or "dr_schema_0",
        caption="Referans Eser Sayfa 29: Standart Pedigri Sembolleri, Otozomal ve Cinsiyete Bağlı Kalıtım Ağaçları",
        key_findings=[
            "Pedigri Sembolleri: Kare erkek, daire kadın; içi dolu sembol klinik olarak etkilenmiş birey [s.29].",
            "Akraba Evliliği (Konsanguinite): Eşler arasında çift yatay çizgi ile gösterilir.",
            "Proband (İndeks Vaka): Kliniğe ilk başvuran ve araştırmayı başlatan birey (ok işareti ile gösterilir).",
            "Taşıyıcılık İşareti: Simgenin ortasında nokta (X'e bağlı taşıyıcı) veya yarısı dolu sembol."
        ],
        differentials=[
            "Otozomal Dominant: Her kuşakta hasta birey, kadın/erkek eşit etkilenme, babadan oğula geçiş var.",
            "Otozomal Resesif: Anne-baba sağlıklı, kardeşler etkilenmiş, ebeveynler arasında akrabalık sık.",
            "X'e Bağlı: Yalnızca erkekler hasta, hasta babanın tüm kızları taşıyıcı, babadan oğula geçiş yok."
        ],
        clinical_pearl="Aile ağacında babadan oğula hastalık geçişi kanıtlanmışsa, o hastalık kesinlikle X'e bağlı olamaz [s.30]."
    )

    # Slayt 1.3.1.5: Karşılaştırmalı Analiz: İzole vs Sendromik Retinal Distrofiler
    builder.add_split_comparison_slide(
        title="RETİNAL DİSTROFİLER: İZOLE VS SENDROMİK FENOİTİPLER",
        category="BÖLÜM 1.3.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Yalnızca Oküler Tutulum vs Sistemik ve Ekstraoküler Anomalilerle Seyreden Sendromlar",
        left_entity={
            "name": "İZOLE RETİNAL DİSTROFİLER",
            "features": [
                ("Organ Tutulumu", "Patoloji kesin olarak yalnızca göz küresi ve retina dokusuyla sınırlıdır [s.30]."),
                ("Sistemik Sağlık", "İşitme, böbrek fonksiyonları, iskelet sistemi ve zihinsel gelişim tamamen normaldir."),
                ("Tipik Örnekler", "İzole Retinitis Pigmentosa, Stargardt (ABCA4), Best Vitelliform Distrofi."),
                ("Genetik Profil", "RHO, RP1, BEST1, RDS genlerindeki izole mutasyonlar."),
                ("Takip Yaklaşımı", "Yıllık oftalmolojik görme alanı, OKT ve elektrofizyoloji takibi yeterlidir.")
            ]
        },
        right_entity={
            "name": "SENDROMİK RETİNAL DİSTROFİLER",
            "features": [
                ("Organ Tutulumu", "Retina distrofisine eşlik eden işitme kaybı, böbrek yetmezliği, polidaktili veya obezite [s.33]."),
                ("Sistemik Sağlık", "Multiorgan disfonksiyonu; erken tanı hayat kurtarıcı olabilir."),
                ("Usher Sendromu", "Retinitis Pigmentosa + Nörosensoryal İşitme Kaybı (USH2A, MYO7A)."),
                ("Bardet-Biedl (BBS)", "Retinopati + Polidaktili + Obezite + Hipogonadizm + Böbrek Disfonksiyonu."),
                ("Kearns-Sayre / Refsum", "Kardiyak iletim bloğu / Fitonik asit yüksekliği (ölümcül komplikasyonlar).")
            ]
        },
        bottom_takeaway="RP tanısı konulan her çocukta işitme testi (odyometri) ve elektrokardiyogram (EKG) zorunlu taranmalıdır; Usher ve Kearns-Sayre sendromu erken tespiti hayati öneme sahiptir [RV1:pdf412]."
    )

    # =========================================================================
    # KONU 1.3.2: GENETİK TEST STRATEJİLERİ VE VARYANT YORUMLAMA (5 SLAYT)
    # =========================================================================
    # Slayt 1.3.2.1: Yeni Nesil Dizileme (NGS) Teknolojileri
    builder.add_study_card_slide(
        title="YENİ NESİL DİZİLEME (NGS) VE GENETİK TANI TEKNOLOJİLERİ",
        category="BÖLÜM 1.3.2: GENETİK TEST STRATEJİLERİ",
        subtitle="Hedefe Yönelik Retinal Gen Panelleri, Tüm Ekzom (WES) ve Tüm Genom (WGS)",
        cards=[
            {
                "card_title": "HEDEFE YÖNELİK NGS PANELLERİ",
                "lead": "300+ Retinal Gen Taraması",
                "items": [
                    "Kalıtsal retina hastalıklarıyla ilişkili bilinen 300'den fazla geni eşzamanlı diziler [s.33].",
                    "Yüksek Kapsama Derinliği (Coverage): Hedef genler >100-200X derinlikle okunur; güvenilirlik çok yüksektir.",
                    "Birincil Tercih: Maliyet-etkinlik ve yüksek tanısal verim (%60-70) nedeniyle ilk basamak testtir.",
                    "Sınırlılık: Henüz tanımlanmamış yeni hastalık genlerini veya derin intronik mutasyonları yakalayamaz."
                ],
                "footer": "İlk Basamak Test: 300+ Gen Paneli"
            },
            {
                "card_title": "TÜM EKZOM DİZİLEME (WES)",
                "lead": "Tüm Protein Kodlayan Bölgeler",
                "items": [
                    "Genomdaki yaklaşık 20.000 genin tüm kodlayan ekzon bölgelerini (%1-2) analiz eder [s.34].",
                    "Kullanım Alanı: Gen paneli negatif çıkan atipik veya sendromik şüpheli vakalarda ikinci basamaktır.",
                    "Trio-WES: Anne, baba ve proband birlikte dizilenerek de novo mutasyonlar netleştirilir.",
                    "Sınırlılık: Derin intronik varyantlar ve büyük yapısal delesyonlar ekzomda atlanabilir."
                ],
                "footer": "İkinci Basamak: Trio-WES Analizi"
            },
            {
                "card_title": "TÜM GENOM DİZİLEME (WGS)",
                "lead": "Kodlayan ve Kodlamayan Tüm DNA",
                "items": [
                    "Genomun 3 milyar baz çiftinin tamamını (ekzonlar + intronlar + intergenik alanlar) diziler [s.34].",
                    "Büyük Yapısal Varyantlar: CNV (kopya sayısı değişimleri), translokasyon ve inversiyonları saptar.",
                    "Derin İntronik Mutasyonlar: Kriptik ekzon oluşturan splicing mutasyonlarını yakalar (ör. ABCA4 intronik).",
                    "Geleceğin Standardı: Maliyetler düştükçe nihai tek basamaklı tanı aracı haline gelmektedir."
                ],
                "footer": "Nihai Araştırma: Derin İntronik & CNV"
            }
        ]
    )

    # Slayt 1.3.2.2: ACMG/AMP Varyant Sınıflama Sistemi
    builder.add_study_card_slide(
        title="ACMG / AMP VARYANT DERECELENDİRME VE YORUMLAMA STANDARDI",
        category="BÖLÜM 1.3.2: GENETİK TEST STRATEJİLERİ",
        subtitle="5 Basamaklı Kanıt Derecelendirmesi ve Bilinmeyen Öneme Sahip Varyant (VUS) Yönetimi",
        cards=[
            {
                "card_title": "5 STANDART ACMG KATEGORİSİ",
                "lead": "Kanıt Düzeyine Göre Sınıflama",
                "items": [
                    "Sınıf 5 - Patojenik: Hastalık yaptığı %99'un üzerinde kesin kanıtlanmış varyant [s.34].",
                    "Sınıf 4 - Muhtemel Patojenik: Hastalık yapma olasılığı %90'ın üzerinde olan varyant.",
                    "Sınıf 3 - VUS (Bilinmeyen Öneme Sahip): Eldeki verilerin patojenik veya benign demeye yetmediği grup.",
                    "Sınıf 2 - Muhtemel Benign / Sınıf 1 - Benign: Sağlıklı popülasyonda sık görülen zararsız polimorfizmler."
                ],
                "footer": "Patojenik -> VUS -> Benign"
            },
            {
                "card_title": "KANIT KRİTERLERİ KODLARI",
                "lead": "PVS, PS, PM, PP ve Popülasyon Verisi",
                "items": [
                    "PVS1 (Null Varyant): Erken stop kodonu, frameshift veya kanonik splice mutasyonu [s.35].",
                    "Popülasyon Sıklığı (PM2 / BA1): gnomAD veritabanında aşırı nadir olması patojeniteyi destekler.",
                    "İn Silico Tahmin (PP3): REVEL, CADD, AlphaMissense patojenite skorları.",
                    "Kosegregasyon (PP1): Aile içinde hastalığın varyantı taşıyanlarla birlikte aktarılması."
                ],
                "footer": "PVS1 (Ağır) + PM2 (Nadir) + PP3 (Hesapsal)"
            },
            {
                "card_title": "VUS YÖNETİMİNDE ALTIN KURALLAR",
                "lead": "Asla Tek Başına Karar Verilmez",
                "items": [
                    "Klinik Karar Yasağı: Yalnızca VUS sonucuna dayanılarak hastaya klinik tanı konulamaz [s.35].",
                    "Gen Tedavisi Yasağı: VUS taşıyan bir hasta Faz 3 veya onaylı gen tedavilerine (Luxturna vb.) alınamaz.",
                    "Kosegregasyon Taraması: Ailedeki diğer hasta ve sağlıklı bireyler taranarak varyantın seyri izlenir.",
                    "Yeniden Değerlendirme: Literatür güncellendikçe VUS'lar 1-2 yıl içinde patojenik veya benigne yeniden sınıflandırılabilir."
                ],
                "footer": "VUS ile Tedavi Verilmez / Aile Taraması Şart"
            }
        ]
    )

    # Slayt 1.3.2.3: Genetik Danışmanlık ve Aile Taraması Protokolü
    builder.add_study_card_slide(
        title="RETİNAL GENETİK DANIŞMANLIK VE AİLE TARAMASI REHBERİ",
        category="BÖLÜM 1.3.2: GENETİK TEST STRATEJİLERİ",
        subtitle="Pre-test Bilgilendirme, Post-test Sonuç Açıklama, Taşıyıcılık ve Üreme Seçenekleri",
        cards=[
            {
                "card_title": "TEST ÖNCESİ (PRE-TEST)",
                "lead": "Beklentiler ve Olası Senaryolar",
                "items": [
                    "Genetik testin tanı koyma oranının (%60-70) anlatılması; negatif çıkabileceği uyarısı [s.36].",
                    "VUS Olasılığı: Test sonucunda belirsiz varyant çıkabileceği hastaya önceden bildirilir.",
                    "İkincil / Rastlantısal Bulgular: Kanser veya kardiyak risk genlerinin (ACMG ikincil liste) öğrenilmek istenip istenmediği sorulur.",
                    "Aydınlatılmış Onam: Yazılı kapsamlı genetik onam formu mutlaka alınır."
                ],
                "footer": "Gerçekçi Beklenti & Yazılı Onam"
            },
            {
                "card_title": "TEST SONRASI (POST-TEST)",
                "lead": "Sonuç Paylaşımı ve Fenotip Doğrulama",
                "items": [
                    "Genotip-Fenotip Uyumu: Saptanan mutasyon hastanın kliniği ve OKT/ERG bulgusuyla birebir uyuşuyor mu? [s.36]",
                    "Taşıyıcılık Testi: Resesif veya X'e bağlı durumlarda eş ve kardeşlerin taranması.",
                    "Prognoz ve Yaşam Tarzı: Sigaranın kesilmesi, güneş gözlüğü kullanımı, lütein desteği.",
                    "Klinik Çalışma Eşleşmesi: ClinicalTrials.gov üzerinden hastanın mutasyonuna uygun aktif faz çalışmaları."
                ],
                "footer": "Genotip-Fenotip Eşleşmesi & Faz Taraması"
            },
            {
                "card_title": "ÜREME SEÇENEKLERİ (REPRODÜKTİF)",
                "lead": "Gelecek Nesillerin Korunması",
                "items": [
                    "Preimplantasyon Genetik Tanı (PGT): Tüp bebek (IVF) sürecinde embriyodan biyopsi yapılarak mutasyonsuz embriyo seçimi [s.36].",
                    "Prenatal Tanı: Gebelik sırasında koryon villus biyopsisi (CVS) veya amniyosentez ile fetal DNA analizi.",
                    "Etik Prensipler: Çocukluk çağında semptomsuz bireylere tedavi seçeneği olmayan geç başlangıçlı hastalık testi önerilmez.",
                    "Psikososyal Destek: Görme kaybı kaygısıyla başa çıkma ve görme rehabilitasyonu yönlendirmesi."
                ],
                "footer": "PGT Seçeneği & Etik Prensipler"
            }
        ]
    )

    # Slayt 1.3.2.4: Atlas Görseli: Genetik Varyant Analizi ve Kromatogram
    img_p33 = builder.get_image_for_page(33)
    builder.add_atlas_image_slide(
        title="MOLEKÜLER GENETİK DİZİLEME VE VARYANT TESPİT ATLASI",
        category="BÖLÜM 1.3.2: GÖRSEL ATLAS",
        subtitle="Sanger Doğrulama Kromatogramı, NGS Okuma Derinliği ve Splice Bölgesi Kusurları",
        image_path=img_p33 or "dr_schema_7",
        caption="Referans Eser Sayfa 33: Sanger Dizileme Kromatogramında Heterozigot Pik ve NGS Kapsama Grafiği",
        key_findings=[
            "Sanger Kromatogramı: Çift pik (overlapping peaks) heterozigot nokta mutasyonunu kanıtlar [s.33].",
            "NGS Okuma Derinliği (Depth): Hedef ekzonda 150X okuma derinliği varyantın artefakt olmadığını doğrular.",
            "Kanonik Splice Bölgeleri: İntron başındaki GT (donor) ve sonundaki AG (akseptör) mutasyonları ağır null etki yapar.",
            "Missense Değişim: Tek bir nükleotidin değişerek farklı aminoasit kodlaması; in silico skorlarla tartılır."
        ],
        differentials=[
            "Homozigot Mutasyon: Tek ve saf anormal pik; otozomal resesif hastalık kanıtı.",
            "Bileşik Heterozigot (Compound Heterozygous): Aynı genin bir kopyasında farklı, diğerinde farklı mutasyon.",
            "Dizi Artefaktı: Yalnızca tek yönde (forward) görülen, ters yönde (reverse) doğrulanmayan yalancı pik."
        ],
        clinical_pearl="NGS ile bulunan her kritik patojenik varyant, gen tedavisi veya PGT öncesinde bağımsız bir Sanger dizileme ile mutlaka valide edilmelidir [s.34]."
    )

    # Slayt 1.3.2.5: Aktif Hatırlama & Board Sınavı Vakası
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: BÖLÜM 1",
        category="BÖLÜM 1: AKTİF HATIRLAMA",
        subtitle="22 Yaşında Erkek Hastada Niktalopi, Periferik Görme Daralması ve Genetik Test Triyajı",
        vignette="22 yaşında erkek hasta çocukluğundan beri gece görme güçlüğü (niktalopi) ve son 2 yıldır yanları görememe şikayetiyle başvuruyor. Anne-baba birinci derece akraba. Görme keskinliği bilateral 10/10. Biyomikroskopide ön segment doğal. Fundusta bilateral kemik spikülü benzeri pigmentler, retinal arteriollerde incelme ve balmumu solukluğunda optik disk izleniyor. Makula SD-OCT kesitinde santral foveal EZ korunmuş, parafoveada silinmiştir.",
        differentials=[
            "Otozomal Resesif Retinitis Pigmentosa (en olası: USH2A, PDE6A, EYS).",
            "X'e Bağlı Retinitis Pigmentosa (RPGR mutasyonu - soy ağacında kadın taşıyıcılar sorgulanmalı).",
            "Usher Sendromu Tip 2 (hafif-orta nörosensoryal işitme kaybı eşlik edebilir).",
            "Koroideremi (fundusta yaygın RPE ve koryokapillaris atrofisi ile sklera görünümü)."
        ],
        decision="1. Adım: Ayrıntılı 3 kuşak pedigri çizimi ve odyometri testi (işitme kaybı ekarte edilmeli).\n2. Adım: Hedefe yönelik 300+ genlik Kalıtsal Retina Distrofisi NGS Paneli istenmeli.\n3. Adım: Eğer USH2A veya RPE65 patojenik varyantı saptanırsa aile taraması ve uygun klinik faz çalışması/gen tedavisi planlanmalı.",
        board_trap="Hastanın görmesi 10/10 olduğu için tabloyu hafife alıp test istememek ölümcül bir klinik tuzaktır. RP'de foveal koniler hastalığın son evresine kadar 10/10 görmeyi koruyabilir; periferik görme alanı ve genetik test acil prognostik zorunluluktur [RV1:pdf412]."
    )

    print(f" -> Bölüm 1 (Temel Bilimler ve Anatomi) Tamamlandı: 46 Slayt Eklendi.")
