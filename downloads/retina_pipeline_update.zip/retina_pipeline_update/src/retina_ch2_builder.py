# -*- coding: utf-8 -*-
r"""
retina_ch2_builder.py — Bölüm 2: Retinal Görüntüleme ve Tanı Yöntemleri (63 Slayt)
==================================================================================
Kitap Sayfaları: 38 – 90
Alt Başlıklar:
  2.0   Bölüm 2 Çalışma Yol Haritası (1 slayt)
  2.1.1 SD-OKT ve Swept-Source (SS-OKT) İlkeleri (5 slayt)
  2.1.2 Retinal Katman Biyobelirteçleri (EZ, ELM, HRF, DRIL, SHRM) (6 slayt)
  2.1.3 Koroid Görüntüleme: EDI-OKT ve CVI Analizi (5 slayt)
  2.2.1 OKTA Yüzeyel, Derin ve FAZ Analizi (5 slayt)
  2.2.2 OKTA Koryokapillaris Akım Boşlukları ve KNV Tespiti (5 slayt)
  2.2.3 OKTA Artefaktları ve Kalite Standartları (5 slayt)
  2.3.1 FA Hiperflöresans ve Hipoflöresans Paternleri (5 slayt)
  2.3.2 ICG Koroit Dolaşımı ve Polipoidal Lezyonlar (5 slayt)
  2.3.3 Geniş Açılı (Ultra-Widefield) Anjiyografi (5 slayt)
  2.4.1 Fundus Otofloresans (FAF) ve Lipofuskin Paternleri (5 slayt)
  2.4.2 Ultrasonografi (B-Scan) Opasiteler ve Kitleler (5 slayt)
  2.5.1 Elektrofizyoloji: ffERG, mfERG, EOG, VEP Dalga Analizi (6 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_2(builder: RetinaStudyDeckBuilder):
    """Bölüm 2'ye ait 63 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 2 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=2,
        title="RETİNAL GÖRÜNTÜLEME VE TANI YÖNTEMLERİ",
        page_range="Sayfa 38 – 90",
        subtitle="SD/SS-OKT Biyobelirteçleri, OKTA Pleksus Haritalaması, FA/ICG Dinamiği, FAF ve Elektrofizyoloji",
        cards=[
            {
                "title": "1. Optik Koherens Tomografi",
                "color": PPTXPalette.BLUE,
                "lead": "SD-OKT vs SS-OKT & Biyobelirteçler",
                "items": [
                    "SD-OKT (840 nm) yüksek aksiyel çözünürlük (~3-5 μm), SS-OKT (1050 nm) derin koroid penetrasyonu sağlar.",
                    "Retinal Biyobelirteçler: EZ bütünlüğü, ELM devamlılığı, HRF (mikroglia/lipit), DRIL ve SHRM.",
                    "EDI-OKT ve CVI: Koryoidal vaskülarite indeksi koroid vasküler lümen/stroma oranını (%65) kantifiye eder.",
                    "Pakikoroid Biyobelirteçleri: Subfoveal kalınlaşma (>350 μm), dilate Haller venleri ve koryokapillaris basısı."
                ],
                "footer": "Yapısal Tomografi Biyobelirteçleri"
            },
            {
                "title": "2. OKT Anjiyografi (OKTA)",
                "color": PPTXPalette.GREEN,
                "lead": "Boya Gerektirmeyen Pleksus Analizi",
                "items": [
                    "Bölünmüş Spektrum Genlik Dekorelasyonu (SSADA) ile hareketli eritrositlerin tespiti.",
                    "Yüzeyel Pleksus (SVP): RNFL/GCL tabakalarında; Derin Pleksus (DVP): INL/OPL sınırında yer alır.",
                    "FAZ Analizi: Sağlıklı foveada avasküler alan 0.25-0.40 mm²; diyabetik iskemide sirkülarite bozulur.",
                    "Koryokapillaris İskemisi: Akım boşlukları (flow voids) ve avasküler zonların kantitatif segmentasyonu."
                ],
                "footer": "Pleksus Düzeyinde Mikroakım"
            },
            {
                "title": "3. Boyalı Anjiyografi (FA/ICG)",
                "color": PPTXPalette.AMBER,
                "lead": "Retinal & Koroidal Dinamik",
                "items": [
                    "Floresein (FA - 490/520 nm): İç B-RB vasküler sızıntısı, kapiller dolum defektleri ve neovaskülarizasyon.",
                    "İndosiyanin Yeşili (ICG - 805/835 nm): %98 proteine bağlanır; koroid dolaşımı ve PCV poliplerini gösterir.",
                    "Hiperflöresans Nedenleri: Sızıntı (leakage), boyanma (staining), göllenme (pooling), pencere defekti.",
                    "Geniş Açı (UWF): 200° periferik retina taraması; periferik vaskülit ve non-perfüzyon alanlarının tespiti."
                ],
                "footer": "Dinamik Akım ve Bariyer Kaçakları"
            },
            {
                "title": "4. FAF & Elektrofizyoloji",
                "color": PPTXPalette.PURPLE,
                "lead": "Metabolizma & Elektriksel Fonksiyon",
                "items": [
                    "FAF (Fundus Otofloresans): RPE lipofuskin birikimini (hiper-FAF) ve coğrafi atrofiyi (hipo-FAF) gösterir.",
                    "B-Scan USG: Opak ortamlarda vitreus kanaması, retina dekolmanı ve koroid melanomunun (akustik boşluk) ayrımı.",
                    "ffERG: Skotopik çomak a-dalgası (fotoreseptör), b-dalgası (bipolar); fotopik koni yanıtları.",
                    "EOG & mfERG: Arden oranı (<%150 Best hastalığı) ve multifokal foveal koni amplitüd haritası."
                ],
                "footer": "Fonksiyonel & Biyofiziksel Tanı"
            }
        ]
    )

    # =========================================================================
    # KONU 2.1.1: SD-OKT VE SS-OKT İLKELERİ (5 SLAYT)
    # =========================================================================
    # Slayt 2.1.1.1: Fiziksel İlkeler ve İnterferometri
    builder.add_study_card_slide(
        title="OPTİK KOHERENS TOMOGRAFİ (OKT) FİZİKSEL VE OPTİK İLKELERİ",
        category="BÖLÜM 2.1.1: OKT PRENSİPLERİ",
        subtitle="Düşük Koherensli İnterferometri, Michelson Düzeneği ve Spektral Domain Dönüşümü",
        cards=[
            {
                "card_title": "İNTERFEROMETRİ VE IŞIK KAYNAĞI",
                "lead": "Düşük Koherensli Süperlüminesans Işık",
                "items": [
                    "Düşük Koherensli İnterferometri (LCI): Kısa koherens boyuna sahip geniş bantlı ışık kullanılır [s.39].",
                    "Michelson İnterferometresi: Işık demeti yarı geçirgen aynayla referans kolu ve numune koluna ayrılır.",
                    "Girişim Deseni (Interference): Dokudan geri yansıyan ışık referans aynasından dönen ışıkla üst üste biner.",
                    "Aksiyel Çözünürlük: Işık kaynağının merkez dalga boyu (λ) ve bant genişliği (Δλ) ile belirlenir."
                ],
                "footer": "LCI & Michelson İnterferometresi"
            },
            {
                "card_title": "ZAMAN DOMAİNİNDEN SPEKTRAL DOMAİNE",
                "lead": "Mekanik Aynadan Spektrometreye",
                "items": [
                    "Time-Domain OKT (Stratus): Referans aynası mekanik hareket ederdi; saniyede yalnızca 400 A-taraması yapardı [s.40].",
                    "Spektral Domain OKT (SD-OKT): Referans aynası sabittir; geri dönen ışık spektrometre ve CCD kamera ile okunur.",
                    "Fourier Dönüşümü (FFT): Frekans spektrumu matematiksel Fourier dönüşümüyle derinlik profiline çevrilir.",
                    "Hız Devrimi: Saniyede 40.000 - 85.000 A-taraması; göz hareket artefaktları dramatik azalmıştır."
                ],
                "footer": "Sabit Referans + Spektrometre + FFT"
            },
            {
                "card_title": "ÇÖZÜNÜRLÜK MATEMATİĞİ",
                "lead": "Aksiyel vs Lateral Çözünürlük",
                "items": [
                    "Aksiyel Çözünürlük: Gözün optik ortamından bağımsızdır; Δx = (2 ln 2 / π) × (λ² / Δλ) formülüyle hesaplanır [s.40].",
                    "SD-OKT Aksiyel Gücü: Ortalama 3 - 5 μm (hücresel tabaka ayrımına izin verir).",
                    "Lateral (Enine) Çözünürlük: Gözün kornea ve lens optiğine bağımlıdır; ortalama 15 - 20 μm düzeyindedir.",
                    "B-Taraması: Yan yana dizilen yüzlerce A-taramasının oluşturduğu 2 boyutlu kesit görüntüsüdür."
                ],
                "footer": "Aksiyel: 3-5 μm | Lateral: 15-20 μm"
            }
        ]
    )

    # Slayt 2.1.1.2: SD-OKT vs Swept-Source OKT (SS-OKT)
    builder.add_split_comparison_slide(
        title="SD-OKT VS SWEPT-SOURCE OKT (SS-OKT) TEKNOLOJİK KARŞILAŞTIRMASI",
        category="BÖLÜM 2.1.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Dalga Boyu, Tarama Hızı, Derinlik Sinyal Kaybı (Roll-off) ve Koroid Görünürlüğü",
        left_entity={
            "name": "SPEKTRAL DOMAIN OKT (SD-OKT)",
            "features": [
                ("Merkez Dalga Boyu", "840 nm (yakın kızılötesi ışık) [s.40]."),
                ("Işık Kaynağı & Dedektör", "Geniş bantlı süperlüminesans diyot (SLD) + Spektrometre / CCD kamera."),
                ("Tarama Hızı", "40.000 - 85.000 A-taraması / saniye."),
                ("Sinyal Zayıflaması (Roll-off)", "Derinlik arttıkça sinyal hızla düşer; sklera ve derin koroid net seçilemez."),
                ("Klinik Odak", "Retina iç ve dış katmanlarının mikroskobik morfolojisi ve biyobelirteçleri.")
            ]
        },
        right_entity={
            "name": "SWEPT-SOURCE OKT (SS-OKT)",
            "features": [
                ("Merkez Dalga Boyu", "1050 - 1060 nm (uzun dalga boyu; RPE ve katarakttan yüksek penetrasyon) [s.41]."),
                ("Işık Kaynağı & Dedektör", "Hızlı taranan dalga boylu lazer (Swept Laser) + Tekli fotodedektör."),
                ("Tarama Hızı", "100.000 - 400.000 A-taraması / saniye (aşırı hızlı)."),
                ("Sinyal Zayıflaması (Roll-off)", "Neredeyse sıfır roll-off; vitreustan koroid ve skleraya kadar homojen sinyal."),
                ("Klinik Odak", "Geniş açılı vitreoretinal arayüz, pakikoroid, stafilom ve koroid neoplazileri.")
            ]
        },
        bottom_takeaway="1050 nm dalga boyuna sahip SS-OKT, RPE ve katarakt gibi opak ortamlardan daha az saçılır ve EDI moduna ihtiyaç duymaksızın koroid-sklera sınırını net olarak görüntüler [s.41]."
    )

    # Slayt 2.1.1.3: Aksiyel Çözünürlük ve Sinyal Dinamiği
    builder.add_study_card_slide(
        title="OKT'DE SİNYAL VE YANSIMA DİNAMİĞİ (REFLEKTİVİTE)",
        category="BÖLÜM 2.1.1: OKT PRENSİPLERİ",
        subtitle="Optik Kırılma İndisi Farkları, Hiperreflektif ve Hiporeflektif Dokular",
        cards=[
            {
                "card_title": "OPTİK KIRILMA İNDİSİ",
                "lead": "Fresnel Yansıması İlkesi",
                "items": [
                    "OKT sinyali iki doku tabakası arasındaki kırılma indisi (n) farkından doğar [s.41].",
                    "Büyük İndis Farkı: Yüksek geri saçılma ve parlak beyaz (hiperreflektif) sinyal oluşturur.",
                    "Küçük İndis Farkı: Düşük geri saçılma ve koyu gri/siyah (hiporeflektif) sinyal verir.",
                    "Homojen Sıvı: İçinde hücresel eleman olmayan seröz sıvı optik olarak şeffaftır (zifiri anekoik/siyah)."
                ],
                "footer": "Kırılma İndisi Farkı = OKT Sinyali"
            },
            {
                "card_title": "HİPERREFLEKTİF YAPILAR",
                "lead": "Yüksek Sinyal Veren Retinal Dokular",
                "items": [
                    "Retina Sinir Lifi Tabakası (RNFL): Yoğun paralel akson demetleri ışığı güçlü geri saçar [s.42].",
                    "Pleksiform Tabakalar (IPL ve OPL): Yoğun nöropil ve sinaps ağları hiperreflektiftir.",
                    "Elipsoid Zon (EZ): Koni/çomak iç segmentlerindeki yoğun mitokondri kümelenmesi.",
                    "RPE / Bruch Kompleksi: Melanin granülleri nedeniyle retinadaki en güçlü hiperreflektif banttır."
                ],
                "footer": "RNFL, OPL, EZ, RPE = Hiperreflektif"
            },
            {
                "card_title": "HİPOREFLEKTİF YAPILAR",
                "lead": "Düşük Sinyal Veren Retinal Dokular",
                "items": [
                    "Nükleer Tabakalar (GCL, INL, ONL): Hücre çekirdekleri homojendir; ışığı zayıf saçar ve koyu görünür [s.42].",
                    "Kistoid Sıvı Boşlukları: İntraretinal ve subretinal seröz sıvı cepleri hiporeflektiftir.",
                    "Vitreus Gövdesi: Sağlıklı vitreus sıvısı tamamen optik boşluktur (sinyalsiz siyah).",
                    "Gölgeleme Etkisi (Shadowing): Yoğun kanama, sert eksüda veya pigment arkasında yalancı hiporeflektivite."
                ],
                "footer": "Nükleer Katmanlar & Sıvı = Hiporeflektif"
            }
        ]
    )

    # Slayt 2.1.1.4: Atlas Görseli: SD-OKT vs SS-OKT Foveal Kesitleri
    img_p41 = builder.get_image_for_page(41)
    builder.add_atlas_image_slide(
        title="SD-OKT VE SS-OKT KARŞILAŞTIRMALI KLİNİK KESİT ATLASI",
        category="BÖLÜM 2.1.1: GÖRSEL ATLAS",
        subtitle="840 nm Retina Detaylandırması vs 1050 nm Derin Koroid ve Sklera Penetrasyonu",
        image_path=img_p41 or "dr_schema_2",
        caption="Referans Eser Sayfa 41: Eşzamanlı Alınan SD-OKT ve SS-OKT Foveal Kesitlerinde Koroid Sınırı",
        key_findings=[
            "Retinal Çözünürlük: SD-OKT'de iç retina katmanları ve dış retina bantları (ELM/EZ/IZ) ultra-keskindir [s.41].",
            "Koroid Görünürlüğü: SS-OKT'de koroid damar lümenleri ve sklera iç yüzeyi sıfır sinyal kaybıyla seçilir.",
            "Geniş Tarama Açısı: SS-OKT tek çekimde 12×12 mm veya 15×9 mm geniş vitreoretinal alanı tarar.",
            "Katarakt Geçirgenliği: Nükleer kataraktlı gözlerde SS-OKT sinyali korurken SD-OKT'de kararma gelişir."
        ],
        differentials=[
            "Normal Koroid: Ortalama 250-300 μm kalınlık; damar tabakaları düzenli dizilimlidir.",
            "Pakikoroid: Haller tabakasında dev damarlar (pakivessel) ve koryokapillaris tabakasında ezilme.",
            "Miyopik Stafilom: Skleranın arkaya doğru bombeleştiği derin çukurluk ve aşırı incelmiş retina."
        ],
        clinical_pearl="Vitreoretinal arayüz cerrahisi planlanırken (ERM/FTMH) SD-OKT'nin iç retina çözünürlüğü tercih edilirken; pakikoroid ve tümör cerrahisinde SS-OKT tartışmasız üstündür [s.42]."
    )

    # Slayt 2.1.1.5: Akış Şeması: Klinik Pratikte OKT Cihazı Seçim Rehberi
    builder.add_decision_tree_slide(
        title="KLİNİK ANTİTELERE GÖRE OKT MODALİTE SEÇİM ALGORİTMASI",
        category="BÖLÜM 2.1.1: KARAR AĞACI",
        subtitle="Hastalığın Primer Tutulum Odaklarına Göre En Uygun Tomografi Cihazının Belirlenmesi",
        root_label="KLİNİK ŞÜPHE VE GÖRÜNTÜLEME HEDEFİ",
        branches=[
            {
                "label": "1. İç Retina & VMA Bozuklukları",
                "criteria": "Epiretinal membran, makula deliği, DRIL, foveal avasküler zon sınırları veya glokom RNFL [s.42].",
                "action": "Tercih: Yüksek Aksiyel Çözünürlüklü SD-OKT (840 nm) -> İLM ve tabaka ayrıntıları için ideal."
            },
            {
                "label": "2. Koroid & Pakikoroid Spektrumu",
                "criteria": "SSKR, PKNV, PCV polipleri, koroid nevüsü/melanomu, koryoretinit odakları [s.41].",
                "action": "Tercih: Swept-Source OKT (1050 nm) veya EDI-OKT -> Koroid-sklera sınırını ve damarları net gösterir."
            },
            {
                "label": "3. Medya Opasiteleri & Yüksek Miyopi",
                "criteria": "Yoğun nükleer katarakt, vitreus hemorajisi kalıntısı, arka stafilom (>26 mm aks boyu) [s.42].",
                "action": "Tercih: SS-OKT (1050 nm) -> Saçılmayan uzun dalga boyu ve derin fokus yeteneği zorunludur."
            }
        ],
        bottom_rule="Koroid kalınlığı ölçümünde SD-OKT kullanılıyorsa EDI (Enhanced Depth Imaging) modu aktif edilmeli; fovea sıfır hattı koroid-sklera bileşkesine kilitlenmelidir [s.47]."
    )

    # =========================================================================
    # KONU 2.1.2: RETİNAL KATMAN BİYOBELİRTEÇLERİ (6 SLAYT)
    # =========================================================================
    # Slayt 2.1.2.1: Elipsoid Zon (EZ) ve Dış Sınırlayıcı Membran (ELM)
    builder.add_study_card_slide(
        title="DIŞ RETİNA BİYOBELİRTEÇLERİ: ELİPSOİD ZON (EZ) VE ELM",
        category="BÖLÜM 2.1.2: OKT BİYOBELİRTEÇLERİ",
        subtitle="Fotoreseptör Sağlığı, Görme Keskinliği Korelasyonu ve Yapısal İyileşme Kriterleri",
        cards=[
            {
                "card_title": "ELİPSOİD ZON (EZ) BÜTÜNLÜĞÜ",
                "lead": "Fotoreseptör İç/Dış Segment Hattı",
                "items": [
                    "Eski Adı: IS/OS (Inner/Outer Segment) bileşkesi; gerçekte iç segment elipsoid kısmıdır [s.43].",
                    "Mitokondri Reflektivitesi: Aşırı yoğun mitokondri içeriği nedeniyle parlak hiperreflektiftir.",
                    "Görme İle Doğrudan Korelasyon: Santral foveal EZ bütünlüğü hastanın BCVA düzeyiyle en güçlü korelasyona sahiptir.",
                    "Fokal Defekt: EZ hattındaki kesinti (disruption) fotoreseptör kaybını veya fonksiyonel bayılmasını kanıtlar."
                ],
                "footer": "EZ = Fotoreseptör Metabolik Canlılığı"
            },
            {
                "card_title": "DIŞ SINIRLAYICI MEMBRAN (ELM)",
                "lead": "Müller-Fotoreseptör Kenetlenmesi",
                "items": [
                    "ONL ile fotoreseptör iç segmentleri arasındaki zonula adherens bağlantılarıdır [s.43].",
                    "Yapısal Bariyer: Fotoreseptör mikroçevresini izole eden mekanik stabilizatördür.",
                    "Rejenerasyon Şartı: Tedavi sonrası (makula deliği kapanması, anti-VEGF) EZ'nin düzelmesi için ELM'nin sağlam kalması şarttır.",
                    "İki Basamaklı İyileşme: Önce ELM hattı kesintisizleşir; aylar sonra üzerine EZ bandı yeniden oturur."
                ],
                "footer": "ELM Sağlam Değilse EZ İyileşemez"
            },
            {
                "card_title": "KLİNİK PROGNOSTİK DEĞERİ",
                "lead": "Cerrahi ve Medikal Sonuç Tahmini",
                "items": [
                    "Başarılı Anatomi vs Kötü Görme: Makula deliği cerrahisiyle delik kapansa bile EZ restore olmamışsa görme artmaz [s.44].",
                    "Solar Retinopati: Foveolada fokal EZ defekti ve arkasında RPE gölgelenmesi kalıcı santral skotom yaratır.",
                    "Kloroquin / HCQ Toksisitesi: Parafoveal EZ silinmesi ('uçan daire' / flying saucer belirtisi) erken toksisite kanıtıdır.",
                    "Kalıcı Skar: EZ ve ELM'nin birlikte yok olduğu alanlarda fotoreseptör rejenerasyonu imkansızdır."
                ],
                "footer": "EZ İntakt = Yüksek Görme Potansiyeli"
            }
        ]
    )

    # Slayt 2.1.2.2: Hiperreflektif Odaklar (HRF)
    builder.add_study_card_slide(
        title="HİPERREFLEKTİF ODAKLAR (HRF) VE İNFLAMATUAR GÖÇ",
        category="BÖLÜM 2.1.2: OKT BİYOBELİRTEÇLERİ",
        subtitle="Retinal Mikroglia Aktivasyonu, Lipid Ekstravazasyonu ve Tedaviye Yanıt Belirteci",
        cards=[
            {
                "card_title": "HRF MORFOLOJİSİ",
                "lead": "<30 μm Noktasal Hiperreflektif Odaklar",
                "items": [
                    "Çapı <30 μm olan, gölgeleme yapmayan, sınırları net noktasal hiperreflektif parçacıklardır [s.44].",
                    "Ayırıcı Özellik: Sert eksüdalardan (>30 μm ve arkasında koyu gölge bırakır) gölgeleme yapmamasıyla ayrılır.",
                    "Retinal Dağılım: Erken evrede iç retinada (IPL, INL) toplanır; hastalık ilerledikçe dış retinaya göç eder.",
                    "Subretinal Göç: Dış sınırlayıcı membranı aşarak subretinal alana inmesi şiddetli doku yıkımını gösterir."
                ],
                "footer": "<30 μm / Arkasında Gölge Bırakmaz"
            },
            {
                "card_title": "HÜCRESEL VE MOLEKÜLER KÖKEN",
                "lead": "Aktive Mikroglia vs Lipid Damlacıkları",
                "items": [
                    "Aktive Mikroglialar: İnflamasyonla aktive olan fagositik mikroglia hücrelerinin birikimidir [s.44].",
                    "Lipid-Yüklü Makrofajlar: Kırılan kapillerlerden sızan lipoproteinleri yutmuş köpüksü makrofajlar.",
                    "Göç Eden RPE: Kuru YBMD'de strese giren RPE hücreleri epitelyal-mezenkimal dönüşümle (EMT) iç retinaya tırmanır.",
                    "İnflamatuar İndeks: HRF sayısı retinadaki aktif inflamasyon yüküyle doğru orantılıdır."
                ],
                "footer": "Aktif Mikroglia & Lipid Makrofajları"
            },
            {
                "card_title": "TEDAVİ YANITINDA KULLANIMI",
                "lead": "Steroid Switch Göstergesi",
                "items": [
                    "Diyabetik Makula Ödemi: Yoğun HRF varlığı tablonun inflamatuar bileşeninin yüksek olduğunu gösterir [s.45].",
                    "Anti-VEGF Direnci: Anti-VEGF'e yetersiz yanıt veren ve çok sayıda HRF içeren DMÖ'de deksametazon implant (Ozurdex) üstündür.",
                    "Kuru YBMD Progresyonu: Drusen tepesinde beliren HRF'ler o alanın 1-2 yıl içinde coğrafi atrofiye gideceğini haber verir.",
                    "Tedavi Takibi: Etkin anti-inflamatuar tedaviyle HRF sayısında dramatik azalma izlenir."
                ],
                "footer": "Yüksek HRF = Steroid İmplant Endikasyonu"
            }
        ]
    )

    # Slayt 2.1.2.3: DRIL (Disorganization of Retinal Inner Layers)
    builder.add_study_card_slide(
        title="İÇ RETİNA TABAKALANMA BOZUKLUĞU (DRIL)",
        category="BÖLÜM 2.1.2: OKT BİYOBELİRTEÇLERİ",
        subtitle="Ganglion Hücresi, Bipolar ve Müller Nöron Yolaklarının Yapısal Yıkımı ve Görme Prognozu",
        cards=[
            {
                "card_title": "DRIL TANIM VE KRİTERLERİ",
                "lead": "GCL, IPL, INL ve OPL Sınırlarının Silinmesi",
                "items": [
                    "Tanım: Santral 1 mm foveal alanda iç retina katmanları arasındaki sınırların ayırt edilememesidir [s.45].",
                    "Tabakalanma Kaybı: GCL-IPL kompleksi, INL ve OPL sınırları homojen amorf bir dokuya dönüşür.",
                    "Ölçüm Kriteri: Yatay foveal B-taramasında DRIL uzanım genişliği mikrometre (μm) olarak ölçülür.",
                    "Eşik Değer: DRIL genişliği >500 μm olduğunda kalıcı görme kaybı riski katlanarak artar."
                ],
                "footer": "İç Katman Sınırlarının Tamamen Silinmesi"
            },
            {
                "card_title": "PATOFİZYOLOJİK ARKA PLAN",
                "lead": "İskemik Nöron Ölümü ve Gliyozis",
                "items": [
                    "Mikrovasküler İskemi: Derin ve yüzeyel kapiller pleksusun kronik non-perfüzyonu nöronları besleyemez [s.45].",
                    "İkinci Sıra Nöron Ölümü: Bipolar, amakrin ve horizontal hücrelerin apoptoza gitmesi.",
                    "Müller Reaktif Gliyozisi: Boşalan nöron alanlarını Müller glial skar dokusunun doldurması.",
                    "Klinik Çıkarım: Sıvı tamamen kurutulsa dahi, sinirsel iletim kabloları koptuğu için hasta göremez."
                ],
                "footer": "Derin Pleksus İskemisi & Glial Skar"
            },
            {
                "card_title": "PROGNOSTİK DEĞERİ",
                "lead": "Görsel Potansiyelin Bağımsız Belirteci",
                "items": [
                    "DMÖ ve RVO Takibi: DRIL varlığı, santral retinal kalınlıktan bağımsız olarak görme keskinliğinin en güçlü belirleyicisidir [s.46].",
                    "DRIL Gerilemesi: Başarılı tedaviyle DRIL alanının daralması görme keskinliğinde artışla sonuçlanır.",
                    "Kalıcı DRIL: Ödem çekilmesine rağmen DRIL devam ediyorsa görsel prognoz zayıftır.",
                    "Tedavi Beklentisi: Hastaya gerçekçi beklenti anlatılırken DRIL varlığı mutlaka dikkate alınmalıdır."
                ],
                "footer": "DRIL Varlığı = Sınırlı Görme Kazanımı"
            }
        ]
    )

    # Slayt 2.1.2.4: SHRM (Subretinal Hiperreflektif Materyal)
    builder.add_study_card_slide(
        title="SUBRETİNAL HİPERREFLEKTİF MATERYAL (SHRM)",
        category="BÖLÜM 2.1.2: OKT BİYOBELİRTEÇLERİ",
        subtitle="Nörosensoryal Retina ile RPE Arasındaki Patolojik Kitle: Fibrin, Kan, KNV ve Fibrozis",
        cards=[
            {
                "card_title": "SHRM ANATOMİK LOKALİZASYONU",
                "lead": "Dış Retina ile RPE Arasındaki Boşluk",
                "items": [
                    "Nörosensoryal retinanın dış sınırı (EZ/IZ) ile RPE bandı arasında yerleşen hiperreflektif materyaldir [s.46].",
                    "Subretinal Sıvıdan Farkı: Seröz sıvı hiporeflektif (siyah) iken SHRM optik yansıma veren solid kitledir.",
                    "Sık Görüldüğü Durumlar: Neovasküler YBMD (Tip 2 KNV), akut SSKR bülloz formu, vitelliform lezyonlar.",
                    "Dinamik Doğası: Tedaviyle hızla boyut değiştirebilen veya kalıcı skara dönüşebilen dinamik yapıdır."
                ],
                "footer": "Subretinal Solid Hiperreflektif Kitle"
            },
            {
                "card_title": "BİLEŞEN AYRIMI VE DÖNÜŞÜM",
                "lead": "Fibrin, Kanama, Neovasküler Damar ve Skar",
                "items": [
                    "Fibrin Eksüdasyonu: Homojen, orta hiperreflektif; anti-VEGF ile hızla erir ve kaybolur [s.46].",
                    "Subretinal Kanama: Yoğun optik gölgeleme yapan yüksek hiperreflektif tabaka.",
                    "Tip 2 KNV Kompleksi: Bruch ve RPE'yi delip subretinal alana çıkmış gerçek vasküler yumak.",
                    "Fibrozis (Subretinal Skar): Zamanla organize olan, sert, fotoreseptörleri ezen kalıcı fibröz bağ dokusu."
                ],
                "footer": "Fibrin (Eriyen) vs Fibrozis (Kalıcı Skar)"
            },
            {
                "card_title": "KLİNİK YÖNETİM VE PROGNOZ",
                "lead": "Erken Tedavi ile Skarlaşmanın Önlenmesi",
                "items": [
                    "Agresif Anti-VEGF: Taze SHRM saptandığında fibrozise dönüşmeden acil yükleme dozu başlanmalıdır [s.47].",
                    "Skar Riski: SHRM tabanı genişledikçe ve yüksekliği arttıkça subretinal fibrozis gelişme riski katlanır.",
                    "Kalıcı Fotoreseptör Hasarı: SHRM üzerindeki fotoreseptörlerin EZ bandı hızla dejenere olur.",
                    "Tedavi Başarısı: SHRM'nin tamamen temizlenmesi en iyi fonksiyonel sonuçla birliktedir."
                ],
                "footer": "Hızlı Tedavi = Fibrozisi Önler"
            }
        ]
    )

    # Slayt 2.1.2.5: Atlas Görseli: Retinal Biyobelirteçler Koleksiyonu
    img_p45 = builder.get_image_for_page(45)
    builder.add_atlas_image_slide(
        title="RETİNAL VE DIŞ RETİNA BİYOBELİRTEÇLERİ ATLASI",
        category="BÖLÜM 2.1.2: GÖRSEL ATLAS",
        subtitle="EZ Defekti, HRF Göçü, DRIL Alanı ve Subretinal SHRM Koleksiyonu",
        image_path=img_p45 or "dr_panel_5",
        caption="Referans Eser Sayfa 45: DMÖ ve Neovasküler YBMD'de Eşzamanlı Gözlenen Retinal Biyobelirteçler",
        key_findings=[
            "DRIL Sınırları: Foveal 1 mm alanda iç nükleer ve pleksiform katmanların homojen grileşmesi [s.45].",
            "HRF Dağılımı: İç retinadan dış retinaya doğru saçılmış sayısız <30 μm hiperreflektif nokta.",
            "SHRM Tabanı: Fovea altında RPE üzerinde kubbe yapan heterojen hiperreflektif fibrin ve KNV kütlesi.",
            "EZ/ELM Kesintisi: SHRM'nin tam üzerindeki dış retina bantlarında kalıcı mimari kayıp."
        ],
        differentials=[
            "İzole Kistoid Ödem: Tabakalanma korunmuştur; kist kaviteleri hiporeflektiftir, DRIL yoktur.",
            "Sert Eksüda Plakları: Büyük (>30 μm) ve arkasında RPE'yi örten derin gölge konileri bırakır.",
            "Vitelliform Lezyon: Homojen hiperreflektif materyal; inflamatuar HRF ve neovaskülarizasyon içermez."
        ],
        clinical_pearl="Anti-VEGF tedavisi sonrası kistoid boşluklar tamamen kapansa dahi, DRIL ve kalıcı EZ kaybı olan gözlerde görme artışı beklenmemelidir; biyobelirteçler sıvının ötesindedir [s.46]."
    )

    # Slayt 2.1.2.6: Karşılaştırmalı Özet Tablosu: Biyobelirteçler Matrisi
    builder.add_study_card_slide(
        title="OKT RETİNAL BİYOBELİRTEÇLERİ PROGNOSTİK VE KLİNİK MATRİSİ",
        category="BÖLÜM 2.1.2: BİYOBELİRTEÇ MATRİSİ",
        subtitle="Hücresel Anlam, İdeal Tedavi Seçeneği ve Görme Keskinliğiyle İlişkisi",
        cards=[
            {
                "card_title": "EZ / ELM BÜTÜNLÜĞÜ",
                "lead": "Fotoreseptör Rezervi",
                "items": [
                    "Patoloji: Fotoreseptör metabolik ve yapısal kaybı [s.43].",
                    "Görsel İlgi: En güçlü pozitif belirteç (r = 0.7-0.8).",
                    "Tedavi: Altta yatan ödem/traksiyonun hızla giderilmesi.",
                    "Hedef: Hasarın kalıcı skara dönüşmeden durdurulması."
                ],
                "footer": "En Güçlü Pozitif Görme Belirteci"
            },
            {
                "card_title": "HİPERREFLEKTİF ODAK (HRF)",
                "lead": "İnflamasyon Göstergesi",
                "items": [
                    "Patoloji: Aktive mikroglia ve lipid makrofaj göçü [s.44].",
                    "Görsel İlgi: Progresyon ve doku hasarı habercisi.",
                    "Tedavi: Steroid İmplant (Ozurdex) > Anti-VEGF.",
                    "Hedef: İnflamatuar fırtınanın ve göçün durdurulması."
                ],
                "footer": "Steroid Tedavisine Üstün Yanıt"
            },
            {
                "card_title": "DRIL (İÇ TABAKA YIKIMI)",
                "lead": "Nöral İletim Kopukluğu",
                "items": [
                    "Patoloji: İkinci sıra nöron ölümü ve Müller gliyozu [s.45].",
                    "Görsel İlgi: En güçlü negatif görme belirteci.",
                    "Tedavi: İskemi kontrolü ve erken yoğun anti-VEGF.",
                    "Hedef: DRIL alanı >500 μm olmadan müdahale."
                ],
                "footer": "En Güçlü Negatif Görme Belirteci"
            },
            {
                "card_title": "SHRM (SUBRETİNAL MATERYAL)",
                "lead": "Fibrin & Skar Riski",
                "items": [
                    "Patoloji: Fibrin, neovasküler damar veya taze kan [s.46].",
                    "Görsel İlgi: Erken erirse iyi, skarlaşırsa kalıcı körlük.",
                    "Tedavi: Yükleme dozlu acil Anti-VEGF / kombine PDT.",
                    "Hedef: Subretinal fibrozisin engellenmesi."
                ],
                "footer": "Acil Tedavi = Fibrozis Engeli"
            }
        ]
    )

    # =========================================================================
    # KONU 2.1.3: KOROİD GÖRÜNTÜLEME: EDI-OKT VE CVI (5 SLAYT)
    # =========================================================================
    # Slayt 2.1.3.1: EDI-OKT (Enhanced Depth Imaging) İlkeleri
    builder.add_study_card_slide(
        title="ENHANCED DEPTH IMAGING (EDI-OKT) FİZİKSEL PRENSİPLERİ",
        category="BÖLÜM 2.1.3: KOROİD GÖRÜNTÜLEME",
        subtitle="Sıfır Gecikme Hattının Koryosikleral Sınıra Kaydırılması ve Derinlik Kazancı",
        cards=[
            {
                "card_title": "SIFIR GECİKME HATTI (ZERO DELAY)",
                "lead": "Maksimum Duyarlılık Düzlemi",
                "items": [
                    "Standart OKT'de sıfır gecikme hattı vitreoretinal arayüzdedir (iç retina keskindir) [s.47].",
                    "EDI Prensibi: Cihaz göze yaklaştırılarak sıfır gecikme hattı koroid-sklera bileşkesine kaydırılır.",
                    "Ters Görüntü (Inverted Image): Ekrandaki görüntü ters çevrilir; maksimum hassasiyet koroid tabakasına odaklanır.",
                    "Fayda: SD-OKT cihazlarında donanım değiştirmeden koroidin derin anatomisini görünür kılar."
                ],
                "footer": "Sıfır Hattı Koroid Düzlemine Kaydırılır"
            },
            {
                "card_title": "SUBFOVEAL KOROİD KALINLIĞI (SFCT)",
                "lead": "Ölçüm Yöntemi ve Normal Aralık",
                "items": [
                    "Ölçüm Noktası: Foveola merkezinde RPE hiperreflektif bandının alt yüzünden sklera iç sınırına dik mesafe [s.48].",
                    "Sağlıklı Yetişkin: Ortalama 250 - 320 μm arasındadır [RV1:pdf478].",
                    "Yaşla İncelme: Her dekadda yaklaşık 15-20 μm fizyolojik koroid incelmesi görülür.",
                    "Miyopi Etkisi: Aksiyel uzunluktaki her 1 mm artış SFCT'yi yaklaşık 20-30 μm inceltir."
                ],
                "footer": "Normal SFCT: 250 - 320 μm"
            },
            {
                "card_title": "KLİNİK KULLANIM ALANLARI",
                "lead": "Pakikoroidden Atrofiye",
                "items": [
                    "Pakikoroid Hastalıkları: SFCT >350-400 μm; SSKR, pakikoroid neovaskülarizasyon ve PCV [s.48].",
                    "Enflamatuar Koroidopatiler: VKH ve sempatik oftalmide koroid kalınlığı 800-1000 μm'ye ulaşır.",
                    "Yaşa Bağlı Koroidal Atrofi: İleri yaşta SFCT <120 μm'ye iner; kuru YBMD ile birliktedir.",
                    "Tedavi Takibi: VKH'de sistemik steroid yanıtı SFCT'nin normale dönmesiyle izlenir."
                ],
                "footer": "Pakikoroid (>350 μm) vs Atrofi (<120 μm)"
            }
        ]
    )

    # Slayt 2.1.3.2: Koryoidal Vaskülarite İndeksi (CVI)
    builder.add_study_card_slide(
        title="KORYOİDAL VASKÜLARİTE İNDEKSİ (CVI) VE KANTİTATİF ANALİZ",
        category="BÖLÜM 2.1.3: KOROİD GÖRÜNTÜLEME",
        subtitle="Lümen Alanı / Toplam Koroid Alanı Oranı, Niblack Binarizasyonu ve Stroma Dengesi",
        cards=[
            {
                "card_title": "CVI NEDİR VE NASIL HESAPLANIR?",
                "lead": "Niblack Görüntü Binarizasyon Algoritması",
                "items": [
                    "CVI koroid kesitindeki damar lümen alanının (LCA) toplam koroid alanına (TCA) oranıdır [s.48].",
                    "Binarizasyon: OKT B-taraması Niblack algoritmasıyla siyah (lümen) ve beyaz (stroma) piksellere ayrılır.",
                    "Formül: CVI (%) = [Lümen Alanı (LCA) / Toplam Koroid Alanı (TCA)] × 100.",
                    "Sağlıklı Değer: Sağlıklı insan gözünde son derece stabildir; ortalama %65.0 ± %2.5 düzeyindedir."
                ],
                "footer": "CVI = LCA / TCA x 100 (~%65)"
            },
            {
                "card_title": "SFCT'YE ÜSTÜNLÜĞÜ",
                "lead": "Fizyolojik Faktörlerden Bağımsız İndeks",
                "items": [
                    "SFCT Değişkenliği: Yaş, tansiyon, göz içi basıncı, aks boyu ve diurnal ritimden aşırı etkilenir [s.49].",
                    "CVI Stabilitesi: Koroid kalınlığı değişse dahi lümen/stroma oranı sağlıklı popülasyonda sabit kalır.",
                    "Gerçek Vasküler Durum: Koroid kalınlaşmasının damar genişlemesinden mi (lümen artışı) yoksa stromal ödemden mi olduğunu ayırır.",
                    "Biyolojik Güvenilirlik: Karşılaştırmalı klinik araştırmalarda en güvenilir koroid biyobelirteçtir."
                ],
                "footer": "Diurnal Ritimden & Aks Boyundan Etkilenmez"
            },
            {
                "card_title": "KLİNİK PATOLOJİLERDE CVI",
                "lead": "Pakikoroid, Üveit ve Diyabet",
                "items": [
                    "Pakikoroid & SSKR: Haller damarlarının genişlemesine bağlı CVI belirgin olarak artar (>%68-70) [s.49].",
                    "VKH ve Arka Üveit: Erken evrede stromal inflamatuar ödem nedeniyle CVI düşer; tedaviyle toparlar.",
                    "Diyabetik Retinopati: Koroid mikrovasküler dökülmesine bağlı CVI retinopati evresiyle paralel azalır.",
                    "Coğrafi Atrofi: Koryokapillaris kaybı ve koroid sklerozu CVI'yi <%58 düzeyine düşürür."
                ],
                "footer": "SSKR: CVI Artar | VKH/Diyabet: CVI Düşer"
            }
        ]
    )

    # Slayt 2.1.3.3: Pakikoroid Spektrumu Biyobelirteçleri
    builder.add_study_card_slide(
        title="PAKİKORİD SPEKTRUMU TEMEL OKT BİYOBELİRTEÇLERİ",
        category="BÖLÜM 2.1.3: KOROİD GÖRÜNTÜLEME",
        subtitle="Pakivessel Varlığı, Koryokapillaris Basısı, RPE İncelmesi ve Haller Asimetrisi",
        cards=[
            {
                "card_title": "PAKİVESSEL (DEV DAMARLAR)",
                "lead": "Haller Tabakasında Patolojik Genişleme",
                "items": [
                    "Haller tabakasındaki dış koroid venlerinin lümen çapının patolojik olarak dev boyutlara ulaşmasıdır [s.49].",
                    "Asimetrik Drenaj: Genellikle vorteks ven çıkışındaki direnç nedeniyle bir kadranda göllenir.",
                    "Watershed Aşımı: Normalde foveayı besleyen anastomozsuz sınırları aşarak karşı kadrana uzanır.",
                    "Mekanik Bası: Genişleyen dev damar üzerindeki iç koroid tabakalarını yukarı doğru iter."
                ],
                "footer": "Genişlemiş Haller Damarları"
            },
            {
                "card_title": "KORYOKAPİLLARİS BASISI VE İNCELME",
                "lead": "Sattler ve Koryokapillarisin Silinmesi",
                "items": [
                    "Dev pakivessel doğrudan Bruch zarına doğru baskı yapar [s.50].",
                    "Tabaka Kaybı: Pakivessel üzerindeki Sattler tabakası tamamen kaybolur; koryokapillaris aşırı incelir.",
                    "Akım Boşluğu (Flow Void): OKTA'da dev damarın tam üzerindeki koryokapillariste perfüzyon kaybı izlenir.",
                    "RPE İskemisi: Koryokapillaris akımının kesilmesi üzerindeki RPE hücrelerinde metabolik krizi başlatır."
                ],
                "footer": "Pakivessel Üzerinde Koryo İskemisi"
            },
            {
                "card_title": "RPE PİGMENT EPİTELYOPATİSİ (PPE)",
                "lead": "Fokal Hiperplazi ve Mikrodekolmanlar",
                "items": [
                    "Kronik mekanik bası ve iskemi altındaki RPE tabakasında fokal atrofi ve hiperplazi gelişir [s.50].",
                    "Pakikoroid Pigment Epitelyopati (PPE): Pakikoroid zemininde subretinal sıvı olmaksızın RPE düzensizliğidir.",
                    "Mikro-PED: RPE altında küçük, sığ seröz dekolman odakları belirir.",
                    "Progresyon: PPE tedavi edilmeyen vakalarda SSKR ve Pakikoroid Neovaskülarizasyonun (PKNV) öncüsüdür."
                ],
                "footer": "PPE = Pakikoroid Spektrumunun Giriş Kapısı"
            }
        ]
    )

    # Slayt 2.1.3.4: Atlas Görseli: EDI-OKT Koroid Kalınlık Haritası
    img_p48 = builder.get_image_for_page(48)
    builder.add_atlas_image_slide(
        title="EDI-OKT KOROİD VE PAKİVESSEL ATLASI",
        category="BÖLÜM 2.1.3: GÖRSEL ATLAS",
        subtitle="Subfoveal Koroid Kalınlığı, Haller Tabakası Dev Damarları ve Koryosikleral Sınır",
        image_path=img_p48 or "dr_schema_0",
        caption="Referans Eser Sayfa 48: EDI-OKT ile Ölçülen 520 μm SFCT ve Haller Tabakasında Pakivessel Mimarisi",
        key_findings=[
            "Aşırı Koroid Kalınlığı (520 μm): Sağlıklı üst sınırın (>350 μm) çok üzerinde kalınlaşmış koroid [s.48].",
            "Pakivessel Lümenleri: Haller tabakasında RPE'yi yukarı doğru kubbeleştiren dev hiporeflektif venöz lümenler.",
            "Koryokapillaris Ezilmesi: Dev damarların tepe noktasında koryokapillaris bandının kağıt gibi incelmesi.",
            "Sklera İç Yüzeyi: Koroid damarlarının sonlandığı ve sklera liflerinin başladığı sınırın net seçilmesi."
        ],
        differentials=[
            "Normal Koroid (280 μm): Koryokapillaris, Sattler ve Haller tabakaları dengeli ve kademelidir.",
            "Miyopik Koroid (80 μm): Tüm koroid tabakaları silinmiş, sklera doğrudan RPE'ye yapışmıştır.",
            "Koroid Nevüsü: Koroid stromasında iç damarları örten homojen hiperreflektif dens kitle."
        ],
        clinical_pearl="Pakikoroid tanısı için tek başına koroid kalınlığı yetmez; koryokapillaris incelmesi ve pakivessel varlığı mutlaka gösterilmelidir; kalın koroidi olup damarları normal olan durumlar 'fizyolojik kalın koroid'dir [s.49]."
    )

    # Slayt 2.1.3.5: Akış Şeması: Koroid Kalınlık Değişimlerinde Ayırıcı Tanı
    builder.add_decision_tree_slide(
        title="KOROİD KALINLIĞI (SFCT) DEĞİŞİMLERİNDE AYIRICI TANI ALGORİTMASI",
        category="BÖLÜM 2.1.3: KARAR AĞACI",
        subtitle="Subfoveal Koroid Kalınlığı Artışı (>350 μm) vs Belirgin İncelmesi (<120 μm)",
        root_label="EDI-OKT VEYA SS-OKT İLE KOROİD KALINLIK ANALİZİ",
        branches=[
            {
                "label": "1. Kalın Koroid (>350 - 400 μm)",
                "criteria": "Haller damarlarında dev genişleme (pakivessel), lümen/stroma oranı yüksek (CVI >%68) [s.48].",
                "action": "Tanı: Pakikoroid Spektrumu (PPE, SSKR, PCV, PKNV) -> Tedavi: PDT veya mineralokortikoid / Anti-VEGF."
            },
            {
                "label": "2. Devasa Stromal Kalınlaşma (>600 - 1000 μm)",
                "criteria": "Lümen değil stromal infiltrasyon belirgin; çok odaklı büllöz seröz sıvı; CVI düşüktür [s.49].",
                "action": "Tanı: İnflamatuar (VKH, Sempatik Oftalmi, Sklerit) -> Tedavi: Acil yüksek doz sistemik kortikosteroid."
            },
            {
                "label": "3. İnce Koroid (<120 μm)",
                "criteria": "Tüm koroid damarlarında yaygın kayıp; sklera RPE'ye bitişik; aks boyu uzun veya ileri yaş [s.48].",
                "action": "Tanı: Yüksek Miyopi, Yaşa Bağlı Koroidal Atrofi (GCA), Kuru YBMD -> İzlem ve koruyucu filtreler."
            }
        ],
        bottom_rule="SFCT diurnal ritim gösterir (sabah kalın, akşam ince); takip ölçümleri hastada günün aynı saatinde yapılmalıdır [RV1:pdf479]."
    )

    print(f" -> Bölüm 2 (Görüntüleme) Kısım 1 Tamamlandı.")

    # =========================================================================
    # KONU 2.2.1: OKTA YÜZEYEL, DERİN VE FAZ ANALİZİ (5 SLAYT)
    # =========================================================================
    # Slayt 2.2.1.1: OKTA Prensibi ve Hareket Kontrastı
    builder.add_study_card_slide(
        title="OKT ANJİYOGRAFİ (OKTA) FİZİKSEL ÇALIŞMA PRENSİBİ",
        category="BÖLÜM 2.2.1: OKT ANJİYOGRAFİ",
        subtitle="Hareket Kontrastı, SSADA Algoritması, Tekrarlayan B-Taramaları ve Akım Dekorelasyonu",
        cards=[
            {
                "card_title": "HAREKET KONTRASTI (MOTION CONTRAST)",
                "lead": "Statik Doku vs Hareketli Eritrositler",
                "items": [
                    "OKTA intravenöz boya enjeksiyonuna ihtiyaç duymadan kan akımını 3 boyutlu haritalar [s.51].",
                    "Prensip: Aynı retina kesitinden mikrosaniyeler arayla ardışık B-taramaları alınır.",
                    "Statik Doku: Nörosensoryal retina dokusundan yansıyan ışığın genliği ve fazı değişmez.",
                    "Dinamik Akım: Damar içinden geçen eritrositler sinyalde zamana bağlı varyasyon (dekorelasyon) yaratır."
                ],
                "footer": "Boya Gerekmez / Eritrosit Hareketi"
            },
            {
                "card_title": "SSADA ALGORİTMASI",
                "lead": "Split-Spectrum Amplitude-Decorrelation",
                "items": [
                    "Geniş spektral bant matematiksel olarak daha dar alt bantlara bölünür [s.51].",
                    "Aksiyel Çözünürlük Dengesi: Spektrum bölünerek aksiyel rezolüsyon biraz feda edilir.",
                    "Sinyal/Gürültü Oranı (SNR): Alt bantların dekorelasyon sinyalleri birleştirilerek gürültü yok edilir.",
                    "Kan Akım Hızı: Yavaş kılcal damar akımları (0.4 - 3 mm/sn) dahi net kontrastla yakalanır."
                ],
                "footer": "Spektrum Bölme -> Düşük Gürültü"
            },
            {
                "card_title": "EN-FACE SEGMENTASYON DÜZLEMLERİ",
                "lead": "Katman Katman Vasküler Rekonstrüksiyon",
                "items": [
                    "En-Face Dilimleme: Cihaz retinal katman sınırlarını otomatik tanıyarak 2 boyutlu haritalar üretir [s.52].",
                    "Yüzeyel Vasküler Pleksus (SVP): İLM'den IPL/INL sınırına kadar olan arter ve ven dalları.",
                    "Derin Vasküler Pleksus (DVP): INL tabakası ile OPL alt sınırı arasındaki ince kapiller ağı.",
                    "Avasküler Dış Retina: OPL'den Bruch zarına kadar olan normalde sıfır akım içeren bölge."
                ],
                "footer": "SVP -> DVP -> Avasküler Dış Retina"
            }
        ]
    )

    # Slayt 2.2.1.2: Yüzeyel Pleksus (SVP) vs Derin Pleksus (DVP)
    builder.add_split_comparison_slide(
        title="OKTA VASKÜLER PLEKSUSLARI: YÜZEYEL (SVP) VS DERİN (DVP)",
        category="BÖLÜM 2.2.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Anatomik Tabakalanma, Damar Çapları, İskemi Duyarlılığı ve Patolojik Yanıtlar",
        left_entity={
            "name": "YÜZEYEL VASKÜLER PLEKSUS (SVP)",
            "features": [
                ("Anatomik Düzlem", "RNFL ve Ganglion Hücre Katmanı (GCL) içinde seyreder [s.52]."),
                ("Damar Mimarisi", "Dallanan büyük retinal arteriol ve venüller ile onları bağlayan kapillerler."),
                ("Dolaşım Şekli", "Radyal peripapiller kapiller ağı (RPC) optik disk çevresinde SVP'ye dahildir."),
                ("İskemi & İnfarkt", "Pamuk atılmış lekeler (cotton-wool spots) primer olarak SVP arteriol tıkanıklığıdır."),
                ("FA Benzerliği", "Geleneksel floresein anjiyografisinde görülen ana vasküler paterni yansıtır.")
            ]
        },
        right_entity={
            "name": "DERİN VASKÜLER PLEKSUS (DVP)",
            "features": [
                ("Anatomik Düzlem", "İç Nükleer Tabaka (INL) ve Dış Pleksiform Tabaka (OPL) sınırındadır [s.53]."),
                ("Damar Mimarisi", "Heksagonal 'vorteks benzeri' mikrokapiller anastomoz ağları içerir."),
                ("Dolaşım Şekli", "Düşük perfüzyon basınçlı terminal venöz yatak; iskemiye en hassas bölgedir."),
                ("İskemi & İnfarkt", "PAMM (Parasantral Akut Orta Makulopati) primer DVP enfarktını temsil eder."),
                ("Klinik Önemi", "Diyabetik retinopatide mikrovasküler dökülme ve kapiller silinme ilk DVP'de başlar.")
            ]
        },
        bottom_takeaway="Floresein anjiyografisi derin kapiller pleksusu (DVP) gösteremezken; OKTA her iki katmanı bağımsız segmente ederek mikrovasküler iskemiyi çok daha erken evrede yakalar [s.53]."
    )

    # Slayt 2.2.1.3: FAZ Alanı ve Sirkülarite İndeksi
    builder.add_study_card_slide(
        title="FOVEAL AVASKÜLER ZON (FAZ) OKTA KANTİTATİF ANALİZİ",
        category="BÖLÜM 2.2.1: OKT ANJİYOGRAFİ",
        subtitle="FAZ Alanı (mm²), Çevre Uzunluğu, Sirkülarite İndeksi ve İskemik Deformasyon",
        cards=[
            {
                "card_title": "KANTİTATİF FAZ PARAMETRELERİ",
                "lead": "Alan, Çevre ve Sirkülarite",
                "items": [
                    "FAZ Alanı (Area): Sağlıklı gözlerde ortalama 0.25 - 0.40 mm² arasındadır [s.53].",
                    "FAZ Çevresi (Perimeter): Normalde pürüzsüz ve yuvarlak bir kontura sahiptir (~2.0 - 2.5 mm).",
                    "Sirkülarite İndeksi: Dairesellik derecesidir; formülü 4π × Alan / (Çevre)², ideal değer 1.0'dır.",
                    "Sağlıklı Değer: Genç sağlıklı bireylerde sirkülarite indeksi >0.70 düzeyindedir."
                ],
                "footer": "Alan: 0.25-0.40 mm² | Sirkülarite >0.70"
            },
            {
                "card_title": "İSKEMİK DEFORMASYON KRİTERLERİ",
                "lead": "Kapiller Dökülme ve Kırıklı Kenarlar",
                "items": [
                    "Diyabetik Mikropatoloji: Prekapiller arteriollerin tıkanmasıyla sınır kapillerleri kaybolur [s.54].",
                    "FAZ Genişlemesi: FAZ alanı >0.50 mm² düzeyine çıkar; ilerlemiş vakalarda >1.0 mm²'yi aşar.",
                    "Sirkülarite Kaybı: Kenarlarda çentiklenmeler ve kırılmalarla indeks <0.50'nin altına düşer.",
                    "DVP FAZ Bozulması: Derin pleksustaki FAZ deformasyonu her zaman yüzeyel pleksustan daha ağırdır."
                ],
                "footer": "İskemi = Alan Artar & Sirkülarite Düşer"
            },
            {
                "card_title": "KLİNİK PROGNOSTİK KULLANIM",
                "lead": "Tedavi Yanıtı ve Görme Potansiyeli",
                "items": [
                    "Görsel Korelasyon: FAZ sirkülarite indeksi görme keskinliği ile en yüksek korelasyona sahip OKTA parametresidir [s.54].",
                    "İskemik Makulopati Tanısı: Ödemi kurutulmuş ancak görmesi artmayan DMÖ hastalarında genişlemiş FAZ sorumludur.",
                    "Retinopati Progresyonu: FAZ genişleme hızı diyabetik retinopatinin proliferatif faza geçiş riskini haber verir.",
                    "Otomatik Yazılım: Güncel cihazlar FAZ sınırlarını yapay zeka ile otomatik çizerek takip haritası çıkarır."
                ],
                "footer": "Sirkülarite İndeksi = Görme Keskinliği"
            }
        ]
    )

    # Slayt 2.2.1.4: Atlas Görseli: SVP, DVP ve FAZ Segmentasyonu
    img_p52 = builder.get_image_for_page(52)
    builder.add_atlas_image_slide(
        title="OKTA EN-FACE VASKÜLER PLEKSUS ATLASI",
        category="BÖLÜM 2.2.1: GÖRSEL ATLAS",
        subtitle="Yüzeyel Kapiller Ağ, Derin Kapiller Ağ ve Foveal Avasküler Zon Rekonstrüksiyonu",
        image_path=img_p52 or "dr_panel_5",
        caption="Referans Eser Sayfa 52: 3×3 mm OKTA En-Face Kesitlerinde Yüzeyel (SVP) ve Derin (DVP) Pleksus Mimarisi",
        key_findings=[
            "Yüzeyel Pleksus: Foveaya radyal yaklaşan lineer kapillerler ve pürüzsüz dairesel FAZ sınırı [s.52].",
            "Derin Pleksus: Heksagonal mikro-ünitelerden oluşan daha yoğun ve homojen kapiller ağı.",
            "Normal Avasküler Zon: 0.30 mm² alanda sıfır intralüminal akım sinyali içeren santral çukur.",
            "Radyal Peripapiller Ağ: Optik sinir başından çıkan uzun, dallanmayan aksonal kapillerler."
        ],
        differentials=[
            "Diyabetik İskemi: FAZ kenarlarında kapiller silinme, mikroanevrizmalar ve akım kaybı.",
            "RVO İskemisi: Tıkanan ven trasesine uyan kadranda derin kapiller pleksusun tamamen silinmesi.",
            "Telanjiektazi (MacTel 2): Temporal foveada derin pleksusta başlayıp dış retinaya inen anormal damarlar."
        ],
        clinical_pearl="Diyabetik retinopatide erken kapiller dökülme derin pleksusta başlar; bu nedenle erken taramada yalnızca yüzeyel pleksusa bakmak iskemiyi atlatabilir [s.53]."
    )

    # Slayt 2.2.1.5: Akış Şeması: OKTA ile Foveal İskemi Derecelendirmesi
    builder.add_horizontal_flowchart_slide(
        title="OKTA İLE DİYABETİK FOVEAL İSKEMİ DERECELENDİRME PROTOKOLÜ",
        category="BÖLÜM 2.2.1: AKIŞ ŞEMASI",
        subtitle="Görüntü Kalite Kontrolünden Kantitatif Vasküler Yoğunluk ve FAZ Ölçümüne",
        steps=[
            {
                "num": "1",
                "title": "Kalite Denetimi",
                "desc": "Sinyal gücü kontrolü (Q-score ≥7/10); göz kırpma ve hareket çizgilerinin dışlanması [s.51].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Segmentasyon Onayı",
                "desc": "Ödemli dokuda otomatik segmentasyon hatalarının kontrolü; İLM ve OPL sınırlarının düzeltilmesi.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "FAZ Kantifikasyonu",
                "desc": "SVP ve DVP düzeyinde FAZ alanı (mm²) ve sirkülarite indeksinin ölçülmesi.",
                "status": "warning"
            },
            {
                "num": "4",
                "title": "Vasküler Dansite (VD)",
                "desc": "Foveal ve parafoveal vasküler yoğunluk yüzdesinin (% cinsinden) normatif veriyle kıyaslanması.",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "Klinik Karar",
                "desc": "FAZ >0.5 mm² ve VD <%40 ise iskemik makulopati tanısı; anti-VEGF yanıt beklentisinin ayarlanması.",
                "status": "danger"
            }
        ],
        bottom_takeaway="İntraretinal kistler kapillerleri fiziksel olarak kenara iterek yalancı non-perfüzyon görüntüsü verebilir; kist duvarı ile gerçek kapiller silinmesi B-taraması akım overlay'i ile ayırt edilmelidir [s.54]."
    )

    # =========================================================================
    # KONU 2.2.2: KORYOKAPİLLARİS AKIM BOŞLUKLARI VE KNV (5 SLAYT)
    # =========================================================================
    # Slayt 2.2.2.1: Koryokapillaris Akım Boşlukları (Flow Voids)
    builder.add_study_card_slide(
        title="KORYOKAPİLLARİS AKIM BOŞLUKLARI (FLOW VOIDS) VE İSKEMİ",
        category="BÖLÜM 2.2.2: KORYOKAPİLLARİS OKTA",
        subtitle="En-Face Koryokapillaris Segmentasyonu, Eşikleme Yöntemleri ve Yaşlanma Etkisi",
        cards=[
            {
                "card_title": "KORYOKAPİLLARİS EN-FACE DİLİMİ",
                "lead": "Bruch Altındaki 10-20 μm'lik Tabaka",
                "items": [
                    "Segmentasyon: Bruch membranının 10 μm altından başlayan ve 20-30 μm kalınlığındaki dilimdir [s.55].",
                    "Granüler Akım Sinyali: Hızlı kan akımı nedeniyle normalde homojen, ince tuz-biber benzeri akım verir.",
                    "Akım Boşluğu (Flow Void): Akımın saptanamadığı karanlık, sinyalsiz mikroskobik adacıklardır.",
                    "Fizyolojik Durum: Genç sağlıklı gözlerde küçük (<20-30 μm) ve seyrek flow void alanları izlenir."
                ],
                "footer": "Bruch Altı Dilim & Tuz-Biber Deseni"
            },
            {
                "card_title": "KANTİTATİF ANALİZ VE BİNARİZASYON",
                "lead": "Phansalkar ve Otsu Eşikleme Yöntemleri",
                "items": [
                    "Lokal Eşikleme (Phansalkar): Görüntü pikselleri akım olan ve olmayan alanlara binarize edilir [s.55].",
                    "Flow Void Alanı (%): Toplam taranan alandaki akımsız piksellerin yüzdesidir.",
                    "Flow Void Boyut Dağılımı: Boşlukların ortalama çapı ve kümelenme eğilimi analiz edilir.",
                    "Yaşlanma İle Artış: 60 yaş üzerinde fizyolojik koryokapillaris dökülmesine bağlı boşluklar büyür."
                ],
                "footer": "Phansalkar Binarizasyonu ile % Alan Hesabı"
            },
            {
                "card_title": "KLİNİK PATOLOJİLERLE İLİŞKİ",
                "lead": "Kuru YBMD, Drusen ve Glokom",
                "items": [
                    "Kuru YBMD: Drusen çevresinde ve coğrafi atrofi sınırlarında dev flow void kümeleri gelişir [s.56].",
                    "Pakikoroid Spektrumu: Dilate Haller damarlarının tam üzerinde fokal koryokapillaris akım kaybı izlenir.",
                    "Glokom: Peripapiller koryokapillaris akım boşlukları görme alanı kaybıyla paralel genişler.",
                    "Prognostik Uyarı: Coğrafi atrofi gelişmeden önce koryokapillaris akım boşluklarının arttığı kanıtlanmıştır."
                ],
                "footer": "Flow Void Artışı = Atrofi Habercisi"
            }
        ]
    )

    # Slayt 2.2.2.2: Koroideal Neovaskülarizasyon (KNV) OKTA Tespiti
    builder.add_study_card_slide(
        title="OKTA İLE KOROİDEAL NEOVASKÜLARİZASYON (KNV) TESPİTİ",
        category="BÖLÜM 2.2.2: KORYOKAPİLLARİS OKTA",
        subtitle="Avasküler Dış Retinada Patolojik Damar Ağı, Tip 1 vs Tip 2 Morfolojisi ve Aktivite",
        cards=[
            {
                "card_title": "AVASKÜLER RETİNADA AKIM SİNYALİ",
                "lead": "Sıfır Akım Düzleminde Damar Yumağı",
                "items": [
                    "Normalde OPL ile RPE arasındaki dış retinada hiçbir kan damarı bulunmaz (avaskülerdir) [s.56].",
                    "Altın Standart Tarama: Avasküler dış retina diliminde saptanan herhangi bir organize akım KNV tanısı koydurur.",
                    "Boya Sızıntısı Yok: FA'daki gibi sızıntı ve floresein birikimi damarları gizlemez; damar mimarisi çıplaktır.",
                    "Yüksek Duyarlılık: Erken evre ve boyasız KNV lezyonlarını saptamada duyarlılığı >%90'dır."
                ],
                "footer": "Dış Retinada Akım = Kesin KNV"
            },
            {
                "card_title": "TİP 1 VE TİP 2 KNV MORFOLOJİSİ",
                "lead": "Sub-RPE vs Subretinal Damar Ağları",
                "items": [
                    "Tip 1 KNV (Sub-RPE): RPE ile Bruch membranı arasında yerleşir; geniş, olgun damar gövdeleri izlenir [s.57].",
                    "Tip 2 KNV (Subretinal): RPE'yi delip nörosensoryal retina altına çıkmıştır; parlak, kompakt medusa başı deseni.",
                    "Besleyici Damar (Feeder Vessel): Lezyonun merkezinde veya kenarında yüksek akımlı tekil ana kök damar.",
                    "Periferik Anastomoz Halkası: Aktif lezyonların dış kenarında minik kapiller arkadlar bulunur."
                ],
                "footer": "Tip 1: Sub-RPE | Tip 2: Subretinal Medusa"
            },
            {
                "card_title": "OKTA AKTİVİTE KRİTERLERİ",
                "lead": "Aktif Lezyon vs Tedaviye Yanıt",
                "items": [
                    "Aktif KNV Belirtileri: Yoğun ince dallanmalar (sprouting), periferik kapiller arkadlar ve hipointens halo [s.57].",
                    "Hipointens Perilezyonel Halo: KNV çevresindeki koryokapillariste çalma fenomenine (steal) bağlı akımsız halka.",
                    "İnaktif / Tedavi Edilmiş KNV: İnce kapillerler kaybolur; geriye kalın 'ölü ağaç dalı' (dead tree trunk) damarlar kalır.",
                    "Nüks Uyarısı: Kalın ana damarların uçlarından taze ince dallanmaların belirmesi nüksün habercisidir."
                ],
                "footer": "Aktif: İnce Kapillerler | İnaktif: Ölü Ağaç Dalı"
            }
        ]
    )

    # Slayt 2.2.2.3: Tip 1 vs Tip 2 vs Tip 3 KNV Karşılaştırması
    builder.add_split_comparison_slide(
        title="OKTA İLE KNV TİPLERİNİN MORFOLOJİK KARŞILAŞTIRMASI",
        category="BÖLÜM 2.2.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Tip 1 (Sub-RPE), Tip 2 (Subretinal) ve Tip 3 (Retinal Anjiyomatöz Proliferasyon - RAP)",
        left_entity={
            "name": "TİP 1 KNV (OKÜLT / SUB-RPE)",
            "features": [
                ("Anatomik Düzlem", "RPE'nin altında, Bruch membranının üzerinde yerleşir [s.57]."),
                ("OKTA Morfolojisi", "Geniş, yaygın, olgun damar ağı; deniz yelpazesi (sea-fan) paterni."),
                ("PED İlişkisi", "Fibrovasküler pigment epitel dekolmanı (PED) içinde akım sinyali verir."),
                ("FA Korelasyonu", "Klasik FA'da zayıf sızıntı veya geç boyanma (okült KNV)."),
                ("Anti-VEGF Yanıtı", "Yavaş küçülür; sıvı çekilse bile vasküler iskelet kalıcı kalabilir.")
            ]
        },
        right_entity={
            "name": "TİP 2 KNV (KLASİK / SUBRETİNAL)",
            "features": [
                ("Anatomik Düzlem", "RPE'yi yırtarak nörosensoryal retinanın tam altına çıkmıştır [s.58]."),
                ("OKTA Morfolojisi", "Kompakt, parlak, sınırları keskin medusa başı veya tekerlek (spoke-wheel) paterni."),
                ("SHRM İlişkisi", "OKT'de subretinal hiperreflektif materyalin (SHRM) tam içine oturur."),
                ("FA Korelasyonu", "Klasik FA erken fazında dantela benzeri hiperflöresans ve yoğun sızıntı."),
                ("Anti-VEGF Yanıtı", "Dramatik yanıt; kapiller dallar hızla geriler ancak skar riski yüksektir.")
            ]
        },
        bottom_takeaway="Tip 3 KNV (RAP) ise derin retinal kapiller pleksustan (DVP) başlayarak aşağıya doğru büyüyen retino-retinal anastomozdur; OKTA'da dik uzanan hairpin halkalarıyla tanınır [s.58]."
    )

    # Slayt 2.2.2.4: Atlas Görseli: Tip 1 ve Tip 2 KNV OKTA Ağları
    img_p57 = builder.get_image_for_page(57)
    builder.add_atlas_image_slide(
        title="OKTA İLE KNV VASKÜLER DALLANMA ATLASI",
        category="BÖLÜM 2.2.2: GÖRSEL ATLAS",
        subtitle="Avasküler Dış Retinada Medusa Başı Deseni, Besleyici Damar ve Çevre Halo",
        image_path=img_p57 or "dr_panel_3",
        caption="Referans Eser Sayfa 57: Neovasküler YBMD'de 3×3 mm OKTA Dış Retina En-Face Kesitinde Tip 2 KNV Ağı",
        key_findings=[
            "Medusa Başı Paterni: Tek bir santral gövdeden 360 derece radyal dağılan ince kapiller filizlenmeler [s.57].",
            "Besleyici Damar (Trunk): Lezyonun merkezinde yüksek sinyal veren kalın besleyici koroideal damar.",
            "Perilezyonel Hipointens Halo: Neovasküler yumağın çevresindeki koryokapillariste süzülen siyah iskemi çemberi.",
            "Dış Retina Akımı: Normalde simsiyah olması gereken avasküler dilimde parlayan organize damar mozaiği."
        ],
        differentials=[
            "Projeksiyon Artefaktı: Yüzeyel damarların gölgesinin dış retinada yalancı akım gibi belirmesi.",
            "Retinal Telanjiektazi: Anastomozlar iç retinadadır, koroid kökenli besleyici gövde içermez.",
            "İnaktif Fibrovasküler Skar: Yalnızca birkaç kalın, küt uçlu gövde; minik filiz kapillerleri yoktur."
        ],
        clinical_pearl="OKTA'da aktif KNV'yi inaktif skardan ayıran en güvenilir bulgu, lezyon sınırındaki küçük kapiller arkadlar (tiny loops) ve perilezyonel hipointens halodur [s.58]."
    )

    # Slayt 2.2.2.5: Akış Şeması: Neovasküler Lezyon Tedavi Takip Algoritması
    builder.add_horizontal_flowchart_slide(
        title="OKTA İLE NEOVASKÜLER YBMD TEDAVİ TAKİP PROTOKOLÜ",
        category="BÖLÜM 2.2.2: AKIŞ ŞEMASI",
        subtitle="Anti-VEGF Enjeksiyonları Sonrası Damarsal Morfoloji ve Reaktivasyon Tespiti",
        steps=[
            {
                "num": "1",
                "title": "Başlangıç Haritası",
                "desc": "Enjeksiyon öncesi KNV alanının (mm²), damar yoğunluğunun ve aktif filizlerin kaydedilmesi [s.56].",
                "status": "danger"
            },
            {
                "num": "2",
                "title": "Yükleme Dozu Yanıtı",
                "desc": "3 doz anti-VEGF sonrası ince kapiller arkadların kaybolması ve lezyonun 'budanması' (pruning).",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Matürasyon / İnaktivite",
                "desc": "Kalan kalın ana damarların (dead tree) stabil kalması; subretinal sıvının tamamen çekilmesi.",
                "status": "success"
            },
            {
                "num": "4",
                "title": "Reaktivasyon Taraması",
                "desc": "Treat-and-Extend uzatma fazında ana damar uçlarında taze kapiller tomurcuklanmanın izlenmesi.",
                "status": "warning"
            },
            {
                "num": "5",
                "title": "Tedavi Yeniden Yoğunlaştırma",
                "desc": "Taze filizlenme veya perilezyonel halo saptandığında sıvı henüz belirmeden enjeksiyon aralığının kısaltılması.",
                "status": "danger"
            }
        ],
        bottom_takeaway="OKTA, yapısal OKT'de sıvı belirmeden önce neovasküler damar filizlenmesini göstererek 'erken reaktivasyonu' sıvıdan haftalar önce haber verebilir [s.58]."
    )

    # =========================================================================
    # KONU 2.2.3: OKTA ARTEFAKTLARI VE KALİTE STANDARTLARI (5 SLAYT)
    # =========================================================================
    # Slayt 2.2.3.1: Projeksiyon Artefaktı ve Giderme Yöntemleri
    builder.add_study_card_slide(
        title="OKTA PROJEKSİYON ARTEFAKTI VE YAZILIMSAL GİDERME",
        category="BÖLÜM 2.2.3: OKTA ARTEFAKTLARI",
        subtitle="Yüzeyel Damar Gölgelerinin Dış Retinada Yalancı Akım Yaratması ve PAR Algoritmaları",
        cards=[
            {
                "card_title": "PROJEKSİYON ARTEFAKTI NEDİR?",
                "lead": "Derin Katmanlara Yansıyan Yalancı Akım",
                "items": [
                    "Yüzeyel damarlardan geçen ışık hareketli eritrositler tarafından modüle edilir [s.59].",
                    "Aşağıya Saçılma: Modüle olan ışık altındaki RPE veya dış retina tabakasına çarparak geri yansır.",
                    "Yalancı Pozitiflik: Cihaz alt katmanda da eritrosit hareketi varmış gibi sahte akım sinyali üretir.",
                    "Sonuç: Avasküler dış retinada gerçekte olmayan yalancı neovaskülarizasyon veya damarlar görünür."
                ],
                "footer": "Yüzeyel Damarın Alt Katmana Yansıması"
            },
            {
                "card_title": "PROJECTION ARTIFACT REMOVAL (PAR)",
                "lead": "Matematiksel Projeksiyon Temizleme",
                "items": [
                    "Yazılımsal Filtreler: Modern OKTA cihazları PAR (Projection Artifact Removal) algoritmaları kullanır [s.59].",
                    "Piksel Kıyaslaması: Derin katmandaki akım sinyali tam üzerindeki yüzeyel damarla birebir örtüşüyorsa silinir.",
                    "Aşırı Temizleme Riski: Bazen gerçek Tip 2 KNV lezyonunun üst katmanla çakışan damarları PAR ile yanlışlıkla silinebilir.",
                    "B-Scan Doğrulama: Şüpheli durumlarda B-taraması üzerindeki akım pikselleri (flow overlay) incelenmelidir."
                ],
                "footer": "PAR Yazılımı & Aşırı Silme Riski"
            },
            {
                "card_title": "KLİNİK AYIRICI TANI KRİTERİ",
                "lead": "Gerçek KNV vs Projeksiyon",
                "items": [
                    "Yüzeyel İz Düşümü: Projeksiyon artefaktı yüzeyel damarların geometrisiyle birebir aynı deseni taşır [s.60].",
                    "Gerçek KNV Ayrımı: Gerçek KNV yüzeyel damarlardan tamamen bağımsız, rastgele bir anastomotik yumak oluşturur.",
                    "Yapısal Karşılık: Gerçek KNV yapısal B-taramasında hiperreflektif bir kitle (PED veya SHRM) oluşturur.",
                    "Projeksiyon Kitlesi Yoktur: Projeksiyon artefaktında yapısal B-taramasında lezyon kütlesi bulunmaz."
                ],
                "footer": "Yüzeyel Damarla Örtüşme = Artefakt"
            }
        ]
    )

    # Slayt 2.2.3.2: Segmentasyon Hataları ve Düzeltilmesi
    builder.add_study_card_slide(
        title="OKTA SEGMENTASYON HATALARI VE DÜZELTME STRATEJİLERİ",
        category="BÖLÜM 2.2.3: OKTA ARTEFAKTLARI",
        subtitle="Ödem, Kist, Yüksek Miyopi ve Deforme Anatomide Otomatik Sınır Kaymaları",
        cards=[
            {
                "card_title": "OTOMATİK SEGMENTASYON ÇÖKMESİ",
                "lead": "Bozulmuş Anatomide Yazılım Yanılgısı",
                "items": [
                    "OKTA yazılımları sağlıklı retinanın düzgün hiper/hiporeflektif bantlarına göre programlanmıştır [s.60].",
                    "Ödem ve Kistler: Devasa intraretinal kistler tabaka sınırlarını bükerek algoritmayı şaşırtır.",
                    "PED ve Kitleler: RPE dekolmanlarında cihaz Bruch zarı ile RPE'yi karıştırır.",
                    "Sonuç: 'Dış retina' en-face dilimine gerçekte yüzeyel veya derin pleksus damarları dahil olur."
                ],
                "footer": "Kist ve Ödem Segmentasyonu Kaydırır"
            },
            {
                "card_title": "YALANCI KNV VE YALANCI İSKEMİ",
                "lead": "Yanlış Dilimlemenin Klinik Bedeli",
                "items": [
                    "Yalancı KNV (False Positive): Segmentasyon çizgisi derin pleksusa kaydığında normal kapillerler KNV sanılır [s.60].",
                    "Yalancı İskemi (False Negative): Çizgi avasküler alana kayarsa normal damarlı bölge 'ölü doku' gibi siyah görünür.",
                    "Miyopik Stafilom: Aşırı eğimli sklerada tarama çizgisi eğimi takip edemez; temporalde kesit kayar.",
                    "Kural: En-face OKTA görüntüsüne bakmadan önce mutlaka B-taramasındaki segmentasyon çizgileri kontrol edilmelidir."
                ],
                "footer": "Segmentasyon Kayması = Yanlış Tanı"
            },
            {
                "card_title": "MANUEL SEGMENTASYON DÜZELTME",
                "lead": "Klinisyenin Dijital Müdahalesi",
                "items": [
                    "Çizgiyi Elle Taşıma: Cihaz ara yüzünde İLM, OPL veya RPE referans çizgisi manuel olarak doğru sınıra çekilir [s.61].",
                    "Özelleştirilmiş Dilim Kalınlığı: Dilim kalınlığı 20 μm'den 40-50 μm'ye genişletilerek kitle tamamen kapsanır.",
                    "Eğrilik Düzeltme (Flattening): Fovea eğriliği algoritmik olarak düzleştirilerek homojen kesit elde edilir.",
                    "Tekrar Çekim: Deformasyon düzeltilemeyecek kadar ciddiyse tarama açısı küçültülerek (6x6 yerine 3x3) tekrarlanır."
                ],
                "footer": "Manuel Çizgi Düzeltme Zorunluluğu"
            }
        ]
    )

    # Slayt 2.2.3.3: Hareket, Gölgeleme ve Yalancı Akım Artefaktları
    builder.add_study_card_slide(
        title="HAREKET (MOTION) VE GÖLGELEME (SHADOWING) ARTEFAKTLARI",
        category="BÖLÜM 2.2.3: OKTA ARTEFAKTLARI",
        subtitle="Mikrosakkadlar, Göz Kırpma Çizgileri, Kanama Engeli ve Sinyal Eşik Değerleri",
        cards=[
            {
                "card_title": "HAREKET ARTEFAKTI (MOTION ARTIFACT)",
                "lead": "Sakkadlar ve Göz Kırpma Çizgileri",
                "items": [
                    "Mikrosakkadlar: Tarama sırasında gözün istemsiz mikro hareketleri görüntüde yatay/dikey basamaklar yaratır [s.61].",
                    "Göz Kırpma: Göz kapağının anlık kapanması en-face haritada siyah veya beyaz yatay kör çizgiler oluşturur.",
                    "Yazılımsal Eye-Tracking: Çift kamera ve gerçek zamanlı takip sistemleri hareketi minimize eder.",
                    "Kalite Eşiği: Cihaz sinyal kalite skoru (Q-score) minimum 7/10 olmalıdır; altı güvenilmezdir."
                ],
                "footer": "Yatay Çizgiler = Göz Kırpma / Sakkad"
            },
            {
                "card_title": "GÖLGELEME (SHADOWING) ETKİSİ",
                "lead": "Optik Engeller Arkasında Sinyal Kaybı",
                "items": [
                    "Pre-retinal Engeller: Vitreus kanaması, yoğun floaters veya asteroid hyalozis ışığı bloke eder [s.61].",
                    "İntraretinal Engeller: Yoğun preretinal veya intraretinal kanamalar, kalın sert eksüda plakları.",
                    "Yalancı Non-Perfüzyon: Işık alt tabakaya ulaşamadığı için koryokapillaris kapkara görünür (yalancı iskemi).",
                    "Doğrulama: Yapısal OKT kesitinde altta sinyal kararması (black shadowing) varsa akım kaybı gerçek değildir."
                ],
                "footer": "Kanama Arkası Yalancı İskemi Yaratır"
            },
            {
                "card_title": "YALANCI AKIM (UNMASKING ARTEFAKTI)",
                "lead": "RPE Atrofisi Arkasında Aşırı Sinyal",
                "items": [
                    "Unmasking Etkisi: Coğrafi atrofi veya RPE yırtığında melanin kalkanı ortadan kalkar [s.62].",
                    "Derin Koroid Işıklaması: Işık normalden çok daha derine (büyük Haller damarlarına) kolayca sızar.",
                    "Yalancı Neovaskülarizasyon: Derin koroid venlerinin akımı avasküler retina dilimine sızarak KNV sanılabilir.",
                    "Yapısal Eşleşme: Aşırı sinyalin tam üzerinde RPE atrofisi ve hipertransmisyon olduğu teyit edilmelidir."
                ],
                "footer": "RPE Yokluğu = Yalancı KNV Sinyali"
            }
        ]
    )

    # Slayt 2.2.3.4: Atlas Görseli: OKTA Artefaktları Karşılaştırma Galerisi
    img_p61 = builder.get_image_for_page(61)
    builder.add_atlas_image_slide(
        title="OKTA ARTEFAKT TESPİT VE AYIRICI TANI ATLASI",
        category="BÖLÜM 2.2.3: GÖRSEL ATLAS",
        subtitle="Projeksiyon Kalıntısı, Segmentasyon Kayması, Sakkad Çizgileri ve Gölgeleme",
        image_path=img_p61 or "dr_panel_6",
        caption="Referans Eser Sayfa 61: En-Face OKTA'da Tipik Artefakt Örnekleri ve Yanıltıcı Bulgular",
        key_findings=[
            "Projeksiyon İzi: Dış retinada yüzeyel retinal damarların birebir gölge haritasının parlaması [s.61].",
            "Segmentasyon Basamağı: Kist kenarında fokal çizgi kayması sonucu beliren yarım ay biçimli yalancı defekt.",
            "Göz Kırpma Bandı: Görüntüyü boydan boya kesen homojen siyah transvers şerit.",
            "Katarakt Kararması: Görüntü merkezinde veya kenarında sinyal gücü düşüklüğüne bağlı yaygın gürültü artışı."
        ],
        differentials=[
            "Gerçek İskemi vs Gölgeleme: İskemide yapısal B-taraması parlaktır; gölgelemede tüm katmanlar karanlıktır.",
            "Gerçek KNV vs Projeksiyon: KNV yüzeyel damarlarla örtüşmez; kendine özgü saçaklı mimarisi vardır.",
            "Gerçek Mikroanevrizma vs Gürültü: Mikroanevrizma B-taramasında intraretinal akım odağı olarak doğrulanır."
        ],
        clinical_pearl="OKTA'da patolojik bir lezyon raporlanmadan önce mutlaka B-taramasındaki akım örtüşmesi (flow overlay) incelenmeli; lezyonun yapısal bir karşılığı olduğu teyit edilmelidir [s.62]."
    )

    # Slayt 2.2.3.5: Karşılaştırmalı Özet Tablosu: Artefakt Çözüm Matrisi
    builder.add_study_card_slide(
        title="OKTA ARTEFAKTLARI VE PRATİK ÇÖZÜM STRATEJİLERİ MATRİSİ",
        category="BÖLÜM 2.2.3: ARTEFAKT MATRİSİ",
        subtitle="Klinik Görünüm, Yanıltıcı Tanı Riski ve Düzeltme Yöntemleri",
        cards=[
            {
                "card_title": "PROJEKSİYON ARTEFAKTI",
                "lead": "Dış Retinada Sahte Damar",
                "items": [
                    "Görünüm: Dış retinada yüzeyel damar kopyası [s.59].",
                    "Yanılgı: Yalancı KNV tanısı.",
                    "Çözüm: PAR algoritmasını aktifleştir; B-scan flow overlay'de sinyalin RPE üzerinde kalıp kalmadığını kontrol et."
                ],
                "footer": "PAR Yazılımı + B-Scan Kontrolü"
            },
            {
                "card_title": "SEGMENTASYON KAYMASI",
                "lead": "Dilim Sınırının Bozulması",
                "items": [
                    "Görünüm: Damar ağında ani kesilme veya yabancı damarlar [s.60].",
                    "Yanılgı: Yalancı iskemi veya yanlış KNV tipi.",
                    "Çözüm: B-taraması referans çizgilerini elle (manuel) doğru katman sınırına taşı ve dilimi genişlet."
                ],
                "footer": "Manuel Çizgi Düzeltme"
            },
            {
                "card_title": "HAREKET & KIRPMA",
                "lead": "Çizgilenme ve Basamaklanma",
                "items": [
                    "Görünüm: Transvers siyah/beyaz bantlar [s.61].",
                    "Yanılgı: Takipte yalancı progresyon.",
                    "Çözüm: Eye-tracking kontrolü; çekimi Q-score ≥7 olana dek hemen tekrarla."
                ],
                "footer": "Q-Score ≥7 ile Tekrar Çekim"
            },
            {
                "card_title": "GÖLGELEME (SHADOWING)",
                "lead": "Kanama / Eksüda Altı Kararma",
                "items": [
                    "Görünüm: Derin katmanda kapkara defekt [s.61].",
                    "Yanılgı: Yaygın koryokapillaris enfarktı.",
                    "Çözüm: Yapısal OKT ile üstte kanama/eksüda olduğunu doğrula; akım kaybını iskemi olarak raporlama."
                ],
                "footer": "Yapısal Karartı Doğrulaması"
            }
        ]
    )

    # =========================================================================
    # KONU 2.3.1: FA HİPERFLÖRESANS VE HİPOFLÖRESANS PATERNLERİ (5 SLAYT)
    # =========================================================================
    # Slayt 2.3.1.1: Floresein Anjiyografisi Prensipleri ve Fazları
    builder.add_study_card_slide(
        title="FUNDUS FLORESEİN ANJİYOGRAFİSİ (FA) DİNAMİK FAZLARI",
        category="BÖLÜM 2.3.1: FLORESEİN ANJİYOGRAFİ",
        subtitle="Mavi Uyarıcı (490 nm), Sarı-Yeşil Emisyon (520 nm) ve Zamana Bağlı Dolaşım Fazları",
        cards=[
            {
                "card_title": "OPTİK VE FİZİKSEL PRENSİP",
                "lead": "Eksitasyon ve Emisyon Filtreleri",
                "items": [
                    "Sodyum Floresein: Düşük molekül ağırlıklı (376 Da) hidrofilik florofor boyadır [s.63].",
                    "Eksitasyon (Uyarı): 490 nm mavi ışıkla uyarılır; elektronları üst enerji düzeyine fırlar.",
                    "Emisyon (Işıma): Temel düzeye dönerken 520-530 nm sarı-yeşil ışık yayar.",
                    "Bariyer Filtresi: Kameradaki filtre yalnızca yayılan sarı-yeşil ışığı geçirir; mavi ışığı engeller."
                ],
                "footer": "490 nm Mavi Uyarım -> 520 nm Sarı Emisyon"
            },
            {
                "card_title": "KRONOLOJİK DOLAŞIM FAZLARI",
                "lead": "Kol-Retina Zamanı ve Dolaşım",
                "items": [
                    "Kol-Retina Zamanı: Ön koldan enjeksiyondan göze ulaşma süresi 8 - 12 saniyedir [s.63].",
                    "1. Koroideal Faz (8-10 sn): Koroid lobüllerinin yamalı dolumu ve arka plan parıltısı.",
                    "2. Arteryel Faz (10-12 sn): Retinal arterlerin dolumu.",
                    "3. Arteriyovenöz (Laminer) Faz: Ven duvarlarında çizgisel laminer akım izlenir.",
                    "4. Venöz Faz (15-20 sn): Venlerin tam dolumu; kapiller yatak maksimum parlaklıktadır."
                ],
                "footer": "Kol-Retina: 8-12 sn | Laminer -> Venöz Faz"
            },
            {
                "card_title": "GEÇ FAZ VE ELİMİNASYON",
                "lead": "Resirkülasyon ve Geç Fazlar (5-10 dk)",
                "items": [
                    "Resirkülasyon Fazı (1-3 dk): Boya konsantrasyonu düşer; damar parlaklığı azalır [s.64].",
                    "Geç Faz (5-10 dk): Normal damarlar tamamen boşalır; yalnızca sklera, optik disk kenarı ve Bruch hafif boyanır.",
                    "Patolojik Tutulum: Geç fazda devam eden veya artan hiperflöresans patolojiktir (sızıntı veya boyanma).",
                    "Eliminasyon: Boya karaciğerde metabolize edilir ve 24-36 saat içinde idrarla atılır."
                ],
                "footer": "5-10 dk Geç Faz: Sağlıklı Damar Boşalır"
            }
        ]
    )

    # Slayt 2.3.1.2: Hiperflöresans Mekanizmaları
    builder.add_study_card_slide(
        title="FA HİPERFLÖRESANSIN 4 TEMEL MEKANİZMASI",
        category="BÖLÜM 2.3.1: FLORESEİN ANJİYOGRAFİ",
        subtitle="Sızıntı (Leakage), Boyanma (Staining), Göllenme (Pooling) ve Pencere Defekti (Window)",
        cards=[
            {
                "card_title": "1. SIZINTI (LEAKAGE)",
                "lead": "Bariyer Yıkımı / Boyut ve Parlaklık Artar",
                "items": [
                    "Tanım: Bozulmuş endotelden veya KNV damarlarından boyanın serbest doku aralığına kaçmasıdır [s.64].",
                    "Kritik Kriter: Hiperflöresansın alanı (boyutu) VE parlaklığı zamana bağlı olarak sürekli büyür.",
                    "Sınırlar: Sınırlar belirsizleşir, çevre dokuya doğru bulanık bir parlaklık yayılır.",
                    "Örnekler: Aktif KNV, PDR neovaskülarizasyonları, makula ödemi (DMÖ, RVO), retinal vaskülit."
                ],
                "footer": "Zamanla Boyut ve Parlaklık Artar"
            },
            {
                "card_title": "2. GÖLLENME (POOLING)",
                "lead": "Anatomik Boşlukta Sıvı Birikimi",
                "items": [
                    "Tanım: Boyanın önceden var olan anatomik bir boşluğa dolup birikmesidir [s.64].",
                    "Kritik Kriter: Parlaklık zamanla artar ancak sınırları kesinlikle anatomik boşluğun dışına taşmaz.",
                    "Sınırlar: Keskin ve sabittir; boşluğun tavanı ve tabanı boyanın yayılmasını sınırlar.",
                    "Örnekler: Seröz PED (RPE dekolmanı kubbesi), SSKR'de subretinal boşluğa göllenme."
                ],
                "footer": "Parlaklık Artar / Sınırlar Sabit Kalır"
            },
            {
                "card_title": "3. BOYANMA (STAINING)",
                "lead": "Solid Dokunun Boyayı Tutması",
                "items": [
                    "Tanım: Fibröz skar, sklera veya drusen gibi solid doku matrisinin boyayı hapsetmesidir [s.65].",
                    "Kritik Kriter: Geç fazda parlaklık belirginleşir ancak sızıntı gibi kenarlara doğru yayılmaz.",
                    "Sınırlar: Skarın veya dokunun sınırlarıyla birebir örtüşür.",
                    "Örnekler: Disiform skar dokusu, sklera çıplaklığı, optik disk fizyolojik geç boyanması."
                ],
                "footer": "Skar / Doku Boyanır / Yayılmaz"
            },
            {
                "card_title": "4. PENCERE DEFEKTİ (TRANSMİSYON)",
                "lead": "RPE Pigment Kaybı / Erken Parlar",
                "items": [
                    "Tanım: RPE melanin pigmentinin kaybı sonucu alttaki normal koroid parıltısının öne sızmasıdır [s.65].",
                    "Kritik Kriter: Koroideal dolumla (çok erken) aynı anda parlar; geç fazda koroidle birlikte söner.",
                    "Boyut Değişmez: Alan asla büyümez; sızıntı veya sınır bulanıklaşması görülmez.",
                    "Örnekler: RPE atrofisi, kuru YBMD, delinmiş makula deliği tabanı."
                ],
                "footer": "Erken Parlar / Büyümez / Geç Fazda Söner"
            }
        ]
    )

    # Slayt 2.3.1.3: Hipoflöresans Mekanizmaları
    builder.add_study_card_slide(
        title="FA HİPOFLÖRESANSIN 2 TEMEL MEKANİZMASI",
        category="BÖLÜM 2.3.1: FLORESEİN ANJİYOGRAFİ",
        subtitle="Vasküler Dolum Eksikliği (Non-Perfüzyon) vs Ön Engel Tarafından Gölgeleme (Maskeleme)",
        cards=[
            {
                "card_title": "1. DOLUM EKSİKLİĞİ (NON-PERFÜZYON)",
                "lead": "Damarsal Tıkanıklık ve Akım Yokluğu",
                "items": [
                    "Tanım: Retinal veya koroideal damarların tıkalı olması sonucu boyanın dokuya hiç ulaşamamasıdır [s.65].",
                    "Kritik Kriter: Damar lümeni boş kalır; anjiyografinin hiçbir fazında dolum izlenmez.",
                    "Koroideal Dolum Defekti: Koryokapillaris lobül tıkanıklığı (akut dev hücreli arterit, Elschnig lekesi).",
                    "Retinal Non-Perfüzyon: Diyabetik kapiller kapanma alanları, BRVO/CRVO iskemik alanları, CRAO tablosu."
                ],
                "footer": "Damar Tıkalı / Boya Hiç Ulaşamaz"
            },
            {
                "card_title": "2. MASKELEME (BLOCKED FLUORESCENCE)",
                "lead": "Optik Engelle Işığın Örtülmesi",
                "items": [
                    "Tanım: Alttaki normal floresans ışımasının önde yer alan opak bir materyalce emilmesi veya saçılmasıdır [s.66].",
                    "Kritik Kriter: Alttaki damarlar sağlamdır ancak görüntüye ulaşamaz; fundus muayenesindeki lezyonla birebir çakışır.",
                    "Gölgeleyen Materyaller: Kanama (preretinal, intraretinal, subretinal), yoğun melanin hiperplazisi, lipid, lipofuskin.",
                    "Preretinal Kanama: Hem retinal hem koroid damarlarını tamamen maskeler; karanlık ada oluşturur."
                ],
                "footer": "Altta Floresans Var / Öndeki Madde Engeller"
            },
            {
                "card_title": "KLİNİK AYIRICI TANI KRİTERİ",
                "lead": "Non-Perfüzyon vs Maskeleme Ayrımı",
                "items": [
                    "Biyomikroskopi Kontrolü: Renkli fundus fotoğrafında o alanda görünür opak bir lezyon (kan, pigment) var mı? [s.66]",
                    "Varsa: Tablo maskelenmiş hipoflöresanstır (blocked fluorescence).",
                    "Yoksa (Retina Berraksa): Tablo kesinlikle kapiller non-perfüzyondur (iskemi).",
                    "Klinik Önemi: Non-perfüzyon alanları VEGF salgılatarak neovaskülarizasyonu tetikler; lazer gerektirir."
                ],
                "footer": "Fundusta Kan Varsa = Maskeleme | Yoksa = İskemi"
            }
        ]
    )

    # Slayt 2.3.1.4: Atlas Görseli: FA Paternleri ve Sızıntı Dinamiği
    img_p63 = builder.get_image_for_page(63)
    builder.add_atlas_image_slide(
        title="FLORESEİN ANJİYOGRAFİSİ PATERN TANIMA ATLASI",
        category="BÖLÜM 2.3.1: GÖRSEL ATLAS",
        subtitle="Erken Koroideal Dolum, Petalloid Sızıntı, RPE Pencere Defekti ve Non-Perfüzyon",
        image_path=img_p63 or "dr_panel_7",
        caption="Referans Eser Sayfa 63: Diyabetik Retinopati ve Makula Ödeminde Erken ve Geç Faz FA Paternleri",
        key_findings=[
            "Mikroanevrizmalar: Erken arteriyel fazda beliren sayısız parlak noktasal hiperflöresan odak [s.63].",
            "Petalloid Sızıntı: Geç fazda (10. dk) fovea merkezinde çiçek yaprağı biçiminde biriken yoğun hiperflöresans.",
            "Kapiller Non-Perfüzyon: Damarsızlaşmış, kapkara retina adacıkları ve kenarlarında telanjiektazik damarlar.",
            "Optik Disk Boyanması: Geç fazda optik sinir başının fizyolojik veya vaskülitik parlak boyanması."
        ],
        differentials=[
            "Sızıntı vs Boyanma: Sızıntı geç fazda foveayı taşarak bulanıklaşır; boyanma sınırlı kalır.",
            "Pencere Defekti vs Sızıntı: Pencere defekti erken fazda parlaktır ancak geç fazda tamamen söner.",
            "Subretinal Kanama: Tüm fazlarda zifiri karanlık maskeleme alanı olarak kalır."
        ],
        clinical_pearl="Diyabetik makula ödeminde kistoid boşlukların petalloid dizilimi, foveal Henle lif tabakasının oblik radyal yöneliminin doğrudan bir sonucudur [RV1:pdf469]."
    )

    # Slayt 2.3.1.5: Karar Ağacı: Anjiyografik Anomali Analiz Algoritması
    builder.add_decision_tree_slide(
        title="FA ANOMALİLERİNİ DEĞERLENDİRME VE AYIRICI TANI ALGORİTMASI",
        category="BÖLÜM 2.3.1: KARAR AĞACI",
        subtitle="Hiperflöresans ve Hipoflöresans Bulgularında Adım Adım Akıl Yürütme",
        root_label="FA GÖRÜNTÜSÜNDE SAPTANAN FLÖRESANS ANOMALİSİ",
        branches=[
            {
                "label": "1. Hiperflöresans Saptandı",
                "criteria": "Geç fazda alan ve parlaklık artıyorsa = Sızıntı (KNV, ödem, vaskülit); Sabit anatomik sınırlıysa = Göllenme (PED, SSKR); Erken parlayıp sönüyorsa = Pencere Defekti [s.64].",
                "action": "Karar: Bariyer yıkımı doğrulanır -> Anti-VEGF, steroid veya fokal lazer endikasyonu."
            },
            {
                "label": "2. Hipoflöresans Saptandı",
                "criteria": "Fundusta kanama/pigment varsa = Maskeleme; Fundus berrak ancak damar dolmuyorsa = Kapiller Non-Perfüzyon (İskemi) [s.65].",
                "action": "Karar: Non-perfüzyon alanı >10 disk çapı ise iskemik retinopati -> PRP lazer veya yakın takip."
            },
            {
                "label": "3. Mikst Patern (Hiper + Hipo)",
                "criteria": "Kanama odaklarının maskelediği alanların kenarından yoğun sızıntı yapan neovaskülarizasyonlar [s.64].",
                "action": "Karar: Yüksek riskli Proliferatif Retinopati (PDR) -> Acil panretinal fotokoagülasyon (PRP)."
            }
        ],
        bottom_rule="FA floresan sızıntısını ve dinamik kaçakları göstermede rakipsizdir; ancak derin kapiller pleksusu ve koryokapillaris akımını göstermede OKTA'nın gerisindedir [s.66]."
    )

    # =========================================================================
    # KONU 2.3.2: ICG KOROİD DOLAŞIMI VE POLİPOİDAL LEZYONLAR (5 SLAYT)
    # =========================================================================
    # Slayt 2.3.2.1: İndosiyanin Yeşili (ICG) Farmakofiziksel Özellikleri
    builder.add_study_card_slide(
        title="İNDOSİYANİN YEŞİLİ ANJİYOGRAFİSİ (ICGA) PRENSİPLERİ",
        category="BÖLÜM 2.3.2: ICG ANJİYOGRAFİ",
        subtitle="Yakın Kızılötesi Optik, %98 Plazma Protein Bağlanması ve Koroid Bariyeri",
        cards=[
            {
                "card_title": "YAKIN KIZILÖTESİ SPEKTRUM",
                "lead": "805 nm Uyarım / 835 nm Emisyon",
                "items": [
                    "Dalga Boyu: 805 nm yakın kızılötesi ışıkla uyarılır, 835 nm dalga boyunda ışır [s.68].",
                    "RPE Penetrasyonu: Melanin, ksantofil pigmenti, lipofuskin ve subretinal kandan kolayca geçer.",
                    "Derin Görünürlük: Floreseinin göremediği RPE altındaki koroid damarlarını berrak gösterir.",
                    "Medya Opasitesi Üstünlüğü: Hafif katarakt ve kanama varlığında dahi koroid dolaşımını tarayabilir."
                ],
                "footer": "Yakın Kızılötesi = RPE ve Kanı Aşar"
            },
            {
                "card_title": "%98 PROTEİN BAĞLANMA ÖZELLİĞİ",
                "lead": "Yüksek Moleküler İntravasküler Retansiyon",
                "items": [
                    "Protein Bağlanması: Kanda dolaşan ICG moleküllerinin %98'i plazma proteinlerine (özellikle albumin ve lipoproteinler) bağlanır [s.68].",
                    "Koryokapillaris Fenestrası: Koryokapillaris pencereleri serbest floreseini sızdırırken, büyük ICG-protein kompleksini tutar.",
                    "Düşük Ekstravazasyon: Koroid damarlarından çevre stromaya hızla kaçmaz; damar lümeninde kalır.",
                    "Sonuç: Koroidal damar mimarisi, anastomozlar ve polipoidal dilatasyonlar kristal netliğinde izlenir."
                ],
                "footer": "%98 Proteine Bağlı = Koroid İçinde Kalır"
            },
            {
                "card_title": "METABOLİZMA VE KONTRENDİKASYON",
                "lead": "Karaciğer Klirensi ve İyot İçeriği",
                "items": [
                    "Karaciğer Eliminasyonu: Böbrekten atılmaz; karaciğer tarafından safraya salgılanır [s.69].",
                    "Böbrek Yetmezliğinde Güvenli: Ağır diyabetik nefropatide dahi (diyaliz hastaları dahil) güvenle uygulanabilir.",
                    "İyot Alerjisi Riski: Liyofilize preparat çözünürlüğü artırmak için sodyum iyodür içerir.",
                    "Kontrendikasyon: İyot veya kabuklu deniz ürünleri alerjisi olanlarda ve ağır karaciğer yetmezliğinde KONTRENDİKEDİR."
                ],
                "footer": "Böbrek Yetmezliğinde Güvenli / İyot Alerjisine Dikkat"
            }
        ]
    )

    # Slayt 2.3.2.2: ICG Fazları ve Koroidal Paternler
    builder.add_study_card_slide(
        title="ICG ANJİYOGRAFİSİNİN DİNAMİK FAZLARI VE LEZYON PATERNLERİ",
        category="BÖLÜM 2.3.2: ICG ANJİYOGRAFİ",
        subtitle="Erken Koroid Arteriyel Dolumu, Ara Faz Vasküler Ağ ve Geç Faz Yıkanma (Washout)",
        cards=[
            {
                "card_title": "1. ERKEN FAZ (İLK 1-3 DAKİKA)",
                "lead": "Arka Koroid Arterleri ve Koryokapillaris",
                "items": [
                    "Kısa Posterior Siliyer Arterler (SPCA): Makulayı besleyen koroid arterleri saniyeler içinde dolar [s.69].",
                    "Haller ve Sattler Damarları: Koroid büyük ve orta damarları net konturlarla seçilir.",
                    "Besleyici Damar (Feeder Vessel): KNV'yi besleyen ana arteriyel kök erken fazda hiperflöresan olarak parlar.",
                    "Fizyolojik Kararma: Normal fovea koryokapillaris lobüllerinin hızlı dolumuyla aydınlanır."
                ],
                "footer": "Koroid Arterleri & Besleyici Damar Tespiti"
            },
            {
                "card_title": "2. ARA FAZ (5-15 DAKİKA)",
                "lead": "Vasküler Ağ ve Polip Tepe Noktası",
                "items": [
                    "Damar Detaylarının Zirvesi: Retinal damarlar boşalmaya başlarken koroid venleri belirgindir [s.69].",
                    "Dallanan Vasküler Ağ (BVN): Polipoidal koroideal vaskülopatide (PCV) patolojik damar ağı netleşir.",
                    "Polip Anevrizmaları: BVN uçlarında yer alan üzüm salkımı benzeri hiperflöresan nodüller parlar.",
                    "Koryoretinal İnflamasyon: Koroidit odakları hipoflöresan karanlık odaklar olarak belirir."
                ],
                "footer": "BVN & Polip Nodüllerinin En Net Fazı"
            },
            {
                "card_title": "3. GEÇ FAZ (20-35 DAKİKA)",
                "lead": "Yıkanma (Washout) ve Hiper-Ajanlar",
                "items": [
                    "Koroideal Yıkanma (Washout): Normal koroid damarları boyayı tamamen tahliye ederek grileşir [s.70].",
                    "Polip Yıkanması (Washout Belirtisi): Polip nodüllerinin içi boşalır; yalnızca hiperflöresan halka kenarı kalır.",
                    "Geç Coğrafi Hipoflöresans: Koryokapillaris atrofisi alanları zifiri karanlık defektler olarak izlenir.",
                    "Plak Boyanması: KNV tabanındaki fibrovasküler doku geç fazda diffüz hiperflöresan plak verir."
                ],
                "footer": "Polip Washout & Geç İnflamatuar Odaklar"
            }
        ]
    )

    # Slayt 2.3.2.3: Polipoidal Koroideal Vaskülopati (PCV) Tanı Kriterleri
    builder.add_study_card_slide(
        title="POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) ICGA KRİTERLERİ",
        category="BÖLÜM 2.3.2: ICG ANJİYOGRAFİ",
        subtitle="EVEREST ve PLANET Çalışmaları Tanı Kriterleri, Subretinal Anevrizmalar ve BVN",
        cards=[
            {
                "card_title": "ICGA ALTIN STANDART KRİTERLERİ",
                "lead": "EVEREST Konsensus Kriterleri",
                "items": [
                    "PCV tanısında ICGA tartışmasız tek altın standart tanı aracıdır [s.70].",
                    "Primer Kriter: ICGA'nın ilk 5-6 dakikasında beliren tekil veya çoklu nodüler hiperflöresan odaklar (polip).",
                    "Dallanan Vasküler Ağ (BVN): Polipleri besleyen sub-RPE yerleşimli neovasküler damar ağı.",
                    "Bozulma (Washout): Geç fazda polip merkezinin boşalarak halkasal hiperflöresans vermesi.",
                    "Sıvı/Kanama Pervanesi: Polip odağının çevresinde masif subretinal kanama veya seröz PED eşlik eder."
                ],
                "footer": "EVEREST Kriteri: Erken Polip + BVN Ağı"
            },
            {
                "card_title": "OKT KORRELASYONU (NON-İNVAZİV)",
                "lead": "Keskin Kubbe ve Çentikli PED",
                "items": [
                    "Dik Kubbe (Thumb-like PED): RPE'nin parmak benzeri dik açıyla aniden yükselmesi [s.70].",
                    "Çentik Belirtisi (Notch Sign): BVN ile polip bileşkesinde PED kenarında çentik izlenmesi.",
                    "Çift Yansıma Hattı (Double-Layer Sign): RPE ile Bruch zarı arasında BVN'yi temsil eden iki hiperreflektif çizgi.",
                    "İç Hipo/Hiperreflektivite: Polip lümeni hiporeflektif, lümen duvarı hiperreflektiftir."
                ],
                "footer": "Thumb-like PED & Double-Layer Sign"
            },
            {
                "card_title": "TEDAVİ STRATEJİSİ VE PDT",
                "lead": "Anti-VEGF Monoterapi vs Kombine PDT",
                "items": [
                    "EVEREST II Çalışması: Anti-VEGF (ranibizumab) + Fotodinamik Tedavi (PDT) polip kapanmasında (%70) üstündür [s.71].",
                    "PLANET Çalışması: Aflibercept monoterapisi görmeyi artırır ancak kombine PDT polipleri daha yüksek oranda kapatır.",
                    "Yeni Ajanlar (Faricimab & Yüksek Doz Aflibercept): Anjiyopoietin-2 inhibisyonu polip regresyonunu artırmaktadır.",
                    "Hedef: Görme kazanımı VE polip lezyonlarının masif kanama yapmadan tamamen tıkanmasıdır."
                ],
                "footer": "Kombine PDT = Yüksek Polip Kapanma Oranı"
            }
        ]
    )

    # Slayt 2.3.2.4: Atlas Görseli: PCV ve BVN ICGA Atlası
    img_p66 = builder.get_image_for_page(66)
    builder.add_atlas_image_slide(
        title="ICGA İLE POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) ATLASI",
        category="BÖLÜM 2.3.2: GÖRSEL ATLAS",
        subtitle="Erken Faz Nodüler Polip Odakları, BVN Mimarisi ve Geç Faz Hipoflöresan Odaklar",
        image_path=img_p66 or "dr_panel_4",
        caption="Referans Eser Sayfa 66: Makulada Masif Subretinal Kanamalı Gözde ICGA ile Polip Nodüllerinin Tespiti",
        key_findings=[
            "Nodüler Hiperflöresans: Erken fazda beliren üzüm salkımı benzeri hiperflöresan polip anevrizmaları [s.66].",
            "BVN İskeleti: Poliplere doğru uzanan düşük akımlı dallanmış besleyici damar ağı.",
            "Maskelenmeyen Floresans: Kalın subretinal kanamanın arkasından ICG ışığının parlaması.",
            "Geç Washout Halesi: Polip merkezinin boşalarak hipoflöresan hale gelmesi, kenarların parlak kalması."
        ],
        differentials=[
            "Tip 2 KNV: Besleyici damar ve diffüz saçaklı yumak vardır; yuvarlak polip anevrizmaları içermez.",
            "Santral Seröz Koryoretinopati: Dev koroid venleri ve hiperpermeabilite vardır; polip ve BVN yoktur.",
            "Retinal Makroanevrizma (RAM): Retinal arter boyundadır; koroid yerleşimli değildir."
        ],
        clinical_pearl="Anti-VEGF tedavisine dirençli ve masif subretinal kanaması olan yaş tip YBMD olgularında akla ilk gelmesi gereken tanı PCV'dir; kesin tanı için ICGA zorunludur [s.71]."
    )

    # Slayt 2.3.2.5: Karşılaştırmalı Özet: FA vs ICGA Endikasyonları
    builder.add_split_comparison_slide(
        title="KLİNİK PRATİKTE SEÇİM: FA VS ICGA ENDİKASYONLARI",
        category="BÖLÜM 2.3.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Retinal Damar Patolojileri (FA) vs Koroid ve Sub-RPE Patolojileri (ICGA)",
        left_entity={
            "name": "FLORESEİN ANJİYOGRAFİ (FA)",
            "features": [
                ("Primer Hedef Doku", "Nörosensoryal retina damarları ve İç Kan-Retina Bariyeri [s.64]."),
                ("Birincil Endikasyonlar", "Diyabetik retinopati, retinal ven/arter tıkanıklıkları, Coats hastalığı."),
                ("İnflamasyon Tespiti", "Retinal vaskülit, periflebit ve optik disk sızıntısı (papillit)."),
                ("Üstünlüğü", "Mikrovasküler kaçakları ve kapiller non-perfüzyonu aşırı duyarlılıkla gösterir."),
                ("Kısıtlılığı", "RPE altını, derin koroidi ve kanama altındaki lezyonları gösteremez.")
            ]
        },
        right_entity={
            "name": "İNDOSİYANİN YEŞİLİ ANJİYOGRAFİ (ICGA)",
            "features": [
                ("Primer Hedef Doku", "Koryokapillaris, koroid vasküler ağı ve Dış Kan-Retina Bariyeri [s.68]."),
                ("Birincil Endikasyonlar", "Polipoidal vaskülopati (PCV), okült KNV, SSKR, kronik pakikoroid."),
                ("İnflamasyon Tespiti", "Beyaz nokta sendromları (MEWDS, Birdshot, Serpinöz), VKH koroidit odakları."),
                ("Üstünlüğü", "RPE ve kataraktı aşarak koroid damarlarını ve polipleri netleştirir."),
                ("Kısıtlılığı", "Retinal kapiller sızıntıları ve ince makula ödemini değerlendirmede zayıftır.")
            ]
        },
        bottom_takeaway="Retinal vasküler hastalıklarda (DR/RVO) FA birincil modalite iken; pakikoroid, neovasküler YBMD ayırıcı tanısı ve koroiditlerde ICGA vazgeçilmezdir [s.71]."
    )

    # =========================================================================
    # KONU 2.3.3: GENİŞ AÇILI (ULTRA-WIDEFIELD) ANJİYOGRAFİ (5 SLAYT)
    # =========================================================================
    # Slayt 2.3.3.1: Ultra-Widefield (UWF) Teknolojisi
    builder.add_study_card_slide(
        title="ULTRA-WIDEFIELD (UWF) GÖRÜNTÜLEME VE ELİPSOİD AYNA OPTİĞİ",
        category="BÖLÜM 2.3.3: GENİŞ AÇILI ANJİYOGRAFİ",
        subtitle="200 Derece Tek Çekim, Eliptik Aynalar, Lazer Dalga Boyları ve Periferik Görüş",
        cards=[
            {
                "card_title": "200 DERECE TEK ÇEKİM",
                "lead": "Retinanın %82'sinin Eşzamanlı Taranması",
                "items": [
                    "Geleneksel Kameralar: 30° veya 50° açı ile yalnızca arka kutbu ve vasküler arkadları görüntüler [s.71].",
                    "UWF Sistemi (Optos vb.): Eliptik ayna optiği sayesinde tek çekimde 200° fundus açısını tarar.",
                    "Retina Kapsamı: Tüm retina yüzey alanının yaklaşık %82'sini tek karesinde yakalar.",
                    "Periferik Ora Serrata: Hastaya aşırı göz hareketi yaptırmadan ora serrataya kadar periferi netleştirir."
                ],
                "footer": "200° Açı / Retinanın %82 Alanı"
            },
            {
                "card_title": "İKİLİ LAZER DALGA BOYU",
                "lead": "Yeşil (532 nm) ve Kırmızı (635 nm)",
                "items": [
                    "Konvansiyonel Flaş Yok: Gözü kamaştırmayan düşük enerjili eşzamanlı iki lazer hattı kullanılır [s.72].",
                    "Yeşil Lazer (532 nm): Retinal damarları, iç retinayı ve RPE yüzeyini yüksek kontrastla görüntüler.",
                    "Kırmızı Lazer (635 nm): Daha derine inerek koroid tabakasını, nevüsleri ve sklera pigmentasyonunu inceler.",
                    "Kompozit Görüntü: İki dalga boyu birleştirilerek yalancı renkli (pseudo-color) yüksek çözünürlüklü fundus resmi üretilir."
                ],
                "footer": "Yeşil (İç Retina) + Kırmızı (Derin Koroid)"
            },
            {
                "card_title": "KÜRESEL DİSTORSİYON VE DÜZELTME",
                "lead": "3D Küreden 2D Düzleme Projeksiyon",
                "items": [
                    "Distorsiyon Riski: Küresel göz yapısının 2 boyutlu sensöre aktarılması periferde büyütme artefaktı yaratır [s.72].",
                    "Yazılımsal Stereografik Düzeltme: Modern yazılımlar anatomik distorsiyonu düzelterek gerçek alan hesabı yapar.",
                    "Metrik Alan Ölçümü: Periferik non-perfüzyon alanları mm² cinsinden matematiksel olarak hesaplanabilir.",
                    "İskemi İndeksi: İskemik periferik alanın toplam retina alanına oranı objektif olarak raporlanır."
                ],
                "footer": "Stereografik Düzeltme ile mm² İskemi Hesabı"
            }
        ]
    )

    # Slayt 2.3.3.2: Periferik İskemi İndeksi ve Neovaskülarizasyon
    builder.add_study_card_slide(
        title="PERİFERİK İSKEMİ İNDEKSİ (ISI) VE PROLİFERASYON RİSKİ",
        category="BÖLÜM 2.3.3: GENİŞ AÇILI ANJİYOGRAFİ",
        subtitle="Toplam Non-Perfüzyon Alanı, VEGF Aşırı Yükü ve Hedefe Yönelik Tedavi",
        cards=[
            {
                "card_title": "İSKEMİ İNDEKSİ (ISI) TANIMI",
                "lead": "Non-Perfüzyon Alanı / Toplam Alan",
                "items": [
                    "İskemi İndeksi: [Toplam Non-Perfüzyon Alanı (mm²) / Toplam Görüntülenen Retina Alanı (mm²)] oranıdır [s.72].",
                    "Eşik Değer: İskemi indeksi >%35 - 45 olduğunda göz aşırı anjiyogenik risk altındadır.",
                    "Gizli Periferik İskemi: Standart 50° arka kutup FA'sında tamamen normal görünen gözlerde periferde masif iskemi olabilir.",
                    "VEGF Fabrikası: İskemik periferik retina milyonlarca endotel hücresiyle devasa bir VEGF salgılama merkezidir."
                ],
                "footer": "ISI >%35 = Masif Proliferasyon Riski"
            },
            {
                "card_title": "DİYABETİK RETİNOPATİ VE RVO",
                "lead": "Ön Görülemeyen NVD ve NVE Oluşumu",
                "items": [
                    "Diyabette Periferik Dağılım: Hastaların 1/3'ünde periferik lezyonlar arka kutuptan çok daha ağırdır [s.73].",
                    "NVE Odakları: Neovaskülarizasyonlar sıklıkla perfüze retina ile non-perfüze retinanın sınır çizgisinde filizlenir.",
                    "Retinal Ven Tıkanıklığı: Periferik non-perfüzyon alanı >10 disk çapı (veya >45 mm²) ise rubeozis iridis riski fırlar.",
                    "Tedaviye Direnç: İskemik perifer tedavi edilmedikçe inatçı makula ödemi anti-VEGF'e tam yanıt vermez."
                ],
                "footer": "İskemik Perifer = İnatçı Makula Ödemi"
            },
            {
                "card_title": "HEDEFE YÖNELİK LAZER (TRP)",
                "lead": "Targeted Retinal Photocoagulation",
                "items": [
                    "Geleneksel PRP: Tüm orta ve uzak periferik retinaya körlemesine dairesel lazer uygulanırdı [s.73].",
                    "Hedefe Yönelik Lazer (TRP): UWF-FA rehberliğinde yalnızca anjiyografik olarak iskemik non-perfüze alanlar yakılır.",
                    "Sağlıklı Dokunun Korunması: Perfüze alanlar korunarak hastanın periferik görme alanı ve gece görmesi kurtarılır.",
                    "Kombine Yaklaşım: Anti-VEGF ile makula ödemi kurutulurken, TRP ile VEGF kaynağı kalıcı söndürülür."
                ],
                "footer": "Yalnızca İskemik Perifere Seçici Lazer"
            }
        ]
    )

    # Slayt 2.3.3.3: Periferik Vaskülit ve İnflamasyon Tespiti
    builder.add_study_card_slide(
        title="UWF-FA İLE PERİFERİK VASKÜLİT VE ÜVEİT MONİTÖRİZASYONU",
        category="BÖLÜM 2.3.3: GENİŞ AÇILI ANJİYOGRAFİ",
        subtitle="Damar Duvarı Boyanması, Sızıntı, Eales Hastalığı ve Behçet Vasküliti",
        cards=[
            {
                "card_title": "PERİFERİK DAMAR KILIFLANMASI VE KAÇAK",
                "lead": "Klinik Olarak Sessiz Vaskülit Tespiti",
                "items": [
                    "Göz Dibi Muayenesinde Görünmez: Biyomikroskopta retina sakin görünürken UWF-FA'da periferik vaskülit parlar [s.73].",
                    "Periflebit Sızıntısı: Aktif vaskülitte periferik ven duvarlarında eğrelti otu benzeri boyanma ve diffüz kaçak.",
                    "Periferik Kapiller Kapanma: İnflamatuar endarterit sonucu periferik damarlar küt biçimde sonlanır.",
                    "Tedavi Kararı: Sistemik immünsupresif tedavinin doz ayarlamasında UWF-FA vaskülit skoru kullanılır."
                ],
                "footer": "Klinik Sessiz / Anjiyografik Aktif Vaskülit"
            },
            {
                "card_title": "SPESİFİK HASTALIK PATERNLERİ",
                "lead": "Behçet, Sarkoidoz ve Eales Hastalığı",
                "items": [
                    "Behçet Hastalığı: Yaygın tıkayıcı retinal vaskülit; periferde geniş non-perfüzyon ve optik disk sızıntısı [s.74].",
                    "Oküler Sarkoidoz: Venler boyunca mum damlası (candlewax drippings) eksüdaları ve segmental periflebit.",
                    "Eales Hastalığı: Genç erkeklerde periferden merkeze ilerleyen ağır tıkayıcı periflebit ve masif vitreus kanamaları.",
                    "Birdshot Koryoretinopati: Yaygın periferik retinal vasküler kaçak ve retinal dolaşım zamanında uzama."
                ],
                "footer": "Behçet, Sarkoidoz, Eales Ayırıcı Tanısı"
            },
            {
                "card_title": "PİYASAYA ETKİSİ VE REMİSYON",
                "lead": "Gerçek İmmünolojik Remisyon Kriteri",
                "items": [
                    "Yalancı Remisyon Yanılgısı: Ön kamara ve vitreus hücresi sıfırlandığında hastalık remisyonda sanılabilir [s.74].",
                    "UWF-FA Doğrulaması: Hücre olmasa bile damar duvarlarında aktif kaçak sürüyorsa immünsupresyon kesilemez.",
                    "Nüks Erken Uyarısı: Sistemik alevlenmeden haftalar önce periferik damar sızıntısı artmaya başlar.",
                    "Objektif Takip: Anjiyografik anjiyit skoru klinik muayeneden 5 kat daha hassastır."
                ],
                "footer": "UWF-FA Kaçağı Kesilmeden İlaç Kesilmez"
            }
        ]
    )

    # Slayt 2.3.3.4: Atlas Görseli: UWF-FA Periferik İskemi ve Vaskülit Atlası
    img_p73 = builder.get_image_for_page(73)
    builder.add_atlas_image_slide(
        title="ULTRA-WIDEFIELD ANJİYOGRAFİ (UWF-FA) LEZYON ATLASI",
        category="BÖLÜM 2.3.3: GÖRSEL ATLAS",
        subtitle="200 Derece Fundus Taramasında Periferik Non-Perfüzyon, NVE ve Vaskülitik Kaçak",
        image_path=img_p73 or "dr_panel_2",
        caption="Referans Eser Sayfa 73: PDR ve Retinal Vaskülitli Olgularda 200° UWF-FA Periferik Tutulumu",
        key_findings=[
            "200° Perifer Görüşü: Ekvatordan ora serrataya kadar tüm periferik vasküler ağın tek karede netliği [s.73].",
            "Periferik Non-Perfüzyon: Geniş kapiller kapanma alanları ve komşuluğunda filizlenen parlak NVE çiçekleri.",
            "Venöz Kılıflanma ve Kaçak: Periferik ven traselerinde duman benzeri diffüz hiperflöresan floresein sızıntısı.",
            "Arka Kutup Korunumu: Makula nispeten sakin iken periferin ağır iskemik fırtına içinde olması."
        ],
        differentials=[
            "Standart 50° FA: Yalnızca makula ve diski görür; periferdeki masif iskemiyi tamamen gözden kaçırır.",
            "Kalıtsal Vitreoretinopati (FEVR): Temporal periferde avasküler zon ve kordon benzeri traksiyonel damarlar.",
            "RVO İskemisi: Tıkanan ven kadranına uyan kama biçimli periferik non-perfüzyon."
        ],
        clinical_pearl="Standart FA ile 'hafif NPDR' sanılan hastaların %10-15'inde UWF-FA çekildiğinde yüksek riskli PDR ve periferik NVE saptanmaktadır; tanı paradigması bütünüyle değişmiştir [s.74]."
    )

    # Slayt 2.3.3.5: Akış Şeması: UWF-FA Bulgularına Göre Periferik Lazer Kararı
    builder.add_decision_tree_slide(
        title="UWF-FA İLE PERİFERİK İSKEMİ VE LAZER KARAR ALGORİTMASI",
        category="BÖLÜM 2.3.3: KARAR AĞACI",
        subtitle="Non-Perfüzyon Genişliğine Göre Hedefe Yönelik Lazer (TRP) veya Tam PRP Kararı",
        root_label="UWF-FA'DA PERİFERİK NON-PERFÜZYON ALANI VE LEZYONLAR",
        branches=[
            {
                "label": "1. Sınırlı Non-Perfüzyon (<10 Disk Çapı)",
                "criteria": "Periferik kapiller kapanma var ancak neovaskülarizasyon (NVD/NVE) yok; makula ödemi sakin [s.72].",
                "action": "Karar: Lazer gerekmez -> 6 ay arayla UWF-FA ve klinik takip; sistemik risk faktörlerinin kontrolü."
            },
            {
                "label": "2. Masif İskemi + NVE Filizlenmesi",
                "criteria": "İskemi indeksi >%35; perfüze-nonperfüze sınırında aktif sızdıran NVE odakları mevcut [s.73].",
                "action": "Karar: Hedefe Yönelik Retinal Fotokoagülasyon (TRP) -> Yalnızca iskemik perifere seçici lazer."
            },
            {
                "label": "3. İleri PDR / NVD / Rubeozis İridis",
                "criteria": "Optik diskte neovaskülarizasyon (NVD), vitreus kanaması veya ön segment neovaskülarizasyonu [s.74].",
                "action": "Karar: Tam Panretinal Fotokoagülasyon (PRP) + İntravitreal Anti-VEGF enjeksiyonu."
            }
        ],
        bottom_rule="UWF-FA'da periferik damarlarda 'periferik kılıflanma ve boyanma' görülmesi aktif vaskülit kanıtıdır; lazer değil sistemik immünsupresyon doz artışı gerektirir [s.74]."
    )

    # =========================================================================
    # KONU 2.4.1: FUNDUS OTOFLÖRESANS (FAF) VE LİPOFUSKİN (5 SLAYT)
    # =========================================================================
    # Slayt 2.4.1.1: FAF Biyofiziksel Temelleri ve Floroforlar
    builder.add_study_card_slide(
        title="FUNDUS OTOFLÖRESANS (FAF) BİYOFİZİKSEL İLKELERİ",
        category="BÖLÜM 2.4.1: FUNDUS OTOFLÖRESANS",
        subtitle="Ekzojen Boya Gerektirmeyen Metabolik Görüntüleme, A2E Floroforu ve RPE Sağlığı",
        cards=[
            {
                "card_title": "OTOFLÖRESANS FİZİĞİ",
                "lead": "İntraoküler Floroforların Kendiliğinden Işıması",
                "items": [
                    "FAF hiçbir intravenöz boya verilmeden retinanın doğal floroforlarının uyarılmasıdır [s.75].",
                    "Eksitasyon Dalgası: Mavi FAF (488 nm) veya Yeşil FAF (510-530 nm) lazer ışığı kullanılır.",
                    "Emisyon Dalgası: 500 - 700 nm sarı-yeşil ve turuncu dalga boyunda kendiliğinden ışıma kaydedilir.",
                    "Bariyer Filtresi: Gözün yansıttığı uyarıcı lazer ışığını keserek yalnızca hücresel otoflöresansı geçirir."
                ],
                "footer": "Boya Gerekmez / Doğal Florofor Işıması"
            },
            {
                "card_title": "TEMEL FLOROFOR: LİPOFUSKİN VE A2E",
                "lead": "RPE Yaşlanmasının ve Yükünün Aynası",
                "items": [
                    "Primer Kaynak: FAF sinyalinin %95'i RPE lizozomlarında biriken lipofuskinden kaynaklanır [s.76].",
                    "A2E Bileşeni: Görme döngüsünde sindirilemeyen piridinyum bisretinoid polimeridir.",
                    "Fizyolojik Düzey: Normal yaşlanmayla hafif artan difüz homojen bir arka plan floresansı verir.",
                    "Patolojik Yük: Fotoreseptör yıkımının arttığı veya lizozomun bozulduğu durumlarda aşırı birikir."
                ],
                "footer": "RPE Lizozom Lipofuskini = FAF Sinyali"
            },
            {
                "card_title": "İKİNCİL FLOROFORLAR",
                "lead": "Optik Disk Druzeni ve Melanin",
                "items": [
                    "Optik Disk Druzeni: Yoğun kalsiyum ve mukoprotein içeriği nedeniyle devasa hiper-otoflöresans verir [s.76].",
                    "Kollajen ve Elastin: Sklera ve koroid skarları zayıf yeşil FAF sinyali üretebilir.",
                    "Melanin (Near-Infrared FAF): Yakın kızılötesi FAF (787 nm) melanin dağılımını gösterir.",
                    "Emici Filtreler: Lutein/zeaksantin ve kanama FAF ışığını emerek hipo-otoflöresan görünür."
                ],
                "footer": "Optik Disk Druzeni & Melanin"
            }
        ]
    )

    # Slayt 2.4.1.2: Normal FAF Dağılımı ve Anatomik Kararmalar
    builder.add_study_card_slide(
        title="SAĞLIKLI FUNDUS OTOFLÖRESANSININ ANATOMİK DAĞILIMI",
        category="BÖLÜM 2.4.1: FUNDUS OTOFLÖRESANS",
        subtitle="Santral Foveal Hipoflöresans, Optik Disk Sönüklüğü ve Arka Plan Griliği",
        cards=[
            {
                "card_title": "FOVEAL HİPO-OTOFLÖRESANS",
                "lead": "Santral Sarı Pigment Filtresi",
                "items": [
                    "Normal fovea merkezinde zifiri koyu (hipootofloresan) bir alan izlenir [s.76].",
                    "Mekanizma 1: Henle lif tabakasındaki yoğun lütein ve zeaksantin mavi eksitasyon ışığını (488 nm) emer.",
                    "Mekanizma 2: Foveola merkezinde çomak bulunmaz; koni dış segmentleri daha az lipofuskin üretir.",
                    "Mekanizma 3: Foveal RPE hücreleri daha yüksek melanin konsantrasyonuna sahiptir.",
                    "Yeşil FAF Farkı: Yeşil FAF'ta (532 nm) makuler pigment emilimi olmadığı için fovea daha aydınlık çıkar."
                ],
                "footer": "Lütein Mavi Işığı Emer -> Koyu Fovea"
            },
            {
                "card_title": "OPTİK SİNİR BAŞI SÖNÜKLÜĞÜ",
                "lead": "RPE Bulunmayan Tam Kör Nokta",
                "items": [
                    "Optik disk alanı FAF görüntüsünde tamamen sinyalsiz, kapkara bir delik gibi görünür [s.77].",
                    "Gerekçe: Optik sinir başında RPE hücresi ve dolayısıyla lipofuskin bulunmaz.",
                    "Klinik Önemi: Optik disk alanında herhangi bir parlama saptanırsa primer olarak 'Gömülü Optik Disk Druzeni' düşünülür.",
                    "Peripapiller Kresent: Miyopik konusta RPE yoksa disk kenarında hilal şeklinde hipo-FAF izlenir."
                ],
                "footer": "RPE Yok = Optik Disk Zifiri Karanlık"
            },
            {
                "card_title": "DAMAR GÖLGELERİ VE ARKA PLAN",
                "lead": "Hemoglobin Absorpsiyonu ve Homojen Ton",
                "items": [
                    "Retinal Damarlar: Damar içindeki hemoglobin eksitasyon ve emisyon ışığını emdiği için koyu çizgilerdir [s.77].",
                    "Arka Plan Floresansı: Fovea ve damarlar haricinde arka kutup homojen orta gri renktedir.",
                    "Periferik Azalma: Ekvatora ve periferiye doğru RPE lipofuskin yoğunluğu azaldığı için sinyal tedricen düşer.",
                    "Simetri: Sağ ve sol göz FAF arka plan parlaklığı sağlıklı bireylerde tam simetriktir."
                ],
                "footer": "Damarlar Hipootofloresan Gölgelerdir"
            }
        ]
    )

    # Slayt 2.4.1.3: Hiperotoflöresans vs Hipootoflöresans Paternleri
    builder.add_split_comparison_slide(
        title="FAF PATOLOJİK PATERNLERİ: HİPER-FAF VS HİPO-FAF",
        category="BÖLÜM 2.4.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Hücresel Stres ve Yük Artışı (Hiper) vs Hücre Ölümü ve Emilim Engeli (Hipo)",
        left_entity={
            "name": "HİPER-OTOFLÖRESANS (PARLAK SİNYAL)",
            "features": [
                ("Hücresel Anlam", "RPE hücresinde aşırı lipofuskin birikimi ve metabolik stres [s.77]."),
                ("Dış Segment Yığılması", "Fotoreseptör dış segment disklerinin sindirilemeyip birikmesi."),
                ("Karakteristik Hastalıklar", "Best Hastalığı (vitelliform plak), Stargardt fleckleri, aktif CSCR kenarı."),
                ("Atrofi Habercisi", "Coğrafi atrofi odaklarının kenarındaki hiper-FAF halkası genişleme yönünü gösterir."),
                ("Optik Disk Druzeni", "Boya vermeden kendiliğinden parlayan gömülü kalsifik disk druzenleri.")
            ]
        },
        right_entity={
            "name": "HİPO-OTOFLÖRESANS (SÖNÜK SİNYAL)",
            "features": [
                ("Hücresel Anlam", "RPE hücrelerinin ölümü, kaybı veya ışığın önde bloke edilmesi [s.78]."),
                ("RPE Atrofisi", "RPE tamamen öldüğünde lipofuskin kaynağı yok olur; zifiri siyah zemin kalır."),
                ("Karakteristik Hastalıklar", "Coğrafi Atrofi, miyopik makulopati atrofisi, lazer skar alanları, koroideremi."),
                ("Blokaj / Maskeleme", "Preretinal veya subretinal kanama, kalın sert eksüda veya yoğun melanin kitlesi."),
                ("Prognoz", "Kalıcı hipo-FAF alanlarında retina hücresi kalmadığı için görme kurtarılamaz.")
            ]
        },
        bottom_takeaway="Coğrafi atrofinin yıllık büyüme hızını takip etmede ve yeni kompleman inhibitörü tedavilerinin (Pegcetacoplan vb.) etkinliğini kanıtlamada FAF hipootoflöresan alan ölçümü FDA onaylı altın standarttır [s.78]."
    )

    # Slayt 2.4.1.4: Atlas Görseli: Stargardt, Best ve Coğrafi Atrofi FAF
    img_p77 = builder.get_image_for_page(77)
    builder.add_atlas_image_slide(
        title="FAF KLİNİK HASTALIK VE ATROFİ PATERNLERİ ATLASI",
        category="BÖLÜM 2.4.1: GÖRSEL ATLAS",
        subtitle="Stargardt Fleck Dağılımı, Best Vitelliform Yumurtası ve Coğrafi Atrofi Haritası",
        image_path=img_p77 or "dr_schema_4",
        caption="Referans Eser Sayfa 77: Stargardt (ABCA4), Best (BEST1) ve Kuru YBMD Olgularında Karakteristik FAF İmzaları",
        key_findings=[
            "Stargardt Fleckleri: Arka kutba saçılmış balık kılçığı benzeri parlak hiper-FAF benekleri [s.77].",
            "Peripapiller Korunma (Peripapillary Sparing): Stargardt'ta optik disk çevresindeki 1-2 mm'lik RPE'nin sağlam kalması.",
            "Best Yumurta Sarısı: Makula merkezinde homojen, parlak yuvarlak hiperotofloresan vitelliform kitle.",
            "Coğrafi Atrofi Adaları: Keskin kenarlı, harita benzeri zifiri hipo-FAF atrofi alanları."
        ],
        differentials=[
            "YBMD vs Stargardt: Stargardt peripapiller RPE'yi korur; YBMD peripapiller atrofiyi sever.",
            "Erişkin Vitelliform (AVMD): Lezyon daha küçüktür (<1/3 disk çapı) ve EOG Arden oranı normaldir.",
            "Kloroquin Toksisitesi: Foveayı çevreleyen 'öküz gözü' (bull's eye) hiper-FAF ve atrofi halkası."
        ],
        clinical_pearl="Peripapiller korunma (peripapillary sparing) Stargardt hastalığı için patognomoniktir; fundus fleckleri olan bir hastada disk kenarındaki RPE sağlamsa tanı %99 ABCA4 mutasyonudur [s.78]."
    )

    # Slayt 2.4.1.5: Akış Şeması: Makuler Lezyonlarda FAF ile Ayırıcı Tanı
    builder.add_decision_tree_slide(
        title="MAKULA PATOLOJİLERİNDE FAF İLE AYIRICI TANI PROTOKOLÜ",
        category="BÖLÜM 2.4.1: KARAR AĞACI",
        subtitle="Santral Floresans Yoğunluğuna ve Çevre Paternine Göre Klinik Triyaj",
        root_label="MAKULA BÖLGESİNDE FAF SİNYAL DEĞİŞİKLİĞİ",
        branches=[
            {
                "label": "1. Santral Hiper-FAF Odak",
                "criteria": "Homojen vitelliform kitle var -> EOG çek; Arden <%150 ise Best Hastalığı; EOG normalse AVMD [s.77].",
                "action": "Karar: Genetik test (BEST1 / PRPH2) -> İntravitreal enjeksiyondan kaçın (sıvı seröz kisttir)."
            },
            {
                "label": "2. Yaygın Fleckler + Peripapiller Korunma",
                "criteria": "Arka kutupta hiper-FAF benekler; optik disk çevresinde RPE sağlam; santral fovea atrofisi [s.78].",
                "action": "Karar: Stargardt Hastalığı (ABCA4) -> A vitamini takviyesini YASAKLA; güneş gözlüğü reçete et."
            },
            {
                "label": "3. Keskin Hipootoflöresan Harita Alanı",
                "criteria": "Zifiri siyah atrofi adası; kenarlarında hiper-FAF halkası; drusen zemininde kuru YBMD [s.78].",
                "action": "Karar: Coğrafi Atrofi -> FAF ile lezyon alanını (mm²) ölç; Kompleman inhibitörü adayı olarak değerlendir."
            }
        ],
        bottom_rule="Stargardt şüphesi olan hastaya asla yüksek doz Vitamin A verilmemelidir; retinoid yükü toksik A2E ve lipofuskin üretimini hızlandırarak körlüğü erkene çeker [s.78]."
    )

    # =========================================================================
    # KONU 2.4.2: ULTRASONOGRAFİ (B-SCAN) OPASİTELER VE KİTLELER (5 SLAYT)
    # =========================================================================
    # Slayt 2.4.2.1: Oküler Ultrasonografi Fiziksel İlkeleri
    builder.add_study_card_slide(
        title="OKÜLER B-SCAN ULTRASONOGRAFİ FİZİKSEL TEMELLERİ",
        category="BÖLÜM 2.4.2: B-SCAN ULTRASONOGRAFİ",
        subtitle="10 - 20 MHz Piezoelektrik Kristaller, Akustik Empedans ve Doku Yansımaları",
        cards=[
            {
                "card_title": "SES DALGASI VE FREKANS SEÇİMİ",
                "lead": "Yüksek Frekans = Yüksek Çözünürlük",
                "items": [
                    "Prob Kristali: Piezoelektrik kristal elektriksel enerjiyi yüksek frekanslı ses dalgalarına çevirir [s.81].",
                    "Standart Posterior Prob: 10 MHz frekans (doku penetrasyonu derin, çözünürlük ~150 μm).",
                    "Yüksek Çözünürlüklü Prob: 20 MHz frekans (arka kutup ve retina yüzeyi için ultra-keskin).",
                    "UBM (Ultrason Biyomikroskopisi): 35 - 50 MHz frekans (yalnızca ön segment ve silier cisim için)."
                ],
                "footer": "10 MHz (Derin) vs 20 MHz (Keskin) vs 50 MHz (UBM)"
            },
            {
                "card_title": "AKUSTİK EMPEDANS FARKI",
                "lead": "Dokuların Sesi Yansıtma Gücü",
                "items": [
                    "Akustik Empedans (Z): Dokunun yoğunluğu ile sesin o dokudaki yayılma hızının çarpımıdır [s.81].",
                    "Yansıma İlkesi: İki doku arasındaki empedans farkı ne kadar büyükse, arayüzden o kadar güçlü eko döner.",
                    "Sıvı/Doku Arayüzü: Vitreus sıvısı ile retina arasındaki empedans farkı çok güçlü eko verir.",
                    "Sıvı İçi Eko Yokluğu: Berrak vitreus, lens içi ve seröz sıvı tamamen 'akustik olarak boş'tur (anekoik siyah)."
                ],
                "footer": "Büyük Empedans Farkı = Parlak Eko"
            },
            {
                "card_title": "A-SCAN VE B-SCAN KOMBİNASYONU",
                "lead": "Genlik Vektörü ve 2 Boyutlu Kesit",
                "items": [
                    "A-Scan (Amplitude): Ekonun gücünü dikey sivri tepeler (pike) olarak gösteren tek boyutlu sinyaldir [s.82].",
                    "Doku Spike Yüksekliği: Retinanın A-scan reflektivitesi %100'e yakındır; vitreus opasiteleri %10-30 arasındadır.",
                    "B-Scan (Brightness): Yan yana hareket eden yüzlerce A-taramasının parlaklık noktacıklarına çevrilmiş 2B haritasıdır.",
                    "Vektörel Tanı: Tümörlerin ve membranların ayrımında eşzamanlı B-scan + vektörel A-scan altın standarttır."
                ],
                "footer": "A-Scan (Doku Sivrilmesi) + B-Scan (2B Morfoloji)"
            }
        ]
    )

    # Slayt 2.4.2.2: Opak Ortamlarda Membran Ayrımı: RD vs PVD
    builder.add_split_comparison_slide(
        title="B-SCAN İLE MEMBRAN AYRIMI: RETİNA DEKOLMANI VS PVD",
        category="BÖLÜM 2.4.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Yoğun Vitreus Kanamasında Yırtıklı Retina Dekolmanı ile Posterior Hyaloid Ayrımı",
        left_entity={
            "name": "REGMATOJEN RETİNA DEKOLMANI (RD)",
            "features": [
                ("Eko Yoğunluğu", "Yüksek reflektiviteli (%100 spike), kalın, parlak membranöz bant [s.82]."),
                ("Anatomik Yapışma", "Optik disk kenarına VE ora serrataya kesin olarak anatomik yapışıklık gösterir."),
                ("Kinetik Hareket", "Sert, rijit, kısıtlı dalgalanma hareketi; göz hareketi durduğunda hızla durur."),
                ("Konfigürasyon", "Tipik huni (funnel) veya kubbe konfigürasyonu."),
                ("A-Scan Karşılığı", "Tekil, dik, %100 yükseklikte dev retina spike'ı verir.")
            ]
        },
        right_entity={
            "name": "POSTERİOR VİTREUS DEKOLMANI (PVD)",
            "features": [
                ("Eko Yoğunluğu", "Düşük-orta reflektiviteli (%10-40 spike), ince, silik membranöz hat [s.82]."),
                ("Anatomik Yapışma", "Optik diske tutunmaz (Weiss halkası serbest yüzer); ora serratada sonlanmaz."),
                ("Kinetik Hareket", "Aşırı hareketli, akışkan, jelatinöz dalgalanma (after-movement); göz dursa da sallanır."),
                ("Konfigürasyon", "Düzensiz, dalgalı, gevşek katlantılar."),
                ("A-Scan Karşılığı", "Düşük-orta genlikli, değişken yükseklikte çoklu küçük spike'lar.")
            ]
        },
        bottom_takeaway="Yoğun vitreus kanaması olan bir gözde membranın optik diske yapışık olması ve %100 A-scan piki vermesi acil cerrahi gerektiren retina dekolmanının kesin kanıtıdır [s.83]."
    )

    # Slayt 2.4.2.3: İntraoküler Kitlelerin Ultrasonik Karakterizasyonu
    builder.add_study_card_slide(
        title="OKÜLER ONKOLOJİDE B-SCAN VE A-SCAN BULGULARI",
        category="BÖLÜM 2.4.2: B-SCAN ULTRASONOGRAFİ",
        subtitle="Koroid Melanomu, Koroid Nevüsü, Hemanjiom ve Metastazın Akustik Ayrımı",
        cards=[
            {
                "card_title": "KOROİD MELANOMU",
                "lead": "Mantar Konfigürasyonu ve Akustik Boşluk",
                "items": [
                    "B-Scan Morfolojisi: Kubbe şeklinde başlar; Bruch membranını deldiğinde 'Mantar / Düğme' (Mushroom) şeklini alır [s.83].",
                    "Akustik Boşluk (Acoustic Cavity): Tümör tabanında hücre yoğunluğuna bağlı ekojenite düşüklüğü.",
                    "A-Scan Reflektivitesi: Karakteristik olarak DÜŞÜK-ORTA (%15-40) iç reflektivite ve açılı iniş (angle kappa).",
                    "Vasküler Nabız: Tümör içi damarlanmaya bağlı lezyon tabanında hızlı iç pulsasyon izlenir."
                ],
                "footer": "Mantar Şekli + Düşük A-Scan + Akustik Boşluk"
            },
            {
                "card_title": "KOROİD HEMANJİOMU",
                "lead": "Yüksek İç Reflektivite ve Kubbe",
                "items": [
                    "B-Scan Morfolojisi: Geniş tabanlı, pürüzsüz yüzeyli, hafif kubbemsi koroidal kabarıklık [s.83].",
                    "Akustik Gölge Yoktur: Ses dalgaları tümör içinden engelsiz geçer; sklera arkasında gölgeleme yapmaz.",
                    "A-Scan Reflektivitesi: Karakteristik olarak AŞIRI YÜKSEK (%95-100) düzenli iç reflektivite.",
                    "Histopatolojik Neden: Geniş, kan dolu kavernöz vasküler kanalların yarattığı güçlü empedans farkları."
                ],
                "footer": "Yüksek A-Scan (%100) + Düzenli Eko"
            },
            {
                "card_title": "KOROİD METASTAZI",
                "lead": "Düzensiz, Yayvan ve Lobüle Kitle",
                "items": [
                    "B-Scan Morfolojisi: Yüksekliği az, tabanı çok geniş, diffüz dalgalı/yayvan (plateau) kitle [s.84].",
                    "A-Scan Reflektivitesi: ORTA-YÜKSEK (%60-80), düzensiz, heterojen spike dizilimi.",
                    "Eksüdatif Sıvı: Tümör boyutuna oranla çok erken ve masif eksüdatif retina dekolmanı oluşturur.",
                    "Çok Odaklılık: Genellikle multifokal ve bilateral tutulum eğilimi gösterir (akciğer/meme kanseri)."
                ],
                "footer": "Yayvan / Orta-Yüksek Eko / Erken Sıvı"
            }
        ]
    )

    # Slayt 2.4.2.4: Atlas Görseli: B-Scan RD ve Melanom Kesitleri
    img_p82 = builder.get_image_for_page(82)
    builder.add_atlas_image_slide(
        title="B-SCAN ULTRASONOGRAFİ DOKU PATOLOJİLERİ ATLASI",
        category="BÖLÜM 2.4.2: GÖRSEL ATLAS",
        subtitle="Huni Şekilli Total Retina Dekolmanı, Koroid Ekskavasyonu ve Mantar Melanom",
        image_path=img_p82 or "dr_panel_8",
        caption="Referans Eser Sayfa 82: B-Scan Kesitinde Total Regmatojen RD ve Koroid Melanomunun Akustik Boşluğu",
        key_findings=[
            "Huni Şekilli RD: Optik diske V-şeklinde tutunan, ora serrataya uzanan kalın hiperreflektif retina bandı [s.82].",
            "Mantar Biçimli Kitle: Bruch membranını delerek vitreus içine boğumlanan melanom dokusu.",
            "Koroid Ekskavasyonu: Tümörün sklera tabanında oluşturduğu çöküntü ve arka akustik gölgeleme.",
            "Subretinal Sıvı: Dekolman membranının altında akustik olarak tamamen temiz, berrak seröz alan."
        ],
        differentials=[
            "Retina Dekolmanı vs Hyaloid: Hyaloid diske tutunmaz, sallantılıdır; retina diske kilitlidir ve serttir.",
            "Melanom vs Hemanjiom: Melanom düşük iç eko ve akustik boşluk verir; hemanjiom %100 yüksek eko verir.",
            "İntraoküler Yabancı Cisim: Arkasında kuyruklu yıldız (comet tail) saçılma artefaktı bırakan aşırı dens eko."
        ],
        clinical_pearl="B-Scan ultrasonografide şüpheli koroid kitlesinde 'mantar şekli' ve 'akustik boşluk' görülmesi koroid melanomu için neredeyse patognomoniktir; biyopsi gerekmeden tanı koydurur [s.83]."
    )

    # Slayt 2.4.2.5: Akış Şeması: Opak Medyada Ultrasonik Triyaj
    builder.add_decision_tree_slide(
        title="OPAK ORTAMLARDA (VİTREUS KANAMASI) B-SCAN TRİYAJ PROTOKOLÜ",
        category="BÖLÜM 2.4.2: KARAR AĞACI",
        subtitle="Göz Dibi Görünmeyen Hastada Membranöz Ekolara Göre Cerrahi Aciliyet Kararı",
        root_label="BİYOMİKROSKOPİDE RETİNA SEÇİLEMİYOR (VİTREUS KANAMASI)",
        branches=[
            {
                "label": "1. Optik Diske Kilitli Rijit Membran (%100 Eko)",
                "criteria": "Kalın bant diske ve ora serrataya uzanıyor; A-scan %100; kinetik hareket kısıtlı [s.82].",
                "action": "Tanı: Retina Dekolmanı (RD) eşlik eden kanama -> Acil (ilk 24-48 saat) Pars Plana Vitrektomi."
            },
            {
                "label": "2. Diske Tutunmayan Hareketli İnce Membran",
                "criteria": "Zayıf-orta eko (%20-30); göz hareketleriyle serbestçe dalgalanıyor; retina yatışık [s.82].",
                "action": "Tanı: Posterior Vitreus Dekolmanı (PVD) ve izole vitreus kanaması -> Baş yukarıda istirahat ve haftalık B-scan."
            },
            {
                "label": "3. Koroidde Kubbe / Mantar Kitle Saptandı",
                "criteria": "Tabanı skleraya oturan solid lezyon; düşük iç reflektivite ve akustik boşluk [s.83].",
                "action": "Tanı: Koroid Melanomu zemininde tümöral kanama -> Acil oküler onkoloji sevki ve brakiterapi/enükleasyon."
            }
        ],
        bottom_rule="Vitreus kanamalı bir gözde B-Scan yapılmadan hastaya 'bekleyelim kanama açılsın' denemez; yırtıklı dekolman atlanırsa PVR gelişir ve cerrahi başarı şansı çöker [s.83]."
    )

    # =========================================================================
    # KONU 2.5.1: ELEKTROFİZYOLOJİ: ffERG, mfERG, EOG, VEP (6 SLAYT)
    # =========================================================================
    # Slayt 2.5.1.1: Tam Alan ERG (ffERG) Standartları ve Dalgalar
    builder.add_study_card_slide(
        title="TAM ALAN ELEKTRORETİNOGRAFİ (ffERG) VE DALGA ANALİZİ",
        category="BÖLÜM 2.5.1: ELEKTROFİZYOLOJİ",
        subtitle="ISCEV Standartları, a-Dalgası (Fotoreseptör), b-Dalgası (Bipolar) ve Osilatör Potansiyeller",
        cards=[
            {
                "card_title": "a-DALGASI VE b-DALGASI",
                "lead": "Negatif ve Pozitif Dalga Kökenleri",
                "items": [
                    "a-Dalgası (Negatif İniş): Işık uyarısıyla fotoreseptörlerin (çomak/koni) hiperpolarizasyonunu yansıtır [s.85].",
                    "b-Dalgası (Pozitif Tepe): On-bipolar hücrelerin ve Müller glial hücrelerinin depolarizasyonundan kaynaklanır.",
                    "Amplitüd Ölçümü: a-dalgası taban çizgisinden vadiye; b-dalgası a-vadisinden pozitif tepeye ölçülür.",
                    "Latans (İmmatürite / Gecikme): Işık çakmasından dalga tepesine kadar geçen süredir (ms cinsinden)."
                ],
                "footer": "a-Dalgası: Fotoreseptör | b-Dalgası: Bipolar/Müller"
            },
            {
                "card_title": "ISCEV STANDART ffERG PROTOKOLÜ",
                "lead": "Karanlık ve Aydınlık Adaptasyon Basamakları",
                "items": [
                    "20 Dakika Karanlık Adaptasyon: Skotopik çomak fonksiyonlarını açığa çıkarmak için şarttır [s.85].",
                    "1. Skotopik Zayıf Işık (0.01 cd·s/m²): Saf çomak yanıtı (yalnızca b-dalgası izlenir).",
                    "2. Skotopik Standart Işık (3.0 cd·s/m²): Birleşik çomak-koni yanıtı (büyük a ve b dalgası).",
                    "3. Osilatör Potansiyeller: b-dalgası çıkan kolundaki küçük testere dişleri; iç retina amakrin hücrelerini yansıtır.",
                    "4. Fotopik Yanıt (3.0 cd·s/m²): 10 dk aydınlık adaptasyon sonrası saf koni yanıtı.",
                    "5. 30 Hz Titreşim (Flicker): Çomakların yetişemediği yüksek frekanslı saf koni yanıtı."
                ],
                "footer": "5 Standart ISCEV Basamağı"
            },
            {
                "card_title": "NEGATİF ERG VE KLİNİK ANLAMI",
                "lead": "b-Dalgasının a-Dalgasından Küçük Olması",
                "items": [
                    "Negatif ERG Tanımı: b-dalgası genliğinin a-dalgası genliğinin altına düşmesidir (b/a oranı <1.0) [s.86].",
                    "Patoloji Düzeyi: Fotoreseptörler sağlamdır ancak sinaptik iletim veya bipolar hücreler çalışmaz.",
                    "Karakteristik Hastalıklar: X'e bağlı Retinoskizis (RS1), Konjenital Duragan Gece Körlüğü (CSNB).",
                    "Vasküler Neden: Santral Retinal Arter Tıkanıklığında (CRAO) iç retina iskemisiyle negatif ERG gelişir."
                ],
                "footer": "b/a < 1.0 = Bipolar / İç Retina Tutulumu"
            }
        ]
    )

    # Slayt 2.5.1.2: Multifokal ERG (mfERG) ve Foveal Harita
    builder.add_study_card_slide(
        title="MULTİFOKAL ERG (mfERG) VE TOPOGRAFİK KONİ HARİTASI",
        category="BÖLÜM 2.5.1: ELEKTROFİZYOLOJİ",
        subtitle="Santral 30 Derecenin 61 veya 103 Heksagonal Elemanla Haritalanması",
        cards=[
            {
                "card_title": "LOKAL ELEKTRİKSEL YANITLAR",
                "lead": "Fokal ve Topografik Harita",
                "items": [
                    "Tam alan ffERG makulayı seçemez (makula retinadaki konilerin yalnızca %10'unu barındırır) [s.86].",
                    "mfERG Prensibi: Santral 30-40° alan 61 veya 103 heksagonal adacığa bölünür.",
                    "Sözde-Rastgele Titreşim (m-sekansı): Her heksagon bağımsız siyah-beyaz yanıp söner.",
                    "Matematiksel Çapraz Korelasyon: Her fokal alanın ürettiği mikro-voltaj bağımsız hesaplanır.",
                    "3 Boyutlu Tepe: Normal fovea merkezinde sivri dev bir koni fonksiyon tepesi izlenir."
                ],
                "footer": "Santral 30° / 61-103 Heksagonal Alan"
            },
            {
                "card_title": "KLİNİK KULLANIM ALANLARI",
                "lead": "Toksisite Taraması ve Erken Tanı",
                "items": [
                    "Hidroksiklorokin (Plaquenil) Toksisitesi: Parafoveal koni amplitüdünde çökme en erken objektif belirtidir [s.87].",
                    "Fokal Makulopatiler: Stargardt ve koni distrofisinde santral tepenin düzleşmesi izlenir.",
                    "Gizli Görme Kaybı: Fundus tamamen normal görünürken açıklanamayan görme azlığında (CAR, kordisfonksiyon).",
                    "Santral İskemi: Diyabetik iskemik makulopatide foveal elektriksel aktivite düşüşünü kantifiye eder."
                ],
                "footer": "Plaquenil Toksisitesi Taramasında 1 Numara"
            },
            {
                "card_title": "ffERG İLE FARKI",
                "lead": "Makuler vs Diffüz Retinal Ayrım",
                "items": [
                    "ffERG Diffüz Hastalıklar İçindir: RP veya koroideremi gibi tüm retinayı tutan hastalıklarda çöker [s.87].",
                    "mfERG Makuler Hastalıklar İçindir: İzole makula deliği veya YBMD'de ffERG normal, mfERG anormaldir.",
                    "Fiksasyon Şartı: mfERG güvenilirliği hastanın fiksasyonu koruyabilmesine mutlak bağımlıdır.",
                    "Kötü Fiksasyon: Ağır nistagmus veya santral skotomda mfERG haritası artefaktlı çıkar."
                ],
                "footer": "ffERG = Tüm Retina | mfERG = Yalnızca Makula"
            }
        ]
    )

    # Slayt 2.5.1.3: Elektrookülografi (EOG) ve RPE Fonksiyonu
    builder.add_study_card_slide(
        title="ELEKTROOKÜLOGRAFİ (EOG) VE RPE TRANSEPİTELYAL POTANSİYELİ",
        category="BÖLÜM 2.5.1: ELEKTROFİZYOLOJİ",
        subtitle="Karanlık Çöküşü (Dark Trough), Işık Piki (Light Peak), Arden Oranı ve BEST1",
        cards=[
            {
                "card_title": "DİPOL MOMENTİ VE HAREKET",
                "lead": "Gözün Kalıcı Elektriksel Pili",
                "items": [
                    "Göz Küresi Bir Dipoldür: Kornea elektriksel olarak pozitif (+), arka kutup (RPE) negatiftir (-) [s.87].",
                    "Transepitelyal Potansiyel (TEP): RPE bazolateral zarı 6 - 10 mV kalıcı dinlenim potansiyeli üretir.",
                    "Ölçüm Tekniği: İç ve dış kantuslara elektrot yerleştirilir; hasta iki ışık noktası arasında gözlerini ritmik hareket ettirir.",
                    "Hareket Sinyali: Korneanın elektrotlara yaklaşması potansiyel dalgalanmaları yaratır."
                ],
                "footer": "Göz Bir Pildir: Kornea (+) / RPE (-)"
            },
            {
                "card_title": "ARDEN ORANI HESABI",
                "lead": "Işık Piki / Karanlık Dip Oranı",
                "items": [
                    "Karanlık Faz (15 dk): Transepitelyal potansiyel tedricen düşer ve taban yapar (Dark Trough) [s.88].",
                    "Aydınlık Faz (15 dk): Parlak ışık açıldığında RPE klorür kanalları açılır ve potansiyel zirveye tırmanır (Light Peak).",
                    "Arden Oranı Formülü: [Işık Piki Amplitüdü (LP) / Karanlık Dip Amplitüdü (DT)] × 100.",
                    "Normal Değer: Sağlıklı bireylerde Arden oranı >%180 - 185 düzeyindedir.",
                    "Sınır Değer: %165 - 180 arası şüpheli; <%150 kesin patolojiktir."
                ],
                "footer": "Normal Arden Oranı >%180 | Patolojik <%150"
            },
            {
                "card_title": "BEST VİTELLİFORM MAKULA DİSTROFİSİ",
                "lead": "EOG'nin Patognomonik İmzası",
                "items": [
                    "Best Hastalığı (BEST1 Geni): RPE bazolateral zardaki bestrofin-1 klorür kanalı mutasyonudur [s.88].",
                    "Işık Piki Kaybı: Işık açılsa dahi klorür iletimi başlayamaz; ışık piki hiç oluşmaz.",
                    "Düşük Arden Oranı: Arden oranı dramatik şekilde <%130 - 140 düzeyine çöker.",
                    "ffERG Tamamen Normaldir: Çomak ve koniler sağlam olduğu için tam alan ERG kusursuzdur.",
                    "Taşıyıcı Taraması: Geni taşıyan ancak fundusu tamamen normal olan aile bireylerinde dahi EOG bozuktur."
                ],
                "footer": "Normal ERG + Çökmüş EOG = Best Hastalığı"
            }
        ]
    )

    # Slayt 2.5.1.4: Görsel Uyarılmış Potansiyeller (VEP)
    builder.add_study_card_slide(
        title="GÖRSEL UYARILMIŞ POTANSİYELLER (VEP) VE GÖRSEL YOLAK",
        category="BÖLÜM 2.5.1: ELEKTROFİZYOLOJİ",
        subtitle="P100 Dalgası, Dama Tahtası (Pattern VEP), Flaş VEP ve Optik Sinir İletimi",
        cards=[
            {
                "card_title": "OKSİPİTAL KORTEKS YANITI",
                "lead": "Retinadan Görme Merkezine İletim",
                "items": [
                    "VEP retina ganglion hücrelerinden oksipital görme korteksine (Brodmann 17) kadar olan iletimi ölçer [s.88].",
                    "Elektrot Lokalizasyonu: Oksipital saçlı deri üzerine (inionun 3-4 cm üstü) yerleştirilir.",
                    "P100 Dalgası: Yaklaşık 100 ms latansta beliren dev pozitif tepe dalgasıdır.",
                    "İki Temel Parametre: P100 latansı (iletim hızı - ms) ve P100 amplitüdü (akson sayısı - μV)."
                ],
                "footer": "P100 Dalgası: Latans (Hız) & Amplitüd (Akson)"
            },
            {
                "card_title": "PATTERN VEP VS FLAŞ VEP",
                "lead": "Dama Tahtası vs Işık Parlaması",
                "items": [
                    "Pattern VEP: Siyah-beyaz dama tahtası deseninin yer değiştirmesiyle uyarılır [s.89].",
                    "Kooperasyon Şartı: Hastanın ekrana odaklanması ve fiksasyonu gerekir; son derece hassastır.",
                    "Flaş VEP: Parlak ışık çakmasıyla uyarılır; fiksasyon veya kooperasyon gerektirmez.",
                    "Kullanım Alanı: Bebeklerde, komadaki hastalarda veya yoğun kornea/katarakt opasitelerinde tercih edilir."
                ],
                "footer": "Pattern (Hassas) vs Flaş (Opak/Bebek)"
            },
            {
                "card_title": "OPTİK NÖRİT VE DEMİYELİNİZASYON",
                "lead": "Multipl Skleroz ve İskemik Nöropati",
                "items": [
                    "Demiyelinizasyon (Optik Nörit / MS): İletim hızı yavaşlar; P100 latansı belirgin uzar (>120-130 ms) [s.89].",
                    "Kalıcı Belirteç: Görme 10/10'a dönse dahi P100 latans gecikmesi yıllarca kalıcı kalır.",
                    "Aksonal Kayıp (AION): İskemik optik nöropatide latans normal kalırken P100 amplitüdü çöker.",
                    "Fonksiyonel Görme Kaybı: Görmediğini iddia eden hastada (simülasyon) normal VEP objektif kanıttır."
                ],
                "footer": "Optik Nörit: Gecikmiş P100 Latansı (>120 ms)"
            }
        ]
    )

    # Slayt 2.5.1.5: Atlas Görseli: ffERG ve EOG Dalga Formları Atlası
    img_p84 = builder.get_image_for_page(84)
    builder.add_atlas_image_slide(
        title="ELEKTROFİZYOLOJİ STANDART DALGA FORMLARI ATLASI",
        category="BÖLÜM 2.5.1: GÖRSEL ATLAS",
        subtitle="Normal ISCEV Trasesi, Sönük ERG (RP), Negatif ERG ve Düşük Arden Oranı",
        image_path=img_p84 or "dr_schema_1",
        caption="Referans Eser Sayfa 84: Normal ffERG Dalga Basamakları ve Retinitis Pigmentosada Sönük Trase",
        key_findings=[
            "Normal Skotopik Yanıt: Derin negatif a-dalgası ve üzerine binen yüksek amplitüdlü pozitif b-dalgası [s.84].",
            "30 Hz Flicker: Koni sisteminin mükemmel zamanlama ile her ışık çakmasına senkron verdiği dalgalar.",
            "Sönük ERG (Extinguished): Retinitis Pigmentosada amplitüdlerin taban çizgisine yapışması (sıfırlanması).",
            "EOG Arden Oranı Grafiği: 15. dakikada karanlık çöküşü ve ardından 28. dakikada ışık tepe tırmanışı."
        ],
        differentials=[
            "Retinitis Pigmentosa: Tüm ffERG basamakları tamamen sönüktür (extinguished).",
            "X'e Bağlı Retinoskizis: a-dalgası normal, b-dalgası çökmüş (Negatif ERG paterni).",
            "Best Vitelliform Distrofi: ffERG kusursuz normal, EOG Arden oranı <%130."
        ],
        clinical_pearl="Çocukluk çağında niktalopi şikayeti olan bir hastada fundus muayenesi tamamen normal görünse dahi, sönük bir ffERG trasesi Retinitis Pigmentosa tanısını fundus bulgularından yıllar önce kesinleştirir [s.86]."
    )

    # Slayt 2.5.1.6: Karşılaştırmalı Özet Tablosu: Elektrofizyoloji Tanı Matrisi
    builder.add_study_card_slide(
        title="RETİNAL ELEKTROFİZYOLOJİ KLİNİK VE PATOLOJİ TANI MATRİSİ",
        category="BÖLÜM 2.5.1: TANI MATRİSİ",
        subtitle="ffERG, mfERG, EOG ve VEP Testlerinin Hastalık Bazında Yanıt Tablosu",
        cards=[
            {
                "card_title": "RETİNİTİS PİGMENTOSA",
                "lead": "Çomak-Koni Distrofisi",
                "items": [
                    "ffERG: Tamamen sönük / düz çizgi [s.85].",
                    "mfERG: Çevre sönük, foveada küçük tepe.",
                    "EOG: Işık piki tamamen kayıp.",
                    "VEP: İleri evrede amplitüd düşüşü."
                ],
                "footer": "Diffüz Dış Retina Yıkımı"
            },
            {
                "card_title": "BEST VİTELLİFORM",
                "lead": "RPE Klorür Kanalopatisi",
                "items": [
                    "ffERG: Kesinlikle Normal [s.88].",
                    "mfERG: Santral foveal tepe basık.",
                    "EOG: Patognomonik Düşük (<%140).",
                    "VEP: Tamamen Normal."
                ],
                "footer": "İzole RPE Kanal Disfonksiyonu"
            },
            {
                "card_title": "X'E BAĞLI RETİNOSKİZİS",
                "lead": "Retinoskizin (RS1) Defekti",
                "items": [
                    "ffERG: Negatif ERG (b < a) [s.86].",
                    "mfERG: Santral foveal kistte amplitüd kaybı.",
                    "EOG: Subnormal veya normal.",
                    "VEP: Genellikle Normal."
                ],
                "footer": "Bipolar / Müller İletim Engeli"
            },
            {
                "card_title": "OPTİK NÖRİT / MS",
                "lead": "Görsel Yolak Demiyelinizasyonu",
                "items": [
                    "ffERG: Tamamen Normal [s.89].",
                    "mfERG: Tamamen Normal.",
                    "EOG: Tamamen Normal.",
                    "VEP: P100 Latansı Aşırı Gecikmiş (>130 ms)."
                ],
                "footer": "İletim Hızı Yavaşlaması"
            }
        ]
    )

    print(f" -> Bölüm 2 (Görüntüleme ve Tanı Yöntemleri) Tamamlandı: 63 Slayt Eklendi.")
