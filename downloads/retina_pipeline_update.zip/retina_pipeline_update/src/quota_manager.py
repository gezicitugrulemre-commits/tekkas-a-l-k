"""
$100 Ek Kota (WPS / VPS / API Kredisi) + Google AI Ultra Hibrit Bütçe ve Yük Dengeleyici.

Özellikler:
1. $100'lık ek kotanızı (WPS / VPS / API Gateway) ve Ultra abonelik kredinizi birlikte takip eder.
2. Her alt-bölümde (420 alt-bölüm = 1000 sayfa) harcanan girdi/çıktı tokenlarını ve
   USD maliyetini `storage/quota_usage_ledger.json` dosyasına kaydeder.
3. Birincil kanalda (örn. Vertex AI / AI Studio) 429 Rate Limit oluşursa veya paralel hızlandırma
   istenirse otomatik olarak $100'lık WPS/VPS uç noktasına (Failover / Load Balancing) geçiş yapar.
4. Bütçe koruma kilidi: Belirlenen $100 kotanın %90'ına ulaşıldığında otomatik olarak
   ekonomik yüksek hız moduna geçerek kitabın yarıda kalmasını engeller.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Literal, Optional
from pydantic import BaseModel, Field

from config import MODEL_CONFIG, PATHS, SCALE_CONFIG


# Milyon token başına yaklaşık API maliyetleri (USD)
MODEL_PRICING_PER_1M_TOKENS = {
    "gemini-2.5-flash": {"input": 0.15, "output": 0.60},
    "gemini-2.5-pro": {"input": 1.25, "output": 10.00},
    "claude-sonnet-4@20250514": {"input": 3.00, "output": 15.00},
    "wps-remote-model": {"input": 0.50, "output": 1.50},
}


class QuotaUsageRecord(BaseModel):
    total_budget_usd: float = Field(default=100.0, description="Toplam $100 WPS/VPS ek bütçesi")
    spent_usd: float = Field(default=0.0, description="Şimdiye kadar harcanan USD tutarı")
    wps_pool_spent_usd: float = Field(default=0.0, description="$100 WPS/VPS havuzundan harcanan tutar")
    ultra_pool_spent_usd: float = Field(default=0.0, description="Ultra abonelik havuzundan harcanan tutar")
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    subsections_completed: int = 0
    last_updated: str = ""
    history: Dict[str, Dict] = Field(default_factory=dict)

    @property
    def remaining_usd(self) -> float:
        return max(0.0, round(self.total_budget_usd - self.spent_usd, 4))

    @property
    def avg_cost_per_subsection(self) -> float:
        if self.subsections_completed == 0:
            return 0.042  # Varsayılan hibrit maliyet tahmini ($0.042 / alt-bölüm)
        return round(self.spent_usd / self.subsections_completed, 4)

    @property
    def projected_1000_page_cost_usd(self) -> float:
        total_subs = SCALE_CONFIG.num_parts * SCALE_CONFIG.chapters_per_part * SCALE_CONFIG.subsections_per_chapter
        return round(self.avg_cost_per_subsection * total_subs, 2)


class QuotaAndWPSManager:
    """
    $100 WPS/VPS kotasını yönetir, token maliyetlerini hesaplar ve
    paralel/yedekli (failover) çalıştırma kararlarını verir.
    """

    def __init__(self):
        PATHS.ensure_dirs()
        self.quota_file: Path = PATHS.storage_dir / "quota_usage_ledger.json"
        self.record = self._load()

    def _load(self) -> QuotaUsageRecord:
        if self.quota_file.exists():
            data = json.loads(self.quota_file.read_text(encoding="utf-8"))
            rec = QuotaUsageRecord(**data)
            rec.total_budget_usd = MODEL_CONFIG.wps_quota_budget_usd
            return rec
        return QuotaUsageRecord(total_budget_usd=MODEL_CONFIG.wps_quota_budget_usd)

    def save(self) -> None:
        self.record.last_updated = datetime.now().isoformat(timespec="seconds")
        self.quota_file.write_text(self.record.model_dump_json(indent=2), encoding="utf-8")

    def estimate_and_log_usage(
        self,
        subsection_id: str,
        fast_input_tokens: int,
        fast_output_tokens: int,
        writer_input_tokens: int,
        writer_output_tokens: int,
        used_pool: Literal["ultra", "wps"] = "wps",
    ) -> float:
        """Alt-bölüm üretimi sonunda harcanan token ve USD tutarını hesaplayıp kaydeder."""
        fast_rates = MODEL_PRICING_PER_1M_TOKENS.get(
            MODEL_CONFIG.fast_model_name, {"input": 0.15, "output": 0.60}
        )
        writer_rates = MODEL_PRICING_PER_1M_TOKENS.get(
            MODEL_CONFIG.writer_model_name, {"input": 3.00, "output": 15.00}
        )

        fast_cost = (fast_input_tokens / 1_000_000) * fast_rates["input"] + (
            fast_output_tokens / 1_000_000
        ) * fast_rates["output"]
        writer_cost = (writer_input_tokens / 1_000_000) * writer_rates["input"] + (
            writer_output_tokens / 1_000_000
        ) * writer_rates["output"]

        section_cost = round(fast_cost + writer_cost, 5)

        self.record.total_input_tokens += fast_input_tokens + writer_input_tokens
        self.record.total_output_tokens += fast_output_tokens + writer_output_tokens
        self.record.spent_usd = round(self.record.spent_usd + section_cost, 4)

        if used_pool == "wps":
            self.record.wps_pool_spent_usd = round(self.record.wps_pool_spent_usd + section_cost, 4)
        else:
            self.record.ultra_pool_spent_usd = round(self.record.ultra_pool_spent_usd + section_cost, 4)

        self.record.subsections_completed += 1
        self.record.history[subsection_id] = {
            "cost_usd": section_cost,
            "pool": used_pool,
            "input_tokens": fast_input_tokens + writer_input_tokens,
            "output_tokens": fast_output_tokens + writer_output_tokens,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        self.save()
        return section_cost

    def should_use_economy_writer(self) -> bool:
        """
        Eğer $100'lık kotanın %88'inden fazlası harcandıysa ve hala yazılacak bölümler varsa,
        kitabın kesintiye uğramaması için yazarı otomatik olarak düşük maliyetli modele geçirir.
        """
        if self.record.total_budget_usd <= 0:
            return False
        utilization = self.record.spent_usd / self.record.total_budget_usd
        return utilization >= 0.88
