# -*- coding: utf-8 -*-
r"""
retina_ch9_builder.py — Bölüm 9: Travma, Farmakoterapi, Gelecek Perspektifler ve Yapay Zeka (31 Slayt)
===================================================================================================
Kitap Sayfaları: 259 – 276
Alt Başlıklar:
  9.0   Bölüm 9 Çalışma Yol Haritası (1 slayt)
  9.1.1 Posterior Segment Travmaları (Berlin Ödemi, Koroid Rüptürü, İOYC, Açık Glob) (8 slayt)
  9.1.2 İntravitreal Enjeksiyon Güvenliği, Sterilite ve Endoftalmi Yönetimi (EVS Protokolü) (8 slayt)
  9.2.1 Yapay Zeka, Teleoftalmoloji ve Türkiye Sağlık Sistemi (ASM / Teletıp) Entegrasyonu (7 slayt)
  9.2.2 Kök Hücre Tedavileri, Retinal Protezler (Biyonik Göz) ve Biyomühendislik (7 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_9(builder: RetinaStudyDeckBuilder):
    """Bölüm 9'a ait 31 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 9 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=9,
        title="TRAVMA, FARMAKOTERAPİ, GELECEK PERSPEKTİFLER VE YAPAY ZEKA",
        page_range="Sayfa 259 – 276",
        subtitle="Posterior Travma, Enjeksiyon Sterilitesi, EVS Endoftalmi Protokolü, Türkiye ASM Triyajı ve Biyonik Göz",
        cards=[
            {
                "title": "1. Posterior Travma Acilleri",
                "color": PPTXPalette.RED,
                "lead": "Berlin Ödemi, İOYC & Açık Glob",
                "items": [
                    "Berlin Ödemi (Commotio Retinae): Fotoreseptör dış segment parçalanması; genellikle spontan iyileşir.",
                    "Koroid Rüptürü: Künt travmada konsantrik kavisli yırtık; en büyük geç risk subretinal KNV gelişimidir.",
                    "Açık Küre (Glob) Yaralanması: İlk 24 saatte acil primer cerrahi kapatma; göze MR KESİNLİKLE YASAKTIR.",
                    "İntraoküler Yabancı Cisim (İOYC): Demir parçaları (siderozis bulbi) katarakt, heterokromi ve negatif ERG yapar."
                ],
                "footer": "Açık Glob (MR Yasak) / İOYC (Siderozis)"
            },
            {
                "title": "2. Enjeksiyon Güvenliği & Endoftalmi",
                "lead": "Povidon İyot & EVS Protokolü",
                "items": [
                    "Enjeksiyonun Altın Kuralı: %5 Povidon İyot (Betadin) en az 3 dk temas; cerrahi maske ve konuşma yasağı.",
                    "Hatalı Alışkanlık: Postoperatif antibiyotikli damla dirençli florayı artırır; KESİNLİKLE KULLANILMAMALIDIR.",
                    "Endoftalmi Tedavisi (EVS Kuralı): Işık hissi (LP) ise acil PPV; El hareketi (HM) veya üzeri ise İntravitreal Antibiyotik.",
                    "Antibiyotik Çifti: Vankomisin (1 mg) [Gram +] + Seftazidim (2.25 mg) [Gram -] intravitreal enjeksiyonu."
                ],
                "footer": "%5 Povidon İyot / Postop Damla Yok / EVS Kuralı"
            },
            {
                "title": "3. Yapay Zeka & Türkiye Sağlık Sistemi",
                "lead": "ASM Triyajı ve Teletıp Entegrasyonu",
                "items": [
                    "Otonom YZ Sistemleri: IDx-DR ve EyeArt ile sevk edilebilir diyabetik retinopati tespiti (Duyarlılık >%87).",
                    "Türkiye ASM Entegrasyonu: Aile Sağlığı Merkezlerinde non-midriyatik kamera ile 1. basamak triyajı.",
                    "Sağlık Bakanlığı Teletıp: Görüntülerin merkezi bulutta taranması ve 3. basamak sevk yükünün %70 azaltılması.",
                    "SGK ve SUT Perspektifi: Erken tanı ile vitrektomi ve anti-VEGF maliyetlerinin dramatik düşürülmesi."
                ],
                "footer": "ASM Triyajı / Sağlık Bakanlığı Teletıp / SUT Tasarrufu"
            },
            {
                "title": "4. Biyomühendislik & Biyonik Retina",
                "lead": "Kök Hücre & Retinal Protezler",
                "items": [
                    "iPSC ve ESC Hücreleri: Coğrafi atrofi ve Stargardt için RPE süspansiyonu ve sentetik yama nakilleri.",
                    "Subretinal Mikroçipler: PRIMA ve Argus II implantları ile fotoreseptörsüz kör retinada harf okuma başarısı.",
                    "Optogenetik Restorasyon: Bipolar ve gangliyon hücrelerine aktarılan kanalrodopsin ile ışık duyarlılığı.",
                    "Nöroproteksiyon: BDNF ve CNTF salgılayan enkapsüle hücre teknolojileri ile dejenerasyonun yavaşlatılması."
                ],
                "footer": "iPSC Yama / PRIMA Protezi / Optogenetik Restorasyon"
            }
        ]
    )

    # =========================================================================
    # 9.1.1: POSTERİOR SEGMENT TRAVMALARI (8 Slayt)
    # =========================================================================

    # Slayt 9.1.1.1: Künt Göz Travması ve Berlin Ödemi (Commotio Retinae)
    builder.add_study_card_slide(
        title="KÜNT TRAVMA VE BERLİN ÖDEMİ (COMMOTİO RETİNAE)",
        category="BÖLÜM 9.1.1: KÜNT TRAVMA",
        subtitle="Şok Dalgası (Coup-Contrecoup), Fotoreseptör Dış Segment Parçalanması ve Doğal Seyir",
        cards=[
            {
                "card_title": "1. Patofizyolojik Mekanizma",
                "lead": "Gerçek Bir Hücreler Arası Sıvı Ödemi DEĞİLDİR",
                "items": [
                    "Göze gelen doğrudan darbenin oluşturduğu hidrolik şok dalgası arka kutba vurur (contrecoup mekanizması) [s.259].",
                    "Sanılanın aksine vasküler sızıntı veya seröz sıvı birikimi (ekstrasellüler ödem) YOKTUR.",
                    "Patoloji: Fotoreseptör dış segment disklerinin mekanik olarak kırılması ve hücre içi bulanıklaşmasıdır.",
                    "SD-OKT'de elipsoid zonda (EZ) geçici aşırı hiperreflektivite ve fotoreseptör tabakasında kalınlaşma izlenir."
                ],
                "footer": "Mekanik Fotoreseptör Hasarı / Vasküler Sızıntı Yoktur"
            },
            {
                "card_title": "2. Klinik Oftalmoskopik Görünüm",
                "lead": "Süt Beyazı-Gri Retinal Opasifikasyon",
                "items": [
                    "Travmadan birkaç saat sonra makulada veya darbe yönünün karşı periferinde süt beyazı-gri donukluk belirir [s.259].",
                    "Fovea merkezinde retina çok ince olduğundan alttaki koroid parlar ve 'kiraz kırmızısı benek' (cherry-red spot) taklidi oluşur.",
                    "Görme keskinliği geçici olarak 0.1 - 0.4 düzeyine inebilir.",
                    "Periferik retina tutulumuna 'Commotio Retinae', izole foveal tutuluma ise özel olarak 'Berlin Ödemi' denir."
                ],
                "footer": "Süt Beyazı Retina / Yalancı Kiraz Kırmızısı Benek"
            },
            {
                "card_title": "3. Doğal Seyir ve Tedavi İlkesi",
                "lead": "Spontan İyileşme — İlaç Tedavisi GEREKMEZ",
                "items": [
                    "Olguların %90'ından fazlasında beyazlık 1 ila 2 hafta içinde kendiliğinden tamamen geriler [s.260].",
                    "Görme keskinliği foveada kalıcı dış segment nekrozu oluşmamışsa tekrar 1.0 tam seviyesine toparlar.",
                    "Sistemik steroid veya cerrahi müdahale KESİNLİKLE GEREKSİZDİR; faydası kanıtlanmamıştır.",
                    "Ancak travmaya bağlı periferik diyaliz, retina yırtığı veya koroid rüptürü eşlik edebileceğinden 360° muayene şarttır."
                ],
                "footer": "1-2 Haftada Spontan Rezolüsyon / Steroid GEREKSİZDİR"
            }
        ]
    )

    # Slayt 9.1.1.2: Koroid Rüptürü: Direkt vs İndirekt ve Geç KNV Riski
    builder.add_study_card_slide(
        title="KOROİD RÜPTÜRÜ VE GEÇ KOROİDAL NEOVASKÜLARİZASYON",
        category="BÖLÜM 9.1.1: KOROİD RÜPTÜRÜ",
        subtitle="Bruch Zarı Yırtılması, Optik Diske Konsantrik Hilal Hatları ve Sekonder KNV Tehdidi",
        cards=[
            {
                "card_title": "1. Rüptür Biyomekaniği ve Çeşitleri",
                "lead": "Elastik Skleranın Direncine Karşı Kırılgan Bruch Zarı",
                "items": [
                    "Künt darbe sırasında sklera esnerken elastikiyeti olmayan koryokapillaris, Bruch zarı ve RPE yırtılır [s.260].",
                    "Direkt Koroid Rüptürü: Darbenin doğrudan vurduğu ön periferde, darbe hattına paralel yırtık.",
                    "İndirekt Koroid Rüptürü (%80 En Sık): Arka kutupta, optik diske konsantrik kavisli (hilal şeklinde) yırtık.",
                    "Akut evrede yırtık sahası subretinal kanama ile örtülüdür; kan çekildikten sonra beyaz kavisli hat netleşir."
                ],
                "footer": "Bruch Yırtığı / Diske Konsantrik Hilal Şekli"
            },
            {
                "card_title": "2. Görme Prognozu ve Fovea İlişkisi",
                "lead": "Hilalin Foveadan Geçip Geçmemesi",
                "items": [
                    "Yırtık hattı foveanın dışından geçiyorsa hastanın santral görmesi korunabilir [s.260].",
                    "Eğer kavis tam fovea merkezinden (subfoveal) geçiyorsa fotoreseptörler anatomik olarak koptuğu için kalıcı skotom kalır.",
                    "Yırtık iyileşirken kenarlarında hiperplastik RPE pigmentasyonu ve fibrotik skar oluşur.",
                    "Hasta foveal lezyon olsa dahi eksantrik fiksasyonla yaşamını sürdürebilir."
                ],
                "footer": "Subfoveal Yırtık = Kalıcı Santral Skotom"
            },
            {
                "card_title": "3. En Büyük Geç Komplikasyon: Travmatik KNV",
                "lead": "Yaralanmadan Aylar Sonra Gelişen Kanama",
                "items": [
                    "Yırtık zemininde Bruch zarının yırtık olması koroid damarlarının subretinal alana sızmasına zemin hazırlar [s.261].",
                    "Hastaların %15-20'sinde aylar veya yıllar sonra yırtık kenarından Tip 2 Koroidal Neovaskülarizasyon (KNV) filizlenir.",
                    "Hastada ani görme düşüşü ve metamorfopsi başlarsa derhal SD-OKT ve OKTA çekilmelidir.",
                    "Tedavi: İntravitreal Anti-VEGF (Ranibizumab veya Aflibercept) enjeksiyonlarına mükemmel ve hızlı yanıt verir."
                ],
                "footer": "Geç KNV Riski (%20) / İntravitreal Anti-VEGF Çözümü"
            }
        ]
    )

    # Slayt 9.1.1.3: Purtscher ve Purtscher-Benzeri Retinopati
    builder.add_study_card_slide(
        title="PURTSCHER VE PURTSCHER-BENZERİ RETİNOPATİ",
        category="BÖLÜM 9.1.1: TRAVMA İLİŞKİLİ",
        subtitle="Ağır Toraks Kompresyonu, Akut Pankreatit, Yağ Embolisi ve Purtscher Fleckleri",
        cards=[
            {
                "card_title": "1. Etyoloji: Purtscher vs Purtscher-Benzeri",
                "lead": "Doğrudan Göze Darbe Olmaksızın Gelişen Hasar",
                "items": [
                    "Klasik Purtscher Retinopatisi: Ağır toraks travması (ezilme/kompresyon) veya uzun kemik kırıkları sonrası gelişir [s.261].",
                    "Purtscher-Benzeri (Purtscher-Like): Travma olmaksızın akut pankreatit, preeklampsi/HELLP sendromu, amniyon sıvısı embolisi veya kollajen doku hastalıklarında görülür.",
                    "Mekanizma: Kompleman aktivasyonu (C5a) sonucu oluşan lökosit agregatları veya yağ embolilerinin prekapiller arteriolleri tıkamasıdır.",
                    "Olaydan 24-48 saat sonra her iki gözde ani ve belirgin görme azalması ile tablo ortaya çıkar."
                ],
                "footer": "Toraks Travması / Akut Pankreatit / Yağ Embolisi"
            },
            {
                "card_title": "2. Patognomonik Bulgu: Purtscher Fleckleri",
                "lead": "Pamuk Atığından Ayrılan Berrak Perivasküler Kuşak",
                "items": [
                    "Optik disk çevresi ve arka kutupta çok sayıda beyaz, poligonel retinal infiltratlar izlenir [s.261].",
                    "Purtscher Fleck'inin ayırt edici özelliği: Retinal arteriolün hemen çevresindeki 50 μm'lik alanı temiz bırakmasıdır.",
                    "Yani infiltrat damara yapışmaz; damar çevresinde şeffaf bir 'temiz koridor' (perivasküler aralık) bulunur.",
                    "Ayrıca yüzeyel alev kanamalar ve pamuk atığı (cotton-wool) lekeleri eşlik eder."
                ],
                "footer": "Purtscher Fleck = Damar Çevresinde Temiz Koridor"
            },
            {
                "card_title": "3. Tedavi ve Prognoz",
                "lead": "Altta Yatan Nedenin Tedavisi",
                "items": [
                    "Spesifik bir oküler cerrahi tedavisi yoktur; altta yatan sistemik patoloji (pankreatit, kırık stabilizasyonu) düzeltilir [s.262].",
                    "Yüksek doz sistemik kortikosteroidler kompleman kaskadını ve endotel inflamasyonunu baskılamak için tartışmalıdır ancak sık kullanılır.",
                    "Hastaların yaklaşık %50'sinde lezyonlar 1-3 ayda geriler ve görme kısmen toparlar.",
                    "Fovea avasküler zonunda kalıcı kapiller oklüzyon kalan olgularda santral skotom ve optik atrofi kalıcı olur."
                ],
                "footer": "Sistemik Stabilizasyon / %50 İyileşme / Kalıcı İskemi Riski"
            }
        ]
    )

    # Slayt 9.1.1.4: Açık Küre Yaralanması: İlk 24 Saatte Primer Skleral Sütürasyon
    builder.add_study_card_slide(
        title="AÇIK KÜRE (GLOB) YARALANMASI VE ACİL PRİMER ONARIM",
        category="BÖLÜM 9.1.1: AÇIK GLOB ACİLİ",
        subtitle="Rüptür ve Perforasyon Yönetimi, Koruyucu Kalkan, Kusmanın Önlenmesi ve MR KONTRENDİKASYONU",
        cards=[
            {
                "card_title": "1. Acil Serviste İlk Müdahale Kuralları",
                "lead": "Göze Asla Dokunma, Basınç Uygulama!",
                "items": [
                    "Açık glob şüphesi olan göze kesinlikle göz kapağı ekartörü takılmaz, tonometri yapılmaz [s.262].",
                    "Gözün üzerine steril sert koruyucu kalkan (eye shield) bantlanır; göze temas eden gazlı bez veya baskılı pansuman KESİNLİKLE YASAKTIR.",
                    "Hasta mutlak aç bırakılır; göz içi içeriğinin dışarı fışkırmasını önlemek için öksürük ve kusma antiemetiklerle derhal durdurulur.",
                    "Tetanoz profilaksisi ve sistemik geniş spektrumlu intravenöz antibiyotik (Vankomisin + Siprofloksasin) başlanır."
                ],
                "footer": "Sert Kalkan / Sıfır Basınç / Antiemetik / İV Antibiyotik"
            },
            {
                "card_title": "2. Radyolojik Altın Kural: MR KESİNLİKLE YASAKTIR!",
                "lead": "Manyetik Rezonansın Ölümcül Riski",
                "items": [
                    "Açık glob yaralanmalarında metalik yabancı cisim ihtimali dışlanana kadar MR ÇEKİLMESİ KESİNLİKLE YASAKTIR [s.262].",
                    "Güçlü manyetik alan göz içindeki metal parçasını hareket ettirerek retinayı parçalar ve gözü tamamen imha eder.",
                    "Görüntülemede Altın Standart: 1 mm kesitli, kontrastsız İnce Kesit Taşral/Orbital Bilgisayarlı Tomografidir (BT).",
                    "BT skleral bütünlüğü, yabancı cismi ve optik sinir hasarını kusursuz gösterir."
                ],
                "footer": "⚠️ MANYETİK REZONANS (MRG) KESİNLİKLE KONTRENDİKEDİR"
            },
            {
                "card_title": "3. İlk 24 Saatte Primer Cerrahi Onarım",
                "lead": "Göz Bütünlüğünün Su Geçirmez Kapatılması",
                "items": [
                    "İlk 24 saat içinde genel anestezi altında (süksinilkolin KULLANILMAZ; GİB'i artırır) acil ameliyata alınır [s.263].",
                    "Kornea kesileri 10-0 naylon, sklera kesileri 8-0 veya 9-0 vikril/naylon ile su geçirmez şekilde kapatılır.",
                    "Dışarı prolabe olmuş üveal doku taze ve temizse nazikçe içeri itilir; nekrotik veya kirli ise eksize edilir.",
                    "Primer cerrahide amaç vitreus cerrahisi değil, YALNIZCA GÖZ KÜRESİNİN BÜTÜNLÜĞÜNÜN KAPATILMASIDIR."
                ],
                "footer": "İlk 24 Saat / Su Geçirmez Sütürasyon / Küre Bütünlüğü"
            }
        ]
    )

    # Slayt 9.1.1.5: İntraoküler Yabancı Cisim (İOYC) ve Siderozis Bulbi
    builder.add_study_card_slide(
        title="İNTRAOKÜLER YABANCI CİSİM (İOYC) VE SİDEROZİS BULBİ",
        category="BÖLÜM 9.1.1: İOYC & SİDEROZİS",
        subtitle="Demir ve Bakır Toksisitesi, Heterokromi, Midriyazis ve Patognomonik ERG Çöküşü",
        cards=[
            {
                "card_title": "1. Metal Parçacığının Dokularda Oksidasyonu",
                "lead": "Demir (Siderozis) vs Bakır (Kalkozis)",
                "items": [
                    "Çekiçle metale vurma, taşlama veya ateşli silah yaralanmalarında yüksek hızlı parçacıklar göze saplanır [s.263].",
                    "Siderozis Bulbi: Demir (Fe) içeren yabancı cismin göz içinde paslanarak demir iyonlarının dokulara yayılmasıdır.",
                    "Demir serbest oksijen radikalleri üreterek RPE, trabeküler ağ ve fotoreseptör hücrelerini irreversibl zehirler.",
                    "Kalkozis: Bakır (>%85) içeren cisimler ise saatler içinde fulminan aseptik endoftalmi ve sarı kornea halkası yapar."
                ],
                "footer": "Demir Toksisitesi (Siderozis) vs Bakır Toksisitesi (Kalkozis)"
            },
            {
                "card_title": "2. Siderozis Bulbi Klinik Bulguları",
                "lead": "Göz Renginin Pas Sarısına Dönmesi",
                "items": [
                    "İris Heterokromisi: Demir çöken gözün irisi diğer göze kıyasla daha koyu kahverengi veya pas rengi alır [s.263].",
                    "Pupilla Anomalisi: İris sfinkter disfonksiyonuna bağlı midriyazis ve ışık refleksinde tembellik.",
                    "Siderotik Katarakt: Ön lens kapsülü altında pas rengi demir lekeleri ve difüz lens opasifikasyonu.",
                    "İkincil Glokom: Trabeküler ağın demir birikimiyle tıkanması sonucu tedaviye dirençli glokom gelişir."
                ],
                "footer": "Heterokromi + Midriyazis + Pas Rengi Katarakt + Glokom"
            },
            {
                "card_title": "3. Erken Teşhiste Altın Standart: ERG",
                "lead": "B-Dalgası Amplitüdünün Çökmesi",
                "items": [
                    "Siderozis tanısında ve ameliyat aciliyetinin belirlenmesinde en duyarlı yöntem tam alan ERG'dir [s.264].",
                    "Erken Faz: İrritasyona bağlı a- ve b-dalgalarında geçici süpernormal genlik artışı görülebilir.",
                    "Toksik Faz: B-dalgası amplitüdü hızla çöker; b-dalgası a-dalgasının altına iner (negatif ERG).",
                    "Geç Faz: Tüm dalgalar düzleşir ve söner (extinguished ERG); geri dönüşsüz körlük oluşur.",
                    "Cerrahi: ERG bozulmaya başladığı anda acil 23/25G PPV ve intraoküler mıknatıs/forseps ile cisim çıkarılmalıdır."
                ],
                "footer": "ERG Takibi / B-Dalgası Çöküşü / Acil PPV ile Çıkarma"
            }
        ]
    )

    # Slayt 9.1.1.6: Travma Radyolojik ve Klinik Tanı Atlası
    builder.add_split_comparison_slide(
        title="TRAVMA RADYOLOJİSİ: B-SCAN vs BİLGİSAYARLI TOMOGRAFİ (BT)",
        category="BÖLÜM 9.1.1: GÖRÜNTÜLEME AYRIMI",
        subtitle="Açık Glob Şüphesinde Görüntüleme Güvenliği ve Endikasyon Matrisi",
        left_entity={
            "name": "BİLGİSAYARLI TOMOGRAFİ (BT) — İLK SEÇENEK",
            "subtitle": "Açık Glob ve İOYC Şüphesinde Tartışmasız Standart",
            "bullets": [
                "Güvenlik: Göze hiçbir fiziksel temas veya prob basıncı gerektirmez [s.262].",
                "Yabancı Cisim: 0.5 mm boyutundaki metalik cisimleri dahi %100 doğrulukla saptar.",
                "Lokalizasyon: Cismin skleranın içinde mi, retinada mı yoksa retrobulber orbitada mı olduğunu net gösterir.",
                "Skleral Bütünlük: Ön kamara sığlaşması, lens luksasyonu ve sklera çentiğini gösterir.",
                "Kural: Kontrastsız, 1 mm aksiyel ve koronal ince kesit orbital BT çekilmelidir [s.262]."
            ]
        },
        right_entity={
            "name": "B-SCAN ULTRASONOGRAFİ — DİKKAT!",
            "subtitle": "Yalnızca Kapalı Globda ve Primer Kapatma Sonrası",
            "bullets": [
                "GÜVENLİK TEHLİKESİ: Açık küre varlığında göze prob bastırmak GÖZ İÇERİĞİNİ DIŞARI FIŞKIRTIR!",
                "Bu nedenle rüptüre veya açık glob şüphesi olan göze B-Scan USG KESİNLİKLE YAPILMAZ [s.262].",
                "Ne Zaman Yapılır? Sklera ve kornea primer cerrahiyle su geçirmez kapatıldıktan SONRA yapılır.",
                "Klinik Rolü: Postoperatif dönemde vitreus kanamasının arkasında retina dekolmanı ve PVR varlığını tarar.",
                "Yabancı Cisim: Metal cisim arkasında reverberasyon ve kuyruklu yıldız ekosu verir [s.263]."
            ]
        },
        bottom_takeaway="Açık glob şüphesinde göze ultrason probu değdirmek felakettir; ilk tetkik ince kesit orbital BT'dir; MR ise metal varlığında gözü imha eder [s.262]."
    )

    # Slayt 9.1.1.7: Oküler Travma Acil Triyaj Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="POSTERİOR SEGMENT TRAVMA ACİL TRİYAJ PROTOKOLÜ",
        category="BÖLÜM 9.1.1: AKIŞ ŞEMASI",
        subtitle="Travma İle Acil Servise Gelen Hastada Saatlik Müdahale Algoritması",
        steps=[
            {
                "num": "1",
                "title": "Kalkan Takılması ve Basınçtan Kaçınma",
                "desc": "Göze sert koruyucu kalkan takılır; baskılı pansuman yapılmaz; antiemetik verilir [s.262].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "İnce Kesit Orbital BT Çekimi",
                "desc": "MR KESİNLİKLE YASAKTIR; 1 mm kesitli BT ile yabancı cisim ve skleral defekt araştırılır.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "İlk 24 Saatte Primer Skleral Kapatma",
                "desc": "Genel anestezi altında kornea ve sklera su geçirmez kapatılır; sistemik IV antibiyotik yüklenir.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "İkinci Seans PPV (İOYC Çıkarılması)",
                "desc": "Küre kapandıktan sonraki 3-7. günlerde vitrektomi yapılarak yabancı cisim çıkarılır ve retina onarılır [s.264].",
                "status": "success"
            }
        ],
        bottom_takeaway="Açık glob yaralanmasında yabancı cismi hemen primer onarımda çıkarmaya çalışmak kanamaya yol açabilir; önce göz kapatılmalı, vitrektomi deneyimli merkezde 3-7 gün sonra yapılmalıdır [s.263]."
    )

    # Slayt 9.1.1.8: Aktif Hatırlama & Board Sınavı Vakası: Metal Çapak ve Siderozis
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: İOYC VE SİDEROZİS",
        category="BÖLÜM 9.1.1: AKTİF HATIRLAMA",
        subtitle="32 Yaşında Demir Doğrama Ustası Çekiç Sesinden 3 Ay Sonra Görme Azlığı ve İris Kararması",
        vignette="32 yaşında demir doğrama ustası erkek hasta, 3 ay önce çekiçle demir döverken sağ gözüne 'bir şey sıçrar gibi' olduğunu ancak acı hissetmediği için doktora gitmediğini belirtiyor. Son 2 haftadır sağ gözünde görme bulanıklığı, karanlıkta zor görme ve eşinin fark ettiği 'sağ göz renginin sol göze göre pas sarısına kararması' şikayetiyle başvuruyor. Sağ görme 0.3, sol görme 1.0 tam. Biyomikroskopide sağ iriste belirgin pas rengi koyulaşma (heterokromi), pupillada hafif midriyazis ve lens ön kapsülünde dairesel pas benekleri izleniyor. İndirekt oftalmoskopide inferotemporal periferik retinada üzeri hafif fibrozisle örtülü küçük koyu bir cisim ve retinal damarlarda kılıflanma izleniyor. Çekilen ince kesit orbital BT'de inferotemporal retinaya saplanmış 1.5 mm boyutunda radyoopak metalik cisim doğrulanıyor. Tam alan ERG'de sağ gözde b-dalgası amplitüdünün a-dalgasının altına indiği (negatif ERG) saptanıyor.",
        differentials=[
            "Oküler Siderozis Bulbi (İhmal edilmiş demir İOYC, heterokromi, midriyazis, pas kataraktı ve ERG b-dalga çöküşü).",
            "Kalkozis (Bakır cisimdir; haftalar içinde değil saatler/günler içinde aseptik endoftalmi ve korneal ayçiçeği kataraktı yapar).",
            "Primer İris Melanomu (Heterokromi yapar ancak travma öyküsü, pas kataraktı ve kitle yoktur).",
            "Fuchs Heterokromik İridosikliti (Heterokromi ve katarakt yapar ancak travma ve İOYC içermez)."
        ],
        decision="1. Kesin Tanı: İhmal Edilmiş İntraoküler Yabancı Cisim (Demir) Zemininde Gelişen Erken Siderozis Bulbi.\n2. Tedavi Stratejisi: Cisim derhal cerrahi olarak çıkarılmalıdır; beklenirse toksisite tüm retinayı eriterek sönük ERG ile kalıcı körlük yapar.\n3. Cerrahi Yöntem: 23G/25G Pars Plana Vitrektomi yapılır; cisim fovea üzerinden değil periferik retinadan intraoküler mıknatıs veya yabancı cisim forsepsi ile çıkarılır; saplanma yerine endolazer uygulanır.\n4. Takip: Cisim çıkarıldıktan sonra ERG takibi yapılır; erken evrede çıkarılan demir olgularında retina fonksiyonları kısmen toparlayabilir.",
        board_trap="Bu hastada göz rengi koyulaşmasını görüp 'gözün içinde metal var mı diye bir MR çekelim' demek ölümcül bir felakettir; manyetik rezonans demir parçasını fırlatarak gözü içeriden parçalar; görüntüleme yalnızca ince kesit BT ile yapılmalıdır [s.262]."
    )

    # =========================================================================
    # 9.1.2: İNTRAVİTREAL ENJEKSİYON STERİLİTESİ VE ENDOFTALMİ (8 Slayt)
    # =========================================================================

    # Slayt 9.1.2.1: Enjeksiyonun Altın Kuralı: %5 Povidon İyot
    builder.add_study_card_slide(
        title="İNTRAVİTREAL ENJEKSİYONDA STERİLİTE VE %5 POVİDON İYOT",
        category="BÖLÜM 9.1.2: STERİLİTE PROTOKOLÜ",
        subtitle="Endoftalmiyi Önleyen Kanıtlanmış Tek Antiseptik: %5 Betadin ve Maske Kuralı",
        cards=[
            {
                "card_title": "1. %5 Povidon İyot (Betadin) Şartı",
                "lead": "Kanıta Dayalı Tıbbın Tartışmasız Tek Ajanı",
                "items": [
                    "Konjonktiva forniksine ve korneaya en az %5'lik povidon iyot damlatılmalıdır [s.264].",
                    "Temas Süresi: Antiseptik etkinliğin tam sağlanması için solüsyon göze damlatıldıktan sonra EN AZ 3 DAKİKA beklenmelidir.",
                    "Konsantrasyon: Cilt için olan %10'luk solüsyon kornea epitel toksisitesi yapabilir; göze %5'lik konsantrasyon idealdir.",
                    "Göz kapaklarına ve kirpik diplerine ise %10 povidon iyot ile mekanik fırçalama/silme uygulanır."
                ],
                "footer": "%5 Povidon İyot / En Az 3 Dakika Bekleme Süresi"
            },
            {
                "card_title": "2. Cerrahi Maske ve Konuşma Yasağı",
                "lead": "Ağız Florasından Damlacık İzolasyonu",
                "items": [
                    "Endoftalmi olgularında en yıkıcı ajan oral flora bakterisi olan Streptococcus viridans'tır [s.264].",
                    "Hem hekim hem hasta işlem boyunca cerrahi maske takmalı VEYA enjeksiyon sırasında konuşma tamamen yasaklanmalıdır.",
                    "Maske takılmaması veya enjeksiyon sırasında konuşulması streptokok endoftalmisi riskini katlar.",
                    "Göz kapaklarını açık tutmak için kirpik temasını engelleyen steril bir blefarosta (spekulum) kullanılmalıdır."
                ],
                "footer": "Cerrahi Maske Şart / Konuşma Kesinlikle Yasaktır"
            },
            {
                "card_title": "3. Enjeksiyon Lokalizasyonu ve İğne Çapı",
                "lead": "Limbus Gerisi Güvenlik Mesafeleri",
                "items": [
                    "Fakik (Doğal lensli) Gözlerde: Limbus gerisinden 3.5 – 4.0 mm mesafe [s.264].",
                    "Psödofakik / Afakik Gözlerde: Limbus gerisinden 3.0 – 3.5 mm mesafe.",
                    "Kadran Tercihi: Genellikle üst veya alt temporal kadran; iğne göz küresinin merkezine (arka kutba) doğru yönlendirilir.",
                    "30G veya 32G ince iğneler tercih edilir; iğne çekilirken skleral reflüyü önlemek için steril pamukla bası yapılır."
                ],
                "footer": "Fakik 3.5-4.0 mm / Psödofakik 3.0-3.5 mm"
            }
        ]
    )

    # Slayt 9.1.2.2: Postoperatif Antibiyotikli Damla Neden Yasaktır?
    builder.add_study_card_slide(
        title="KLİNİK TUZAK: POSTOPERATİF ANTİBİYOTİKLİ DAMLA YASAĞI",
        category="BÖLÜM 9.1.2: KANITA DAYALI TIP",
        subtitle="Enjeksiyon Sonrası Rutin Antibiyotik Kullanımı Neden Endoftalmiyi Azaltmaz ve Zarar Verir?",
        cards=[
            {
                "card_title": "1. Kanıt Düzeyi: Endoftalmiyi Azaltmaz",
                "lead": "Büyük Çok Merkezli Kohort Sonuçları",
                "items": [
                    "Yüz binlerce enjeksiyonu inceleyen randomize çalışmalarda (DRCR.net, ASRS) antibiyotik alan ve almayan gruplar karşılaştırılmıştır [s.265].",
                    "Enjeksiyon sonrası 3-5 gün antibiyotikli damla (florokinolon vb.) kullanmanın endoftalmi insidansını HİÇ AZALTMADIĞI kanıtlanmıştır.",
                    "Enfeksiyon anı iğnenin girdiği ilk saniyelerdir; yüzeye sonradan damlatılan antibiyotik göz içine girmiş bakteriyi öldüremez.",
                    "Bu nedenle Amerikan Retina Uzmanları Derneği (ASRS) ve uluslararası kılavuzlar postop antibiyotiği terk etmiştir."
                ],
                "footer": "Endoftalmi Riskini Sıfır Derecede Azaltır"
            },
            {
                "card_title": "2. Tehlike: Dirençli Bakteri Florası Gelişimi",
                "lead": "Konjonktiva Mikrobiyotasının Bozulması",
                "items": [
                    "Her ay tekrarlayan enjeksiyonlar alan hastalarda sürekli antibiyotik damlatılması konjonktivadaki kommensal florayı yok eder [s.265].",
                    "Yerini metisiline dirençli Staphylococcus aureus (MRSA) ve dirençli Gram-negatif basiller alır.",
                    "Eğer bu dirençli bakterilerle bir endoftalmi gelişirse standart intravitreal antibiyotikler çalışmaz ve göz tamamen körleşir.",
                    "Ayrıca her gün damla damlatmak hastanın gözünü kaşımasına ve iatrojenik kontaminasyona yol açar."
                ],
                "footer": "Dirençli MRSA İndüksiyonu / Dirençli Körlük Riski"
            },
            {
                "card_title": "3. Güncel Standart Uygulama Protokolü",
                "lead": "Sıfır Postop Damla, Sadece Suni Gözyaşı",
                "items": [
                    "Enjeksiyon bittiğinde konjonktiva bol steril BSS ile yıkanarak povidon iyot kalıntısı uzaklaştırılır [s.265].",
                    "Hastaya KESİNLİKLE ANTİBİYOTİKLİ DAMLA REÇETE EDİLMEZ.",
                    "Povidon iyotun oluşturduğu geçici punktat keratit batmasını rahatlatmak için koruyucusuz tek dozluk suni gözyaşı verilir.",
                    "Hastaya ilk 24 saat gözünü ovuşturmaması ve ağrı/görme düşüşü olursa derhal araması tembihlenir."
                ],
                "footer": "Postop Antibiyotik YOKTUR / Koruyucusuz Suni Gözyaşı"
            }
        ]
    )

    # Slayt 9.1.2.3: Akut Postoperatif Endoftalmi: Triad ve Patojenler
    builder.add_study_card_slide(
        title="AKUT POSTOPERATİF ENDOFTALMİ: KLİNİK TRİAD VE AJANLAR",
        category="BÖLÜM 9.1.2: ENDOFTALMİ",
        subtitle="Cerrahi/Enjeksiyon Sonrası Ağrı, Hipopiyon ve Vitrit Triadı; Koagülaz Negatif Stafilokoklar",
        cards=[
            {
                "card_title": "1. Klasik Klinik Belirtiler ve Başvuru",
                "lead": "İlk 3-7 Günde Ortaya Çıkan Tablo",
                "items": [
                    "Şiddetli zonklayıcı göz ağrısı (olguların %75'inde vardır; diyabetiklerde hafif olabilir) [s.265].",
                    "Görme keskinliğinde ani ve derin düşüş (parmak sayma veya el hareketine gerileme).",
                    "Kapak ödemi, konjonktival kemozis, kornea ödemi ve ön kamarada eksüdatif HİPOPYON.",
                    "Fundus detaylarını tamamen silen yoğun vitrit ve kırmızı fundus refleksinin kaybolması."
                ],
                "footer": "Ağrı + Ani Görme Düşüşü + Hipopiyon + Vitrit"
            },
            {
                "card_title": "2. En Sık İzole Edilen Patojenler",
                "lead": "Hastanın Kendi Kapak ve Cilt Florası (%90)",
                "items": [
                    "1. Koagülaz Negatif Stafilokoklar (Staphylococcus epidermidis - %65-70): En sık etkendir; nispeten daha selim seyreder [s.266].",
                    "2. Staphylococcus aureus (%10-15): Daha yıkıcıdır; hızlı fibrin ve kornea nekrozu yapar.",
                    "3. Streptococcus türleri (S. viridans, S. pneumoniae - %10): En kötü görsel prognoza sahip fulminan tiptir.",
                    "4. Gram-negatif Basiller (Pseudomonas aeruginosa, Enterobacter - %5-8): Saatler içinde korneayı eritebilir."
                ],
                "footer": "S. epidermidis (%70 En Sık) / Streptococcus (En Yıkıcı)"
            },
            {
                "card_title": "3. Zamanlama Kuralı",
                "lead": "Akut vs Gecikmiş / Kronik Endoftalmi",
                "items": [
                    "Akut Endoftalmi: Cerrahiden sonraki ilk 1-2 hafta içinde başlar (virülan bakteriler) [s.266].",
                    "Gecikmiş / Kronik Endoftalmi: Cerrahiden haftalar veya aylar sonra başlayan sinsi, steroide geçici yanıt veren formdur.",
                    "Kronik formun 1 numaralı etkeni Cutibacterium (Propionibacterium) acnes ve mantarlardır.",
                    "Arka kapsül üzerinde beyaz plak ve granülomatöz keratik presipitatlar izlenir."
                ],
                "footer": "Akut (İlk 1-2 Hafta) vs Kronik (P. acnes / Aylar Sonra)"
            }
        ]
    )

    # Slayt 9.1.2.4: Endophthalmitis Vitrectomy Study (EVS) Landmark Kriteri
    builder.add_study_card_slide(
        title="ENDOPHTHALMİTİS VİTRECTOMY STUDY (EVS) PROTOKOLÜ",
        category="BÖLÜM 9.1.2: EVS PROTOKOLÜ",
        subtitle="Katarakt ve Enjeksiyon Sonrası Endoftalmide Görme Düzeyine Göre Cerrahi Karar Ağacı",
        cards=[
            {
                "card_title": "1. EVS Çalışmasının Tarihsel Önemi",
                "lead": "Prospektif Randomize Çok Merkezli Landmark RCT",
                "items": [
                    "Katarakt cerrahisi veya sekonder lens implantasyonu sonrası gelişen akut endoftalmileri incelemiştir [s.266].",
                    "İki büyük soruyu yanıtlamıştır:",
                    "1. Acil Pars Plana Vitrektomi mi (PPV) yoksa sadece Parasentez + İntravitreal Antibiyotik mi yapılmalı?",
                    "2. Sistemik intravenöz antibiyotik eklenmeli mi?",
                    "Sonuç: Sistemik İV antibiyotiklerin klinik sonuca hiçbir ek katkı sağlamadığı kanıtlanmıştır."
                ],
                "footer": "Landmark RCT / Sistemik Antibiyotik Faydasız Bulundu"
            },
            {
                "card_title": "2. ALTIN KURAL: Görme Işık Hissi (LP) İse ACİL PPV",
                "lead": "Işık Hissinde Vitrektomi Görmeyi 3 Kat Artırır",
                "items": [
                    "Başvuru anında hastanın görmesi yalnızca IŞIK HİSSİ (Light Perception - LP) düzeyinde ise [s.266]:",
                    "ACİL PARS PLANA VİTREKTOMİ (PPV) ZORUNLUDUR.",
                    "EVS verisi: LP düzeyindeki hastalarda acil vitrektomi yapılan grupta 20/40 (0.5) ve üzeri görme oranı 3 kat daha yüksek çıkmıştır (%33 vs %11).",
                    "Gecikmeden ilk saatlerde ameliyathaneye girilmelidir."
                ],
                "footer": "Görme = Sadece Işık Hissi (LP) -> ACİL PPV ŞARTTIR"
            },
            {
                "card_title": "3. Görme El Hareketi (HM) veya Üzeri İse",
                "lead": "Vitrektomi ile İntravitreal Enjeksiyon Eşit Çıkmıştır",
                "items": [
                    "Başvuru anında hasta EL HAREKETİ (HM), parmak sayma veya daha iyi görüyorsa [s.267]:",
                    "Acil vitrektomi ile poliklinikte yapılan 'Örnekleme + İntravitreal Antibiyotik' arasında nihai görme EŞİT bulunmuştur.",
                    "Bu hastalarda ön kamara/vitreus parasentezi ile kültür alınır ve derhal İntravitreal Vankomisin + Seftazidim verilir.",
                    "Hasta 24-48 saat sonra kontrol edilir; tablo kötüleşirse PPV'ye geçilir."
                ],
                "footer": "Görme ≥ El Hareketi (HM) -> Parasentez + İntravitreal Antibiyotik"
            }
        ]
    )

    # Slayt 9.1.2.5: İntravitreal Antibiyotik Rejimi: Vankomisin ve Seftazidim
    builder.add_split_comparison_slide(
        title="İNTRAVİTREAL ANTİBİYOTİK STANDARDI: VANKOMİSİN + SEFTAZİDİM",
        category="BÖLÜM 9.1.2: ANTİBİYOTİK SEÇİMİ",
        subtitle="Gram-Pozitif ve Gram-Negatif Spektrumu Kusursuz Kapsayan Empirik İkili Rejim",
        left_entity={
            "name": "VANKOMİSİN (1.0 mg / 0.1 ml)",
            "subtitle": "Tüm Gram-Pozitif Bakterilerin Katili",
            "bullets": [
                "Dozaj: 1.0 mg / 0.1 ml steril enjeksiyon [s.267].",
                "Spektrum: S. epidermidis, S. aureus (MRSA dahil), Streptococcus türleri, Enterokoklar.",
                "Etki Mekanizması: Bakteri hücre duvarında peptidoglikan sentezini bloke eder.",
                "Retinal Toksisite: Çok düşüktür; foveaya doğrudan sıkılmadıkça retinotoksisite yapmaz.",
                "Klinik Rol: Endoftalmilerin %85'inden sorumlu Gram-pozitif florayı tek başına temizler [s.267]."
            ]
        },
        right_entity={
            "name": "SEFTAZİDİM (2.25 mg / 0.1 ml)",
            "subtitle": "Gram-Negatif Basiller ve Pseudomonas Katili",
            "bullets": [
                "Dozaj: 2.25 mg / 0.1 ml steril enjeksiyon [s.267].",
                "Spektrum: Pseudomonas aeruginosa, Proteus, Klebsiella, E. coli, Enterobacter.",
                "Eski Ajan (Amikasin) Neden Terk Edildi?: Aminoglikozidler (Amikasin/Gentamisin) konsantrasyona bağlı kalıcı 'makuler infarkt' yapar!",
                "Bu nedenle Seftazidim güvenli profili nedeniyle Amikasin'in yerini almıştır.",
                "Alternatif: Ağır sefalosporin alerjisinde Amikasin (0.4 mg) çok dikkatle verilebilir [s.267]."
            ]
        },
        bottom_takeaway="İntravitreal antibiyotik hazırlarken iki ilaç asla aynı enjektörde karıştırılmaz; iki ayrı 1 ml'lik enjektörle ardışık olarak enjekte edilmelidir [s.267]."
    )

    # Slayt 9.1.2.6: Non-Enfeksiyöz Psödoendoftalmi ve Brolucizumab Vasküliti
    builder.add_study_card_slide(
        title="STERİL ENFLAMASYON: PSÖDOENDOFTALMİ VE BROLUCİZUMAB",
        category="BÖLÜM 9.1.2: AYIRICI TANI",
        subtitle="Steroid Kristal Çökmesi, Toksik Ön Segment Sendromu (TASS) ve Oklüzif Vaskülit",
        cards=[
            {
                "card_title": "1. İntravitreal Steroid Psödoendoftalmisi",
                "lead": "Kristallerin Ön Kamaraya Dökülmesi",
                "items": [
                    "İntravitreal Triamsinolon enjeksiyonundan 24-48 saat sonra ön kamarada beyaz hipopiyon belirir [s.267].",
                    "Göz tamamen AĞRISIZDIR; siliyer enjeksiyon ve kornea ödemi minimaldir.",
                    "Yalancı Hipopiyon: Ön kamaradaki beyaz çökelti lökosit değil, yerçekimiyle çöken triamsinolon kristalleridir.",
                    "Hasta sırtüstü yatırıldığında kristaller açı boyunca dağılır; enfektif endoftalmideki gibi yapışkan fibrin oluşturmaz."
                ],
                "footer": "Ağrısız Beyaz Çökelti / Triamsinolon Kristalleri"
            },
            {
                "card_title": "2. Toksik Ön Segment Sendromu (TASS)",
                "lead": "İlk 12-24 Saatte Gelişen Steril Kimyasal Toksisite",
                "items": [
                    "Katarakt cerrahisinde otoklav kalıntıları, deterjanlar veya steril olmayan solüsyonlar kaynaklıdır [s.268].",
                    "Ameliyattan sonraki ilk 12-24 saatte (çok erken) 'limbusdan limbusa' diffüz kornea ödemi ve hipopiyon başlar.",
                    "Vitreus boşluğu tamamen sakindir (vitrit yoktur; reaksiyon ön kamarayla sınırlıdır).",
                    "Tedavi: Saatlik topikal steroid damlaları ile hızla söner; antibiyotik gerekmez."
                ],
                "footer": "İlk 24 Saat / Kornea Ödemi / Vitreus Temiz / Topikal Steroid"
            },
            {
                "card_title": "3. Brolucizumab İlişkili Retinal Vaskülit (IOI)",
                "lead": "Gecikmiş İmmün Kaynaklı Oklüzif Arterit",
                "items": [
                    "Yeni nesil tek zincirli anti-VEGF Brolucizumab (Beovu) enjeksiyonundan 2-4 hafta sonra ortaya çıkabilir [s.268].",
                    "Tip IV hipersensitivite zemininde şiddetli retinal vaskülit ve retinal arter oklüzyonu gelişir.",
                    "Hastada ağrısız ani görme kaybı, retinal kanamalar ve vasküler kılıflanma izlenir.",
                    "Tedavi: Acil yüksek doz sistemik ve lokal kortikosteroidler; gecikilirse kalıcı körlük oluşur."
                ],
                "footer": "Brolucizumab / Oklüzif Arterit / Acil Yüksek Doz Steroid"
            }
        ]
    )

    # Slayt 9.1.2.7: Endoftalmi Acil Cerrahi ve Karar Ağacı
    builder.add_decision_tree_slide(
        title="AKUT ENDOFTALMİ ACİL YÖNETİM PROTOKOLÜ",
        category="BÖLÜM 9.1.2: KARAR AĞACI",
        subtitle="Cerrahi veya Enjeksiyon Sonrası Hipopiyonla Gelen Hastada EVS Algoritması",
        root_label="POSTOPERATİF HASTADA AĞRI, HİPOPYON VE VİTRİT GELİŞTİ (ENDOFTALMİ)",
        branches=[
            {
                "label": "1. Görme Yalnızca Işık Hissi (LP)",
                "criteria": "El hareketini göremiyor, yalnızca ışığı fark ediyor [s.266].",
                "action": "ACİL PARS PLANA VİTREKTOMİ: Aynı gün ameliyathaneye alınır; 25G PPV + İntravitreal Vankomisin + Seftazidim."
            },
            {
                "label": "2. Görme El Hareketi (HM) veya Daha İyi",
                "criteria": "El hareketlerini, parmakları sayabiliyor [s.267].",
                "action": "Ofis Girişimi: Ön kamara ve vitreus parasentezi (kültür için) + Derhal İntravitreal Vankomisin (1 mg) + Seftazidim (2.25 mg)."
            },
            {
                "label": "3. 48 Saat Sonra Kötüleşen / Yanıtsız Tablo",
                "criteria": "Antibiyotiğe rağmen hipopiyon artıyor, görme ışık hissine geriliyor [s.267].",
                "action": "Kurtarma Vitrektomisi: Vakit kaybetmeden PPV'ye geçilir, vitreus boşluğu yıkanır ve antibiyotik tekrarlanır."
            }
        ],
        bottom_rule="EVS protokolüne göre görmesi el hareketi veya daha iyi olan hastayı gece yarısı alelacele vitrektomiye almak gereksizdir; intravitreal antibiyotik enjeksiyonu eşit başarı sağlar [s.266]."
    )

    # Slayt 9.1.2.8: Aktif Hatırlama & Board Sınavı Vakası: 4. Günde Hipopiyon ve EVS
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: POSTOP ENDOFTALMİ",
        category="BÖLÜM 9.1.2: AKTİF HATIRLAMA",
        subtitle="Katarakt Cerrahisinden 4 Gün Sonra Şiddetli Ağrı, Hipopiyon ve Parmak Sayma Düzeyinde Görme",
        vignette="68 yaşında erkek hasta, sağ gözünden 4 gün önce komplikesiz fakoemülsifikasyon ve arka kamara göz içi lens implantasyonu ameliyatı geçirmiştir. Dün akşam başlayan ve sabaha kadar giderek şiddetlenen göz ağrısı, kızarıklık ve görmede ani kararma şikayetiyle saat 09:00'da acil polikliniğe başvuruyor. Sağ görme keskinliği 1 metreden parmak sayma düzeyindedir (el hareketi ve ışık hissinden daha iyidir). Biyomikroskopide sağ konjonktivada yoğun kemozis, kornea alt yarısında hafif ödem, ön kamarada 2 mm seviyesinde fibrinöz hipopiyon ve 4+ yoğun hücresel reaksiyon izleniyor. İntraoküler lens santralde duruyor. Arka segment muayenesinde kırmızı refle tamamen kaybolmuş, fundus detayları yoğun vitrit nedeniyle seçilemiyor. B-Scan USG'de vitreus boşluğunda diffüz ekojenik hücre kümeleri izleniyor; retina yatışık.",
        differentials=[
            "Akut Postoperatif Bakteriyel Endoftalmi (4. günde başlama, şiddetli ağrı, hipopiyon, yoğun vitrit ve parmak sayma görme).",
            "Toksik Ön Segment Sendromu (TASS - İlk 24 saatte başlar, ağrı hafiftir, kornea limbusdan limbusa ödemlidir ve vitrit yoktur).",
            "Steroid Kristal Çökmesi (Katarakt ameliyatında intrakameral triamsinolon verilmediyse görülmez).",
            "Şiddetli İridosiklit / Fibrin Reaksiyonu (Vitrit eşlik etmez, kırmızı refle kaybolmaz)."
        ],
        decision="1. Klinik Teşhis: Akut Postoperatif Bakteriyel Endoftalmi (Büyük olasılıkla S. epidermidis veya S. aureus).\n2. EVS Kriterine Göre Cerrahi Karar: Hastanın görme keskinliği '1 metreden parmak sayma' düzeyindedir (El hareketinden daha iyidir). EVS kurallarına göre acil vitrektomi endikasyonu yoktur; ofis şartlarında 'Musluk/Biyopsi ve Antibiyotik Enjeksiyonu' endikedir.\n3. Acil Eylem: %5 Povidon iyot damlatılır; 25G iğne ile ön kamara ve vitreustan mikrobiyolojik kültür (Gram boyama, kanlı/çikolata agar) için 0.1 ml sıvı aspire edilir.\n4. İntravitreal Antibiyotik: Beklemeden iki ayrı enjektörle İntravitreal Vankomisin (1.0 mg/0.1 ml) ve İntravitreal Seftazidim (2.25 mg/0.1 ml) enjekte edilir; hasta 24 saat sonra kontrole çağrılır.",
        board_trap="Bu hastada 'endoftalmi var, hemen vitrektomiye almalıyız' demek EVS landmark kriterlerine göre hatalıdır; görmesi el hareketi veya daha iyi olan hastalarda acil vitrektomi yapmanın antibiyotik enjeksiyonuna hiçbir üstünlüğü yoktur [s.266]."
    )

    # =========================================================================
    # 9.2.1: YAPAY ZEKA VE TÜRKİYE ASM TRİYAJ PERSPEKTİFİ (7 Slayt)
    # =========================================================================

    # Slayt 9.2.1.1: Derin Öğrenme ile Fundus Analizi: IDx-DR ve EyeArt
    builder.add_study_card_slide(
        title="DERİN ÖĞRENME İLE OTONOM RETİNA ANALİZİ",
        category="BÖLÜM 9.2.1: YAPAY ZEKA",
        subtitle="Evrişimli Sinir Ağları (CNN), FDA Onaylı Otonom Cihazlar (IDx-DR, EyeArt) ve Tanı Performansı",
        cards=[
            {
                "card_title": "1. Evrişimli Sinir Ağları (CNN) Mimarisi",
                "lead": "Piksel Düzeyinde Lezyon Segmentasyonu",
                "items": [
                    "ResNet, EfficientNet ve Vision Transformer (ViT) mimarileri yüzbinlerce etiketli fundus fotoğrafıyla eğitilmiştir [s.268].",
                    "Mikroanevrizmalar, intraretinal kanamalar, sert eksüdalar ve pamuk atığı odakları milimetrik segmente edilir.",
                    "Sadece lezyon tespiti değil; foveaya olan mesafe hesaplanarak klinik anlamlı makula ödemi (CSME) riski skorlanır.",
                    "Görüntü kalite kontrolü (Image quality check) algoritması çekilen fotoğrafın okunabilirliğini otomatik doğrular."
                ],
                "footer": "CNN / Vision Transformer / Otomatik Kalite Kontrolü"
            },
            {
                "card_title": "2. FDA Onaylı Otonom Sistemler (IDx-DR / EyeArt)",
                "lead": "Doktor Onayına İhtiyaç Duymayan Otonom Karar",
                "items": [
                    "IDx-DR: 2018 yılında FDA'dan onay alan ilk 'tam otonom' tıbbi yapay zeka sistemidir [s.268].",
                    "Göz hekimi veya radyolog olmaksızın, birinci basamakta çekilen fundus fotoğrafını 20 saniyede analiz eder.",
                    "Klinik Karar Çıktısı ikilidir: 1. 'Sevk edilebilir DR saptandı (Göz hekimine sevk et)', 2. 'Sevk edilebilir DR yok (1 yıl sonra tekrar tara)'.",
                    "EyeArt Sistemi: Benzer şekilde >%95 duyarlılık ve >%90 özgüllükle FDA ve CE onayı almıştır."
                ],
                "footer": "IDx-DR / EyeArt / Doktor Onaysız Otonom Tanı"
            },
            {
                "card_title": "3. Tanı Doğruluğu ve Güvenlik Sınırları",
                "lead": "Landmark Klinik Doğrulama Sonuçları",
                "items": [
                    "Büyük çok merkezli klinik deneylerde duyarlılık (sensitivity) %87 - 96 arasında kanıtlanmıştır [s.269].",
                    "Özgüllük (specificity) %90 - 94 düzeyindedir; yanlış sevk oranları tolere edilebilir sınırlardadır.",
                    "Sistemler orta dereceli NPDR, şiddetli NPDR, PDR ve makula ödemini kaçırmayacak şekilde kalibre edilmiştir.",
                    "En büyük sınırlılık: Medya opasitesi (katarakt, kornea lekesi) varlığında sistem 'yetersiz görüntü kalitesi' vererek sevk eder."
                ],
                "footer": "Duyarlılık >%90 / Özgüllük >%90 / Güvenilir Kalibrasyon"
            }
        ]
    )

    # Slayt 9.2.1.2: Türkiye Birinci Basamak Sağlık Gerçekleri: ASM Triyajı
    builder.add_study_card_slide(
        title="TÜRKİYE SAĞLIK SİSTEMİNDE BİRİNCİ BASAMAK (ASM) TRİYAJI",
        category="BÖLÜM 9.2.1: YEREL SAĞLIK PRATİĞİ",
        subtitle="Aile Sağlığı Merkezlerinde (ASM) Taşınabilir Non-Midriyatik Kamera ve Yapay Zeka Entegrasyonu",
        cards=[
            {
                "card_title": "1. Türkiye Diyabet Epidemiyolojisi ve Yükü",
                "lead": "10 Milyona Yaklaşan Diyabet Popülasyonu",
                "items": [
                    "Türkiye, TURDEP-II verilerine göre Avrupa'da diyabet prevalansı en yüksek ülkedir (%13.7) [s.269].",
                    "Yaklaşık 9-10 milyon diyabet hastasının yıllık retina taraması mevcut 5000 oftalmolog ile fiziken İMKANSIZDIR.",
                    "Hastaların %60'tan fazlası hiçbir zaman göz dibi muayenesine gitmemekte ve körlük evresinde başvurmaktadır.",
                    "Çözüm: Taramayı hastaneden çıkarıp hastanın ayağına, yani Aile Sağlığı Merkezine (ASM) indirmektir."
                ],
                "footer": "TURDEP-II (%13.7 Diyabet) / Yıllık Tarama Yetersizliği"
            },
            {
                "card_title": "2. ASM Düzeyinde Taşınabilir Kamera Çözümü",
                "lead": "Damlaya İhtiyaç Duymayan Non-Midriyatik Teknoloji",
                "items": [
                    "Aile hekimliklerine yerleştirilecek kompakt, el tipi veya masaüstü non-midriyatik fundus kameraları [s.269].",
                    "Pupilla dilatasyonuna (damlaya) gerek kalmadan, karanlık odada 45 derecelik makula ve disk fotoğrafı çekilir.",
                    "Fotoğraf çekimi aile sağlığı elemanı (hemşire/ebe) tarafından 1 dakikada tamamlanır.",
                    "Hasta damla damlatılmadığı için günlük işine ve araç kullanımına hemen devam edebilir."
                ],
                "footer": "Non-Midriyatik / Damlasız Çekim / 1 Dakikada Sonuç"
            },
            {
                "card_title": "3. Yapay Zekanın Triyaj Gücü",
                "lead": "Temiz Olguların ASM'de Kalması",
                "items": [
                    "Çekilen fundus fotoğrafı cihazdaki yerel YZ yazılımı tarafından 15 saniyede analiz edilir [s.270].",
                    "Retinası temiz çıkan (%70-80 hasta) hastaneye boş yere gönderilmez; 1 yıl sonra ASM'ye kontrole çağrılır.",
                    "Sadece 'Sevk Edilebilir DR veya Makula Ödemi' saptanan hastaya otomatik olarak 2. ve 3. basamak randevusu açılır.",
                    "Böylece hastanelerdeki yığılma önlenir; hekim zamanını gerçekten tedaviye muhtaç hastalara ayırır."
                ],
                "footer": "%75 Gereksiz Sevk Engellenir / Hedefe Yönelik Randevu"
            }
        ]
    )

    # Slayt 9.2.1.3: Sağlık Bakanlığı Teletıp ve SGK / SUT Geri Ödeme Dinamikleri
    builder.add_study_card_slide(
        title="SAĞLIK BAKANLIĞI TELETIP VE SGK / SUT MALİYET ANALİZİ",
        category="BÖLÜM 9.2.1: TELETIP & EKONOMİ",
        subtitle="Merkezi Teletıp Bulutu, 3. Basamak Sevk Yükünün Azaltılması ve SGK Bütçe Tasarrufu",
        cards=[
            {
                "card_title": "1. Sağlık Bakanlığı Teletıp Sistemi Entegrasyonu",
                "lead": "Ulusal e-Nabız ve Teletıp Havuzu",
                "items": [
                    "Türkiye Sağlık Bakanlığı Teletıp ve Teleradyoloji sistemi dünyadaki en büyük merkezi görüntüleme ağlarındandır [s.270].",
                    "ASM'lerde çekilen tüm fundus fotoğrafları DICOM formatında doğrudan merkezi teletıp bulutuna aktarılır.",
                    "Yapay zeka analiz sonucu doğrudan hastanın e-Nabız profiline ve aile hekiminin AHBS ekranına düşer.",
                    "Şüpheli veya sınırda olgular referans eğitim araştırma hastanelerindeki retina uzmanları tarafından uzaktan onaylanır."
                ],
                "footer": "Merkezi Teletıp / DICOM Entegrasyonu / e-Nabız Raporu"
            },
            {
                "card_title": "2. Üçüncü Basamak Sevk Yükünün %70 Azaltılması",
                "lead": "Üniversite ve Şehir Hastanelerinin Rahatlaması",
                "items": [
                    "Mevcut sistemde retina polikliniklerine başvuran hastaların çoğunluğu erken/hafif evrede rutin kontrole gelenlerdir [s.270].",
                    "YZ tabanlı birinci basamak triyajı sayesinde hastane sevk yükü %65-75 oranında azalır.",
                    "Üçüncü basamak merkezler gereksiz tarama yükünden kurtularak vitrektomi, dekolman ve enjeksiyonlara odaklanır.",
                    "Periferden büyük şehirlere gereksiz hasta göçü ve sevk maliyetleri engellenir."
                ],
                "footer": "Sevk Yükünde %70 Azalma / Nitelikli Hizmete Odaklanma"
            },
            {
                "card_title": "3. SGK ve SUT Ekonomik Boyutu",
                "lead": "İleri Evre Cerrahilerin Önlenmesiyle Masif Tasarruf",
                "items": [
                    "Sosyal Güvenlik Kurumu (SGK) için geç evrede gelen bir PDR hastasının vitrektomi, gaz/silikon ve anti-VEGF maliyeti devasadır [s.271].",
                    "Ayrıca kalıcı körlük sonucu ödenen maluliyet maaşları ve iş gücü kaybı ekonomiyi ağır sarsar.",
                    "Sağlık Uygulama Tebliği'ne (SUT) 'Yapay Zeka Destekli Fundus Tarama' kodu eklenmesi sistemik tasarruf sağlar.",
                    "Erken evrede yakalanıp lazerle veya tek dozla kurtarılan her göz, devlete yüz binlerce TL doğrudan tasarruf ettirir."
                ],
                "footer": "SUT Kodu / Vitrektomi Maliyetinin Önlenmesi / Yüksek Tasarruf"
            }
        ]
    )

    # Slayt 9.2.1.4: Yapay Zeka vs Uzman Oftalmolog Karşılaştırması
    builder.add_split_comparison_slide(
        title="DİYAGNOSTİK KARŞILAŞTIRMA: YAPAY ZEKA vs RETİNA UZMANI",
        category="BÖLÜM 9.2.1: KARŞILAŞTIRMA",
        subtitle="Otonom Algoritmaların Güçlü Yönleri ve İnsan Hekimin Vazgeçilmez Klinik Muhakemesi",
        left_entity={
            "name": "OTONOM YAPAY ZEKA SİSTEMLERİ",
            "subtitle": "Hız, Standartlık ve Birinci Basamak Tarama Gücü",
            "bullets": [
                "Hız: 15-20 saniyede tam retinal segmentasyon ve sınıflandırma [s.268].",
                "Yorulmazlık: Milyonlarca hastayı dikkat dağınıklığı ve yorgunluk olmadan aynı standartta tarar.",
                "Erişilebilirlik: Uzman doktorun bulunmadığı kırsal ASM'lere ve ilçelere uzmanlık standardı taşır.",
                "Sınırlılık: Sadece eğitildiği hastalığı (örn. DR) tanır; tesadüfi kitle veya periferik yırtığı atlayabilir.",
                "Mediko-Legal: Otonom sistemlerin hukuki sorumluluğu henüz netleşmemiştir [s.269]."
            ]
        },
        right_entity={
            "name": "UZMAN RETİNA HEKİMİ",
            "subtitle": "Klinik Muhakeme, Biyomikroskopi ve Tedavi Kararı",
            "bullets": [
                "Bütüncül Yaklaşım: Hastanın tansiyonunu, böbrek fonksiyonunu, sistemik durumunu birlikte sentezler.",
                "Multimodal Hakimiyet: OKT, FFA, ICG ve ultrasonografi bulgularını eşzamanlı yorumlar.",
                "Cerrahi ve Girişim: Lazer parametrelerini ayarlar, enjeksiyon yapar, vitrektomi cerrahisini icra eder.",
                "Klinik Empati: Hasta ile iletişim kurar, uyumu artırır ve cerrahi komplikasyonları yönetir.",
                "Sonuç: Yapay zeka doktorun rakibi değil; birinci basamakta doktorun en büyük triyaj yardımcısıdır [s.271]."
            ]
        },
        bottom_takeaway="Yapay zeka göz hekiminin yerini almayacak; ancak yapay zekayı kullanan ve birinci basamağa entegre eden hekimler ve sağlık sistemleri diğerlerinin önüne geçecektir [s.271]."
    )

    # Slayt 9.2.1.5: YZ Tabanlı Diyabetik Retinopati Tarama Algoritması
    builder.add_horizontal_flowchart_slide(
        title="TÜRKİYE BİRİNCİ BASAMAK (ASM) YZ TARAMA ALGORİTMASI",
        category="BÖLÜM 9.2.1: AKIŞ ŞEMASI",
        subtitle="Aile Hekimliğinde Başlayıp 3. Basamak Göz Kliniğine Ulaşan Entegre Triyaj Akışı",
        steps=[
            {
                "num": "1",
                "title": "ASM'de Non-Midriyatik Çekim",
                "desc": "Diyabet hastasının pupillası büyütülmeden 45° makula ve optik disk fundus fotoğrafı çekilir [s.269].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Otonom YZ Analizi (20 Saniye)",
                "desc": "Yazılım görüntüyü analiz eder; 'Sevk Edilebilir DR / Makula Ödemi Var mı?' sorusunu yanıtlar.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Otomatik e-Nabız / Teletıp Entegrasyonu",
                "desc": "DR negatifse 1 yıl sonra ASM kontrolü; DR pozitifse doğrudan hastaneye yeşil alan randevusu açılır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Üçüncü Basamakta Erken Tedavi",
                "desc": "Göz kliniğine erken evrede ulaşan hastaya lazer veya anti-VEGF uygulanarak körlük engellenir [s.270].",
                "status": "success"
            }
        ],
        bottom_takeaway="ASM triyajı sayesinde hastalar proliferatif dekolman veya neovasküler glokomla değil, tedavi edilebilir erken evrede göz polikliniğine ulaştırılır [s.270]."
    )

    # Slayt 9.2.1.6: Teleoftalmolojide Kalite Kontrol ve Yasal Sorumluluk
    builder.add_study_card_slide(
        title="TELEOFTALMOLOJİDE KALİTE KONTROL VE HUKUKİ STANDARTLAR",
        category="BÖLÜM 9.2.1: MEDİKO-LEGAL",
        subtitle="Görüntü Kalite Eşikleri, KVKK/GDPR Uyumlu Veri Güvenliği ve Malpraktis Sınırları",
        cards=[
            {
                "card_title": "1. Otomatik Kalite Değerlendirmesi (Quality Filter)",
                "lead": "Yetersiz Görüntüye Asla 'Normal' Denemez",
                "items": [
                    "Katarakt, kornea bulanıklığı veya küçük pupil nedeniyle fovea ve damarlar net seçilemeyebilir [s.271].",
                    "YZ algoritması görüntünün aydınlanma, odak ve kontrast parametrelerini test eder.",
                    "Kalite eşiğini geçemeyen görüntülerde sistem asla 'retina sağlıklıdır' demez; 'Yetersiz Görüntü Kalitesi' çıktısı verir.",
                    "Bu hastalar doğrudan bir oftalmolog tarafından biyomikroskopi ile muayene edilmek üzere sevk edilir."
                ],
                "footer": "Kalite Filtresi / Yetersiz Görüntü = Otomatik Sevk"
            },
            {
                "card_title": "2. Veri Güvenliği ve KVKK Standartları",
                "lead": "Biyometrik Sağlık Verisinin Korunması",
                "items": [
                    "Retina damar paterni parmak izi gibi kişiye özel biyometrik bir tanımlayıcıdır [s.271].",
                    "Fundus fotoğrafları çekildiği anda hasta kimlik bilgileri anonimleştirilerek şifrelenir (pseudonymization).",
                    "Görüntüler Türkiye sınırları içindeki Sağlık Bakanlığı güvenli sunucularında (KVKK uyumlu) saklanır.",
                    "Yurtdışı sunuculara veya izinsiz ticari bulutlara hasta verisi aktarımı kesinlikle yasaktır."
                ],
                "footer": "KVKK Uyumu / Anonimleştirme / Yerli Sunucu Güvencesi"
            },
            {
                "card_title": "3. Hukuki ve Malpraktis Sorumluluğu",
                "lead": "Karar Destek Sistemi vs Otonom Cihaz Sorumluluğu",
                "items": [
                    "Türk Hukukunda nihai tıbbi teşhis ve sevk sorumluluğu halen hekimdedir [s.271].",
                    "Karar Destek Sistemi (CDSS) formatında yapay zeka aile hekimine öneri sunar; aile hekimi kararı onaylar.",
                    "Otonom sistemlerde ise üretici firma FDA/Sağlık Bakanlığı onaylı algoritmik hata oranlarını garanti eder.",
                    "Hekim ve sağlık personeli çekim protokollerine ve cihaz kalibrasyon standartlarına uymakla yükümlüdür."
                ],
                "footer": "Hekim Onayı / Üretici Sorumluluğu / Protokol Güvencesi"
            }
        ]
    )

    # Slayt 9.2.1.7: Aktif Hatırlama & Board Sınavı Vakası: Kırsal ASM'de YZ Triyajı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: ASM YZ TRİYAJI",
        category="BÖLÜM 9.2.1: AKTİF HATIRLAMA",
        subtitle="58 Yaşında Asemptomatik Diyabetik Köy Sakininde ASM Non-Midriyatik Kamerasında Saptanan PDR",
        vignette="58 yaşında tip 2 diyabet hastası erkek çiftçi, kırsal bir ilçedeki Aile Sağlığı Merkezine (ASM) rutin ilaç yazdırmak için başvuruyor. Hastanın görmeyle ilgili hiçbir şikayeti yoktur (görme 1.0 tam). Hasta 12 yıldır diyabeti olmasına rağmen son 4 yıldır hiç göz doktoruna gitmemiştir. ASM'deki pilot proje kapsamında aile sağlığı çalışanı tarafından taşınabilir non-midriyatik fundus kamerası ile 1 dakikada sağ ve sol göz fundus fotoğrafları çekiliyor. Cihaza entegre otonom yapay zeka yazılımı 15 saniye içinde sol gözde: 'Yüksek Riskli Sevk Edilebilir Diyabetik Retinopati (Olası PDR) ve Foveal Eksüda Saptandı' uyarısı vererek kırmızı alarm oluşturuyor. Fotoğraf incelendiğinde optik disk kenarında 1/3 DD boyutunda ince neovaskülarizasyon yumağı (NVD) ve üst temporal arkatta sert eksüdalar izleniyor.",
        differentials=[
            "Yüksek Riskli Proliferatif Diyabetik Retinopati (Optik diskte NVD, görme tam olsa da masif kanama riski kapıda).",
            "Hafif Non-Proliferatif Diyabetik Retinopati (Sadece birkaç mikroanevrizma bulunur; NVD içermez).",
            "Normal Retina (Hastanın görmesi 1.0 olsa dahi fundusta aktif NVD vardır; normal kabul edilemez).",
            "Santral Retinal Ven Dal Tıkanıklığı (Alev kanamaları ve venöz genişleme ön plandadır)."
        ],
        decision="1. Triyaj Kararı: Hasta görmesi 1.0 tam olmasına rağmen yüksek riskli PDR taşımaktadır; haftalar içinde masif vitreus kanamasıyla kör kalabilir.\n2. Sağlık Bakanlığı Entegrasyonu: Aile hekimi sistemi üzerinden Sağlık Bakanlığı Merkezi Randevu Sistemine (MHRS) 'Yeşil Liste' üzerinden doğrudan 3. basamak Şehir Hastanesi Retina Polikliniğine 3 gün içinde acil randevu oluşturulur.\n3. Hastanedeki Tedavi: Retina kliniğinde çekilen FFA ile diskteki aktif NVD doğrulanır ve hastaya derhal Panretinal Lazer Fotokoagülasyon (PRP) + İntravitreal Anti-VEGF uygulanır.\n4. Sonuç: Birinci basamak YZ taraması olmasaydı hasta gözü kanayıp körleştiğinde gelecekti; erken triyaj gözü kurtarmıştır.",
        board_trap="Hastanın görme keskinliği 1.0 tam diye 'gözünüzde bir şey yok, şikayetiniz olunca gidersiniz' demek hastayı vitreus kanamasına ve traksiyonel dekolmana mahkum etmektir; PDR erken evrede 1.0 görmeyle sinsice seyreder [s.269]."
    )

    # =========================================================================
    # 9.2.2: KÖK HÜCRE VE RETİNAL PROTEZLER (BİYONİK GÖZ) (7 Slayt)
    # =========================================================================

    # Slayt 9.2.2.1: Kök Hücre Teknolojileri: iPSC ve ESC
    builder.add_study_card_slide(
        title="RETİNADA KÖK HÜCRE BİYOLOJİSİ: iPSC VE ESC",
        category="BÖLÜM 9.2.2: KÖK HÜCRE",
        subtitle="Uyarılmış Pluripotent Kök Hücreler (iPSC), Embriyonik Kök Hücreler ve RPE Diferansiasyonu",
        cards=[
            {
                "card_title": "1. Hücre Kaynakları: iPSC vs ESC",
                "lead": "Yamanaka Faktörleri ile Hücre Yeniden Programlama",
                "items": [
                    "Uyarılmış Pluripotent Kök Hücreler (iPSC): Hastanın kendi cilt biyopsisinden veya kan hücrelerinden üretilir [s.272].",
                    "Dört transkripsiyon faktörü (Oct3/4, Sox2, Klf4, c-Myc) ile somatik hücreler embriyonik pluripotent aşamaya döndürülür.",
                    "Otojenik (hastanın kendi hücresi) olduğu için immün ret riski SIFIRDIR; immünsüpresyon gerektirmez.",
                    "Embriyonik Kök Hücreler (ESC): Erken blastokist evresinden elde edilir; allojeneiktir ve immün baskılama gerektirir."
                ],
                "footer": "iPSC (Hastanın Kendi Hücresi) vs ESC (Embriyonik)"
            },
            {
                "card_title": "2. RPE Hücrelerine Yönlendirilmiş Diferansiasyon",
                "lead": "Fonksiyonel Pigment Epiteli Üretimi",
                "items": [
                    "Kök hücreler laboratuvarda spesifik sinyal molekülleriyle (Wnt, Nodal inhibitörleri) retina nöroektodermine yönlendirilir [s.272].",
                    "Hücreler hekzagonal morfoloji kazanır, melanin granülleri üretir ve RPE65/BEST1 eksprese eder.",
                    "En kritik fonksiyon testi: İzole edilen fotoreseptör dış segmentlerini fagosite edebilme yeteneğidir.",
                    "Polarize tek tabaka oluşturan RPE hücreleri subretinal nakil için hazır hale getirilir."
                ],
                "footer": "Hekzagonal Epitel / Fagositoz Yeteneği / RPE65 Ekspresyonu"
            },
            {
                "card_title": "3. Tümörogenez ve Güvenlik Sınırları",
                "lead": "Teratom Oluşum Riskinin Elenmesi",
                "items": [
                    "Pluripotent hücrelerin en büyük tehlikesi farklılaşmamış hücrelerin kontrolsüz çoğalarak teratom yapmasıdır [s.273].",
                    "Klinik nakil öncesinde hücre süspansiyonundaki tüm pluripotent kalıntılar özel manyetik antikorlarla (FACS) temizlenir.",
                    "Genomik stabilite ve proto-onkogen mutasyonları tam genom dizileme ile taranır.",
                    "Masayo Takahashi'nin öncü Japon ekibi ilk insan otojenik iPSC-RPE naklini başarıyla gerçekleştirmiştir."
                ],
                "footer": "Teratom Riski / Saflaştırma / Takahashi Öncü Klinik Deneyi"
            }
        ]
    )

    # Slayt 9.2.2.2: RPE Hücre Süspansiyonu ve Biyomühendislik Yamaları
    builder.add_study_card_slide(
        title="SUBRETİNAL NAKİL TEKNİKLERİ: SÜSPANSİYON vs YAMA",
        category="BÖLÜM 9.2.2: DOKU MÜHENDİSLİĞİ",
        subtitle="Serbest Sıvı Enjeksiyonu vs Sentetik Biyo-Bozunur İskele Üzerinde RPE Monolayer Tabakası",
        cards=[
            {
                "card_title": "1. Serbest Hücre Süspansiyonu Enjeksiyonu",
                "lead": "Kanül ile Sıvı Hücre Dağıtımı",
                "items": [
                    "Farklılaştırılmış RPE hücreleri tek tek serbest hücre süspansiyonu halinde 38G kanülle enjekte edilir [s.273].",
                    "Uygulaması kolaydır; küçük bir sklerotomi deliğinden subretinal alana verilir.",
                    "Dezavantajı: Hücrelerin çoğu yapışamaz ve apoptoza gider; serbest hücreler vitreusa kaçarak PVR yapabilir.",
                    "RPE hücreleri düzgün tek sıra dizilim (monolayer) oluşturmakta zorlanır."
                ],
                "footer": "Kolay Uygulama / PVR Riski / Hücre Ölümü"
            },
            {
                "card_title": "2. Biyomühendislik RPE Yamaları (Patch)",
                "lead": "Önceden Organize Edilmiş Fonksiyonel Tabaka",
                "items": [
                    "RPE hücreleri biyouyumlu sentetik bir membran (Parylene, PLGA veya amniyon zarı) üzerine tek sıra dizilir [s.273].",
                    "Hücreler arasında sıkı bağlantılar (tight junctions / zonula occludens) ve apikal mikrovilluslar kurulur.",
                    "Cerrahi: Özel mikrocerrahi enjektörü ile koğrafi atrofi sahasına bir 'halı' gibi serilir.",
                    "Hücreler önceden polarize olduğu için fotoreseptörleri hemen beslemeye ve fagositoza başlar."
                ],
                "footer": "Sentetik İskele / Polarize Monolayer / Anında Fonksiyon"
            },
            {
                "card_title": "3. Klinik Endikasyonlar: GA ve Stargardt",
                "lead": "Kuru YBMD Coğrafi Atrofisi ve Makuler Distrofi",
                "items": [
                    "İleri evre kuru YBMD'deki santral coğrafi atrofi (GA) adacıklarının altına nakledilir [s.274].",
                    "Stargardt hastalığında toksik A2E ile ölmüş RPE tabakasını sağlıklı genç hücrelerle değiştirmeyi hedefler.",
                    "Faz 1/2 klinik çalışmalarda lezyon büyüme hızının durduğu ve bazı olgularda görmede sıra artışı bildirildi.",
                    "Hücre nakli gelecekte coğrafi atrofinin tek biyolojik kür adayıdır."
                ],
                "footer": "Coğrafi Atrofi (GA) / Stargardt / Faz 1-2 Çalışmaları"
            }
        ]
    )

    # Slayt 9.2.2.3: Biyonik Retina ve Retinal Protezler: Argus II ve PRIMA
    builder.add_study_card_slide(
        title="BİYONİK GÖZ VE RETİNAL PROTEZLER: ARGUS II VE PRIMA",
        category="BÖLÜM 9.2.2: BİYONİK RETİNA",
        subtitle="Fotoreseptörsüz Terminal Körlükte Elektriksel Uyarım: Epiretinal vs Fotovoltaik Subretinal Çip",
        cards=[
            {
                "card_title": "1. Epiretinal Protez: Argus II Sistemi",
                "lead": "İlk FDA ve CE Onaylı Biyonik Göz İmplantı",
                "items": [
                    "Retina iç yüzeyine (gangliyon hücreleri üzerine) 60 elektrotlu esnek bir dizi çivilerle sabitlenir [s.274].",
                    "Gözlükteki mini kamera görüntüyü yakalar; harici işlemci görüntüyü radyo frekans sinyallerine çevirir.",
                    "Gözün sklerasına yerleştirilen alıcı bobin elektrotları tetikleyerek doğrudan gangliyon hücrelerini uyarır.",
                    "Hastalar ışık pikselleri (fosfenler) algılayarak kapı, pencere, beyaz çizgi ve büyük harfleri ayırt edebilir."
                ],
                "footer": "Argus II / 60 Elektrot / Epiretinal Sabitleme / Fosfen Görmesi"
            },
            {
                "card_title": "2. Yeni Nesil Fotovoltaik Protez: PRIMA Sistemi",
                "lead": "Kablosuz ve Yüksek Çözünürlüklü Subretinal Çip",
                "items": [
                    "Yalnızca 2 mm boyutunda, 378 adet bağımsız fotovoltaik piksel içeren mikroskobik kablosuz çiptir [s.275].",
                    "Pars plana vitrektomi ile doğrudan ölmüş fotoreseptörlerin yerine, subretinal aralığa kaydırılır.",
                    "Gözlükteki kızılötesi (IR) lazer projektörü çipi hem kablosuz olarak besler (güç) hem de görüntüyü optik iletir.",
                    "Doğrudan bipolar hücreleri uyardığı için retinanın doğal fizyolojik sinir işleme devrelerini kullanır."
                ],
                "footer": "PRIMA Çipi / 378 Fotovoltaik Piksel / Subretinal / Bipolar Uyarım"
            },
            {
                "card_title": "3. Klinik Görsel Başarı: Harf Okuma",
                "lead": "Kör Hastaların Yeniden Okuyabilmesi",
                "items": [
                    "PRIMA klinik fazlarında kuru YBMD coğrafi atrofili terminal hastalar harfleri ve kelimeleri okuyabilmiştir [s.275].",
                    "Optik büyütme desteğiyle hastaların görme keskinliği 20/400 düzeyine kadar restore edilmiştir.",
                    "Elektrik kabloları veya skleral bobinler gerektirmediği için cerrahi komplikasyon riski son derece düşüktür.",
                    "Retinal protezler optik siniri sağlam olan her terminal fotoreseptör körlüğünde umut ışığıdır."
                ],
                "footer": "Harf ve Kelime Okuma / Kablosuz Güvenlik / 20/400 Görme"
            }
        ]
    )

    # Slayt 9.2.2.4: Hücresel Restorasyon vs Biyonik Protez Karşılaştırması
    builder.add_split_comparison_slide(
        title="TERMİNAL RETİNA RESTORASYONU: KÖK HÜCRE vs BİYONİK ÇİP",
        category="BÖLÜM 9.2.2: KARŞILAŞTIRMA",
        subtitle="Biyolojik Hücre Replasmanı (iPSC) vs Nöromorfik Elektronik İmplant (PRIMA)",
        left_entity={
            "name": "KÖK HÜCRE TEDAVİSİ (iPSC / RPE)",
            "subtitle": "Biyolojik ve Hücresel Yenilenme",
            "bullets": [
                "Hedef: Hasarlı veya ölmüş RPE ve fotoreseptörleri canlı biyolojik hücrelerle yenilemek [s.272].",
                "Görsel Potansiyel: Eğer fotoreseptör sinapsları kurulabilirse doğal ve yüksek çözünürlüklü görme potansiyeli taşır.",
                "Uygulama Zamanı: Erken veya orta evre; henüz tüm nöronal katmanlar yok olmadan önce idealdir.",
                "Riskler: İmmün ret (allojeneikte), teratom riski, kontrolsüz proliferasyon veya PVR.",
                "Mevcut Durum: Faz 1/2 klinik deneyler; fonksiyonel görme artışı henüz sınırlı düzeydedir [s.273]."
            ]
        },
        right_entity={
            "name": "BİYONİK RETİNAL PROTEZ (PRIMA / ARGUS)",
            "subtitle": "Mühendislik ve Nöromorfik Elektronik Çözüm",
            "bullets": [
                "Hedef: Fotoreseptörleri tamamen yok olmuş göze yapay elektriksel fototransdüksiyon kazandırmak [s.274].",
                "Görsel Potansiyel: Pikselli fosfen görmesi; siyah-beyaz yüksek kontrastlı formları ve harfleri ayırt etme.",
                "Uygulama Zamanı: Son evre (terminal) körlük; hastada hiç ışık hissi veya fotoreseptör kalmadığında.",
                "Riskler: Çip yer değiştirmesi, korozyon, epiretinal fibrozis veya implant reddi.",
                "Mevcut Durum: FDA/CE onayları mevcut; klinik olarak harf okuma başarısı kanıtlanmıştır [s.275]."
            ]
        },
        bottom_takeaway="Kök hücre henüz yaşayan nöronları kurtarmayı hedeflerken, biyonik çipler tüm biyolojik fotoreseptörleri tamamen ölmüş son evre kör hastalara yapay görme sağlar [s.274]."
    )

    # Slayt 9.2.2.5: Devam Eden Biyomühendislik Klinik Fazları ve Landmarklar
    builder.add_trials_kpi_slide(
        title="BİYOMÜHENDİSLİK VE REJENERATİF RETİNA LANDMARK VERİLERİ",
        category="BÖLÜM 9.2.2: KANIT DÜZEYİ",
        subtitle="iPSC Faz Çalışmaları, PRIMA Çip Sonuçları ve Retinal Nöroproteksiyon",
        kpis=[
            {"val": "20/400", "label": "PRIMA Çipi ile Elde Edilen Görme"},
            {"val": "378", "label": "PRIMA Fotovoltaik Piksel Sayısı"},
            {"val": "%100", "label": "Otojenik iPSC Naklinde İmmün Uyum"},
            {"val": ">%80", "label": "Biyonik Çipte Harf Tanıma Başarısı"}
        ],
        trials_table=[
            {
                "trial": "PRIMA European Feasibility Clinical Study",
                "design": "Kuru YBMD Coğrafi Atrofili Hastalarda Subretinal Kablosuz Çip Faz 1/2 Çalışması [s.275]",
                "result": "Tüm hastalarda implant stabil kalmış, subretinal alanda harfleri ve kelimeleri optik zoom ile okuyabilme başarısı kanıtlanmıştır."
            },
            {
                "trial": "RIKEN Institute Mandai et al. Landmark iPSC Study",
                "design": "İleri YBMD Olgusunda Dünyada İlk Otojenik iPSC-RPE Monolayer Nakli (NEJM 2017) [s.273]",
                "result": "Nakledilen RPE tabakası 2 yıl boyunca hiçbir immünsüpresyon olmaksızın tamamen canlı kalmış ve neovaskülarizasyon nüksü görülmemiştir."
            },
            {
                "trial": "OpRegen Human Embryonic Stem Cell (hESC) Trial",
                "design": "Coğrafi Atrofi Olgularında Süspansiyon Halinde RPE Hücre Nakli Faz 1/2a",
                "result": "Atrofi sınırlarında stabilizasyon ve bazı hastalarda elipsoid zon yapısında kısmi restorasyon ile görme artışı bildirilmiştir."
            }
        ],
        bottom_evidence="Regeneratif tıp ve nöromorfik mühendislik retina hastalıklarının 'tedavi edilemez' kabul edilen terminal evrelerini tarihe karıştırmaktadır [s.275]."
    )

    # Slayt 9.2.2.6: Gelecek Nesil Tedaviler Triyaj ve Uygulama Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="İLERİ EVRE RETİNAL RESTORASYON SEÇİM ALGORİTMASI",
        category="BÖLÜM 9.2.2: AKIŞ ŞEMASI",
        subtitle="Terminal Görme Kaybı Olan Hastada Gen, Kök Hücre ve Biyonik Çip Triyajı",
        steps=[
            {
                "num": "1",
                "title": "Hücresel Canlılık Analizi (SD-OKT)",
                "desc": "Foveada elipsoid zon (canlı fotoreseptör) adası var mı? Retina kalınlığı >100 μm mi? [s.272]",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Monogenik Mutasyon Doğrulaması",
                "desc": "Canlı hücre varsa ve çift allelik RPE65 saptanmışsa standart gen tedavisi (Luxturna) uygulanır.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "RPE Hasarı / Coğrafi Atrofi (Hücre Nakli)",
                "desc": "Fotoreseptörler kısmen korunmuş ancak RPE tamamen silinmişse iPSC/ESC kök hücre yaması nakledilir.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Terminal Fotoreseptör Kaybı (PRIMA Çipi)",
                "desc": "Hiç canlı fotoreseptör kalmamış ve optik sinir sağlamsa PRIMA subretinal biyonik çip takılır [s.275].",
                "status": "success"
            }
        ],
        bottom_takeaway="Doğru hastaya doğru ileri tedavi: Canlı hücre varsa gen terapisi; RPE yoksa kök hücre; fotoreseptör tamamen ölmüşse biyonik çip endikedir [s.275]."
    )

    # Slayt 9.2.2.7: Aktif Hatırlama & Board Sınavı Vakası: Terminal RP ve Biyonik Çip
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: BİYONİK RETİNA",
        category="BÖLÜM 9.2.2: AKTİF HATIRLAMA",
        subtitle="55 Yaşında Son Evre RP Hastasında Hiç Fotoreseptör Kalmadığında Tedavi Seçimi",
        vignette="55 yaşında erkek hasta, 40 yıldır Retinitis Pigmentosa tanısıyla takip edilmektedir. Son 5 yıldır her iki gözünde görme keskinliği yalnızca 'el hareketi ve ışık hissi' seviyesindedir. Hasta bağımsız hareket edememekte ve refakatçi olmadan yürüyememektedir. Yapılan SD-OKT incelemesinde her iki makulada nörosensoriyel retinanın aşırı inceldiği (kalınlık 45 μm), elipsoid zonun ve dış nükleer katmanın (fotoreseptörlerin) tamamen kaybolduğu izleniyor. Yapılan tam alan ERG'de hem skotopik hem fotopik yanıtlar tamamen sönüktür (extinguished ERG). Kranial MRG ve görsel uyarılmış potansiyeller (VEP) testinde optik sinir aksonlarının ve oksipital korteksin canlılığını koruduğu doğrulanıyor. Aile gen tedavisi (Luxturna) için başvuruyor.",
        differentials=[
            "Biyonik Retinal Protez Adayı (PRIMA / Argus II - Fotoreseptörler tamamen ölmüş ancak optik sinir ve gangliyon hücreleri canlıdır).",
            "Luxturna Adayı (Hatalı düşünce; retinada hiç canlı fotoreseptör kalmamıştır, kalınlık <100 μm'dir, gen tedavisi etki edemez).",
            "Kök Hücre RPE Nakli (RPE değil fotoreseptörler öldüğü için tek başına RPE nakli görme sağlamaz).",
            "Optogenetik Tedavi (Kanalrodopsin gen aktarımı alternatif bir biyolojik seçenektir)."
        ],
        decision="1. Luxturna Uygunsuzluğu: Hastanın retinasında hiç canlı hücre kalmadığı için (EZ yok, retina 45 μm) standart gen tedavisi KESİNLİKLE UYGULANAMAZ; virüsün gen aktaracağı canlı hedef hücre yoktur.\n2. En Uygun Seçenek: Biyonik Retinal Protez (PRIMA Subretinal Fotovoltaik Çip İmplantasyonu).\n3. Cerrahi ve Rehabilitasyon: 25G PPV ile makula altına 378 piksellik fotovoltaik çip yerleştirilir. Hasta IR projektörlü gözlük ile rehabilite edilerek büyük kontrastlı harfleri okuyabilir ve bağımsız yürüyebilir hale getirilir.",
        board_trap="Son evre körlükte olan ve retinasında tek bir canlı fotoreseptör kalmamış bir hastaya 'RPE65 geni bulunursa gen tedavisiyle gözü açılır' demek biyolojik olarak imkansızdır; fotoreseptörü kalmayan gözün tek çözümü biyonik retina çipi veya optogenetiktir [s.274]."
    )

    print(f" -> Bölüm 9 (Travma, Farmakoterapi, Gelecek Perspektifler ve YZ) Tamamlandı: 31 Slayt Eklendi.")
