"""Conservative figure resolver: section numbers are never disease identifiers.

Only approved, hash-bound figure/panel records may be inserted. Legacy records
remain retrieval candidates, not verified clinical illustrations.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Optional, Union
from PIL import Image
from bookgraph.safety import atomic_json, file_hash

BASE_DIR = Path(os.getenv('RETINA_WORKSPACE_DIR', str(Path(__file__).resolve().parent)))
REGISTRY_PATH = Path(os.getenv('RETINA_REGISTRY_PATH', str(BASE_DIR / 'retina_precise_registry.json')))
CACHE_DIR = BASE_DIR / 'assets' / 'cached_images'

# Small unambiguous set only. Unknown/compound topics require an explicit topic_id.
DISEASE_TERMS = {
    'crao': ('crao', 'central retinal artery occlusion', 'santral retinal arter'),
    'crvo': ('crvo', 'central retinal vein occlusion', 'santral retinal ven'),
    'brao': ('brao', 'branch retinal artery occlusion'),
    'brvo': ('brvo', 'branch retinal vein occlusion', 'dal retinal ven'),
    'arn': ('arn', 'acute retinal necrosis', 'akut retinal nekroz'),
    'porn': ('porn', 'progressive outer retinal necrosis'),
    'cmv': ('cmv', 'cytomegalovirus', 'sitomegalovir'),
    'toxoplasmosis': ('toxoplasm', 'toksoplazm'),
    'stargardt': ('stargardt', 'abca4'),
    'best': ('best', 'best1', 'bestrophin', 'vitelliform'),
    'npdr': ('npdr', 'nonproliferative', 'nonproliferatif'),
    'pdr': ('pdr', 'proliferative diabetic', 'proliferatif diyabetik'),
    'dme': ('dme', 'dmö', 'diabetic macular edema', 'diyabetik makula ödem'),
    'rp': ('retinitis pigmentosa', 'retinitİs pigmentosa', 'retinitis pigmentoza'),
}

def _topics(text):
    text = text.casefold()
    return {key for key, terms in DISEASE_TERMS.items()
            if any(re.search(r'(?<!\w)' + re.escape(t.casefold()) + r'\w*', text) for t in terms)}

class RetinaVisualResolver:
    _instance = None
    def __init__(self, registry_path=None, cache_dir=None):
        self.registry = {}
        self.cache_dir = Path(cache_dir) if cache_dir else CACHE_DIR
        self.decisions = []
        self.registry_path = Path(registry_path) if registry_path else REGISTRY_PATH
        self.load_registry()

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def load_registry(self):
        if not self.registry_path.is_file():
            return
        data = json.loads(self.registry_path.read_text(encoding='utf-8'))
        self.registry = data.get('registry', data)

    def ensure_rgb_cached(self, src_path):
        p = Path(src_path)
        if not p.is_file():
            return None
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        # Content identity prevents filename collisions and stale-image reuse.
        digest = file_hash(p)
        target = self.cache_dir / (digest + '.png')
        if not target.is_file():
            from tempfile import NamedTemporaryFile
            with Image.open(p) as image:
                with NamedTemporaryFile(dir=self.cache_dir, suffix='.png', delete=False) as tmp:
                    name = tmp.name
                try:
                    image.convert('RGB').save(name, format='PNG')
                    os.replace(name, target)
                finally:
                    if os.path.exists(name):
                        os.unlink(name)
        return target

    def resolve_visual(self, chapter_num, title, category, explicit_path=None,
                       explicit_caption=None, *, topic_id=None, modality=None):
        # The automatic path intentionally refuses broad/comparative topics.
        requested = {topic_id} if topic_id else _topics(title)
        decision = dict(chapter=chapter_num, title=title, category=category,
                        requested_topics=sorted(requested), status='review_required',
                        reason='No approved, panel-specific matching record', candidates=[])
        if len(requested) != 1:
            decision['reason'] = 'Unknown or compound topic; assign an explicit topic_id'
            self.decisions.append(decision)
            return None, ''
        candidates = {}
        for group in self.registry.values():
            if not isinstance(group, list):
                continue
            for rec in group:
                path = rec.get('path', '')
                if path:
                    candidates[path] = rec
        for path, rec in candidates.items():
            if explicit_path and Path(path).resolve() != Path(explicit_path).resolve():
                continue
            labels = set(rec.get('disease_ids') or [])
            caption_topics = _topics(rec.get('original_caption', ''))
            if not (requested & (labels | caption_topics)):
                continue
            decision['candidates'].append(path)
            # Old labels and page-level captions are insufficient proof.
            if labels != requested or (caption_topics - requested):
                continue
            if rec.get('review_status') != 'approved' or not rec.get('reviewer'):
                continue
            if not all(rec.get(key) for key in ('source_id', 'page', 'figure_id', 'panel_id', 'modality', 'original_caption', 'image_sha256')):
                continue
            if not isinstance(rec.get('bbox'), list) or len(rec['bbox']) != 4:
                continue
            if modality and rec['modality'] != modality:
                continue
            p = Path(path)
            if not p.is_file() or file_hash(p) != rec['image_sha256']:
                continue
            cached = self.ensure_rgb_cached(p)
            if cached is None:
                continue
            # Preserve the approved original caption, never a disease-wide default.
            caption = f"{rec['original_caption']} [{rec['source_id']}, PDF s.{rec['page']}, {rec['figure_id']}/{rec['panel_id']}]"
            decision.update(status='approved_record_used', reason='Approved record and content hash matched',
                            image_sha256=rec['image_sha256'], source_id=rec['source_id'], path=path)
            self.decisions.append(decision)
            return cached, caption
        self.decisions.append(decision)
        return None, ''

    def write_manifest(self, path):
        atomic_json(path, {'schema_version': 1, 'decisions': self.decisions,
                           'review_required': sum(d['status'] == 'review_required' for d in self.decisions)})

def get_slide_visual(chapter_num, title, category, explicit_path=None, explicit_caption=None, **kwargs):
    return RetinaVisualResolver.get_instance().resolve_visual(chapter_num, title, category, explicit_path, explicit_caption, **kwargs)
