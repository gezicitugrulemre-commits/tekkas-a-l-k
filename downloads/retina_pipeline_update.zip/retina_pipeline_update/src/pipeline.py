"""
Aşama 2 & 3: LangGraph 1000 Sayfalık Akademik Kitap Üretim Orkestratörü.
(LangGraph Studio / LangGraph Server & $100 WPS + Google AI Ultra Çift Havuz Bağlantılı)

Mimari:
1. `section_writer_graph`: Tek bir alt-bölümü (~1050 kelime) uçtan uca üreten LangGraph StateGraph:
   - Düğüm 0 (`wps_quota_router`): $100 WPS kotasını ve Google AI Ultra havuzunu kontrol eder,
     aktif havuzu ve yazar modeli seçer.
   - Düğüm 1 (`generate_queries`): Gemini Flash ile hedefe yönelik tıbbi arama sorguları üretir.
   - Düğüm 2 (`retrieve_evidence`): ChromaDB + BM25 Hibrit Arama ile PDF'lerden sayfalı kanıt çeker.
   - Düğüm 3 (`synthesize_evidence`): Gemini Flash ile ham PDF metinlerini yapılandırılmış klinik
     kanıt özetine sıkıştırır (Yazar modelin token tüketimini %70 azaltır).
   - Düğüm 4 (`write_section`): Claude Sonnet / Gemini Pro / WPS Gateway (Otomatik Failover bağlantılı)
     ile 1050+ kelimelik akademik metin, ayırıcı tanı tablosu ve kaynakça yazar.
   - Düğüm 5 (`critic_review`): Gemini Flash ile kelime sayısını, atıfları ve tekrar kontrolünü denetler;
     eksik varsa yazara geri gönderir (Conditional Edge).
   - Düğüm 6 (`commit_ledger_and_quota`): Onaylanan metni diske yazar, Global Bellek Defterini ve
     $100 WPS Kota Defterini LangGraph içinden günceller.
2. `book_orchestrator_graph`: 420 alt-bölümün tamamını LangGraph Studio veya LangGraph SDK üzerinden
   otonom döngüde yürüten üst düzey (Master) StateGraph.
"""

import json
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Literal, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field
from rich.console import Console

from config import MODEL_CONFIG, PATHS, SCALE_CONFIG
from ingest import HybridMedicalRetriever
from quota_manager import QuotaAndWPSManager
from state import (
    BookBlueprint,
    BookOrchestratorState,
    ChapterSpec,
    CriticReview,
    GlobalMemoryLedger,
    PartSpec,
    SectionWriterState,
    SubsectionSpec,
)

console = Console()


# ============================================================================
# 1. ÇİFT HAVUZLU (ULTRA + $100 WPS) HİBRİT MODEL VE FAILOVER BAĞLANTISI
# ============================================================================

def _build_single_llm(provider: str, model_name: str, temperature: float):
    """Belirtilen sağlayıcı (wps_gateway, vertex_ai, google_ai_studio) için LLM nesnesi oluşturur."""
    if provider == "wps_gateway" and MODEL_CONFIG.wps_api_base_url and MODEL_CONFIG.wps_api_key:
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=MODEL_CONFIG.wps_model_name or model_name,
            api_key=MODEL_CONFIG.wps_api_key,
            base_url=MODEL_CONFIG.wps_api_base_url,
            temperature=temperature,
            max_tokens=8192,
            max_retries=2,
        )

    if provider == "vertex_ai" and "claude" in model_name.lower():
        from langchain_google_vertexai.model_garden import ChatAnthropicVertex
        return ChatAnthropicVertex(
            model_name=model_name,
            project=MODEL_CONFIG.gcp_project_id,
            location=MODEL_CONFIG.gcp_location,
            temperature=temperature,
            max_output_tokens=8192,
            max_retries=2,
        )

    if provider == "vertex_ai":
        from langchain_google_vertexai import ChatVertexAI
        return ChatVertexAI(
            model_name=model_name,
            project=MODEL_CONFIG.gcp_project_id,
            location=MODEL_CONFIG.gcp_location,
            temperature=temperature,
            max_output_tokens=8192,
            max_retries=2,
        )

    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(
        model=model_name,
        temperature=temperature,
        max_output_tokens=8192,
        max_retries=2,
    )


def get_llm(role: Literal["fast", "writer"], temperature: float = 0.2):
    """
    LangGraph düğümleri için birincil model ve $100 WPS / Ultra yedek (fallback) zincirini bağlar.
    Birincil kanalda kota/429 hatası alınırsa LangGraph kesintisiz olarak yedek havuza geçer.
    """
    quota_mgr = QuotaAndWPSManager()
    if role == "writer" and quota_mgr.should_use_economy_writer():
        primary_model = MODEL_CONFIG.fast_model_name
    else:
        primary_model = MODEL_CONFIG.fast_model_name if role == "fast" else MODEL_CONFIG.writer_model_name

    primary_llm = _build_single_llm(MODEL_CONFIG.provider_mode, primary_model, temperature)

    # Eğer hem Ultra (Vertex/AI Studio) hem de $100 WPS Gateway tanımlıysa birbirine Fallback olarak bağla
    fallbacks = []
    if MODEL_CONFIG.wps_api_base_url and MODEL_CONFIG.wps_api_key and MODEL_CONFIG.provider_mode != "wps_gateway":
        wps_llm = _build_single_llm("wps_gateway", MODEL_CONFIG.wps_model_name or primary_model, temperature)
        fallbacks.append(wps_llm)
    elif MODEL_CONFIG.provider_mode == "wps_gateway":
        # Birincil WPS ise yedeğe Gemini Flash / Pro bağla
        backup_llm = _build_single_llm("google_ai_studio", MODEL_CONFIG.fast_model_name, temperature)
        fallbacks.append(backup_llm)

    if fallbacks:
        return primary_llm.with_fallbacks(fallbacks)
    return primary_llm


# ============================================================================
# 2. KÜRESEL BELLEK DEFTERİ (LEDGER) YÖNETİMİ
# ============================================================================

def load_ledger() -> GlobalMemoryLedger:
    if PATHS.ledger_path.exists():
        data = json.loads(PATHS.ledger_path.read_text(encoding="utf-8"))
        return GlobalMemoryLedger(**data)
    return GlobalMemoryLedger()


def save_ledger(ledger: GlobalMemoryLedger) -> None:
    PATHS.ledger_path.write_text(
        ledger.model_dump_json(indent=2), encoding="utf-8"
    )


# ============================================================================
# 3. AŞAMA 2: 1000 SAYFALIK HİYERARŞİK MÜFREDAT MİMARI (BLUEPRINT ARCHITECT)
# ============================================================================

OPHTHALMOLOGY_12_PARTS_SEED = [
    ("P01", 1, "KISIM I: OFTALMOLOJİNİN TEMELLERİ, OKÜLER ANATOMİ, EMBRİYOLOJİ VE GENETİK", ["Fundamentals", "Anatomy", "Khurana", "Principles"]),
    ("P02", 2, "KISIM II: KLİNİK OPTİK, REFRAKSİYON VE GÖRME REHABİLİTASYONU", ["Clinical Optics", "elkington", "Vision Rehabilitation"]),
    ("P03", 3, "KISIM III: KORNEA, OKÜLER YÜZEY HASTALIKLARI VE HARİCİ HASTALIKLAR", ["Cornea", "Topography", "External Disease"]),
    ("P04", 4, "KISIM IV: REFRAKTİF CERRAHİ PRENSİPLERİ VE TEKNİKLERİ", ["Refractive Surgery", "LASIK", "PRK", "SMILE"]),
    ("P05", 5, "KISIM V: LENS VE KATARAKT CERRAHİSİ (FAKOEMÜLSİFİKASYON VE GİL)", ["Cataract", "Lens", "Intraocular Lens"]),
    ("P06", 6, "KISIM VI: GLOKOM: TANI, MEDİKAL, LAZER VE CERRAHİ YÖNETİM", ["Glaucoma", "Intraocular Pressure", "OCT", "Trabeculectomy"]),
    ("P07", 7, "KISIM VII: ÜVEİT, SKLERİT VE İNTRAOKÜLER İNFLAMASYON", ["Uveitis", "inflammation", "Endophthalmitis"]),
    ("P08", 8, "KISIM VIII: RETİNA VE VİTREUS HASTALIKLARI (MEDİKAL VE CERRAHİ RETİNA)", ["Retina", "Vitreous", "Guncel_Retina", "Macular"]),
    ("P09", 9, "KISIM IX: NÖRO-OFTALMOLOJİ VE GÖRME YOLLARI HASTALIKLARI", ["Neuro-Ophthalmology", "Neurology", "Bradley", "Optic Nerve"]),
    ("P10", 10, "KISIM X: PEDİATRİK OFTALMOLOJİ VE ŞAŞILIK (STRABİSMUS)", ["Pediatric", "Strabismus", "Amblyopia"]),
    ("P11", 11, "KISIM XI: OKÜLOPLASTİK CERRAHİ, LAKRİMAL SİSTEM VE ORBİTA", ["Oculofacial", "Orbital", "Oculoplastics"]),
    ("P12", 12, "KISIM XII: OFTALMİK PATOLOJİ, İNTRAOKÜLER TÜMÖRLER VE SİSTEMİK HASTALIKLAR", ["Pathology", "Intraocular Tumors", "General Medicine"]),
]


class PartChaptersOutput(BaseModel):
    chapters: List[ChapterSpec] = Field(description="Bu kısma ait bölümler ve alt-bölümler listesi")


def generate_book_blueprint(force_rebuild: bool = False) -> BookBlueprint:
    """
    12 Ana Kısım x 7 Bölüm x 5 Alt-Bölüm = 420 Yaprak Düğüm (~1000 Sayfa)
    yapısını oluşturur. Kesintiye dayanıklıdır; her kısım üretildiğinde diske kaydeder.
    """
    PATHS.ensure_dirs()
    if PATHS.blueprint_path.exists() and not force_rebuild:
        data = json.loads(PATHS.blueprint_path.read_text(encoding="utf-8"))
        bp = BookBlueprint(**data)
        if len(bp.parts) == len(OPHTHALMOLOGY_12_PARTS_SEED):
            return bp

    writer_llm = get_llm("writer", temperature=0.3)
    structured_architect = writer_llm.with_structured_output(PartChaptersOutput)

    existing_parts: List[PartSpec] = []
    if PATHS.blueprint_path.exists() and not force_rebuild:
        partial_data = json.loads(PATHS.blueprint_path.read_text(encoding="utf-8"))
        existing_parts = [PartSpec(**p) for p in partial_data.get("parts", [])]

    completed_part_ids = {p.part_id for p in existing_parts}
    chapter_global_counter = sum(len(p.chapters) for p in existing_parts) + 1

    for part_id, part_num, part_title, domain_keywords in OPHTHALMOLOGY_12_PARTS_SEED:
        if part_id in completed_part_ids:
            continue

        console.print(f"[bold magenta]Mimari Tasarlanıyor:[/bold magenta] {part_title}...")
        prompt = f"""
Sen dünya çapında bir Oftalmoloji Profesörü ve Baş Editörsün.
'{SCALE_CONFIG.book_title}' adlı 1000 sayfalık akademik başvuru kitabının
'{part_title}' (Part ID: {part_id}) kısmının detaylı müfredatını tasarlıyorsun.

GÖREV KURALLARI:
1. Bu kısım için tam olarak {SCALE_CONFIG.chapters_per_part} adet Bölüm (Chapter) oluştur.
   Bölüm numaraları {chapter_global_counter}'den başlamalıdır.
2. Her Bölüm (Chapter) altında tam olarak {SCALE_CONFIG.subsections_per_chapter} adet Alt-Bölüm (Subsection) oluştur.
3. ID formatları:
   - `chapter_id`: '{part_id}-C01', '{part_id}-C02' ...
   - `subsection_id`: '{part_id}-C01-S01', '{part_id}-C01-S02' ...
4. Her alt-bölüm (`SubsectionSpec`) ~1050 kelimelik (~2.5 sayfa) derin bir akademik makale
   boyutunda yazılacaktır; bu nedenle başlıklar yüzeysel değil spesifik klinik/cerrahi/patolojik
   konuları kapsamalıdır.
5. `key_search_terms` alanına İngilizce tıbbi literatürde (AAO BCSC, Kanski, Wills Eye, Duane's)
   arama yaparken kullanılacak 4-6 adet spesifik İngilizce tıbbi terim ekle.
"""
        result: PartChaptersOutput = structured_architect.invoke([
            SystemMessage(content="Akademik tıp kitabı müfredat mimarısın. Çıktıyı eksiksiz JSON şemasına uygun üret."),
            HumanMessage(content=prompt),
        ])

        normalized_chapters: List[ChapterSpec] = []
        for c_idx, ch in enumerate(result.chapters, start=1):
            ch_id = f"{part_id}-C{c_idx:02d}"
            ch.chapter_id = ch_id
            ch.chapter_number = chapter_global_counter
            chapter_global_counter += 1

            for s_idx, sub in enumerate(ch.subsections, start=1):
                sub.subsection_id = f"{ch_id}-S{s_idx:02d}"
                sub.target_words = SCALE_CONFIG.target_words_per_subsection
                sub.status = "pending"
            normalized_chapters.append(ch)

        part_spec = PartSpec(
            part_id=part_id,
            part_number=part_num,
            title=part_title,
            source_domain_keywords=domain_keywords,
            chapters=normalized_chapters,
        )
        existing_parts.append(part_spec)

        total_ch = sum(len(p.chapters) for p in existing_parts)
        total_sub = sum(len(c.subsections) for p in existing_parts for c in p.chapters)
        est_words = total_sub * SCALE_CONFIG.target_words_per_subsection
        blueprint = BookBlueprint(
            book_title=SCALE_CONFIG.book_title,
            total_parts=len(existing_parts),
            total_chapters=total_ch,
            total_subsections=total_sub,
            estimated_total_words=est_words,
            estimated_total_pages=round(est_words / SCALE_CONFIG.words_per_page),
            parts=existing_parts,
        )
        PATHS.blueprint_path.write_text(blueprint.model_dump_json(indent=2), encoding="utf-8")

    return blueprint


# ============================================================================
# 4. AŞAMA 3: LANGGRAPH ALT-BÖLÜM YAZIM GRAFIĞI (`section_writer_graph`)
# ============================================================================

def node_wps_quota_router(state: SectionWriterState) -> Dict:
    """
    Düğüm 0 (LangGraph Giriş Yönlendiricisi):
    $100 WPS kotasını, Google AI Ultra havuzunu ve Global Bellek Defterini LangGraph
    durumuna (state) bağlar. Eğer dışarıdan (örn. LangGraph Studio'dan) sadece `subsection`
    verilerek tetiklendiyse, Global Bellek özetlerini otomatik yükler.
    """
    quota_mgr = QuotaAndWPSManager()
    ledger = load_ledger()

    economy = quota_mgr.should_use_economy_writer()
    selected_writer = MODEL_CONFIG.fast_model_name if economy else (
        MODEL_CONFIG.wps_model_name or MODEL_CONFIG.writer_model_name
    )

    if MODEL_CONFIG.wps_api_base_url and MODEL_CONFIG.wps_api_key:
        pool = "wps_hybrid_fallback"
    elif MODEL_CONFIG.provider_mode == "vertex_ai":
        pool = "ultra_vertex_wps_pool"
    else:
        pool = "ultra_ai_studio_pool"

    ch_id = state.get("chapter_id", "P01-C01")
    prev_summaries = state.get("previous_sections_summary")
    if not prev_summaries:
        prev_list = ledger.rolling_chapter_summaries.get(ch_id, [])
        prev_summaries = "\n".join(f"- {s}" for s in prev_list[-6:])

    covered = state.get("already_covered_concepts")
    if not covered:
        covered = "\n".join(f"- {k} (Bkz: {v})" for k, v in list(ledger.covered_concepts.items())[-40:])

    glossary = state.get("standard_glossary")
    if not glossary:
        glossary = "\n".join(f"- {en}: {tr}" for en, tr in list(ledger.terminology_glossary.items())[-50:])

    return {
        "active_pool": pool,
        "selected_writer_model": selected_writer,
        "wps_remaining_usd": quota_mgr.record.remaining_usd,
        "previous_sections_summary": prev_summaries,
        "already_covered_concepts": covered,
        "standard_glossary": glossary,
        "revision_count": state.get("revision_count", 0),
    }


class SearchQueriesOutput(BaseModel):
    queries: List[str] = Field(description="PDF veritabanında aranacak 4-6 adet spesifik İngilizce tıbbi sorgu")


def node_generate_queries(state: SectionWriterState) -> Dict:
    """Düğüm 1 (Gemini Flash): Alt-bölüm için PDF veritabanına yönelik hibrit arama sorguları üretir."""
    fast_llm = get_llm("fast", temperature=0.1).with_structured_output(SearchQueriesOutput)
    sub = state["subsection"]

    prompt = f"""
Bölüm: {state.get('chapter_title', '')}
Alt-Bölüm: {sub['title']}
Klinik Odak: {sub.get('clinical_focus', '')}
Önerilen Terimler: {', '.join(sub.get('key_search_terms', []))}

Kaynak veritabanımız İngilizce ve Türkçe Oftalmoloji referans kitaplarından
(AAO BCSC, Kanski, Albert's, Wills Eye, Güncel Retina vb.) oluşmaktadır.
Bu alt-bölümü kanıta dayalı yazabilmek için patofizyoloji, tanı/görüntüleme (OCT, FA, topografi vb.),
ayırıcı tanı ve cerrahi/medikal tedavi protokollerini bulacak 5 adet spesifik arama sorgusu üret (4 İngilizce, 1 Türkçe).
"""
    res: SearchQueriesOutput = fast_llm.invoke([HumanMessage(content=prompt)])
    return {"search_queries": res.queries}


def node_retrieve_evidence(state: SectionWriterState) -> Dict:
    """Düğüm 2 (ChromaDB + BM25): Sorguları çalıştırır ve sayfa numaralı kaynak parçalarını getirir."""
    retriever = HybridMedicalRetriever()
    queries = state.get("search_queries", []) + state["subsection"].get("key_search_terms", [])[:2]
    chunks = retriever.retrieve(queries=queries, top_k=14)
    return {"retrieved_chunks": chunks}


def node_synthesize_evidence(state: SectionWriterState) -> Dict:
    """
    Düğüm 3 (Gemini Flash): Ham PDF parçalarını yapılandırılmış klinik kanıt özetine dönüştürür.
    """
    fast_llm = get_llm("fast", temperature=0.1)
    chunks = state.get("retrieved_chunks", [])
    if not chunks:
        return {"synthesized_evidence": "Veritabanında doğrudan eşleşen parça bulunamadı; standart AAO BCSC kılavuz bilgilerini kullanın."}

    formatted_chunks = "\n\n".join(
        f"--- KAYNAK [{i+1}]: {c['source_book']} (Sayfa {c['page_number']}) ---\n{c['content']}"
        for i, c in enumerate(chunks)
    )

    prompt = f"""
Aşağıdaki ham PDF alıntılarını '{state['subsection']['title']}' başlıklı akademik kitap bölümü için
yapılandırılmış bir Klinik Kanıt Dosyasına dönüştür.

KURALLAR:
1. Sayısal verileri (dozajlar, yüzdeler, evreleme kriterleri, OCT/FA bulguları, cerrahi parametreler) asla kaybetme.
2. Her bilginin yanına mutlaka kaynak adını ve sayfa numarasını `[Kaynak: Kitap Adı, s. X]` formatında ekle.
3. Bilgileri şu başlıklar altında grupla:
   - Patofizyoloji ve Histopatoloji
   - Klinik Bulgular ve Tanısal Görüntüleme
   - Ayırıcı Tanı Kriterleri
   - Medikal ve Cerrahi Tedavi Protokolleri

HAM PDF ALINTILARI:
{formatted_chunks}
"""
    res = fast_llm.invoke([HumanMessage(content=prompt)])
    return {"synthesized_evidence": str(res.content)}


def node_write_section(state: SectionWriterState) -> Dict:
    """
    Düğüm 4 (Claude Sonnet / Gemini Pro / WPS Failover): 1050+ kelimelik derin akademik kitap alt-bölümünü yazar.
    """
    writer_llm = get_llm("writer", temperature=0.3)
    sub = state["subsection"]
    revision_note = ""
    if state.get("revision_count", 0) > 0 and state.get("critic_feedback"):
        revision_note = f"""
\n⚠️ EDİTÖR DÜZELTME TALİMATI (Revizyon #{state['revision_count']}):
Önceki taslak şu nedenlerle revizyona gönderildi:
{state['critic_feedback']}
Lütfen mevcut taslağı bu geri bildirim doğrultusunda genişleterek ve düzelterek yeniden yaz.
Önceki Taslak:
{state.get('draft_markdown', '')}
"""

    prompt = f"""
Sen '{SCALE_CONFIG.book_title}' kitabının Baş Yazarısın.
Aktif Kota Havuzu: {state.get('active_pool', 'ultra_wps_pool')} | Kalan $100 WPS Bütçesi: ${state.get('wps_remaining_usd', 100.0):.2f}

Şu anda aşağıdaki alt-bölümü yazıyorsun:
- **Üst Kısım:** {state.get('part_title', '')}
- **Bölüm:** {state.get('chapter_title', '')}
- **Alt-Bölüm ID ve Başlığı:** {sub['subsection_id']} — {sub['title']}
- **Klinik Odak:** {sub.get('clinical_focus', '')}
- **Hedef Uzunluk:** En az {SCALE_CONFIG.min_words_per_subsection} kelime (İdeal: {SCALE_CONFIG.target_words_per_subsection} - 1250 kelime, ~2.5 kitap sayfası).

### KÜRESEL TUTARLILIK VE TEKRAR ÖNLEME BAĞLAMI
- **Bu Bölümde Önceki Alt-Bölümlerde Anlatılanlar (Tekrar Etme, Atıf Yap):**
{state.get('previous_sections_summary') or 'Bu bölümün ilk alt-bölümüdür.'}

- **Daha Önce Detaylı İşlenen Kavramlar:**
{state.get('already_covered_concepts') or 'Henüz yok.'}

- **Standart Tıbbi Terminoloji Sözlüğü:**
{state.get('standard_glossary') or 'İlk kullanımda Türkçe Terim (İngilizce Orijinal Terim, Kısaltma) formatını kullan.'}

### VERİTABANINDAN ÇIKARILAN KANITA DAYALI KLİNİK DOSYA
{state.get('synthesized_evidence', '')}

### YAZIM VE FORMAT KURALLARI (ZORUNLU)
1. **Akademik Tıbbi Üslup:** Uzman hekim ve asistan düzeyinde, kanıta dayalı, derinlemesine mekanizma ve klinik pratik odaklı Türkçe kullan. Önemli terimlerin ilk geçişinde parantez içinde İngilizce karşılığını ver.
2. **Zorunlu Yapısal Bileşenler:**
   - `### {sub['subsection_id']} {sub['title']}` ana başlığı ile başla.
   - **Temel Mekanizma ve Patofizyoloji:** Hücresel, anatomik veya optik prensipleri detaylı açıkla.
   - **Klinik Prezantasyon ve Tanısal Görüntüleme:** Biyomikroskopi, OCT, FA, KGA, topografi vb. bulguları detaylandır.
   - **Ayırıcı Tanı Tablosu:** Markdown tablosu (`| Hastalık/Durum | Ayırt Edici Klinik Bulgu | Görüntüleme / Test |`) olarak sun.
   - **Güncel Medikal ve Cerrahi Yönetim:** İlaç dozları, cerrahi adımlar, komplikasyon yönetimi.
   - **> [!IMPORTANT] Klinik İpuçları (Clinical Pearls):** Pratikte dikkat edilmesi gereken kritik noktaları özetleyen kutu.
3. **Metin İçi Kaynak Gösterimi:** Veritabanı kanıtlarındaki kaynakları metin içinde `[Kaynak: Kitap Adı, s. X]` şeklinde belirt ve alt-bölüm sonunda `#### Kaynaklar` altında listele.
{revision_note}
"""
    res = writer_llm.invoke([
        SystemMessage(content="Kıdemli Oftalmoloji Profesörü ve akademik tıp yazarısın."),
        HumanMessage(content=prompt),
    ])
    return {
        "draft_markdown": str(res.content),
        "revision_count": state.get("revision_count", 0) + 1,
    }


def node_critic_review(state: SectionWriterState) -> Dict:
    """
    Düğüm 5 (Gemini Flash): Yazılan taslağı kelime sayısı, kaynak atıfı, tablo varlığı ve
    terminoloji tutarlılığı açısından denetler; ayrıca Global Bellek için özet çıkarır.
    """
    fast_llm = get_llm("fast", temperature=0.0).with_structured_output(CriticReview)
    draft = state.get("draft_markdown", "")
    actual_words = len(draft.split())

    prompt = f"""
Aşağıdaki akademik kitap alt-bölüm taslağını Baş Editör gözüyle denetle:

Hedeflenen Minimum Kelime Sayısı: {SCALE_CONFIG.min_words_per_subsection}
Mevcut Kelime Sayısı (Hesaplanan): {actual_words}
Alt-Bölüm Başlığı: {state['subsection']['title']}

DENETİM KRİTERLERİ:
1. Kelime sayısı {SCALE_CONFIG.min_words_per_subsection} kelimenin altındaysa veya metin yüzeysel bırakılmışsa `is_approved=False` yap ve hangi alt başlıkların detaylandırılması gerektiğini `revision_instructions` içine yaz.
2. Metin içinde `[Kaynak: ...]` atıfları ve Markdown Ayırıcı Tanı Tablosu var mı kontrol et.
3. `section_summary` alanına bu alt-bölümde nelerin anlatıldığını özetleyen 2-3 cümle yaz (sonraki bölümlerde tekrar edilmemesi için).
4. `extracted_terms` alanına bu bölümde geçen en önemli 3-5 İngilizce->Türkçe tıbbi terim eşleşmesini çıkar.

TASLAK METİN:
{draft}
"""
    review: CriticReview = fast_llm.invoke([HumanMessage(content=prompt)])

    force_approve = state.get("revision_count", 1) >= SCALE_CONFIG.max_revisions_per_subsection
    approved = (review.is_approved and actual_words >= SCALE_CONFIG.min_words_per_subsection) or force_approve

    return {
        "is_approved": approved,
        "critic_feedback": review.revision_instructions,
        "final_summary": review.section_summary,
        "new_terms": review.extracted_terms,
        "final_word_count": actual_words,
    }


def node_commit_ledger_and_quota(state: SectionWriterState) -> Dict:
    """
    Düğüm 6 (LangGraph Çıkış Kayıt Düğümü):
    Onaylanan alt-bölümü diske kaydeder, Global Bellek Defterini ve $100 WPS Kota Defterini
    doğrudan LangGraph akışı içerisinde günceller.
    """
    PATHS.ensure_dirs()
    sub = state["subsection"]
    sub_id = sub["subsection_id"]
    part_id = sub_id.split("-")[0] if "-" in sub_id else "P01"
    ch_id = state.get("chapter_id") or ("-".join(sub_id.split("-")[:2]) if "-" in sub_id else "P01-C01")

    part_dir = PATHS.chapters_dir / part_id
    part_dir.mkdir(parents=True, exist_ok=True)
    out_file = part_dir / f"{sub_id}.md"
    out_file.write_text(state.get("draft_markdown", ""), encoding="utf-8")

    # 1. Global Bellek Defterini Güncelle
    ledger = load_ledger()
    word_count = state.get("final_word_count", len(state.get("draft_markdown", "").split()))
    if sub_id not in ledger.completed_subsection_ids:
        ledger.total_words_written += word_count
        ledger.completed_subsection_ids.append(sub_id)
    ledger.covered_concepts[sub["title"]] = sub_id
    ledger.terminology_glossary.update(state.get("new_terms", {}))
    ledger.rolling_chapter_summaries.setdefault(ch_id, []).append(
        f"[{sub_id} - {sub['title']}]: {state.get('final_summary', '')}"
    )
    save_ledger(ledger)

    # 2. Blueprint Durumunu Güncelle (Eğer dosya mevcutsa)
    if PATHS.blueprint_path.exists():
        bp_data = json.loads(PATHS.blueprint_path.read_text(encoding="utf-8"))
        for p in bp_data.get("parts", []):
            for c in p.get("chapters", []):
                for s in c.get("subsections", []):
                    if s.get("subsection_id") == sub_id:
                        s["status"] = "completed"
                        s["output_file"] = str(out_file)
                        s["actual_words"] = word_count
        PATHS.blueprint_path.write_text(json.dumps(bp_data, indent=2, ensure_ascii=False), encoding="utf-8")

    # 3. $100 WPS / Bulut Kotası Defterini Güncelle
    quota_mgr = QuotaAndWPSManager()
    est_fast_in = len(state.get("synthesized_evidence", "").split()) * 4 + 2500
    est_fast_out = 900
    est_writer_in = len(state.get("synthesized_evidence", "").split()) * 2 + 1200
    est_writer_out = int(word_count * 1.45) * max(1, state.get("revision_count", 1))
    sec_cost = quota_mgr.estimate_and_log_usage(
        subsection_id=sub_id,
        fast_input_tokens=est_fast_in,
        fast_output_tokens=est_fast_out,
        writer_input_tokens=est_writer_in,
        writer_output_tokens=est_writer_out,
        used_pool="wps",
    )

    return {
        "section_cost_usd": sec_cost,
        "wps_remaining_usd": quota_mgr.record.remaining_usd,
        "saved_file_path": str(out_file),
    }


def route_after_critic(state: SectionWriterState) -> Literal["revise", "approve"]:
    if state.get("is_approved", False):
        return "approve"
    return "revise"


def build_section_writer_graph(conn: Optional[sqlite3.Connection] = None):
    """
    LangGraph Alt-Bölüm Yazım Grafiğini derler.
    `conn` verilirse SQLite Checkpointer ile, verilmezse LangGraph Studio / Server
    kendi dahili checkpointer'ını bağlayabilsin diye doğrudan derler.
    """
    workflow = StateGraph(SectionWriterState)

    workflow.add_node("wps_quota_router", node_wps_quota_router)
    workflow.add_node("generate_queries", node_generate_queries)
    workflow.add_node("retrieve_evidence", node_retrieve_evidence)
    workflow.add_node("synthesize_evidence", node_synthesize_evidence)
    workflow.add_node("write_section", node_write_section)
    workflow.add_node("critic_review", node_critic_review)
    workflow.add_node("commit_ledger_and_quota", node_commit_ledger_and_quota)

    workflow.add_edge(START, "wps_quota_router")
    workflow.add_edge("wps_quota_router", "generate_queries")
    workflow.add_edge("generate_queries", "retrieve_evidence")
    workflow.add_edge("retrieve_evidence", "synthesize_evidence")
    workflow.add_edge("synthesize_evidence", "write_section")
    workflow.add_edge("write_section", "critic_review")

    workflow.add_conditional_edges(
        "critic_review",
        route_after_critic,
        {
            "revise": "write_section",
            "approve": "commit_ledger_and_quota",
        },
    )
    workflow.add_edge("commit_ledger_and_quota", END)

    if conn is not None:
        checkpointer = SqliteSaver(conn)
        return workflow.compile(checkpointer=checkpointer)
    return workflow.compile()


# ============================================================================
# 5. ÜST DÜZEY (MASTER) KİTAP ORKESTRATÖR GRAFIĞI (`book_orchestrator_graph`)
# ============================================================================

def node_orchestrator_pick_next(state: BookOrchestratorState) -> Dict:
    """Blueprint'ten sıradaki tamamlanmamış alt-bölümü bulur ve `section_writer_graph` ile çalıştırır."""
    blueprint = generate_book_blueprint(force_rebuild=False)
    quota_mgr = QuotaAndWPSManager()

    for part in blueprint.parts:
        for chapter in part.chapters:
            for sub in chapter.subsections:
                if sub.status == "completed" and sub.output_file and Path(sub.output_file).exists():
                    continue

                # Sıradaki alt-bölümü alt-grafik (subgraph) üzerinde çalıştır
                sub_state: SectionWriterState = {
                    "part_title": part.title,
                    "chapter_id": chapter.chapter_id,
                    "chapter_title": f"Bölüm {chapter.chapter_number}: {chapter.title}",
                    "subsection": sub.model_dump(),
                    "previous_sections_summary": "",
                    "already_covered_concepts": "",
                    "standard_glossary": "",
                    "search_queries": [],
                    "retrieved_chunks": [],
                    "synthesized_evidence": "",
                    "draft_markdown": "",
                    "revision_count": 0,
                    "critic_feedback": "",
                    "is_approved": False,
                    "final_summary": "",
                    "new_terms": {},
                    "final_word_count": 0,
                    "active_pool": "",
                    "selected_writer_model": "",
                    "wps_remaining_usd": quota_mgr.record.remaining_usd,
                    "section_cost_usd": 0.0,
                    "saved_file_path": "",
                }
                res = section_writer_graph.invoke(sub_state)
                ledger = load_ledger()
                return {
                    "processed_count": state.get("processed_count", 0) + 1,
                    "current_part_id": part.part_id,
                    "current_chapter_id": chapter.chapter_id,
                    "current_subsection_id": sub.subsection_id,
                    "last_completed_file": res.get("saved_file_path", ""),
                    "total_words_written": ledger.total_words_written,
                    "wps_remaining_usd": res.get("wps_remaining_usd", 100.0),
                    "is_finished": False,
                }

    ledger = load_ledger()
    return {
        "is_finished": True,
        "total_words_written": ledger.total_words_written,
        "wps_remaining_usd": quota_mgr.record.remaining_usd,
    }


def route_orchestrator(state: BookOrchestratorState) -> Literal["continue_next", "stop"]:
    if state.get("is_finished", False):
        return "stop"
    limit = state.get("batch_limit", 1)
    if limit > 0 and state.get("processed_count", 0) >= limit:
        return "stop"
    return "continue_next"


def build_book_orchestrator_graph():
    """LangGraph Studio'dan tüm kitabı veya belirli bir batch'i yöneten üst grafik."""
    wf = StateGraph(BookOrchestratorState)
    wf.add_node("process_next_subsection", node_orchestrator_pick_next)
    wf.add_edge(START, "process_next_subsection")
    wf.add_conditional_edges(
        "process_next_subsection",
        route_orchestrator,
        {
            "continue_next": "process_next_subsection",
            "stop": END,
        },
    )
    return wf.compile()


# LangGraph Studio / CLI (`langgraph.json`) için dışa aktarılan derlenmiş grafikler
section_writer_graph = build_section_writer_graph()
book_orchestrator_graph = build_book_orchestrator_graph()


# ============================================================================
# 6. CLI YÜRÜTÜCÜ: TÜM KİTABI KESİNTİYE DAYANIKLI ÜRETME DÖNGÜSÜ
# ============================================================================

def run_book_generation_pipeline(max_subsections_this_run: int = 0) -> None:
    """
    Blueprint'teki 420 alt-bölümü sırayla (veya kaldığı yerden) SQLite Checkpointer destekli
    LangGraph üzerinde çalıştırır.
    """
    PATHS.ensure_dirs()
    blueprint = generate_book_blueprint(force_rebuild=False)

    conn = sqlite3.connect(str(PATHS.checkpoint_db_path), check_same_thread=False)
    graph = build_section_writer_graph(conn)

    processed_in_session = 0
    rpm_delay = 60.0 / max(1, MODEL_CONFIG.requests_per_minute_limit)

    for part in blueprint.parts:
        for chapter in part.chapters:
            ch_id = chapter.chapter_id

            for sub in chapter.subsections:
                if sub.status == "completed" and sub.output_file and Path(sub.output_file).exists():
                    continue

                console.rule(f"[bold green]LangGraph Yazıyor: {sub.subsection_id} — {sub.title}[/bold green]")

                initial_state: SectionWriterState = {
                    "part_title": part.title,
                    "chapter_id": ch_id,
                    "chapter_title": f"Bölüm {chapter.chapter_number}: {chapter.title}",
                    "subsection": sub.model_dump(),
                    "previous_sections_summary": "",
                    "already_covered_concepts": "",
                    "standard_glossary": "",
                    "search_queries": [],
                    "retrieved_chunks": [],
                    "synthesized_evidence": "",
                    "draft_markdown": "",
                    "revision_count": 0,
                    "critic_feedback": "",
                    "is_approved": False,
                    "final_summary": "",
                    "new_terms": {},
                    "final_word_count": 0,
                    "active_pool": "",
                    "selected_writer_model": "",
                    "wps_remaining_usd": 100.0,
                    "section_cost_usd": 0.0,
                    "saved_file_path": "",
                }

                thread_config = {"configurable": {"thread_id": f"sub_{sub.subsection_id}"}}
                final_state = graph.invoke(initial_state, config=thread_config)

                ledger = load_ledger()
                est_pages_done = round(ledger.total_words_written / SCALE_CONFIG.words_per_page, 1)
                console.print(
                    f"[bold cyan]✓ Tamamlandı:[/bold cyan] {sub.subsection_id} "
                    f"({final_state['final_word_count']} kelime | Havuz: {final_state.get('active_pool')}) | "
                    f"İlerleme: {len(ledger.completed_subsection_ids)}/{blueprint.total_subsections} alt-bölüm "
                    f"(~{est_pages_done}/{SCALE_CONFIG.target_total_pages} sayfa) | "
                    f"[bold yellow]Maliyet: ${final_state.get('section_cost_usd', 0.0):.4f} "
                    f"(Kalan $100 WPS Kotası: ${final_state.get('wps_remaining_usd', 100.0):.2f})[/bold yellow]"
                )

                processed_in_session += 1
                if max_subsections_this_run > 0 and processed_in_session >= max_subsections_this_run:
                    console.print("[yellow]Bu oturum için belirlenen alt-bölüm sınırına ulaşıldı.[/yellow]")
                    conn.close()
                    return

                time.sleep(rpm_delay)

    conn.close()
    console.print("[bold green]🎉 Tüm 1000 sayfalık kitap alt-bölümleri başarıyla tamamlandı![/bold green]")
