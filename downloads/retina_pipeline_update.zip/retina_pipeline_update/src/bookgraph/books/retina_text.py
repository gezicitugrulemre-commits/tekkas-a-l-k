"""
Retina metin son-i?leme: tekrar ay?klama + master markdown derleme.
clean_and_deduplicate_topic_markdown, retina_pubmed_graph.py'den DE???T?R?LMEDEN ta??nd?.
(Eski assemble d???m?ndeki ReportLab "story" kodu hi? derlenmiyordu; yaln?zca master markdown
pro_pdf_publisher taraf?ndan kullan?ld??? i?in o k?s?m sadele?tirildi.)
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple


def _normalize_tokens_for_dedup(text: str) -> set[str]:
    """
    Aynı kaynak sayfalarından ('Temeller', 'Kanıt', 'Uygulama') üretilen paragraf ve
    cümlelerdeki eşanlamlı tıbbi terimleri normalize ederek tekrar tespiti yapar.
    """
    s = re.sub(r"\[(?:RV[123]|ICROP3|PRD|INJ):pdf\d+\]", "", text.lower())
    s = re.sub(r"\[pmid:\d+\]", "", s)
    synonyms = {
        "rod": "çubuk",
        "rods": "çubuk",
        "çomak": "çubuk",
        "kon": "koni",
        "cone": "koni",
        "cones": "koni",
        "sgmp": "cgmp",
        "dekorasyon": "dekorlasyon",
        "dekorrelasyon": "dekorlasyon",
        "otofloresan": "otofloresans",
        "otofagositoz": "otofloresans",
    }
    words = re.findall(r"[a-zçğıöşü0-9]{4,}", s)
    out = set()
    for w in words:
        for k, v in synonyms.items():
            if w.startswith(k):
                w = v + w[len(k):]
                break
        out.add(w[:6])
    return out


def clean_and_deduplicate_topic_markdown(md_text: str, display_tid: str) -> str:
    """
    1. Konu başlığını ([10.1.1] -> [9.1.1]) ve terminolojiyi ('Fundus Otofagositoz' -> 'Fundus Otofloresans') düzeltir.
    2. Yapay zeka meta-yorum cümlelerini ('Bu bölümde, kaynaklarda tanımlanan...', '[metin kesintisi]', '**Kaynak sınırı:**') temizler.
    3. Ana metin ('Temeller') paragraflarını eksiksiz korurken, altındaki '#### Kanıt' ve '#### Uygulama'
       bloklarını '#### Kanıta Dayalı Klinik Uygulama ve Yönetim' başlığı altında birleştirir ve
       ana metinde zaten anlatılmış olan tekrar paragraf/cümleleri eler.
    """
    md_text = md_text.replace("Fundus Otofagositoz", "Fundus Otofloresans").replace("fundus otofagositoz", "fundus otofloresans")

    meta_patterns = [
        r"\[metin kesintisi\]",
        r"\*\*Kaynak sınırı:\*\*[^\n]+",
        r"Bu bölümde,\s*kaynaklarda tanımlanan[^\n.!?]*[.!?]",
        r"Aşağıdaki alt başlıklar[^\n.!?]*[.!?]",
        r"Buradaki çerçeve,\s*yalnızca sağlanan kaynak metinlerde[^\n.!?]*[.!?]",
        r"Verilen kaynak metinlerde[^\n.!?]*doğrudan veri yer almamaktadır[.!?]",
        r"Mevcut kaynak sayfalarında[^\n.!?]*ayrıntılandırılmamıştır[.!?]",
        r"Sağlanan kaynak metinlerde[^\n.!?]*bulunmamaktadır[.!?]",
    ]
    for pat in meta_patterns:
        md_text = re.sub(pat, "", md_text, flags=re.IGNORECASE)

    lines = [ln.strip() for ln in md_text.splitlines() if ln.strip()]
    header = ""
    sections: Dict[str, List[str]] = {"temeller": [], "kanit": [], "uygulama": []}
    curr = "temeller"

    for ln in lines:
        if ln.startswith("### ") or ln.startswith("## ") or ln.startswith("# "):
            if not header:
                # Başlık numarasını display_tid ile senkronize et (ör. 10.1.1 -> 9.1.1)
                ln = re.sub(r"^#{1,3}\s+\[?\d+\.\d+\.\d+\]?\s+", f"### [{display_tid}] ", ln)
                header = ln
            continue
        if ln.startswith("#### "):
            low = ln.lower()
            if "kanıt" in low or "kanit" in low:
                curr = "kanit"
            elif "uygulama" in low:
                curr = "uygulama"
            continue
        sections[curr].append(ln)

    temeller_kept: List[str] = []
    temeller_Paragraph_tokens: List[set[str]] = []
    seen_sent_tokens: List[set[str]] = []

    for p in sections["temeller"]:
        if len(p) < 25:
            continue
        ptoks = _normalize_tokens_for_dedup(p)
        temeller_kept.append(p)
        temeller_Paragraph_tokens.append(ptoks)
        for s in re.split(r"(?<=[.!?])\s+", p):
            st = _normalize_tokens_for_dedup(s)
            if len(st) >= 5:
                seen_sent_tokens.append(st)

    merged_clinical: List[str] = []
    merged_para_tokens: List[set[str]] = []

    for sec_name in ("kanit", "uygulama"):
        for p in sections[sec_name]:
            if len(p) < 40:
                continue
            ptoks = _normalize_tokens_for_dedup(p)
            if not ptoks:
                continue
            # Ana metin (Temeller) paragrafıyla %50+ örtüşüyorsa tekrardır, atla
            if any(len(ptoks & prev) / max(1, min(len(ptoks), len(prev))) >= 0.50 for prev in temeller_Paragraph_tokens):
                continue
            # Birleştirilmiş klinik blok içindeki önceki paragraflarla %52+ örtüşüyorsa atla
            if any(len(ptoks & prev) / max(1, min(len(ptoks), len(prev))) >= 0.52 for prev in merged_para_tokens):
                continue

            sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", p) if len(s.strip()) >= 30]
            kept_sents: List[str] = []
            for s in sents:
                st = _normalize_tokens_for_dedup(s)
                if len(st) < 5:
                    continue
                if any(len(st & prev_s) / max(1, min(len(st), len(prev_s))) >= 0.55 for prev_s in seen_sent_tokens):
                    continue
                kept_sents.append(s)
                seen_sent_tokens.append(st)

            if kept_sents:
                new_p = " ".join(kept_sents)
                if len(new_p) >= 65:
                    merged_clinical.append(new_p)
                    merged_para_tokens.append(_normalize_tokens_for_dedup(new_p))

    # Eğer bir konuda tüm Kanıt/Uygulama paragrafları elendiyse, Uygulama/Kanıt içinden
    # Temeller ile en az örtüşen 2-3 klinik uygulama cümlesini seçerek özlü bir klinik sentez paragrafı oluştur
    if not merged_clinical and (sections["uygulama"] or sections["kanit"]):
        candidate_sents: List[tuple[float, str]] = []
        for sec_name in ("uygulama", "kanit"):
            for p in sections[sec_name]:
                for s in re.split(r"(?<=[.!?])\s+", p):
                    s_clean = s.strip()
                    if len(s_clean) < 45:
                        continue
                    st = _normalize_tokens_for_dedup(s_clean)
                    if len(st) < 5:
                        continue
                    max_ov = max(
                        (len(st & prev_s) / max(1, min(len(st), len(prev_s))) for prev_s in seen_sent_tokens),
                        default=0.0,
                    )
                    if max_ov < 0.72:
                        candidate_sents.append((max_ov, s_clean))
        candidate_sents.sort(key=lambda x: x[0])
        chosen: List[str] = []
        chosen_toks: List[set[str]] = []
        for _, sc in candidate_sents:
            st = _normalize_tokens_for_dedup(sc)
            if any(len(st & ct) / max(1, min(len(st), len(ct))) >= 0.50 for ct in chosen_toks):
                continue
            chosen.append(sc)
            chosen_toks.append(st)
            if len(chosen) >= 4:
                break
        if chosen:
            merged_clinical.append(" ".join(chosen))

    out_lines = [header] if header else [f"### [{display_tid}]"]
    out_lines.extend(temeller_kept)
    if merged_clinical:
        out_lines.append("#### Kanıta Dayalı Klinik Uygulama ve Yönetim")
        out_lines.extend(merged_clinical)
    return "\n\n".join(out_lines)


def _disp(tid: str) -> str:
    """B?l?m 10 kitapta B?l?m 9 olarak numaraland?r?l?r."""
    return f"9.{tid[3:]}" if str(tid).startswith("10.") else tid


def build_master_markdown(outline: Dict, accepted: Dict, source_map: Dict, pubmed_dir: Path) -> Tuple[str, int, int]:
    """(master_markdown, toplam_kelime, pubmed_makale_say?s?) d?nd?r?r."""
    lines = [
        f"# {outline['title']}",
        "",
        f"*?retim Tarihi: {datetime.now().strftime('%Y-%m-%d %H:%M')} ? Kaynak Veritaban? (Ryan's Retina 7th Ed. Vol 1?3) + NCBI PubMed Literat?r Sentezi*",
        "",
    ]
    total_words = 0
    for ch in outline["chapters"]:
        disp_ch = 9 if str(ch["id"]) == "10" else ch["id"]
        lines.extend([f"## B?L?M {disp_ch}: {ch['title']}", ""])
        for sec in ch["subsections"]:
            sec_title = sec["title"].replace("Fundus Otofagositoz", "Fundus Otofloresans")
            lines.extend([f"### {_disp(sec['id'])}. {sec_title}", ""])
            for t in sec["required_topics"]:
                entry = accepted[t["id"]]
                raw = Path(entry.get("local_path") or entry["manuscript_path"]).read_text(encoding="utf-8").strip()
                text = clean_and_deduplicate_topic_markdown(raw, _disp(t["id"]))
                total_words += len(text.split())
                lines.extend([text, ""])

    lines.extend(["## KAYNAK?A VE PUBMED L?TERAT?R D?Z?N?", ""])
    for sid, meta in source_map.get("sources", {}).items():
        lines.append(f"- **{sid}**: `{Path(meta['path']).name}`")
    lines.extend(["", "### Tamamlay?c? PubMed (NCBI) Makaleleri", ""])
    seen = set()
    if pubmed_dir.exists():
        for pm_file in sorted(pubmed_dir.glob("*.json")):
            for art in json.loads(pm_file.read_text(encoding="utf-8")).get("articles", []):
                pmid = art.get("pmid")
                if pmid and pmid not in seen:
                    seen.add(pmid)
                    lines.append(f"- **[PMID:{pmid}]** {art.get('title', '')} (*{art.get('journal', '')}*, {art.get('year', '')})")
    return "\n".join(lines), total_words, len(seen)
