"""
OCTA grafiği (eski octa_langgraph_pipeline.py'nin yerine): 3 katmanlı Reader -> Author(+MCQ) -> Senior Review.

Ana grafik                                     Alt grafik (chapter) — her OCTA bölümü için
----------                                     -------------------------------------------
START -> prepare (evidence-package planları)     START -> existing ── geçerli modül varsa ──> END
      ==Send==> chapter x N (paralel)                     -> reader    (Flash, kaynak parçaları paralel)
      -> render (sözleşme PDF + doğrulama) -> END         -> author    (Pro, JSON şema)
                                                          -> questions (alt başlık başına MCQ)
                                                          -> review    (Senior; düşük puan -> editor/interrupt)
                                                          -> save -> END

Eski sürümde 12 bölümün TAMAMI tek bir düğümde işleniyordu: 11. bölümde hata = her şey baştan.
Artık her bölüm ayrı bir dal; checkpoint sayesinde yalnızca hatalı dal tekrar çalışır.
"""

from __future__ import annotations

import json
import operator
import os
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Any, Dict, List, Literal, Optional, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import Send, interrupt

from ..core import RETRY, emit, store
from ..llm import ask
from ..prompting import load_prompt
from ..settings import PATHS, MODELS
from ..safety import fingerprint, file_hash, PIPELINE_VERSION

BOOK = "octa"
PROD_DIR = PATHS.octa_root / "production"
AWS_DIR = PATHS.octa_root / "production-aws"
LOCAL_OUT = PATHS.output / "octa"
STEMS_NS = ("octa", "stems")


def _h():
    """OCTA alan yardımcıları (production_worker'a bağımlı) — yalnızca gerektiğinde yüklenir."""
    from . import octa_helpers
    return octa_helpers


# ============================================================================
# Durumlar
# ============================================================================

class OctaInput(TypedDict, total=False):
    chapters: List[str]     # boş = hepsi; ör. ["c05", "c06"]
    human_review: bool      # True -> senior puanı min_score altındaysa editör onayı bekle
    render: bool            # True (varsayılan) -> sonunda sözleşme PDF'ini üret/doğrula


class OctaState(OctaInput, total=False):
    evidence_path: str
    chapter_ids: List[str]
    completed: Annotated[List[str], operator.add]
    verification_report: Dict[str, Any]


class ChapterInput(TypedDict, total=False):
    cid: str
    evidence_path: str
    human_review: bool


class ChapterOutput(TypedDict, total=False):
    completed: Annotated[List[str], operator.add]


class ChapterState(ChapterInput, ChapterOutput, total=False):
    already_valid: bool
    notes: List[Dict[str, Any]]
    authored: Dict[str, Any]
    questions: List[Dict[str, Any]]
    critique: Dict[str, Any]
    approved: bool
    editor_note: str


# ============================================================================
# Yardımcılar
# ============================================================================

def read_json(path: Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


@lru_cache(maxsize=2)
def _package(evidence_path: str) -> Dict[str, Any]:
    return read_json(Path(evidence_path))


def _plan(state) -> Dict[str, Any]:
    return next(p for p in _package(state["evidence_path"])["plans"] if p["id"] == state["cid"])


def _subset_ev(state) -> Dict[str, Any]:
    ev = _package(state["evidence_path"])["evidence"]
    return {eid: ev[eid] for eid in _plan(state)["evidence_ids"]}


def _section_words(sec) -> int:
    return sum(len(p["text"].split()) for p in sec["paragraphs"])


def _validate_full(module: Dict[str, Any], plan: Dict[str, Any], subset_ev: Dict[str, Any]) -> None:
    h = _h()
    h.validate_module(module["authored"], plan, subset_ev)
    for sec in module["authored"]["sections"]:
        sec_qs = [q for q in module["questions"] if q["heading_id"] == sec["id"]]
        h.validate_questions({"questions": sec_qs}, sec["id"], h.question_minimum(_section_words(sec)), subset_ev)


def _register_stems(questions: List[Dict[str, Any]]) -> None:
    st, norm = store(), _h().norm
    for q in questions:
        st.put(STEMS_NS, norm(q["stem"]), {"heading_id": q["heading_id"]})


def _known_stems() -> set:
    return {i.key for i in store().search(STEMS_NS, limit=100_000)}


# ============================================================================
# ANA GRAFİK
# ============================================================================

def node_prepare(state: OctaState) -> Dict:
    pkg_path = PROD_DIR / "evidence-package.json"
    pkg = read_json(pkg_path)
    wanted = set(state.get("chapters") or [])
    cids = [p["id"] for p in pkg["plans"] if not wanted or p["id"] in wanted]
    emit(f"OCTA: {len(cids)} bölüm işlenecek -> {', '.join(cids)}")
    return {"evidence_path": str(pkg_path), "chapter_ids": cids}


def route_prepare(state: OctaState):
    return [Send("chapter", {"cid": c, "evidence_path": state["evidence_path"],
                             "human_review": bool(state.get("human_review"))}) for c in state["chapter_ids"]]


def node_render(state: OctaState) -> Dict:
    if state.get("render") is False:
        return {}
    _h()  # OCTA paketini sys.path'e ekler
    from production_worker import render as contract_render, verify as contract_verify

    pkg = _package(state["evidence_path"])
    modules = [read_json(PROD_DIR / "modules" / f"{p['id']}.json") for p in pkg["plans"]]
    out = contract_render({"evidence_path": state["evidence_path"], "modules": modules})
    report = contract_verify({"report": out["report"]})["report"]
    emit(f"Sözleşme PDF doğrulandı: {report.get('pdf')}")
    return {"verification_report": report}


# ============================================================================
# ALT GRAFİK (tek bölüm)
# ============================================================================

def _chapter_fingerprint(state):
    return fingerprint(PIPELINE_VERSION, file_hash(state["evidence_path"]), _plan(state),
                       {name: file_hash(PATHS.prompts / f"octa/{name}.md")
                        for name in ("reader", "author", "mcq", "senior_review")},
                       MODELS.fast, MODELS.writer, MODELS.reviewer)


def node_existing(state: ChapterState) -> Dict:
    """Daha önce üretilmiş ve doğrulamadan geçen modül varsa tekrar üretme."""
    cid = state["cid"]
    path = PROD_DIR / "modules" / f"{cid}.json"
    if not path.exists():
        return {"already_valid": False}
    try:
        mod = read_json(path)
        if mod.get("review_status") != "approved" or mod.get("pipeline_fingerprint") != _chapter_fingerprint(state):
            return {"already_valid": False}
        _validate_full(mod, _plan(state), _subset_ev(state))
    except Exception as exc:
        emit(f"{cid}: mevcut modül yeniden üretilecek ({exc})")
        return {"already_valid": False}
    _register_stems(mod["questions"])
    save_json(LOCAL_OUT / "modules" / f"{cid}.json", mod)
    emit(f"{cid}: mevcut modül doğrulandı ({len(mod['questions'])} soru)")
    return {"already_valid": True, "completed": [cid]}


def route_existing(state: ChapterState) -> Literal["reader", "__end__"]:
    return END if state.get("already_valid") else "reader"


def node_reader(state: ChapterState) -> Dict:
    """Katman 1: Her kaynak `chunk_chars` uzunluğunda parçalanır ve paralel okunur."""
    cid, plan, h = state["cid"], _plan(state), _h()
    for p in (PROD_DIR / "notes" / f"{cid}.json", AWS_DIR / "notes" / f"{cid}.json", LOCAL_OUT / "notes" / f"{cid}.json"):
        if p.exists():
            cached = read_json(p)
            if not isinstance(cached, dict) or cached.get("pipeline_fingerprint") != _chapter_fingerprint(state):
                continue
            notes = cached["notes"]
            emit(f"{cid}: hazır okuyucu notları kullanılıyor ({p.parent.parent.name})")
            return {"notes": notes}

    ev = _package(state["evidence_path"])["evidence"]
    step = int(load_prompt("octa/reader").meta.get("chunk_chars", 36000))
    tasks = []
    for eid in plan["evidence_ids"]:
        text = ev[eid]["text"]
        for n, start in enumerate(range(0, len(text), step)):
            tasks.append((eid, n, start, min(start + step, len(text))))
    emit(f"{cid}: {len(tasks)} kaynak parçası okunuyor")

    def read_one(task):
        eid, n, start, end = task
        chunk_ev = {eid: {**ev[eid], "text": ev[eid]["text"][start:end]}}
        raw = ask("octa/reader", book=BOOK, unit=f"{cid}-{eid}-{n}", chapter_title=plan["title"], chapter_id=cid,
                  data={"evidence_id": eid, "chunk_index": n, "text": chunk_ev[eid]["text"]})
        if isinstance(raw, list):
            raw = {"facts": raw, "limitations": [], "irrelevant_span": False}
        facts = []
        for f in raw.get("facts") or []:
            if isinstance(f, dict) and h.norm(f.get("text", "")):
                sup = h.align_support(f.get("support"), chunk_ev)
                if sup:
                    facts.append({"text": h.norm(f["text"]), "support": sup})
        if not facts:
            raise ValueError(f"{eid}: kaynak parçasında doğrulanabilir alıntı bulunamadı.")
        lims = [h.norm(x) for x in (raw.get("limitations") or []) if h.norm(x)] or \
               [f"{eid} kaynağının yalnızca atanmış metin aralığı ({start}-{end} karakter) değerlendirilmiştir."]
        note = {"facts": facts, "limitations": lims, "irrelevant_span": False}
        h.validate_notes(note, chunk_ev)
        return note

    with ThreadPoolExecutor(max_workers=4) as pool:
        notes = list(pool.map(read_one, tasks))
    save_json(PROD_DIR / "notes" / f"{cid}.json", {"notes": notes, "pipeline_fingerprint": _chapter_fingerprint(state)})
    save_json(LOCAL_OUT / "notes" / f"{cid}.json", {"notes": notes, "pipeline_fingerprint": _chapter_fingerprint(state)})
    emit(f"{cid}: {sum(len(n['facts']) for n in notes)} desteklenmiş bulgu çıkarıldı")
    return {"notes": notes}


def node_author(state: ChapterState) -> Dict:
    cid, plan, subset, h = state["cid"], _plan(state), _subset_ev(state), _h()
    recovered = AWS_DIR / "attempts" / "c05-sol-author-ed585e038cab4053822b9900bdc36005" / "parsed.json"
    if cid == "c05" and recovered.exists() and not state.get("editor_note"):
        authored = h.normalize_authored_module(read_json(recovered)["result"]["schema"], plan, subset)
        h.validate_module(authored, plan, subset)
        emit("c05: önceki yazar taslağı kurtarıldı")
        return {"authored": authored}

    facts = [f for n in state["notes"] for f in n.get("facts", [])]
    max_facts = int(load_prompt("octa/author").meta.get("max_facts", 95))
    headings = " and ".join(f"{hd['id']} ('{hd['title']}')" for hd in plan["headings"][:2])
    data = {"plan": plan, "supported_facts_pool": facts[:max_facts],
            "source_metadata": {k: {kk: vv for kk, vv in v.items() if kk != "text"} for k, v in subset.items()}}
    if state.get("editor_note"):
        data["editor_instructions"] = state["editor_note"]
    raw = ask("octa/author", book=BOOK, unit=cid, chapter_title=plan["title"], chapter_id=cid, headings=headings,
              data=data)
    authored = h.normalize_authored_module(raw, plan, subset)
    h.validate_module(authored, plan, subset)   # geçersizse hata -> RetryPolicy yeniden yazdırır
    return {"authored": authored}


def node_questions(state: ChapterState) -> Dict:
    cid, plan, subset, h = state["cid"], _plan(state), _subset_ev(state), _h()
    authored = state["authored"]
    known = _known_stems()   # diğer bölümlerin (Store'daki) soru kökleri -> tekrar engeli
    all_qs: List[Dict[str, Any]] = []
    for sec in authored["sections"]:
        need = h.question_minimum(_section_words(sec))
        got: List[Dict[str, Any]] = []
        for attempt in range(2):   # 1. tur + eksik kalırsa tamamlama turu
            missing = need - len(got)
            if missing <= 0:
                break
            raw = ask("octa/mcq", book=BOOK, unit=f"{sec['id']}-{attempt}", required_count=missing + 2,
                      heading_id=sec["id"], heading_title=sec["title"], chapter_title=plan["title"],
                      avoid_stems=[q["stem"] for q in got][:40] or "yok",
                      data={"section": sec, "disagreements": authored.get("disagreements", [])})
            got.extend(h.normalize_questions_for_heading(raw, sec["id"], missing, subset, sec, known))
        got = got[:need]
        h.validate_questions({"questions": got}, sec["id"], need, subset)
        emit(f"{sec['id']}: {len(got)} soru")
        all_qs.extend(got)
    return {"questions": all_qs}


def node_review(state: ChapterState) -> Dict:
    cid, plan, authored, qs = state["cid"], _plan(state), state["authored"], state["questions"]
    critique = ask("octa/senior_review", book=BOOK, unit=cid, chapter_id=cid, chapter_title=plan["title"], data={
        "source_evidence": _subset_ev(state), "full_sections": authored["sections"], "all_questions": qs,
        "sections_summary": [{"id": s["id"], "word_count": _section_words(s), "table_rows_count": len(s["table_rows"]),
                              "cases_count": len(s["cases"])} for s in authored["sections"]],
        "disagreements": authored["disagreements"], "questions_count": len(qs), "sample_questions": qs[:4]})
    min_score = int(load_prompt("octa/senior_review").meta.get("min_score", 85))
    score = int(critique.get("clinical_quality_score", 0) or 0)
    approved = score >= min_score
    if not approved and not state.get("human_review"):
        raise ValueError(f"{cid}: klinik kalite puanı {score}/{min_score}; otomatik kabul engellendi.")
    emit(f"{cid}: senior puan {score}/100 -> {'kabul' if approved else 'editör onayı gerekli'}")
    return {"critique": critique, "approved": approved}


def route_review(state: ChapterState) -> Literal["save", "editor"]:
    return "save" if state.get("approved") else "editor"


def node_editor(state: ChapterState) -> Dict:
    decision = interrupt({"message": f"OCTA {state['cid']} senior puanı düşük: {state['critique'].get('clinical_quality_score')}",
                          "issues": state["critique"].get("issues", [])})
    if isinstance(decision, dict) and decision.get("revise"):
        emit(f"{state['cid']}: editör revizyon istedi -> yazar yeniden çalışacak")
        return {"approved": False, "editor_note": decision["revise"]}
    if decision != "approve" and not (isinstance(decision, dict) and decision.get("approve") is True):
        raise ValueError("Açık editör onayı gerekli.")
    return {"approved": True}


def route_editor(state: ChapterState) -> Literal["save", "author"]:
    return "save" if state.get("approved") else "author"


def node_save(state: ChapterState) -> Dict:
    if state.get("approved") is not True:
        raise ValueError("Onaylanmamış OCTA bölümü kaydedilemez.")
    cid = state["cid"]
    module = {**_plan(state), "authored": state["authored"], "questions": state["questions"],
              "review_status": "approved", "pipeline_fingerprint": _chapter_fingerprint(state)}
    _validate_full(module, _plan(state), _subset_ev(state))   # son deterministik kapı
    save_json(LOCAL_OUT / "reviews" / f"{cid}-senior-review.json", state.get("critique", {}))
    save_json(PROD_DIR / "modules" / f"{cid}.json", module)
    save_json(LOCAL_OUT / "modules" / f"{cid}.json", module)
    _register_stems(state["questions"])
    emit(f"✓ {cid} kaydedildi ({len(state['questions'])} soru, {len(state['authored']['disagreements'])} görüş ayrılığı)")
    return {"completed": [cid]}


# ============================================================================
# Grafik kurucular
# ============================================================================

def build_chapter() -> StateGraph:
    g = StateGraph(ChapterState, input_schema=ChapterInput, output_schema=ChapterOutput)
    g.add_node("existing", node_existing)
    g.add_node("reader", node_reader, retry_policy=RETRY)
    g.add_node("author", node_author, retry_policy=RETRY)
    g.add_node("questions", node_questions, retry_policy=RETRY)
    g.add_node("review", node_review, retry_policy=RETRY)
    g.add_node("editor", node_editor)
    g.add_node("save", node_save)
    g.add_edge(START, "existing")
    g.add_conditional_edges("existing", route_existing, ["reader", END])
    g.add_edge("reader", "author")
    g.add_edge("author", "questions")
    g.add_edge("questions", "review")
    g.add_conditional_edges("review", route_review, ["save", "editor"])
    g.add_conditional_edges("editor", route_editor, ["save", "author"])
    g.add_edge("save", END)
    return g


def build() -> StateGraph:
    g = StateGraph(OctaState, input_schema=OctaInput)
    g.add_node("prepare", node_prepare)
    g.add_node("chapter", build_chapter().compile())
    g.add_node("render", node_render, retry_policy=RETRY)
    g.add_edge(START, "prepare")
    g.add_conditional_edges("prepare", route_prepare, ["chapter"])
    g.add_edge("chapter", "render")
    g.add_edge("render", END)
    return g


DEFAULT_INPUT: OctaInput = {"chapters": [], "human_review": False, "render": True}
