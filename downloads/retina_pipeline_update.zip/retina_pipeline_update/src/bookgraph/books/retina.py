"""
RETİNA grafiği (eski retina_pubmed_graph.py'nin yerine): Anahat (outline) + DB PDF sayfaları + PubMed.

Ana grafik                                     Alt grafik (topic) — her konu başlığı için
----------                                     -----------------------------------------
START -> prepare (anahat + eski çıktıları senk.)  START -> pages   (source-map'teki PDF sayfaları, önbellekli)
      -> plan    (yazılmamış konular)                    -> pubmed  (NCBI E-utilities, önbellekli)
      ==Send==> topic x N (paralel)                      -> author  (prompt: retina/author_facet, yön yön)
      -> assemble (hepsi bittiyse PDF) -> END            -> commit  (manuscript + accepted.json) -> END

Eski sürümde konular tek tek bir döngüde yazılıyordu (49 konu x 5 adım ≈ 250 süper-adım, Studio'da
recursion_limit=25'e takılıyordu). Artık tüm bekleyen konular tek süper-adımda paralel dağıtılır.
"""

from __future__ import annotations

import hashlib
import json
import operator
import os
import re
import shutil
import threading
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, Dict, List, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import Send

from ..core import CACHE, RETRY, emit
from ..llm import ask
from ..prompting import load_prompt
from ..quality import PDF_OR_PMID_CITE, ensure_first_line, ensure_paragraph_citations
from ..settings import PATHS, MODELS
from ..safety import fingerprint, file_hash, PIPELINE_VERSION
from pydantic import BaseModel, Field

BOOK = "retina"
_json_lock = threading.Lock()

# --- Yollar (hepsi .env ile değiştirilebilir: RETINA_LAB_DIR, OUTPUT_DIR, STORAGE_DIR) ---
LAB = PATHS.retina_lab
OUTLINE_MD = LAB / "outline-clinical-v2.md"
SOURCE_MAP = LAB / "source-map-v3.json"
LAB_PILOT_DIR = LAB / "chapter-1-1-v2" / "manuscript"
LAB_FULLBOOK = LAB / "full-book-v2"
LAB_MANUSCRIPT = LAB_FULLBOOK / "manuscript"
LAB_ACCEPTED = LAB_FULLBOOK / "accepted.json"
LOCAL_MANUSCRIPT = PATHS.output / "manuscript"
LOCAL_ACCEPTED = PATHS.storage / "retina_accepted.json"
COMPILED = PATHS.output / "compiled"
LOCAL_PDF = COMPILED / "Retina_ve_Vitreus_Klinik_Yaklasim.pdf"
LOCAL_MASTER_MD = COMPILED / "Retina_ve_Vitreus_Klinik_Yaklasim_Master.md"
LAB_PDF = LAB_FULLBOOK / "Retina_ve_Vitreus_Klinik_Yaklasim_TASLAK.pdf"
MIN_TOPIC_WORDS = 250


# ============================================================================
# Durumlar
# ============================================================================

class RetinaInput(TypedDict, total=False):
    limit: int                 # 0 = tüm bekleyen konular
    assemble: bool             # True (varsayılan) -> hepsi bitince PDF derle


class RetinaState(RetinaInput, total=False):
    outline: Dict[str, Any]
    topic_order: List[str]
    jobs: List[Dict[str, Any]]
    completed: Annotated[List[str], operator.add]
    pdf_result: Dict[str, Any]


class TopicInput(TypedDict, total=False):
    tid: str
    title: str
    book_title: str


class TopicOutput(TypedDict, total=False):
    completed: Annotated[List[str], operator.add]


class TopicState(TopicInput, TopicOutput, total=False):
    db_pages: List[Dict[str, Any]]
    pubmed_articles: List[Dict[str, Any]]
    draft: str
    approved: bool
    review: Dict[str, Any]


# ============================================================================
# Yardımcılar
# ============================================================================

def sha256_str(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _load_json(path: Path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default


def _save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _update_accepted(path: Path, tid: str, entry: Dict) -> None:
    """Paralel dallar aynı JSON'a yazdığı için oku-değiştir-yaz işlemi kilit altında yapılır."""
    with _json_lock:
        data = _load_json(path, {})
        data[tid] = entry
        _save_json(path, data)


def parse_outline_markdown(md_path: Path = OUTLINE_MD) -> Dict:
    if not md_path.is_file():
        raise FileNotFoundError(f"Outline dosyası bulunamadı: {md_path} (RETINA_LAB_DIR ayarını kontrol edin)")
    raw = md_path.read_text(encoding="utf-8")
    title, chapters = "RETİNA VE VİTREUS: KLİNİK YAKLAŞIM", []
    ch_re = re.compile(r"^##\s+BÖLÜM\s+(\d+):\s*(.+)$")
    sub_re = re.compile(r"^###\s+(\d+\.\d+)\.\s*(.+)$")
    topic_re = re.compile(r"^-\s+\[(\d+\.\d+\.\d+)\]\s*(.+)$")
    for line in raw.splitlines():
        s = line.strip()
        if s.startswith("# ") and not s.startswith("## "):
            title = s[2:].strip()
        elif m := ch_re.match(s):
            chapters.append({"id": m.group(1), "title": m.group(2).strip(), "subsections": []})
        elif m := sub_re.match(s):
            chapters[-1]["subsections"].append({"id": m.group(1), "title": m.group(2).strip(), "required_topics": []})
        elif m := topic_re.match(s):
            chapters[-1]["subsections"][-1]["required_topics"].append({"id": m.group(1), "text": m.group(2).strip()})
    topics = [t for c in chapters for sub in c["subsections"] for t in sub["required_topics"]]
    return {"title": title, "outline_path": str(md_path), "outline_sha256": sha256_str(raw),
            "total_chapters": len(chapters), "total_topics": len(topics), "chapters": chapters}


def _iter_topics(outline: Dict):
    for c in outline["chapters"]:
        for s in c["subsections"]:
            for t in s["required_topics"]:
                yield t


def _pipeline_fingerprint():
    source_map = _load_json(SOURCE_MAP, {})
    source_hashes = {key: file_hash(value.get("path", ""))
                     for key, value in source_map.get("sources", {}).items()}
    return fingerprint(PIPELINE_VERSION, file_hash(SOURCE_MAP), file_hash(OUTLINE_MD),
                       source_hashes, file_hash(PATHS.prompts / "retina/author_facet.md"),
                       file_hash(PATHS.prompts / "retina/reviewer.md"), MODELS.writer, MODELS.reviewer)


def _is_done(entry):
    if not entry or entry.get("review_status") != "approved" or entry.get("pipeline_fingerprint") != _pipeline_fingerprint():
        return False
    p = Path(entry.get("local_path") or entry.get("manuscript_path", ""))
    return (p.is_file() and sha256_str(p.read_text(encoding="utf-8")) == entry.get("sha256")
            and len(p.read_text(encoding="utf-8").split()) >= MIN_TOPIC_WORDS)


# ============================================================================
# ANA GRAFİK DÜĞÜMLERİ
# ============================================================================

def node_prepare(state: RetinaState) -> Dict:
    """Anahattı yükler, pilot ve laboratuvar çıktılarını yerel klasöre senkronize eder."""
    LOCAL_MANUSCRIPT.mkdir(parents=True, exist_ok=True)
    LAB_MANUSCRIPT.mkdir(parents=True, exist_ok=True)
    outline = parse_outline_markdown()

    accepted = _load_json(LAB_ACCEPTED, {})
    accepted.update(_load_json(LOCAL_ACCEPTED, {}))
    for tid in ("1.1.1", "1.1.2", "1.1.3", "1.1.4"):
        pilot, local = LAB_PILOT_DIR / f"{tid}.md", LOCAL_MANUSCRIPT / f"{tid}.md"
        if pilot.is_file():
            txt = pilot.read_text(encoding="utf-8")
            if not local.is_file():
                local.write_text(txt, encoding="utf-8")
            accepted[tid] = {"manuscript_path": str(pilot), "local_path": str(local),
                             "source_ids": sorted(set(PDF_OR_PMID_CITE.findall(txt))),
                             "words": len(txt.split()), "sha256": sha256_str(txt)}
    for tid, meta in accepted.items():
        src, local = Path(meta.get("manuscript_path", "")), LOCAL_MANUSCRIPT / f"{tid}.md"
        if src.is_file() and not local.is_file():
            shutil.copy2(src, local)
            meta["local_path"] = str(local)
    _save_json(LOCAL_ACCEPTED, accepted)

    order = [t["id"] for t in _iter_topics(outline)]
    emit(f"Anahat: {outline['total_chapters']} bölüm, {len(order)} konu | tamamlanan: {sum(_is_done(accepted.get(t)) for t in order)}")
    return {"outline": outline, "topic_order": order}


def node_plan(state: RetinaState) -> Dict:
    accepted = _load_json(LOCAL_ACCEPTED, {})
    pending = [t for t in _iter_topics(state["outline"]) if not _is_done(accepted.get(t["id"]))]
    limit = int(state.get("limit") or 0)
    if limit > 0:
        pending = pending[:limit]
    emit(f"Bekleyen konu: {len(pending)} -> paralel dağıtılıyor")
    return {"jobs": [{"tid": t["id"], "title": t["text"], "book_title": state["outline"]["title"]} for t in pending]}


def route_plan(state: RetinaState):
    if state.get("jobs"):
        return [Send("topic", job) for job in state["jobs"]]
    return "assemble"


def node_assemble(state: RetinaState) -> Dict:
    """Tüm konular hazırsa master markdown + yayınevi PDF'ini üretir ve PDF'i doğrular."""
    if state.get("assemble") is False:
        emit("assemble=False -> PDF derlemesi atlandı")
        return {}
    accepted = _load_json(LOCAL_ACCEPTED, {})
    missing = [tid for tid in state["topic_order"] if not _is_done(accepted.get(tid))]
    if missing:
        emit(f"PDF derlenmedi: {len(missing)} konu eksik ({', '.join(missing[:8])}...). Tekrar `run retina` çalıştırın.")
        return {}

    from .retina_text import build_master_markdown
    outline = state["outline"]
    COMPILED.mkdir(parents=True, exist_ok=True)
    master, total_words, pmids = build_master_markdown(outline, accepted, _load_json(SOURCE_MAP, {}), PATHS.storage / "pubmed")
    LOCAL_MASTER_MD.write_text(master, encoding="utf-8")

    from pro_pdf_publisher import build_publishing_grade_pdf  # kökteki yayınevi dizgi motoru
    pdf_path = build_publishing_grade_pdf()
    shutil.copy2(pdf_path, LOCAL_PDF)
    if LAB_FULLBOOK.is_dir():
        shutil.copy2(pdf_path, LAB_PDF)

    import pymupdf
    with pymupdf.open(LOCAL_PDF) as doc:
        pages, text = len(doc), "\n".join(p.get_text() for p in doc)
    disp = lambda tid: f"9.{tid[3:]}" if tid.startswith("10.") else tid  # noqa: E731  (Bölüm 10 -> 9)
    not_in_pdf = [tid for tid in state["topic_order"] if not re.search(r"(?<![\d.])" + re.escape(disp(tid)) + r"(?![\d.])", text)]
    if not_in_pdf:
        raise ValueError(f"PDF içinde bulunamayan başlık ID'leri: {not_in_pdf}")

    from .. import usage
    result = {"status": "completed_pdf_reference_checked", "title": outline["title"], "total_words": total_words,
              "pdf_pages": pages, "pubmed_articles_indexed": pmids, "local_pdf_path": str(LOCAL_PDF),
              "master_markdown_path": str(LOCAL_MASTER_MD), "spent_usd": round(usage.spent(BOOK), 4),
              "finished_at": datetime.now().isoformat(timespec="seconds")}
    _save_json(PATHS.storage / "final_book_status.json", result)
    emit(f"PDF hazır: {LOCAL_PDF} ({pages} sayfa, {total_words:,} kelime)")
    return {"pdf_result": result}


# ============================================================================
# ALT GRAFİK DÜĞÜMLERİ (tek konu)
# ============================================================================

def node_pages(state: TopicState) -> Dict:
    tid = state["tid"]
    cached = LAB_FULLBOOK / "source-text" / f"{tid}.json"
    data = _load_json(cached, {})
    if data.get("pages") and data.get("pipeline_fingerprint") == _pipeline_fingerprint():
        return {"db_pages": data["pages"]}

    import pymupdf
    source_map = _load_json(SOURCE_MAP, {})
    topic_map = source_map.get("topics", {}).get(tid)
    if not topic_map:
        raise ValueError(f"{tid} için source-map içinde eşleşme yok: {SOURCE_MAP}")
    pages = []
    for item in topic_map["pages"]:
        sid, page_num = item["source_id"], item["pdf_page"]
        with pymupdf.open(source_map["sources"][sid]["path"]) as doc:
            raw = doc[page_num - 1].get_text(sort=True)
        cleaned = re.sub(r"Downloaded for Anonymous User.*?All rights reserved\.", "", raw, flags=re.S).strip()
        pages.append({"citation": f"[{sid}:pdf{page_num}]", "source_id": sid, "page": page_num,
                      "text": cleaned, "hash": sha256_str(cleaned)})
    _save_json(cached, {"topic": tid, "pages": pages, "mapping_rationale": topic_map.get("rationale", ""),
                        "confidence": topic_map.get("confidence", "unknown"), "pipeline_fingerprint": _pipeline_fingerprint()})
    emit(f"{tid}: {len(pages)} PDF sayfası çıkarıldı")
    return {"db_pages": pages}


def node_pubmed(state: TopicState) -> Dict:
    from pubmed_client import fetch_pubmed_evidence  # kökteki NCBI istemcisi (storage/pubmed önbellekli)
    arts = fetch_pubmed_evidence(topic_id=state["tid"], topic_title=state["title"], max_articles=5)
    if LAB_FULLBOOK.is_dir():
        _save_json(LAB_FULLBOOK / "pubmed" / f"{state['tid']}.json",
                   {"topic_id": state["tid"], "title": state["title"], "articles": arts})
    emit(f"{state['tid']}: {len(arts)} PubMed makalesi")
    return {"pubmed_articles": arts}


def node_author(state: TopicState) -> Dict:
    """Prompt dosyasındaki `facets` listesini sırayla yazar; her yön ayrı dosyada önbelleklenir."""
    tid, title = state["tid"], state["title"]
    db_pages, arts = state.get("db_pages", []), state.get("pubmed_articles", [])
    db_c, pm_c = [p["citation"] for p in db_pages], [a["citation"] for a in arts]
    valid = db_c + pm_c
    if not valid:
        raise ValueError("Kanıt yok; retina yazarlığı durduruldu.")
    fallback = db_c[0] if db_c else pm_c[0]
    prompt = load_prompt("retina/author_facet")
    min_words = int(prompt.meta.get("min_words", 260))

    sections = []
    for facet in prompt.meta["facets"]:
        cache_key = fingerprint(_pipeline_fingerprint(), tid, title, facet, db_pages, arts)
        cache = PATHS.storage / "raw_facets" / f"{tid}-{facet['key']}-{cache_key}.json"
        cached = _load_json(cache, {})
        if cached.get("text") and len(cached["text"].split()) >= min_words:
            sections.append(cached["text"])
            continue
        header = facet["header"].format(tid=tid, title=title)
        emit(f"{tid}/{facet['key']} yazılıyor...")
        raw = ask("retina/author_facet", book=BOOK, unit=f"{tid}-{facet['key']}",
                  book_title=state.get("book_title", ""), tid=tid, title=title, header_line=header,
                  focus=facet["focus"], db_citations=db_c, pm_citations=pm_c,
                  example_citation=pm_c[0] if pm_c else fallback,
                  db_context="\n\n".join(f"{p['citation']}\n{p['text']}" for p in db_pages),
                  pubmed_context="\n\n".join(f"{a['citation']}\n{a['text']}" for a in arts))
        text = ensure_paragraph_citations(ensure_first_line(raw, header), valid, fallback)
        if len(text.split()) < min_words:
            raise ValueError(f"{tid}/{facet['key']} çok kısa ({len(text.split())} kelime) -> RetryPolicy tekrar dener")
        _save_json(cache, {"topic_id": tid, "facet": facet["key"], "words": len(text.split()), "text": text})
        sections.append(text)
    return {"draft": "\n\n".join(sections).strip() + "\n"}


class TopicReview(BaseModel):
    approved: bool
    unsupported_claims: List[str] = Field(default_factory=list)
    notes: str = ""


def node_review(state):
    review = ask("retina/reviewer", book=BOOK, unit=state["tid"] + "-review", schema=TopicReview,
                 draft=state["draft"], db_pages=state.get("db_pages", []),
                 pubmed_articles=state.get("pubmed_articles", []))
    if not review.approved or review.unsupported_claims:
        _save_json(PATHS.storage / "review_required" / f"{state['tid']}.json",
                   {"draft": state["draft"], "review": review.model_dump()})
        raise ValueError("Retina konusu kaynak incelemesinde reddedildi; taslak review_required içinde korundu.")
    return {"approved": True, "review": review.model_dump()}


def node_commit(state: TopicState) -> Dict:
    if state.get("approved") is not True:
        raise ValueError("Retina konusu kaynak incelemesinden onay almadan kaydedilemez.")
    tid, text = state["tid"], state["draft"]
    local = LOCAL_MANUSCRIPT / f"{tid}.md"
    local.parent.mkdir(parents=True, exist_ok=True)
    local.write_text(text, encoding="utf-8")
    lab = LAB_MANUSCRIPT / f"{tid}.md"
    if LAB_MANUSCRIPT.is_dir():
        lab.write_text(text, encoding="utf-8")
    cites = sorted(set(PDF_OR_PMID_CITE.findall(text)))
    entry = {"manuscript_path": str(lab if lab.is_file() else local), "local_path": str(local), "source_ids": cites,
             "words": len(text.split()), "sha256": sha256_str(text),
             "pubmed_enriched": any(c.startswith("[PMID:") for c in cites),
             "review_status": "approved", "review": state["review"],
             "pipeline_fingerprint": _pipeline_fingerprint()}
    _update_accepted(LOCAL_ACCEPTED, tid, entry)
    if LAB_ACCEPTED.parent.is_dir():
        _update_accepted(LAB_ACCEPTED, tid, entry)
    emit(f"✓ {tid} kaydedildi ({entry['words']} kelime, {len(cites)} atıf)")
    return {"completed": [tid]}


# ============================================================================
# Grafik kurucular
# ============================================================================

def build_topic() -> StateGraph:
    g = StateGraph(TopicState, input_schema=TopicInput, output_schema=TopicOutput)
    g.add_node("pages", node_pages, retry_policy=RETRY)
    g.add_node("pubmed", node_pubmed, retry_policy=RETRY, cache_policy=CACHE)
    g.add_node("author", node_author, retry_policy=RETRY)
    g.add_node("review", node_review, retry_policy=RETRY)
    g.add_node("commit", node_commit)
    g.add_edge(START, "pages")
    g.add_edge("pages", "pubmed")
    g.add_edge("pubmed", "author")
    g.add_edge("author", "review")
    g.add_edge("review", "commit")
    g.add_edge("commit", END)
    return g


def build() -> StateGraph:
    g = StateGraph(RetinaState, input_schema=RetinaInput)
    g.add_node("prepare", node_prepare)
    g.add_node("plan", node_plan)
    g.add_node("topic", build_topic().compile())
    g.add_node("assemble", node_assemble)
    g.add_edge(START, "prepare")
    g.add_edge("prepare", "plan")
    g.add_conditional_edges("plan", route_plan, ["topic", "assemble"])
    g.add_edge("topic", "assemble")
    g.add_edge("assemble", END)
    return g


DEFAULT_INPUT: RetinaInput = {"limit": 0, "assemble": True}
