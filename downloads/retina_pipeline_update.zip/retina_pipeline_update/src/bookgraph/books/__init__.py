"""
Kitap kayıt defteri. Yeni bir kitap grafiği eklemek için:
  1. bookgraph/books/<ad>.py içinde `build()` (StateGraph döndürür) ve `DEFAULT_INPUT` tanımlayın
  2. Aşağıdaki BOOKS sözlüğüne ekleyin
  3. langgraph.json'a `./bookgraph/graphs.py:<ad>` satırını ekleyin
"""

from importlib import import_module

BOOKS = {
    "kitap": ("bookgraph.books.kitap", "Tarif (recipe) tabanlı uzun kitap: müfredat -> paralel alt-bölüm yazımı (RAG + editör döngüsü)"),
    "retina": ("bookgraph.books.retina", "Retina ve Vitreus: anahat + DB PDF sayfaları + PubMed -> yayınevi PDF"),
    "octa": ("bookgraph.books.octa", "OCTA: Reader (Flash) -> Author + MCQ (Pro) -> Senior Review -> sözleşme PDF"),
}


def get_book(name: str):
    if name not in BOOKS:
        raise SystemExit(f"Bilinmeyen kitap '{name}'. Seçenekler: {', '.join(BOOKS)}")
    return import_module(BOOKS[name][0])
