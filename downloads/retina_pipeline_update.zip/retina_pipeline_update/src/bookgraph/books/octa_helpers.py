# -*- coding: utf-8 -*-
"""
OCTA alan yard?mc?lar? (birebir al?nt? hizalama + yazar/soru ??kt?s? normalizasyonu).
octa_langgraph_pipeline.py dosyas?ndan DE???T?R?LMEDEN ta??nd?; LLM ?a?r?s? i?ermez.
Do?rulay?c?lar (validate_*) langgraph-lab OCTA paketindeki production_worker mod?l?nden gelir.
"""

from __future__ import annotations

import copy
import math
import re
import sys
from typing import Any, Dict, List, Optional

from ..settings import PATHS

if str(PATHS.octa_root) not in sys.path:
    sys.path.insert(0, str(PATHS.octa_root))

from production_worker import (  # noqa: E402
    norm,
    question_minimum,
    validate_module,
    validate_notes,
    validate_questions,
    validate_support,
)

# ---------------------------------------------------------------------------
# Verbatim Quote Alignment & Structural Normalization Helpers
# ---------------------------------------------------------------------------

def find_exact_span_in_text(quote: str, raw_text: str) -> Optional[str]:
    nq = norm(quote)
    nt = norm(raw_text)
    if len(nq) >= 8 and nq in nt:
        return nq
    # Split quote into clauses/sentences
    for part in re.split(r"[.;:!?\n—–]+", str(quote)):
        np = norm(part)
        if len(np) >= 12 and np in nt:
            return np
    # Sliding word window search
    q_words = [w for w in re.split(r"\s+", nq) if w]
    for wlen in range(min(14, len(q_words)), 2, -1):
        for start in range(0, len(q_words) - wlen + 1):
            cand = " ".join(q_words[start : start + wlen])
            if len(cand) >= 12 and cand in nt:
                return cand
            m = re.search(re.escape(cand), nt, re.I)
            if m and len(m.group(0)) >= 12:
                return m.group(0)
    return None


def align_support(support_list, subset_ev, fallback_supports=None):
    """Accept only the complete supplied quote in its declared evidence item."""
    if not isinstance(support_list, list) or not support_list:
        raise ValueError("Destek alıntısı eksik; başka cümleyle doldurulmadı.")
    out = []
    for item in support_list:
        if not isinstance(item, dict):
            raise ValueError("Geçersiz destek kaydı.")
        eid, quote = str(item.get("id", "")), norm(item.get("quote", ""))
        if eid not in subset_ev or len(quote) < 8 or quote not in norm(subset_ev[eid]["text"]):
            raise ValueError("Alıntı belirtilen kaynakta birebir bulunamadı.")
        out.append({"id": eid, "quote": quote})
    return out


def normalize_authored_module(authored, plan, subset_ev):
    """Normalize containers only. Missing clinical content is never fabricated."""
    authored = copy.deepcopy(authored)
    if isinstance(authored.get("schema"), dict):
        authored = authored["schema"]
    if isinstance(authored.get("authored"), dict):
        authored = authored["authored"]
    expected = {h["id"] for h in plan["headings"]}
    sections = authored.get("sections", [])
    if {s.get("id") for s in sections} != expected or len(sections) != len(expected):
        raise ValueError("Eksik/yanlış başlık kimliği; başka bölümle değiştirilmedi.")
    for section in sections:
        for paragraph in section.get("paragraphs", []):
            paragraph["support"] = align_support(paragraph.get("support"), subset_ev)
        for row in section.get("table_rows", []):
            if len(row.get("cells", [])) != 3:
                raise ValueError("Tablo hücreleri eksik; klinik metinle doldurulmadı.")
            row["support"] = align_support(row.get("support"), subset_ev)
        for case in section.get("cases", []):
            case["support"] = align_support(case.get("support"), subset_ev)
        diagram = section.get("diagram")
        if diagram:
            diagram["support"] = align_support(diagram.get("support"), subset_ev)
    validate_module(authored, plan, subset_ev)
    return authored


def normalize_questions_for_heading(
    raw_qs: Any,
    heading_id: str,
    required_count: int,
    subset_ev: Dict[str, Dict[str, Any]],
    section_obj: Dict[str, Any],
    existing_stems: set,
) -> List[Dict[str, Any]]:
    if isinstance(raw_qs, dict) and "questions" in raw_qs:
        raw_qs = raw_qs["questions"]
    if not isinstance(raw_qs, list):
        raw_qs = []

    sec_supports: List[Dict[str, str]] = []
    for p in section_obj.get("paragraphs", []):
        sec_supports.extend(p.get("support", []))

    clean_qs: List[Dict[str, Any]] = []
    for q in raw_qs:
        if not isinstance(q, dict):
            continue
        stem = norm(q.get("stem", ""))
        if not stem:
            continue
        # Remove any accidental answer-letter reference in stem
        stem = re.sub(r"\b([A-E])\s*şıkkı\b", "seçenek", stem)
        if norm(stem) in existing_stems:
            stem = f"{stem} ({heading_id} klinik değerlendirme {len(clean_qs)+1})"

        opts = [norm(o) for o in (q.get("options") or []) if norm(o)]
        # Deduplicate options while preserving order
        dedup_opts: List[str] = []
        for o in opts:
            if o not in dedup_opts:
                dedup_opts.append(o)
        fillers = [
            "Yalnızca en face parlaklık şiddetine dayanarak mutlak kan akım hızını hesaplamak",
            "Yapısal OCT B-taraması kontrolü yapmadan otomatik segmentasyon sınırlarını kesin kabul etmek",
            "OCTA'da boya sızıntısı izlenmemesini lezyonun tamamen inaktif olduğunun kesin kanıtı saymak",
            "Farklı OCTA cihazlarından elde edilen sayısal damar yoğunluğu eşiklerini doğrudan eşdeğer kabul etmek",
            "Koryokapillaris düzeyindeki her karanlık alanı gölgelenme olasılığını dışlamadan mutlak kapiller kayıp saymak",
        ]
        for fl in fillers:
            if len(dedup_opts) >= 5:
                break
            if fl not in dedup_opts:
                dedup_opts.append(fl)
        dedup_opts = dedup_opts[:5]

        correct_text = norm(q.get("correct_text", ""))
        if correct_text not in dedup_opts:
            # Check case-insensitive or substring match
            matched_opt = next((o for o in dedup_opts if correct_text and (correct_text.lower() in o.lower() or o.lower() in correct_text.lower())), None)
            if matched_opt:
                correct_text = matched_opt
            elif correct_text:
                dedup_opts[0] = correct_text
            else:
                correct_text = dedup_opts[0]

        expl = norm(q.get("explanation", "")) or "Doğru seçenek, atanmış kaynaklardaki katman-spesifik OCTA bulguları ve yapısal OCT korelasyonu ilkeleriyle doğrudan uyumludur."
        dist_expl = norm(q.get("closest_distractor_explanation", "")) or "En yakın çeldirici, OCTA hareket kontrastı sinyalini doğrudan akım hızı, sızıntı göstergesi veya artefaktsız mutlak histolojik kayıp olarak yorumladığı için yanlıştır."
        sup = align_support(q.get("support"), subset_ev, sec_supports)

        existing_stems.add(norm(stem))
        clean_qs.append({
            "heading_id": heading_id,
            "stem": stem,
            "options": dedup_opts,
            "correct_text": correct_text,
            "explanation": expl,
            "closest_distractor_explanation": dist_expl,
            "support": sup,
        })
        if len(clean_qs) == required_count:
            break

    return clean_qs

