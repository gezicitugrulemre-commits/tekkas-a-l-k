"""
KİTAP grafiği (eski pipeline.py'nin yerine): Tarif (recipe) tabanlı, paralel, kalıcı uzun kitap üretimi.

Ana grafik (book)                           Alt grafik (section) — her alt-bölüm için bir kopya
-----------------                           ----------------------------------------------------
START                                       START
  -> blueprint   (müfredat yoksa üret)        -> load_context   (Store: önceki özetler, kavramlar, sözlük)
  -> plan_wave   (her bölümden sıradaki 1)    -> queries        (Flash)
  ==Send==> section x N  (paralel)            -> retrieve       (ChromaDB+BM25, önbellekli)
  -> plan_wave   (dalga döngüsü)              -> synthesize     (Flash)
  -> finish -> END                            -> write          (Writer zinciri)
                                              -> review         (önce kod kontrolleri, sonra LLM editör)
                                                   ├─ revise  -> write
                                                   ├─ editor  -> interrupt() (insan onayı, opsiyonel)
                                                   └─ approve -> commit (dosya + Store) -> END

Neden "dalga" (wave)? Aynı bölümün alt-bölümleri birbirinin özetine ihtiyaç duyar (tekrarı önlemek
için), bu yüzden bölüm İÇİNDE sıralı, bölümler ARASINDA paraleldir.
"""

from __future__ import annotations

import json
import operator
from functools import lru_cache
from typing import Annotated, Any, Dict, List, Literal, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import Send, interrupt
from pydantic import BaseModel, Field

from ..core import CACHE, RETRY, emit, store
from ..llm import ask
from ..quality import check_section, word_count
from ..recipe import load_recipe
from ..settings import PATHS

BOOK = "kitap"


# ============================================================================
# Şemalar
# ============================================================================

class SubsectionSpec(BaseModel):
    subsection_id: str = Field(description="Örn: 'P01-C01-S01'")
    title: str
    clinical_focus: str = Field(description="Alt-bölümde ele alınacak spesifik klinik/anatomik/cerrahi odak")
    key_search_terms: List[str] = Field(description="PDF veritabanında aranacak İngilizce tıbbi anahtar kelimeler")


class ChapterSpec(BaseModel):
    chapter_id: str
    chapter_number: int
    title: str
    overview: str = Field(description="Bölümün kapsamı ve diğer bölümlerle sınırları")
    subsections: List[SubsectionSpec]


class PartChapters(BaseModel):
    chapters: List[ChapterSpec]


class SearchQueries(BaseModel):
    queries: List[str] = Field(description="4-6 adet spesifik tıbbi arama sorgusu")


class CriticReview(BaseModel):
    is_approved: bool = Field(description="Bölüm yayınlanmaya hazır mı?")
    revision_instructions: str = Field(default="", description="Yazara verilecek net düzeltme talimatı")
    section_summary: str = Field(default="", description="Global belleğe eklenecek 2-3 cümlelik özet")
    extracted_terms: Dict[str, str] = Field(default_factory=dict, description="İngilizce -> Türkçe terimler")
    key_concepts: List[str] = Field(default_factory=list, description="Detaylı işlenen kavramlar")


# --- Ana grafik durumu -------------------------------------------------------

class BookInput(TypedDict, total=False):
    recipe: str            # tarif adı (bookgraph/recipes/<ad>.yaml)
    limit: int             # bu koşuda yazılacak en fazla alt-bölüm (0 = sınırsız)
    human_review: bool     # True -> revizyon limiti aşılınca editör onayı bekle


class BookState(BookInput, total=False):
    book_id: str
    wave: List[Dict[str, Any]]
    completed: Annotated[List[str], operator.add]   # paralel dallar buraya EKLER (reducer)
    finished: bool


# --- Alt grafik durumu -------------------------------------------------------

class SectionInput(TypedDict, total=False):
    recipe: str
    book_id: str
    part_title: str
    chapter_id: str
    chapter_title: str
    subsection: Dict[str, Any]
    human_review: bool


class SectionOutput(TypedDict, total=False):
    completed: Annotated[List[str], operator.add]


class SectionState(SectionInput, SectionOutput, total=False):
    previous_summaries: str
    covered_concepts: str
    glossary: str
    queries: List[str]
    chunks: List[Dict[str, Any]]
    evidence: str
    draft: str
    revision: int
    feedback: str
    approved: bool
    needs_human: bool
    review: Dict[str, Any]


# ============================================================================
# Yardımcılar
# ============================================================================

def _blueprint_path(book_id: str):
    return PATHS.storage / book_id / "blueprint.json"


def _sections_ns(book_id: str):
    return (book_id, "sections")


@lru_cache(maxsize=1)
def _retriever():
    from ingest import HybridMedicalRetriever  # kökteki mevcut RAG indeksleyici
    return HybridMedicalRetriever()


def _scale(state) -> Dict[str, Any]:
    return load_recipe(state["recipe"])["scale"]


# ============================================================================
# ANA GRAFİK DÜĞÜMLERİ
# ============================================================================

def node_blueprint(state: BookState) -> Dict:
    """Tariften müfredat ağacını üretir (kısım kısım, kesintiye dayanıklı)."""
    recipe = load_recipe(state["recipe"])
    book_id = recipe["book_id"]
    path = _blueprint_path(book_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    bp = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {"book_id": book_id, "parts": []}
    done = {p["part_id"] for p in bp["parts"]}
    sc = recipe["scale"]
    chapter_no = sum(len(p["chapters"]) for p in bp["parts"]) + 1

    for part in recipe["parts"]:
        if part["id"] in done:
            continue
        emit(f"Müfredat tasarlanıyor: {part['title']}")
        res: PartChapters = ask(
            "kitap/blueprint", book=book_id, unit=part["id"], schema=PartChapters,
            field=recipe["field"], book_title=recipe["book_title"], target_pages=sc["target_pages"],
            part_title=part["title"], part_id=part["id"], chapters_per_part=sc["chapters_per_part"],
            first_chapter_number=chapter_no, subsections_per_chapter=sc["subsections_per_chapter"],
            target_words=sc["target_words"], reference_books=recipe["reference_books"],
            domain_keywords=part.get("keywords", []),
        )
        chapters = []
        for c_idx, ch in enumerate(res.chapters, start=1):
            ch_id = f"{part['id']}-C{c_idx:02d}"
            subs = [{**s.model_dump(), "subsection_id": f"{ch_id}-S{s_idx:02d}"}
                    for s_idx, s in enumerate(ch.subsections, start=1)]
            chapters.append({**ch.model_dump(), "chapter_id": ch_id, "chapter_number": chapter_no, "subsections": subs})
            chapter_no += 1
        bp["parts"].append({"part_id": part["id"], "title": part["title"], "chapters": chapters})
        path.write_text(json.dumps(bp, ensure_ascii=False, indent=2), encoding="utf-8")  # her kısımdan sonra kaydet

    return {"book_id": book_id}


def node_plan_wave(state: BookState) -> Dict:
    """Her bölümden sıradaki yazılmamış alt-bölümü seçer (bölüm içi sıra korunur)."""
    book_id = state["book_id"]
    bp = json.loads(_blueprint_path(book_id).read_text(encoding="utf-8"))
    done = {it.key for it in store().search(_sections_ns(book_id), limit=100_000)}

    limit = int(state.get("limit") or 0)
    budget_left = (limit - len(state.get("completed", []))) if limit > 0 else 10**9

    wave: List[Dict[str, Any]] = []
    total = pending = 0
    for part in bp["parts"]:
        for ch in part["chapters"]:
            first_pending = None
            for sub in ch["subsections"]:
                total += 1
                if sub["subsection_id"] not in done:
                    pending += 1
                    first_pending = first_pending or sub
            if first_pending and len(wave) < budget_left:
                wave.append({
                    "recipe": state["recipe"], "book_id": book_id, "part_title": part["title"],
                    "chapter_id": ch["chapter_id"], "chapter_title": f"Bölüm {ch['chapter_number']}: {ch['title']}",
                    "subsection": first_pending, "human_review": bool(state.get("human_review")),
                })
    emit(f"İlerleme: {total - pending}/{total} alt-bölüm tamam | bu dalga: {len(wave)} paralel iş")
    return {"wave": wave, "finished": pending == 0}


def route_wave(state: BookState):
    if not state.get("wave"):
        return "finish"
    return [Send("section", job) for job in state["wave"]]


def node_finish(state: BookState) -> Dict:
    msg = "Tüm alt-bölümler tamamlandı." if state.get("finished") else "Bu koşunun limiti doldu."
    emit(f"{msg} Bu koşuda yazılan: {len(state.get('completed', []))}")
    return {}


# ============================================================================
# ALT GRAFİK DÜĞÜMLERİ (tek alt-bölüm)
# ============================================================================

def node_load_context(state: SectionState) -> Dict:
    st, book_id = store(), state["book_id"]
    prev = sorted(st.search(_sections_ns(book_id), filter={"chapter_id": state["chapter_id"]}, limit=100), key=lambda i: i.key)
    concepts = sorted(st.search((book_id, "concepts"), limit=100_000), key=lambda i: i.updated_at)[-40:]
    terms = sorted(st.search((book_id, "glossary"), limit=100_000), key=lambda i: i.updated_at)[-50:]
    return {
        "previous_summaries": "\n".join(f"- [{i.key} - {i.value['title']}]: {i.value['summary']}" for i in prev[-6:])
                              or "Bu bölümün ilk alt-bölümüdür.",
        "covered_concepts": "\n".join(f"- {i.key} (Bkz: {i.value['subsection_id']})" for i in concepts) or "Henüz yok.",
        "glossary": "\n".join(f"- {i.key}: {i.value['tr']}" for i in terms)
                    or "İlk kullanımda Türkçe Terim (İngilizce Orijinal Terim, Kısaltma) formatını kullan.",
        "revision": 0,
    }


def node_queries(state: SectionState) -> Dict:
    sub, recipe = state["subsection"], load_recipe(state["recipe"])
    res: SearchQueries = ask(
        "kitap/queries", book=state["book_id"], unit=sub["subsection_id"], schema=SearchQueries,
        chapter_title=state["chapter_title"], title=sub["title"], clinical_focus=sub.get("clinical_focus", ""),
        key_search_terms=sub.get("key_search_terms", []), reference_books=recipe["reference_books"],
    )
    return {"queries": res.queries}


def node_retrieve(state: SectionState) -> Dict:
    queries = state.get("queries", []) + state["subsection"].get("key_search_terms", [])[:2]
    try:
        chunks = _retriever().retrieve(queries=queries, top_k=_scale(state).get("retrieval_top_k", 14))
    except Exception as exc:
        raise RuntimeError("RAG indeksi kullanılamadı; kanıtsız üretim engellendi.") from exc
    return {"chunks": chunks}


def node_synthesize(state: SectionState) -> Dict:
    chunks = state.get("chunks", [])
    if not chunks:
        raise ValueError("Kaynak pasajı bulunamadı; bölüm inceleme gerektiriyor.")
    formatted = "\n\n".join(
        f"--- KAYNAK [{i + 1}]: {c['source_book']} (Sayfa {c['page_number']}) ---\n{c['content']}" for i, c in enumerate(chunks)
    )
    text = ask("kitap/synthesize", book=state["book_id"], unit=state["subsection"]["subsection_id"],
               title=state["subsection"]["title"], chunks=formatted)
    return {"evidence": text}


def node_write(state: SectionState) -> Dict:
    sub, recipe, sc = state["subsection"], load_recipe(state["recipe"]), _scale(state)
    revision_note = ""
    if state.get("revision", 0) > 0 and state.get("feedback"):
        revision_note = (
            f"⚠️ EDİTÖR DÜZELTME TALİMATI (Revizyon #{state['revision']}):\n{state['feedback']}\n"
            f"Lütfen mevcut taslağı bu geri bildirim doğrultusunda genişleterek ve düzelterek yeniden yaz.\n"
            f"Önceki Taslak:\n{state.get('draft', '')}"
        )
    text = ask(
        "kitap/write", book=state["book_id"], unit=sub["subsection_id"],
        field=recipe["field"], book_title=recipe["book_title"], part_title=state["part_title"],
        chapter_title=state["chapter_title"], subsection_id=sub["subsection_id"], title=sub["title"],
        clinical_focus=sub.get("clinical_focus", ""), min_words=sc["min_words"], target_words=sc["target_words"],
        max_words=sc.get("max_words", 1250), previous_summaries=state["previous_summaries"],
        covered_concepts=state["covered_concepts"], glossary=state["glossary"], evidence=state.get("evidence", ""),
        heading=f"### {sub['subsection_id']} {sub['title']}", revision_note=revision_note,
    )
    return {"draft": text, "revision": state.get("revision", 0) + 1}


def node_review(state: SectionState) -> Dict:
    sub, sc = state["subsection"], _scale(state)
    draft, rev, max_rev = state["draft"], state["revision"], sc.get("max_revisions", 2)
    chk = check_section(draft, min_words=sc["min_words"])

    # 1) Ölçülebilir kural bozuksa LLM'e hiç gitme: bedava ve anlık revizyon
    if not chk.passed and rev < max_rev:
        emit(f"{sub['subsection_id']}: kod kontrolü başarısız -> revizyon #{rev}")
        return {"approved": False, "needs_human": False, "feedback": chk.feedback}

    # 2) İçerik kalitesi + küresel bellek çıktısı için LLM editör
    review: CriticReview = ask(
        "kitap/critic", book=state["book_id"], unit=sub["subsection_id"], schema=CriticReview,
        deterministic_report="geçti" if chk.passed else chk.feedback, title=sub["title"],
        clinical_focus=sub.get("clinical_focus", ""), draft=draft,
        evidence=state.get("chunks", []), previous_summaries=state.get("previous_summaries", ""),
        glossary=state.get("glossary", ""),
    )
    approved = review.is_approved and chk.passed
    feedback = "\n".join(filter(None, [chk.feedback, review.revision_instructions]))
    needs_human = False
    if not approved and rev >= max_rev:
        if state.get("human_review"):
            needs_human = True
        else:
            raise ValueError(f"{sub['subsection_id']}: kalite reddi devam ediyor; otomatik onay engellendi. İnsan incelemesi gerekli.")
    return {"approved": approved, "needs_human": needs_human, "feedback": feedback, "review": review.model_dump()}


def route_review(state: SectionState) -> Literal["write", "editor", "commit"]:
    if state.get("approved"):
        return "commit"
    if state.get("needs_human"):
        return "editor"
    return "write"


def node_editor(state: SectionState) -> Dict:
    """İnsan onayı: grafik burada DURUR. CLI: `resume kitap --approve` veya `--revise "talimat"`."""
    sub = state["subsection"]
    decision = interrupt({
        "message": f"{sub['subsection_id']} '{sub['title']}' {state['revision']} revizyonda onaylanmadı",
        "feedback": state.get("feedback", ""),
        "words": word_count(state["draft"]),
        "preview": state["draft"][:800],
    })
    if isinstance(decision, dict) and decision.get("revise"):
        return {"approved": False, "needs_human": False, "feedback": decision["revise"]}
    if decision != "approve" and not (isinstance(decision, dict) and decision.get("approve") is True):
        raise ValueError("Açık editör onayı gerekli.")
    return {"approved": True, "needs_human": False}


def route_editor(state: SectionState) -> Literal["write", "commit"]:
    return "commit" if state.get("approved") else "write"


def node_commit(state: SectionState) -> Dict:
    """Dosyaya yazar + Store'u günceller. Anahtar = alt-bölüm ID'si -> tekrar çalışırsa ÜZERİNE yazar (idempotent)."""
    if state.get("approved") is not True:
        raise ValueError("Onaylanmamış bölüm commit edilemez.")
    sub, book_id = state["subsection"], state["book_id"]
    sub_id = sub["subsection_id"]
    out = PATHS.output / book_id / sub_id.split("-")[0] / f"{sub_id}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(state["draft"], encoding="utf-8")

    review = state.get("review") or {}
    st = store()
    st.put(_sections_ns(book_id), sub_id, {
        "chapter_id": state["chapter_id"], "title": sub["title"], "summary": review.get("section_summary", ""),
        "words": word_count(state["draft"]), "path": str(out), "revisions": state.get("revision", 0),
    })
    for concept in review.get("key_concepts", []) or [sub["title"]]:
        st.put((book_id, "concepts"), concept, {"subsection_id": sub_id})
    for en, tr in (review.get("extracted_terms") or {}).items():
        st.put((book_id, "glossary"), en, {"tr": tr})

    emit(f"✓ {sub_id} kaydedildi ({word_count(state['draft'])} kelime)")
    return {"completed": [sub_id]}


# ============================================================================
# Grafik kurucular
# ============================================================================

def build_section() -> StateGraph:
    g = StateGraph(SectionState, input_schema=SectionInput, output_schema=SectionOutput)
    g.add_node("load_context", node_load_context)
    g.add_node("queries", node_queries, retry_policy=RETRY)
    g.add_node("retrieve", node_retrieve, retry_policy=RETRY, cache_policy=CACHE)
    g.add_node("synthesize", node_synthesize, retry_policy=RETRY)
    g.add_node("write", node_write, retry_policy=RETRY)
    g.add_node("review", node_review, retry_policy=RETRY)
    g.add_node("editor", node_editor)
    g.add_node("commit", node_commit)

    g.add_edge(START, "load_context")
    g.add_edge("load_context", "queries")
    g.add_edge("queries", "retrieve")
    g.add_edge("retrieve", "synthesize")
    g.add_edge("synthesize", "write")
    g.add_edge("write", "review")
    g.add_conditional_edges("review", route_review, ["write", "editor", "commit"])
    g.add_conditional_edges("editor", route_editor, ["write", "commit"])
    g.add_edge("commit", END)
    return g


def build() -> StateGraph:
    g = StateGraph(BookState, input_schema=BookInput)
    g.add_node("blueprint", node_blueprint, retry_policy=RETRY)
    g.add_node("plan_wave", node_plan_wave)
    g.add_node("section", build_section().compile())     # alt grafik = düğüm (Studio'da içi görünür)
    g.add_node("finish", node_finish)

    g.add_edge(START, "blueprint")
    g.add_edge("blueprint", "plan_wave")
    g.add_conditional_edges("plan_wave", route_wave, ["section", "finish"])
    g.add_edge("section", "plan_wave")    # tüm paralel dallar bitince bir sonraki dalga
    g.add_edge("finish", END)
    return g


DEFAULT_INPUT: BookInput = {"recipe": "oftalmoloji_1000", "limit": 0, "human_review": False}
