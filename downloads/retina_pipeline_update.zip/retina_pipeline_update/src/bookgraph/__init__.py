"""bookgraph — üç kitap hattı (kitap / retina / octa) için ortak LangGraph çatısı. Başlangıç: `python -m bookgraph --help`"""

__version__ = "2.0.0"
