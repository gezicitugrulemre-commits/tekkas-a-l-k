"""
bookgraph komut satırı — tüm kitap hatları için tek giriş noktası.

  python -m bookgraph list                              # kitaplar
  python -m bookgraph run retina --limit 3              # 3 konu yaz (yarım kalan varsa devam eder)
  python -m bookgraph run kitap --recipe oftalmoloji_1000 --limit 10 --workers 4 --human-review
  python -m bookgraph run octa --chapters c05,c06
  python -m bookgraph resume kitap --approve            # editör onayı bekleyen dalları onayla
  python -m bookgraph resume kitap --revise "Tabloyu genişlet"
  python -m bookgraph status                            # ilerleme + maliyet
  python -m bookgraph prompts                           # prompt dosyaları
  python -m bookgraph prompts kitap/write               # bir promptu ve değişkenlerini göster
  python -m bookgraph graph retina                      # grafiğin Mermaid diyagramı
  python -m bookgraph new-recipe glokom_300 --title "Klinik Glokom"
  python -m bookgraph publish soru-bankasi | octa-pdf   # mevcut yayıncı (PDF) modülleri
"""

from __future__ import annotations

import argparse
import json
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def _print(msg: str) -> None:
    print(msg, flush=True)


def cmd_list(_args) -> None:
    from .books import BOOKS
    for name, (_, desc) in BOOKS.items():
        _print(f"  {name:<8} {desc}")


def _build_input(args, book) -> dict:
    inp = dict(book.DEFAULT_INPUT)
    if getattr(args, "limit", None) is not None:
        inp["limit"] = args.limit
    if getattr(args, "recipe", None):
        inp["recipe"] = args.recipe
    if getattr(args, "human_review", False):
        inp["human_review"] = True
    if getattr(args, "chapters", None):
        inp["chapters"] = [c.strip() for c in args.chapters.split(",") if c.strip()]
    if getattr(args, "no_pdf", False):
        inp["assemble"] = False
        inp["render"] = False
    return inp


def _key(args) -> str:
    # "kitap" grafiğinde her tarif ayrı bir koşu geçmişine sahiptir
    return f"kitap.{args.recipe}" if args.book == "kitap" and getattr(args, "recipe", None) else args.book


def cmd_run(args, resume=None) -> None:
    from .books import get_book
    from .core import run_graph

    book = get_book(args.book)
    if args.book == "kitap" and not getattr(args, "recipe", None):
        args.recipe = book.DEFAULT_INPUT["recipe"]
    try:
        result = run_graph(
            book.build, key=_key(args), input=_build_input(args, book), thread_id=args.thread,
            resume=resume, max_concurrency=args.workers, fresh=getattr(args, "fresh", False), printer=_print,
        )
    except KeyboardInterrupt:
        _print("\n⏹  Durduruldu. Aynı komutla kaldığı yerden devam edebilirsiniz.")
        return
    except Exception as exc:
        _print(f"\n✗ Hata: {type(exc).__name__}: {exc}")
        _print(f"  Checkpoint kaydedildi -> düzelttikten sonra `python -m bookgraph run {args.book}` kaldığı yerden devam eder.")
        raise SystemExit(1)
    done = result.get("completed") or []
    _print(f"\nBu koşuda tamamlanan: {len(done)} birim  (thread={result['thread_id']})")


def cmd_resume(args) -> None:
    value = {"revise": args.revise} if args.revise else "approve"
    cmd_run(args, resume=value)


def cmd_status(_args) -> None:
    from . import usage
    from .core import _threads
    from .settings import MODELS, PATHS

    _print("=" * 64)
    _print("MALİYET TAHMİNİ (yerel fiyat tablosu; Cloud faturası veya abonelik kotası değildir)")
    for book, s in usage.summary().items():
        _print(f"  {book:<10} {s['calls']:>5} çağrı | in {s['input_tokens']:>10,} | out {s['output_tokens']:>9,} | ${s['usd']:.4f}")
    _print(f"  Toplam: ${usage.spent():.4f} / bütçe ${MODELS.budget_usd:.2f}"
           f"  {'(EKONOMİ MODU)' if usage.economy_mode() else ''}")
    _print("-" * 64)
    _print("İLERLEME")
    retina_acc = PATHS.storage / "retina_accepted.json"
    if retina_acc.is_file():
        acc = json.loads(retina_acc.read_text(encoding="utf-8"))
        _print(f"  retina : {len(acc)} konu kabul edildi, {sum(v.get('words', 0) for v in acc.values()):,} kelime")
    try:
        from .core import store
        for item in store().list_namespaces(max_depth=2):
            if len(item) == 2 and item[1] == "sections":
                n = len(store().search(item, limit=100_000))
                _print(f"  kitap  : tarif '{item[0]}' -> {n} alt-bölüm yazıldı")
    except Exception:
        pass
    _print("-" * 64)
    _print("SON KOŞULAR (thread)")
    for k, v in _threads().items():
        _print(f"  {k:<24} {v}")
    _print("=" * 64)


def cmd_prompts(args) -> None:
    from .prompting import list_prompts, load_prompt
    if args.name:
        p = load_prompt(args.name)
        _print(f"# {p.name}  ({p.path})\n{p.description}")
        _print(f"model: {', '.join(p.models) if p.models else 'rol=' + p.role} | sıcaklık={p.temperature} | çıktı={p.output}")
        _print(f"değişkenler: {', '.join(p.variables)}\n")
        _print(p.path.read_text(encoding="utf-8"))
        return
    for p in list_prompts():
        model = ",".join(m.split(":")[-1] for m in p.models) if p.models else f"rol:{p.role}"
        _print(f"  {p.name:<22} [{model}]  {p.description}")


def cmd_graph(args) -> None:
    from .books import get_book
    g = get_book(args.book).build().compile()
    _print(g.get_graph(xray=1).draw_mermaid())


def cmd_new_recipe(args) -> None:
    from .recipe import create_recipe
    path = create_recipe(args.book_id, args.title, args.field)
    _print(f"Tarif oluşturuldu: {path}\nDüzenleyin, sonra: python -m bookgraph run kitap --recipe {args.book_id} --limit 3")


def cmd_publish(args) -> None:
    if args.what == "soru-bankasi":
        from question_bank_pdf_publisher import compile_question_bank_pdf
        res = compile_question_bank_pdf()
        _print(f"Soru Bankası: {res['pdf_path']} ({res['total_questions']} soru, {res['total_pages']} sayfa)")
    elif args.what == "octa-pdf":
        from octa_pdf_publisher import build_octa_publication_pdf
        res = build_octa_publication_pdf()
        _print(f"OCTA kitabı: {res['pdf_path']} ({res['page_count']} sayfa, {res['total_questions']} soru)")


def main(argv=None) -> None:
    from .books import BOOKS

    ap = argparse.ArgumentParser(prog="bookgraph", description="LangGraph kitap üretim çatısı",
                                 formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="kitap grafiklerini listele").set_defaults(fn=cmd_list)

    def add_run_args(p):
        p.add_argument("book", choices=list(BOOKS))
        p.add_argument("--recipe", help="kitap: tarif adı (bookgraph/recipes/<ad>.yaml)")
        p.add_argument("--thread", help="belirli bir thread_id kullan (varsayılan: otomatik)")
        p.add_argument("--workers", type=int, help="paralel dal sayısı (varsayılan: MAX_CONCURRENCY)")

    r = sub.add_parser("run", help="kitap grafiğini çalıştır / kaldığı yerden devam et")
    add_run_args(r)
    r.add_argument("--limit", type=int, help="bu koşuda en fazla N birim yaz (0 = hepsi)")
    r.add_argument("--human-review", action="store_true", help="kalite eşiği geçilemezse editör onayı bekle")
    r.add_argument("--chapters", help="octa: virgülle bölüm listesi (ör. c05,c06)")
    r.add_argument("--no-pdf", action="store_true", help="sonda PDF derleme/render adımını atla")
    r.add_argument("--fresh", action="store_true", help="yarım kalan koşuyu yok say, yeni koşu başlat")
    r.set_defaults(fn=cmd_run)

    rs = sub.add_parser("resume", help="editör onayı bekleyen koşuyu devam ettir")
    add_run_args(rs)
    g = rs.add_mutually_exclusive_group()
    g.add_argument("--approve", action="store_true", help="bekleyen tüm taslakları onayla (varsayılan)")
    g.add_argument("--revise", metavar="TALİMAT", help="taslakları bu talimatla yeniden yazdır")
    rs.set_defaults(fn=cmd_resume)

    sub.add_parser("status", help="ilerleme ve maliyet").set_defaults(fn=cmd_status)

    p = sub.add_parser("prompts", help="prompt dosyalarını listele / göster")
    p.add_argument("name", nargs="?")
    p.set_defaults(fn=cmd_prompts)

    gr = sub.add_parser("graph", help="grafiğin Mermaid diyagramını yazdır")
    gr.add_argument("book", choices=list(BOOKS))
    gr.set_defaults(fn=cmd_graph)

    nr = sub.add_parser("new-recipe", help="yeni kitap tarifi oluştur")
    nr.add_argument("book_id")
    nr.add_argument("--title", required=True)
    nr.add_argument("--field", default="Oftalmoloji")
    nr.set_defaults(fn=cmd_new_recipe)

    pb = sub.add_parser("publish", help="mevcut PDF yayıncılarını çalıştır")
    pb.add_argument("what", choices=["soru-bankasi", "octa-pdf"])
    pb.set_defaults(fn=cmd_publish)

    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
