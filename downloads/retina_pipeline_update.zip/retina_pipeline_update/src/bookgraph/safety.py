"""Versioned artifacts and conservative post-edit integrity checks; no API calls."""
from __future__ import annotations
import hashlib
import json
import os
import re
import tempfile
from collections import Counter
from functools import lru_cache
from pathlib import Path

PIPELINE_VERSION = "evidence-safety-v1"

def fingerprint(*items):
    return hashlib.sha256(json.dumps(items, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()

@lru_cache(maxsize=256)
def _file_hash(path, size, modified):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def file_hash(path):
    p = Path(path)
    if not p.is_file():
        return "missing"
    stat = p.stat()
    return _file_hash(str(p.resolve()), stat.st_size, stat.st_mtime_ns)

def atomic_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=p.name + ".", suffix=".tmp", dir=p.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def assert_clinical_invariants(before, after):
    """Detect numeric/citation/negation changes. Does not prove clinical equivalence."""
    def collect(obj):
        if isinstance(obj, dict):
            return " ".join(collect(v) for v in obj.values())
        if isinstance(obj, list):
            return " ".join(collect(v) for v in obj)
        return str(obj)
    def markers(obj):
        text = collect(obj)
        return (
            Counter(re.findall(r"\d+(?:[.,]\d+)*", text)),
            Counter(re.findall(r"\[[^\]]+\]", text)),
            Counter(re.findall(r"(?:<=|>=|[<>≤≥±%µμ])", text)),
            Counter(re.findall(r"(\d+(?:[.,]\d+)?)\s*(mg|mcg|µg|μg|g|ml|mmhg|mm|µm|μm|iu|gün|saat|hafta|ay)(?![a-z])", text.casefold())),
            Counter(re.findall(r"\b(?:değil|yok|asla|kontrendike|kontrendikasyon|not|never|without)\b", text.casefold())),
        )
    if markers(before) != markers(after):
        raise ValueError("Dil düzenlemesi sayı/atıf/karşılaştırma/olumsuzluk alanlarını değiştirdi; insan incelemesi gerekli.")
