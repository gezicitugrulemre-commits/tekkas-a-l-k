"""
Ortak LangGraph çalışma zamanı: retry politikası, Store, checkpointer, akış (stream) ve
human-in-the-loop (interrupt) yönetimi. Üç kitap grafiği de bu modülü kullanır.

Temel fikirler (LangGraph 1.x):
  * Checkpointer (SqliteSaver)  -> her süper-adımdan sonra durum diske yazılır;
    çökme sonrası aynı thread_id ile `invoke(None)` kaldığı düğümden devam eder.
  * Store (SqliteStore)         -> kitaplar arası/uzun ömürlü bellek (sözlük, özetler, kavramlar).
    Anahtar-değer olduğu için paralel dallar birbirinin verisini EZMEZ ve tekrar çalıştırma
    aynı anahtarı günceller (idempotent).
  * RetryPolicy                 -> geçici LLM/API hataları düğüm seviyesinde otomatik tekrar denenir.
  * Send                        -> iş birimleri (alt bölüm / konu / OCTA bölümü) paralel dallara dağıtılır.
  * interrupt / Command(resume) -> editör onayı gereken yerde grafik durur, CLI'dan devam ettirilir.
"""

from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Callable, Dict, Iterator, Optional

from langgraph.types import CachePolicy, Command, RetryPolicy

from .settings import MODELS, PATHS

# ---------------------------------------------------------------------------
# Retry politikası: LLM/ağ hataları için üstel bekleme ile 3 deneme
# ---------------------------------------------------------------------------

def _retryable(exc: Exception) -> bool:
    # Programlama hataları tekrar denenmez; ağ / kota / ayrıştırma hataları denenir.
    if isinstance(exc, (ValueError, KeyError, TypeError, AttributeError, NameError, FileNotFoundError, NotImplementedError)):
        return False
    if isinstance(exc, RuntimeError) and exc.__cause__ is not None:
        return _retryable(exc.__cause__)
    response = getattr(exc, "response", None)
    status = getattr(exc, "status_code", None) or getattr(response, "status_code", None)
    if status is not None:
        return status in (408, 429, 500, 502, 503, 504)
    return isinstance(exc, (TimeoutError, ConnectionError)) or type(exc).__name__ in {
        "ConnectError", "ReadTimeout", "ConnectTimeout", "RemoteProtocolError",
        "ServiceUnavailable", "ResourceExhausted", "DeadlineExceeded", "InternalServerError",
    }


RETRY = RetryPolicy(max_attempts=3, initial_interval=3.0, backoff_factor=2.0, max_interval=60.0, retry_on=_retryable)

# Pahalı ama deterministik düğümler (PDF arama, PubMed) için düğüm önbelleği:
# aynı girdiyle tekrar çalışırsa sonucu SQLite önbellekten döndürür (ttl=None -> süresiz).
CACHE = CachePolicy(ttl=3600)


def open_cache():
    try:
        from langgraph.cache.sqlite import SqliteCache
        PATHS.ensure()
        return SqliteCache(path=str(PATHS.storage / "bookgraph_node_cache.sqlite"))
    except (ImportError, ModuleNotFoundError):
        from langgraph.cache.memory import InMemoryCache
        print("UYARI: SQLite cache yok; önbellek bu süreçle sınırlı.")
        return InMemoryCache()


# ---------------------------------------------------------------------------
# Store erişimi
# ---------------------------------------------------------------------------

_default_store = None
_store_lock = threading.Lock()


def _open_sqlite_store():
    try:
        from langgraph.store.sqlite import SqliteStore
        PATHS.ensure()
        conn = sqlite3.connect(str(PATHS.store_db), check_same_thread=False, isolation_level=None)
        s = SqliteStore(conn)
        s.setup()
        return s
    except (ImportError, ModuleNotFoundError):
        from langgraph.store.memory import InMemoryStore
        print("UYARI: SQLite Store yok; kalıcı bellek devre dışı.")
        return InMemoryStore()


def store():
    """
    Düğüm içinden Store'a erişim. LangGraph Server/Studio veya CLI bir store verdiyse onu,
    vermediyse (ör. doğrudan `graph.invoke`) yerel SQLite store'u kullanır.
    """
    global _default_store
    try:
        from langgraph.config import get_store
        s = get_store()
        if s is not None:
            return s
    except Exception:
        pass
    with _store_lock:
        if _default_store is None:
            _default_store = _open_sqlite_store()
    return _default_store


def emit(message: str) -> None:
    """Düğümden canlı ilerleme mesajı gönderir (stream_mode='custom'). Akış yoksa konsola yazar."""
    try:
        from langgraph.config import get_stream_writer
        get_stream_writer()(message)
    except Exception:
        print(message, flush=True)


# ---------------------------------------------------------------------------
# Checkpointer + Store yaşam döngüsü (CLI için)
# ---------------------------------------------------------------------------

@contextmanager
def open_runtime() -> Iterator[tuple]:
    PATHS.ensure()
    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
        conn = sqlite3.connect(str(PATHS.checkpoints_db), check_same_thread=False)
        saver = SqliteSaver(conn)
    except ImportError:  # pragma: no cover
        from langgraph.checkpoint.memory import InMemorySaver
        print("UYARI: langgraph-checkpoint-sqlite yok, kalıcı olmayan bellek kullanılıyor.")
        conn, saver = None, InMemorySaver()
    try:
        yield saver, store()
    finally:
        if conn is not None:
            conn.close()


def _pending_interrupts(snapshot) -> list:
    items = list(getattr(snapshot, "interrupts", None) or [])
    if not items:
        for t in snapshot.tasks or ():
            items.extend(getattr(t, "interrupts", ()) or ())
    return items


_THREADS_FILE = "bookgraph_threads.json"


def _threads() -> Dict[str, str]:
    import json
    f = PATHS.storage / _THREADS_FILE
    return json.loads(f.read_text(encoding="utf-8")) if f.is_file() else {}


def _save_thread(key: str, thread_id: str) -> None:
    import json
    data = _threads()
    data[key] = thread_id
    (PATHS.storage / _THREADS_FILE).write_text(json.dumps(data, indent=2), encoding="utf-8")


def last_thread(key: str) -> Optional[str]:
    return _threads().get(key)


def run_graph(
    builder_fn: Callable[[], Any],
    *,
    key: str,
    input: Optional[Dict[str, Any]] = None,
    thread_id: Optional[str] = None,
    resume: Any = None,
    max_concurrency: Optional[int] = None,
    recursion_limit: int = 1000,
    fresh: bool = False,
    printer: Callable[[str], None] = print,
) -> Dict[str, Any]:
    """
    Bir kitap grafi?ini kal?c? (checkpoint'li) olarak ?al??t?r?r ve canl? ak??? yazd?r?r.

    Thread se?imi (`key` = kitap ad?, ?r. "retina"):
      * thread_id verilmediyse ve bu kitab?n son ko?usu YARIM kald?ysa -> o thread'den devam eder
        (fresh=True ise yar?m ko?u yok say?l?r).
      * Son ko?u bittiyse -> yeni bir thread a??l?r (eski ko?unun durumu kar??maz).
      * `resume` verilirse -> son thread'deki bekleyen interrupt(lar)a bu de?erle cevap verilir.
    """
    with open_runtime() as (saver, st):
        graph = builder_fn().compile(checkpointer=saver, store=st, cache=open_cache())

        def cfg(tid: str) -> Dict[str, Any]:
            return {"configurable": {"thread_id": tid},
                    "max_concurrency": max_concurrency or MODELS.max_concurrency,
                    "recursion_limit": recursion_limit}

        if thread_id is None:
            last = last_thread(key)
            if last and (resume is not None or (not fresh and graph.get_state(cfg(last)).next)):
                thread_id = last
            else:
                from datetime import datetime
                thread_id = f"{key}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        _save_thread(key, thread_id)

        config = cfg(thread_id)
        snapshot = graph.get_state(config)
        pending = _pending_interrupts(snapshot)

        if resume is not None:
            if not pending:
                printer("Bekleyen onay (interrupt) yok; kald??? yerden devam ediliyor.")
                payload = None
            elif len(pending) == 1:
                payload = Command(resume=resume)
            else:
                payload = Command(resume={i.id: resume for i in pending})
        elif snapshot.next:
            printer(f"? Yar?m kalan ko?u: thread={thread_id}, s?radaki d???m(ler): {list(snapshot.next)} -> devam")
            payload = None
        else:
            printer(f"? Yeni ko?u: thread={thread_id}")
            payload = input or {}

        for ns, mode, chunk in graph.stream(payload, config, stream_mode=["updates", "custom"], subgraphs=True):
            where = "/".join(n.split(":")[0] for n in ns) if ns else "ana"
            if mode == "custom":
                printer(f"  ? {chunk}")
            elif isinstance(chunk, dict):
                for node in chunk:
                    if node != "__interrupt__":
                        printer(f"[{where}] ? {node}")

        final = graph.get_state(config)
        pending = _pending_interrupts(final)
        if pending:
            printer("\n?  Grafik edit?r onay? bekliyor:")
            for i in pending:
                v = i.value
                printer(f"   - {v.get('message', v) if isinstance(v, dict) else v}")
            printer(f"   Devam:  python -m bookgraph resume {key} --approve    |    --revise \"talimat\"")
        elif final.next:
            printer(f"? Ko?u tamamlanmad? (s?radaki: {list(final.next)}). Tekrar `run {key}` ile devam edebilirsiniz.")
        return {"thread_id": thread_id, **dict(final.values)}
