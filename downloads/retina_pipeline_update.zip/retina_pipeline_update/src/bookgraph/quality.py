"""
Deterministik kalite kontrolleri (LLM'siz, bedava, anlık).

Eleştirmen LLM'e gitmeden önce burada ölçülebilir kurallar denetlenir. Kural bozuksa
taslak doğrudan revizyona gider; LLM eleştirmeni yalnızca içerik kalitesine bakar.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

TABLE_ROW = re.compile(r"^\s*\|.+\|\s*$", re.MULTILINE)
SOURCE_CITE = re.compile(r"\[Kaynak:[^\]]+\]")
PDF_OR_PMID_CITE = re.compile(r"\[(?:[A-Za-z0-9-]+:pdf\d+|PMID:\d+)\]")


def word_count(text: str) -> int:
    return len(text.split())


@dataclass
class CheckResult:
    passed: bool
    problems: List[str] = field(default_factory=list)

    @property
    def feedback(self) -> str:
        return "\n".join(f"- {p}" for p in self.problems)


def check_section(text: str, *, min_words: int, min_citations: int = 3, require_table: bool = True,
                  require_pearls: bool = True, heading: str = "") -> CheckResult:
    problems: List[str] = []
    wc = word_count(text)
    if wc < min_words:
        problems.append(f"Metin {wc} kelime; en az {min_words} kelime olmalı. Yüzeysel kalan alt başlıkları derinleştir.")
    cites = len(SOURCE_CITE.findall(text))
    if cites < min_citations:
        problems.append(f"Yalnızca {cites} adet [Kaynak: ...] atfı var; en az {min_citations} olmalı.")
    if require_table and len(TABLE_ROW.findall(text)) < 4:
        problems.append("Markdown ayırıcı tanı tablosu eksik veya 2 satırdan kısa.")
    if require_pearls and "[!IMPORTANT]" not in text:
        problems.append("'> [!IMPORTANT] Klinik İpuçları' kutusu eksik.")
    if heading and not text.lstrip().startswith(heading):
        problems.append(f"Metin tam olarak '{heading}' başlığıyla başlamalı.")
    return CheckResult(passed=not problems, problems=problems)


def ensure_paragraph_citations(text: str, valid_citations: List[str], fallback_citation: str = "") -> str:
    """Validate citation IDs and coverage; never attach an unrelated fallback.

    This checks references, not whether passages entail the claims.
    """
    allowed = set(valid_citations)
    if not allowed:
        raise ValueError("Geçerli kanıt kaydı yok; otomatik atıf eklenmedi.")
    def split_multi(match):
        parts = [f"[{p.strip()}]" for p in re.split(r"[,;]\s*", match.group(1)) if p.strip()]
        if not all(p in allowed for p in parts):
            raise ValueError("Bilinmeyen kaynak kimliği; atıf otomatik değiştirilmedi.")
        return " ".join(parts)
    text = re.sub(r"\[((?:[A-Za-z0-9-]+:pdf\d+|PMID:\d+)[,;][^\[\]]+)\]", split_multi, text)
    unknown = set(PDF_OR_PMID_CITE.findall(text)) - allowed
    if unknown:
        raise ValueError("İzinli kanıt listesinde olmayan atıflar: " + ", ".join(sorted(unknown)))
    for block in re.split(r"\n\s*\n", text.strip()):
        lines = [line for line in block.splitlines() if not line.lstrip().startswith("#")]
        body = "\n".join(lines).strip()
        if body and not PDF_OR_PMID_CITE.search(body):
            raise ValueError("Kaynak etiketi olmayan paragraf; yedek atıf eklemek yerine inceleme gerekli.")
    return text


def ensure_first_line(text: str, header_line: str) -> str:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if lines and lines[0].strip().startswith(header_line):
        return text
    if lines and lines[0].strip().startswith("#"):
        lines[0] = header_line
        return "\n\n".join(lines)
    return f"{header_line}\n\n{text}"
