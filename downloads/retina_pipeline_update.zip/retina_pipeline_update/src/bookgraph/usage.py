"""Append-only, additive-migration usage ledger. USD values are local estimates."""
from __future__ import annotations
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Dict, Optional
from .settings import MODELS, PATHS

PRICING = {
    'gemini-4-argon': {'input': 2.0, 'output': 10.0},
    'gemini-3.8-flash': {'input': 0.75, 'output': 3.75},
    'gemini-2.5-flash': {'input': 0.30, 'output': 2.50},
    'gemini-2.5-pro': {'input': 1.25, 'output': 10.0},
}
_lock = threading.Lock()
_conn = None

def _db():
    global _conn
    if _conn is None:
        PATHS.ensure()
        conn = sqlite3.connect(str(PATHS.usage_db), check_same_thread=False, timeout=30)
        try:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('''CREATE TABLE IF NOT EXISTS usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, book TEXT, unit TEXT,
                prompt TEXT, model TEXT, input_tokens INTEGER, output_tokens INTEGER, usd REAL)''')
            columns = {r[1] for r in conn.execute('PRAGMA table_info(usage)')}
            for name, dtype in {
                'requested_model': 'TEXT', 'actual_model': 'TEXT', 'provider': 'TEXT',
                'provider_response_id': 'TEXT', 'langchain_run_id': 'TEXT', 'run_id': 'TEXT',
                'status': "TEXT DEFAULT 'LEGACY_UNVERIFIED'", 'usage_available': 'INTEGER',
                'model_identity_source': 'TEXT', 'cost_kind': "TEXT DEFAULT 'local_estimate'",
            }.items():
                if name not in columns:
                    conn.execute(f'ALTER TABLE usage ADD COLUMN {name} {dtype}')
            conn.execute('''CREATE TABLE IF NOT EXISTS fallback_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, run_id TEXT,
                book TEXT, unit TEXT, prompt TEXT, from_model TEXT, to_model TEXT,
                error_type TEXT, http_status INTEGER)''')
            conn.commit()
        except Exception:
            conn.close()
            raise
        _conn = conn
    return _conn

def price(model, input_tokens, output_tokens):
    rates = PRICING.get(model.split(':')[-1])
    if not rates or input_tokens is None or output_tokens is None:
        return None
    return round(input_tokens / 1e6 * rates['input'] + output_tokens / 1e6 * rates['output'], 6)

def record(book, unit, prompt, model, input_tokens, output_tokens, *,
           requested_model=None, actual_model=None, provider='unknown',
           provider_response_id=None, langchain_run_id=None, run_id=None,
           status='LEGACY_UNVERIFIED', model_identity_source='unknown'):
    # Old callers supplied a requested model as "model". Never upgrade that to proof.
    actual = actual_model or 'unknown'
    available = input_tokens is not None and output_tokens is not None
    usd = price(actual, input_tokens, output_tokens)
    with _lock:
        db = _db()
        db.execute('''INSERT INTO usage
            (ts,book,unit,prompt,model,input_tokens,output_tokens,usd,
             requested_model,actual_model,provider,provider_response_id,langchain_run_id,
             run_id,status,usage_available,model_identity_source,cost_kind)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (datetime.now(timezone.utc).isoformat(),book,unit,prompt,actual,input_tokens,
             output_tokens,usd,requested_model or model,actual,provider,provider_response_id,
             langchain_run_id,run_id,status,int(available),model_identity_source,'local_estimate'))
        db.commit()
    return usd

def log_fallback(*, run_id, book, unit, prompt, from_model, to_model, error):
    # Do not persist raw provider exceptions: they may contain URLs or customer text.
    status = getattr(error, 'status_code', None) or getattr(getattr(error, 'response', None), 'status_code', None)
    if not isinstance(status, int):
        status = None
    with _lock:
        db = _db()
        db.execute('''INSERT INTO fallback_events
            (ts,run_id,book,unit,prompt,from_model,to_model,error_type,http_status)
            VALUES (?,?,?,?,?,?,?,?,?)''', (datetime.now(timezone.utc).isoformat(),run_id,
            book,unit,prompt,from_model,to_model,type(error).__name__,status))
        db.commit()

def spent(book=None):
    with _lock:
        sql = 'SELECT COALESCE(SUM(usd),0) FROM usage' + (' WHERE book=?' if book else '')
        return float(_db().execute(sql, (book,) if book else ()).fetchone()[0])

def summary():
    with _lock:
        rows = _db().execute('''SELECT book,COUNT(*),COALESCE(SUM(input_tokens),0),
            COALESCE(SUM(output_tokens),0),COALESCE(SUM(usd),0) FROM usage GROUP BY book''').fetchall()
    return {r[0]:dict(calls=r[1], input_tokens=r[2], output_tokens=r[3], usd=round(r[4],4)) for r in rows}

def remaining_budget():
    return max(0.0, MODELS.budget_usd - spent())

def economy_mode():
    return MODELS.budget_usd > 0 and spent() / MODELS.budget_usd >= MODELS.economy_threshold
