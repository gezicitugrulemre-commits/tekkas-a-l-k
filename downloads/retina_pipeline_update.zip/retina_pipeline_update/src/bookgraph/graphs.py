"""
LangGraph Studio / `langgraph dev` / LangGraph Server için derlenmiş grafikler (langgraph.json buraya bakar).

Sunucu kendi checkpointer ve Store'unu otomatik bağlar; bu yüzden burada yalnızca düğüm önbelleği
verilir. `with_config(recursion_limit=...)` sayesinde Studio'dan çalıştırırken 25 adım sınırına takılmazsınız.
"""

from .books import kitap as _kitap, octa as _octa, retina as _retina
from .core import open_cache

_CFG = {"recursion_limit": 1000}

kitap = _kitap.build().compile(cache=open_cache(), name="kitap").with_config(_CFG)
retina = _retina.build().compile(cache=open_cache(), name="retina").with_config(_CFG)
octa = _octa.build().compile(cache=open_cache(), name="octa").with_config(_CFG)
