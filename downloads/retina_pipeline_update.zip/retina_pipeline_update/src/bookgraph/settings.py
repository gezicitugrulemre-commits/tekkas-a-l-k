"""
Tek merkezli ayarlar.

Kural: Kodda hiçbir makineye özel yol veya proje kimliği yazılmaz. Her şey `.env`
dosyasından (veya ortam değişkeninden) okunur; burada yalnızca güvenli varsayılanlar bulunur.

Yükleme sırası (ilk bulunan değer kazanır):
  1. Gerçek ortam değişkenleri (Docker / shell)
  2. <proje>/.env
  3. EXTRA_ENV_FILE (varsayılan: langgraph-lab/.env — Vertex/LangSmith anahtarları orada)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

BASE_DIR = Path(__file__).resolve().parent.parent
PACKAGE_DIR = Path(__file__).resolve().parent

if load_dotenv:
    load_dotenv(BASE_DIR / ".env", override=False)
    _extra = os.getenv("EXTRA_ENV_FILE", r"c:\Users\gezic\Projects\langgraph-lab\.env")
    if _extra and Path(_extra).is_file():
        load_dotenv(_extra, override=False)


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip().strip('"')


def _env_list(name: str, default: str) -> List[str]:
    return [x.strip() for x in _env(name, default).split(",") if x.strip()]


@dataclass(frozen=True)
class ModelSettings:
    """
    Model zincirleri: "sağlayıcı:model" biçiminde, virgülle ayrılmış.
    İlk model birincil, diğerleri sırasıyla yedek (fallback) olur.

    Sağlayıcılar: google (AI Studio / GOOGLE_GENAI_USE_VERTEXAI ile Vertex),
                  vertex (Gemini veya Claude), bedrock (AWS), wps (OpenAI-uyumlu gateway)
    """
    fast: List[str] = field(default_factory=lambda: _env_list(
        "MODELS_FAST", "google:gemini-3.8-flash,google:gemini-2.5-flash"))
    writer: List[str] = field(default_factory=lambda: _env_list(
        "MODELS_WRITER", "google:gemini-4-argon,google:gemini-3.8-flash,google:gemini-2.5-pro,bedrock:deepseek.v3.2"))
    reviewer: List[str] = field(default_factory=lambda: _env_list(
        "MODELS_REVIEWER", "google:gemini-4-argon,google:gemini-3.8-flash,google:gemini-2.5-pro"))

    gcp_project: str = field(default_factory=lambda: _env("GOOGLE_CLOUD_PROJECT", _env("GCP_PROJECT_ID")))
    gcp_location: str = field(default_factory=lambda: _env("GOOGLE_CLOUD_LOCATION", _env("GCP_LOCATION", "us-central1")))
    aws_profile: str = field(default_factory=lambda: _env("AWS_PROFILE", "TEG"))
    aws_region: str = field(default_factory=lambda: _env("AWS_REGION", "eu-north-1"))
    wps_base_url: str = field(default_factory=lambda: _env("WPS_API_BASE_URL"))
    wps_api_key: str = field(default_factory=lambda: _env("WPS_API_KEY"))

    budget_usd: float = field(default_factory=lambda: float(_env("BUDGET_USD", _env("WPS_QUOTA_BUDGET_USD", "100"))))
    economy_threshold: float = field(default_factory=lambda: float(_env("ECONOMY_THRESHOLD", "0.88")))
    max_concurrency: int = field(default_factory=lambda: int(_env("MAX_CONCURRENCY", _env("PARALLEL_WORKERS", "3"))))


@dataclass(frozen=True)
class Paths:
    base: Path = BASE_DIR
    prompts: Path = PACKAGE_DIR / "prompts"
    recipes: Path = PACKAGE_DIR / "recipes"
    storage: Path = field(default_factory=lambda: Path(_env("STORAGE_DIR", str(BASE_DIR / "storage"))))
    output: Path = field(default_factory=lambda: Path(_env("OUTPUT_DIR", str(BASE_DIR / "output"))))
    source_pdfs: Path = field(default_factory=lambda: Path(_env(
        "SOURCE_PDF_DIR", r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI")))

    # Retina kitabı (langgraph-lab çıktıları)
    retina_lab: Path = field(default_factory=lambda: Path(_env(
        "RETINA_LAB_DIR", r"c:\Users\gezic\Projects\langgraph-lab\outputs\retina-longform-v1")))
    # OCTA kitabı (langgraph-lab production paketi)
    octa_root: Path = field(default_factory=lambda: Path(_env(
        "OCTA_ROOT_DIR", r"c:\Users\gezic\Projects\langgraph-lab\outputs\octa-database-20261023")))

    @property
    def checkpoints_db(self) -> Path:
        return self.storage / "bookgraph_checkpoints.sqlite"

    @property
    def store_db(self) -> Path:
        return self.storage / "bookgraph_store.sqlite"

    @property
    def usage_db(self) -> Path:
        return self.storage / "bookgraph_usage.sqlite"

    def ensure(self) -> None:
        for d in (self.storage, self.output):
            d.mkdir(parents=True, exist_ok=True)


MODELS = ModelSettings()
PATHS = Paths()
