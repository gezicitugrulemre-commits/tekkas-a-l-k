---
description: Alt-bölüm için PDF veritabanında (ChromaDB + BM25) aranacak sorguları üretir
role: fast
temperature: 0.1
---
## user
Bölüm: {{ chapter_title }}
Alt-Bölüm: {{ title }}
Klinik Odak: {{ clinical_focus }}
Önerilen Terimler: {{ key_search_terms }}

Kaynak veritabanımız İngilizce ve Türkçe referans kitaplarından ({{ reference_books }}) oluşmaktadır.
Bu alt-bölümü kanıta dayalı yazabilmek için patofizyoloji, tanı/görüntüleme (OCT, FA, topografi vb.),
ayırıcı tanı ve cerrahi/medikal tedavi protokollerini bulacak 5 adet spesifik arama sorgusu üret
(4 İngilizce, 1 Türkçe).
