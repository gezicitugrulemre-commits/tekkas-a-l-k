---
description: Ham PDF parçalarını kaynak/sayfa etiketli yapılandırılmış klinik kanıt dosyasına sıkıştırır
role: fast
temperature: 0.1
---
## user
Aşağıdaki ham PDF alıntılarını '{{ title }}' başlıklı akademik kitap bölümü için
yapılandırılmış bir Klinik Kanıt Dosyasına dönüştür.

KURALLAR:
1. Sayısal verileri (dozajlar, yüzdeler, evreleme kriterleri, OCT/FA bulguları, cerrahi parametreler) asla kaybetme.
2. Her bilginin yanına mutlaka kaynak adını ve sayfa numarasını `[Kaynak: Kitap Adı, s. X]` formatında ekle.
3. Bilgileri şu başlıklar altında grupla:
   - Patofizyoloji ve Histopatoloji
   - Klinik Bulgular ve Tanısal Görüntüleme
   - Ayırıcı Tanı Kriterleri
   - Medikal ve Cerrahi Tedavi Protokolleri

HAM PDF ALINTILARI:
{{ chunks }}
