"""
Kitap tarifi (recipe) yükleyici: bookgraph/recipes/<ad>.yaml
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict

import yaml

from .settings import PATHS

TEMPLATE = """# Yeni kitap tarifi — alanları düzenleyip çalıştırın:
#   python -m bookgraph run kitap --recipe {book_id} --limit 3
book_id: {book_id}
book_title: "{title}"
field: {field}
reference_books: "Alanınızın temel referans kitapları (ör. AAO BCSC, Kanski)"

scale:
  target_pages: 300
  words_per_page: 420
  chapters_per_part: 5
  subsections_per_chapter: 4
  target_words: 1050
  min_words: 850
  max_words: 1250
  max_revisions: 2
  retrieval_top_k: 14

parts:
  - id: P01
    title: "KISIM I: ..."
    keywords: [anahtar, kelimeler]
  - id: P02
    title: "KISIM II: ..."
    keywords: [anahtar, kelimeler]
"""


def recipe_path(name: str) -> Path:
    p = Path(name)
    if p.suffix in (".yaml", ".yml") and p.is_file():
        return p
    return PATHS.recipes / f"{name}.yaml"


@lru_cache(maxsize=16)
def load_recipe(name: str) -> Dict[str, Any]:
    path = recipe_path(name)
    if not path.is_file():
        raise FileNotFoundError(f"Tarif bulunamadı: {path}  (mevcutlar: {[p.stem for p in PATHS.recipes.glob('*.yaml')]})")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    for key in ("book_id", "book_title", "parts", "scale"):
        if key not in data:
            raise ValueError(f"{path.name}: '{key}' alanı zorunlu")
    data.setdefault("field", "Tıp")
    data.setdefault("reference_books", "")
    return data


def create_recipe(book_id: str, title: str, field: str = "Oftalmoloji") -> Path:
    path = PATHS.recipes / f"{book_id}.yaml"
    if path.exists():
        raise FileExistsError(path)
    path.write_text(TEMPLATE.format(book_id=book_id, title=title, field=field), encoding="utf-8")
    return path
