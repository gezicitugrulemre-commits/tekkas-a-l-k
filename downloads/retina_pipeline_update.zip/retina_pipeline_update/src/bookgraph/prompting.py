"""
Prompt kütüphanesi: Tüm promptlar `bookgraph/prompts/**.md` dosyalarında durur.

Dosya biçimi
------------
    ---
    description: Bu prompt ne işe yarar (CLI'da listelenir)
    role: writer            # fast | writer | reviewer  -> settings.MODELS zinciri
    models: google:gemini-2.5-flash, google:gemini-2.5-pro   # (opsiyonel) role yerine özel zincir
    temperature: 0.3
    max_tokens: 8192
    output: text            # text | json
    ---
    ## system
    Sistem mesajı ...
    ## user
    Kullanıcı mesajı ... {{ degisken }} ...

Değişkenler `{{ isim }}` şeklinde yazılır. Tek süslü parantez `{ }` serbesttir; bu sayede
JSON şemaları promptun içine kaçış karakteri olmadan yazılabilir.
Eksik bir değişken verilirse hata, hangi değişkenlerin eksik olduğunu söyler.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from .settings import PATHS

_VAR = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")
_SECTION = re.compile(r"^##\s+(system|user)\s*$", re.MULTILINE | re.IGNORECASE)


@dataclass
class Prompt:
    name: str
    path: Path
    description: str = ""
    role: str = "fast"
    models: Optional[List[str]] = None
    temperature: float = 0.2
    max_tokens: int = 8192
    output: str = "text"
    system: str = ""
    user: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)

    @property
    def variables(self) -> List[str]:
        seen: List[str] = []
        for m in _VAR.finditer(self.system + "\n" + self.user):
            if m.group(1) not in seen:
                seen.append(m.group(1))
        return seen

    def render(self, **values: Any) -> List[tuple[str, str]]:
        """[("system", ...), ("user", ...)] listesi döndürür (LangChain mesaj tuple formatı)."""
        missing = [v for v in self.variables if v not in values]
        if missing:
            raise KeyError(f"Prompt '{self.name}' için eksik değişken(ler): {', '.join(missing)}")

        def _sub(text: str) -> str:
            return _VAR.sub(lambda m: _stringify(values[m.group(1)]), text).strip()

        msgs: List[tuple[str, str]] = []
        if self.system.strip():
            msgs.append(("system", _sub(self.system)))
        msgs.append(("user", _sub(self.user)))
        return msgs


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    if isinstance(value, dict):
        import json
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _parse(path: Path, name: str) -> Prompt:
    raw = path.read_text(encoding="utf-8")
    meta: Dict[str, Any] = {}
    body = raw
    if raw.startswith("---"):
        _, fm, body = raw.split("---", 2)
        meta = yaml.safe_load(fm) or {}

    parts = _SECTION.split(body)
    system, user = "", ""
    if len(parts) == 1:
        user = body
    else:
        for i in range(1, len(parts), 2):
            if parts[i].lower() == "system":
                system = parts[i + 1]
            else:
                user = parts[i + 1]

    models = meta.get("models")
    if isinstance(models, str):
        models = [m.strip() for m in models.split(",") if m.strip()]

    return Prompt(
        name=name,
        path=path,
        description=str(meta.get("description", "")),
        role=str(meta.get("role", "fast")),
        models=models,
        temperature=float(meta.get("temperature", 0.2)),
        max_tokens=int(meta.get("max_tokens", 8192)),
        output=str(meta.get("output", "text")),
        system=system,
        user=user,
        meta=meta,
    )


@lru_cache(maxsize=None)
def load_prompt(name: str) -> Prompt:
    """`load_prompt("retina/author_facet")` -> prompts/retina/author_facet.md"""
    path = PATHS.prompts / f"{name}.md"
    if not path.is_file():
        raise FileNotFoundError(f"Prompt bulunamadı: {path}")
    return _parse(path, name)


def list_prompts() -> List[Prompt]:
    out = []
    for p in sorted(PATHS.prompts.rglob("*.md")):
        name = p.relative_to(PATHS.prompts).with_suffix("").as_posix()
        out.append(_parse(p, name))
    return out
