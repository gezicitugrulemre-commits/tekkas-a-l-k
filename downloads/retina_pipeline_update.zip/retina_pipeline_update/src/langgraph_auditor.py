# -*- coding: utf-8 -*-
"""
LangGraph Auditor & Academic Turkish Humanizer Pipeline (all_gemini Edition)
============================================================================
Bu modül iki temel görevi canlı Vertex AI `global` (`gemini-3.8-flash` & `gemini-4-argon`)
modelleri üzerinden yürütür:

1. `audit_langgraph_pipeline(..., mode="all_gemini")`:
   LangGraph kodlarını, `StateGraph` durum şemalarını, `Annotated[..., operator.add]`
   indirgeyicilerini (reducer), `Send` paralel dallanmalarını ve döngü devre kesicilerini
   (circuit-breaker) `gemini-3.8-flash` (Triage & Rapor) ve `gemini-4-argon` (Baş Mimar &
   Kod Denetimi) ile denetler.

2. `academic_turkish_humanizer_node(state)`:
   Hem denetim raporlarını (`AuditState`) hem de LangGraph PDF üretim boru hatlarındaki
   akademik çalışma modüllerini (`authored_module`) `turkish-academic-humanizer` dilbilim
   kurallarına göre (`gemini-3.8-flash`) doğal, baş-son (head-final) Akademik Türkçeye
   dönüştürür; çeviri kokusunu (calque) ve yapay zekâ klişelerini (AI slop) temizlerken
   sayısal verileri, kaynak atıflarını ve kod sembollerini birebir korur.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Annotated, Any, Dict, List, Literal, Optional, Tuple, TypedDict

from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

try:
    from bookgraph import settings as _bg_settings  # noqa: F401 (.env yüklemesini tetikler)
    from bookgraph import usage as _bg_usage
except Exception:
    _bg_settings = None
    _bg_usage = None

# ==============================================================================
# Model Tanımları (Saf Gemini `all_gemini` Varsayılan Kümesi)
# ==============================================================================
MODEL_FLASH = "gemini-3.8-flash"
MODEL_ARGON = "gemini-4-argon"
MODEL_SONNET = "claude-sonnet-5-5"
MODEL_OPUS = "claude-opus-5-5"

AGENT_API_PATH = r"C:\Users\gezic\.gemini\antigravity\bin\agentapi.bat"

# Yasaklı çeviri kokusu (calque) ve AI slop kalıpları (nicel metrik taraması için)
CALQUE_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("sahiptir / sahip olmak", re.compile(r"\bsahip(?:tir|tiler|sin|siniz|iz)?\b|\bsahip\s+ol\w+", re.IGNORECASE)),
    ("izin verir / olanak sağlar", re.compile(r"\bizin\s+ver\w+|\bolanak\s+sağla\w+", re.IGNORECASE)),
    ("kritik rol oynar", re.compile(r"\bkritik\s+(?:bir\s+)?rol\s+oyna\w+", re.IGNORECASE)),
    ("bu bağlamda / söz konusu", re.compile(r"\bbu\s+bağlamda\b|\bsöz\s+konusu\b", re.IGNORECASE)),
    ("önemli/büyük ölçüde", re.compile(r"\b(?:önemli|büyük)\s+ölçüde\b", re.IGNORECASE)),
    ("yalnızca X değil aynı zamanda", re.compile(r"\byalnızca\b[^.]{1,80}\bdeğil,?\s+aynı\s+zamanda\b", re.IGNORECASE)),
]

ACADEMIC_TURKISH_SYSTEM_RULES = """Sen üst düzey bir tıp/bilgisayar bilimleri akademisyeni ve teknik dilbilimcisin.
Görevin: Verilen Türkçe akademik metni veya yapılandırılmış çalışma modülünü, hiçbir bilimsel veriyi, sayısal eşiği, ilaç dozunu veya kaynak atfını bozmadan uluslararası hakemli dergi standartlarında duru, yetkin ve akıcı bir Akademik Türkçeye dönüştürmektir.

KESİN AKADEMİK DİLBİLİM KURALLARI (turkish-academic-humanizer):
1. DALLANMA YÖNÜ (Head-Final Syntax): İngilizce 'head-initial' sözdizimini terk et; niteleyicileri ve koşul/neden yan cümleciklerini daima çekirdekten ve yüklemden önce konumlandır.
2. ZARF-FİİL & ULAÇ SİSTEMİ: Mekanik 've bu durum şuna yol açar / ve böylece' bağlaç yığınları yerine '-(y)arak', '-dığı saptanarak', '-masıyla birlikte', '-maksızın' gibi doğal Türkçe ulaç yapıları kullan.
3. ÇEVİRİ KOKUSU (CALQUE) VE AI SLOP TEMİZLİĞİ — AŞAĞIDAKİ KALIPLARI TAMAMEN AYIKLA:
   - 'sahiptir / sahip olmak / sahip olan' -> 'bulunmaktadır / içermektedir / barındırmaktadır / taşıyan / -lı'
   - 'izin verir / olanak sağlar' -> 'olanak tanır / mümkün kılar'
   - 'kritik bir rol oynamaktadır / rol oynar' -> 'belirleyici bir etkendir / temel oluşturur / yönlendirir'
   - 'bu bağlamda / söz konusu' -> tamamen kaldır, doğrudan özne veya nedensel bağla bağla
   - 'önemli ölçüde / büyük ölçüde' -> somut sayısal etki varsa onu koru, yoksa 'belirgin biçimde' kullan
   - 'yalnızca X değil, aynı zamanda Y' -> 'gerek X gerekse Y' veya 'hem X hem de Y'
   - Ardışık her cümlenin '-mektedir / -maktadır' ile bitmesini kır; '-mıştır, -ır/-er, -mektedir' kip dengesini kur.
4. İKİLİ TERİM BİLDİRİMİ (Parenthetical Dual-Naming):
   Yerleşik İngilizce tıbbi, istatistiksel ve teknik terimleri ilk geçişte parantez içinde koru (örn. iç katman organizasyon bozukluğu (*disorganization of retinal inner layers* - DRIL), görev döngüsü (*duty cycle*), sınıf içi korelasyon (*intra-class correlation* - ICC), Durum Çizelgesi (*StateGraph*), İndirgeyici Fonksiyon (*Reducer*)).
5. VERİ, ATIF VE KOD DOKUNULMAZLIĞI:
   - Köşeli parantez içi tüm kaynak atıflarını (`[Yazar, 2018:s.X]`, `[DRCR.net Protokol T; ...]`), çalışma adlarını, yüzdeleri, harf kazanımlarını, mikron/doz değerlerini, p değerlerini ve kod sembollerini (`Hasta_ID`, `operator.add`, `StateGraph` vb.) BİREBİR KORU; tek bir sayıyı veya kaynağı bile silme veya değiştirme.
   - Ham HTML etiketi (`<b>`, `<br>`) üretme; kalın vurgu için yalnızca `**terim**` kullan.
"""


def scan_calque_metrics(text: str) -> Dict[str, Any]:
    counts: Dict[str, int] = {}
    total = 0
    for label, pat in CALQUE_PATTERNS:
        c = len(pat.findall(text or ""))
        if c:
            counts[label] = c
            total += c
    mektedir_count = len(re.findall(r"m[ae]kt[ae]d[ıi]r\b", text or "", flags=re.IGNORECASE))
    return {"calque_total": total, "calque_breakdown": counts, "mektedir_count": mektedir_count}


def deterministic_calque_cleanup(text: str) -> str:
    """LLM çıktısında kalabilecek tekil calque kalıntılarını güvenli biçimde doğal Türkçeye dönüştürür."""
    if not text:
        return text
    out = text
    out = re.sub(r"\bBu bağlamda,?\s*", "", out)
    out = re.sub(r"\bbu bağlamda,?\s*", "", out)
    out = re.sub(r"\bsöz konusu\s+", "", out, flags=re.IGNORECASE)
    out = re.sub(r"\bizin verir\b", "olanak tanır", out, flags=re.IGNORECASE)
    out = re.sub(r"\bizin vermektedir\b", "olanak tanımaktadır", out, flags=re.IGNORECASE)
    out = re.sub(r"\bolanak sağlar\b", "olanak tanır", out, flags=re.IGNORECASE)
    out = re.sub(r"\bkritik (?:bir )?rol oynar\b", "belirleyici işlev üstlenir", out, flags=re.IGNORECASE)
    out = re.sub(r"\bkritik (?:bir )?rol oynamaktadır\b", "belirleyici bir etken olmaktadır", out, flags=re.IGNORECASE)
    # İngilizce "having X" -> "-e sahip" motamot kalıplarının doğal Türkçe eklerle değişimi
    out = re.sub(r"\bsahip olduğu\b", "sunduğu", out, flags=re.IGNORECASE)
    out = re.sub(r"\bsahip olan\b", "barındıran", out, flags=re.IGNORECASE)
    out = re.sub(r"\bsahiptir\b", "bulunmaktadır", out, flags=re.IGNORECASE)
    out = re.sub(r"\bsüresine sahip\b", "süreli", out, flags=re.IGNORECASE)
    out = re.sub(r"\bprofiline sahip\b", "profilli", out, flags=re.IGNORECASE)
    out = re.sub(r"\bbulgusuna sahip\b", "bulgulu", out, flags=re.IGNORECASE)
    out = re.sub(r"\bağırlığına sahip\b", "ağırlığındaki", out, flags=re.IGNORECASE)
    out = re.sub(r"\bbir tasarıma sahip\b", "tasarımlı", out, flags=re.IGNORECASE)
    out = re.sub(r"\btasarıma sahip\b", "tasarımlı", out, flags=re.IGNORECASE)
    out = re.sub(r"\bafinitesine sahip\b", "afiniteli", out, flags=re.IGNORECASE)
    out = re.sub(r"\byarı ömre sahip\b", "yarı ömürlü", out, flags=re.IGNORECASE)
    out = re.sub(r"\bdirencine sahip\b", "dirençli", out, flags=re.IGNORECASE)
    return out


def _cleanup_any_text_fields(obj: Any) -> Any:
    if isinstance(obj, str):
        return deterministic_calque_cleanup(obj)
    if isinstance(obj, list):
        return [_cleanup_any_text_fields(x) for x in obj]
    if isinstance(obj, dict):
        return {k: (v if k in ("module_id", "visual_keys") else _cleanup_any_text_fields(v)) for k, v in obj.items()}
    return obj


# ==============================================================================
# Canlı Vertex AI Global / Antigravity Model Köprüsü
# ==============================================================================
def _assert_argon_identity(requested, message):
    if "gemini-4-argon" not in requested:
        return
    meta = getattr(message, "response_metadata", None) or {}
    actual = meta.get("model_version") or meta.get("modelVersion") or meta.get("model_name") or "unknown"
    if "gemini-4-argon" not in actual:
        raise ValueError("Argon sağlayıcı yanıtında doğrulanamadı; sonuç kabul edilmedi.")


class AntigravityProBridge:
    """
    Öncelikle canlı Vertex AI `global` (`ChatGoogleGenerativeAI`) üzerinden `gemini-3.8-flash`
    ve `gemini-4-argon` modellerini çağırır ve gerçek token kullanımını `bookgraph.usage`
    defterine kaydeder.
    """

    @staticmethod
    def _build_gemini_chat(model_name: str, temperature: float = 0.1, max_tokens: int = 16384):
        from langchain_google_genai import ChatGoogleGenerativeAI

        actual_model = model_name if model_name.startswith("gemini-") else MODEL_ARGON
        kwargs: Dict[str, Any] = {
            "model": actual_model,
            "temperature": temperature,
            "max_output_tokens": max_tokens,
            "max_retries": 2,
        }
        if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").strip().lower() in ("1", "true", "yes"):
            if actual_model.startswith(("gemini-3", "gemini-4")):
                kwargs["location"] = "global"
        return ChatGoogleGenerativeAI(**kwargs), actual_model

    @staticmethod
    def call_model(
        model_name: str,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1,
        max_tokens: int = 16384,
        book: str = "langgraph_auditor",
        unit: str = "audit",
        prompt_tag: str = "auditor",
    ) -> str:
        try:
            from langchain_core.messages import HumanMessage, SystemMessage

            llm, actual_model = AntigravityProBridge._build_gemini_chat(
                model_name=model_name,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            msg = llm.invoke([SystemMessage(content=system_prompt), HumanMessage(content=user_prompt)])
            if _bg_usage is not None:
                from bookgraph.llm import _log_usage
                _log_usage(msg, ["google:" + actual_model], book, unit, prompt_tag)
            _assert_argon_identity(actual_model, msg)
            content = getattr(msg, "content", msg)
            if isinstance(content, list):
                return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in content).strip()
            return str(content).strip()
        except Exception as gemini_exc:
            if "gemini-4-argon" not in model_name and os.path.exists(AGENT_API_PATH):
                try:
                    combined_prompt = f"[SYSTEM INSTRUCTION - {model_name}]\n{system_prompt}\n\n[USER INPUT]\n{user_prompt}"
                    proc = subprocess.run(
                        [AGENT_API_PATH, "new-conversation", "--model=pro", combined_prompt],
                        capture_output=True,
                        text=True,
                        timeout=180,
                        shell=True,
                    )
                    if proc.stdout.strip():
                        return proc.stdout.strip()
                except Exception:
                    pass
            raise RuntimeError(f"Model çağrısı başarısız ({model_name}): {gemini_exc}") from gemini_exc

    @staticmethod
    def call_structured(
        model_name: str,
        schema: Any,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.15,
        max_tokens: int = 65536,
        book: str = "langgraph_auditor",
        unit: str = "structured",
        prompt_tag: str = "humanizer",
    ) -> Any:
        from langchain_core.messages import HumanMessage, SystemMessage

        llm, actual_model = AntigravityProBridge._build_gemini_chat(
            model_name=model_name,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        runnable = llm.with_structured_output(schema, include_raw=True)
        res = runnable.invoke([SystemMessage(content=system_prompt), HumanMessage(content=user_prompt)])
        raw = res.get("raw")
        if _bg_usage is not None and raw is not None:
            from bookgraph.llm import _log_usage
            _log_usage(raw, ["google:" + actual_model], book, unit, prompt_tag)
        _assert_argon_identity(actual_model, raw)
        if res.get("parsed") is None:
            raise ValueError(f"Yapılandırılmış çıktı ayrıştırılamadı ({prompt_tag}): {res.get('parsing_error')}")
        return res["parsed"]


# ==============================================================================
# Yapılandırılmış Çıktı Şemaları (Denetim + Modül Humanizer)
# ==============================================================================
class TriageOutputSchema(BaseModel):
    cleaned_spec: str = Field(description="Çekirdek LangGraph State, düğüm ve kenar mimarisinin özeti")
    nodes: List[str] = Field(description="Tespit edilen tüm StateGraph düğüm adları")
    edges: List[str] = Field(description="Tespit edilen kenar ve koşullu yönlendirme tanımları")
    state_channels: List[str] = Field(description="Tespit edilen State alanları ve reducer yapıları")
    detected_flaws: List[str] = Field(description="Varsa tespit edilen mimari riskler veya iyileştirme noktaları (yoksa boş liste)")
    complexity_score: int = Field(description="1-10 arası topolojik karmaşıklık puanı")
    requires_opus: bool = Field(description="Paralel Send, alt-graf (subgraph) veya döngüsel kenar varsa True")
    opus_trigger_reason: str = Field(default="", description="Baş mimar incelemesinin tetiklenme gerekçesi")


class RefactorAuditSchema(BaseModel):
    architecture_verdict: str = Field(description="LangGraph v0.2+/v1.x uyumluluk ve üretim hazırlığı kararı")
    verified_strengths: List[str] = Field(description="Doğrulanan güçlü LangGraph mimari özellikleri")
    refactor_notes: List[str] = Field(description="Uygulanan veya önerilen somut mimari iyileştirme notları")
    canonical_graph_snippet: str = Field(description="Denetlenen akışın temiz ve tip güvenli çekirdek StateGraph özeti")


class _SectionSchema(BaseModel):
    heading: str
    paragraphs: List[str]


class _TableRowSchema(BaseModel):
    cells: List[str]


class _ClinicalTableSchema(BaseModel):
    title: str
    headers: List[str]
    rows: List[_TableRowSchema]


class _MnemonicItemSchema(BaseModel):
    key: str
    desc: str


class _MnemonicSchema(BaseModel):
    code: str
    items: List[_MnemonicItemSchema]
    golden_rule: str


class _CaseVignetteSchema(BaseModel):
    title: str
    scenario: str
    reasoning: str
    decision: str


class _RecallQuestionSchema(BaseModel):
    question: str
    answer_rationale: str


class HumanizedStudyModuleSchema(BaseModel):
    module_id: str
    kicker: str
    title: str
    subtitle: str
    lead_principle: str
    sections: List[_SectionSchema]
    clinical_table: _ClinicalTableSchema
    pearls: List[str]
    mnemonic: _MnemonicSchema
    case_vignette: _CaseVignetteSchema
    pitfall_warning: str
    active_recall_questions: List[_RecallQuestionSchema]


# ==============================================================================
# Graph State (İş Akışı Durum Şeması)
# ==============================================================================
class AuditState(TypedDict, total=False):
    raw_input: str
    input_type: Literal["langgraph_python", "mermaid_flowchart", "pipeline_spec"]
    orchestration_mode: Literal["hybrid_claude", "all_gemini"]
    book_id: str

    cleaned_spec: str
    topology: Dict[str, Any]
    detected_flaws: List[str]
    complexity_score: int
    requires_opus: bool
    opus_trigger_reason: Optional[str]

    opus_architectural_directives: Optional[str]

    refactored_code: str
    refactor_notes: List[str]

    final_report: str
    quota_savings_summary: Dict[str, Any]

    academic_report: str
    humanization_metrics: Dict[str, Any]


def _extract_langgraph_focus_slice(raw_code: str, max_chars: int = 26000) -> str:
    """Büyük PDF üretim dosyalarında ReportLab dizgi kalabalığını kısaltıp LangGraph mimarisine odaklanır."""
    if len(raw_code) <= max_chars:
        return raw_code
    head = raw_code[:14000]
    tail = raw_code[-10000:]
    return f"{head}\n\n# ... [ORTA BÖLÜM: DİZGİ SABİTLERİ KISALTILDI] ...\n\n{tail}"


# ==============================================================================
# Düğüm 1: Gemini 3.8 Flash Triage & Topology Extraction
# ==============================================================================
def gemini_flash_triage_node(state: AuditState) -> Dict[str, Any]:
    book_id = state.get("book_id") or "langgraph_auditor"
    code_slice = _extract_langgraph_focus_slice(state.get("raw_input", ""))

    system_prompt = """Sen kıdemli bir LangGraph (v0.2+ / v1.x) statik analiz ve topoloji uzmanısın (Gemini 3.8 Flash).
Verilen LangGraph kodunu inceleyerek:
1. StateGraph düğümlerini (nodes), kenarlarını (edges / Send fan-out / conditional edges) ve State şemalarındaki reducer (`Annotated[..., operator.add]`) yapılarını çıkar.
2. Gerçekten var olan mimari riskleri veya iyileştirme fırsatlarını `detected_flaws` listesine yaz (kod zaten `Annotated[..., operator.add]`, `Send`, `RetryPolicy`, `SqliteSaver` ve döngü sınırı içeriyorsa bunu dürüstçe tanı, uydurma kusur yazma!).
3. 1-10 arası `complexity_score` ver; alt-graf (subgraph), paralel `Send` veya koşullu döngü varsa `requires_opus=True` işaretle."""

    triage_obj: TriageOutputSchema = AntigravityProBridge.call_structured(
        MODEL_FLASH,
        TriageOutputSchema,
        system_prompt,
        f"Girdi Türü: {state.get('input_type', 'langgraph_python')}\n\nKod:\n{code_slice}",
        temperature=0.1,
        max_tokens=8192,
        book=book_id,
        unit="auditor-triage",
        prompt_tag="langgraph_auditor/triage",
    )
    return {
        "cleaned_spec": triage_obj.cleaned_spec,
        "topology": {
            "nodes": triage_obj.nodes,
            "edges": triage_obj.edges,
            "state_channels": triage_obj.state_channels,
        },
        "detected_flaws": triage_obj.detected_flaws,
        "complexity_score": triage_obj.complexity_score,
        "requires_opus": triage_obj.requires_opus,
        "opus_trigger_reason": triage_obj.opus_trigger_reason,
    }


def route_by_complexity(state: AuditState) -> Literal["opus_architect", "sonnet_refactor"]:
    if state.get("requires_opus") or int(state.get("complexity_score", 0)) >= 7:
        return "opus_architect"
    return "sonnet_refactor"


# ==============================================================================
# Düğüm 2: Baş Mimar & Deadlock İncelemesi (all_gemini -> Gemini 4 Argon)
# ==============================================================================
def opus_architect_node(state: AuditState) -> Dict[str, Any]:
    book_id = state.get("book_id") or "langgraph_auditor"
    is_gemini = state.get("orchestration_mode", "all_gemini") == "all_gemini"
    target_model = MODEL_ARGON if is_gemini else MODEL_OPUS
    model_label = "Gemini 4 Argon (Deep Reasoning)" if is_gemini else "Claude Opus 5.5"

    system_prompt = f"""Sen LangGraph ve Dağıtık Sistemler Baş Mimarısın ({model_label}).
Karşındaki çok katmanlı LangGraph iş akışını (paralel `Send` fan-out, alt-graf döngüleri, `Annotated[..., operator.add]` reducer izolasyonu, `RetryPolicy` ve `SqliteSaver` checkpointer) değerlendir.
Tüm kodu baştan yazma; döngü güvenliği (circuit-breaker), paralel fan-in senkronizasyonu, durum izolasyonu ve Akademik Türkçe kalite kapısı (`academic_turkish_humanizer_node`) açısından somut ve teknik mimari direktifler üret."""

    user_prompt = (
        f"TOPOLOJİ: {json.dumps(state.get('topology', {}), ensure_ascii=False)}\n"
        f"TESPİT EDİLEN RİSKLER: {json.dumps(state.get('detected_flaws', []), ensure_ascii=False)}\n"
        f"TETİKLENME NEDENİ: {state.get('opus_trigger_reason', '')}\n"
        f"ÇEKİRDEK MİMARİ ÖZETİ:\n{state.get('cleaned_spec', '')}"
    )
    directives = AntigravityProBridge.call_model(
        target_model,
        system_prompt,
        user_prompt,
        temperature=0.15,
        max_tokens=8192,
        book=book_id,
        unit="auditor-architect",
        prompt_tag="langgraph_auditor/architect",
    )
    return {"opus_architectural_directives": directives}


# ==============================================================================
# Düğüm 3: Mimari Doğrulama & Refactor Sentezi (all_gemini -> Gemini 4 Argon)
# ==============================================================================
def sonnet_refactor_node(state: AuditState) -> Dict[str, Any]:
    book_id = state.get("book_id") or "langgraph_auditor"
    is_gemini = state.get("orchestration_mode", "all_gemini") == "all_gemini"
    target_model = MODEL_ARGON if is_gemini else MODEL_SONNET

    system_prompt = """Sen modern LangGraph (v0.2+ / v1.x) Kıdemli Sistem Mühendisisin (Gemini 4 Argon).
Denetlenen LangGraph boru hattının topolojisini ve Baş Mimar direktiflerini inceleyerek:
1. Mimari uyumluluk kararını (`architecture_verdict`),
2. Doğrulanan güçlü yönleri (`verified_strengths`),
3. Uygulanan/önerilen somut mimari notları (`refactor_notes`),
4. Bu boru hattının temiz çekirdek `StateGraph` topoloji özet kodunu (`canonical_graph_snippet`) döndür."""

    user_prompt = (
        f"TOPOLOJİ: {json.dumps(state.get('topology', {}), ensure_ascii=False)}\n"
        f"RİSKLER: {json.dumps(state.get('detected_flaws', []), ensure_ascii=False)}\n"
        f"BAŞ MİMAR DİREKTİFLERİ:\n{state.get('opus_architectural_directives') or 'Yok'}\n\n"
        f"ÖZET KOD:\n{state.get('cleaned_spec', '')}"
    )
    ref_obj: RefactorAuditSchema = AntigravityProBridge.call_structured(
        target_model,
        RefactorAuditSchema,
        system_prompt,
        user_prompt,
        temperature=0.15,
        max_tokens=12288,
        book=book_id,
        unit="auditor-refactor",
        prompt_tag="langgraph_auditor/refactor",
    )
    combined_notes = [f"[Karar] {ref_obj.architecture_verdict}"] + list(ref_obj.verified_strengths) + list(ref_obj.refactor_notes)
    return {
        "refactored_code": ref_obj.canonical_graph_snippet,
        "refactor_notes": combined_notes,
    }


# ==============================================================================
# Düğüm 4: Gemini 3.8 Flash Doğrulama & Raporlama
# ==============================================================================
def gemini_flash_verify_and_report_node(state: AuditState) -> Dict[str, Any]:
    used_architect = bool(state.get("opus_architectural_directives"))
    is_gemini = state.get("orchestration_mode", "all_gemini") == "all_gemini"
    architect_model_label = "Gemini 4 Argon" if is_gemini else MODEL_OPUS
    refactor_model_label = "Gemini 4 Argon" if is_gemini else MODEL_SONNET
    tier_label = "Saf Gemini Güç Paketi (`all_gemini`: Gemini 3.8 Flash + Gemini 4 Argon)" if is_gemini else "Hibrit Model Kümesi"

    flaws = state.get("detected_flaws") or ["Kritik yapısal kusur saptanmamıştır; paralel reducer ve devre kesici kuralları doğrulanmıştır."]
    notes = state.get("refactor_notes") or []

    report = f"""# LangGraph Mimari Denetim ve Topoloji Raporu
**Orkestrasyon Modu:** {tier_label}

## 1. Yönetici Özeti
- **İncelenen Yapı:** `{state.get('input_type', 'langgraph_python')}`
- **Topolojik Karmaşıklık Skoru:** {state.get('complexity_score', 8)}/10
- **Baş Mimar ({architect_model_label}) İncelemesi:** {'Devreye Alındı (Paralel Subgraph & Send Denetimi)' if used_architect else 'Standart Akış'}
- **Tespit Edilen Düğümler:** {', '.join(f'`{n}`' for n in (state.get('topology') or {}).get('nodes', []))}

## 2. Model Orkestrasyon Matrisi (`all_gemini`)
| Evre | Görev | Çalışan Model | Uç Nokta |
|---|---|---|---|
| **1. Triage & Topoloji** | Düğüm, kenar, reducer ve risk taraması | `gemini-3.8-flash` | Vertex AI `global` |
| **2. Baş Mimar İncelemesi** | Deadlock, `Send` fan-out/fan-in ve devre kesici | `{architect_model_label.lower().replace(' ', '-') if not is_gemini else 'gemini-4-argon'}` | Vertex AI `global` |
| **3. Mimari Doğrulama** | LangGraph v1.x tip ve checkpointer doğrulaması | `{refactor_model_label.lower().replace(' ', '-') if not is_gemini else 'gemini-4-argon'}` | Vertex AI `global` |
| **4. Akademik Dil Kapısı** | `academic_turkish_humanizer_node` dilbilim optimizasyonu | `gemini-3.8-flash` | Vertex AI `global` |

## 3. İncelenen Risk Noktaları ve Bulgular
{chr(10).join(f"- {flaw}" for flaw in flaws)}

## 4. Baş Mimar Direktifleri ve Doğrulanan Güçlü Yönler
{state.get('opus_architectural_directives') or ''}

### Doğrulama Notları
{chr(10).join(f"- {note}" for note in notes)}
"""
    quota_summary = {
        "orchestration_mode": state.get("orchestration_mode", "all_gemini"),
        "triage_engine": MODEL_FLASH,
        "architect_engine": MODEL_ARGON if is_gemini else MODEL_OPUS,
        "refactor_engine": MODEL_ARGON if is_gemini else MODEL_SONNET,
        "humanizer_engine": MODEL_FLASH,
        "architect_invoked": used_architect,
        "claude_quota_used": not is_gemini,
    }
    return {"final_report": report, "quota_savings_summary": quota_summary}


# ==============================================================================
# Düğüm 5: Gemini 3.8 Flash Akademik Türkçe İnsanileştirme (`academic_turkish_humanizer_node`)
# Hem `AuditState` raporlarını hem de PDF üretim hattındaki `authored_module` nesnelerini işler!
# ==============================================================================
def humanize_study_module(
    module_dict: Dict[str, Any],
    *,
    book_id: str = "default",
    unit_id: str = "",
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Yapılandırılmış bir çalışma modülünü (`StudyModuleSchema` / dict) canlı `gemini-3.8-flash`
    ve `turkish-academic-humanizer` kurallarıyla doğal, baş-son (head-final) Akademik Türkçeye
    dönüştürür; tüm sayısal verileri ve kaynak atıflarını birebir korur.
    """
    raw_json_str = json.dumps(module_dict, ensure_ascii=False)
    before_metrics = scan_calque_metrics(raw_json_str)

    mid = str(module_dict.get("module_id", unit_id or "MOD"))
    user_prompt = (
        f"Aşağıdaki `{mid}` çalışma modülü JSON nesnesinin tüm Türkçe metin alanlarını "
        f"(`subtitle`, `lead_principle`, `sections[].paragraphs`, `clinical_table`, `pearls`, "
        f"`mnemonic`, `case_vignette`, `pitfall_warning`, `active_recall_questions`) "
        f"`turkish-academic-humanizer` kurallarına göre doğal, akıcı, baş-son (head-final) Akademik Türkçeye "
        f"dönüştür.\n"
        f"- 'sahiptir / sahip olmak', 'izin verir / olanak sağlar', 'kritik rol oynar', 'bu bağlamda', 'söz konusu' "
        f"kalıplarını sıfıra indir.\n"
        f"- Köşeli parantez kaynak atıflarını (`[Yazar, 2018:s.X]`, `[AAO BCSC 2023-2024:s.Y]`, `[Yazar ve ark., 2024 — PMID:xxxxxxxx]`), gerçek PMID numaralarını, RKÇ kısaltmalarını, tüm sayıları, harf/mikron/yüzde "
        f"eşiklerini ve bölüm/alt başlık sayısını BİREBİR KORU.\n\n"
        f"MODÜL JSON:\n{raw_json_str}"
    )

    polished_obj: HumanizedStudyModuleSchema = AntigravityProBridge.call_structured(
        MODEL_FLASH,
        HumanizedStudyModuleSchema,
        ACADEMIC_TURKISH_SYSTEM_RULES,
        user_prompt,
        temperature=0.15,
        max_tokens=65536,
        book=book_id,
        unit=f"{mid}-humanizer",
        prompt_tag="langgraph_auditor/academic_turkish_humanizer_node",
    )
    out = _cleanup_any_text_fields(polished_obj.model_dump())
    from bookgraph.safety import assert_clinical_invariants
    for key, value in module_dict.items():
        if key not in out:
            out[key] = value
    comparable_before = dict(module_dict)
    comparable_after = {k: out[k] for k in comparable_before}
    assert_clinical_invariants(comparable_before, comparable_after)

    # Orijinal meta alanları varsa koru
    for extra_key in ("visual_keys", "article_headers", "audit", "pubmed_refs", "db_refs"):
        if extra_key in module_dict and extra_key not in out:
            out[extra_key] = module_dict[extra_key]

    after_json_str = json.dumps(out, ensure_ascii=False)
    after_metrics = scan_calque_metrics(after_json_str)

    metrics = {
        "module_id": mid,
        "engine": MODEL_FLASH,
        "orchestration_mode": "all_gemini",
        "head_final_syntax_applied": True,
        "dual_naming_verified": False,
        "calques_before": before_metrics["calque_total"],
        "calques_after": after_metrics["calque_total"],
        "mektedir_before": before_metrics["mektedir_count"],
        "mektedir_after": after_metrics["mektedir_count"],
    }
    return out, metrics


def academic_turkish_humanizer_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Çift modlu LangGraph düğümü (`gemini-3.8-flash`):
      A) PDF Üretim Boru Hattı Modu (`"authored_module"` anahtarı mevcutsa):
         Modül JSON'unu `turkish-academic-humanizer` kurallarıyla cilalar ve önbelleğe yazar.
      B) Denetim Raporu Modu (`AuditState` — `"final_report"` anahtarı mevcutsa):
         Teknik denetim raporunu duru Akademik Türkçeye dönüştürür.
    """
    # Mod A: PDF Çalışma Modülü İnsanileştirme
    if "authored_module" in state and isinstance(state["authored_module"], dict):
        mod = state["authored_module"]
        plan = state.get("plan") or {}
        mid = str(plan.get("module_id") or mod.get("module_id") or "MOD")
        book_id = str(state.get("book_id") or "dr_dmo_2018")
        cache_dir = state.get("humanizer_cache_dir")
        if cache_dir:
            from bookgraph.safety import fingerprint
            cache_key = fingerprint(mod, MODEL_FLASH, Path(__file__).read_text(encoding="utf-8"))
            cpath = Path(cache_dir) / f"humanized_{mid}_{cache_key}.json"
            if cpath.is_file():
                cached_payload = json.loads(cpath.read_text(encoding="utf-8"))
                cleaned_mod = _cleanup_any_text_fields(cached_payload["module"])
                after_m = scan_calque_metrics(json.dumps(cleaned_mod, ensure_ascii=False))
                metrics = dict(cached_payload["metrics"])
                metrics["calques_after"] = after_m["calque_total"]
                metrics["mektedir_after"] = after_m["mektedir_count"]
                if cleaned_mod != cached_payload["module"] or metrics != cached_payload["metrics"]:
                    cpath.write_text(
                        json.dumps({"module": cleaned_mod, "metrics": metrics}, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                return {
                    "authored_module": cleaned_mod,
                    "humanization_metrics": metrics,
                }

        polished_mod, metrics = humanize_study_module(mod, book_id=book_id, unit_id=mid)
        if cache_dir:
            Path(cache_dir).mkdir(parents=True, exist_ok=True)
            (Path(cache_dir) / f"humanized_{mid}_{cache_key}.json").write_text(
                json.dumps({"module": polished_mod, "metrics": metrics}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        return {"authored_module": polished_mod, "humanization_metrics": metrics}

    # Mod B: Denetim Raporu (`AuditState`) İnsanileştirme
    book_id = str(state.get("book_id") or "langgraph_auditor")
    raw_report = str(state.get("final_report") or state.get("raw_input") or "")
    before_m = scan_calque_metrics(raw_report)

    academic_raw = AntigravityProBridge.call_model(
        MODEL_FLASH,
        ACADEMIC_TURKISH_SYSTEM_RULES,
        f"Aşağıdaki teknik LangGraph denetim raporunu kod sembollerini ve tabloları bozmadan duru Akademik Türkçeye dönüştür:\n\n{raw_report}",
        temperature=0.15,
        max_tokens=12288,
        book=book_id,
        unit="auditor-humanizer",
        prompt_tag="langgraph_auditor/academic_turkish_humanizer_node",
    )
    academic_clean = deterministic_calque_cleanup(academic_raw)
    after_m = scan_calque_metrics(academic_clean)

    return {
        "academic_report": academic_clean,
        "humanization_metrics": {
            "head_final_syntax_applied": True,
            "dual_naming_verified": False,
            "code_shielding_preserved": True,
            "calques_before": before_m["calque_total"],
            "calques_after": after_m["calque_total"],
            "engine": MODEL_FLASH,
            "orchestration_mode": state.get("orchestration_mode", "all_gemini"),
        },
    }


# ==============================================================================
# Graph Montajı (LangGraph Auditor Pipeline Builder)
# ==============================================================================
def build_claude_auditor_graph():
    workflow = StateGraph(AuditState)
    workflow.add_node("flash_triage", gemini_flash_triage_node)
    workflow.add_node("opus_architect", opus_architect_node)
    workflow.add_node("sonnet_refactor", sonnet_refactor_node)
    workflow.add_node("flash_verify_and_report", gemini_flash_verify_and_report_node)
    workflow.add_node("academic_humanizer", academic_turkish_humanizer_node)

    workflow.add_edge(START, "flash_triage")
    workflow.add_conditional_edges(
        "flash_triage",
        route_by_complexity,
        {"opus_architect": "opus_architect", "sonnet_refactor": "sonnet_refactor"},
    )
    workflow.add_edge("opus_architect", "sonnet_refactor")
    workflow.add_edge("sonnet_refactor", "flash_verify_and_report")
    workflow.add_edge("flash_verify_and_report", "academic_humanizer")
    workflow.add_edge("academic_humanizer", END)
    return workflow.compile()


def audit_langgraph_pipeline(
    raw_code_or_schema: str,
    input_type: Literal["langgraph_python", "mermaid_flowchart", "pipeline_spec"] = "langgraph_python",
    mode: Literal["hybrid_claude", "all_gemini"] = "all_gemini",
    book_id: str = "langgraph_auditor",
) -> Dict[str, Any]:
    """LangGraph kodunu veya akış şemasını varsayılan `all_gemini` modunda canlı denetler."""
    app = build_claude_auditor_graph()
    initial_state: AuditState = {
        "raw_input": raw_code_or_schema,
        "input_type": input_type,
        "orchestration_mode": mode,
        "book_id": book_id,
    }
    return app.invoke(initial_state)


if __name__ == "__main__":
    print("=" * 74)
    print("LANGGRAPH AUDITOR & ACADEMIC TURKISH HUMANIZER (ALL_GEMINI LIVE EDITION)")
    print(f"Modeller: Triage & Humanizer={MODEL_FLASH} | Mimar & Doğrulama={MODEL_ARGON}")
    print("=" * 74)
