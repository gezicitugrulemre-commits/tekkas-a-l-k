"""
LangGraph Durum (State) ve Veri Şemaları (Pydantic v2 + TypedDict).
1000 sayfalık kitap boyunca kavram tekrarını önleyen Global Bellek Defteri (Ledger)
ve hiyerarşik Kitap Anahattı (Blueprint) modellerini içerir.
"""

from typing import Annotated, Dict, List, Optional, TypedDict
import operator
from pydantic import BaseModel, Field


# ============================================================================
# 1. HİYERARŞİK KİTAP ANAHATTI (BLUEPRINT) MODELLERİ
# ============================================================================

class SubsectionSpec(BaseModel):
    """Yaprak düğüm: Her biri ~1.050 kelimelik (~2.5 sayfa) tek bir alt-bölüm."""
    subsection_id: str = Field(description="Örn: 'P01-C01-S01'")
    title: str = Field(description="Alt-bölüm başlığı")
    clinical_focus: str = Field(description="Bu alt-bölümde ele alınacak spesifik klinik/anatomik/cerrahi odak")
    key_search_terms: List[str] = Field(description="PDF veritabanında aranacak İngilizce/Türkçe tıbbi anahtar kelimeler")
    required_elements: List[str] = Field(
        default_factory=lambda: [
            "Patofizyoloji / Temel Mekanizma",
            "Klinik Bulgular ve Tanı Kriterleri",
            "Ayırıcı Tanı Tablosu veya Algoritması",
            "Güncel Medikal ve Cerrahi Tedavi Yaklaşımları",
            "Klinik İpuçları (Clinical Pearls)"
        ],
        description="Alt-bölümde bulunması zorunlu akademik alt başlıklar"
    )
    target_words: int = Field(default=1050)
    status: str = Field(default="pending", description="pending | completed | failed")
    output_file: Optional[str] = Field(default=None)
    actual_words: int = Field(default=0)


class ChapterSpec(BaseModel):
    """Orta düğüm: ~5 alt-bölümden oluşan (~12-13 sayfa) tek bir kitap bölümü."""
    chapter_id: str = Field(description="Örn: 'P01-C01'")
    chapter_number: int
    title: str
    overview: str = Field(description="Bölümün kapsamı ve diğer bölümlerle sınırları")
    subsections: List[SubsectionSpec]


class PartSpec(BaseModel):
    """Üst düğüm: Oftalmolojinin 12 ana bilim dalından her biri (~80-85 sayfa)."""
    part_id: str = Field(description="Örn: 'P01'")
    part_number: int
    title: str = Field(description="Örn: 'KISIM VII: RETİNA VE VİTREUS HASTALIKLARI'")
    source_domain_keywords: List[str] = Field(
        description="Bu kısım için önceliklendirilecek kaynak kitap/konu filtreleri (örn: Retina, BCSC Section 12)"
    )
    chapters: List[ChapterSpec]


class BookBlueprint(BaseModel):
    """1000 sayfalık kitabın tamamının hiyerarşik ağacı."""
    book_title: str
    total_parts: int
    total_chapters: int
    total_subsections: int
    estimated_total_words: int
    estimated_total_pages: int
    parts: List[PartSpec]


# ============================================================================
# 2. KÜRESEL TUTARLILIK VE BELLEK DEFTERİ (GLOBAL MEMORY LEDGER)
# ============================================================================

class GlobalMemoryLedger(BaseModel):
    """
    1000 sayfa boyunca aynı bilginin tekrar tekrar anlatılmasını ve terim
    tutarsızlıklarını önleyen merkezi bellek.
    """
    terminology_glossary: Dict[str, str] = Field(
        default_factory=dict,
        description="İngilizce terim -> Standart Türkçe karşılığı (Örn: 'Age-related macular degeneration': 'Yaşa Bağlı Makula Dejenerasyonu (YBMD)')"
    )
    covered_concepts: Dict[str, str] = Field(
        default_factory=dict,
        description="Kavram/Hastalık -> Hangi alt-bölümde detaylı anlatıldığı (Örn: 'Anti-VEGF farmakokinetiği': 'P07-C02-S03')"
    )
    rolling_chapter_summaries: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="chapter_id -> O bölümde şimdiye kadar yazılan alt-bölümlerin kısa özetleri"
    )
    total_words_written: int = 0
    completed_subsection_ids: List[str] = Field(default_factory=list)


# ============================================================================
# 3. LANGGRAPH ALT-BÖLÜM YAZIM DÜĞÜM DURUMU (SECTION WRITER STATE)
# ============================================================================

class RetrievedChunk(BaseModel):
    source_book: str
    page_number: int
    content: str
    score: float = 0.0


class CriticReview(BaseModel):
    is_approved: bool = Field(description="Bölüm yayınlanmaya hazır mı?")
    word_count: int = Field(description="Mevcut kelime sayısı")
    citation_count: int = Field(description="Metin içi kaynak atıf sayısı")
    terminology_issues: List[str] = Field(default_factory=list, description="Terim veya tekrar sorunları")
    missing_clinical_elements: List[str] = Field(default_factory=list, description="Eksik kalan klinik unsurlar")
    revision_instructions: str = Field(default="", description="Yazar modele verilecek net düzeltme talimatı")
    section_summary: str = Field(default="", description="Global belleğe eklenecek 2-3 cümlelik bölüm özeti")
    extracted_terms: Dict[str, str] = Field(default_factory=dict, description="Bu bölümde kullanılan yeni tıbbi terimler")


class SectionWriterState(TypedDict):
    """Tek bir alt-bölümün ( ~1050 kelime ) LangGraph içindeki yaşam döngüsü durumu."""
    # Girdi parametreleri
    part_title: str
    chapter_id: str
    chapter_title: str
    subsection: Dict  # SubsectionSpec.model_dump()

    # Global bellekten aktarılan bağlam (Context)
    previous_sections_summary: str
    already_covered_concepts: str
    standard_glossary: str

    # Düğümler arası üretilen veriler
    search_queries: List[str]
    retrieved_chunks: List[Dict]
    synthesized_evidence: str
    draft_markdown: str

    # Kalite kontrol ve döngü durumu
    revision_count: int
    critic_feedback: str
    is_approved: bool

    # Çıktı özetleri (Global belleği güncellemek için)
    final_summary: str
    new_terms: Dict[str, str]
    final_word_count: int

    # LangGraph İçi $100 WPS / Ultra Kota ve Yönlendirme Durumu
    active_pool: str              # "ultra" | "wps" | "hybrid_fallback"
    selected_writer_model: str
    wps_remaining_usd: float
    section_cost_usd: float
    saved_file_path: str


class BookOrchestratorState(TypedDict):
    """
    Üst Düzey (Master) LangGraph Orkestratör Durumu:
    LangGraph Studio üzerinden tüm 1000 sayfalık kitabın üretim kuyruğunu yönetir.
    """
    batch_limit: int
    processed_count: int
    current_part_id: str
    current_chapter_id: str
    current_subsection_id: str
    last_completed_file: str
    total_words_written: int
    wps_remaining_usd: float
    is_finished: bool
