# -*- coding: utf-8 -*-
r"""
retina_ch4_builder.py — Bölüm 4: Makula Hastalıkları ve Yaşa Bağlı Makula Dejenerasyonu (52 Slayt)
=================================================================================================
Kitap Sayfaları: 127 – 155
Alt Başlıklar:
  4.0   Bölüm 4 Çalışma Yol Haritası (1 slayt)
  4.1.1 Non-Eksüdatif (Kuru) YBMD, Coğrafi Atrofi ve Kompleman İnhibitörleri (8 slayt)
  4.1.2 Eksüdatif (Yaş) YBMD: KNV Tipleri ve Modern Treat-and-Extend Rejimleri (8 slayt)
  4.2.1 Santral Seröz Koryoretinopati (SSKR - Akut, Kronik, PDT Yönetimi) (7 slayt)
  4.2.2 Pakikoroid Spektrumu: PPE ve Pakikoroid Neovaskülarizasyon (6 slayt)
  4.2.3 Polipoidal Koroideal Vaskülopati (PCV - Tanı ve Tedavi) (7 slayt)
  4.3.1 Vitreomaküler Arayüz Bozuklukları: VMT, ERM, FTMH ve Lameller Delik (8 slayt)
  4.3.2 Miyopik Makulopati, Miyopik KNV ve Arka Stafilom (7 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_4(builder: RetinaStudyDeckBuilder):
    """Bölüm 4'e ait 52 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 4 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=4,
        title="MAKULA HASTALIKLARI VE YBMD",
        page_range="Sayfa 127 – 155",
        subtitle="Kuru/Yaş YBMD, Coğrafi Atrofi, Kompleman İnhibitörleri, Pakikoroid Spektrumu ve VMA",
        cards=[
            {
                "title": "1. Kuru YBMD & Coğrafi Atrofi",
                "color": PPTXPalette.AMBER,
                "lead": "Drusen & Kompleman Yolağı",
                "items": [
                    "Drusen Morfolojisi: Sert (<63 μm), yumuşak (>125 μm), retiküler psödodrusen (SDD - subretinal).",
                    "Coğrafi Atrofi (GA): RPE ve fotoreseptörlerin harita benzeri kalıcı kaybı; FAF ile alan takibi.",
                    "Kompleman İnhibitörleri: Pegcetacoplan (C3/C3b - OAKS/DERBY) ve Avacincaptad pegol (C5 - GATHER1/2).",
                    "Yan Etki Uyarısı: Kompleman inhibitörü alan gözlerde %7-12 oranında eksüdatif yaş tipe dönüşüm riski."
                ],
                "footer": "Drusen -> Coğrafi Atrofi -> Anti-C3/C5"
            },
            {
                "title": "2. Neovasküler (Yaş) YBMD",
                "color": PPTXPalette.RED,
                "lead": "KNV Tipleri & Treat-and-Extend",
                "items": [
                    "Tip 1 (Sub-RPE / Okült), Tip 2 (Subretinal / Klasik), Tip 3 (RAP - İntraretinal neovaskülarizasyon).",
                    "Aktivite Belirteçleri: İntraretinal sıvı (IRC - en tehlikeli), subretinal sıvı (SRF) ve SHRM yüksekliği.",
                    "Treat-and-Extend (T&E): Sıvısız kalındıkça aralık 2'şer hafta uzatılarak 12-16 haftaya tırmanılır.",
                    "Yeni Nesil Moleküller: Faricimab (Ang-2/VEGF-A) ve Yüksek Doz Aflibercept 8 mg (PULSAR çalışması)."
                ],
                "footer": "Tip 1/2/3 KNV & T&E Rejimi"
            },
            {
                "title": "3. Pakikoroid Spektrumu",
                "color": PPTXPalette.BLUE,
                "lead": "PPE, SSKR ve PCV",
                "items": [
                    "Çekirdek Mekanizma: Koroid venöz konjesyonu, dev Haller damarları (pakivessel) ve koryokapillaris basısı.",
                    "Santral Seröz Koryoretinopati (SSKR): İdiyopatik nörosensoryal dekolman; kortikosteroid KESİNLİKLE YASAKTIR.",
                    "Yarım Doz / Yarım Akı PDT: Kronik SSKR'de koryokapillaris perfüzyonunu sıfırlayan altın standart tedavi.",
                    "Polipoidal Vaskülopati (PCV): ICGA ile gösterilen nodüler polip anevrizmaları ve kombine PDT."
                ],
                "footer": "Pakivessel -> SSKR / PCV / PDT"
            },
            {
                "title": "4. Vitreomaküler Arayüz (VMA)",
                "color": PPTXPalette.PURPLE,
                "lead": "VMT, ERM, FTMH & Miyopi",
                "items": [
                    "VMA Sınıflaması: VMT (≤400 μm fokal / >400 μm geniş), Epiretinal Membran (ERM) ve kırışıklık.",
                    "Tam Kat Delik (FTMH): Küçük (≤250 μm), orta (250-400 μm), büyük (>400 μm); vitrektomi + İLM soyulması.",
                    "Ters İLM Flep Tekniği: >400 μm büyük ve persistan deliklerde anatomik kapanma oranını %95'e çıkarır.",
                    "Miyopik Traksiyonel Makulopati (MTM): Arka stafilom zemininde foveoskizis ve makula deliği dekolmanı."
                ],
                "footer": "FTMH Cerrahi & Ters İLM Flebi"
            }
        ]
    )

    # =========================================================================
    # KONU 4.1.1: NON-EKSÜDATİF YBMD, COĞRAFİ ATROFİ VE KOMPLEMAN (8 SLAYT)
    # =========================================================================
    # Slayt 4.1.1.1: Drusen Biyogenezi ve Morfolojik Spektrumu
    builder.add_study_card_slide(
        title="DRUSEN BİYOGENEZİ VE SINIFLAMASI",
        category="BÖLÜM 4.1.1: KURU YBMD",
        subtitle="Bruch Membranı İç Katmanında Lipid Birikimi, Boyut Eşikleri ve Risk Derecelendirmesi",
        cards=[
            {
                "card_title": "DRUSENİN BİYOLOJİK KÖKENİ",
                "lead": "RPE Bazal Membranı ile İç Kolajenöz Tabaka Arasında",
                "items": [
                    "Lokalizasyon: RPE hücrelerinin bazal laminası ile Bruch membranının iç kollajen tabakası arasına oturur [s.127].",
                    "Bileşim: Nötral lipidler, esterifiye kolesterol, apolipoprotein E (ApoE), kompleman faktörleri ve amiloid-β.",
                    "Hidrofobik Bariyer: Biriken lipid tabakası koryokapillaris ile RPE arasındaki sıvı ve besin transferini bloke eder.",
                    "İnflamatuar Odak: Drusen yüzeyinde alternatif kompleman yolağı sürekli aktif durumdadır."
                ],
                "footer": "RPE Altı Lipid & Kompleman Odağı"
            },
            {
                "card_title": "BOYUT BAZLI KLİNİK SINIFLAMA",
                "lead": "Sert, Orta ve Yumuşak Drusen",
                "items": [
                    "Sert Drusen (Hard): <63 μm çapında, keskin sınırlı, yuvarlak; yaşa bağlı normal kabul edilebilir [s.128].",
                    "Orta Drusen (Intermediate): 63 - 124 μm çapında; 'Erken YBMD' evresini başlatır.",
                    "Yumuşak Drusen (Soft): ≥125 μm çapında (büyük retinal ven kalınlığı), silik sınırlı, birleşme (confluent) eğilimli.",
                    "Yüksek Risk: ≥125 μm yumuşak drusen varlığı gözü 'Orta Evre YBMD' sınıfına ve yüksek progresyon riskine sokar."
                ],
                "footer": "Sert (<63 μm) | Orta (63-124 μm) | Yumuşak (≥125 μm)"
            },
            {
                "card_title": "KLİNİK PROGNOZ VE DÖNÜŞÜM",
                "lead": "Yumuşak Drusenden Coğrafi Atrofiye",
                "items": [
                    "Drusenoid PED: Geniş yumuşak drusenlerin birleşerek RPE tabakasını >350-500 μm yükseklikte kaldırması [s.128].",
                    "Drusen Kollapsı: Yıllar içinde drusen apeksindeki RPE ölür; drusen kendi içine çökerek yerinde coğrafi atrofi bırakır.",
                    "Kalsifik Drusen: Eskiyen drusenlerin içinde parlak beyaz kalsiyum fosfat kristalleri çöker.",
                    "AREDS Formülü: Orta veya büyük druseni olan hastalara antioksidan AREDS2 formülü (C, E, Çinko, Lutein) başlanmalıdır."
                ],
                "footer": "Kollaps = Coğrafi Atrofi | AREDS2 Desteği"
            }
        ]
    )

    # Slayt 4.1.1.2: Retiküler Psödodrusen (Subretinal Drusenoid Deposits - SDD)
    builder.add_study_card_slide(
        title="RETİKÜLER PSÖDODRUSEN (SDD) ANATOMİSİ VE ÖNEMİ",
        category="BÖLÜM 4.1.1: KURU YBMD",
        subtitle="RPE'nin Apikal Yüzünde Subretinal Birikim, Koryokapillaris Hipoperfüzyonu ve Yüksek Risk",
        cards=[
            {
                "card_title": "KLASİK DRUSENDEN TEMEL FARKI",
                "lead": "Sub-RPE Değil, SUBRETİNAL Lokalizasyon",
                "items": [
                    "Klasik Drusen: RPE'nin altında (Bruch ile RPE arasında) yerleşir [s.128].",
                    "Retiküler Psödodrusen (SDD): RPE'nin üstünde, nörosensoryal retina ile fotoreseptörler arasında yerleşir.",
                    "OKT Karakteristiği: RPE üzerinden yukarı doğru, EZ bandını delen sivri hiperreflektif koniler (tepecikler).",
                    "Dağılım Deseni: Fovea merkezinden ziyade üst makula ve perifoveada dantela benzeri ağ örgüsü oluşturur."
                ],
                "footer": "Subretinal Koniler / Üst Makula Tercihi"
            },
            {
                "card_title": "EN İYİ GÖRÜNTÜLEME MODALİTELERİ",
                "lead": "Kızılötesi (IR), FAF ve Mavi Işık",
                "items": [
                    "Renkli Fundusta Zordur: Standart fundus muayenesinde soluk ve zor seçilir [s.129].",
                    "Yakın Kızılötesi (Near-Infrared / IR): Retiküler ağı hipo-reflektif koyu benekler halinde en net gösteren yöntemdir.",
                    "Mavi Işık ve FAF: Mavi filtrede yüksek kontrast verir; FAF'ta küçük hipootofloresan benek adacıkları izlenir.",
                    "SD-OKT Doğrulaması: Dış nükleer tabakaya (ONL) doğru uzanan konilerle kesin histolojik tanı konur."
                ],
                "footer": "En Net: Yakın Kızılötesi (IR) & FAF"
            },
            {
                "card_title": "AGRESİF PROGNOSTİK ANLAM",
                "lead": "Coğrafi Atrofi ve Tip 3 KNV Habercisi",
                "items": [
                    "Koryokapillaris Hipoperfüzyonu: SDD varlığı derin koroid dolaşımının yaygın olarak yetersiz olduğunu yansıtır [s.129].",
                    "Coğrafi Atrofi Riski: Klasik drusene göre coğrafi atrofiye ilerleme hızını 3 - 4 KAT artırır.",
                    "Tip 3 KNV (RAP) Birlikteliği: Neovaskülarizasyon gelişirse ezici oranda Tip 3 KNV (intraretinal) formunda çıkar.",
                    "Kardiyovasküler Korelasyon: Koroner arter hastalığı ve karotis darlığı olan bireylerde SDD prevalansı çok daha yüksektir."
                ],
                "footer": "3-4 Kat Artmış Atrofi & Tip 3 KNV Riski"
            }
        ]
    )

    # Slayt 4.1.1.3: Coğrafi Atrofi (GA) Patolojisi ve İlerleme Dinamiği
    builder.add_study_card_slide(
        title="COĞRAFİ ATROFİ (GA) PATOLOJİSİ VE SINIR DİNAMİĞİ",
        category="BÖLÜM 4.1.1: KURU YBMD",
        subtitle="RPE ve Dış Retina Kaybı, Hipertransmisyon, FAF Kenar Paternleri ve Foveal Korunma",
        cards=[
            {
                "card_title": "COĞRAFİ ATROFİ ANATOMİK TANIMI",
                "lead": "RPE, Fotoreseptör ve Koryokapillarisin Yok Olması",
                "items": [
                    "Tanım: Çapı ≥175 μm olan, sınırları keskin, RPE ve fotoreseptörlerin tam kaybıyla giden atrofi alanıdır [s.129].",
                    "Göz Dibi Görünümü: RPE kalktığı için alttaki büyük koroid damarları ve beyaz sklera çıplak görünür.",
                    "OKT'de Hipertransmisyon: Işık RPE bariyerine takılmadan skleraya kadar derinleşir (parlak dikey sütun).",
                    "Santral Skotom: Atrofiye uğrayan retina alanında kesin ve geri dönüşsüz absolü kör nokta gelişir."
                ],
                "footer": "RPE Kaybı + OKT Hipertransmisyonu"
            },
            {
                "card_title": "FOVEAL KORUNMA (FOVEAL SPARING)",
                "lead": "Santral 10/10 Görmenin Son Ana Kadar Sürmesi",
                "items": [
                    "Atrofi Başlangıcı: Tipik olarak foveanın hemen çevresinde (parafoveada) parasantral at nalı şeklinde başlar [s.130].",
                    "Koni Direnci: Foveal koniler çomaklara göre kompleman saldırısına ve iskemiye daha uzun süre direnir.",
                    "Foveal Sparing: Hasta fovea merkezinde 10/10 görmeyi korur ancak çevresinde okuma ve yüz tanıma körlüğü yaşar.",
                    "Nihai Çöküş: Yıllar içinde atrofi adaları birleşerek fovea merkezini yutar; görme dramatik olarak sıfırlanır."
                ],
                "footer": "Foveal Sparing = Çevresi Kör / Merkez Sağlam"
            },
            {
                "card_title": "FAF KENAR PATERNLERİ VE BÜYÜME HIZI",
                "lead": "Junctionel Zon ve Progresyon Tahmini",
                "items": [
                    "Atrofi İçi: RPE olmadığı için zifiri kapkara hipo-otoflöresandır [s.130].",
                    "Bileşke Zonu (Junction): Atrofi sınırındaki hasta RPE hücreleri aşırı lipofuskin biriktirerek parlak hiper-FAF verir.",
                    "Bant Patern (Banded): Kesintisiz kalın hiper-FAF halkası en hızlı ilerleyen (yılda >2 mm²) agresif tiptir.",
                    "Diffüz Patern: Arka kutba saçılmış hiper-FAF lekeleri çok odaklı hızlı büyümeyi haber verir."
                ],
                "footer": "Banded Hiper-FAF = Hızlı Atrofi Büyümesi"
            }
        ]
    )

    # Slayt 4.1.1.4: Kompleman Kaskadı ve Coğrafi Atrofi İlaçları
    builder.add_study_card_slide(
        title="KOMPLEMAN KASKADI VE COĞRAFİ ATROFİ FARMAKOTERAPİSİ",
        category="BÖLÜM 4.1.1: KURU YBMD",
        subtitle="Pegcetacoplan (Syfovre - C3) ve Avacincaptad Pegol (Izervay - C5) Kanıtları",
        cards=[
            {
                "card_title": "ALTERNATİF KOMPLEMAN AŞIRI AKTİVİTESİ",
                "lead": "Membran Atak Kompleksi (MAC / C5b-9)",
                "items": [
                    "Genetik Temel: Faktör H (CFH Y402H) ve ARMS2 mutasyonları kompleman frenini gevşetir [s.131].",
                    "Sürekli Saldırı: Baskılanamayan alternatif yolak RPE hücre zarına saldırır.",
                    "MAC Gözenekleri: C5b-9 kompleksi RPE hücre zarını delerek hücresel lizis ve apoptoza yol açar.",
                    "Hedef: Kompleman kaskadının C3 veya C5 basamağında kilitlenerek atrofi yayılımının yavaşlatılmasıdır."
                ],
                "footer": "CFH Kusuru -> C3/C5 Aktivasyonu -> MAC Lizisi"
            },
            {
                "card_title": "PEGCETACOPLAN (SYFOVRE) — C3 İNHİBİTÖRÜ",
                "lead": "OAKS ve DERBY Faz 3 Çalışmaları",
                "items": [
                    "Molekül: Pegillenmiş sentetik bisiklik peptid (C3 ve C3b'yi bloke eder) [s.131].",
                    "Etki Düzeyi: Kaskadı en üst noktada keserek hem opsonizasyonu hem inflamasyonu hem MAC'ı durdurur.",
                    "OAKS & DERBY Sonucu: Aylık veya 2 ayda bir uygulamayla coğrafi atrofi büyüme hızını %18 - 22 yavaşlattı.",
                    "FDA Onayı: Coğrafi atrofi tedavisinde onay alan dünyadaki ilk ilaçtır (Şubat 2023)."
                ],
                "footer": "C3 Blokajı / Atrofi Büyümesinde %20 Yavaşlama"
            },
            {
                "card_title": "AVACİNCAPTAD PEGOL (IZERVAY) — C5 İNHİBİTÖRÜ",
                "lead": "GATHER 1 ve GATHER 2 Faz 3 Çalışmaları",
                "items": [
                    "Molekül: Pegillenmiş RNA aptameri; kompleman C5'i seçici olarak inhibe eder [s.132].",
                    "Etki Düzeyi: C3b opsonizasyonunu korurken, terminal inflamatuar C5a ve litik C5b-9'u susturur.",
                    "GATHER Sonucu: 12. ayda coğrafi atrofi büyüme hızında %14 - 18 oranında istatistiksel anlamlı yavaşlama.",
                    "Güvenlik Profili: Hedefe yönelik C5 blokajı ile güvenilir terapötik kontrol sağlar."
                ],
                "footer": "C5 Blokajı / Terminal MAC Engeli"
            }
        ]
    )

    # Slayt 4.1.1.5: Kompleman Tedavisinde Yaş Tip YBMD Dönüşüm Riski
    builder.add_study_card_slide(
        title="KOMPLEMAN İNHİBİSYONUNDA EKSÜDATİF (YAŞ) TİP DÖNÜŞÜM ALARMI",
        category="BÖLÜM 4.1.1: KURU YBMD",
        subtitle="OAKS/DERBY ve GATHER'da %7 - 12 Oranında KNV Gelişimi ve Güvenlik Yönetimi",
        cards=[
            {
                "card_title": "PARADOKSAL NEOVASKÜLARİZASYON",
                "lead": "%7 - 12 Yaş Tip YBMD Dönüşümü",
                "items": [
                    "Klinik Gerçek: Kompleman inhibitörü alan kuru YBMD gözlerinde KNV gelişme riski sahte kola göre belirgin artar [s.132].",
                    "İnsidans: Aylık pegcetacoplan alanlarda 2. yılda yaş tip dönüşüm oranı yaklaşık %12'ye ulaşır.",
                    "Mekanizma Hipotezi: Kompleman MAC lizisi azalınca endotel hücreleri hayatta kalır; koryokapillaris filizlenmesi kolaylaşır.",
                    "Lezyon Tipi: Gelişen KNV lezyonlarının çoğunluğu RPE altı Tip 1 KNV (okült) formundadır."
                ],
                "footer": "Kuru Tip Tedavisinde %12 Yaş Tip Riski"
            },
            {
                "card_title": "OKT İLE YAKIN MONİTÖRİZASYON",
                "lead": "Her Enjeksiyonda Sıvı Taraması",
                "items": [
                    "Zorunlu Protokol: Kompleman inhibitörü yapılan her vizitte enjeksiyon öncesi foveal SD-OKT çekilir [s.132].",
                    "Sıvı Tespiti: İntraretinal veya subretinal sıvı belirdiği anda yaş tipe dönüşüm kabul edilir.",
                    "Kombine Tedavi: KNV geliştiğinde kompleman inhibitörü kesilmez; tedaviye eşzamanlı Anti-VEGF enjeksiyonu eklenir.",
                    "Çift Tedavi Güvenliği: Anti-VEGF + Kompleman inhibitörü aynı seansta farklı kadranlardan güvenle uygulanabilir."
                ],
                "footer": "Her Vizitte OKT / Sıvı Varsa Anti-VEGF Ekle"
            },
            {
                "card_title": "OKÜLER İNFLAMASYON VE VASKÜLİT",
                "lead": "Nadir Fakat Kör Edici Oklüzif Vaskülit",
                "items": [
                    "Pazarlama Sonrası Uyarı: Pegcetacoplan sonrası nadir (1/10.000) görülen kör edici oklüzif retinal vaskülit bildirilmiştir [s.133].",
                    "Klinik Tablo: Enjeksiyondan 1-2 hafta sonra ağır ön ve arka üveit ile periferik arter tıkanıklığı.",
                    "Risk Yönetimi: Enjeksiyon öncesi gözde hiçbir aktif üveitik reaksiyon veya enfeksiyon olmamalıdır.",
                    "Hasta Eğitimi: Ağrı veya ani görme kaybında beklemeden acil oftalmolojiye başvurulması tembihlenir."
                ],
                "footer": "1/10.000 Oklüzif Retinal Vaskülit Riski"
            }
        ]
    )

    # Slayt 4.1.1.6: Atlas Görseli: Coğrafi Atrofi ve FAF İlerlemesi
    img_p130 = builder.get_image_for_page(130)
    builder.add_atlas_image_slide(
        title="COĞRAFİ ATROFİ FAF VE OKT İLERLEME ATLASI",
        category="BÖLÜM 4.1.1: GÖRSEL ATLAS",
        subtitle="Zifiri Hipo-FAF Atrofi Odakları, Bileşke Zonu Hiper-FAF Halkası ve Hipertransmisyon",
        image_path=img_p130 or "dr_schema_4",
        caption="Referans Eser Sayfa 130: Coğrafi Atrofinin Yıllık Büyümesi, Junctionel Hiper-FAF ve Foveal Sparing",
        key_findings=[
            "Harita Biçimli Atrofi: Keskin kenarlı, koroid damarlarının çıplak göründüğü geniş atrofi sahası [s.130].",
            "Junctionel Hiper-FAF: Atrofi adasını kuşatan parlak beyaz hiperotofloresan metabolik stres halkası.",
            "OKT Koroid Hipertransmisyonu: Atrofiye uğramış RPE'nin altındaki skleraya ışığın serbestçe inmesi.",
            "Korunmuş Foveal Ada: Fovea merkezinde sağlam kalmış küçük fotoreseptör tepesi (foveal sparing)."
        ],
        differentials=[
            "Miyopik Koryoretinal Atrofi: Aksiyel miyopiye bağlı yaygın arka kutup solukluğu; drusen içermez.",
            "Toksik Klorokin Retinopati: Tipik konsantrik 'öküz gözü' halkası ve ilaç kullanım öyküsü.",
            "Santral Areoler Koroid Distrofisi: Otozomal dominant kalıtım ve erken yaşta başlangıç."
        ],
        clinical_pearl="Coğrafi atrofi ilaçları (Syfovre/Izervay) kaybedilmiş görmeyi geri getirmez veya mevcut atrofiyi küçültmez; var olan görmeyi korumak için büyüme hızını %20 yavaşlatır; hastaya gerçekçi beklenti anlatılmalıdır [s.131]."
    )

    # Slayt 4.1.1.7: Karşılaştırmalı Analiz: Pegcetacoplan vs Avacincaptad Pegol
    builder.add_split_comparison_slide(
        title="COĞRAFİ ATROFİ TEDAVİSİNDE İKİ AJAN: C3 VS C5 İNHİBİSYONU",
        category="BÖLÜM 4.1.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Pegcetacoplan (Syfovre) vs Avacincaptad Pegol (Izervay) Karşılaştırması",
        left_entity={
            "name": "PEGCETACOPLAN (SYFOVRE - C3)",
            "features": [
                ("Moleküler Hedef", "Kompleman C3 ve aktif fragmanı C3b [s.131]."),
                ("Molekül Yapısı", "Bisiklik pegillenmiş peptid."),
                ("Uygulama Aralığı", "Aylık VEYA 2 ayda bir (esnek dozlama seçeneği)."),
                ("Faz 3 Çalışmaları", "OAKS ve DERBY (24 aylık takip verisi mevcut)."),
                ("Etkinlik", "Atrofi büyüme hızında %18 - 22 yavaşlama; etki 2. yılda katlanarak artar."),
                ("Güvenlik Profili", "Yaş tipe dönüşüm %12; çok nadir oklüzif retinal vaskülit riski bildirilmiştir.")
            ]
        },
        right_entity={
            "name": "AVACİNCAPTAD PEGOL (IZERVAY - C5)",
            "features": [
                ("Moleküler Hedef", "Yalnızca kompleman C5 (terminal yolak) [s.132]."),
                ("Molekül Yapısı", "Pegillenmiş RNA aptameri."),
                ("Uygulama Aralığı", "Aylık uygulama (12 ay boyunca)."),
                ("Faz 3 Çalışmaları", "GATHER1 ve GATHER2 (12 aylık primer sonlanım)."),
                ("Etkinlik", "Atrofi büyüme hızında %14 - 18 yavaşlama."),
                ("Güvenlik Profili", "Yaş tipe dönüşüm yaklaşık %7; henüz oklüzif vaskülit vakası bildirilmemiştir.")
            ]
        },
        bottom_takeaway="Pegcetacoplan kaskadı en tepeden (C3) keserek daha güçlü yavaşlatma sağlarken 2 ayda bir kullanım esnekliği sunar; Avacincaptad ise seçici C5 blokajıyla vaskülitsiz güvenlik profili sergiler [s.133]."
    )

    # Slayt 4.1.1.8: Karar Ağacı: Kuru YBMD Takip ve İlaç Başlama Algoritması
    builder.add_decision_tree_slide(
        title="KURU YBMD VE COĞRAFİ ATROFİ HASTA YÖNETİM ALGORİTMASI",
        category="BÖLÜM 4.1.1: KARAR AĞACI",
        subtitle="Drusen Evresinden Kompleman Tedavisi Adaylığına ve Yaş Tip Takibine",
        root_label="KURU YBMD KLİNİK VE FAF DEĞERLENDİRMESİ",
        branches=[
            {
                "label": "1. Erken / Orta YBMD (Drusen Var, GA Yok)",
                "criteria": "≥125 μm yumuşak drusen veya pigment değişiklikleri mevcut; atrofi gelişmemiş [s.128].",
                "action": "Yönetim: AREDS2 antioksidan formülü başla; Amsler kartı ver; yıllık FAF ve OKT ile izle."
            },
            {
                "label": "2. Ekstrafoveal Coğrafi Atrofi (Foveal Sparing)",
                "criteria": "FAF'ta subfoveal olmayan fokal GA adaları; görme 10/10; kenarda hiper-FAF halkası [s.130].",
                "action": "Yönetim: EN İDEAL KOMPLEMAN ADAYI -> Foveayı kurtarmak için Pegcetacoplan veya Avacincaptad başla."
            },
            {
                "label": "3. Subfoveal Büyük Coğrafi Atrofi",
                "criteria": "Atrofi fovea merkezini tamamen yutmuş; görme <20/200'e çökmüş; devasa skotom [s.130].",
                "action": "Yönetim: İlaç faydası sınırlıdır -> Az Görenlere Yardım (LVR) teleskopik sistemler ve rehabilitasyon."
            }
        ],
        bottom_rule="Kompleman tedavisi alan her hastada her enjeksiyonda OKT çekilmeli; foveal sıvı görülürse beklemeden anti-VEGF eklenmelidir [s.132]."
    )

    # =========================================================================
    # KONU 4.1.2: EKSÜDATİF (YAŞ) YBMD: KNV VE T&E (8 SLAYT)
    # =========================================================================
    # Slayt 4.1.2.1: Neovasküler YBMD Patofizyolojisi ve Sınıflaması
    builder.add_study_card_slide(
        title="NEOVASKÜLER (YAŞ) YBMD SINIFLAMASI VE VASKÜLER TİPLER",
        category="BÖLÜM 4.1.2: YAŞ YBMD",
        subtitle="Konsensus Kriterleri: Tip 1 (Okült / Sub-RPE), Tip 2 (Klasik / Subretinal) ve Tip 3 (RAP)",
        cards=[
            {
                "card_title": "TİP 1 KNV (SUB-RPE / OKÜLT)",
                "lead": "RPE'nin Altında Gelişen Vasküler Ağ",
                "items": [
                    "Anatomik Yerleşim: Bruch membranı ile RPE tabakası arasına oturur (%70-80 en sık form) [s.133].",
                    "Klinik Bulgular: Fibrovasküler pigment epitel dekolmanı (PED) oluşturur.",
                    "Doğal Koruma: RPE üzerini örttüğü için fotoreseptörleri doğrudan mekanik olarak tahrip etmez; görme yavaş düşer.",
                    "Pakikoroid Form: Pakikoroid neovaskülarizasyon (PKNV) morfolojik olarak bir Tip 1 KNV'dir."
                ],
                "footer": "%75 En Sık Tip / Sub-RPE Yerleşim"
            },
            {
                "card_title": "TİP 2 KNV (SUBRETİNAL / KLASİK)",
                "lead": "RPE'yi Delip Nörosensoryal Retinanın Altına Çıkan Tip",
                "items": [
                    "Anatomik Yerleşim: RPE ve Bruch'u yırtarak subretinal potansiyel aralığa fırlar (%15-20) [s.134].",
                    "Klinik Bulgular: Subretinal hiperreflektif materyal (SHRM), taze subretinal kanama ve yoğun sıvı.",
                    "Agresif Hasar: Doğrudan fotoreseptör tabakasıyla temas halindedir; tedavi edilmezse hızla disiform skara gider.",
                    "FA Manzarası: Erken fazda parlak dantela deseni ve geç fazda masif floresein sızıntısı."
                ],
                "footer": "Subretinal Medusa Başı / Hızlı Skar Riski"
            },
            {
                "card_title": "TİP 3 KNV (RAP / İNTRARETİNAL)",
                "lead": "Retinal Anjiyomatöz Proliferasyon",
                "items": [
                    "Köken: Koroidden değil; derin retinal kapiller pleksustan (DVP) başlayarak aşağıya büyür (%10-15) [s.134].",
                    "Retino-Koroideal Şant: İntraretinal başlayan damarlar RPE'yi delip koroid dolaşımıyla anastomoz yapar.",
                    "Yaşlı Kadınlar & SDD: İleri yaşlı, retiküler psödodruseni olan kadınlarda iki taraflı tutulum sıktır.",
                    "Hızlı RPE Atrofisi: Anti-VEGF ile hızla kurur ancak aylar içinde lezyon yerinde fokal derin atrofi bırakır."
                ],
                "footer": "İntraretinal Başlangıç -> Koroide Anastomoz"
            }
        ]
    )

    # Slayt 4.1.2.2: OKT Aktivite Biyobelirteçleri (IRC vs SRF)
    builder.add_split_comparison_slide(
        title="YAŞ YBMD'DE SIVI ANALİZİ: İNTRARETİNAL (IRC) VS SUBRETİNAL (SRF)",
        category="BÖLÜM 4.1.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Hangi Sıvıyı Tamamen Kurutmalıyız? CVIEW ve FLUID Çalışmaları Işığında Kriterler",
        left_entity={
            "name": "İNTRARETİNAL SIVI (IRC / KİSTLER)",
            "features": [
                ("Lokalizasyon", "Nörosensoryal retina tabakaları içinde kistoid boşluklar [s.134]."),
                ("Hücresel Anlam", "Müller hücre ölümü, nöronal dejenerasyon ve aktif vasküler yıkım."),
                ("Görsel Etki", "EN YIKICI SIVI TÜRÜDÜR; görme keskinliğinde doğrudan kalıcı düşüş yaratır."),
                ("Klinik Tolerans", "KESİNLİKLE TOLERE EDİLEMEZ; sıfır IRC hedeflenmelidir (zero tolerance)."),
                ("Tedavi Eylemi", "Tek bir foveal intraretinal kist dahi görülse enjeksiyon aralığı derhal kısaltılmalıdır.")
            ]
        },
        right_entity={
            "name": "SUBRETİNAL SIVI (SRF / SUBLİKİT)",
            "features": [
                ("Lokalizasyon", "Nörosensoryal retina ile RPE arasındaki potansiyel boşlukta sıvı [s.135]."),
                ("Hücresel Anlam", "Bozulmuş RPE pompasının tahliye edemediği seröz göllenme."),
                ("Görsel Etki", "FLUID Çalışması: Hafif subfoveal SRF (<100 μm) varlığında görme kaybı gelişmez!"),
                ("Klinik Tolerans", "KISMEN TOLERE EDİLEBİLİR; RPE atrofisini geciktirici koruyucu rolü olabilir."),
                ("Tedavi Eylemi", "IRC yoksa ve görme stabilse, küçük bir SRF cebi için aralık kısaltılmayabilir.")
            ]
        },
        bottom_takeaway="İntraretinal sıvı (IRC) aktif nöron hasarıdır ve asla tolere edilemez; subretinal sıvı (SRF) ise görmeyi bozmuyorsa kontrollü tolere edilebilir (FLUID çalışma konsensusu) [s.135]."
    )

    # Slayt 4.1.2.3: Modern Treat-and-Extend (T&E) Rejimi
    builder.add_study_card_slide(
        title="TREAT-AND-EXTEND (T&E) UYGULAMA STANDARDI",
        category="BÖLÜM 4.1.2: YAŞ YBMD",
        subtitle="Sıvısız Dönemde Enjeksiyon Aralığını Uzatma, Nüks Yönetimi ve Klinik Başarı",
        cards=[
            {
                "card_title": "T&E FELSEFESİ VE MANTIĞI",
                "lead": "Proaktif ve Kişiselleştirilmiş Aralık",
                "items": [
                    "Her Vizitte Enjeksiyon: Hasta kliniğe her geldiğinde OKT çekilir ve MUTLAKA enjeksiyonu yapılır [s.135].",
                    "Sıvı Varlığında: Foveada aktif sıvı (özellikle IRC) varsa enjeksiyon aralığı 4 haftaya sabitlenir.",
                    "Sıvı Yokluğunda: Fovea tamamen kuruysa bir sonraki randevu aralığı 2 hafta uzatılır (4 -> 6 -> 8 -> 10 -> 12 hafta).",
                    "Maksimum Aralık: Klasik anti-VEGF ile 12 hafta; yeni nesil ajanlarla (Faricimab/Aflibercept 8mg) 16-20 hafta."
                ],
                "footer": "Kuruysa 2 Hafta Uzat / Her Vizitte Yap"
            },
            {
                "card_title": "NÜKS YÖNETİMİ (REAKTİVASYON)",
                "lead": "Aralığı Kısalt ve Sabitle",
                "items": [
                    "Sıvı Tekrar Belirdiğinde: Aralık en son sıvısız kalınan başarılı haftaya (ör. 10 haftadan 8 haftaya) çekilir [s.135].",
                    "Sabit İdame: Hasta o aralıkta (ör. 8 haftada bir) kararlı olarak takip edilir.",
                    "PRN'ye Göre Üstünlüğü: PRN'de sıvı nüksettikten sonra müdahale edilir (reaktif); görme kaybı birikir.",
                    "T&E Üstünlüğü: Sıvı hiç nüksetmeden baskılanır; 5 yıllık görme kazanımları en yüksek rejimdir."
                ],
                "footer": "Nükste 2 Hafta Kısalt ve Sabitle"
            },
            {
                "card_title": "TEDAVİYİ SONLANDIRMA (DISCONTINUATION)",
                "lead": "Enjeksiyon Kesilebilir mi?",
                "items": [
                    "Kronik Hastalık Gerçeği: Yaş YBMD genetik ve vasküler zemini olan ömür boyu kronik bir patolojidir [s.136].",
                    "Kesilme Riski: Tedavi tamamen kesildiğinde hastaların %80'inde 1 yıl içinde agresif nüks ve kanama gelişir.",
                    "Maksimum Aralıkta İdame: Hasta 12 veya 16 haftalık aralıkta stabilse, enjeksiyonu kesmek yerine o aralıkta sürdürmek en güvenlisidir.",
                    "İstisna: Geniş disiform skar veya coğrafi atrofiye dönmüş, görme potansiyeli kalmayan gözlerde sonlandırılır."
                ],
                "footer": "Tedaviyi Kesmek Yüksek Nüks Riski Taşır"
            }
        ]
    )

    # Slayt 4.1.2.4: Yeni Nesil Ajanlar: Faricimab ve Yüksek Doz Aflibercept 8 mg
    builder.add_study_card_slide(
        title="YENİ NESİL ANTİ-VEGF MOLEKÜLLERİ: FARİCİMAB VE AFLİBERCEPT 8 MG",
        category="BÖLÜM 4.1.2: YAŞ YBMD",
        subtitle="TENAYA/LUCERNE ve PULSAR Faz 3 Çalışmaları Işığında 16-20 Haftalık Dayanıklılık",
        cards=[
            {
                "card_title": "FARİCİMAB (VABYSMO - DUAL BLOKAJ)",
                "lead": "TENAYA ve LUCERNE Çalışmaları (Lancet)",
                "items": [
                    "Bileşim: 6 mg / 0.05 ml bispesifik antikor; VEGF-A ve Angiopoietin-2'yi (Ang-2) birlikte nötralize eder [s.136].",
                    "Damar Stabilizasyonu: Ang-2'yi susturarak Tie-2 yolağını açar; damar sızıntısını ve inflamasyonu kilitler.",
                    "Dayanıklılık Sonucu: Hastaların yaklaşık %80'i 12 hafta veya daha uzun; %63'ü 16 HAFTALIK (4 ay) aralığa ulaştı.",
                    "Hızlı Kuruluk: Standart anti-VEGF'e göre foveal sıvıyı ve SHRM'yi çok daha hızlı temizler."
                ],
                "footer": "TENAYA/LUCERNE: %63 Hasta 16 Haftada"
            },
            {
                "card_title": "YÜKSEK DOZ AFLİBERCEPT 8 MG",
                "lead": "PULSAR Çalışması (4 Kat Molar Doz)",
                "items": [
                    "Formülasyon Devrimi: 8 mg / 0.07 ml; standart Eylea'nın tam 4 katı molar konsantrasyonda tuzak protein [s.136].",
                    "Göz İçi Yarı Ömür Uzaması: Vitreus içi terapötik konsantrasyonu standart 2 mg'a göre haftalarca uzun sürer.",
                    "PULSAR Sonucu: 1. yılda hastaların %83'ü 12 hafta veya daha uzun; %78'i 16 HAFTALIK aralıkta görmeyi korudu.",
                    "Güvenlik Profili: 4 kat yüksek doza rağmen göz içi inflamasyon ve GİB güvenlik profili standart dozla farksızdır."
                ],
                "footer": "PULSAR: %78 Hasta 16 Haftada / Eşit Güvenlik"
            },
            {
                "card_title": "KLİNİK PARADİGMA DEĞİŞİMİ",
                "lead": "Enjeksiyon Yükünün Düşürülmesi",
                "items": [
                    "Yılda 3-4 Enjeksiyon: Yeni ajanlarla hastalar yılda 8-10 enjeksiyon yerine yalnızca 3-4 enjeksiyonla kuru kalabilir [s.137].",
                    "Hasta Uyumu Artışı: Hastane ziyaret sıklığı azaldığı için tedavi aksatma oranları dramatik düşer.",
                    "Dirençli Sıvının Kurutulması: Klasik ajanlarla kurumayan inatçı PED ve kistler yüksek doz veya dual blokajla kurur.",
                    "Klinik Hedef: Maksimum görme kazanımı + minimum vizit yükü (durability)."
                ],
                "footer": "Yılda 3-4 Enjeksiyonla Mükemmel Kuruluk"
            }
        ]
    )

    # Slayt 4.1.2.5: Atlas Görseli: Yaş YBMD KNV Tipleri ve Tedavi Yanıtı
    img_p134 = builder.get_image_for_page(134)
    builder.add_atlas_image_slide(
        title="NEOVASKÜLER YBMD KNV TİPLERİ VE TEDAVİ YANITI ATLASI",
        category="BÖLÜM 4.1.2: GÖRSEL ATLAS",
        subtitle="Fibrovasküler PED (Tip 1), Subretinal KNV (Tip 2), İntraretinal Şant (Tip 3) ve Kuruma",
        image_path=img_p134 or "dr_panel_1",
        caption="Referans Eser Sayfa 134: Tip 1 KNV'de Sub-RPE Fibrovasküler PED ve Anti-VEGF Sonrası Anatomik Düzelme",
        key_findings=[
            "Fibrovasküler PED: RPE'nin altında heterojen iç reflektivite içeren çentikli membran elevasyonu [s.134].",
            "Subretinal Sıvı: PED'in tepe noktasında fotoreseptörleri ayıran hiporeflektif sıvı gölü.",
            "SHRM Kütlesi: Subretinal alanda neovasküler endotel ve fibrin yansıması.",
            "Post-Enjeksiyon Kuruma: Tek doz anti-VEGF sonrası subretinal sıvının tamamen çekilmesi ve EZ hattının oturması."
        ],
        differentials=[
            "Seröz PED (Pakikoroid): İç reflektivite tamamen anekoik siyahtır; damar yumağı içermez.",
            "Vitelliform Lezyon: Homojen hiperreflektif birikim; intraretinal kist ve neovaskülarizasyon yoktur.",
            "Santral Seröz Koryoretinopati: Kalın koroid zemininde fokal RPE mikroyırtığı ve berrak seröz sıvı."
        ],
        clinical_pearl="Tip 1 KNV'de amaç alttaki fibrovasküler PED'i tamamen düzleştirmek değil; PED üzerindeki ve içindeki serbest sıvıyı kurutmaktır; PED'i agresif kurutmaya çalışmak RPE yırtığına yol açabilir [s.135]."
    )

    # Slayt 4.1.2.6: RPE Yırtığı (RPE Tear) Riski ve Yönetimi
    builder.add_study_card_slide(
        title="RPE YIRTILMASI (RPE TEAR) MEKANİZMASI VE YÖNETİMİ",
        category="BÖLÜM 4.1.2: YAŞ YBMD",
        subtitle="Dev Seröz/Vaskülarize PED, Anti-VEGF Sonrası Kontraksiyon ve Prognostik Risk",
        cards=[
            {
                "card_title": "YIRTILMA MEKANİZMASI",
                "lead": "Neovasküler Zarın Büzüşmesi ve Mekanik Gerilim",
                "items": [
                    "Zemin Patolojisi: Yüksekliği >400-500 μm olan dev vaskülarize veya seröz PED varlığı [s.135].",
                    "Anti-VEGF Etkisi: Enjeksiyon sonrası KNV damar yumağındaki endotel aniden büzüşür (fibrovasküler retraksiyon).",
                    "Mekanik Yırtılma: Büzüşen neovasküler zar, altından gerilmiş olan zayıf RPE tabakasını kenarından yırtar.",
                    "Rulo Olma: Yırtılan RPE bir tarafa doğru rulo gibi kıvrılırken, diğer taraf çıplak Bruch membranı olarak açığa çıkar."
                ],
                "footer": "Yüksek PED (>400 μm) + Anti-VEGF Büzüşmesi"
            },
            {
                "card_title": "KLİNİK VE GÖRÜNTÜLEME BULGULARI",
                "lead": "Çıplak Bruch vs Katlanmış Hiperreflektif RPE",
                "items": [
                    "Ani Görme Kaybı: Yırtık foveayı içeriyorsa hasta enjeksiyondan birkaç gün sonra ani görme düşüşü tarifler [s.135].",
                    "Fundus Manzarası: Bir yarıda çıplak koroid damarlarının parladığı sınır; diğer yarıda koyu pigmente RPE rulosu.",
                    "FAF İmzası: Yırtılan çıplak alanda zifiri hipo-FAF; katlanan RPE rulosunda aşırı parlak hiper-FAF.",
                    "OKT Kesiti: RPE bandında tam kat kesinti ve rulo yapmış hiperreflektif kalınlaşma."
                ],
                "footer": "Çıplak Alan (Hipo-FAF) & RPE Rulosu"
            },
            {
                "card_title": "TEDAVİ STRATEJİSİ VE KARAR",
                "lead": "Anti-VEGF Kesilmeli mi?",
                "items": [
                    "HAYIR, KESİLMEZ: RPE yırtıldıktan sonra açıkta kalan KNV damarları hızla büyüyüp masif kanama yapabilir [s.136].",
                    "Tedaviye Devam: Sıvı ve eksüdasyon kontrolü için anti-VEGF enjeksiyonları kararlılıkla sürdürülür.",
                    "Görsel Prognoz: Yırtık fovea dışındaysa foveal koniler canlı kalabilir; foveayı yırtan vakalarda prognoz zayıftır.",
                    "Önleme Kuralı: >400 μm PED varlığında hastaya enjeksiyon öncesi RPE yırtılma riski mutlaka anlatılmalıdır."
                ],
                "footer": "RPE Yırtılsa Bile Anti-VEGF Kesilmez!"
            }
        ]
    )

    # Slayt 4.1.2.7: Akış Şeması: Yaş YBMD Treat-and-Extend Protokolü
    builder.add_horizontal_flowchart_slide(
        title="NEOVASKÜLER YBMD TREAT-AND-EXTEND (T&E) UYGULAMA ALGORİTMASI",
        category="BÖLÜM 4.1.2: AKIŞ ŞEMASI",
        subtitle="Yükleme Dozundan Uzatma ve Nüks Yönetimine Adım Adım Klinik Protokol",
        steps=[
            {
                "num": "1",
                "title": "Yükleme Fazı (3 Doz)",
                "desc": "Aylık 3 doz anti-VEGF enjeksiyonu uygulanması (Faricimab/Aflibercept/Ranibizumab) [s.135].",
                "status": "danger"
            },
            {
                "num": "2",
                "title": "Aktivite Değerlendirmesi",
                "desc": "3. dozdan 4 hafta sonra OKT kontrolü: Foveada IRC, SRF veya taze kanama var mı?",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Fovea Kuruysa: Uzat",
                "desc": "Sıvı tamamen çekilmişse enjeksiyon yapılır ve bir sonraki randevu 2 hafta uzatılır (4 -> 6 -> 8 -> 10 -> 12 hf).",
                "status": "success"
            },
            {
                "num": "4",
                "title": "Sıvı Varsa: Sabitle / Kısalt",
                "desc": "İnatçı sıvı sürüyorsa 4 haftada kalınır; uzatma fazında sıvı nüks ederse aralık 2 hafta kısaltılır.",
                "status": "warning"
            },
            {
                "num": "5",
                "title": "Maksimum Aralıkta İdame",
                "desc": "12-16 haftalık aralıkta sıvısız kalan hasta bu aralıkta sürekli enjeksiyonla korunur.",
                "status": "success"
            }
        ],
        bottom_takeaway="İntraretinal kist (IRC) belirdiği anda uzatma derhal durdurulur ve aralık kısaltılır; küçük bir subretinal sıvı (SRF) cebi ise görme stabilse tolere edilebilir [s.135]."
    )

    # Slayt 4.1.2.8: Landmark Çalışmalar: Yaş YBMD Faz 3 Karşılaştırma Matrisi
    builder.add_trials_kpi_slide(
        title="YAŞ YBMD LANDMARK KLİNİK ÇALIŞMALARI MATRİSİ",
        category="BÖLÜM 4.1.2: KANIT TABANI",
        subtitle="CATT, VIEW 1/2, TENAYA/LUCERNE ve PULSAR Çalışmalarının Karşılaştırılması",
        kpis=[
            {"val": "%63", "label": "TENAYA/LUCERNE 16 Haftalık Aralık Oranı"},
            {"val": "%78", "label": "PULSAR Aflibercept 8mg 16 Haftalık Aralık"},
            {"val": "+8 - 10 Harf", "label": "Anti-VEGF ile 1. Yılda Ortalama Görme Artışı"},
            {"val": "2 Yıl", "label": "CATT PRN Rejiminde Harf Kaybı Başlangıcı"}
        ],
        trials_table=[
            {
                "trial": "CATT Çalışması (NEJM 2011/2012)",
                "design": "1208 hasta; Ranibizumab vs Bevacizumab; Aylık vs PRN rejimi.",
                "result": "İki ilaç eşdeğer etkinlik gösterdi; ancak aylık rejim PRN'ye göre sıvıyı daha iyi kuruttu ve görmeyi daha stabil korudu."
            },
            {
                "trial": "VIEW 1 ve VIEW 2 (Ophthalmology 2012)",
                "design": "2419 hasta; Aflibercept 2 mg (2 ayda bir) vs Ranibizumab 0.5 mg (aylık).",
                "result": "3 yükleme sonrası 2 ayda bir Aflibercept, aylık Ranibizumab ile tam eşdeğer görme kazanımı sağladı; enjeksiyon sayısı azaldı."
            },
            {
                "trial": "TENAYA / LUCERNE (Lancet 2022)",
                "design": "1329 hasta; Faricimab 6 mg (16 haftaya kadar T&E) vs Aflibercept 2 mg (8 haftada bir).",
                "result": "Hastaların %63'ü 16 haftalık (4 ayda bir) aralığa ulaştı; görme kazanımı eşdeğer, kuruma hızı sayısal olarak daha üstün."
            },
            {
                "trial": "PULSAR Çalışması (Lancet 2024)",
                "design": "1009 hasta; Yüksek Doz Aflibercept 8 mg (12-16 hafta) vs Aflibercept 2 mg (8 hafta).",
                "result": "Aflibercept 8 mg alan hastaların %78'i 16 haftalık aralıkta görmeyi korudu; inflamasyon ve güvenlik profili standart dozla farksız."
            }
        ],
        bottom_evidence="Seviye 1A Kanıt: Yeni nesil dual ajanlar (Faricimab) ve yüksek doz füzyon proteinleri (Aflibercept 8mg) hastaların çoğunda görme kaybı olmaksızın 4 aylık enjeksiyon aralığı sağlamaktadır [s.137]."
    )

    print(f" -> Bölüm 4 (Kuru ve Yaş YBMD) Kısım 1 Tamamlandı.")

    # =========================================================================
    # KONU 4.2.1: SANTRAL SERÖZ KORYORETİNOPATİ (SSKR) (7 SLAYT)
    # =========================================================================
    # Slayt 4.2.1.1: SSKR Patofizyolojisi ve Risk Faktörleri
    builder.add_study_card_slide(
        title="SANTRAL SERÖZ KORYORETİNOPATİ (SSKR) PATOFİZYOLOJİSİ",
        category="BÖLÜM 4.2.1: PAKİKORİD & SSKR",
        subtitle="Koroideal Venöz Aşırı Yük, Endojen/Ekzojen Steroidler ve RPE Mikroyırtığı",
        cards=[
            {
                "card_title": "KOROİDAL HİPERPERMEABİLİTE",
                "lead": "Pakikoroid Zemininde Hidrostatik Basınç",
                "items": [
                    "Çekirdek Mekanizma: Koroid venöz drenaj tıkanıklığı ve Haller tabakasında devasa göllenme (pakivessel) [s.137].",
                    "Koryokapillaris İskemisi: Aşırı gerilen koryokapillaris endoteli hiperpermeabl hale gelir; sıvı sızdırır.",
                    "Sub-RPE Hidrostatik Basınç: RPE tabakasının altına doğru devasa bir sıvı basıncı biner.",
                    "Dış B-RB Yıkımı: Basınca dayanamayan RPE zonula occludens bağlantıları fokal olarak patlar (mikroyırtık)."
                ],
                "footer": "Koroid Hiperpermeabilitesi -> RPE Yırtığı"
            },
            {
                "card_title": "STEROİD VE TİP A KİŞİLİK",
                "lead": "En Tehlikeli Tetikleyici: Kortikosteroid",
                "items": [
                    "Kortikosteroid Etkisi: Sistemik, topikal, inhaler veya intraartiküler her türlü steroid SSKR'yi tetikler [s.137].",
                    "Mekanizma: Mineralokortikoid reseptörlerini (MR) aktive ederek koroid damar geçirgenliğini katlar.",
                    "Tip A Kişilik: Aşırı stresli, rekabetçi, yüksek sempatik tonuslu bireylerde endojen kortizol zirvededir.",
                    "Diğer Faktörler: Uyku apnesi, Cushing sendromu, fosfodiesteraz-5 inhibitörleri (sildenafil vb.)."
                ],
                "footer": "Kortikosteroid SSKR'nin 1 Numaralı Düşmanıdır!"
            },
            {
                "card_title": "DEMOGRAFİK PROFİL VE BAŞVURU",
                "lead": "Genç-Orta Yaşlı Erkek Hastalar",
                "items": [
                    "Cinsiyet & Yaş: 30 - 55 yaş arası erkeklerde kadınlara göre 6 kat daha sık görülür [s.138].",
                    "Tipik Semptomlar: Ani başlayan parasantral bulanıklık, mikropsia (cisimleri küçük görme), metamorfopsi.",
                    "Hipermetropik Kayma: Subretinal sıvı foveayı öne doğru ittiği için kırma kusuru +1.00 ila +2.00 D hipermetropa kayar.",
                    "Karanlık Adaptasyon Güçlüğü: Foveal fotoreseptörlerin RPE'den ayrılmasına bağlı renk ve kontrast solukluğu."
                ],
                "footer": "30-50 Yaş Erkek / Mikropsia / Hipermetropi"
            }
        ]
    )

    # Slayt 4.2.1.2: Akut vs Kronik SSKR Ayrımı
    builder.add_split_comparison_slide(
        title="SSKR'DE EVRELEME: AKUT VS KRONİK SSKR AYRIMI",
        category="BÖLÜM 4.2.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Spontan Rezolüsyon (Akut) vs Diffüz Retina Pigment Epitelyopatisi (Kronik)",
        left_entity={
            "name": "AKUT SSKR (KENDİNİ SINIRLAYAN)",
            "features": [
                ("Süre Eşiği", "Sıvı süresi <3 - 4 aydır [s.138]."),
                ("Fundus Görünümü", "Fovea merkezinde berrak, kubbemsi, sınırları yuvarlak seröz dekolman."),
                ("RPE Değişiklikleri", "RPE zemininde kalıcı atrofi yoktur; tekil fokal mikroyırtık bulunur."),
                ("Doğal Seyir", "Olguların %80-90'ında 3-4 ay içinde hiçbir tedavi gerektirmeden SPONTAN YATIŞIR."),
                ("Yönetim", "Gözlem + Steroidlerin derhal kesilmesi + Stres kontrolü.")
            ]
        },
        right_entity={
            "name": "KRONİK SSKR (DIFFUSE RETINAL PIGMENT EPITHELIOPATHY)",
            "features": [
                ("Süre Eşiği", "Subretinal sıvı >4 - 6 aydan uzun süre persistan olarak kalır [s.138]."),
                ("Fundus Görünümü", "Yaygın RPE atrofisi, pigment kümelenmeleri ve yerçekimi izleri (guttering / damla izi)."),
                ("Fotoreseptör Hasarı", "Uzayan sıvı foveal konilerin EZ bandını eritir; görme 20/200'e kadar düşer."),
                ("Doğal Seyir", "Spontan düzelme şansı çok düşüktür; kalıcı fotoreseptör atrofisi ve kistik dejenerasyon."),
                ("Yönetim", "Yarım Doz / Yarım Akı Fotodinamik Tedavi (PDT) veya Mineralokortikoid blokajı.")
            ]
        },
        bottom_takeaway="Akut SSKR'de ilk 3 ay aktif bekleme altın kuraldır; ancak sıvı 3 ayı aştığında fotoreseptör hasarı kalıcı hale gelmeden Fotodinamik Tedavi (PDT) planlanmalıdır [s.139]."
    )

    # Slayt 4.2.1.3: FA Sızıntı Paternleri: Mürekkep Lekesi vs Tüten Baca
    builder.add_study_card_slide(
        title="SSKR'DE FLORESEİN ANJİYOGRAFİSİ SIZINTI PATERNLERİ",
        category="BÖLÜM 4.2.1: PAKİKORİD & SSKR",
        subtitle="Mürekkep Lekesi (Ink-Blot), Tüten Baca (Smokestack) ve Diffüz Sızıntı",
        cards=[
            {
                "card_title": "MÜREKKEP LEKESİ (INK-BLOT) — %85",
                "lead": "Konsantrik Genişleyen Fokal Kaçak",
                "items": [
                    "En Sık Patern: SSKR olgularının yaklaşık %80-85'inde görülür [s.139].",
                    "Erken Faz: RPE mikroyırtığı düzeyinde tek bir parlak hiperflöresan nokta belirir.",
                    "Geç Faz: Nokta kurutma kağıdına damlayan mürekkep gibi her yöne doğru konsantrik genişler.",
                    "Göllenme: Seröz retina dekolmanı boşluğunu homojen olarak doldurur.",
                    "Sınırlar: Anatomik seröz dekolman sınırında durur; sınır dışına taşmaz."
                ],
                "footer": "%85 En Sık: Konsantrik Genişleyen Nokta"
            },
            {
                "card_title": "TÜTEN BACA (SMOKESTACK) — %10-15",
                "lead": "Konveksiyonel Yukarı Tırmanan Sızıntı",
                "items": [
                    "Klasik İkonik Patern: Olguların %10-15'inde görülen son derece patognomonik tablodur [s.139].",
                    "Erken Faz: RPE defektinden ince bir floresein sütunu halinde dikey olarak yukarı doğru yükselir.",
                    "Mantar Bulutu: Subretinal boşluğun üst sınırına ulaştığında sağa ve sola yayılarak mantar/şemsiye şekli alır.",
                    "Fiziksel Prensip: Boyalı sıvının seröz sıvı içindeki protein konsantrasyonu ve yoğunluk farkı (termal konveksiyon).",
                    "Klinik Önemi: Görüldüğünde tartışmasız SSKR tanısı koydurur."
                ],
                "footer": "Yukarı Tırmanan Mantar / Şemsiye Sızıntısı"
            },
            {
                "card_title": "DİFFÜZ / İZOLASYONSUZ KAÇAK",
                "lead": "Kronik SSKR ve Yerçekimi İzi (Guttering)",
                "items": [
                    "Kronik Patern: Tek bir nokta yoktur; RPE atrofisi boyunca çok sayıda silik mikrokaçak bulunur [s.140].",
                    "Yerçekimi Yolu (Descending Track): Sıvı makuladan aşağıya doğru akarak alt periferde atrofik bir iz bırakır.",
                    "Geniş Açı Önemi: Yerçekimi izini yakalamak için mutlaka alt perifer fundus taranmalıdır.",
                    "ICGA Üstünlüğü: ICGA koroideal hiperpermeabilite plaklarını FA'dan çok daha geniş gösterir."
                ],
                "footer": "Çok Odaklı Sızıntı & İnen Yerçekimi İzi"
            }
        ]
    )

    # Slayt 4.2.1.4: Fotodinamik Tedavi (PDT) Protokolü
    builder.add_study_card_slide(
        title="SSKR'DE FOTODİNAMİK TEDAVİ (PDT) VE MİNİMAL PROTOKOLLER",
        category="BÖLÜM 4.2.1: PAKİKORİD & SSKR",
        subtitle="Verteporfin (Visudyne), Yarım Doz vs Yarım Akı PDT ve Koryokapillaris Remodelingi",
        cards=[
            {
                "card_title": "VERTEPORFİN ETKİ MEKANİZMASI",
                "lead": "Koryokapillaris Hipoperfüzyonu ve Remodeling",
                "items": [
                    "Verteporfin (Visudyne): Düşük yoğunluklu lipoproteinlere (LDL) bağlanan fotosensitizer boyadır [s.140].",
                    "Lazer Aktivasyonu: 689 nm nonthermal kırmızı lazer ışığıyla aktive edilir.",
                    "Reaktif Oksijen Radikalleri: Endotel hasarı ve lokal trombüsle koroid damarlarını geçici tıkar.",
                    "Koryokapillaris Dekonjesyonu: Genişlemiş Haller damarlarını büzüştürür; koroid kalınlığını ve basıncını hızla düşürür."
                ],
                "footer": "689 nm Lazer + Verteporfin = Koroid Büzüşmesi"
            },
            {
                "card_title": "GÜVENLİ PROTOKOL: YARIM DOZ / YARIM AKI",
                "lead": "RPE Atrofisini Önleyen Güvenlik Standardı",
                "items": [
                    "Klasik Standart Doz Riski: Standart PDT koroid iskemisi ve kalıcı RPE atrofisi yapabilir [s.140].",
                    "Yarım Doz PDT (Half-Dose): Verteporfin dozu 6 mg/m² yerine 3 mg/m² verilir (en sık tercih).",
                    "Yarım Akı PDT (Half-Fluence): Enerji akısı 50 J/cm² yerine 25 J/cm²'ye düşürülür (ışınlama süresi 42 sn).",
                    "Mükemmel Başarı: Yarım doz/akı PDT ile olguların >%90'ında foveal sıvı 4-6 haftada kalıcı kurur."
                ],
                "footer": "Yarım Doz (3 mg/m²) VEYA Yarım Akı (25 J/cm²)"
            },
            {
                "card_title": "MEDİKAL TEDAVİ: MİNERALOKORTİKOİD BLOKAJI",
                "lead": "Eplerenon ve Spironolakton",
                "items": [
                    "İlaç Sınıfı: Oral mineralokortikoid reseptör antagonistleri (Eplerenon 50 mg/gün veya Spironolakton 50 mg/gün) [s.141].",
                    "Etki Yolu: Koroid endotelindeki mineralokortikoid reseptörlerini bloke ederek damar dilatasyonunu engeller.",
                    "VICI Çalışması Şoku: Faz 3 VICI çalışmasında eplerenon plaseboya üstünlük gösterememiştir.",
                    "Güncel Konsensus: PDT'ye ulaşılamayan durumlarda denenebilir; ancak birinci basamak kanıtlanmış tedavi YARIM DOZ PDT'dir."
                ],
                "footer": "PDT 1 Numaradır; Eplerenon Kanıtı Zayıftır"
            }
        ]
    )

    # Slayt 4.2.1.5: Atlas Görseli: Akut ve Kronik SSKR Multimodal Atlası
    img_p138 = builder.get_image_for_page(138)
    builder.add_atlas_image_slide(
        title="SANTRAL SERÖZ KORYORETİNOPATİ (SSKR) MULTİMODAL ATLASI",
        category="BÖLÜM 4.2.1: GÖRSEL ATLAS",
        subtitle="EDI-OKT'de Kalın Koroid, Foveal Seröz Dekolman ve FA'da Tüten Baca Sızıntısı",
        image_path=img_p138 or "dr_schema_0",
        caption="Referans Eser Sayfa 138: Akut SSKR'de 580 μm Koroid Zemininde Subretinal Sıvı ve FA Tüten Baca Paternı",
        key_findings=[
            "Subfoveal Nörosensoryal Dekolman: Fovea altında kubbe şeklinde yükselmiş optik olarak berrak seröz sıvı [s.138].",
            "Aşırı Koroid Kalınlığı (580 μm): EDI-OKT kesitinde Haller tabakasında dev pakivessel lümenleri.",
            "Tüten Baca Sızıntısı: FA orta fazında fokal RPE defektinden yukarı tırmanan beyaz duman sütunu.",
            "ICGA Hiperpermeabilitesi: Orta fazda arka kutupta diffüz parlak koroideal hiperpermeabilite göllenmesi."
        ],
        differentials=[
            "Tip 1 Neovasküler YBMD: Drusen zeminindedir, koroid incedir; KNV ağı içerir.",
            "Vogt-Koyanagi-Harada: Bilateraldir, ön kamara reaksiyonu ve disk ödemi eşlik eder.",
            "Optik Pit Makulopatisi: Optik disk kenarında konjenital çukurluk ve şizis benzeri dekolman."
        ],
        clinical_pearl="SSKR hastasına yanlışlıkla 'ödemi geçirsin' diye kortikosteroid damla, hap veya enjeksiyon verilmesi yangına körükle gitmektir; büllöz retina dekolmanı ve kalıcı körlük yaratabilir [s.137]."
    )

    # Slayt 4.2.1.6: Karşılaştırmalı Analiz: Akut SSKR vs Yaş YBMD Ayrımı
    builder.add_split_comparison_slide(
        title="KRİTİK AYIRICI TANI: AKUT SSKR VS NEOVASKÜLER (YAŞ) YBMD",
        category="BÖLÜM 4.2.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Yanlışlıkla Anti-VEGF veya Yanlışlıkla Steroid Verilmesini Önleyen Kriterler",
        left_entity={
            "name": "SANTRAL SERÖZ KORYORETİNOPATİ (SSKR)",
            "features": [
                ("Yaş ve Cinsiyet", "30 - 50 yaş arası genç-orta yaş erkek hastalar [s.138]."),
                ("Drusen Durumu", "Retinada sert veya yumuşak drusen KESİNLİKLE YOKTUR."),
                ("Koroid Kalınlığı (SFCT)", "AŞIRI KALINDIR (>400 - 550 μm); dev pakivessel damarları izlenir."),
                ("FA Sızıntı Tipi", "Mürekkep lekesi veya tüten baca tarzında fokal mikrokaçak."),
                ("Steroid Yanıtı", "Kortikosteroid ile tablo FELAKET DÜZEYİNDE ALEVLENİR."),
                ("Birincil Tedavi", "Gözlem (ilk 3 ay) -> İnatçıysa Yarım Doz PDT.")
            ]
        },
        right_entity={
            "name": "NEOVASKÜLER (YAŞ) YBMD",
            "features": [
                ("Yaş ve Cinsiyet", ">65 yaş ileri yaşlı bireyler; kadınlarda bir miktar daha sık [s.133]."),
                ("Drusen Durumu", "Karşı gözde ve fovea çevresinde yumuşak confluent drusenler mevcuttur."),
                ("Koroid Kalınlığı (SFCT)", "NORMAL VEYA İNCEDİR (<200 - 250 μm)."),
                ("FA Sızıntı Tipi", "Tip 1 veya Tip 2 KNV'ye bağlı diffüz dantela tarzı vasküler sızıntı."),
                ("Steroid Yanıtı", "Steroid veya anti-VEGF ile ödem geriler (alevlenmez)."),
                ("Birincil Tedavi", "Aylık İntravitreal Anti-VEGF (Faricimab/Aflibercept).")
            ]
        },
        bottom_takeaway="50 yaşındaki bir hastada subretinal sıvı görüldüğünde ilk bakılacak yer koroid kalınlığı ve drusen varlığıdır; kalın koroid ve drusensiz retina SSKR'dir, yaşlı ve drusenli retina YBMD'dir [s.138]."
    )

    # Slayt 4.2.1.7: Akış Şeması: SSKR Klinik Yönetim ve PDT Zamanlaması
    builder.add_horizontal_flowchart_slide(
        title="SANTRAL SERÖZ KORYORETİNOPATİ (SSKR) TEDAVİ AKIŞ ŞEMASI",
        category="BÖLÜM 4.2.1: AKIŞ ŞEMASI",
        subtitle="Tanı Anından Aktif Beklemeye, PDT Endikasyonuna ve Takip Basamaklarına",
        steps=[
            {
                "num": "1",
                "title": "İlk Tanı & Steroid Kesimi",
                "desc": "EDI-OKT ve fundus muayenesiyle tanı konur; hastanın kullandığı TÜM STEROİDLER derhal kesilir [s.137].",
                "status": "danger"
            },
            {
                "num": "2",
                "title": "3 Ay Aktif Gözlem",
                "desc": "İlk 3 ay boyunca hiçbir invaziv müdahale yapılmaz; hastaların %85'i kendiliğinden düzelir.",
                "status": "info"
            },
            {
                "num": "3",
                "title": "3. Ay Kontrolü",
                "desc": "Sıvı tamamen çekildiyse rutin takip; subretinal sıvı aynen sürüyorsa 'Kronik SSKR' kabul edilir.",
                "status": "warning"
            },
            {
                "num": "4",
                "title": "Yarım Doz PDT Planı",
                "desc": "FA ve ICGA ile sızıntı ve koroideal hiperpermeabilite odağı işaretlenir; 689 nm yarım doz PDT uygulanır.",
                "status": "success"
            },
            {
                "num": "5",
                "title": "Rezolüsyon Teyidi",
                "desc": "PDT sonrası 4-6. haftada EDI-OKT ile koroid kalınlığının azaldığı ve sıvının kuruduğu teyit edilir.",
                "status": "success"
            }
        ],
        bottom_takeaway="Tek istisna mesleki gereksinimdir; pilot, cerrah veya şoför gibi meslek icra edenlerde 3 ay beklenmeden erken dönemde yarım doz PDT uygulanabilir [s.140]."
    )

    # =========================================================================
    # KONU 4.2.2: PAKİKORİD SPEKTRUMU VE PKNV (6 SLAYT)
    # =========================================================================
    # Slayt 4.2.2.1: Pakikoroid Spektrum Hastalıkları Tanımı
    builder.add_study_card_slide(
        title="PAKİKORİD SPEKTRUMU HASTALIKLARI ŞEMSİYESİ",
        category="BÖLÜM 4.2.2: PAKİKORİD SPEKTRUMU",
        subtitle="PPE'den SSKR'ye, Pakikoroid Neovaskülarizasyondan (PKNV) PCV'ye Evrim",
        cards=[
            {
                "card_title": "PAKİKORİD FENOTİPİ VE ÖZELLİKLERİ",
                "lead": "Ortak Patogenetik Zemin",
                "items": [
                    "Spektrum Hipotezi: Birbirinden bağımsız sanılan hastalıkların aynı patofizyolojik kökten doğmasıdır [s.140].",
                    "Ortak Özellik 1: Artmış subfoveal koroid kalınlığı (SFCT genellikle >350-400 μm).",
                    "Ortak Özellik 2: Haller tabakasında dilate venöz gövdeler (pakivessel).",
                    "Ortak Özellik 3: Pakivessel üzerinde koryokapillaris tabakasının ezilerek incelmesi (flow void).",
                    "Ortak Özellik 4: Drusen yokluğu veya yalnızca sert drusen benzeri kütiküler birikimler."
                ],
                "footer": "SFCT >350 μm + Pakivessel + Koryokapillaris İncelmesi"
            },
            {
                "card_title": "4 BASAMAKLI KLİNİK SPEKTRUM",
                "lead": "PPE -> SSKR -> PKNV -> PCV",
                "items": [
                    "1. Pakikoroid Pigment Epitelyopatisi (PPE): Sıvısız evre; kalın koroid üzerinde fokal RPE düzensizlikleri [s.141].",
                    "2. Santral Seröz Koryoretinopati (SSKR): RPE mikroyırtığı ve subretinal seröz sıvı birikimi.",
                    "3. Pakikoroid Neovaskülarizasyon (PKNV): RPE altında Tip 1 KNV damar yumağının filizlenmesi.",
                    "4. Polipoidal Koroideal Vaskülopati (PCV): Neovasküler damar uçlarında nodüler anevrizmal polip oluşumu."
                ],
                "footer": "Progresif 4 Basamaklı Spektrum"
            },
            {
                "card_title": "VASKÜLER ASİMETRİ VE VORTEKS BASINCI",
                "lead": "Vorteks Venöz Anastomozları",
                "items": [
                    "Etyolojik Kök: Vorteks venlerinin skleradan çıkış tünellerinde daralma veya konjesyon [s.141].",
                    "Drenaj Bölünmesi: Üst ve alt vorteks venleri arasında venöz watershed zonu üzerinden şant damarları açılır.",
                    "Geniş Açılı ICG (UWF-ICG): Makulayı boydan boya kat eden dev anastomotik venöz kollateralleri kanıtlar.",
                    "Klinik Çıkarım: Hastalık lokal bir retina sorunu değil; tüm koroidin venöz drenaj yetmezliğidir."
                ],
                "footer": "Vorteks Ven Konjesyonu -> Şant Damarları"
            }
        ]
    )

    # Slayt 4.2.2.2: Pakikoroid Pigment Epitelyopatisi (PPE)
    builder.add_study_card_slide(
        title="PAKİKORİD PİGMENT EPİTELYOPATİSİ (PPE) KRİTERLERİ",
        category="BÖLÜM 4.2.2: PAKİKORİD SPEKTRUMU",
        subtitle="Spektrumun Sessiz Öncüsü: Kalın Koroid Üzerinde RPE Değişiklikleri ve Sıvısız Faz",
        cards=[
            {
                "card_title": "PPE ANATOMİK TANIMI",
                "lead": "Sıvı Olmayan Pakikoroid İmzası",
                "items": [
                    "Tanım: Subretinal sıvı olmaksızın, kalın koroid (pakivessel) üzerinde fokal RPE anomalileridir [s.141].",
                    "Göz Dibi Muayenesi: Makulada hafif pigment alacalanması veya küçük drusenoid benekler izlenir.",
                    "Sub-RPE Mikro-Kistler: OKT'de RPE tabakasında fokal düzensizlikler ve küçük sığ elevasyonlar.",
                    "Karşı Göz İmzası: Tek taraflı SSKR hastalarının 'sağlıklı' sanılan diğer gözünde %60-70 oranında PPE bulunur."
                ],
                "footer": "Sıvısız Evre / Tek Taraflı SSKR Karşı Gözü"
            },
            {
                "card_title": "FAF VE OKTA ÖZELLİKLERİ",
                "lead": "Fokal Hiper/Hipo-FAF Mozaikleri",
                "items": [
                    "FAF Görüntüsü: RPE stresine bağlı küçük hiper-otoflöresan noktalar ve fokal atrofik hipo-FAF benekleri [s.142].",
                    "OKTA Koryokapillaris: Pakivessel damarının tam üzerindeki koryokapillariste akım boşlukları (flow voids).",
                    "KNV Yokluğu: Avasküler dış retinada neovaskülarizasyon veya damar filizlenmesi saptanmaz.",
                    "Stabilite: Olguların büyük kısmı ömür boyu PPE evresinde semptomsuz ve stabil kalabilir."
                ],
                "footer": "Akım Boşluğu (Flow Void) + FAF Düzensizliği"
            },
            {
                "card_title": "KLİNİK YÖNETİM VE UYARI",
                "lead": "Tedavi Gerekmez / Steroid Yasağı",
                "items": [
                    "Aktif Tedavi Gerekmez: Görme 10/10'dur ve sıvı yoktur; lazer veya enjeksiyon uygulanmaz [s.142].",
                    "HAYATİ UYARI: PPE saptanan bireylere gelecekte sistemik veya lokal KORTİKOSTEROİD verilmemelidir.",
                    "Alevlenme Riski: Steroid maruziyeti latent PPE'yi günler içinde büllöz akut SSKR'ye patlatabilir.",
                    "Amsler Takibi: Hastaya metamorfopsi gelişirse derhal başvurması tembihlenir."
                ],
                "footer": "Tedavi Yok / Steroidden Mutlak Kaçınma"
            }
        ]
    )

    # Slayt 4.2.2.3: Pakikoroid Neovaskülarizasyon (PKNV)
    builder.add_study_card_slide(
        title="PAKİKORİD NEOVASKÜLARİZASYON (PKNV) ANATOMİSİ",
        category="BÖLÜM 4.2.2: PAKİKORİD SPEKTRUMU",
        subtitle="Drusensiz Kalın Koroid Zemininde Tip 1 KNV Gelişimi ve YBMD'den Ayrımı",
        cards=[
            {
                "card_title": "PKNV NEDİR?",
                "lead": "Pakikoroid Zemininde Tip 1 Neovaskülarizasyon",
                "items": [
                    "Tanım: Kalın koroid ve pakivessel üzerindeki kronik koryokapillaris iskemisinden filizlenen Tip 1 KNV'dir [s.142].",
                    "Drusen Yoktur: YBMD'nin aksine foveada yumuşak drusen veya psödodrusen bulunmaz.",
                    "Sığ Düzensiz PED (SIRE): OKT'de RPE ile Bruch zarı arasında basık, yayvan, düzensiz fibrovasküler bant.",
                    "Çift Yansıma (Double-Layer Sign): RPE ile Bruch arasındaki neovasküler zarı temsil eden iki paralel çizgi."
                ],
                "footer": "Drusensiz Zemin + Sığ Düzensiz PED (SIRE)"
            },
            {
                "card_title": "OKTA İLE TEŞHİS",
                "lead": "Koryokapillaris Düzleminde Vasküler Yumak",
                "items": [
                    "Koryokapillaris Segmentasyonu: Bruch membranının hemen altındaki dilimde organize damar ağı netleşir [s.143].",
                    "Dallanmış Ağ (Tangled Network): Geniş ana damarlardan çıkan düşük akımlı saçaklı kapillerler.",
                    "FA Yanıltıcılığı: FA'da belirgin sızıntı vermez; kronik SSKR ile kolayca karıştırılır.",
                    "OKTA Üstünlüğü: Kronik SSKR sanılan hastaların %30'unda OKTA çekildiğinde altta sessiz PKNV saptanır."
                ],
                "footer": "Kronik SSKR Sanılan Olgularda OKTA Şart"
            },
            {
                "card_title": "TEDAVİ YAKLAŞIMI",
                "lead": "Anti-VEGF ve Kombine Yarım Doz PDT",
                "items": [
                    "Anti-VEGF Yanıtı: İntravitreal anti-VEGF (Aflibercept/Faricimab) subretinal sıvıyı hızla kurutur [s.143].",
                    "Dirençli Sıvı: Tek başına anti-VEGF alttaki kalın koroid basıncını düşüremediği için sıvı nüksü sıktır.",
                    "Kombine PDT Üstünlüğü: Anti-VEGF + Yarım Doz PDT kombinasyonu hem damarı söndürür hem koroidi inceltir.",
                    "Hedef: Neovasküler zarın polipoidal aşamaya (PCV) ilerlemesinin önlenmesidir."
                ],
                "footer": "Anti-VEGF + Yarım Doz PDT Kombinasyonu"
            }
        ]
    )

    # Slayt 4.2.2.4: Atlas Görseli: PPE, SSKR ve PKNV Karşılaştırma Atlası
    img_p141 = builder.get_image_for_page(141)
    builder.add_atlas_image_slide(
        title="PAKİKORİD SPEKTRUMU EVRİMİ ATLASI",
        category="BÖLÜM 4.2.2: GÖRSEL ATLAS",
        subtitle="PPE'de RPE Pürüzü, SSKR'de Seröz Dekolman ve PKNV'de Sığ Düzensiz PED",
        image_path=img_p141 or "dr_schema_0",
        caption="Referans Eser Sayfa 141: Pakikoroid Spektrumunda Kalın Koroid Zemininde PPE'den PKNV'ye Progresyon",
        key_findings=[
            "Pakivessel İskeleti: Her üç evrede de koroid tabanında dev hiporeflektif venöz lümenler ve >450 μm kalınlık [s.141].",
            "Koryokapillaris Sıkışması: Dev damarların tepe noktasında iç koroid tabakasının tamamen silinmesi.",
            "SIRE Belirtisi: PKNV evresinde RPE tabakasının altında sığ, basık, dalgalı çift hat (double-layer sign).",
            "OKTA Akım İmzası: Double-layer sign içine oturan belirgin parlak sarı neovasküler akım sinyali."
        ],
        differentials=[
            "Kuru YBMD: Drusen vardır ancak koroid incedir; pakivessel içermez.",
            "Klasik Yaş YBMD: RPE'yi delen dik medusa başı Tip 2 KNV vardır; koroid incedir.",
            "Pattern Distrofi: Genetik ve simetrik bilateral RPE pigment mozaikleri; koroid normaldir."
        ],
        clinical_pearl="Kronik SSKR hastasında OKT'de 'Double-Layer Sign' (çift yansıma çizgisi) görülürse, bu durum aksi kanıtlanana dek Pakikoroid Neovaskülarizasyondur (PKNV); acil OKTA ile doğrulanmalıdır [s.143]."
    )

    # Slayt 4.2.2.5: Karşılaştırmalı Analiz: Pakikoroid KNV vs YBMD Tip 1 KNV
    builder.add_split_comparison_slide(
        title="TİP 1 KNV AYRIMI: PAKİKORİD (PKNV) VS STANDART YBMD",
        category="BÖLÜM 4.2.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="İki Farklı Etiyoloji: Koroidal Aşırı Yük (Pakikoroid) vs Bruch/RPE Yaşlanması (YBMD)",
        left_entity={
            "name": "PAKİKORİD NEOVASKÜLARİZASYON (PKNV)",
            "features": [
                ("Yaş Dağılımı", "Daha genç hastalar (45 - 65 yaş arası) [s.143]."),
                ("Drusen Durumu", "Yumuşak drusen veya psödodrusen KESİNLİKLE YOKTUR."),
                ("Koroid Kalınlığı (SFCT)", "AŞIRI KALIN (>350 - 500 μm); Haller venleri dev boyuttadır."),
                ("Koryokapillaris", "Fokal ezilme vardır; genel koryokapillaris korunmuştur."),
                ("Tedavi Yaklaşımı", "Anti-VEGF + Yarım Doz PDT (koroidi inceltmek şarttır).")
            ]
        },
        right_entity={
            "name": "STANDART YAŞ YBMD (TİP 1 KNV)",
            "features": [
                ("Yaş Dağılımı", "İleri yaşlı hastalar (>70 yaş)."),
                ("Drusen Durumu", "Her iki gözde yaygın confluent yumuşak drusenler mevcuttur."),
                ("Koroid Kalınlığı (SFCT)", "NORMAL VEYA İNCELMİŞTİR (<150 - 250 μm)."),
                ("Koryokapillaris", "Yaygın diffüz skleroz ve koryokapillaris atrofisi."),
                ("Tedavi Yaklaşımı", "Uzun süreli Treat-and-Extend Anti-VEGF monoterapisi.")
            ]
        },
        bottom_takeaway="PKNV'de koroid aşırı kalın olduğu için tek başına anti-VEGF ile kurutmak çok zordur; kombine fotodinamik tedavi (PDT) ile koroid basıncını kırmak kalıcı başarı sağlar [s.143]."
    )

    # Slayt 4.2.2.6: Akış Şeması: Pakikoroid Spektrumu Basamaklı Yönetim
    builder.add_horizontal_flowchart_slide(
        title="PAKİKORİD SPEKTRUMU BASAMAKLI YÖNETİM VE TRİYAJ KASKADI",
        category="BÖLÜM 4.2.2: AKIŞ ŞEMASI",
        subtitle="PPE'den Başlayarak SSKR, PKNV ve PCV Evrelerinde Uygun Tedavi Seçimi",
        steps=[
            {
                "num": "1",
                "title": "PPE (Sıvısız Evre)",
                "desc": "Kalın koroid + RPE pürüzü -> Tedavi yok; steroid KESİNLİKLE YASAK; Amsler takibi [s.141].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Akut SSKR",
                "desc": "Subretinal sıvı <3 ay -> İlk 3 ay aktif gözlem; steroid maruziyeti varsa derhal sonlandır.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Kronik SSKR",
                "desc": "Sıvı >3 ay sürdü -> ICGA rehberliğinde Yarım Doz / Yarım Akı Fotodinamik Tedavi (PDT).",
                "status": "success"
            },
            {
                "num": "4",
                "title": "PKNV Gelişimi",
                "desc": "Double-layer sign ve OKTA'da neovasküler ağ saptandı -> İntravitreal Anti-VEGF + Yarım Doz PDT.",
                "status": "danger"
            },
            {
                "num": "5",
                "title": "PCV Dönüşümü",
                "desc": "Nodüler polip anevrizmaları ve masif kanama -> Tam protokol Anti-VEGF + Kombine PDT.",
                "status": "danger"
            }
        ],
        bottom_takeaway="Pakikoroid spektrumunda erken evrede yakalanan olgulara 'kortikosteroid yasağı' verilmesi, hastayı ileride gelişebilecek büllöz SSKR ve neovaskülarizasyondan koruyan en kritik koruyucu hekimlik adımıdır [s.143]."
    )

    # =========================================================================
    # KONU 4.2.3: POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) (7 SLAYT)
    # =========================================================================
    # Slayt 4.2.3.1: PCV Epidemiyolojisi ve Patogenezi
    builder.add_study_card_slide(
        title="POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) BİYOLOJİSİ",
        category="BÖLÜM 4.2.3: POLİPOİDAL VASKÜLOPATİ",
        subtitle="Asya Popülasyonu Sıklığı, Arteriyel Anevrizmalar, BVN ve Masif Kanama Dinamiği",
        cards=[
            {
                "card_title": "DEMOGRAFİK VE ETNİK DAĞILIM",
                "lead": "Asyalılarda %50, Beyazlarda %10-15",
                "items": [
                    "Etnik Yatkınlık: Asya popülasyonunda yaş tip YBMD tanısı alan hastaların yaklaşık %50'si gerçekte PCV'dir [s.143].",
                    "Kafkas Popülasyonu: Beyaz ırkta bu oran yaklaşık %10 - 15 civarındadır (sıklıkla atlanır).",
                    "Yaş Profili: Klasik YBMD'ye göre yaklaşık 5-10 yıl daha genç yaşta (55-65 yaş) ortaya çıkar.",
                    "Cinsiyet: Erkeklerde kadınlara göre bir miktar daha sıktır; pakikoroid fenotipi hakimdir."
                ],
                "footer": "Asyalılarda %50 / 55-65 Yaş Erkekler"
            },
            {
                "card_title": "İKİ TEMEL VASKÜLER BİLEŞEN",
                "lead": "Dallanan Ağ (BVN) ve Polip Nodülleri",
                "items": [
                    "1. Dallanan Vasküler Ağ (BVN): RPE altında yassı uzanan, yavaş akımlı arteriyel neovasküler iskelettir [s.144].",
                    "2. Polipoidal Lezyonlar (Polips): BVN uçlarında yer alan, balonlaşmış saküler anevrizmal dilatasyonlardır.",
                    "Histopatoloji: Gerçekte koroidal değil; RPE altındaki arteriol benzeri damarların endotelyal ektazisidir.",
                    "Düz Kas Kaybı: Damar duvarında perisit ve düz kas tabakası hyalinize olur; damar aşırı kırılganlaşır."
                ],
                "footer": "BVN (Ağ) + Polip (Uç Anevrizmalar)"
            },
            {
                "card_title": "MASİF HEMORAJİK FIRTINA",
                "lead": "Subretinal ve Vitreus Kanaması",
                "items": [
                    "Yüksek Basınçlı Patlama: Anevrizmal polip patladığında masif subretinal veya sub-RPE kanama fışkırır [s.144].",
                    "Çığ Düşmesi: Kan nörosensoryal retinayı yırtarak vitreus boşluğuna geçebilir (spontan vitreus kanaması).",
                    "Klinik İpucu: Yaşlı hastada açıklanamayan ani masif vitreus kanaması aksi kanıtlanana dek PCV patlamasıdır.",
                    "Körlük Riski: Subfoveal kan pıhtısı fotoreseptörleri ezer; acil dekompresyon gerektirir."
                ],
                "footer": "Masif Subretinal & Vitreus Kanaması"
            }
        ]
    )

    # Slayt 4.2.3.2: Non-İnvaziv OKT Tanı Kriterleri
    builder.add_study_card_slide(
        title="PCV'NİN NON-İNVAZİV OKT TANI KRİTERLERİ",
        category="BÖLÜM 4.2.3: POLİPOİDAL VASKÜLOPATİ",
        subtitle="ICGA Yapılamayan Durumlarda Doğruluk Oranı >%85 Olan Tomografik Belirteçler",
        cards=[
            {
                "card_title": "PARMAK BENZERİ DİK PED (THUMB-LIKE)",
                "lead": "Dik Açıyla Yükselen Kubbe",
                "items": [
                    "RPE Yükselmesi: RPE tabakası Bruch zarından neredeyse 90 derece dik açıyla fırlar [s.144].",
                    "Parmak İzi: Kubbe biçimli bu dik elevasyon doğrudan lümen içindeki polip nodülünü örter.",
                    "İç Yansıma: Polip lümeni hiporeflektiftir; polip duvarı ise ince parlak hiperreflektif bir halkadır.",
                    "Yükseklik: Klasik drusenoid PED'e göre çok daha dik ve dardır."
                ],
                "footer": "Thumb-like / Dik Açılı RPE Kubbesi"
            },
            {
                "card_title": "ÇİFT HAT İŞARETİ (DOUBLE-LAYER SIGN)",
                "lead": "BVN'yi Temsil Eden İki Paralel Çizgi",
                "items": [
                    "İki Ayrı Çizgi: RPE hiperreflektif hattı ile alttaki Bruch membranı arasında sığ bir ayrılma izlenir [s.145].",
                    "İçerik: İki çizgi arasındaki hafif hiperreflektif alan dallanan vasküler ağı (BVN) barındırır.",
                    "Geniş Taban: Polip kubbesinin hemen komşuluğunda yayvan bir zemin olarak uzanır.",
                    "OKTA Doğrulaması: Double-layer sign içine akım sinyali düşürüldüğünde BVN damarları aydınlanır."
                ],
                "footer": "Double-Layer Sign = RPE Altı BVN Ağı"
            },
            {
                "card_title": "ÇENTİK BELİRTİSİ VE SUB-RPE HALKA",
                "lead": "Notch Sign ve Sıvı Dağılımı",
                "items": [
                    "Çentik Belirtisi (Notch Sign): İki polip nodülünün birleştiği yerde veya polip-BVN bileşkesinde V-şekilli çentik [s.145].",
                    "Sub-RPE Halka (Ring Sign): PED kubbesinin hemen altında polip damar duvarına uyan dairesel parlak halka.",
                    "Masif Subretinal Sıvı: Lezyonun tepesinde foveayı kaldıran dev seröz sıvı kütlesi.",
                    "Tanısal Güç: Bu üç OKT kriterinin (Thumb PED + Double layer + Notch) birlikteliği ICGA ile %90 uyumludur."
                ],
                "footer": "Thumb PED + Double Layer + Notch = PCV"
            }
        ]
    )

    # Slayt 4.2.3.3: EVEREST II ve PLANET Çalışmaları Karşılaştırması
    builder.add_trials_kpi_slide(
        title="PCV TEDAVİSİNDE LANDMARK ÇALIŞMALAR: EVEREST II VS PLANET",
        category="BÖLÜM 4.2.3: POLİPOİDAL VASKÜLOPATİ",
        subtitle="Kombine Fotodinamik Tedavi (PDT) vs Aflibercept Monoterapisi Tartışması",
        kpis=[
            {"val": "%69.3", "label": "EVEREST II Kombine Kolunda Polip Kapanma Oranı"},
            {"val": "%34.7", "label": "Ranibizumab Tek Başına Polip Kapanma Oranı"},
            {"val": "%38.9", "label": "PLANET Aflibercept Tek Başına Polip Kapanma"},
            {"val": "+10.7 Harf", "label": "PLANET Aflibercept Monoterapisi Görme Artışı"}
        ],
        trials_table=[
            {
                "trial": "EVEREST II Çalışması (JAMA Ophthalmol 2017)",
                "design": "322 hasta; Ranibizumab 0.5 mg + Standart PDT vs Ranibizumab Monoterapisi.",
                "result": "Kombine kol hem görme kazanımında (+8.3 vs +5.1 harf) hem de polip lezyonlarını tamamen kapatmada (%69.3 vs %34.7) ezici üstünlük sağladı."
            },
            {
                "trial": "PLANET Çalışması (Lancet 2018)",
                "design": "318 hasta; Aflibercept 2 mg Monoterapisi vs Aflibercept + Kurtarma (Rescue) PDT.",
                "result": "Aflibercept monoterapisi tek başına mükemmel görme artışı sağladı (+10.7 harf); hastaların %85'inde kurtarma PDT'sine gerek kalmadı."
            },
            {
                "trial": "Klinik Uzlaşı ve Konsensus",
                "design": "Ranibizumab kullanılırken mutlaka PDT eklenmelidir; Aflibercept tek başına güçlüdür ancak polip kapatmada PDT hala liderdir.",
                "result": "Göz foveal masif eksüdasyon veya kanama altındaysa en güvenli ve hızlı polip kapanması KOMBİNE PDT ile sağlanır."
            }
        ],
        bottom_evidence="Seviye 1A Kanıt: PCV'de görme artışı için anti-VEGF monoterapisi etkilidir; ancak lezyonun temel patolojisi olan 'polipleri kalıcı kapatmak' için Fotodinamik Tedavi (PDT) tartışmasız altın standarttır [s.145]."
    )

    # Slayt 4.2.3.4: Atlas Görseli: PCV ICGA ve OKT Karşılaştırma Atlası
    img_p144 = builder.get_image_for_page(144)
    builder.add_atlas_image_slide(
        title="POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) MULTİMODAL ATLASI",
        category="BÖLÜM 4.2.3: GÖRSEL ATLAS",
        subtitle="Erken ICGA Polip Kümesi, Thumb-like Dik PED, Çift Hat Belirtisi ve Kanama",
        image_path=img_p144 or "dr_panel_4",
        caption="Referans Eser Sayfa 144: PCV Olgusunda Eşzamanlı ICGA Polip Anevrizmaları ve SD-OKT Dik PED Kubbesi",
        key_findings=[
            "Üzüm Salkımı Polipleri: ICGA'nın ilk 3-5 dakikasında yanan yuvarlak parlak hiperflöresan anevrizma kümeleri [s.144].",
            "Thumb-like PED Kubbesi: OKT'de RPE'nin parmak gibi aniden dikleştiği yüksek kubbe lezyonu.",
            "Double-Layer Sign: Polip tabanından çevreye uzanan çift hiperreflektif yansıma çizgisi.",
            "Subretinal Kanama Sınırı: Fovea altına çökmüş kalın kırmızı kan tabakasının optik gölgelemesi."
        ],
        differentials=[
            "Klasik Yaş YBMD: Yumuşak drusen vardır, koroid incedir; yuvarlak polip nodülleri ve dik thumb PED içermez.",
            "Santral Seröz Koryoretinopati: Polip anevrizması ve BVN yoktur; seröz sıvı tamamen berraktır.",
            "Retinal Makroanevrizma: Retinal arter kökenlidir; koroid ve RPE altı bileşeni yoktur."
        ],
        clinical_pearl="Klasik anti-VEGF monoterapisi ile sıvı kuruyor ancak polip nodülü kapanmıyorsa hasta her an masif kanama riski altındadır; bu olgularda gecikmeden kurtarma PDT'si eklenmelidir [s.146]."
    )

    # Slayt 4.2.3.5: Karşılaştırmalı Analiz: PCV vs Klasik Neovasküler YBMD
    builder.add_split_comparison_slide(
        title="KLİNİK VE TERAPÖTİK AYRIM: PCV VS KLASİK YAŞ YBMD",
        category="BÖLÜM 4.2.3: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Patoloji, İlaç Yanıtı, Polip Kapanması ve PDT İhtiyacının Karşılaştırılması",
        left_entity={
            "name": "POLİPOİDAL VASKÜLOPATİ (PCV)",
            "features": [
                ("Demografi & Etnik", "Asyalılarda %50, genç-orta yaşlılar; pakikoroid zemin hakimdir [s.143]."),
                ("Vasküler Morfoloji", "Dallanan arteriyel ağ (BVN) ve uçlarında anevrizmal nodüler polipler."),
                ("Kanama Deseni", "Spontan MASİF subretinal ve vitreus içi kanama riski çok yüksektir."),
                ("Anti-VEGF Monoterapisi", "Sıvıyı kurutabilir ancak polipleri kapatma oranı düşüktür (%35-40)."),
                ("PDT'nin Rolü", "ALTIN STANDART: Verteporfin PDT polipleri %70-80 oranında kalıcı kapatır.")
            ]
        },
        right_entity={
            "name": "KLASİK YAŞ YBMD (TİP 1 / 2 KNV)",
            "features": [
                ("Demografi & Etnik", "Beyaz ırkta baskın, ileri yaş (>70 yaş); yumuşak drusen zeminlidir [s.133]."),
                ("Vasküler Morfoloji", "Kılcal kapiller filizlenme; deniz yelpazesi veya medusa başı deseni."),
                ("Kanama Deseni", "Genellikle fokal küçük intraretinal veya subretinal kanamalar."),
                ("Anti-VEGF Monoterapisi", "MÜKEMMEL YANIT: Neovasküler damarları hızla kurutur ve regrese eder."),
                ("PDT'nin Rolü", "Günümüzde terk edilmiştir; RPE atrofisi riski nedeniyle uygulanmaz.")
            ]
        },
        bottom_takeaway="Yaş YBMD'de PDT tedavisi RPE atrofisi yaptığı için artık uygulanmazken; PCV'de polipleri kapatmanın ve masif kanamayı önlemenin tek kesin yolu Fotodinamik Tedavidir (PDT) [s.146]."
    )

    # Slayt 4.2.3.6: Akış Şeması: PCV Tanı ve Tedavi Algoritması
    builder.add_decision_tree_slide(
        title="POLİPOİDAL KOROİDEAL VASKÜLOPATİ (PCV) YÖNETİM ALGORİTMASI",
        category="BÖLÜM 4.2.3: KARAR AĞACI",
        subtitle="ICGA ve OKT Bulgularına Göre Monoterapi veya Kombine PDT Kararı",
        root_label="YAŞLI HASTADA MASİF KANAMA VEYA DİK PED (PCV ŞÜPHESİ)",
        branches=[
            {
                "label": "1. ICGA ile Polip + BVN Kanıtlandı",
                "criteria": "Erken fazda parlak polip nodülleri; geç fazda washout; OKT'de dik thumb-like PED [s.144].",
                "action": "Birincil Tercih: İntravitreal Anti-VEGF (Aflibercept/Faricimab) + Kombine Verteporfin PDT."
            },
            {
                "label": "2. ICGA Yok / Yalnızca OKT Belirteçleri",
                "criteria": "Thumb-like PED + Double-layer sign + Çentik (notch) var; ICGA imkanı yok [s.145].",
                "action": "Birincil Tercih: Aflibercept 2mg / 8mg veya Faricimab ile yoğun 3 aylık monoterapi yüklemesi."
            },
            {
                "label": "3. Anti-VEGF'e Dirençli / Sıvı Sürüyor",
                "criteria": "3 doz anti-VEGF'e rağmen subretinal sıvı ve persistan polip varlığı [s.146].",
                "action": "Kurtarma (Rescue): Hastayı gecikmeden PDT merkezine sevk et; poliplere odaklı fokal PDT uygula."
            }
        ],
        bottom_rule="Masif subfoveal kanamalı taze PCV patlamalarında ilk 7-14 gün içinde intravitreal gaz (C3F8) + tPA ile kan foveadan uzaklaştırılmalı; ardından kombine PDT planlanmalıdır [s.146]."
    )

    # Slayt 4.2.3.7: Aktif Hatırlama & Board Sınavı Vakası: PCV
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: PCV",
        category="BÖLÜM 4.2.3: AKTİF HATIRLAMA",
        subtitle="62 Yaşında Asyalı Erkekte Ani Masif Subretinal Kanama ve Dik PED Kubbesi",
        vignette="62 yaşında Asya kökenli erkek hasta sağ gözde aniden başlayan şiddetli görme kaybıyla başvuruyor. Görme keskinliği 20/400. Fundus muayenesinde foveayı tamamen örten 3 disk çapı büyüklüğünde taze subretinal kanama ve kanamanın temporal kenarında parmak şeklinde dik bir RPE elevasyonu izleniyor. Retinada hiç yumuşak drusen yok; karşı gözde subfoveal koroid kalınlığı 420 μm. SD-OKT'de dik thumb-like PED ve double-layer sign saptanıyor.",
        differentials=[
            "Polipoidal Koroideal Vaskülopati (PCV - Etnik köken, kalın koroid, drusensiz zemin ve masif kanama ile kesin tanı).",
            "Tip 2 Neovasküler YBMD (Drusen zemininde gelişir, koroid incedir, kanama genellikle küçüktür).",
            "Retinal Arter Makroanevrizması (Kanamalar çok katmanlı kum saati şeklindedir, arter boyundadır).",
            "Koroid Melanomu Kanaması (Kitle tabanı solid akustik gölgeli olmalıdır)."
        ],
        decision="1. Tanı: Polipoidal Koroideal Vaskülopati (PCV).\n2. Acil Yaklaşım: Foveal fotoreseptörleri kurtarmak için acil İntravitreal Gaz (SF6/C3F8) + tPA ile pnömatik deplasman.\n3. Definitif Tedavi: Kanama açılır açılmaz ICGA ile polip sınırları haritalanmalı ve Anti-VEGF + Kombine Verteporfin PDT uygulanmalıdır.",
        board_trap="Bu hastayı standart kuru/yaş YBMD sanıp yalnızca anti-VEGF monoterapisine almak büyük bir hatadır; polip nodülü kapatılmadığı sürece göz haftalar içinde ikinci bir masif kanamayla total körlüğe gidebilir [s.146]."
    )

    # =========================================================================
    # KONU 4.3.1: VİTREOMAKÜLER ARAYÜZ (VMA) BOZUKLUKLARI (8 SLAYT)
    # =========================================================================
    # Slayt 4.3.1.1: IVTS Uluslararası VMA Sınıflaması
    builder.add_study_card_slide(
        title="ULUSLARARASI VMA / VMT / FTMH SINIFLAMASI (IVTS)",
        category="BÖLÜM 4.3.1: VİTREOMAKÜLER ARAYÜZ",
        subtitle="Uluslararası Vitreomaküler Traksiyon Çalışma Grubu (IVTS) Konsensus Kriterleri",
        cards=[
            {
                "card_title": "1. VİTREOMAKÜLER ADEZYON (VMA)",
                "lead": "Semptomsuz Anatomik Yapışıklık",
                "items": [
                    "Tanım: Periferik korteks ayrılmışken foveaya 3 mm içinde arka hyaloidin yapışık kalmasıdır [s.147].",
                    "Foveal Mimari: Nörosensoryal retina mimarisi ve foveal kontur TAMAMEN NORMALDİR.",
                    "Semptomsuz: Hastanın görmesi 10/10'dur; metamorfopsi veya kistoid sıvı bulunmaz.",
                    "Fokal vs Geniş: Yapışma çapı ≤1500 μm ise 'fokal VMA', >1500 μm ise 'geniş VMA' denir."
                ],
                "footer": "Normal Kontur / Sıfır Traksiyon = VMA"
            },
            {
                "card_title": "2. VİTREOMAKÜLER TRAKSİYON (VMT)",
                "lead": "Foveal Deformasyon ve Çekinti",
                "items": [
                    "Tanım: Arka hyaloid yapışıklığının fovea mimarisini bükerek patolojik çekinti yaratmasıdır [s.147].",
                    "OKT Bulguları: Foveal çukurun düzleşmesi, intraretinal kistler, subretinal sıvı ve EZ bozulması.",
                    "Boyut Sınıflaması: Adezyon çapı ≤400 μm ise 'Fokal VMT'; >400 μm ise 'Geniş VMT'.",
                    "Klinik Semptomlar: Metamorfopsi, görme azalması ve santral skotom."
                ],
                "footer": "Kontur Bozulmuş = VMT (≤400 μm Fokal)"
            },
            {
                "card_title": "3. TAM KAT MAKULA DELİĞİ (FTMH)",
                "lead": "Tüm Retina Katmanlarının Delinmesi",
                "items": [
                    "Tanım: İLM'den RPE'ye kadar fovea merkezinde nörosensoryal retinanın tam kat anatomik defektidir [s.148].",
                    "Küçük Delik: En dar lümen çapı ≤250 μm.",
                    "Orta Delik: En dar lümen çapı 250 - 400 μm.",
                    "Büyük Delik: En dar lümen çapı >400 μm (cerrahi teknik seçimini belirler).",
                    "VMT Eşliği: VMT ile birlikte (açılma evresi) veya VMT olmaksızın (tam ayrılmış)."
                ],
                "footer": "Küçük (≤250) | Orta (250-400) | Büyük (>400 μm)"
            }
        ]
    )

    # Slayt 4.3.1.2: Epiretinal Membran (ERM) Evreleme Sistemi
    builder.add_study_card_slide(
        title="EPİRETİNAL MEMBRAN (ERM) OKT EVRELEMESİ (GOVETTO)",
        category="BÖLÜM 4.3.1: VİTREOMAKÜLER ARAYÜZ",
        subtitle="Evre 1'den Evre 4'e Ektopik İç Foveal Katmanlar (EIFL) ve Görme Prognozu",
        cards=[
            {
                "card_title": "EVRE 1 VE EVRE 2 ERM",
                "lead": "Korunmuş Foveal Çukurluktan Düzleşmeye",
                "items": [
                    "Evre 1 (Hafif): İLM yüzeyinde ince hiperreflektif membran; foveal çukur korunmuştur; görme 10/10 [s.148].",
                    "Evre 2 (Orta): Membran kalınlaşır ve büzüşür; foveal çukurluk tamamen kaybolur (düzleşir).",
                    "Tüm Katmanlar Seçilir: Evre 1 ve 2'de iç ve dış retina katmanları OKT'de net ayırt edilebilir.",
                    "EIFL Yoktur: Ektopik iç foveal katman henüz gelişmemiştir; cerrahi sonrası görme mükemmel döner."
                ],
                "footer": "Evre 1 (Çukur Var) | Evre 2 (Çukur Düz)"
            },
            {
                "card_title": "EVRE 3 ERM (EIFL BAŞLANGICI)",
                "lead": "Ektopik İç Foveal Katmanların Belirmesi",
                "items": [
                    "EIFL Tanımı: Foveola merkezine doğru iç nükleer ve pleksiform katmanların sürekli bir bant halinde uzanması [s.148].",
                    "Kritik Eşik: Fovea merkezinde normalde olmaması gereken nöron tabakalarının birikmesi.",
                    "Retinal Tabakalanma: Katman sınırları hala seçilebilir durumdadır.",
                    "Görsel Düşüş: Görme keskinliği belirgin azalır; cerrahi sonrası toparlanma parsiyeldir."
                ],
                "footer": "Evre 3 = EIFL Var / Tabakalanma Korunmuş"
            },
            {
                "card_title": "EVRE 4 ERM (DİSORGANİZASYON)",
                "lead": "Ağır Anatomik Distorsiyon ve Skar",
                "items": [
                    "Tam Tabaka Bozulması: Foveada iç ve dış retina katman sınırları tamamen silinmiştir [s.149].",
                    "Kalın EIFL Bandı: Tüm makulayı örten kalın, rijit, hiperreflektif ektopik nöral kitle.",
                    "Retinal Kalınlık: Santral kalınlık sıklıkla >500 - 600 μm'ye ulaşır.",
                    "Kötü Prognoz: Cerrahi olarak membran soyulsa dahi nöral devreler bozulduğu için görme artışı sınırlıdır."
                ],
                "footer": "Evre 4 = EIFL Var + Katmanlar Silinmiş"
            }
        ]
    )

    # Slayt 4.3.1.3: Tam Kat Makula Deliği (FTMH) Patogenezi (Gass)
    builder.add_study_card_slide(
        title="TAM KAT MAKULA DELİĞİ (FTMH) EVRELERİ VE PATOGENEZİ",
        category="BÖLÜM 4.3.1: VİTREOMAKÜLER ARAYÜZ",
        subtitle="Gass Evre 1-4 Sınıflaması, Foveal Kistten Total Delinmeye ve Watzke-Allen Testi",
        cards=[
            {
                "card_title": "GASS EVRE 1 (DELİK ÖNCESİ)",
                "lead": "Foveal Kist ve Sarı Nokta / Halka",
                "items": [
                    "Evre 1A (Sarı Nokta): Foveola merkezinde teğetsel traksiyonla oluşan sarı foveolar nokta [s.149].",
                    "Evre 1B (Sarı Halka): Foveal kistin genişlemesiyle santral çukurluğun kaybolup sarı halkaya dönmesi.",
                    "OKT Görünümü: İLM altında foveal kist veya horizontal yarık; fotoreseptör tabakası henüz delinmemiştir.",
                    "Spontan Ayrılma: Olguların %50'sinde korteks çekintisi kendiliğinden ayrılarak delik açılmadan düzelir."
                ],
                "footer": "Evre 1: Delik Öncesi Foveal Kist (%50 Düzelir)"
            },
            {
                "card_title": "GASS EVRE 2 VE 3 (GERÇEK DELİK)",
                "lead": "Erken Defektten Tam Çapa İlerleme",
                "items": [
                    "Evre 2 (Erken Tam Kat Delik): Genellikle <400 μm çaplı, fokal eksantrik yırtılma ile başlayan delik [s.150].",
                    "Evre 3 (Geniş Delik): Çapı >400 μm'ye ulaşmış, kenarlarında kistoid kaviteler ve subretinal sıvı yakalığı olan delik.",
                    "Operkulum: Delinen foveal dokunun arka hyaloid üzerinde serbest yüzen küçük bir kapakçık olarak kalması.",
                    "VMT Ayrımı: Evre 2 ve 3'te arka hyaloid hala optik diske yapışıktır (tam PVD gelişmemiştir)."
                ],
                "footer": "Evre 2 (<400 μm) | Evre 3 (>400 μm / PVD Yok)"
            },
            {
                "card_title": "GASS EVRE 4 VE WATZKE-ALLEN TESTİ",
                "lead": "Tam PVD Eşliğinde Delik ve Klinik Test",
                "items": [
                    "Evre 4 Delik: Arka hyaloid optik diskten de tamamen ayrılmıştır (Weiss halkalı tam PVD mevcuttur) [s.150].",
                    "Watzke-Allen Testi: Biyomikroskopta foveaya ince dikey ışık yarığı düşürülür.",
                    "Pozitif Test: Hasta ışık çizgisinin ortasında kırılma, incelme veya tam kopukluk (boşluk) tarifler.",
                    "Lazer Hedefleme Testi: Delik tabanındaki 50 μm lazer hedef ışığı hasta tarafından algılanamaz."
                ],
                "footer": "Evre 4 (Tam PVD) + Pozitif Watzke-Allen"
            }
        ]
    )

    # Slayt 4.3.1.4: Makula Deliği Cerrahisi: Klasik Soyma vs Ters Flep
    builder.add_split_comparison_slide(
        title="MAKULA DELİĞİ CERRAHİSİ: STANDART İLM SOYMA VS TERS İLM FLEBİ",
        category="BÖLÜM 4.3.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Küçük/Orta Delikler (≤400 μm) vs Büyük/Refrakter Delikler (>400 μm) Cerrahi Stratejisi",
        left_entity={
            "name": "STANDART İLM SOYMA (PEELING)",
            "features": [
                ("Endikasyon Düzeyi", "Çapı ≤400 μm olan küçük ve orta boy taze makula delikleri [s.150]."),
                ("Cerrahi Teknik", "Brilliant Blue G ile İLM boyanır; fovea çevresinde 360° dairesel 2-3 DD İLM soyulup atılır."),
                ("Kapanma Prensibi", "Teğetsel traksiyon sıfırlanır; retina kenarları gaz tamponad altında birbirine yaklaşır."),
                ("Başarı Oranı", "Küçük deliklerde anatomik kapanma oranı %90 - 95 düzeyindedir."),
                ("Kısıtlılığı", ">400 μm büyük deliklerde ve miyopik deliklerde kapanma başarısı %70'in altına düşer.")
            ]
        },
        right_entity={
            "name": "TERS İLM FLEP TEKNİĞİ (INVERTED FLAP)",
            "features": [
                ("Endikasyon Düzeyi", "Çapı >400 μm olan dev delikler, persistan/nüks delikler ve yüksek miyopi [s.151]."),
                ("Cerrahi Teknik", "İLM tamamen koparılmaz; delik kenarına tutunacak menteşeli bir flep bırakılır ve delik içine katlanır."),
                ("Kapanma Prensibi", "Ters katlanan İLM glial hücreler için yapı iskelesi (scaffold) oluşturur; doku köprüsü kurar."),
                ("Başarı Oranı", ">400 μm deliklerde anatomik kapanma oranını %95-98'e çıkarır."),
                ("Görsel İyileşme", "Glial köprü üzerinden dış retina katmanları (ELM ve EZ) aylar içinde restore olur.")
            ]
        },
        bottom_takeaway="Lümen çapı >400 μm olan makula deliklerinde standart İLM soyma yerine Michalewska'nın 'Ters İLM Flep Tekniği' uygulanması kapanma başarısını dramatik artırır [s.151]."
    )

    # Slayt 4.3.1.5: Lameller Delik vs Makuler Psödodelik Ayrımı
    builder.add_split_comparison_slide(
        title="AYIRICI TANI: LAMELLER MAKULA DELİĞİ VS PSÖDODELİK",
        category="BÖLÜM 4.3.1: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Degeneratif vs Traksiyonel Lameller Delik ve ERM Zemininde Yalancı Delik",
        left_entity={
            "name": "LAMELLER MAKULA DELİĞİ (LMD)",
            "features": [
                ("Tanım", "İç retina katmanlarının anatomik defekti; fotoreseptör tabakası korunmuştur [s.151]."),
                ("Foveal Taban", "Deliğin tabanında dış nükleer tabaka veya fotoreseptörler intakt kalır."),
                ("Degeneratif Form", "Epiretinal proliferasyon (LHEP) içerir; kenarlar yuvarlak ve oyukludur (cavitation)."),
                ("Traksiyonel Form", "Klasik ERM çekintisiyle iç katmanların çadır gibi ayrılmasıdır."),
                ("Doğal Seyir", "Çoğunlukla stabil kalır; görme keskinliği genellikle 20/40 - 20/60 arasındadır.")
            ]
        },
        right_entity={
            "name": "MAKULER PSÖDODELİK (MACULAR PSEUDOHOLE)",
            "features": [
                ("Tanım", "Kalın ERM büzüşmesi sonucu normal foveal çukurluğun dik ve derin görünmesidir [s.152]."),
                ("Foveal Taban", "Doku kaybı KESİNLİKLE YOKTUR; tüm 10 katman foveada tamdır."),
                ("OKT Morfolojisi", "Dik kenarlı foveal çukur; perifoveada kalın hiperreflektif ERM omuzları."),
                ("Doğal Seyir", "Gerçek bir delik değildir; doku defekti bulunmaz."),
                ("Tedavi", "Yalnızca belirgin metamorfopsi veya görme kaybı varsa ERM soyulması cerrahisi.")
            ]
        },
        bottom_takeaway="Lameller delikte gerçek bir iç doku kaybı vardır; psödodelikte ise doku kaybı yoktur, kalın ERM omuzları foveayı dikleştirerek yalancı delik görüntüsü verir [s.152]."
    )

    # Slayt 4.3.1.6: Atlas Görseli: FTMH, ERM ve Lameller Delik Atlası
    img_p149 = builder.get_image_for_page(149)
    builder.add_atlas_image_slide(
        title="VİTREOMAKÜLER ARAYÜZ HASTALIKLARI OKT ATLASI",
        category="BÖLÜM 4.3.1: GÖRSEL ATLAS",
        subtitle="Evre 3 FTMH, Kalın Epiretinal Membran, EIFL ve Lameller Defekt",
        image_path=img_p149 or "dr_panel_6",
        caption="Referans Eser Sayfa 149: 450 μm FTMH Kesitinde Kistoid Kenarlar, Subretinal Yakalık ve Operkulum",
        key_findings=[
            "Tam Kat Defekt (450 μm): Fovea merkezinde İLM'den fotoreseptörlere kadar tam kat doku boşluğu [s.149].",
            "Kistoid Kenarlar: Delik kenarlarındaki dış nükleer ve pleksiform katmanlarda kistoid hidrops.",
            "Subretinal Sıvı Yakalığı: Delik çevresinde RPE'den ayrılmış sığ dekolman halkası.",
            "Operkulum Yüzüşü: Arka hyaloid yüzeyinde serbest yüzen foveolar doku kapağı."
        ],
        differentials=[
            "Lameller Delik: Delik tabanında sağlam dış nükleer tabaka ve fotoreseptörler izlenir.",
            "Makuler Psödodelik: Doku kaybı yoktur; dik eğimli fovea ve yüzeyde kalın ERM bulunur.",
            "Güneş Retinopatisi (Solar): Dış retinada fokal EZ defektidir; iç retina katmanları intakttır."
        ],
        clinical_pearl="FTMH cerrahisinde intraoküler gaz tamponadı (SF6 veya C3F8) sonrası hastaya yüzüstü pozisyon (prone positioning) verilmesi, gaz kabarcığının tepe noktasının deliği tıkamasını ve kenarları kurutmasını sağlar [s.151]."
    )

    # Slayt 4.3.1.7: Akış Şeması: Makula Deliği Cerrahi Karar Ağacı
    builder.add_decision_tree_slide(
        title="TAM KAT MAKULA DELİĞİ CERRAHİ YÖNETİM ALGORİTMASI",
        category="BÖLÜM 4.3.1: KARAR AĞACI",
        subtitle="Delik Çapı (μm) ve Kronikliğe Göre Standart Soyma vs Ters Flep Seçimi",
        root_label="OKT'DE TAM KAT MAKULA DELİĞİ (FTMH) SAPTANDI",
        branches=[
            {
                "label": "1. Küçük Delik (≤250 μm)",
                "criteria": "Taze delik (<6 ay); minimal kistoid kenar; foveal traksiyon [s.148].",
                "action": "Cerrahi: PPV + PVD Ayrılması + Standart İLM Soyma + Kısa Etkili Gaz (%20 SF6) -> Kapanma >%95."
            },
            {
                "label": "2. Orta Delik (250 - 400 μm)",
                "criteria": "Tipik evre 3 delik; kistoid kenarlar ve subretinal yakalık mevcut [s.150].",
                "action": "Cerrahi: PPV + Geniş İLM Soyma + Uzun Etkili Gaz (%14 C3F8) + 3-5 gün yüzüstü pozisyon."
            },
            {
                "label": "3. Büyük (>400 μm) veya Refrakter Delik",
                "criteria": "Geniş lümen çapı, yüksek miyopi zemininde delik veya önceden kapanmamış nüks delik [s.151].",
                "action": "Cerrahi: TERS İLM FLEP TEKNİĞİ (Inverted Flap) veya Otolog İLM Transplantasyonu + C3F8 Gaz."
            }
        ],
        bottom_rule="Makula deliği ameliyatı sonrası delik kapansa bile hastanın metamorfopsisinin düzelmesi ve foveal Elipsoid Zon (EZ) restorasyonu 6-12 ay sürebilir [s.151]."
    )

    # Slayt 4.3.1.8: ERM Cerrahi Zamanlaması ve Endikasyonları
    builder.add_study_card_slide(
        title="EPİRETİNAL MEMBRAN (ERM) CERRAHİ ZAMANLAMA KRİTERLERİ",
        category="BÖLÜM 4.3.1: VİTREOMAKÜLER ARAYÜZ",
        subtitle="Ne Zaman Ameliyat Edilmeli? Görme Eşiği, Metamorfopsi Skoru ve EIFL Varlığı",
        cards=[
            {
                "card_title": "CERRAHİ ENDİKASYON KRİTERLERİ",
                "lead": "Semptomatik Hasta Tercihi",
                "items": [
                    "Semptom Varlığı: Yalnızca fundusta zar görülmesi cerrahi endikasyonu DEĞİLDİR [s.152].",
                    "Görme Eşiği: En iyi düzeltilmiş görme keskinliği ≤0.6 (20/30 - 20/40) düzeyine indiğinde.",
                    "Metamorfopsi: Hastanın günlük yaşamını, okumasını veya araba sürmesini bozan dalgalı görme.",
                    "Monoküler Çift Görme: Ağır foveal ektropion ve traksiyona bağlı diplopi gelişmesi."
                ],
                "footer": "Görme ≤0.6 VEYA İlerleyici Metamorfopsi"
            },
            {
                "card_title": "EIFL EVRESİ VE ZAMANLAMA",
                "lead": "Evre 4 Olmadan Müdahale",
                "items": [
                    "İdeal Cerrahi Pencere: Govetto Evre 2 veya erken Evre 3 (EIFL yeni başlarken) en ideal dönemdir [s.152].",
                    "Evre 4 Gecikmesi: Evre 4'e ulaşan, katman sınırları silinmiş gözlerde ameliyat sonrası görme artışı çok sınırlıdır.",
                    "Kombine İLM Soyulması: ERM soyulurken altındaki İLM de soyulursa nüks riski %1'in altına iner.",
                    "Boya Standardı: Çift boyama (Dual staining) veya Brilliant Blue G ile mükemmel görselleştirme."
                ],
                "footer": "Evre 2/3 İdeal Pencere / İLM Soyma Nüksü Önler"
            },
            {
                "card_title": "FAKO-VİTREKTOMİ KOMBİNASYONU",
                "lead": "Fakik Hastalarda Katarakt Hızlanması",
                "items": [
                    "Kaçınılmaz Katarakt: Vitrektomi yapılan 50 yaş üstü fakik gözlerin %80'inde 1-2 yıl içinde nükleer katarakt gelişir [s.152].",
                    "Kombine Cerrahi (Fako+PPV): >55-60 yaş fakik hastalarda fakoemülsifikasyon ve vitrektomi eşzamanlı planlanır.",
                    "Tek İyileşme Dönemi: Hasta ikinci bir ameliyattan kurtulur; erken postoperatif görsel rehabilitasyon sağlanır.",
                    "Refraktif Hedef: Miyopik kayma riski hesaplanarak intraoküler lens gücü doğru ayarlanmalıdır."
                ],
                "footer": ">55 Yaşta Fako-Vitrektomi Kombinasyonu"
            }
        ]
    )

    # =========================================================================
    # KONU 4.3.2: MİYOPİK MAKULOPATİ VE STAFİLOM (7 SLAYT)
    # =========================================================================
    # Slayt 4.3.2.1: Dejeneratif Miyopi ve Biyomekanik Temeller
    builder.add_study_card_slide(
        title="PATOLOJİK MİYOPİ BİYOMEKANİĞİ VE SKLERAL ELASTİSİTE",
        category="BÖLÜM 4.3.2: MİYOPİK MAKULOPATİ",
        subtitle="Aksiyel Uzama (>26 mm), Sklera İncelmesi, Kollajen Remodelingi ve Arka Stafilom",
        cards=[
            {
                "card_title": "PATOLOJİK MİYOPİ TANIMI",
                "lead": "Aks Boyu >26.5 mm / Kırma Kusuru > -6.00 D",
                "items": [
                    "Tanım: Yalnızca kırma kusuru değil; arka kutupta yapısal dejeneratif değişikliklerle giden hastalıktır [s.152].",
                    "Aksiyel Eşik: Aks boyu >26.5 mm (bazen >26.0 mm) veya sferik eşdeğer > -6.00 Dioptri.",
                    "Sklera İncelmesi: Arka kutup sklerası normal kalınlığının (1000 μm) üçte birine (<300 μm) kadar incelir [RV2:pdf410].",
                    "Kollajen Fibril Çapı: Tip I kollajen demetleri çözülür; fibril çapları küçülür ve sklera elastikiyetini yitirir."
                ],
                "footer": "Aks >26.5 mm & Sklera İncelmesi (<300 μm)"
            },
            {
                "card_title": "ARKA STAFİLOM (POSTERIOR STAPHYLOMA)",
                "lead": "Göz Küresi Arka Duvarının Ektazisi",
                "items": [
                    "Tanım: Sklera, koroid ve retinanın geriye doğru lokalize ektatik bombeleşmesidir [s.153].",
                    "Curtin Sınıflaması: Tip 1 (geniş arka kutup stafilomu), Tip 2 (makuler stafilom), Tip 3 (nazal), Tip 4 (inferior).",
                    "Biyomekanik Gerilim: Stafilom kenarlarında retina aşırı gerilir; teğetsel traksiyon foveoskizisi tetikler.",
                    "Görüntüleme: Geniş açılı SS-OKT ve B-Scan stafilom eğriliğini ve derinliğini kusursuz gösterir."
                ],
                "footer": "Sklera Ektazisi / Curtin Sınıflaması"
            },
            {
                "card_title": "META-PM ULUSLARARASI SINIFLAMASI",
                "lead": "Kategori 0'dan Kategori 4'e",
                "items": [
                    "Kategori 0: Miyopik fundus lezyonu yok [s.153].",
                    "Kategori 1: Mozaik (tessellated / kaplan fundus) görünümü.",
                    "Kategori 2: Diffüz koryoretinal atrofi (arka kutupta sarımsı-beyaz solukluk).",
                    "Kategori 3: Yamalı (patchy) koryoretinal atrofi (tam kat koroid ve RPE kaybı gri adalar).",
                    "Kategori 4: Makuler atrofi (foveayı tutan coğrafi atrofi son evresi)."
                ],
                "footer": "META-PM Kat 0-4 Uluslararası Standardı"
            }
        ]
    )

    # Slayt 4.3.2.2: Miyopik Traksiyonel Makulopati (MTM) ve Foveoskizis
    builder.add_study_card_slide(
        title="MİYOPİK TRAKSİYONEL MAKULOPATİ (MTM) VE FOVEOSKİZİS",
        category="BÖLÜM 4.3.2: MİYOPİK MAKULOPATİ",
        subtitle="Skleranın Geriye Kaçması vs Retinanın Esneyememesi ve Katman Katman Ayrılma",
        cards=[
            {
                "card_title": "MEKANİK VE BİYOLOJİK ÇATIŞMA",
                "lead": "Sklera Uzarken Damarlar ve İLM Esneyemez",
                "items": [
                    "Arka Duvar Kaçışı: Stafilom nedeniyle sklera geriye doğru genişler ve uzaklaşır [s.153].",
                    "Esneklik Sınırı: İLM, retinal damarlar ve iç katmanlar sklera kadar uzayamaz; yay kirişi gibi gerilir.",
                    "Katman Katman Yarılma: Teğetsel traksiyon nörosensoryal retinayı kendi katmanları arasından ayırır (foveoskizis).",
                    "Kolon Benzeri Köprüler: Ayrılan tabakalar arasında uzayan Müller hücre köprüleri izlenir."
                ],
                "footer": "Sklera Geriye Kaçar / İç Katmanlar Yırtılır"
            },
            {
                "card_title": "MTM İLERLEME BASAMAKLARI",
                "lead": "Foveoskizisten Makula Deliği Dekolmanına",
                "items": [
                    "1. Foveoskizis: OKT'de dış nükleer ve iç nükleer tabakada horizontal kistoid yarıklar [s.154].",
                    "2. Foveal Kist / Lameller Delik: Foveola merkezindeki Müller konisinin yırtılması.",
                    "3. Foveal Dekolman: Fotoreseptörlerin RPE'den ayrılarak sığ subretinal sıvı oluşturması.",
                    "4. Makula Deliği Dekolmanı (MHD): Tam kat delik açılır ve yüksek miyopik retina hızla total dekolmana gider."
                ],
                "footer": "Skizis -> Foveal Sıvı -> Makula Deliği Dekolmanı"
            },
            {
                "card_title": "CERRAHİ TEDAVİ: PPV VS MAKER BANT",
                "lead": "İçten Dekompresyon vs Dıştan Sklera Desteği",
                "items": [
                    "Pars Plana Vitrektomi (PPV): Arka hyaloid ayrılması + İLM soyulması iç traksiyonu giderir [s.154].",
                    "Fovea Koruyucu İLM Soyma: Fovea merkezindeki İLM delik açılma riskini önlemek için soyulmadan bırakılabilir.",
                    "Makuler Sklera Çökertme (Macular Buckle): Arka stafilom tabanına dıştan L-şekilli plöjet yerleştirilerek sklera öne itilir.",
                    "Kombine Başarı: İleri MTM ve nüks makula deliği dekolmanlarında makuler çökertme en fizyolojik çözümdür."
                ],
                "footer": "Fovea Koruyucu PPV & Makuler Buckle"
            }
        ]
    )

    # Slayt 4.3.2.3: Miyopik Koroideal Neovaskülarizasyon (mKNV)
    builder.add_study_card_slide(
        title="MİYOPİK KOROİDEAL NEOVASKÜLARİZASYON (mKNV)",
        category="BÖLÜM 4.3.2: MİYOPİK MAKULOPATİ",
        subtitle="Lak Çatlakları (Lacquer Cracks), Genç Miyoplar, Tip 2 Morfoloji ve Förster-Fuchs Lekesi",
        cards=[
            {
                "card_title": "LAK ÇATLAKLARI VE KNV BAŞLANGICI",
                "lead": "Bruch Membranının Mekanik Yırtıkları",
                "items": [
                    "Lak Çatlakları (Lacquer Cracks): Aşırı aksiyel gerilmeye dayanamayan Bruch elastik tabakasının lineer kırıklarıdır [s.154].",
                    "Genç Hasta Profili: Genellikle 30 - 50 yaş arası yüksek miyop bireylerde ani görme düşüşü ve metamorfopsi.",
                    "Tip 2 KNV: Koroideal kapillerler Bruch yarığından geçerek doğrudan subretinal alana fırlar.",
                    "Küçük Lezyon Boyutu: Yaş YBMD'ye göre mKNV çok daha küçük, kompakt ve fokal bir damar yumağıdır."
                ],
                "footer": "Bruch Kırığı -> Fokal Tip 2 mKNV"
            },
            {
                "card_title": "FÖRSTER-FUCHS LEKESİ",
                "lead": "Pigmente Subretinal Skar",
                "items": [
                    "Doğal Seyir Skarı: Tedavi edilmeyen mKNV haftalar içinde spontan tromboza ve RPE hiperplazisine uğrar [s.155].",
                    "Klinik Görünüm: Fovea merkezinde küçük, yuvarlak, koyu kahverengi-siyah pigmente skar nodülü.",
                    "Kalıcı Santral Skotom: Förster-Fuchs lekesi oturduğunda foveal fotoreseptörler ölmüştür; geri dönüş yoktur.",
                    "Erken Müdahale Şartı: Skar oturmadan önce acil anti-VEGF ile damar kapatılmalıdır."
                ],
                "footer": "Förster-Fuchs = Geç Dönem Pigmente Skar"
            },
            {
                "card_title": "RADİANCE ÇALIŞMASI VE TEDAVİ",
                "lead": "1 veya 2 Doz Anti-VEGF ile Mükemmel Yanıt",
                "items": [
                    "RADIANCE & MYRROR Çalışmaları: Ranibizumab ve Aflibercept mKNV tedavisinde FDA/EMA onaylıdır [s.155].",
                    "Düşük Enjeksiyon Sayısı: Yaş YBMD gibi sürekli enjeksiyon gerekmez; ortalama 1-2 doz anti-VEGF lezyonu tamamen kurutur.",
                    "PRN Rejimi İdealdir: Yükleme dozu şart değildir; tek enjeksiyon yapılır, hasta aylık OKT ile izlenir.",
                    "Görme Kazanımı: Genç hastalarda erken başlanan tedaviyle +12-14 harf mükemmel görme artışı sağlanır."
                ],
                "footer": "1-2 Doz Anti-VEGF Yeterlidir (RADIANCE)"
            }
        ]
    )

    # Slayt 4.3.2.4: Atlas Görseli: Miyopik Makulopati ve Stafilom Atlası
    img_p153 = builder.get_image_for_page(153)
    builder.add_atlas_image_slide(
        title="MİYOPİK MAKULOPATİ VE ARKA STAFİLOM ATLASI",
        category="BÖLÜM 4.3.2: GÖRSEL ATLAS",
        subtitle="Kaplan Fundus, Foveoskizis, Lak Çatlakları ve Tip 2 mKNV Ağı",
        image_path=img_p153 or "dr_schema_1",
        caption="Referans Eser Sayfa 153: Yüksek Miyopide Arka Stafilom Eğriliği, Foveoskizis Yarıkları ve mKNV",
        key_findings=[
            "Derin Stafilom Eğriliği: SD-OKT kesitinde retinanın arkaya doğru derin bir çanak gibi bükülmesi [s.153].",
            "Foveoskizis Sütunları: Dış ve iç nükleer katmanları birbirinden ayıran dikey glial köprüler ve yarıklar.",
            "Subretinal Hiperreflektif mKNV: Foveada Bruch yarığı üzerinde beliren küçük parlak neovasküler yumak.",
            "Aşırı İnce Koroid: Koroid kalınlığının 50 μm'nin altına indiği kağıt inceliğinde vasküler zemin."
        ],
        differentials=[
            "Standart Yaş YBMD: Yumuşak drusen vardır, aks boyu normaldir; stafilom içermez.",
            "Retinoskizis (Senil): Periferik retinadadır; foveayı tutmaz; yüksek miyopi gerekmez.",
            "Toksik Retinopati: Bilateral konsantrik pigment defekti; koroid kalınlığı normaldir."
        ],
        clinical_pearl="Miyopik KNV tedavisinde yaş YBMD'deki gibi agresif 3 dozluk yükleme yapılmasına gerek yoktur; RADIANCE çalışmasına göre tek bir doz anti-VEGF sonrası PRN izlem olguların çoğunda kalıcı kuruma sağlar [s.155]."
    )

    # Slayt 4.3.2.5: Karşılaştırmalı Analiz: Miyopik KNV vs Yaş YBMD
    builder.add_split_comparison_slide(
        title="NEOVASKÜLARİZASYON AYRIMI: MİYOPİK KNV VS YAŞ YBMD",
        category="BÖLÜM 4.3.2: KARŞILAŞTIRMALI ÇALIŞMA",
        subtitle="Hasta Yaşı, Lezyon Boyutu, Koroid Mimarisi ve İlaç İhtiyacı Karşılaştırması",
        left_entity={
            "name": "MİYOPİK KNV (mKNV)",
            "features": [
                ("Hasta Yaş Grubu", "Genç ve orta yaşlı bireyler (30 - 55 yaş arası) [s.154]."),
                ("Kırma Kusuru & Aks", "Yüksek aksiyel miyopi (>26 mm / > -6.00 D) ve arka stafilom."),
                ("Drusen Varlığı", "Drusen KESİNLİKLE YOKTUR; lak çatlakları zemininde gelişir."),
                ("Lezyon Büyüklüğü", "Çok küçük, kompakt, fokal, foveal yerleşimli Tip 2 KNV."),
                ("Enjeksiyon İhtiyacı", "1. yılda ortalama yalnızca 1 - 3 ENJEKSİYON yeterlidir (düşük nüks).")
            ]
        },
        right_entity={
            "name": "YAŞA BAĞLI YBMD (TİP 1 / 2 KNV)",
            "features": [
                ("Hasta Yaş Grubu", "İleri yaşlı hastalar (>65 - 70 yaş)."),
                ("Kırma Kusuru & Aks", "Genellikle emetrop veya hipermetrop (aks boyu normal <24 mm)."),
                ("Drusen Varlığı", "Her iki gözde geniş confluent yumuşak drusenler mevcuttur."),
                ("Lezyon Büyüklüğü", "Geniş, yaygın, fibrovasküler PED içeren büyük KNV ağları."),
                ("Enjeksiyon İhtiyacı", "Ömür boyu Treat-and-Extend; yılda 6 - 8 enjeksiyon bağımlılığı.")
            ]
        },
        bottom_takeaway="Miyopik KNV hastası gençtir ve lezyon küçüktür; 1-2 doz anti-VEGF ile yıllarca kuru kalabilir; bu hastalara 'ömür boyu her ay iğne olacaksınız' demek gereksiz anksiyetedir [s.155]."
    )

    # Slayt 4.3.2.6: Akış Şeması: Miyopik Traksiyonel Makulopati Cerrahi Kararı
    builder.add_decision_tree_slide(
        title="MİYOPİK MAKULOPATİ (MTM VE mKNV) KLİNİK YÖNETİM ALGORİTMASI",
        category="BÖLÜM 4.3.2: KARAR AĞACI",
        subtitle="Foveoskizis, Neovaskülarizasyon veya Makula Deliği Dekolmanında Adım Adım Protokol",
        root_label="YÜKSEK MİYOP HASTADA GÖRME AZALMASI VE MAKULA LEZYONU",
        branches=[
            {
                "label": "1. Miyopik KNV (mKNV) Saptandı",
                "criteria": "OKTA'da fokal dış retina akımı; lak çatlağı zemininde taze subretinal kanama [s.154].",
                "action": "Tedavi: Tek Doz İntravitreal Anti-VEGF (Ranibizumab/Aflibercept) -> Aylık PRN OKT takibi."
            },
            {
                "label": "2. Asemptomatik Foveoskizis (Görme >0.7)",
                "criteria": "OKT'de iç katman yarıkları var ancak foveal dekolman yok; görme korunmuş [s.153].",
                "action": "Yönetim: Gözlem ve 3 ayda bir OKT takibi -> Cerrahiye acele edilmez; foveal dekolman beklenir."
            },
            {
                "label": "3. Makula Deliği + Retina Dekolmanı (MHD)",
                "criteria": "Stafilom tabanında tam kat delik ve geniş büllöz retina dekolmanı [s.154].",
                "action": "Tedavi: Acil Cerrahi -> Ters İLM Flepli Vitrektomi + Makuler Buckle (Sklera Çökertme) + Silikon Yağı."
            }
        ],
        bottom_rule="Yüksek miyopik foveoskiziste hastanın görmesi 10/10 iken cerrahiye girmek makula deliği riskini tetikleyebilir; cerrahi ancak görme düştüğünde veya foveal dekolman başladığında endikedir [s.154]."
    )

    # Slayt 4.3.2.7: Aktif Hatırlama & Board Sınavı Vakası: Miyopik KNV
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: MİYOPİK MAKULOPATİ",
        category="BÖLÜM 4.3.2: AKTİF HATIRLAMA",
        subtitle="38 Yaşında Kadın Grafikerde -8.00 D Miyopi, Ani Çizgi Kırılması ve Küçük Foveal Kanama",
        vignette="38 yaşında kadın grafiker sağ gözünde 3 gündür bilgisayar ekranındaki düz çizgileri kırık ve eğri gördüğünü (metamorfopsi) belirterek acile başvuruyor. Kırma kusuru her iki gözde -8.50 D, aksiyel uzunluk sağda 27.2 mm. Sağ görme 0.4'e düşmüş. Biyomikroskopide arka kutupta tessellated fundus, optik diskte temporal miyopik konus ve foveola kenarında 1/4 disk çapında minik subretinal kanama izleniyor. Drusen yok. SD-OKT'de fovea altında küçük hiperreflektif SHRM (Tip 2 KNV) ve sığ subretinal sıvı mevcut.",
        differentials=[
            "Miyopik Koroideal Neovaskülarizasyon (mKNV - Yaş, aks boyu, metamorfopsi ve OKT ile kesin tanı).",
            "İzole Lak Çatlağı Kanaması (Neovaskülarizasyon olmaksızın çatlak kanaması; OKTA'da akım sinyali yoktur).",
            "İdiyopatik KNV (Genç hastada miyopi olmaksızın gelişen nadir form).",
            "Santral Seröz Koryoretinopati (Koroid aşırı kalındır; bu hastada koroid kağıt gibi incedir)."
        ],
        decision="1. Tanı: Miyopik Koroideal Neovaskülarizasyon (mKNV).\n2. Tedavi: Derhal tek doz İntravitreal Anti-VEGF (Ranibizumab 0.5 mg veya Aflibercept 2 mg) uygulanmalıdır.\n3. Takip: Yaş YBMD gibi 3 doz yükleme yapılmaz; 1 ay sonra kontrole çağrılır, sıvı tamamen çekilmişse PRN izleme geçilir.",
        board_trap="Bu hastada 'küçük bir kanama var, kendiliğinden geçer' diye beklenirse lezyon haftalar içinde fibrotik Förster-Fuchs siyah pigment skarına dönüşür ve 38 yaşındaki hastanın santral foveal görmesi kalıcı olarak kaybedilir [s.155]."
    )

    print(f" -> Bölüm 4 (Makula Hastalıkları ve YBMD) Tamamlandı: 52 Slayt Eklendi.")
