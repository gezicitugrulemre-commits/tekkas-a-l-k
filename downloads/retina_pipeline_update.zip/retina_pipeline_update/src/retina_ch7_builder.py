# -*- coding: utf-8 -*-
r"""
retina_ch7_builder.py — Bölüm 7: Enfeksiyöz ve İnflamatuar Retina Hastalıkları (62 Slayt)
========================================================================================
Kitap Sayfaları: 201 – 244
Alt Başlıklar:
  7.0   Bölüm 7 Çalışma Yol Haritası (1 slayt)
  7.1.1 Viral Retinitler (ARN, PORN, CMV Retiniti) (8 slayt)
  7.1.2 Oküler Toksoplazmoz, Toksokariyazis, Tüberküloz ve Sifiliz (8 slayt)
  7.2.1 Behçet Hastalığı ve Retinal Vaskülit Yönetimi (7 slayt)
  7.2.2 Vogt-Koyanagi-Harada (VKH) Sendromu ve Oküler Sarkoidoz (7 slayt)
  7.3.1 - 7.3.5 Beyaz Nokta Sendromları (MEWDS, APMPPE, Birdshot, MFC/PIC, Serpinöz) (25 slayt)
  7.3.6 Beyaz Nokta Sendromları Karşılaştırmalı Ayırıcı Tanı ve Karar Matrisi (6 slayt)
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from retina_study_builder_core import RetinaStudyDeckBuilder

from dr_masterclass_engine import PPTXPalette


def build_chapter_7(builder: RetinaStudyDeckBuilder):
    """Bölüm 7'ye ait 62 slaytı sunuma ekler."""

    # =========================================================================
    # SLAYT 1: BÖLÜM 7 ÇALIŞMA YOL HARİTASI
    # =========================================================================
    builder.add_chapter_study_roadmap(
        part_num=7,
        title="ENFEKSİYÖZ VE İNFLAMATUAR RETİNA HASTALIKLARI",
        page_range="Sayfa 201 – 244",
        subtitle="Viral Retinitler, Paraziter/Bakteriyel Üveitler, Behçet, VKH ve Beyaz Nokta Atlası",
        cards=[
            {
                "title": "1. Viral Retinitler & Nekroz",
                "color": PPTXPalette.RED,
                "lead": "ARN, PORN ve CMV Triyajı",
                "items": [
                    "Akut Retinal Nekroz (ARN): İmmünkompetan hastada periferik nekroz, vaskülit ve yoğun vitrit.",
                    "PORN: Ağır immün yetmezlikte (CD4 <50) vitritsiz derin dış retinal nekroz; saatler içinde makulaya ilerler.",
                    "CMV Retiniti: CD4 <50 HIV olgularında 'pizza pie' kanamalı nekroz; İV/İVİ Gansiklovir şarttır.",
                    "Yırtık ve Dekolman Riski: Nekroz sınırında %50-70 dev yırtık ve RRD; profilaktik lazer hayatidir."
                ],
                "footer": "ARN (Vitrit +) / PORN (Vitrit -) / CMV (Gansiklovir)"
            },
            {
                "title": "2. Paraziter & Bakteriyel Enfeksiyon",
                "color": PPTXPalette.AMBER,
                "lead": "Tokso, Sifiliz & Tüberküloz",
                "items": [
                    "Oküler Toksoplazmoz: Eski pigmente skar kenarında taze kabarık nekroz ('sis içinde far' manzarası).",
                    "Tokso Tedavi Kuralı: Tek başına steroid KESİNLİKLE YASAKTIR; TMP-SMX veya Pirimetamin/Sülfadiazin şart.",
                    "Oküler Sifiliz: 'Büyük taklitçi'; plazmid taraması (VDRL/RPR) ve nörosifiliz protokolü Penisilin G.",
                    "Oküler Tüberküloz: Serpinöz benzeri koroidit ve oklüzif vaskülit; PPD/IGRA + 4'lü antitüberküloz rejim."
                ],
                "footer": "Tokso (Tek Steroid Yasak) / Sifiliz (Penisilin)"
            },
            {
                "title": "3. Behçet, VKH & Sarkoidoz",
                "color": PPTXPalette.BLUE,
                "lead": "Otoimmün Retinal Vaskülit",
                "items": [
                    "Behçet Hastalığı: Tekrarlayan non-granülomatöz panüveit, hipopiyon ve nekrotizan oklüzif retinal vaskülit.",
                    "Behçet Biyolojik Tedavisi: Anti-TNF (İnfliksimab / Adalimumab) ve IFN-alfa görmeyi kurtaran devrimdir.",
                    "VKH Sendromu: Bilateral büllöz seröz eksüdatif dekolman; 'gün batımı fundusu'; yüksek doz pulse steroid.",
                    "Oküler Sarkoidoz: Granülomatöz panüveit, mum damlası (candle-wax) periflebiti, Berlin nodülleri."
                ],
                "footer": "Behçet (Anti-TNF) / VKH (Pulse Steroid)"
            },
            {
                "title": "4. Beyaz Nokta Sendromları Atlası",
                "color": PPTXPalette.GREEN,
                "lead": "MEWDS'ten Serpinöze Spektrum",
                "items": [
                    "MEWDS: Genç kadında viral grip sonrası foveal granülarite ve kör nokta genişlemesi; tam spontan iyileşme.",
                    "APMPPE: Plakoid lezyonlar; FFA'da 'block early, stain late'; serebral vaskülit riski nedeniyle steroid şart.",
                    "Birdshot (HLA-A29): %99 HLA ilişkisi; saçma tanesi sarı lezyonlar; erken immünomodülatör tedavi.",
                    "MFC / PIC: Miyop kadınlarda inflamatuar KNV riski; Serpinöz: optik diskten başlayan yılankavi atrofi."
                ],
                "footer": "MEWDS (Selim) / APMPPE (İnme Riski) / Birdshot (HLA-A29)"
            }
        ]
    )

    # =========================================================================
    # 7.1.1: VİRAL RETİNİTLER (ARN, PORN, CMV) (8 Slayt)
    # =========================================================================

    # Slayt 7.1.1.1: Viral Retinit Patofizyolojisi ve Virüs Trofizmleri
    builder.add_study_card_slide(
        title="VİRAL RETİNİTLERİN PATOFİZYOLOJİSİ VE VİRAL TROPİZM",
        category="BÖLÜM 7.1.1: VİRAL RETİNİT",
        subtitle="Herpes Simplex (HSV), Varisella Zoster (VZV) ve Sitomegalovirüs (CMV) Reaktivasyonu",
        cards=[
            {
                "card_title": "1. Virüs Girişi ve Retrograd Taşınma",
                "lead": "Trigeminal ve Serebral Gangliyon Rezervuarı",
                "items": [
                    "HSV-1, HSV-2 ve VZV kraniyal duyusal sinir gangliyonlarında ömür boyu latent kalır [s.201].",
                    "İmmün supresyon, travma veya sistemik stres virüsün aksonal retrograd transportla retinaya inmesini tetikler.",
                    "Virüs nörosensoriyel retinaya ulaştığında hücreden hücreye hızla yayılarak litik nekroz başlatır.",
                    "Gençlerde HSV-1/HSV-2, yaşlılarda ise VZV virüsü akut retinal nekrozdan en sık izole edilen ajandır."
                ],
                "footer": "Gangliyon Latensi -> Retrograd Göç -> Litik Nekroz"
            },
            {
                "card_title": "2. Tam Kat Nekroz ve Vasküler Oklüzyon",
                "lead": "Retinanın Tamamen Erimesi",
                "items": [
                    "Virüs hem nöronları hem de vasküler endotel hücrelerini enfekte eder [s.201].",
                    "Endotel hasarı şiddetli retinal arterit ve venöz oklüzyonlara (perivaskülit) yol açar.",
                    "İskemi ile viral sitoliz birleştiğinde nörosensoriyel retina saatler/günler içinde sarı-beyaz nekrotik peynirleşmeye uğrar.",
                    "Nekrotik alan rezorbe olurken geride kağıt gibi incelmiş, delikli ve aşırı kırılgan bir retina bırakır."
                ],
                "footer": "Vasküler Oklüzyon + Sitoliz -> Kağıt İnceliğinde Retina"
            },
            {
                "card_title": "3. İmmünolojik Durumun Belirleyiciliği",
                "lead": "İmmün Yanıtın Varlığı vs Yokluğu",
                "items": [
                    "İmmün yetkin (sağlıklı) hastada: Güçlü T-hücre yanıtı nedeniyle yoğun vitrit ve ön kamara yangısı gelişir (ARN) [s.202].",
                    "Ağır immün yetmezlikli hastada (HIV/AIDS): İmmün yanıt verilemediği için vitrit SIFIRDIR; yangısız derin nekroz gelişir (PORN).",
                    "Bu nedenle vitreusun berrak olması enfeksiyonu dışlamaz; aksine en tehlikeli formu (PORN) gösterir.",
                    "Tanıda altın standart: Ön kamara veya vitreus sıvısından PCR ile HSV, VZV ve CMV DNA'sının saptanmasıdır."
                ],
                "footer": "PCR Tanısı / İmmünkompetan (Vitrit +) / İmmünsüprese (Vitrit -)"
            }
        ]
    )

    # Slayt 7.1.1.2: Akut Retinal Nekroz (ARN): Klinik Triad ve Tedavi
    builder.add_study_card_slide(
        title="AKUT RETİNAL NEKROZ (ARN): TANI KRİTERLERİ VE TEDAVİ",
        category="BÖLÜM 7.1.1: ARN",
        subtitle="Amerikan Üveit Derneği Kriterleri, Çevresel İlerleme ve Acil Antiviral Protokolü",
        cards=[
            {
                "card_title": "1. ARN Resmi Tanı Triadı (AUBS)",
                "lead": "Amerikan Üveit Derneği Kriterleri",
                "items": [
                    "1. Periferik Retinal Nekroz: Keskin sınırlı, sarımsı-beyaz, saat kadranları boyunca birleşen nekroz odakları [s.202].",
                    "2. Hızlı Çevresel (Sirkumferensiyal) İlerleme: Tedavisiz saatler içinde tüm periferi sararak merkeze yürür.",
                    "3. Oklüzif Vaskülopati ve Yoğun Vitrit: Şiddetli arteriyit, kılıflanma ve ön kamara/arka vitreus bulanıklığı.",
                    "Optik nöropati olguların %50'sinde tabloya eşlik eder ve görme prognozunu ağırlaştırır."
                ],
                "footer": "Periferik Nekroz + Oklüzif Arterit + Yoğun Vitrit"
            },
            {
                "card_title": "2. Acil Antiviral Tedavi Protokolü",
                "lead": "İlk Saatlerde Başlanması Gereken Rejim",
                "items": [
                    "İntravenöz Asiklovir: 10-15 mg/kg (günde 3 kez, her 8 saatte bir) 7-10 gün boyunca verilir [s.202].",
                    "Alternatif Oral Tedavi: Oral Valasiklovir (1000 mg günde 3 kez) İV asiklovir kadar biyoyararlanıma sahiptir.",
                    "İntravitreal İğne Desteği: Dirençli veya makulayı tehdit eden vakalarda intravitreal Gansiklovir (2 mg/0.05 ml) veya Foskarnet (2.4 mg) eklenir.",
                    "İdame: Sistemik Valasiklovir (1000 mg 1-2x) en az 3-6 ay sürdürülür (diğer gözü korumak için hayati)."
                ],
                "footer": "İV Asiklovir / Oral Valasiklovir + İntravitreal Gansiklovir"
            },
            {
                "card_title": "3. Sistemik Kortikosteroid Zamanlaması",
                "lead": "Kritik Kural: Asla Antiviralsiz Başlanamaz!",
                "items": [
                    "Vitrit ve optik sinir ödemini baskılamak için oral prednizolon (0.5-1 mg/kg/gün) gereklidir [s.203].",
                    "ANCAK kortikosteroid mutlaka etkili antiviral tedavinin 24-48. saatinden SONRA başlanmalıdır.",
                    "Antiviral olmaksızın steroid verilmesi viral replikasyonu patlatarak tüm retinanın hızla erimesine yol açar.",
                    "Steroid dozu inflamasyon kontrol altına alındıkça yavaşça azaltılarak kesilir."
                ],
                "footer": "⚠️ Steroid Ancak Antiviralden 48 Saat Sonra Başlanır"
            }
        ]
    )

    # Slayt 7.1.1.3: Progresif Dış Retinal Nekroz (PORN)
    builder.add_study_card_slide(
        title="PROGRESİF DIŞ RETİNAL NEKROZ (PORN)",
        category="BÖLÜM 7.1.1: PORN",
        subtitle="Ağır İmmün Yetmezlikte VZV Enfeksiyonu: Yangısız, Vitritsiz ve Yıldırım Hızında Körlük",
        cards=[
            {
                "card_title": "1. PORN Patofizyolojisi ve Etyoloji",
                "lead": "CD4 <50 Hücre/μl Olan AIDS Hastaları",
                "items": [
                    "Neredeyse tamamı Varisella Zoster Virüsü (VZV) kaynaklıdır; nadiren HSV eşlik eder [s.203].",
                    "Ağır hücresel immün yetmezlik (özellikle CD4 <50) zemininde gelişir.",
                    "Konak inflamatuar yanıt veremediği için ön kamara ve vitreus tamamen pürüzsüz ve berraktır.",
                    "Hasar doğrudan dış retina katmanlarında (fotoreseptör ve dış nükleer tabaka) başlar."
                ],
                "footer": "VZV Kökenli / CD4 <50 / Dış Retina Hasarı"
            },
            {
                "card_title": "2. Klinik Görünüm ve Hız",
                "lead": "Makulayı Erken Tutan Derin Sarı Plaklar",
                "items": [
                    "Derin retinada çok odaklı, sarı-beyaz, sınırları birleşen plakoid nekroz alanları izlenir [s.203].",
                    "ARN'den farklı olarak periferden başlamak zorunda değildir; doğrudan makula ve arka kutbu tutabilir.",
                    "Retinal damarlar başlangıçta temizdir (vaskülit minimaldir); ancak nekroz günler içinde tüm retinayı sarar.",
                    "Hastaların %70'inde her iki göz günler içinde bilateral olarak körleşir."
                ],
                "footer": "Derin Sarı Plaklar / Erken Makula Tutulumu / Bilateralite"
            },
            {
                "card_title": "3. Agresif Kombine Tedavi",
                "lead": "Monoterapi Yetersizdir",
                "items": [
                    "PORN standart asiklovir monoterapisine son derece dirençlidir [s.204].",
                    "İntravenöz Gansiklovir (5 mg/kg 2x/gün) + İntravenöz Foskarnet (90 mg/kg 2x/gün) kombinasyonu şarttır.",
                    "Ayrıca haftada iki kez İntravitreal Gansiklovir ve Foskarnet enjeksiyonları uygulanmalıdır.",
                    "Eşzamanlı olarak enfeksiyon hastalıkları ile yüksek etkili antiretroviral tedavi (HAART) optimize edilmelidir."
                ],
                "footer": "İV Gansiklovir + Foskarnet Çift Rejimi + HAART"
            }
        ]
    )

    # Slayt 7.1.1.4: Sitomegalovirüs (CMV) Retiniti: Pizza Pie ve Gansiklovir
    builder.add_study_card_slide(
        title="SİTOMEGALOVİRÜS (CMV) RETİNİTİ: PİZZA PİE FENOTİPİ",
        category="BÖLÜM 7.1.1: CMV",
        subtitle="CD4 <50 HIV Olguları, Vasküler Yayılım, Kanamalı Nekroz ve Valgansiklovir",
        cards=[
            {
                "card_title": "1. Epidemiyoloji ve Risk Grubu",
                "lead": "Fırsatçı Enfeksiyonların Klasiği",
                "items": [
                    "HIV/AIDS hastalarında CD4 lenfosit sayısı <50 hücre/μl düzeyine indiğinde ortaya çıkar [s.204].",
                    "Organ nakli sonrası ağır immünsüpresyon alan veya lösemi/lenfoma hastalarında da gelişebilir.",
                    "HAART tedavisi öncesi AIDS hastalarının %30-40'ında görülürken, modern çağda insidansı belirgin azalmıştır.",
                    "Semptomlar: Görmede yavaş ilerleyen bulanıklık, uçuşmalar veya görme alanında kayıp adacıkları."
                ],
                "footer": "CD4 <50 / Fırsatçı Enfeksiyon / HAART ile Azalan İnsidans"
            },
            {
                "card_title": "2. Klinik Görünüm Tipleri",
                "lead": "Pizza Pie vs Granüler Morfoloji",
                "items": [
                    "Klasik / Fulminan Tip ('Pizza Pie' veya 'Çilek Reçeli'): Retinal damar arkatları boyunca masif kanamalı beyaz nekroz [s.204].",
                    "Granüler / İndolent Tip: Periferik retinada az kanamalı, kuru, granüler beyaz infiltratlar.",
                    "Perivasküler 'Frosted Branch' (Buzlu Cam Dalları): Damarları kılıflayan şiddetli vaskülit manzarası.",
                    "İnflamasyon minimaldir (vitrit hafiftir); nekroz damarlar boyunca 'çalı yangını' gibi yayılır."
                ],
                "footer": "Pizza Pie (Kanamalı Nekroz) / Granüler Periferik Tip"
            },
            {
                "card_title": "3. Tedavi: Valgansiklovir & Gansiklovir",
                "lead": "İndüksiyon ve İdame Fazları",
                "items": [
                    "Oral Valgansiklovir: İndüksiyonda 900 mg günde 2 kez (21 gün), ardından idamede 900 mg günde 1 kez [s.205].",
                    "İntravenöz Gansiklovir (5 mg/kg 2x/gün) veya Foskarnet alternatif indüksiyon ajanlarıdır.",
                    "Makulayı tehdit eden lezyonlarda derhal İntravitreal Gansiklovir (2 mg) enjekte edilmelidir.",
                    "HAART ile CD4 sayısı >100 hücre/μl üzerine çıkıp 3-6 ay stabil kalınca antiviral idame sonlandırılabilir."
                ],
                "footer": "Oral Valgansiklovir 900 mg 2x -> 1x / CD4 >100 Kriteri"
            }
        ]
    )

    # Slayt 7.1.1.5: Viral Retinitler Büyük Karşılaştırma Matrisi
    builder.add_split_comparison_slide(
        title="VİRAL RETİNİTLERİN BÜYÜK AYIRICI TANI MATRİSİ",
        category="BÖLÜM 7.1.1: KARŞILAŞTIRMA",
        subtitle="Akut Retinal Nekroz (ARN) vs PORN vs Sitomegalovirüs (CMV) Retiniti",
        left_entity={
            "name": "AKUT RETİNAL NEKROZ (ARN)",
            "subtitle": "İmmünkompetan Birey — HSV / VZV",
            "bullets": [
                "İmmün Durum: Genellikle immünolojik olarak sağlıklı bireylerde görülür [s.202].",
                "Vitrit Derecesi: ÇOK ŞİDDETLİDİR (Göz dibi pusludur, ön kamarada fibrin vardır).",
                "Başlangıç Yeri: Ekstrem periferik retinadan başlar, 360° birleşerek merkeze yürür.",
                "Damar Tutulumu: Şiddetli oklüzif arterit ve venöz oklüzyonlar mevcuttur.",
                "Dekolman Riski: %50-70 oranında multipl delikli dev regmatojen dekolman gelişir.",
                "İlk Tedavi: İntravenöz Asiklovir veya Oral Valasiklovir + Geç Steroid [s.203]."
            ]
        },
        right_entity={
            "name": "PORN & CMV RETİNİTİ",
            "subtitle": "Ağır İmmün Yetmezlik (CD4 <50) — VZV / CMV",
            "bullets": [
                "İmmün Durum: Ağır hücresel immün yetmezlik (AIDS, organ nakli, lenfoma) [s.203].",
                "Vitrit Derecesi: MİNİMAL VEYA SIFIRDIR (Vitreus berraktır; yangısız nekroz).",
                "Başlangıç Yeri: PORN derin dış retinada fokal plaklar; CMV damar arkatlarında kanamalı başlar.",
                "Damar Tutulumu: PORN'da damarlar temiz kalabilir; CMV'de perivasküler kanamalı nekroz vardır.",
                "Dekolman Riski: Nekroz sonrası atrofik incelme zemininde yüksek yırtıklı dekolman.",
                "İlk Tedavi: İV Gansiklovir + Foskarnet (PORN) veya Oral Valgansiklovir (CMV) [s.204]."
            ]
        },
        bottom_takeaway="Ön kamara ve vitreusunda tek bir hücre bile olmayan bir hastada retinada beyaz nekroz görülürse bu PORN'dur; vitritin olmaması hastanın immün sisteminin çökmüş olduğunu kanıtlar [s.203]."
    )

    # Slayt 7.1.1.6: Viral Retinitlerde Dekolman Önleme ve Cerrahi
    builder.add_study_card_slide(
        title="VİRAL RETİNİT KOMPLİKASYONU: YIRTIK VE DEKOLMAN YÖNETİMİ",
        category="BÖLÜM 7.1.1: CERRAHİ YÖNETİM",
        subtitle="Nekroz Sınırında Gelişen Multipl Delikler, Profilaktik Bariyer Lazer ve Silikon Vitrektomisi",
        cards=[
            {
                "card_title": "1. Dekolman Mekanizması ve Zamanlaması",
                "lead": "Nekrotik Retinanın Kağıt Gibi Yırtılması",
                "items": [
                    "Nekroz alanları iyileşirken retina incelir ve koryoretinal atrofi sınırında aşırı gerilim oluşur [s.205].",
                    "Enfeksiyondan 3-8 hafta sonra hastaların %50-75'inde multipl dev at nalı yırtıklar veya retinal diyaliz açılır.",
                    "Oluşan dekolman genellikle büllöz, arka kutba hızla uzanan ve yüksek PVR riski taşıyan bir tablodur.",
                    "Göz içi vitreus inflamasyonu da vitreus çekintisini artırarak yırtık oluşumunu hızlandırır."
                ],
                "footer": "3-8 Hafta / Multipl Yırtık / %70 Dekolman Riski"
            },
            {
                "card_title": "2. Profilaktik Bariyer Lazer Protokolü",
                "lead": "Dekolmanı Önleyen Cerrahi Kilit",
                "items": [
                    "Nekrotik alanın sağlam retina ile birleştiği sınırın hemen arkasına 3-4 sıra bariyer lazer atılmalıdır [s.205].",
                    "Lazer nekrotik alanın içine DEĞİL, tamamen sağlıklı ve pigmentli retina zeminine uygulanmalıdır.",
                    "Optik ortam vitrit nedeniyle opaksa lazer atılamaz; vitrit açılır açılmaz profilaksi tamamlanmalıdır.",
                    "Profilaktik bariyer lazer, ARN olgularında dekolman riskini %70'ten %25-30 düzeyine indirir."
                ],
                "footer": "Sağlıklı Sınıra 3 Sıra Lazer / %70'ten %25'e Düşüş"
            },
            {
                "card_title": "3. Cerrahi: PPV ve Silikon Yağı",
                "lead": "Gaz Değil, Mutlaka Silikon Yağı!",
                "items": [
                    "Viral retinite bağlı dekolman geliştiğinde standart tedavi 23/25G Pars Plana Vitrektomidir [s.205].",
                    "Retina son derece frajil ve nekrotiktir; gereksiz forseps manipulasyonlarından kaçınılmalıdır.",
                    "Tüm traksiyonlar kesildikten sonra 360 derece endolazer uygulanır.",
                    "İç tamponad olarak gaz KULLANILMAZ; nekrotik retinada uzun süreli bası sağlamak için Silikon Yağı (1000/5000 cSt) şarttır."
                ],
                "footer": "PPV + 360° Endolazer + Silikon Yağı Şarttır"
            }
        ]
    )

    # Slayt 7.1.1.7: Viral Retinit Tanı ve Tedavi Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="VİRAL RETİNİT TANI VE TEDAVİ PROTOKOLÜ",
        category="BÖLÜM 7.1.1: AKIŞ ŞEMASI",
        subtitle="Akut Beyaz Retinal Nekrozla Başvuran Hastada Saatlik Müdahale Algoritması",
        steps=[
            {
                "num": "1",
                "title": "İmmün Profil & PCR Parasentezi",
                "desc": "HIV serolojisi doğrulanır; ön kamara sıvısından HSV, VZV ve CMV için multiplex PCR alınır [s.202].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Acil İntravenöz / Oral Antiviral Başlanması",
                "desc": "PCR sonucu beklenmeksizin İV Asiklovir veya Oral Valasiklovir + İntravitreal Gansiklovir yüklenir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "48. Saatte Sistemik Kortikosteroid",
                "desc": "Antiviral kalkanı altında vitrit ve optik sinir ödemini dindirmek için oral prednizolon (1 mg/kg) eklenir.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Profilaktik Bariyer Lazer Uygulaması",
                "desc": "Medikal yanıtla nekroz sınırları belirlenince sağlam retinaya 360° bariyer lazer kilitlenir [s.205].",
                "status": "success"
            }
        ],
        bottom_takeaway="PCR sonucunu beklemek için tedaviyi 2 gün geciktirmek nekrozun foveaya ulaşmasına ve kalıcı körlüğe neden olur; tedavi klinik şüphe ile derhal başlanmalıdır [s.202]."
    )

    # Slayt 7.1.1.8: Aktif Hatırlama & Board Sınavı Vakası: 38 Yaş ARN Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: AKUT RETİNAL NEKROZ",
        category="BÖLÜM 7.1.1: AKTİF HATIRLAMA",
        subtitle="38 Yaşında Sağlıklı Erkekte Kızarık Ağrılı Göz, Yoğun Vitrit ve Periferik Sarı Nekroz",
        vignette="38 yaşında bilinen sistemik hastalığı olmayan erkek hasta, sağ gözünde 4 gündür artan kızarıklık, künt ağrı ve görmede ani sislenme şikayetiyle başvuruyor. Görme keskinliği sağda 0.2, solda 1.0 tam. Biyomikroskopide sağ gözde konjonktival hiperemi, kornea endotelinde granülomatöz olmayan keratik presipitatlar, ön kamarada 3+ hücre ve arka vitreusta fundus detaylarını silen yoğun 3+ vitrit izleniyor. İndirekt oftalmoskopide temporal periferde başlayıp saat 7:00'den 1:00'e kadar uzanan birleşik, kaba sarımsı-beyaz nekroz odakları ve çevreleyen retinal damarlarda şiddetli kılıflanma (arterit) saptanıyor. Fovea henüz nekrozla tutulmamış. Sol göz tamamen normal.",
        differentials=[
            "Akut Retinal Nekroz (ARN - İmmünkompetan genç erişkin, periferik nekroz, şiddetli oklüzif vaskülit ve vitrit).",
            "Progresif Dış Retinal Nekroz (PORN - İmmün yetmezlikte görülür, vitrit SIFIRDIR; bu hastada yoğun vitrit var).",
            "Sitomegalovirüs Retiniti (Kanama çok baskındır, vitrit hafiftir, CD4 <50 HIV hastasında beklenir).",
            "Bakteriyel Postoperatif Endoftalmi (Cerrahi veya travma öyküsü olmadığı için dışlanır)."
        ],
        decision="1. Klinik Tanı: Akut Retinal Nekroz (ARN - Yüksek olasılıkla HSV-1 veya VZV kökenli).\n2. Acil Tedavi: Hasta derhal yatırılmalı, ön kamaradan PCR için sıvı alınıp SONUÇ BEKLENMEDEN İntravenöz Asiklovir (10 mg/kg günde 3 kez) veya Oral Valasiklovir (1000 mg günde 3 kez) başlanmalıdır.\n3. İntravitreal Destek: Makulayı korumak için sağ göze aynı gün İntravitreal Gansiklovir (2 mg/0.05 ml) enjekte edilmelidir.\n4. Steroid: Antiviral tedavinin 48. saatinde vitriti baskılamak için Oral Prednizolon (1 mg/kg/gün) eklenmelidir.",
        board_trap="Bu hastada yoğun vitriti görüp 'bu şiddetli bir üveit' diyerek antiviral vermeden tek başına yüksek doz steroid başlamak retinayı saatler içinde eritir; viral nekrozda antiviralsiz steroid KESİNLİKLE KONTRENDİKEDİR [s.203]."
    )

    # =========================================================================
    # 7.1.2: OKÜLER TOKSOPLAZMOZ, TOKSOKARİYA, TB VE SİFİLİZ (8 Slayt)
    # =========================================================================

    # Slayt 7.1.2.1: Oküler Toksoplazmozis: 'Sis İçinde Far' Fenotipi
    builder.add_study_card_slide(
        title="OKÜLER TOKSOPLAZMOZİS: 'SİS İÇİNDE FAR' PATOGENEZİ",
        category="BÖLÜM 7.1.2: TOKSOPLAZMOZİS",
        subtitle="Toxoplasma gondii Bradizoit Kist Reaktivasyonu, Fokal Nekrotizan Retinit ve Vitrit",
        cards=[
            {
                "card_title": "1. Parazitoloji ve Reaktivasyon",
                "lead": "Konjenital Kistin Yıllar Sonra Patlaması",
                "items": [
                    "Dünyada posterior enfeksiyöz üveitlerin en sık nedenidir (%30-50) [s.205].",
                    "Çoğu olgu konjenital geçişli latent bradizoit doku kistlerinin genç erişkinlikte çatlamasıyla reaktive olur.",
                    "Parazit serbest taşi-zoit formuna geçerek nörosensoriyel retinada fokal nekroz ve yoğun yangı başlatır.",
                    "Nekroz esas olarak retinadadır; koroid ve RPE yangıya ikincil olarak (koryoretinit) katılır."
                ],
                "footer": "Bradizoit Kisti -> Taşizoit Patlaması -> Fokal Nekroz"
            },
            {
                "card_title": "2. 'Sis İçinde Far' (Headlight in the Fog)",
                "lead": "Patognomonik Oftalmoskopik Manzara",
                "items": [
                    "Eski, pigmente, atrofik koryoretinal skar kenarında taze, kabarık, sarımsı-beyaz nekrotik lezyon açılır [s.206].",
                    "Lezyonun hemen üzerindeki vitreus kompartımanında yoğun fokal lökosit hücresi ve pus (vitrit) toplanır.",
                    "Biyomikroskopta alttaki parlak beyaz lezyon, üzerindeki yoğun sisli vitrit bulutunun arkasından parlar.",
                    "Bu karakteristik görünüme literatürde 'Sis İçinde Araba Farı' (Headlight in the Fog) denir."
                ],
                "footer": "Eski Skar Sınırında Taze Nekroz + Fokal Vitrit"
            },
            {
                "card_title": "3. Görmeyi Tehdit Eden Durumlar",
                "lead": "Acil Tedavi Endikasyonları",
                "items": [
                    "Periferik küçük lezyonlar immün yetkin bireylerde 6-8 haftada kendi kendine sınırlanabilir [s.206].",
                    "ANCAK lezyon foveaya veya optik diske (Jensen nöroretiniti) 1-2 DD komşulukta ise acil tedavi şarttır.",
                    "Görme keskinliğini düşüren şiddetli vitrit, büyük lezyon (>2-3 DD) veya immünsüprese konak tedavi gerektirir.",
                    "Hamilelikte kazanılan akut primer enfeksiyon fetüs için yıkıcıdır; acil spiramisin gerekir."
                ],
                "footer": "Makula/Disk Tutulumu -> Mutlak Acil Tedavi"
            }
        ]
    )

    # Slayt 7.1.2.2: Toksoplazmozis Klasik Tedavi Protokolü
    builder.add_study_card_slide(
        title="OKÜLER TOKSOPLAZMOZİS TEDAVİ STANDARTLARI",
        category="BÖLÜM 7.1.2: ANTİPARAZİTER TEDAVİ",
        subtitle="Klasik Dörtlü Rejim, TMP-SMX Alternatifi ve Kortikosteroid Güvenlik Kuralları",
        cards=[
            {
                "card_title": "1. Klasik Dörtlü Tedavi Rejimi",
                "lead": "Tarihsel Altın Standart Protokol",
                "items": [
                    "1. Pirimetamin: 100 mg ilk gün yükleme, sonra 25-50 mg/gün [s.206].",
                    "2. Sülfadiazin: 2 gram yükleme, sonra 1 gram günde 4 kez (toplam 4 g/gün).",
                    "3. Folinik Asit (Lökovorin): 5-15 mg/gün (kemik iliği aplazisini ve trombositopeniyi önlemek için ZORUNLU).",
                    "4. Oral Prednizon: 0.5-1.0 mg/kg/gün (antiparaziterin 48. saatinden sonra başlanır).",
                    "Tedavi süresi tipik olarak 4 ila 6 haftadır; haftalık tam kan sayımı takibi şarttır."
                ],
                "footer": "Pirimetamin + Sülfadiazin + Folinik Asit + Steroid"
            },
            {
                "card_title": "2. Modern Pratik Rejim: TMP-SMX",
                "lead": "Eşit Etkinlikte, Çok Daha Güvenli ve Kolay",
                "items": [
                    "Trimetoprim-Sülfametoksazol (TMP-SMX 160/800 mg - Çift Doz): Günde 2 kez oral tablet [s.207].",
                    "Çok merkezli çalışmalarda klasik dörtlü rejim kadar etkin bulunmuş ve yan etki profili çok daha düşük çıkmıştır.",
                    "Birlikte Oral Prednizon (antiparaziter başladıktan 48 saat sonra) eklenir.",
                    "Sık nüks eden olgularda uzun süreli profilaksi için günde 1 tablet TMP-SMX nüks oranını %80 azaltır."
                ],
                "footer": "TMP-SMX (160/800 mg) 2x1 + Oral Steroid"
            },
            {
                "card_title": "3. MUTLAK KURAL: Tek Başına Steroid Yasağı",
                "lead": "Gözü Kör Eden En Ağır Medikal Hata",
                "items": [
                    "Antiparaziter örtü olmaksızın hastaya tek başına sistemik veya lokal kortikosteroid verilmesi YASAKTIR [s.207].",
                    "Steroid parazitin kontrolsüz çoğalmasını tetikleyerek dev nekroz alanlarına ve körlüğe yol açar.",
                    "Özellikle perioküler/subtenon steroid enjeksiyonu toksoplazmozda KESİNLİKLE KONTRENDİKEDİR.",
                    "Perioküler steroid yapılmışsa depoyu cerrahi olarak temizlemek dahi gerekebilir."
                ],
                "footer": "⚠️ TEK BAŞINA STEROİD / PERİOKÜLER İĞNE YASAKTIR"
            }
        ]
    )

    # Slayt 7.1.2.3: Oküler Toksokariyazis: Granülom Tipleri ve Traksiyon
    builder.add_study_card_slide(
        title="OKÜLER TOKSOKARİYAZİS: GRANÜLOM TİPLERİ VE TRAKSİYON",
        category="BÖLÜM 7.1.2: TOKSOKARİYA",
        subtitle="Toxocara canis Larvası, Eozinofilik Granülom, Falciform Katlantı ve Endoftalmi Taklidi",
        cards=[
            {
                "card_title": "1. Paraziter Bulaş ve Çocukluk Çağı",
                "lead": "Köpek Dışkısıyla Kirlenmiş Toprak Teması",
                "items": [
                    "Genellikle 2-10 yaş arası çocuklarda enfekte köpek dışkısındaki Toxocara canis yumurtalarının yutulmasıyla oluşur [s.207].",
                    "Bağırsakta çatlayan larva kan yoluyla göze göç eder ve retinaya yerleşir.",
                    "Larva canlıyken minimal inflamasyon yapar; larva öldüğünde ise masif granülomatöz reaksiyon patlar.",
                    "Hemen daima tektir (unilateraldir); çocukta lökokori (beyaz pupil) veya şaşılıkla fark edilir."
                ],
                "footer": "Toxocara canis / Tek Taraflı Lökokori / Çocuklar"
            },
            {
                "card_title": "2. Üç Temel Klinik Form",
                "lead": "Lokalizasyona Göre Fenotipler",
                "items": [
                    "1. Posterior Kutup Granülomu: Fovea veya optik diskte 1-2 DD boyutunda beyaz-sarı kabarıklık [s.207].",
                    "2. Periferik Retinal Granülom: Ora serratada beyaz kitle; kitleden optik diske uzanan kalın yoğun traksiyonel bant.",
                    "Bu bant makulayı kendine doğru çekerek 'falciform retinal katlantı' ve heterotopi oluşturur.",
                    "3. Kronik Endoftalmi Taklidi: Ağır vitrit ve ön üveit ile retinoblastomla karışan psödo-endoftalmi."
                ],
                "footer": "Posterior Granülom / Periferik Bant / Kronik Endoftalmi"
            },
            {
                "card_title": "3. Tedavi ve Cerrahi Strateji",
                "lead": "Antihelmintik vs Kortikosteroid",
                "items": [
                    "Canlı larva nadiren görülür; primer hasar immün yanıt kaynaklıdır [s.208].",
                    "Aktif inflamasyonda: Sistemik kortikosteroidler (Prednizolon 1 mg/kg) tedavinin temelidir.",
                    "Albendazol (400 mg 2x/gün, 2-4 hafta) aktif paraziti eradike etmek için steroidle kombine edilir.",
                    "Cerrahi: Makulayı çeken kalın vitreoretinal traksiyonel bantlar ve dekolman varlığında 25G Vitrektomi yapılır."
                ],
                "footer": "Oral Steroid + Albendazol / Traksiyonda PPV"
            }
        ]
    )

    # Slayt 7.1.2.4: Oküler Sifiliz: 'Büyük Taklitçi' ve Serolojik Protokol
    builder.add_study_card_slide(
        title="OKÜLER SİFİLİZ (FRENGİ): 'BÜYÜK TAKLİTÇİ'",
        category="BÖLÜM 7.1.2: SİFİLİZ",
        subtitle="Treponema pallidum Enfeksiyonu, Plakoid Koryoretinit ve Nörosifiliz Protokolü",
        cards=[
            {
                "card_title": "1. Neden 'Büyük Taklitçi'?",
                "lead": "Gözün Her Dokusunu ve Her Hastalığı Taklit Eder",
                "items": [
                    "Oküler sifiliz sekonder veya tersiyer evrede ortaya çıkar; her türlü üveit tablosunu taklit edebilir [s.208].",
                    "İnterstisyel keratit, iris roseolaları, retinal vaskülit, vitrit, nöroretinit veya panüveit yapabilir.",
                    "Posterior Plakoid Koryoretinit: Makulada sarı-gri düzensiz plakoid lezyonlar (APMPPE benzeri).",
                    "Bu nedenle etiyolojisi belirsiz her üveit olgusunda sifiliz testleri ZORUNLU olarak taranmalıdır."
                ],
                "footer": "Her Üveitte Sifiliz Taranmalıdır / Plakoid Retinit"
            },
            {
                "card_title": "2. Serolojik Tanı Algoritması",
                "lead": "Non-Treponemal vs Treponemal Testler",
                "items": [
                    "Non-Treponemal (VDRL / RPR): Hastalık aktivitesini ve tedaviye yanıtı izler; erken/geç evrede yalancı negatif olabilir [s.208].",
                    "Treponemal (FTA-ABS / TPHA / TP-PA): Ömür boyu pozitif kalır; kesin enfeksiyon kanıtıdır.",
                    "Modern Tarama: Önce treponemal test (EIA/CIA) yapılır; pozitifse VDRL titresi ile aktivite doğrulanır.",
                    "Oküler tutulum varsa hasta 'NÖROSİFİLİZ' kabul edilir; BOS incelemesi (bel ponksiyonu) şarttır."
                ],
                "footer": "FTA-ABS (Ömür Boyu +) / VDRL (Aktivite) / BOS Ponksiyonu"
            },
            {
                "card_title": "3. Tedavi Protokolü: Nörosifiliz Rejimi",
                "lead": "Standart Penisilin G Rejimi",
                "items": [
                    "Göz tutulumu santral sinir sistemi tutulumu ile eşdeğerdir; basit kas içi enjeksiyon YETERSİZDİR [s.209].",
                    "İntravenöz Kristalize Penisilin G: Günde 18-24 milyon ünite (her 4 saatte bir 3-4 milyon ünite İV) 10-14 gün verilir.",
                    "Alternatif (Penisilin alerjisinde): İntravenöz Seftriakson (2 g/gün) veya oral Doksisiklin (200 mg 2x).",
                    "Tedavi başlangıcında Jarisch-Herxheimer reaksiyonunu (masif endotoksin fırtınası) önlemek için dikkatli olunmalıdır."
                ],
                "footer": "İV Kristalize Penisilin G (18-24 MÜ/gün, 14 Gün)"
            }
        ]
    )

    # Slayt 7.1.2.5: Oküler Tüberküloz: Serpinöz Benzeri Koroidit ve Vaskülit
    builder.add_study_card_slide(
        title="OKÜLER TÜBERKÜLOZ: SERPİNÖZ BENZERİ KOROİDİT VE VASKÜLİT",
        category="BÖLÜM 7.1.2: TÜBERKÜLOZ",
        subtitle="Mycobacterium tuberculosis İmmün Hasarı, Hipersensitivite ve 4'lü Antitüberküloz Tedavi",
        cards=[
            {
                "card_title": "1. Patogenez ve Klinik Spektrum",
                "lead": "Canlı Basil İstilası vs Gecikmiş Hipersensitivite",
                "items": [
                    "Çoğu hastada aktif akciğer tüberkülozu bulunmaz; tablo eski basillere karşı immün hipersensitivitedir [s.209].",
                    "Tüberküloz Serpinöz Benzeri Koroidit (SLC): Klasik serpinözden farklı olarak multifokal başlar ve vitrit içerir.",
                    "Eales Hastalığı Benzeri Retinal Vaskülit: Ağır oklüzif periflebit, periferik neovaskülarizasyon ve tekrarlayan vitreus hemorajileri.",
                    "Koroid Tüberkülü: Milier TB olgularında sarı-gri kabarık soliter koroidal kitleler."
                ],
                "footer": "Serpinöz Benzeri Koroidit / Oklüzif Vaskülit / Vitrit (+)"
            },
            {
                "card_title": "2. Tanısal Kriterler ve Testler",
                "lead": "PPD, IGRA ve Akciğer BT",
                "items": [
                    "Tüberkülin Cilt Testi (PPD): Türkiye gibi BCG aşılı toplumlarda >15 mm indürasyon anlamlı kabul edilir [s.209].",
                    "IGRA (Quantiferon-TB Gold): Aşıdan etkilenmeyen M. tuberculosis antijenlerine karşı interferon-gama ölçer.",
                    "Yüksek Çözünürlüklü Akciğer BT (Toraks BT): Ghon odağı veya kalsifiye hiler lenfadenopati taranır.",
                    "Pozitif test + uyumlu koryoretinit varlığında olası oküler tüberküloz kabul edilir."
                ],
                "footer": "PPD (>15 mm) / Quantiferon-TB / Toraks BT"
            },
            {
                "card_title": "3. Dörtlü Antitüberküloz Tedavi Protokolü",
                "lead": "HRZE Rejimi ve Steroid Desteği",
                "items": [
                    "Standart 4'lü Rejim: İzoniyazid (H) + Rifampisin (R) + Pirazinamid (Z) + Etambutol (E) ilk 2 ay [s.210].",
                    "Ardından İzoniyazid + Rifampisin ile 7-10 ay idameye devam edilir (toplam 9-12 ay).",
                    "Eşzamanlı Sistemik Steroid: İmmün reaksiyonu durdurmak için 1 mg/kg oral prednizon 2. haftada eklenir.",
                    "Uyarı: Etambutol doza bağımlı toksik optik nöropati yapabileceğinden aylık görme ve renkli görme takibi şarttır."
                ],
                "footer": "2 Ay HRZE + 7 Ay HR / Etambutol Optik Nöropati Takibi"
            }
        ]
    )

    # Slayt 7.1.2.6: Enfeksiyöz Retinitler Ayırıcı Tanı Atlası
    builder.add_study_card_slide(
        title="ENFEKSİYÖZ RETİNİTLERİN KARŞILAŞTIRMALI ÖZETİ",
        category="BÖLÜM 7.1.2: SENTEZ",
        subtitle="Toksoplazmoz vs Toksokariyazis vs Sifiliz vs Tüberküloz Ayırıcı Bulguları",
        cards=[
            {
                "card_title": "1. Toksoplazmoz",
                "lead": "Toxoplasma gondii",
                "items": [
                    "Klinik: Eski pigmente skar komşuluğunda taze sarı-beyaz nekroz + yoğun vitrit [s.206].",
                    "Tipik İşaret: 'Sis içinde far' manzarası; Jensen nöroretiniti.",
                    "Tedavi: TMP-SMX veya Pirimetamin/Sülfadiazin + Folinik Asit + Oral Steroid.",
                    "Tuzak: Tek başına steroid veya perioküler enjeksiyon KONTRENDİKEDİR."
                ],
                "footer": "Sis İçinde Far / Skar Komşuluğu"
            },
            {
                "card_title": "2. Toksokariyazis & Sifiliz",
                "lead": "Larva & Treponema",
                "items": [
                    "Toksokariya: Çocukta tek taraflı granülom, optik diske uzanan kalın traksiyonel bant [s.207].",
                    "Sifiliz: 'Büyük taklitçi', plakoid koryoretinit, nöroretinit veya panüveit.",
                    "Sifiliz Tanı: FTA-ABS pozitifliği; BOS tutulumu varsa nörosifiliz kabul edilir.",
                    "Sifiliz Tedavi: İV Kristalize Penisilin G (18-24 MÜ/gün, 14 gün)."
                ],
                "footer": "Toksokariya (Bant) / Sifiliz (Penisilin)"
            },
            {
                "card_title": "3. Tüberküloz",
                "lead": "Mycobacterium tuberculosis",
                "items": [
                    "Klinik: Serpinöz benzeri multifokal koroidit ve oklüzif periflebit [s.209].",
                    "Sistemik İpucu: Quantiferon-TB (+), PPD >15 mm, kalsifiye hiler lenf nodu.",
                    "Tedavi: 4'lü Antitüberküloz (HRZE) 2 ay + HR 7 ay + Oral Steroid desteği.",
                    "Tuzak: TB dışlanmadan tek başına immünsüpresif vermek miliyer yayılım riski doğurur."
                ],
                "footer": "Serpinöz Benzeri / HRZE Rejimi"
            }
        ]
    )

    # Slayt 7.1.2.7: Enfeksiyöz Posterior Üveit Karar Ağacı
    builder.add_decision_tree_slide(
        title="ENFEKSİYÖZ POSTERİOR ÜVEİT VE RETİNİT KARAR AĞACI",
        category="BÖLÜM 7.1.2: KARAR AĞACI",
        subtitle="Retinal Nekroz veya Koryoretinal Yangı İle Başvuran Hastada Adım Adım Protokol",
        root_label="HASTADA POSTERİOR ÜVEİT / RETİNAL İNFİLTRAT ODAĞI SAPTANDI",
        branches=[
            {
                "label": "1. Eski Skar Yanında Taze Kabarık Lezyon",
                "criteria": "Sis içinde far manzarası, tek taraflı fokal vitrit, IgM/IgG pozitifliği [s.206].",
                "action": "Oküler Toksoplazmoz: TMP-SMX (160/800 mg 2x1) başlanır; 48 saat sonra oral steroid eklenir."
            },
            {
                "label": "2. Bilateral Plakoid / Vaskülitik Tutulum",
                "criteria": "Etiyoloji belirsiz; treponema paneli ve tüberküloz taraması pozitif [s.208].",
                "action": "Spesifik Tedavi: Sifiliz ise İV Kristalize Penisilin G (14 gün); TB ise 4'lü HRZE rejimi uygulanır."
            },
            {
                "label": "3. Periferik Hızla Yayılan Çevresel Nekroz",
                "criteria": "Şiddetli vitrit, oklüzif arterit veya PORN tarzı yangısız derin nekroz [s.202].",
                "action": "Viral Retinit (ARN/PORN): Vakit kaybetmeksizin İV Asiklovir/Gansiklovir başlanır; PCR alınır."
            }
        ],
        bottom_rule="Enfeksiyöz şüphe olan bir gözde etiyoloji kanıtlanmadan ve antimikrobiyal kalkan kurulmadan yüksek doz steroid başlamak gözün kaybıyla sonuçlanır [s.207]."
    )

    # Slayt 7.1.2.8: Aktif Hatırlama & Board Sınavı Vakası: Toksoplazmoz ve Steroid Tuzağı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: TOKSOPLAZMOZ",
        category="BÖLÜM 7.1.2: AKTİF HATIRLAMA",
        subtitle="24 Yaşında Kadın Hastada Eski Skar Kenarında 'Sis İçinde Far' ve Makula Tehdidi",
        vignette="24 yaşında kadın anaokulu öğretmeni, sol gözünde 3 gündür uçuşan siyah noktalar, görmede belirgin sislenme ve bulanıklık şikayetiyle başvuruyor. Görme keskinliği sağda 1.0 tam, solda 0.3 düzeyine inmiş. Ön segmentte hafif konjonktival kızarıklık ve ön kamarada 1+ hücre izleniyor. Arka segment muayenesinde foveanın 1 disk çapı superiorunda eski, atrofik, sınırları yoğun pigmente 1 DD boyutunda koryoretinal skar izleniyor. Bu eski skarın hemen alt kenarına bitişik 1.5 DD çapında kabarık, krem-beyaz renkli taze nekrotik infiltrat ve lezyonun hemen üzerinde 3+ yoğun vitreus hücresi ('sis içinde far' manzarası) saptanıyor. Taze lezyon fovea avasküler zon sınırına 500 μm mesafededir.",
        differentials=[
            "Reaktif Oküler Toksoplazmozis (Eski skar kenarında taze nekroz, 'sis içinde far' ve genç yaş).",
            "Akut Retinal Nekroz (Genellikle periferden başlar, eski pigmentli skar içermez, çok daha hızlı yayılır).",
            "Sitomegalovirüs Retiniti (İmmün yetmezlikte görülür, kanama çok yoğundur, vitrit hafiftir).",
            "Sarkoidoz Koroid Granülomu (Eski pigmentli skar kenarında taze satelit lezyon yapmaz)."
        ],
        decision="1. Klinik Tanı: Foveayı tehdit eden Reaktif Oküler Toksoplazmozis.\n2. Tedavi Protokolü: Lezyon foveaya çok yakın olduğu için agresif tedavi şarttır. Trimetoprim-Sülfametoksazol (160/800 mg günde 2 kez) başlanmalıdır.\n3. Kortikosteroid: Antimikrobiyal tedavinin 48. saatinde foveal ödemi ve vitriti yatıştırmak için Oral Prednizolon (1 mg/kg/gün) eklenmelidir.\n4. Takip: 10 gün sonra vitrit açıldığında fovea korunmuşsa steroid kademeli azaltılır; TMP-SMX en az 6 hafta sürdürülür.",
        board_trap="Fovea komşuluğundaki ödemi görüp 'hızlıca ödemi çözelim' diye hastaya tek başına oral veya subtenon steroid yapmak paraziti patlatır ve foveanın tamamen nekroze olmasına yol açar [s.207]."
    )

    # =========================================================================
    # 7.2.1: BEHÇET HASTALIĞI VE RETİNAL VASKÜLİT YÖNETİMİ (7 Slayt)
    # =========================================================================

    # Slayt 7.2.1.1: Behçet Hastalığı Oküler Patogenezi
    builder.add_study_card_slide(
        title="BEHÇET HASTALIĞINDA OKÜLER PATOGENEZ",
        category="BÖLÜM 7.2.1: BEHÇET HASTALIĞI",
        subtitle="HLA-B51 İlişkisi, Nötrofil Hiperaktivitesi ve Tekrarlayan Nekrotizan Oklüzif Vaskülit",
        cards=[
            {
                "card_title": "1. İmmünogenetik Altyapı: HLA-B51",
                "lead": "Tarihi İpek Yolu Hastalığı",
                "items": [
                    "Akdeniz, Orta Doğu ve Uzak Doğu popülasyonlarında yoğunlaşan multisistemik vaskülittir [s.210].",
                    "HLA-B*51 alleli ile çok güçlü genetik birliktelik gösterir (göreceli risk 6 kata kadar artar).",
                    "Genç erkeklerde (20-40 yaş) oküler tutulum kadınlara göre belirgin olarak daha agresif ve kör edicidir.",
                    "Temel mekanizma: Nötrofillerin aşırı kemotaksisi ve endotelyal apoptozla giden T-hücre aracılı vaskülittir."
                ],
                "footer": "İpek Yolu / HLA-B51 / Genç Erkeklerde Agresif"
            },
            {
                "card_title": "2. Tekrarlayan İnflamatuar Ataklar",
                "lead": "Non-Granülomatöz Panüveit Atağı",
                "items": [
                    "Karakteristik özellik: Gözde aniden başlayan, şiddetli, ancak kendiliğinden yatışıp aylar sonra tekrarlayan ataklardır [s.210].",
                    "Ön Kamara Bulgusu: Soğuk, pürülan olmayan, pozisyonla kolayca yer değiştiren 'mobil hipopiyon'.",
                    "Arka Segment Bulgusu: Retinal damarlar boyunca beyaz kılıflanma, retinal kanamalar ve fokal nekrozlar.",
                    "Her atak retinada geri dönüşsüz iskemik hasar, damar tıkanıklığı ve optik atrofi biriktirir."
                ],
                "footer": "Mobil Hipopiyon / Kümülatif İskemik Hasar"
            },
            {
                "card_title": "3. Oklüzif Retinal Vaskülit",
                "lead": "Arteriyel ve Venöz Tıkanıklık Birlikteliği",
                "items": [
                    "Behçet vasküliti hem arterleri hem venleri tutan (arterit ve periflebit) nekrotizan bir oklüzyondur [s.211].",
                    "Kapiller yatak trombozlarla tıkanır; geniş avasküler retina sahaları ve retinal iskemi gelişir.",
                    "İskemiye ikincil olarak optik disk ve retina neovaskülarizasyonları, tekrarlayan vitreus kanamaları oluşur.",
                    "Tedavisiz bırakılan olguların %75'i 3-5 yıl içinde kalıcı görme kaybına uğrar."
                ],
                "footer": "Nekrotizan Oklüzyon / Avasküler İskemi / Neovaskülarizasyon"
            }
        ]
    )

    # Slayt 7.2.1.2: Retinal Vaskülit Morfolojisi ve FFA Eğrelti Otu Belirtisi
    builder.add_study_card_slide(
        title="BEHÇET VASKÜLİTİNDE KLİNİK VE FFA İMZASI",
        category="BÖLÜM 7.2.1: GÖRÜNTÜLEME",
        subtitle="Otofloresan Sızıntı, 'Eğrelti Otu' (Fern-like) Kaçağı ve İskemik Alan Taraması",
        cards=[
            {
                "card_title": "1. Fundus Muayene Bulguları",
                "lead": "Akut Atakta Görülen Patolojiler",
                "items": [
                    "Retinal damarlar boyunca pamuk atığı benzeri beyaz inflamatuar infiltratlar ve kılıflanma [s.211].",
                    "Retina içi alev ve nokta kanamalar, optik disk hiperemisi ve diffüz vitreus bulanıklığı (vitrit).",
                    "Yüzeyel nekrotik odaklar (retinit benzeri) birkaç gün içinde skar bırakmadan silinebilir.",
                    "Ataklar tekrarladıkça retinal damarlar beyaz, kansız fibröz şeritler ('hayalet damarlar') halini alır."
                ],
                "footer": "Beyaz Kılıflanma / Hayalet Damarlar / Vitrit"
            },
            {
                "card_title": "2. FFA'da 'Eğrelti Otu' (Fern-like) Kaçağı",
                "lead": "Kapiller Geçirgenliğin İflası",
                "items": [
                    "Floresein anjiyografisinde erken fazda kapiller non-perfüzyon ve oklüzyon sahaları izlenir [s.211].",
                    "Geç fazda ise damar duvarlarından dışarı sızan yoğun floresein dallanmış eğrelti otu yaprağı manzarası verir.",
                    "Bu diffüz vasküler kaçak deseni aktif retinal vaskülitin en duyarlı göstergesidir.",
                    "Optik diskte yoğun boyanma ve makulada kistik floresans birikimi (KME) eşlik eder."
                ],
                "footer": "Eğrelti Otu Deseni / Non-Perfüzyon / Disk Boyanması"
            },
            {
                "card_title": "3. Remisyonda Sessiz Vaskülit Tespiti",
                "lead": "Göz Dibi Sakinken Devam Eden Yangı",
                "items": [
                    "Biyomikroskopta göz tamamen sakin görünse bile geniş açılı FFA'da periferik vasküler sızıntı sürebilir [s.212].",
                    "Bu 'subklinik vaskülit' tedavi dozunun yetersiz olduğunu ve yeni atağın kapıda olduğunu gösterir.",
                    "Tedavi kararı yalnızca muayeneye değil, FFA'daki sızıntının tam olarak durdurulmasına göre verilir.",
                    "Geniş açılı (Ultra-widefield) FFA bu nedenle Behçet takibinde vazgeçilmezdir."
                ],
                "footer": "Geniş Açılı FFA / Subklinik Sızıntı / Objektif Takip"
            }
        ]
    )

    # Slayt 7.2.1.3: Behçet Tedavisinde Biyolojik Devrim: Anti-TNF ve IFN-alfa
    builder.add_study_card_slide(
        title="BEHÇET VASKÜLİTİNDE BİYOLOJİK AJAN DEVRİMİ",
        category="BÖLÜM 7.2.1: TEDAVİ",
        subtitle="İnfliksimab, Adalimumab ve İnterferon-alfa ile Görmenin Korunması ve Remisyon",
        cards=[
            {
                "card_title": "1. Anti-TNF Alfa Ajanları (İnfliksimab / Adalimumab)",
                "lead": "Atakları Anında Durduran Güçlü Silah",
                "items": [
                    "İnfliksimab (Kimerik monoklonal anti-TNF): 5 mg/kg İV infüzyon (0, 2, 6. haftalar ve her 6-8 haftada bir) [s.212].",
                    "Akut görmeyi tehdit eden ataklarda saatler/günler içinde inflamasyonu söndürür.",
                    "Adalimumab (Tam insan monoklonal anti-TNF): 40 mg 2 haftada bir subkutan enjeksiyon; uzun dönem idame için idealdir.",
                    "EULAR kılavuzunda görmeyi tehdit eden posterior Behçet tutulumunda ilk basamakta önerilmektedir."
                ],
                "footer": "İnfliksimab (İV Hızlı) / Adalimumab (Subkutan İdame)"
            },
            {
                "card_title": "2. İnterferon Alfa (IFN-alfa-2a)",
                "lead": "Uzun Süreli İlaçsız Remisyon Sağlayan Ajan",
                "items": [
                    "Doğal antiviral ve immünomodülatör sitokin: Haftada 3 kez 3-6 milyon ünite subkutan uygulanır [s.212].",
                    "İnflamasyonu baskılamada anti-TNF kadar etkindir; en büyük avantajı tedavi kesildikten sonra bile remisyonun sürmesidir.",
                    "Yan Etkileri: İlk enjeksiyonlarda grip benzeri sendrom (ateş, kas ağrısı), lökopeni ve depresyon eğilimi.",
                    "Anti-TNF'ye dirençli veya tolere edemeyen hastalarda mükemmel bir alternatiftir."
                ],
                "footer": "IFN-alfa-2a / İlaçsız Remisyon / Grip Benzeri Sendrom"
            },
            {
                "card_title": "3. Konvansiyonel İmmünsüpresifler",
                "lead": "Azatioprin ve Siklosporin A",
                "items": [
                    "Azatioprin (2-2.5 mg/kg/gün): Temel idame ajanıdır; yeni atakları ve diğer gözün tutulumunu önler [s.213].",
                    "Siklosporin A (3-5 mg/kg/gün): T-hücre kalsinörin inhibitörüdür; hızlı etkilidir ancak nefrotoksisite ve nöro-Behçet riski taşır.",
                    "ÖNEMLİ KURAL: Nöro-Behçet şüphesi veya bulgusu olan hastada Siklosporin KESİNLİKLE KULLANILMAZ (nörotoksisiteyi tetikler).",
                    "Akut atakta yüksek doz İV pulse metilprednizolon (1 g/gün, 3 gün) immünsüpresif kalkanı altında verilir."
                ],
                "footer": "Azatioprin / Nöro-Behçet'te Siklosporin YASAKTIR"
            }
        ]
    )

    # Slayt 7.2.1.4: Behçet vs Sarkoidoz Retinal Vasküliti Karşılaştırması
    builder.add_split_comparison_slide(
        title="VASKÜLİT AYIRICI TANISI: BEHÇET vs SARKOİDOZ",
        category="BÖLÜM 7.2.1: KARŞILAŞTIRMA",
        subtitle="Nekrotizan Oklüzif Vaskülit (Behçet) vs Granülomatöz Periflebit (Sarkoidoz)",
        left_entity={
            "name": "BEHÇET HASTALIĞI VASKÜLİTİ",
            "subtitle": "Akut Nekrotizan Arterit ve Venit — Oklüzif",
            "bullets": [
                "Üveit Tipi: Non-granülomatöz panüveit; geçici mobil hipopiyon [s.210].",
                "Damar Tutulumu: Hem arterleri hem venleri tutar; ŞİDDETLİ OKLÜZİFTİR.",
                "FFA Görünümü: Eğrelti otu (fern-like) yaygın kaçak ve geniş avasküler kapiller kayıp.",
                "Eşlik Eden Bulgular: Ağrılı oral aftlar, genital ülserler, eritema nodozum, paterji (+).",
                "Komplikasyon: Hızlı optik atrofi, neovaskülarizasyon ve tekrarlayan vitreus hemorajisi.",
                "İlk Tedavi: Anti-TNF (İnfliksimab/Adalimumab) veya IFN-alfa + Azatioprin [s.212]."
            ]
        },
        right_entity={
            "name": "SARKOİDOZ VASKÜLİTİ",
            "subtitle": "Kronik Granülomatöz Periflebit — Non-Oklüzif",
            "bullets": [
                "Üveit Tipi: Granülomatöz panüveit; koyun yağı keratik presipitatlar ve iris nodülleri [s.214].",
                "Damar Tutulumu: Seçici olarak VENLERİ tutar (Periflebit); oklüzyon çok daha nadirdir.",
                "FFA Görünümü: Ven duvarlarında segmental granülomlar; 'Mum Damlası' (Candle-wax drippings).",
                "Eşlik Eden Bulgular: Bilateral hiler lenfadenopati, yüksek ACE ve kalsiyum düzeyi.",
                "Komplikasyon: Kistik makula ödemi, koroid granülomları ve sekonder glokom.",
                "İlk Tedavi: Sistemik Kortikosteroidler ve Metotreksat [s.214]."
            ]
        },
        bottom_takeaway="Behçet hem arteri hem veni tıkar ve gözü iskemiden kör eder; Sarkoidoz ise seçici olarak ven etrafında nodüler granülom (mum damlası) yapar ve iskemi nadirdir [s.211]."
    )

    # Slayt 7.2.1.5: Retinal Vaskülitte İskemi, Neovaskülarizasyon ve Lazer
    builder.add_study_card_slide(
        title="BEHÇET VASKÜLİTİNDE GEÇ DÖNEM CERRAHİ YÖNETİM",
        category="BÖLÜM 7.2.1: CERRAHİ",
        subtitle="Avasküler İskemik Alanlar, Neovaskülarizasyon, Sektörel Lazer ve Vitrektomi",
        cards=[
            {
                "card_title": "1. İskemik Sektörler ve VEGF Salınımı",
                "lead": "Tıkanmış Kapillerlerin Neovasküler Bedeli",
                "items": [
                    "Tekrarlayan vaskülit atakları periferik kapiller ağı tıkayarak geniş non-perfüzyon alanları bırakır [s.213].",
                    "Hipoksik retina aşırı miktarda VEGF sentezleyerek optik diskte (NVD) veya retinada (NVE) yeni damarlar üretir.",
                    "Bu neovaskülarizasyonlar son derece kırılgandır ve kendiliğinden masif vitreus kanaması yapar.",
                    "FFA çekilerek tüm iskemik avasküler kadranlar net olarak haritalanmalıdır."
                ],
                "footer": "Kapiller Tıkanma -> İskemi -> NVD / NVE Gelişimi"
            },
            {
                "card_title": "2. Sektörel / Panretinal Fotokoagülasyon",
                "lead": "İskemik Sahanın Lazerle İtlaf Edilmesi",
                "items": [
                    "Aktif vaskülit medikal tedaviyle sakinleştirildikten sonra tüm avasküler sahalara lazer uygulanır [s.213].",
                    "Geniş açılı anjiyografi kılavuzluğunda perfüze olmayan alanlara sektörel argon lazer fotokoagülasyon atılır.",
                    "Lazer hipoksik dokuyu yok ederek VEGF üretimini durdurur ve neovaskülarizasyonların gerilemesini sağlar.",
                    "Uyarı: Lazer aktif yangı atağı sürerken değil, yangı baskılandıktan sonra atılmalıdır."
                ],
                "footer": "Avasküler Sahaya Sektörel Lazer / VEGF Supresyonu"
            },
            {
                "card_title": "3. Cerrahi: Pars Plana Vitrektomi (PPV)",
                "lead": "Vitreus Kanaması ve Traksiyonel Dekolman",
                "items": [
                    "1 aydan uzun süre açılmayan non-clearing vitreus kanamalarında 25G PPV endikedir [s.213].",
                    "Cerrahide arka hyaloid temizlenir, neovasküler fibrotik membranlar soyulur ve 360° endolazer tamamlanır.",
                    "ÖNEMLİ KURAL: Ameliyat öncesi ve sonrası dönemde yüksek doz steroid/biyolojik ajan verilmelidir.",
                    "Aksi takdirde cerrahi travma gözde yıkıcı bir 'rebound Behçet atağı' tetikleyebilir."
                ],
                "footer": "PPV + İmmünsüpresif Kalkan / Rebound Atağı Önleme"
            }
        ]
    )

    # Slayt 7.2.1.6: Behçet Retinal Vasküliti Tedavi Algoritması
    builder.add_decision_tree_slide(
        title="BEHÇET RETİNAL VASKÜLİTİ TEDAVİ PROTOKOLÜ",
        category="BÖLÜM 7.2.1: ALGORİTMA",
        subtitle="Atak Şiddetine ve FFA Bulgularına Göre Basamaklı Biyolojik Tedavi Karar Ağacı",
        root_label="BEHÇET HASTASINDA POSTERİOR SEGMENT / RETİNAL VASKÜLİT TUTULUMU",
        branches=[
            {
                "label": "1. Şiddetli Atak / Makula ve Disk Tehdidi",
                "criteria": "Görme aniden düşmüş, foveal vaskülit, optik nöropati veya masif sızıntı [s.212].",
                "action": "Acil Biyolojik: İV Pulse Metilprednizolon (1 g/gün, 3 gün) + Derhal İV İnfliksimab (5 mg/kg) veya Adalimumab."
            },
            {
                "label": "2. Standart Posterior Segment İdamesi",
                "criteria": "Orta derecede periferik vaskülit, atak kontrol altına alınmış, idame planlanıyor [s.213].",
                "action": "Kombine İmmünsüpresyon: Azatioprin (2.5 mg/kg/gün) + Düşük doz Oral Steroid; dirençte Anti-TNF'ye geçiş."
            },
            {
                "label": "3. Anti-TNF Direnci veya Nüks Eden Tablo",
                "criteria": "İnfliksimab/Adalimumab altında dahi vasküler sızıntı ve ataklar devam ediyor [s.212].",
                "action": "İnterferon-alfa: Subkutan IFN-alfa-2a (haftada 3 kez 3-6 MÜ) başlanır; uzun süreli ilaçsız remisyon hedeflenir."
            }
        ],
        bottom_rule="Behçet hastasında posterior segment tutulduğunda sadece steroid damla veya oral steroid vermek yetersizdir; körlüğü önlemek için ilk günden itibaren sistemik immünsüpresif veya biyolojik ajan şarttır [s.212]."
    )

    # Slayt 7.2.1.7: Aktif Hatırlama & Board Sınavı Vakası: 26 Yaş Erkekte Behçet Atağı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: BEHÇET PANÜVEİTİ",
        category="BÖLÜM 7.2.1: AKTİF HATIRLAMA",
        subtitle="26 Yaşında Erkekte Ani Görme Düşüşü, Hipopiyon ve FFA'da Eğrelti Otu Manzarası",
        vignette="26 yaşında erkek hasta, sol gözünde dünden beri şiddetli görme bulanıklığı, uçuşmalar ve kanlanma ile acile başvuruyor. Özgeçmişinde yılda 4-5 kez tekrarlayan ağrılı ağız içi yaralar (aft) ve bacaklarında kırmızı ağrılı yumrular (eritema nodozum) öyküsü mevcut. Sol görme keskinliği 0.1'e düşmüş. Biyomikroskopide ön kamarada 1.5 mm yüksekliğinde beyaz-sarı mobil hipopiyon, 3+ hücre izleniyor. Arka segment muayenesinde fovea çevresinde retinal damarlarda yaygın beyaz kılıflanma, intraretinal alev kanamalar ve 2+ vitrit izleniyor. FFA çekildiğinde damar duvarlarından dışarı sızan diffüz floreseinin tipik 'eğrelti otu' (fern-like) paterni oluşturduğu ve kapiller non-perfüzyon alanları saptanıyor.",
        differentials=[
            "Behçet Hastalığına Bağlı Akut Oklüzif Retinal Vaskülit ve Panüveit (Doğru klinik tanı).",
            "HLA-B27 İlişkili Ön Üveit (Hipopiyon yapabilir ancak arka segmentte eğrelti otu vasküliti ve oral aft görülmez).",
            "Enfeksiyöz Endoftalmi (Hipopiyon yapar ancak hastanın ameliyat/travma öyküsü yoktur).",
            "Oküler Sarkoidoz (Vaskülit oklüzif değildir, hipopiyon son derece nadirdir)."
        ],
        decision="1. Klinik Tanı: Behçet Hastalığı Akut Oklüzif Retinal Vaskülit Atağı.\n2. Acil Tedavi: Görmeyi tehdit eden bu tabloda hasta derhal yatırılmalı; 3 gün boyunca İntravenöz Pulse Metilprednizolon (1000 mg/gün) uygulanmalıdır.\n3. Biyolojik Tedavi: Eşzamanlı olarak İntravenöz İnfliksimab (5 mg/kg) infüzyonu veya subkutan Adalimumab başlanmalı, uzun süreli idame için Azatioprin (2.5 mg/kg/gün) eklenmelidir.\n4. Takip: İnflamasyon yatışınca non-perfüze sahalara sektörel lazer planlanmalıdır.",
        board_trap="Bu hastada 'sadece ön kamarada hipopiyon var' diyerek hastaya yalnızca steroidli göz damlası reçete edip göndermek arka kutuptaki retinal vaskülitin gözü birkaç günde kör etmesine neden olur; Behçet panüveiti sistemik biyolojik tedavi gerektirir [s.212]."
    )

    # =========================================================================
    # 7.2.2: VOGT-KOYANAGİ-HARADA (VKH) VE OKÜLER SARKOİDOZ (7 Slayt)
    # =========================================================================

    # Slayt 7.2.2.1: Vogt-Koyanagi-Harada (VKH) Sendromu: Melanosit Otoimmünitesi
    builder.add_study_card_slide(
        title="VOGT-KOYANAGİ-HARADA (VKH) SENDROMU PATOGENEZİ",
        category="BÖLÜM 7.2.2: VKH",
        subtitle="Melanosit Antijenlerine (Tirozinaz) Karşı T-Hücre Saldırısı ve Dört Klinik Evre",
        cards=[
            {
                "card_title": "1. İmmünogenetik Mekanizma",
                "lead": "Pigment Üreten Hücrelere Karşı Sitotoksik Saldırı",
                "items": [
                    "Melanosit içeren tüm dokuları (koroid, meninksler, iç kulak ve cilt) hedef alan otoimmün hastalıktır [s.213].",
                    "HLA-DR4 ve HLA-DRB1*0405 allelleri ile çok güçlü genetik birliktelik gösterir.",
                    "Melanosit spesifik proteinler (tirozinaz ile ilişkili proteinler TRP-1 ve TRP-2) antijenik hedeftir.",
                    "KRİTİK KURAL: Geçirilmiş cerrahi veya penetran göz travması öyküsü KESİNLİKLE OLMAMALIDIR (varsa Sempatik Oftalmidir!)."
                ],
                "footer": "Melanosit Hedefleme / HLA-DR4 / Travma Öyküsü Yoktur"
            },
            {
                "card_title": "2. Dört Klasik Klinik Evre",
                "lead": "Prodromdan Gün Batımı Fundusuna Seyir",
                "items": [
                    "1. Prodromal Evre: Baş ağrısı, ense sertliği, menenjizm, tinnitus (çınlama), dizakuzi ve saç diplerinde hassasiyet [s.214].",
                    "2. Akut Üveitik Evre: Bilateral ani görme kaybı, diffüz koroidit, hiperemik disk ve MULTİFOKAL SERÖZ RETİNA DEKOLMANLARI.",
                    "3. Konvalesan Evre: Haftalar/aylar sonra koroidal melanositlerin kaybıyla fundusun parlak turuncu-kırmızı 'Gün Batımı' (Sunset-glow) görünümü alması; vitiligo, poliozis (kirpik beyazlaşması), alopesi.",
                    "4. Kronik Nüks Evre: Anterior granülomatöz üveit atakları, iris nodülleri ve subretinal KNV gelişimi."
                ],
                "footer": "Prodrom -> Eksüdatif Dekolman -> Gün Batımı -> Kronik Nüks"
            },
            {
                "card_title": "3. Revize Uluslararası Tanı Kriterleri",
                "lead": "Tam (Complete) vs Eksik (Incomplete) VKH",
                "items": [
                    "Tam VKH: Bilateral oküler tutulum + Nörolojik/işitme bulguları + Dermatolojik bulgular (alopesi/poliozis) [s.214].",
                    "Eksik VKH: Bilateral oküler tutulum + Nörolojik VEYA dermatolojik bulguların en az birinin bulunması.",
                    "Olası VKH: Yalnızca tipik bilateral oküler tutulumun olması (ekstraoküler bulgular henüz çıkmamıştır).",
                    "Erken tanı akut evrede (konvalesan cilt bulguları çıkmadan önce) konulup tedavi edilmelidir."
                ],
                "footer": "Tam / Eksik / Olası Kriterleri"
            }
        ]
    )

    # Slayt 7.2.2.2: VKH Multimodal Görüntüleme İmzaları
    builder.add_study_card_slide(
        title="VKH MULTİMODAL GÖRÜNTÜLEME İMZALARI",
        category="BÖLÜM 7.2.2: GÖRÜNTÜLEME",
        subtitle="EDI-OKT Subretinal Septaları, FFA 'Yıldızlı Gökyüzü' ve ICG Koroidal Hipofloresansı",
        cards=[
            {
                "card_title": "1. EDI-OKT: Koroidal Kalınlaşma ve Sıvı Odacıkları",
                "lead": "Akut Evrede Devasa Koroid Ödemi",
                "items": [
                    "Enhanced Depth Imaging (EDI-OKT)'de koroid kalınlığı >800 μm'ye fırlar (aşırı diffüz kalınlaşma) [s.214].",
                    "Nörosensoriyel retinayı kabartan multilobüle subretinal sıvı ve intraretinal septalar (fibrinöz odacıklar) görülür.",
                    "RPE katmanında dalgalanma (undülasyon) ve fotoreseptör tabakasında katlantılar izlenir.",
                    "Başarılı steroid tedavisiyle koroid kalınlığı 48 saatte yarıya iner ve septalar tamamen kaybolur."
                ],
                "footer": "EDI-OKT >800 μm / Multilobüle Sıvı / Septalar"
            },
            {
                "card_title": "2. FFA: 'Yıldızlı Gökyüzü' (Starry Sky)",
                "lead": "Çok Odaklı İğne Başı Sızıntılar",
                "items": [
                    "FFA erken fazında RPE düzeyinde çok sayıda fokal iğne başı hiperfloresan sızıntı noktası (pinpoint leaks) belirir [s.214].",
                    "Geç fazda bu noktalar genişleyerek subretinal sıvı odacıklarını doldurur ve 'göllenme' (pooling) yapar.",
                    "Erken fazdaki yüzlerce parlak sızıntı noktası siyah zemin üzerinde 'Yıldızlı Gökyüzü' manzarası oluşturur.",
                    "Optik diskte yoğun hiperfloresan sızıntı ve boyanma eşlik eder."
                ],
                "footer": "Pinpoint Sızıntı -> Yıldızlı Gökyüzü -> Göllenme"
            },
            {
                "card_title": "3. İndosiyanin Yeşili Anjiyografisi (ICG)",
                "lead": "Koroidal İnflamasyonun Gerçek Haritası",
                "items": [
                    "ICG erken ve orta fazda koroid damarlarında gecikmiş dolum ve diffüz silikleşme izlenir [s.215].",
                    "Tüm arka kutup ve periferde yaygın, hipofloresan karanlık odaklar (HDDs) görülür.",
                    "Bu hipofloresan noktalar koroid stromasını işgal eden lenfositik granülomları temsil eder.",
                    "Tedavi yanıtı ICG'deki bu karanlık odakların kaybolmasıyla objektif olarak doğrulanır."
                ],
                "footer": "Hipofloresan Koroid Odakları (HDDs) / Stromal Granülom"
            }
        ]
    )

    # Slayt 7.2.2.3: Oküler Sarkoidoz: Non-Kazeifiye Granülomlar ve Mum Damlası
    builder.add_study_card_slide(
        title="OKÜLER SARKOİDOZ: GRANÜLOMATÖZ İNFLAMASYON",
        category="BÖLÜM 7.2.2: SARKOİDOZ",
        subtitle="Bilateral Hiler LAP, Mum Damlası (Candle-wax Drippings) Periflebiti ve Berlin Nodülleri",
        cards=[
            {
                "card_title": "1. İmmünopatoloji ve Sistemik Tablo",
                "lead": "Etyolojisi Bilinmeyen Non-Kazeifiye Granülomlar",
                "items": [
                    "Epiteloid histiyositler ve dev hücrelerden oluşan kazeifiye olmayan granülomatöz hastalıktır [s.214].",
                    "Hastaların %30-50'sinde oküler tutulum vardır; kadınlarda ve siyahi ırkta daha sıktır.",
                    "En sık akciğer parankimi ve mediastinal lenf bezleri tutulur (Toraks BT'de bilateral hiler LAP).",
                    "Serumda Anjiyotensin Dönüştürücü Enzim (ACE) ve Lysozyme düzeyleri belirgin yükselir."
                ],
                "footer": "Non-Kazeifiye Granülom / Bilateral Hiler LAP / Yüksek ACE"
            },
            {
                "card_title": "2. Oküler Bulgular ve İmzalar",
                "lead": "Ön Kamaradan Koroide Granülom İstilası",
                "items": [
                    "Ön Segment: Geniş koyun yağı (mutton-fat) keratik presipitatlar, iris yüzeyinde Busacca ve Koeppe nodülleri [s.214].",
                    "Açı İncelemesi: Trabeküler ağda granülomatöz nodüller ve tentür şeklinde PAS sineşileri (Berlin nodülleri).",
                    "Vitreus Bulgusu: Alt vitreusta dizilmiş parlak beyaz lökosit kümeleri ('kar topları' / snowballs ve 'inci kolye' / string of pearls).",
                    "Retinal Vaskülit: Retinal venler çevresinde mum damlamış gibi segmental eksüdalar ('Mum Damlası' / Candle-wax drippings)."
                ],
                "footer": "Koyun Yağı KP / Mum Damlası Periflebiti / İnci Kolyesi"
            },
            {
                "card_title": "3. Tedavi Prensipleri",
                "lead": "Kortikosteroid ve Metotreksat",
                "items": [
                    "Oküler sarkoidoz sistemik kortikosteroid tedavisine son derece hızlı yanıt verir [s.215].",
                    "Oral Prednizolon (0.5-1 mg/kg/gün) ile başlanır; inflamasyon baskılandıkça yavaşça azaltılır.",
                    "Kronik veya steroide bağımlı olgularda Metotreksat (15-25 mg/hafta) veya Azatioprin eklenir.",
                    "Dirençli kistik makula ödeminde intravitreal Deksametazon implantı (Ozurdex) çok etkilidir."
                ],
                "footer": "Oral Steroid + Metotreksat / Ozurdex İmplantı"
            }
        ]
    )

    # Slayt 7.2.2.4: VKH vs Sempatik Oftalmi Karşılaştırması
    builder.add_split_comparison_slide(
        title="GRANÜLOMATÖZ PANÜVEİT AYRIMI: VKH vs SEMPATİK OFTALMİ",
        category="BÖLÜM 7.2.2: KARŞILAŞTIRMA",
        subtitle="Otoimmün Melanosit Hasarı (VKH) vs Delici Travma/Cerrahi Sonrası Uveal Antijen Maruziyeti (SO)",
        left_entity={
            "name": "VOGT-KOYANAGİ-HARADA (VKH)",
            "subtitle": "Spontan Otoimmün Melanosit Tutulumu",
            "bullets": [
                "Travma / Cerrahi Öyküsü: KESİNLİKLE YOKTUR (Travma varsa VKH tanısı elenir) [s.213].",
                "Başlangıç: Her iki gözde eşzamanlı ve simetrik olarak başlar.",
                "Ekstraoküler Bulgular: Menenjizm, baş ağrısı, kranial nöropati, tinnitus ve alopesi/vitiligo sıktır.",
                "Eksüdatif Dekolman: Akut evrede devasa büllöz seröz dekolmanlar ve septalar kuraldır.",
                "Fundus Skarı: Konvalesan evrede yaygın parlak turuncu 'Gün Batımı' (Sunset-glow) fundusu [s.214]."
            ]
        },
        right_entity={
            "name": "SEMPATİK OFTALMİ (SO)",
            "subtitle": "Uveal Antijenlere Karşı Sekonder Otoimmünite",
            "bullets": [
                "Travma / Cerrahi Öyküsü: MUTLAK ŞARTTIR (Bir göze penetran travma veya intraoküler cerrahi olmuştur) [s.215].",
                "Zamanlama: Yaralanan göze (uyarıcı göz) müdahaleden haftalar veya aylar sonra SAĞLAM GÖZDE (sempatize göz) başlar.",
                "Histopatoloji: Koroidde diffüz non-nekrotizan granülomatöz infiltrasyon ve Dalen-Fuchs nodülleri.",
                "Ekstraoküler Bulgular: Nörolojik veya dermatolojik bulgular son derece nadirdir.",
                "Önleme Kuralı: Ağır yaralanmış kör göz ilk 14 gün içinde enüklee edilirse sempatik oftalmi engellenir [s.215]."
            ]
        },
        bottom_takeaway="VKH spontan meningo-üveittir, cerrahi öyküsü yoktur; Sempatik Oftalmi ise mutlaka bir delici travma veya cerrahiyi takip eder, ilk 14 günde enükleasyon hayat kurtarır [s.215]."
    )

    # Slayt 7.2.2.5: Granülomatöz Panüveit Tedavi Prensipleri
    builder.add_study_card_slide(
        title="VKH VE İLERİ ÜVEİTLERDE TEDAVİ STRATEJİSİ",
        category="BÖLÜM 7.2.2: TEDAVİ",
        subtitle="Erken Agresif Pulse Steroid, Yavaş Doz Azaltımı (Tapering) ve İmmünomodülatörler",
        cards=[
            {
                "card_title": "1. Akut Evrede İntravenöz Pulse Metilprednizolon",
                "lead": "İlk Saatlerde Koroidal Fırtınayı Söndürme",
                "items": [
                    "Akut VKH'de tanı konur konmaz İntravenöz Metilprednizolon (1000 mg/gün) 3 gün süreyle verilir [s.214].",
                    "Pulse tedavi koroidal ödemi hızla gerileterek subretinal sıvının RPE pompalarınca emilmesini sağlar.",
                    "Ardından oral Prednizolon'a (1 mg/kg/gün, yaklaşık 60-80 mg/gün) geçilir.",
                    "Tedaviye erken (ilk 2 hafta içinde) başlanması hastalığın kronik evreye ve gün batımı fundusuna geçişini önler."
                ],
                "footer": "İV Pulse 1 g/gün (3 Gün) -> Oral 1 mg/kg"
            },
            {
                "card_title": "2. Çok Yavaş Doz Azaltımı (Tapering)",
                "lead": "En Az 6 Ay Süren Kademeli Çıkış",
                "items": [
                    "VKH tedavisinde en sık yapılan hata steroidin 1-2 ay içinde hızla kesilmesidir [s.215].",
                    "Erken steroid kesimi olguların %70'inde nüksü ve kronik ön üveit/glokom tablosunu tetikler.",
                    "Doz her 2-3 haftada bir 5-10 mg azaltılarak en az 6-9 aya yayılmalıdır.",
                    "Sıvı çekilse dahi EDI-OKT'de koroid kalınlığı bazal seviyeye inene kadar tedaviye devam edilir."
                ],
                "footer": "6-9 Ay Tapering / Erken Kesimde %70 Nüks"
            },
            {
                "card_title": "3. Erken İmmünomodülatör Ajanlar (İMA)",
                "lead": "Kronikleşmeyi Önleyen Kombinasyon",
                "items": [
                    "Yüksek riskli veya steroide dirençli olgularda ilk haftalarda immünomodülatör eklenmelidir [s.215].",
                    "Siklosporin A (3-5 mg/kg/gün) veya Mikofenolat Mofetil (MMF 2 g/gün) T-hücre klonlarını baskılar.",
                    "Biyolojik Ajanlar: Dirençli VKH vakalarında Anti-TNF (İnfliksimab / Adalimumab) tam remisyon sağlar.",
                    "İMA desteği steroid ihtiyacını azaltarak sistemik Cushingoid yan etkileri sınırlar."
                ],
                "footer": "Siklosporin / Mikofenolat / Anti-TNF Desteği"
            }
        ]
    )

    # Slayt 7.2.2.6: Granülomatöz Üveit Tanı ve Tedavi Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="GRANÜLOMATÖZ PANÜVEİT VE VKH YÖNETİM AKIŞI",
        category="BÖLÜM 7.2.2: AKIŞ ŞEMASI",
        subtitle="Bilateral Seröz Dekolman veya Granülomatöz Yangıda Adım Adım Protokol",
        steps=[
            {
                "num": "1",
                "title": "Travma / Cerrahi Öyküsü Sorgulaması",
                "desc": "Delici yaralanma varsa Sempatik Oftalmi; spontan başlangıç ise VKH veya Sarkoidoz düşünülür [s.213].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "EDI-OKT ve FFA Görüntüleme",
                "desc": "EDI-OKT'de koroid >800 μm ve fibrinöz septalar; FFA'da 'yıldızlı gökyüzü' pinpoint kaçakları belgelenir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Acil İV Pulse Steroid İndüksiyonu",
                "desc": "İntravenöz Metilprednizolon (1000 mg/gün, 3 gün) uygulanarak subretinal sıvı hızla yatıştırılır [s.214].",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Oral İdame ve İmmünomodülatör",
                "desc": "Oral prednizolon en az 6 aya yayılarak yavaş azaltılır; nüksü önlemek için Mikofenolat/Siklosporin eklenir.",
                "status": "success"
            }
        ],
        bottom_takeaway="Akut VKH atağında cerrahi kesinlikle kontrendikedir; ilk 2 hafta içinde başlanan yüksek doz pulse steroid hastayı körlükten ve gün batımı fundusundan kurtarır [s.214]."
    )

    # Slayt 7.2.2.7: Aktif Hatırlama & Board Sınavı Vakası: 34 Yaş VKH Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: AKUT VKH",
        category="BÖLÜM 7.2.2: AKTİF HATIRLAMA",
        subtitle="34 Yaşında Kadında Şiddetli Baş Ağrısı, Tinnitus ve İki Taraflı Büllöz Eksüdatif Dekolman",
        vignette="34 yaşında kadın hasta, 1 haftadır devam eden zonklayıcı baş ağrısı, ense kökünde sertlik, kulaklarında çınlama (tinnitus) ve son 2 günde her iki gözünde görmenin el hareketlerine kadar gerilemesi şikayetiyle getiriliyor. Göz cerrahisi veya travma öyküsü kesinlikle yoktur. Görme keskinliği her iki gözde 0.05. Ön kamara muayenesinde bilateral 1+ hücre ve hafif siliyer enjeksiyon izleniyor. Genişletilmiş fundus muayenesinde her iki gözde arka kutupta optik diski çevreleyen ve alt kadrana uzanan devasa büllöz seröz eksüdatif retina dekolmanı alanları izleniyor; periferde yırtık saptanmıyor. EDI-OKT'de koroid kalınlığı 920 μm'ye ulaşmış olup subretinal alanda çok sayıda fibrinöz septa ile ayrılmış sıvı odacıkları izleniyor. FFA'da erken evrede yüzlerce fokal pinpoint sızıntı ('yıldızlı gökyüzü') ve geç evrede multilobüler göllenme izleniyor.",
        differentials=[
            "Akut Vogt-Koyanagi-Harada (VKH) Sendromu (Nörolojik prodrom, işitme semptomları, bilateral büllöz ERD, yıldızlı gökyüzü FFA).",
            "Sempatik Oftalmi (Travma veya cerrahi öyküsü kesinlikle olmadığı için elenir).",
            "Malign Hipertansif Retinopati (Tansiyon normalse dışlanır).",
            "Santral Sinir Sistemi Lenfoması (Hücresel infiltrasyon ön plandadır, bu derecede hızlı büllöz sıvı yapmaz)."
        ],
        decision="1. Klinik Tanı: Akut Vogt-Koyanagi-Harada (VKH) Sendromu (Tam/İnkomplet Evre 2 Akut Üveitik Faz).\n2. Acil Tedavi: Hasta derhal yatırılmalı ve 3 gün boyunca İntravenöz Yüksek Doz Pulse Metilprednizolon (1000 mg/gün) başlanmalıdır.\n3. İdame: 4. gün Oral Prednizolon (1 mg/kg/gün) tedavisine geçilmeli, nüksü engellemek için Mikofenolat Mofetil (2 g/gün) eklenmeli ve steroid dozu en az 6-9 ayda çok yavaş azaltılmalıdır.\n4. Cerrahi Uyarı: Bu hastada cerrahi (vitrektomi veya skleral çökertme) KESİNLİKLE KONTRENDİKEDİR.",
        board_trap="Bu hastada büllöz retinal dekolmanı görüp 'yırtıksız regmatojen dekolman' zannederek acil cerrahiye almak gözün fitizise gitmesine yol açar; bu eksüdatif bir dekolmandır ve tek tedavisi acil sistemik steroiddir [s.214]."
    )

    # =========================================================================
    # 7.3.1: MEWDS (MULTİPL EVANESAN BEYAZ NOKTA SENDROMU) (5 Slayt)
    # =========================================================================

    # Slayt 7.3.1.1: MEWDS Patofizyolojisi ve Genç Kadın Baskınlığı
    builder.add_study_card_slide(
        title="MEWDS (MULTİPL EVANESAN BEYAZ NOKTA SENDROMU)",
        category="BÖLÜM 7.3.1: MEWDS",
        subtitle="Genç Kadınlarda Viral Prodrom Sonrası Foveal Granülarite ve Geçici Kör Nokta Genişlemesi",
        cards=[
            {
                "card_title": "1. Epidemiyoloji ve Klinik Profil",
                "lead": "Genç Miyop Kadınların Selim Hastalığı",
                "items": [
                    "Hastaların %80-90'ı genç erişkin kadınlardır (20-40 yaş arası) [s.217].",
                    "Hastaların yarısında göz semptomlarından 1-2 hafta önce grip benzeri viral üst solunum yolu enfeksiyonu öyküsü vardır.",
                    "Tipik olarak TEK TARAFLIDIR (unilateral); hastada ani görme bulanıklığı, fotopsi (ışık parlamaları) ve kör nokta genişlemesi başlar.",
                    "Beyaz nokta sendromları arasında prognozu en mükemmel olanıdır; kendiliğinden tamamen düzelir."
                ],
                "footer": "Genç Kadın / Unilateral / Viral Prodrom / Selim Seyir"
            },
            {
                "card_title": "2. Fundus Lezyonları ve Foveal Granülarite",
                "lead": "Silik Beyaz Benekler ve Turuncu Fovea",
                "items": [
                    "Arka kutup ve orta periferde derin retinada 100-200 μm çapında çok sayıda silik, belirsiz sınırlı beyaz-gri noktalar izlenir [s.217].",
                    "Lezyonlar birkaç gün veya hafta içinde hızla yer değiştirir veya kaybolur ('evanescent' / uçucu).",
                    "Foveal Granülarite: Fovea merkezinde küçük turuncu-sarı granüler noktalanma izlenir (hastalığın imzasıdır).",
                    "Bu foveal granüler görünüm periferik beyaz noktalar kaybolduktan sonra bile aylarca kalabilir."
                ],
                "footer": "Uçucu Beyaz Noktalar / Patognomonik Foveal Granülarite"
            },
            {
                "card_title": "3. Görme Alanında Kör Nokta Genişlemesi",
                "lead": "Peripapiller Fotoreseptör Disfonksiyonu",
                "items": [
                    "Görme alanı testinde kör noktanın devasa şekilde genişlediği (enlarged blind spot) saptanır [s.218].",
                    "İlginç olarak fundusta optik disk tamamen normal görünse bile kör nokta belirgin geniştir.",
                    "Peripapiller alandaki fotoreseptör dış segmentlerinin geçici iletim blokajına bağlıdır.",
                    "Hastalar karanlıkta ışık çakmaları ve santral parasantral skotom tarif ederler."
                ],
                "footer": "Kör Nokta Genişlemesi / Geçici İletim Blokajı"
            }
        ]
    )

    # Slayt 7.3.1.2: MEWDS Multimodal İmzası: FAF ve ICG
    builder.add_study_card_slide(
        title="MEWDS MULTİMODAL GÖRÜNTÜLEME İMZALARI",
        category="BÖLÜM 7.3.1: GÖRÜNTÜLEME",
        subtitle="FAF'ta Parlayan Hiperotofloresan Çiçekleri ve ICG'de Hipofloresan Odaklar",
        cards=[
            {
                "card_title": "1. Fundus Otofloresans (FAF) İmzası",
                "lead": "Klinikte En Duyarlı Tanı Aracı",
                "items": [
                    "Biyomikroskopide beyaz noktalar çok silik ve zor seçilirken, FAF'ta adeta parıldarlar [s.218].",
                    "Lezyonlar parlak hiperotofloresan odaklar ve çiçek demetleri şeklinde görünür.",
                    "Optik disk çevresinde ve foveada hiperotofloresan noktalanma FAF ile anında yakalanır.",
                    "FAF, şüpheli olgularda MEWDS tanısını 1 dakikada kesinleştiren en pratik incelemedir."
                ],
                "footer": "FAF Hiperotofloresan Çiçekleri / En Duyarlı Test"
            },
            {
                "card_title": "2. İndosiyanin Yeşili Anjiyografisi (ICG)",
                "lead": "Koryokapillaris İskemisi ve Hipofloresans",
                "items": [
                    "ICG anjiyografisinde erken ve geç fazlarda çok sayıda keskin sınırlı hipofloresan siyah benek izlenir [s.218].",
                    "ICG'deki lezyon sayısı fundusta veya FFA'da görülen beyaz noktalardan çok daha fazladır.",
                    "Bu hipofloresan odaklar koryokapillaris perfüzyon defektlerini ve lokalize iskemiyi yansıtır.",
                    "Hastalık iyileştikçe ICG'deki karanlık odaklar 2-3 ay içinde tamamen kaybolur."
                ],
                "footer": "Geç Faz Hipofloresan Benekler / Geri Dönüşümlü İskemi"
            },
            {
                "card_title": "3. Floresein Anjiyografisi (FFA) ve OKT",
                "lead": "Çelenk Şeklinde Erken Hiperfloresans",
                "items": [
                    "FFA erken evrede beyaz noktaların çevresinde küçük çelenk (wreath-like) tarzı hiperfloresans verir [s.218].",
                    "Geç evrede optik diskte hafif boyanma izlenebilir.",
                    "SD-OKT'de fovea ve lezyon alanlarında elipsoid zonda (EZ) geçici kesintiler ve dış retina katlantıları izlenir.",
                    "2-8 hafta içinde EZ bandı hiçbir skar bırakmaksızın tamamen rejenere olur."
                ],
                "footer": "Çelenk FFA / Geçici EZ Kesintisi / Tam Restorasyon"
            }
        ]
    )

    # Slayt 7.3.1.3: Foveal Granülarite ve OKT Elipsoid Zon Restorasyonu
    builder.add_study_card_slide(
        title="MEWDS'TE SPONTAN İYİLEŞME VE RESTORASYON",
        category="BÖLÜM 7.3.1: PROGNOZ",
        subtitle="Tedavisiz Tam Fonksiyonel ve Anatomik İyileşme, OKT Elipsoid Zon Rejenerasyonu",
        cards=[
            {
                "card_title": "1. Mükemmel Doğal Seyir",
                "lead": "Medikal Tedavi GEREKTİRMEZ",
                "items": [
                    "MEWDS, beyaz nokta sendromları içinde tedavi gerektirmeyen tek antitedir [s.219].",
                    "Sistemik steroid veya immünsüpresif vermeye gerek yoktur; hastalık kendi kendini sınırlar.",
                    "Görme keskinliği genellikle 2 ila 6 hafta içinde kendiliğinden 1.0 tam seviyesine ulaşır.",
                    "Işık çakmaları ve kör nokta genişlemesi en son düzelen subjektif semptomlardır (2-3 ay sürebilir)."
                ],
                "footer": "Kendiliğinden İyileşme / Steroid GEREKSİZDİR"
            },
            {
                "card_title": "2. OKT'de Elipsoid Zon Rejenerasyonu",
                "lead": "Fotoreseptör İyileşmesinin Takibi",
                "items": [
                    "Akut evrede foveada elipsoid zon (EZ) ve interdigitasyon zonunda parçalanma ve hiperreflektif döküntüler izlenir [s.219].",
                    "3-4. haftalarda dış nükleer katmandan yeni dış segment uzantıları sentezlenir.",
                    "6. haftada SD-OKT kesitinde EZ bandı kesintisiz tek çizgi halinde tamamen yeniden kurulur.",
                    "Kalıcı RPE atrofisi veya koroid skarı bırakmaz."
                ],
                "footer": "6 Haftada Tam EZ Rejenerasyonu / Sıfır Skar"
            },
            {
                "card_title": "3. Nüks ve İkincil Durumlar",
                "lead": "Nadir Nüksler ve KNV Riski",
                "items": [
                    "Hastaların <%10'unda aylar veya yıllar sonra aynı veya diğer gözde hafif nüks görülebilir [s.219].",
                    "Nüks etse dahi görme yine sekelsiz olarak 1.0 seviyesine toparlar.",
                    "Koroidal neovaskülarizasyon (KNV) gelişme riski son derece nadirdir (<%1-2).",
                    "Genç kadın hastaya durumun selim olduğu ve körlük riski taşımadığı anlatılarak anksiyetesi yatıştırılmalıdır."
                ],
                "footer": "Nüks <%10 / KNV Riski Minimal / Selim Prognoz"
            }
        ]
    )

    # Slayt 7.3.1.4: MEWDS Tanı ve İzlem Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="MEWDS TANI VE İZLEM PROTOKOLÜ",
        category="BÖLÜM 7.3.1: AKIŞ ŞEMASI",
        subtitle="Genç Kadında Ani Kör Nokta Genişlemesi ve Fotopsiyle Başvuru Algoritması",
        steps=[
            {
                "num": "1",
                "title": "Ayrıntılı Anamnez ve Fovea Muayenesi",
                "desc": "Son 2 haftada grip öyküsü sorgulanır; foveada patognomonik turuncu granülarite aranır [s.217].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Fundus Otofloresans (FAF) Çekimi",
                "desc": "FAF ile arka kutup ve peripapiller alandaki parlak hiperotofloresan çiçek lezyonları belgelenir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Görme Alanı ve OKT Doğrulaması",
                "desc": "Kör nokta genişlemesi ve OKT'de geçici elipsoid zon kesintisi tespit edilerek tanı kesinleştirilir.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Tedavisiz Gözlem ve Güvence",
                "desc": "Sistemik steroid verilmez; hasta bilgilendirilir, 4-6 hafta sonra spontan iyileşme doğrulanır [s.219].",
                "status": "success"
            }
        ],
        bottom_takeaway="MEWDS'i tanımak gereksiz yüksek doz steroid tedavilerini, beyin MR'larını ve lomber ponksiyonları önleyen en kritik klinik yetkinliktir [s.219]."
    )

    # Slayt 7.3.1.5: Aktif Hatırlama & Board Sınavı Vakası: 24 Yaş MEWDS Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: MEWDS",
        category="BÖLÜM 7.3.1: AKTİF HATIRLAMA",
        subtitle="24 Yaşında Kadında Grip Sonrası Kör Nokta Genişlemesi ve Foveal Granülarite",
        vignette="24 yaşında kadın stajyer doktor, 10 gün önce geçirdiği ağır ateşli üst solunum yolu enfeksiyonunu takiben 3 gündür sağ gözünün temporal alanında parlayan ışık çakmaları (fotopsi) ve görmesinde sislenme fark ediyor. Sağ görme keskinliği 0.6, sol görme 1.0 tam. Ön segmentte hücre veya inflamasyon yok. Biyomikroskopik fundus muayenesinde optik disk doğal; fovea merkezinde küçük turuncu-sarı beneklenme (foveal granülarite) ve arka kutupta zor seçilen birkaç adet silik grimsi-beyaz lezyon izleniyor. Görme alanı testinde sağda belirgin kör nokta genişlemesi (enlarged blind spot) saptanıyor. Çekilen FAF'ta arka kutupta onlarca parlak hiperotofloresan nokta saptanıyor. SD-OKT'de foveada elipsoid zonda fokal kesintiler izleniyor.",
        differentials=[
            "Multipl Evanesan Beyaz Nokta Sendromu (MEWDS - Genç kadın, viral prodrom, foveal granülarite, FAF hiperotofloresansı ve kör nokta genişlemesi).",
            "Akut Optik Nörit (Görme düşüklüğü ve kör nokta benzerdir ancak MEWDS'te rölatif afferent pupil defekti yoktur ve FAF'ta lezyonlar parlar).",
            "APMPPE (Lezyonlar çok daha büyüktür, bilateraldir ve FFA'da erken blokaj geç boyanma verir).",
            "Akut Retinal Nekroz (İlerleyici nekroz ve yoğun vitrit vardır; MEWDS'te vitrit minimaldir)."
        ],
        decision="1. Klinik Tanı: Multipl Evanesan Beyaz Nokta Sendromu (MEWDS).\n2. Tedavi Kararı: Kesinlikle hiçbir medikal tedavi (steroid veya antiviral) VERİLMEZ.\n3. Yaklaşım: Hastaya tablonun tamamen selim olduğu, lezyonların uçucu olduğu ve foveal elipsoid zonun 4-6 hafta içinde spontan rejenere olarak görmenin 1.0 tam seviyesine döneceği açıklanır.\n4. Takip: 1 ay sonra kontrol OKT ve görme alanı planlanır.",
        board_trap="Bu hastada kör nokta genişlemesini ve görme düşüklüğünü görüp 'bu atipik optik nörittir' diyerek gereksiz kranial MR çekmek ve yüksek doz pulse steroid yüklemek en yaygın klinik yanılgıdır; foveal granülarite ve FAF lezyonları MEWDS'i anında ele verir [s.217]."
    )

    # =========================================================================
    # 7.3.2: APMPPE (AKUT POSTERİOR MULTİFOKAL PLAKOİD EPİTELYOPATİ) (5 Slayt)
    # =========================================================================

    # Slayt 7.3.2.1: APMPPE Patogenezi: Koryokapillaris İskemisi
    builder.add_study_card_slide(
        title="APMPPE PATOFİZYOLOJİSİ VE PLAKOİD LEZYONLAR",
        category="BÖLÜM 7.3.2: APMPPE",
        subtitle="Koryokapillaris Lobüler Oklüzyonu, Genç Erişkinlerde Bilateral Plaklar ve HLA-B7 / DR2",
        cards=[
            {
                "card_title": "1. Koryokapillaris İskemik İnfarktı",
                "lead": "Primer Patoloji RPE Değil, Koryokapillaristir",
                "items": [
                    "Koryokapillaris lobüllerinin akut hipersensitivite veya vaskülit zemininde tromboze olmasıdır [s.221].",
                    "Kan akımı kesilince üzerindeki RPE hücreleri beslenemez ve sekonder olarak ödemleşir.",
                    "Lezyonlar fundusta 1-2 disk çapında, çok odaklı, krem-sarı renkli, yassı 'plakoid' alanlar olarak belirir.",
                    "HLA-B7 ve HLA-DR2 doku gruplarıyla güçlü birliktelik gösterir."
                ],
                "footer": "Koryokapillaris Trombozu -> Sekonder RPE Ödemi"
            },
            {
                "card_title": "2. Klinik Başvuru ve Bilateralite",
                "lead": "Genç Erkek ve Kadınlarda Eşit Görülür",
                "items": [
                    "20-40 yaş arası genç erişkinlerde ani, bilateral santral ve parasantral görme kaybı ile başlar [s.221].",
                    "Hastaların %30-50'sinde semptomlardan önce grip benzeri viral prodrom mevcuttur.",
                    "İki göz eşzamanlı veya birkaç gün/hafta arayla tutulabilir.",
                    "Ön kamara ve vitreus hafiftir; fundusta makulayı saran çok sayıda düzensiz plakoid lezyon dikkat çeker."
                ],
                "footer": "Bilateral Plaklar / 20-40 Yaş / Ani Santral Kayıp"
            },
            {
                "card_title": "3. Doğal Seyir ve Rezolüsyon",
                "lead": "Plakların Skara Dönüşümü",
                "items": [
                    "Akut plaklar 1-2 hafta içinde merkezden başlayarak solar ve incelir [s.221].",
                    "Yerini değişken derecede RPE depigmentasyonu ve hafif pigmente benekli atrofik sınırlara bırakır.",
                    "Görme keskinliği olguların %80'inde 2-3 ay içinde 0.8 ve üzerine toparlar.",
                    "Ancak fovea merkezinde kalıcı RPE hasarı kalan olgularda metamorfopsi ve skotom kalıcı olabilir."
                ],
                "footer": "1-2 Haftada Solma -> RPE Pigmentasyonu -> %80 İyileşme"
            }
        ]
    )

    # Slayt 7.3.2.2: APMPPE İmzası: FFA 'Block Early, Stain Late'
    builder.add_study_card_slide(
        title="APMPPE'NİN ANJİYOGRAFİK İMZASI: BLOCK EARLY, STAIN LATE",
        category="BÖLÜM 7.3.2: GÖRÜNTÜLEME",
        subtitle="FFA'da Erken Hipofloresans (Blokaj) ve Geç Faz Hiperfloresans (Boyanma) İmzası",
        cards=[
            {
                "card_title": "1. Erken Faz: Belirgin Hipofloresans (Block Early)",
                "lead": "Koryokapillaris Dolaşımının Durması",
                "items": [
                    "Floresein anjiyografisinin erken koroidal ve arteriyel fazında plakoid lezyonlar kapkaranlıktır [s.222].",
                    "Bu erken hipofloresansın iki temel mekanizması vardır:",
                    "1. Koryokapillaris lobüllerinin tromboze olması nedeniyle koroid dolumunun olmaması (iskemi).",
                    "2. Üzerindeki ödemli, bulanık RPE hücrelerinin alttaki floresansı fiziksel olarak bloke etmesi.",
                    "Bu erken blokaj APMPPE'nin en karakteristik bulgusudur."
                ],
                "footer": "Erken Hipofloresans = İskemi + RPE Blokajı"
            },
            {
                "card_title": "2. Geç Faz: Yoğun Hiperfloresans (Stain Late)",
                "lead": "Hasarlı Dokuya Floresein Sızıntısı ve Boyanma",
                "items": [
                    "FFA'nın 10-15. dakikasındaki geç fazında görüntü tamamen tersine döner [s.222].",
                    "Karanlık olan plakoid sahalar yoğun şekilde parlar ve homojen hiperfloresans (boyanma) gösterir.",
                    "Mekanizma: Hasarlı RPE hücrelerinin ve koryokapillarisin floreseini tutması (staining).",
                    "Bu 'Erken Fazda Blokaj, Geç Fazda Boyanma' (Block Early, Stain Late) ikilisi APMPPE için patognomoniktir."
                ],
                "footer": "Geç Faz Boyanma (Staining) / Patognomonik İkili"
            },
            {
                "card_title": "3. İndosiyanin Yeşili (ICG) ve OKT Bulguları",
                "lead": "Koryokapillaris Perfüzyon Haritası",
                "items": [
                    "ICG anjiyografisinde hem erken hem geç fazda belirgin coğrafi hipofloresans izlenir [s.222].",
                    "İyileşme döneminde ICG hipofloresansı FFA'ya göre çok daha geç düzelir.",
                    "SD-OKT'de akut evrede RPE üzerinde kubbe şeklinde hiperreflektif plaklar ve dış nükleer katman ödemi görülür.",
                    "Plaklar düzleştikçe elipsoid zon kademeli olarak rejenere olur."
                ],
                "footer": "ICG Kalıcı Hipofloresans / OKT RPE Hiperreflektivitesi"
            }
        ]
    )

    # Slayt 7.3.2.3: Sistemik Risk: Serebral Vaskülit ve İnme İlişkisi
    builder.add_study_card_slide(
        title="APMPPE'NİN ÖLÜMCÜL RİSKİ: SEREBRAL VASKÜLİT VE İNME",
        category="BÖLÜM 7.3.2: SİSTEMİK RİSK",
        subtitle="Santral Sinir Sistemi Vasküliti, İskemik İnme Riski ve Profilaktik Sistemik Steroid",
        cards=[
            {
                "card_title": "1. Serebral Vaskülit Patolojisi",
                "lead": "Oküler Bulgulardan Haftalar Sonra Gelişebilir",
                "items": [
                    "APMPPE izole bir göz hastalığı değildir; sistemik koryoserebral vaskülitin bir parçası olabilir [s.222].",
                    "Beyin damarlarında (özellikle Willis poligonu ve orta serebral arter dalları) nekrotizan vaskülit gelişebilir.",
                    "Hastaların %10-15'inde şiddetli inatçı baş ağrısı, geçici iskemik atak veya fokal nörolojik defisitler görülür.",
                    "Tedavi edilmeyen serebral vaskülit genç hastalarda masif iskemik inme ve ölümle sonuçlanabilir."
                ],
                "footer": "Willis Poligonu Vasküliti / İskemik İnme Riski (%15)"
            },
            {
                "card_title": "2. Nörolojik Değerlendirme Protokolü",
                "lead": "Baş Ağrısı Olan Her Hastada Beyin MRG/MRA",
                "items": [
                    "APMPPE tanısı alan her hastaya ayrıntılı nörolojik semptom (baş ağrısı, parestezi, konuşma bozukluğu) sorulmalıdır [s.223].",
                    "En ufak bir baş ağrısı veya nörolojik bulgu varlığında derhal Kontrastlı Kranial MRG ve Manyetik Rezonans Anjiyografi (MRA) çekilmelidir.",
                    "MRA'da serebral damarlarda segmental daralmalar (tesbih tanesi görünümü) ve vaskülit aranır.",
                    "Gerektiğinde lomber ponksiyon ile BOS'ta lenfositik pleositoz doğrulanır."
                ],
                "footer": "Kranial MRA / Segmental Daralma / BOS İncelemesi"
            },
            {
                "card_title": "3. Tedavi: Sistemik Kortikosteroid Şartı",
                "lead": "Serebral Vaskülit Kalkanı",
                "items": [
                    "Yalnızca periferik hafif göz lezyonları olan asemptomatik APMPPE izlenebilir [s.223].",
                    "ANCAK makula tutulumu varsa VEYA hastada en ufak bir baş ağrısı/nörolojik bulgu eşlik ediyorsa:",
                    "Yüksek Doz İntravenöz Metilprednizolon (1 g/gün, 3 gün) ardından Oral Prednizolon (1 mg/kg/gün) başlanması ZORUNLUDUR.",
                    "Steroid serebral vasküliti durdurarak hastayı inmeden ve ölümden korur."
                ],
                "footer": "Baş Ağrısı Varsa -> ACİL YÜKSEK DOZ STEROİD ŞARTTIR"
            }
        ]
    )

    # Slayt 7.3.2.4: APMPPE Klinik Yönetim Algoritması
    builder.add_decision_tree_slide(
        title="APMPPE TANI VE SİSTEMİK TRİYAJ KARAR AĞACI",
        category="BÖLÜM 7.3.2: KARAR AĞACI",
        subtitle="Plakoid Lezyon Saptanan Hastada Nörolojik Değerlendirme ve Tedavi Triyajı",
        root_label="BİLATERAL PLAKOİD KOROYDİT VE FFA'DA 'BLOCK EARLY, STAIN LATE' İMZASI",
        branches=[
            {
                "label": "1. Şiddetli Baş Ağrısı / Nörolojik Semptom (+)",
                "criteria": "Zonklayıcı baş ağrısı, uyuşma, MRA'da serebral damar düzensizliği [s.222].",
                "action": "Acil Nöroloji Yatışı + İV Pulse Steroid: 1000 mg/gün İV Metilprednizolon (3 gün); inme profilaksisi."
            },
            {
                "label": "2. Foveayı Tutan Akut Plakoid Lezyonlar",
                "criteria": "Nörolojik semptom yok ancak fovea merkezinde akut plak var, görme <0.2 [s.223].",
                "action": "Oral Sistemik Steroid: Oral Prednizolon (1 mg/kg/gün) ile foveal fotoreseptör nekrozu sınırlandırılır."
            },
            {
                "label": "3. Ekstramakuler Periferik Plaklar (Görme Korunmuş)",
                "criteria": "Görme 1.0 tam, fovea tutulmamış, baş ağrısı kesinlikle yok [s.223].",
                "action": "Yakın Gözlem ve Hasta Eğitimi: Steroidsiz takip edilebilir; baş ağrısı gelişirse derhal acile başvurması tembihlenir."
            }
        ],
        bottom_rule="APMPPE hastasında 'gözleri kendiliğinden düzelir' diyerek baş ağrısını görmezden gelmek hastanın serebral vaskülitten inme geçirmesine yol açabilir; baş ağrısı acil kranial MRA ve steroid endikasyonudur [s.222]."
    )

    # Slayt 7.3.2.5: Aktif Hatırlama & Board Sınavı Vakası: 28 Yaş APMPPE ve Baş Ağrısı
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: APMPPE",
        category="BÖLÜM 7.3.2: AKTİF HATIRLAMA",
        subtitle="28 Yaşında Erkekte Her İki Gözde Plakoid Lezyonlar, Şiddetli Baş Ağrısı ve Serebral Tehdit",
        vignette="28 yaşında erkek yazılım mühendisi, 1 hafta önce geçirdiği gribal enfeksiyon sonrası her iki gözünde hızla ilerleyen görme kaybı ve son 2 gündür geçmeyen şiddetli zonklayıcı baş ağrısı şikayetiyle başvuruyor. Görme keskinliği sağda 0.2, solda 0.3. Biyomikroskopide ön kamara sakin, arka vitreusta 1+ hücre izleniyor. Her iki göz fundus muayenesinde makula ve damar arkatları boyunca dağılmış, 1-2 disk çapında, çok odaklı, sarı-krem renkli, yassı geniş plakoid lezyonlar izleniyor. FFA yapıldığında lezyonların erken fazda tamamen siyah kalarak floresansı bloke ettiği (block early), geç fazda ise homojen olarak yoğun boyandığı (stain late) belgeleniyor. Hasta baş ağrısının ağrı kesicilerle hiç geçmediğini ve sağ elinde hafif uyuşma hissettiğini söylüyor.",
        differentials=[
            "APMPPE Zemininde Akut Serebral Vaskülit (Bilateral plakoid lezyonlar, FFA'da block early stain late ve inme öncüsü baş ağrısı).",
            "Serpinöz Koroidit (Lezyonlar diskten başlayıp yılankavi ilerler, daha ileri yaştadır, baş ağrısı yapmaz).",
            "Sifilitik Posterior Plakoid Koryoretinit (Klinik benzerdir; treponema testleri negatifse dışlanır).",
            "Santral Sinir Sistemi Enfeksiyonu / Menenjit (FFA'daki tipik koryokapillaris blokajı APMPPE'ye özgüdür)."
        ],
        decision="1. Klinik Teşhis: APMPPE ve ilişkili Serebral Vaskülit (İnme Riski!).\n2. Acil Girişim: Hasta acil servise yatırılmalı, Nöroloji konsültasyonu ile acil Beyin MRG ve Manyetik Rezonans Anjiyografi (MRA) çekilmelidir.\n3. Medikal Tedavi: MRA sonucu beklenirken derhal İntravenöz Yüksek Doz Pulse Metilprednizolon (1000 mg/gün, 3 gün) başlanmalı, ardından oral prednizolon (1 mg/kg) ile idameye geçilmelidir.\n4. Sonuç: Erken pulse steroid hem foveal görmeyi kurtarır hem de serebral iskemik inme gelişimini engeller.",
        board_trap="APMPPE'yi 'kendiliğinden geçen selim bir beyaz nokta hastalığı' zannedip şiddetli baş ağrısı olan hastayı tedavisiz eve göndermek ölümcül bir medikal ihmaldir; serebral vaskülit riski mutlaka dışlanmalıdır [s.222]."
    )

    # =========================================================================
    # 7.3.3: BİRDSHOT KORYORETİNOPATİSİ (5 Slayt)
    # =========================================================================

    # Slayt 7.3.3.1: Birdshot Patogenezi: HLA-A29 ile %99 Birliktelik
    builder.add_study_card_slide(
        title="BİRDSHOT KORYORETİNOPATİSİ PATOGENEZİ VE HLA-A29",
        category="BÖLÜM 7.3.3: BİRDSHOT",
        subtitle="Tüm Tıpta En Güçlü HLA Birlikteliği (%99), Kronik Koroidit ve 'Saçma Tanesi' Fenotipi",
        cards=[
            {
                "card_title": "1. HLA-A29 ile Eşsiz Genetik Birlik",
                "lead": "Tıptaki En Yüksek Göreceli Risk (OR >200)",
                "items": [
                    "Birdshot hastalarının %95-99'u HLA-A*2902 doku grubunu taşır [s.226].",
                    "HLA-A29 negatif olan bir hastada Birdshot tanısı koymak neredeyse imkansızdır (negatif prediktif değer %100'e yakındır).",
                    "HLA-A29 molekülü retina-koroid spesifik antijenleri sitotoksik CD8+ T-lenfositlerine sunarak kronik granülomatöz koroidit başlatır.",
                    "Tipik olarak 50 yaş civarındaki Kafkas kökenli açık tenli bireylerde (kadın hafif baskın) ortaya çıkar."
                ],
                "footer": "HLA-A29 (%99 Pozitif) / CD8+ T-Hücre Saldırısı"
            },
            {
                "card_title": "2. Klasik Oftalmoskopik Görünüm",
                "lead": "Av Tüfeği Saçma Taneleri Manzarası",
                "items": [
                    "Optik disk çevresinden ve nazal kadrandan başlayarak tüm arka kutba saçılmış krem-turuncu oval lezyonlar [s.226].",
                    "Lezyonlar 500-1000 μm çapında, koroid damarlarının yönüne paralel uzanan 'saçma taneleri' (birdshot pellets) gibidir.",
                    "Hastalığın erken evresinde pigment birikimi veya skarlaşma görülmez; lezyonlar düz ve derindedir.",
                    "Zamanla koroid stroması incelir ve diffüz koroid atrofisi gelişir."
                ],
                "footer": "Krem-Turuncu Oval Lekeler / Saçma Tanesi Deseni"
            },
            {
                "card_title": "3. Sinsi Semptomlar ve Fonksiyonel Kayıp",
                "lead": "Görme 1.0 İken İlerleyen Gece ve Renk Körlüğü",
                "items": [
                    "Santral fovea uzun yıllar korunduğu için hastanın Snellen görme keskinliği 1.0 tam kalabilir [s.227].",
                    "ANCAK hastalar şiddetli niktalopi (gece körlüğü), disromatopsi (renk ayrım kaybı) ve kontrast duyarlılık kaybı tarif eder.",
                    "Kronik diffüz vitrit ve kistik makula ödemi (KME) santral görmeyi bozan en sık komplikasyondur.",
                    "Tedavisiz bırakılırsa diffüz periferik görme alanı daralması ve tam tüp görme gelişir."
                ],
                "footer": "Korunmuş Santral Görme / Erken Niktalopi / KME Riski"
            }
        ]
    )

    # Slayt 7.3.3.2: Birdshot Görüntüleme: FAF, OKTA ve ICG Takibi
    builder.add_study_card_slide(
        title="BİRDSHOT KORYORETİNOPATİSİNDE GÖRÜNTÜLEME VE ERG",
        category="BÖLÜM 7.3.3: GÖRÜNTÜLEME & ERG",
        subtitle="ICG Hipofloresan Saçmaları, 30 Hz Flicker Latans Uzaması ve FAF Atrofi Odakları",
        cards=[
            {
                "card_title": "1. İndosiyanin Yeşili Anjiyografisi (ICG)",
                "lead": "Klinik Muayeneden Çok Daha Fazla Lezyon",
                "items": [
                    "Fundus muayenesinde seçilemeyen onlarca gizli koroid lezyonu ICG'de siyah benekler olarak parlar [s.227].",
                    "Geç fazda tüm fundusa yayılmış homojen hipofloresan karanlık odaklar (HDDs) karakteristiktir.",
                    "ICG, hastalığın sessiz aktivitesini ve tedaviye yanıtı izlemede en duyarlı anjiyografik yöntemdir.",
                    "Başarılı immünsüpresif tedavi altında ICG'deki bu karanlık odakların sayısı ve yoğunluğu azalır."
                ],
                "footer": "ICG Geç Faz Hipofloresan Benekler / Tedavi Takip Aracı"
            },
            {
                "card_title": "2. Tam Alan ERG: 30 Hz Flicker Latansı",
                "lead": "Hastalık Aktivitesinin Objektif Biyomarkeri",
                "items": [
                    "ISCEV standart tam alan ERG'de 30 Hz flicker yanıtının dalga tepesi latansı belirgin şekilde uzar (>32 ms) [s.228].",
                    "Flicker tepe süresinin gecikmesi retinal dolaşım hasarını ve koni sistemindeki stresi yansıtır.",
                    "Tedavi etkinliği ERG latansının kısalmasıyla objektif olarak takip edilir.",
                    "Terminal evrede hem skotopik hem fotopik amplitüdler çökerek sönük ERG tablosu oluşur."
                ],
                "footer": "30 Hz Flicker Latans Uzaması (>32 ms) = Aktif Hastalık"
            },
            {
                "card_title": "3. Fundus Otofloresans (FAF) ve OKT",
                "lead": "RPE Hasarı ve Makula Ödemi",
                "items": [
                    "Erken evrede lezyonlar koroid derinliğinde olduğu için FAF tamamen normal olabilir [s.228].",
                    "Kronik evrede ise RPE atrofisine bağlı hipootofloresan pencereler ve peripapiller atrofi gelişir.",
                    "SD-OKT: Kistik makula ödemi (KME) tespiti ve foveal elipsoid zon incelmesinin takibinde zorunludur.",
                    "KME hastaların %50'sinde kalıcı görme kaybının primer nedenidir."
                ],
                "footer": "Geç FAF Atrofisi / SD-OKT ile KME Taraması"
            }
        ]
    )

    # Slayt 7.3.3.3: Birdshot Tedavi Protokolü: Erken İmmünomodülasyon
    builder.add_study_card_slide(
        title="BİRDSHOT TEDAVİ PROTOKOLÜ: ERKEN İMMÜNOMODÜLASYON",
        category="BÖLÜM 7.3.3: İMMÜNOSÜPRESYON",
        subtitle="Yalnızca Steroid Yetersizdir: Siklosporin A, Mikofenolat Mofetil ve Anti-TNF Stratejisi",
        cards=[
            {
                "card_title": "1. Neden Yalnızca Steroid Yetmez?",
                "lead": "Ömür Boyu Süren Kronik Progresif Hastalık",
                "items": [
                    "Birdshot remisyona girmeyen, yavaş ve sinsice körlüğe ilerleyen kronik bir hastalıktır [s.228].",
                    "Kortikosteroidler akut makula ödemini ve vitriti hızla yatıştırır ancak tek başına uzun dönemde yetersiz kalır.",
                    "Yıllarca yüksek doz steroid kullanmak katarakt, glokom, osteoporoz ve diyabet gibi ağır sekeller doğurur.",
                    "Bu nedenle tanı konur konmaz 'Steroid Koruyucu İmmünomodülatör Tedavi' (İMA) başlanması ZORUNLUDUR."
                ],
                "footer": "Kronik Progresyon / Steroid Koruyucu Ajan Şarttır"
            },
            {
                "card_title": "2. Birinci Basamak İmmünomodülatörler",
                "lead": "Siklosporin A ve Mikofenolat Mofetil (MMF)",
                "items": [
                    "Siklosporin A (2.5 - 4.0 mg/kg/gün): T-hücre IL-2 üretimini bloke eder; Birdshot'ta tarihsel olarak en etkili ajandır [s.229].",
                    "Mikofenolat Mofetil (MMF - 2 g/gün): Siklosporin kadar etkindir, böbrek toksisitesi ve hipertansiyon riski çok daha azdır.",
                    "Kombinasyon: Ağır ve dirençli olgularda Siklosporin + MMF düşük doz kombinasyonu sinerjistik remisyon sağlar.",
                    "Tedavi süresi en az 2-3 yıl tam remisyon sağlanana kadar sürdürülmelidir."
                ],
                "footer": "Siklosporin A / Mikofenolat Mofetil (MMF)"
            },
            {
                "card_title": "3. İkinci Basamak Biyolojik Tedavi",
                "lead": "Anti-TNF Ajanları (Adalimumab)",
                "items": [
                    "Konvansiyonel immünsüpresiflere dirençli veya tolere edemeyen olgularda Adalimumab (40 mg SC/2 hafta) mükemmel sonuç verir [s.229].",
                    "Kistik makula ödemini kurutur ve ERG 30 Hz flicker latansını normale döndürür.",
                    "Lokal Tedavi Desteği: Sistemik tedaviyi tolere edemeyen yaşlı hastalarda Fluosinolon asetonid (İluvien / Retisert) implantı düşünülebilir.",
                    "Göz içi basıncı yakından izlenmelidir."
                ],
                "footer": "Adalimumab / Fluosinolon İmplantı"
            }
        ]
    )

    # Slayt 7.3.3.4: Birdshot Klinik Yönetim ve Takip Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="BİRDSHOT KORYORETİNOPATİSİ YÖNETİM ALGORİTMASI",
        category="BÖLÜM 7.3.3: AKIŞ ŞEMASI",
        subtitle="Saçma Tanesi Lezyonları Olan 50 Yaş Hastada Adım Adım Tanı ve Tedavi Takibi",
        steps=[
            {
                "num": "1",
                "title": "HLA-A29 Genetik Tiplemesi",
                "desc": "Kanda HLA-A29 taranır; negatifse Birdshot tanısı neredeyse imkansızdır, alternatif üveitler aranır [s.226].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Bazal ICG, SD-OKT ve ERG Taraması",
                "desc": "ICG'de hipofloresan karanlık odaklar, OKT'de KME ve tam alan ERG'de 30 Hz flicker latansı ölçülür.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "İndüksiyon: Oral Steroid + İmmünomodülatör",
                "desc": "Oral prednizon ile yangı bastırılırken eşzamanlı Mikofenolat Mofetil (2 g/gün) veya Siklosporin A başlanır [s.228].",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "Yıllık ERG ve Görme Alanı İzlemi",
                "desc": "Görme 1.0 olsa dahi 30 Hz flicker latansı ve 30-2 görme alanı ile periferik fonksiyonel kayıp takip edilir.",
                "status": "success"
            }
        ],
        bottom_takeaway="Birdshot'ta görme keskinliği 1.0 diye hastayı tedavisiz bırakmak tünel görmeye ve irreversibl fotoreseptör kaybına yol açar; ERG takibi şarttır [s.227]."
    )

    # Slayt 7.3.3.5: Aktif Hatırlama & Board Sınavı Vakası: 52 Yaş Birdshot Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: BİRDSHOT",
        category="BÖLÜM 7.3.3: AKTİF HATIRLAMA",
        subtitle="52 Yaşında Kadında Gece Araba Kullanamama, Uçuşmalar ve Saçma Tanesi Koroidit",
        vignette="52 yaşında açık tenli kadın hasta, son 1 yıldır akşamları hava karardığında araba kullanamadığını (niktalopi), renkleri soluk gördüğünü ve her iki gözünün önünde sürekli sinekler uçuştuğunu belirterek başvuruyor. Görme keskinliği sağda 0.9, solda 0.8. Biyomikroskopide ön kamara tamamen sakin, her iki arka vitreusta 1+ diffüz vitrit izleniyor. Genişletilmiş fundus muayenesinde her iki gözde optik disk çevresinden nazal ve temporal ekvatora doğru uzanan, koroid damarlarının seyrine paralel dizilmiş onlarca adet 1 mm çapında oval, krem-turuncu renkli, pigmentsiz 'av tüfeği saçması' (birdshot) lezyonları izleniyor. Makula SD-OKT'sinde hafif kistik makula ödemi mevcut. ICG anjiyografisinde tüm fundusa yayılmış yüzlerce hipofloresan karanlık nokta izleniyor. İstenen genetik testte HLA-A29 pozitif bulunuyor.",
        differentials=[
            "Birdshot Koryoretinopatisi (50'li yaşlar, bilateral saçma tanesi koroidit, vitrit, niktalopi, HLA-A29 pozitifliği).",
            "Oküler Sarkoidoz (Mum damlası periflebiti ve hiler LAP beklenir; HLA-A29 negatiftir).",
            "Multifokal Koroidit (Lezyonlar daha küçüktür, belirgin pigmente skar bırakır, genç miyop kadınlarda sıktır).",
            "Primer İntraoküler Lenfoma (Maskeli üveit; 60 yaş üzerinde RPE altı tümöral birikim yapar)."
        ],
        decision="1. Kesin Tanı: Birdshot Koryoretinopatisi (HLA-A29 Pozitif).\n2. Tedavi Stratejisi: Yalnızca steroid damla veya kısa süreli oral steroid yetersizdir. Kistik makula ödemini ve vitriti baskılamak için orta doz Oral Prednizon (0.5 mg/kg) başlanmalı ve EŞZAMANLI olarak birinci basamak immünomodülatör olan Mikofenolat Mofetil (MMF 2 g/gün) veya Siklosporin A eklenmelidir.\n3. Fonksiyonel İzlem: Tedavi yanıtı 6 ayda bir ISCEV Tam Alan ERG (30 Hz flicker latansı) ve Görme Alanı ile objektif olarak takip edilmelidir.",
        board_trap="Bu hastanın görmesi 0.9 diye 'tedaviye gerek yok' demek en büyük hatadır; Birdshot santral görmeyi en son bozar ancak hastanın periferik retinası ve gece görmesi tedavi verilmezse sessizce tamamen yok olur [s.227]."
    )

    # =========================================================================
    # 7.3.4: MULTİFOKAL KOROİDİT (MFC) VE PUNKTAT İÇ KORYOPATİ (PIC) (5 Slayt)
    # =========================================================================

    # Slayt 7.3.4.1: MFC ve PIC Patofizyolojisi: Miyop Kadınlar ve KNV Riski
    builder.add_study_card_slide(
        title="MULTİFOKAL KOROİDİT (MFC) VE PUNKTAT İÇ KORYOPATİ (PIC)",
        category="BÖLÜM 7.3.4: MFC & PIC",
        subtitle="Genç Miyop Kadınlarda Küçük Zımba Deliği Koroid Lezyonları ve Yüksek KNV Tehdidi",
        cards=[
            {
                "card_title": "1. Epidemiyoloji ve Klinik Benzerlikler",
                "lead": "Genç Miyop Kadınların Enflamatuar Spektrumu",
                "items": [
                    "Her iki hastalık da tipik olarak 20-40 yaş arası hafif/orta miyop kadınlarda görülür [s.230].",
                    "Arka kutup ve orta periferde RPE ve iç koroid düzeyinde çok sayıda 100-300 μm boyutunda küçük lezyonlar bulunur.",
                    "Lezyonlar iyileşirken zımba ile delinmiş gibi (punched-out) atrofik, sınırları koyu pigmente skarlara dönüşür.",
                    "Hastalar skotom, fotopsi ve santral metamorfopsi (çizgilerde eğrilme) şikayetiyle başvururlar."
                ],
                "footer": "Genç Miyop Kadınlar / Zımba Deliği Skarlar / Metamorfopsi"
            },
            {
                "card_title": "2. MFC vs PIC: Vitrit Ayrımı",
                "lead": "İki Kardeş Antiteyi Ayıran Temel Kriter",
                "items": [
                    "Multifokal Koroidit ve Panüveit (MFC): Belirgin ön kamara hücreleri ve yoğun VİTRİT eşlik eder [s.230].",
                    "Punktat İç Koryopati (PIC): VİTRİT KESİNLİKLE YOKTUR (Ön kamara ve vitreus tamamen pürüzsüz ve berraktır).",
                    "PIC lezyonları genellikle daha küçüktür (100-200 μm) ve sadece arka kutupla sınırlıdır.",
                    "MFC lezyonları ise orta perifere kadar yayılabilir ve daha büyüktür."
                ],
                "footer": "MFC (Vitrit +) vs PIC (Vitrit Kesinlikle Yoktur)"
            },
            {
                "card_title": "3. Büyük Tehlike: İnflamatuar KNV (%30-40)",
                "lead": "Körlüğün Primer Nedeni",
                "items": [
                    "İç koroid ve Bruch zarı harabiyeti nedeniyle lezyonların tabanından subretinal neovaskülarizasyon (KNV) filizlenir [s.231].",
                    "PIC hastalarının %30-40'ında, MFC hastalarının %25-35'inde fovea altında Tip 2 KNV gelişir.",
                    "Genç bir miyop hastada ani metamorfopsi ve subretinal kanama görüldüğünde akla ilk bu antiteler gelmelidir.",
                    "Tedavi edilmezse diskiform fibrotik skarla santral görme kalıcı olarak kaybedilir."
                ],
                "footer": "İnflamatuar KNV (%35-40) / Tip 2 Subretinal / Foveal Tehdit"
            }
        ]
    )

    # Slayt 7.3.4.2: İnflamatuar Koroidal Neovaskülarizasyon (iKNV) Yönetimi
    builder.add_study_card_slide(
        title="İNFLAMATUAR KNV (iKNV) YÖNETİMİ: KOMBİNE TEDAVİ",
        category="BÖLÜM 7.3.4: iKNV TEDAVİSİ",
        subtitle="İntravitreal Anti-VEGF + Sistemik Kortikosteroid ve İmmünomodülasyon İkili Protokolü",
        cards=[
            {
                "card_title": "1. Çift Mekanizma: Yangı ve Anjiyogenez",
                "lead": "Yalnızca Anti-VEGF Neden Yetmez?",
                "items": [
                    "Yaş YBMD'deki KNV dejeneratiftir; MFC/PIC'teki KNV ise aktif koroidal inflamasyonun tetiklediği bir neovaskülarizasyondur [s.231].",
                    "Sadece Anti-VEGF enjekte edilirse damar büzülür ancak alttaki koroidit atağı devam ettiği için KNV hızla nüks eder.",
                    "Sadece steroid verilirse yangı söner ancak taze subretinal damar kanamaya ve eksüdasyona devam eder.",
                    "Bu nedenle inflamatuar KNV tedavisinde ANTİ-VEGF + KORTİKOSTEROİD KOMBİNASYONU zorunludur."
                ],
                "footer": "Yangı + VEGF Sinerjisi -> Çift Hedefli Kombinasyon"
            },
            {
                "card_title": "2. Kombine Tedavi Protokolü",
                "lead": "İntravitreal Anti-VEGF + Oral Steroid",
                "items": [
                    "Adım 1: Derhal İntravitreal Anti-VEGF (Ranibizumab 0.5 mg veya Aflibercept 2 mg) uygulanır [s.231].",
                    "Adım 2: Eşzamanlı Oral Prednizolon (0.5 - 1.0 mg/kg/gün) başlanarak alttaki aktif koroidit atağı bastırılır.",
                    "Anti-VEGF yaş YBMD gibi 3 doz yükleme gerektirmeyebilir; PRN (ihtiyaç halinde) rejimle 1-2 dozda bile yatışabilir.",
                    "Steroid dozu 4-6 hafta içinde yavaşça azaltılarak idameye geçilir."
                ],
                "footer": "İntravitreal Anti-VEGF + Oral Prednizolon 1 mg/kg"
            },
            {
                "card_title": "3. Tekrarlayan Olgularda İmmünomodülasyon",
                "lead": "Sık Nüks Eden iKNV'de İMA Şartı",
                "items": [
                    "Yılda 2'den fazla KNV nüksü veya yeni koroidit odakları gelişen olgularda kronik tedavi planlanır [s.232].",
                    "Mikofenolat Mofetil (MMF 2 g/gün) veya Azatioprin uzun süreli remisyon sağlar.",
                    "İmmünomodülatörler hem yeni koroidit ataklarını önler hem de Anti-VEGF enjeksiyon ihtiyacını sıfırlar.",
                    "OKTA (OKT Anjiyografi) ile KNV membranının regresyonu non-invaziv olarak mükemmel takip edilir."
                ],
                "footer": "Mikofenolat Mofetil / OKTA ile Membran Takibi"
            }
        ]
    )

    # Slayt 7.3.4.3: MFC vs PIC Morfolojik Karşılaştırması
    builder.add_split_comparison_slide(
        title="KARDEŞ HASTALIKLAR: MULTİFOKAL KOROİDİT (MFC) vs PIC",
        category="BÖLÜM 7.3.4: KARŞILAŞTIRMA",
        subtitle="Panüveitli Geniş Lezyonlar (MFC) vs Vitritsiz Punktat Arka Kutup Lezyonları (PIC)",
        left_entity={
            "name": "MULTİFOKAL KOROİDİT (MFC / MCP)",
            "subtitle": "Panüveitli Form — Arka Kutup ve Perifer",
            "bullets": [
                "Vitreus Yangısı: BELİRGİN VİTRİT MEVCUTTUR (2+ ila 3+ vitrit) [s.230].",
                "Ön Kamara: Hafif/orta ön üveit hücreleri eşlik edebilir.",
                "Lezyon Boyutu: 150 - 500 μm (daha geniş ve değişken çaplıdır).",
                "Lokalizasyon: Hem arka kutup hem orta ve ön periferik retinaya yayılır.",
                "Skar Görünümü: Geniş atrofik koryoretinal skarlar; periferik lineer pigment bantları.",
                "KNV Sıklığı: Hastaların %25-35'inde gelişir [s.231]."
            ]
        },
        right_entity={
            "name": "PUNKTAT İÇ KORYOPATİ (PIC)",
            "subtitle": "Saf Koroidit — Vitrit Kesinlikle Yoktur",
            "bullets": [
                "Vitreus Yangısı: VİTRİT KESİNLİKLE YOKTUR (Vitreus pürüzsüz ve berraktır) [s.230].",
                "Ön Kamara: Tamamen sakindir (sıfır hücre).",
                "Lezyon Boyutu: 100 - 200 μm (küçük, homojen, punktat noktalar).",
                "Lokalizasyon: YALNIZCA ARKA KUTUPTA kümelenir; perifere uzanmaz.",
                "Skar Görünümü: Küçük zımba deliği (punched-out) RPE defektleri.",
                "KNV Sıklığı: Hastaların %35-45'inde subfoveal/jukstafoveal KNV gelişir [s.231]."
            ]
        },
        bottom_takeaway="Genç miyop bir kadında vitrit varsa Multifokal Koroidittir (MFC); vitrit tek bir hücre dahi içermiyorsa Punktat İç Koryopatidir (PIC); her ikisi de yüksek KNV riski taşır [s.230]."
    )

    # Slayt 7.3.4.4: İnflamatuar KNV Tedavi Akış Şeması
    builder.add_horizontal_flowchart_slide(
        title="İNFLAMATUAR KNV (iKNV) TANI VE TEDAVİ AKIŞI",
        category="BÖLÜM 7.3.4: AKIŞ ŞEMASI",
        subtitle="MFC/PIC Zemininde Ani Görme Düşüşü ve Subretinal Sıvıda Protokol",
        steps=[
            {
                "num": "1",
                "title": "OKTA ve SD-OKT ile KNV Doğrulaması",
                "desc": "Zımba deliği skar tabanında Tip 2 KNV damar yumağı ve subretinal sıvı tespit edilir [s.231].",
                "status": "info"
            },
            {
                "num": "2",
                "title": "Aynı Gün İntravitreal Anti-VEGF",
                "desc": "Neovasküler kanama ve eksüdasyonu kurutmak için tek doz Ranibizumab/Aflibercept enjekte edilir.",
                "status": "warning"
            },
            {
                "num": "3",
                "title": "Eşzamanlı Sistemik Steroid Kalkanı",
                "desc": "Alttaki aktif koroidit atağını söndürmek için oral prednizolon (0.5-1 mg/kg) başlanır.",
                "status": "danger"
            },
            {
                "num": "4",
                "title": "İdame İmmünomodülasyon (MMF)",
                "desc": "Nüksleri ve yeni lezyon çıkışını önlemek için Mikofenolat Mofetil (2 g/gün) başlanarak steroid azaltılır [s.232].",
                "status": "success"
            }
        ],
        bottom_takeaway="İnflamatuar KNV'de tek başına anti-VEGF vermek nüksleri önleyemez; yangıyı söndürmek için immünsüpresif tedavi zorunludur [s.231]."
    )

    # Slayt 7.3.4.5: Aktif Hatırlama & Board Sınavı Vakası: 29 Yaş Miyop Kadında PIC ve KNV
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: PIC VE iKNV",
        category="BÖLÜM 7.3.4: AKTİF HATIRLAMA",
        subtitle="29 Yaşında -4.00 D Miyop Kadında Ani Çizgi Kırılması, Zımba Delikleri ve Subretinal Sıvı",
        vignette="29 yaşında kadın mimar, 4 gündür sol gözünde bilgisayar ekranındaki çizgilerin eğri büğrü kırıldığını (metamorfopsi) ve santral görmesinin aniden bozulduğunu belirterek acile başvuruyor. Kırma kusuru her iki gözde -4.00 D miyopi. Sol görme keskinliği 0.3'e düşmüş. Biyomikroskopide ön kamara ve arka vitreus tamamen berraktır (vitrit kesinlikle yoktur). Sol fundus muayenesinde arka kutupta fovea çevresinde dağınık, 100-200 μm çapında, zımba deliği gibi (punched-out) atrofik, sınırları pigmente eski beyaz skarlar izleniyor. Bu skarlardan foveanın hemen kenarında olanının üzerinde taze küçük bir subretinal kanama ve gri-yeşil bir kabarıklık saptanıyor. SD-OKT'de fovea altında Tip 2 hiperreflektif KNV membranı ve subretinal sıvı izleniyor. OKTA'da dış retina tabakasında yüksek akımlı damar yumağı doğrulanıyor.",
        differentials=[
            "Punktat İç Koryopatiye (PIC) Bağlı Sekonder İnflamatuar KNV (Genç miyop kadın, zımba delikleri, vitritsiz göz ve foveal Tip 2 KNV).",
            "Miyopik Koroidal Neovaskülarizasyon (mKNV - Benzerdir ancak zımba deliği koryoretinal atrofi skarları içermez, lak çatlakları üzerinde gelişir).",
            "Multifokal Koroidit (MFC - Vitrit mevcuttur; bu hastada vitreus tamamen berraktır).",
            "Yaşa Bağlı Makula Dejenerasyonu (29 yaşında bir hastada YBMD beklenmez)."
        ],
        decision="1. Klinik Teşhis: Sol Punktat İç Koryopati (PIC) zemininde gelişen Subfoveal İnflamatuar Koroidal Neovaskülarizasyon (iKNV).\n2. Tedavi Stratejisi: Yalnızca anti-VEGF veya yalnızca steroid yetersizdir; ÇİFT KOMBİNE TEDAVİ uygulanmalıdır.\n3. Acil Eylem: Sol göze derhal İntravitreal Anti-VEGF (Ranibizumab 0.5 mg veya Aflibercept 2 mg) enjekte edilmeli ve AYNI GÜN alttaki aktif koroidit atağını durdurmak için Oral Prednizolon (60 mg/gün) başlanmalıdır.\n4. İdame: Sıvı kuruduktan sonra steroid dozu azaltılmalı, nüksü önlemek için Mikofenolat Mofetil (2 g/gün) eklenmelidir.",
        board_trap="Bu hastada zımba deliği koryoretinit skarlarını atlayıp 'bu basit bir miyopik KNV'dir' diyerek hastaya sadece tek doz anti-VEGF yapıp göndermek koroidit atağının sürmesine ve KNV'nin haftalar içinde hızla nüks etmesine yol açar; inflamatuar KNV mutlaka steroid/immünsüpresif ile kombine edilmelidir [s.231]."
    )

    # =========================================================================
    # 7.3.5: SERPİNÖZ KORYORETİNOPATİ (5 Slayt)
    # =========================================================================

    # Slayt 7.3.5.1: Serpinöz Patogenezi: Optik Diskten Yılankavi İlerleme
    builder.add_study_card_slide(
        title="SERPİNÖZ KORYORETİNOPATİ PATOFİZYOLOJİSİ",
        category="BÖLÜM 7.3.5: SERPİNÖZ",
        subtitle="Optik Disk Çevresinden Başlayan Yılankavi (Serpiginous) RPE ve Koryokapillaris Yıkımı",
        cards=[
            {
                "card_title": "1. Klinik Tanım ve Morfoloji",
                "lead": "Coğrafi / Yılankavi Harita Benzeri Atrofi",
                "items": [
                    "Kronik, ilerleyici, rekürren ve bilateral koryoretinal yıkımla giden otoimmün bir hastalıktır [s.235].",
                    "Lezyonlar hemen daima optik diskin peripapiller kenarından başlar.",
                    "Psödopodlar (yalancı ayaklar) şeklinde merkezkaç olarak yılankavi dalgalar halinde makulaya ve perifere doğru sürünür.",
                    "Aktif kenar kabarık, gri-sarı renklidir; geride bıraktığı merkez ise tam atrofik çıplak skleradır."
                ],
                "footer": "Peripapiller Başlangıç / Yılankavi Dalgalar / Çıplak Sklera"
            },
            {
                "card_title": "2. Demografi ve Sistemik Durum",
                "lead": "30-50 Yaş Erişkinler",
                "items": [
                    "Kadın ve erkeklerde eşit sıklıkta görülür [s.235].",
                    "İki göz asimetrik tutulur; bir gözde eski inaktif atrofik harita varken diğerinde taze aktif kenar alevlenebilir.",
                    "Klasik serpinöz otoimmün bir tablodur ve HLA-B7 ile birliktelik gösterir.",
                    "Ön kamara ve vitreus inflamasyonu minimaldir veya yoktur (hafif vitrit olabilir)."
                ],
                "footer": "30-50 Yaş / Asimetrik Bilateralite / Minimal Vitrit"
            },
            {
                "card_title": "3. Tahrip Edici Doğal Seyir",
                "lead": "Foveayı Yutarak Kalıcı Körlük Yapma Riski",
                "items": [
                    "Yılankavi aktif kenar fovea merkezine ulaştığında fotoreseptörleri ve RPE'yi tamamen yok eder [s.236].",
                    "Santral fovea tutulduğunda görme keskinliği kalıcı olarak 0.05 - 0.1 seviyesine düşer.",
                    "Ayrıca atrofik skar sınırlarında %20-25 oranında sekonder koroidal neovaskülarizasyon (KNV) gelişebilir.",
                    "Atakların agresif immünsüpresyonla foveaya ulaşmadan önce durdurulması hayati hedeftir."
                ],
                "footer": "Foveal Tahribat Riski / KNV Oranı %25 / Agresif Tedavi Şart"
            }
        ]
    )

    # Slayt 7.3.5.2: Klasik Serpinöz vs Tüberküloz Serpinöz-Benzeri Koroidit (SLC)
    builder.add_split_comparison_slide(
        title="SERPİNÖZ AYIRICI TANISI: OTOİMMÜN vs TÜBERKÜLOZ (SLC)",
        category="BÖLÜM 7.3.5: KARŞILAŞTIRMA",
        subtitle="Klasik Otoimmün Serpinöz Koroidit vs Mycobacterium tuberculosis İlişkili Form (SLC)",
        left_entity={
            "name": "KLASİK OTOİMMÜN SERPİNÖZ",
            "subtitle": "Spontan Otoimmünite — HLA-B7",
            "bullets": [
                "Başlangıç: Mutlaka optik disk peripapiller kenarından başlar [s.235].",
                "Yayılım Deseni: Kesintisiz tek bir gövde halinde yılankavi dalgalar halinde yayılır.",
                "Vitrit Derecesi: MİNİMAL VEYA SIFIRDIR (Vitreus hücresi hemen hiç görülmez).",
                "TB Testleri: PPD, Quantiferon-TB ve Toraks BT tamamen negatiftir.",
                "Tedavi Yanıtı: Yüksek doz İmmünsüpresif / Biyolojik tedaviye yanıt verir.",
                "Tehlike: TB dışlanmadan immünsüpresyon verilirse sistemik TB yayılabilir [s.236]."
            ]
        },
        right_entity={
            "name": "TÜBERKÜLOZ İLİŞKİLİ SERPİNÖZ (SLC)",
            "subtitle": "İmmün Hipersensitivite — M. tuberculosis",
            "bullets": [
                "Başlangıç: Optik diskten başlamak zorunda değildir; multifokal periferik başlayabilir [s.209].",
                "Yayılım Deseni: Birbirinden bağımsız çok odaklı lezyonlar zamanla birleşir.",
                "Vitrit Derecesi: BELİRGİN VİTRİT MEVCUTTUR (Orta/yoğun vitreus pusu eşlik eder).",
                "TB Testleri: PPD (>15 mm), Quantiferon-TB (+) ve hiler kalsifikasyon sıktır.",
                "Tedavi Yanıtı: 4'lü Antitüberküloz (HRZE) + Kortikosteroid ile tam şifa sağlanır.",
                "Altın Kural: TB ülkelerinde serpinöz görüldüğünde aksi kanıtlanana kadar SLC kabul edilir [s.210]."
            ]
        },
        bottom_takeaway="Klasik serpinöz diskten başlar ve vitrit içermez; tüberküloz ilişkili serpinöz (SLC) ise multifokal başlar ve vitrit içerir; SLC'de 4'lü antitüberküloz tedavisi şarttır [s.236]."
    )

    # Slayt 7.3.5.3: FFA ve FAF Dinamiği: Aktif Kenar vs İnaktif Merkez
    builder.add_study_card_slide(
        title="SERPİNÖZDE GÖRÜNTÜLEME İMZASI: AKTİF KENAR DİNAMİĞİ",
        category="BÖLÜM 7.3.5: GÖRÜNTÜLEME",
        subtitle="Aktif Öncü Dalgada Floresans Sızıntısı, FAF Hiperotofloresansı ve Merkezde Koyu Atrofi",
        cards=[
            {
                "card_title": "1. Floresein Anjiyografisi (FFA) Dinamiği",
                "lead": "Aktif Kenarda Boyanma, Merkezde Blokaj/Pencere",
                "items": [
                    "Aktif Öncü Kenar (Leading Edge): Erken fazda hipofloresan (ödem blokajı), geç fazda yoğun hiperfloresan sızıntı verir [s.236].",
                    "İnaktif Atrofik Merkez: Koryokapillaris kaybına bağlı erken hipofloresans, geç fazda ise sklera boyanması izlenir.",
                    "FFA aktif yangının sınırını ve foveaya olan mesafesini net olarak gösterir.",
                    "Skar sınırlarında ani odak hiperfloresans ve sızıntı görülürse sekonder KNV gelişimi düşünülmelidir."
                ],
                "footer": "Öncü Kenarda Geç Sızıntı / Merkezde Skleral Boyanma"
            },
            {
                "card_title": "2. Fundus Otofloresans (FAF) İmzası",
                "lead": "Aktif Atak Takibinde En Güvenilir Araç",
                "items": [
                    "Aktif öncü kenarda fotoreseptör döküntüsüne bağlı parlak hiperotofloresan bir sınır kuşağı izlenir [s.236].",
                    "İnaktif eski lezyon gövdesi ise RPE yokluğuna bağlı tamamen simsiyah (hipootofloresan) bir atrofi haritasıdır.",
                    "Tedavi başarılı olduğunda aktif kenardaki parlak hiperotofloresan hat söner ve lezyon siyah atrofiye katılır.",
                    "FAF kontrast madde gerektirmediği için her kontrolde çekilerek ilerleme anında durdurulur."
                ],
                "footer": "Parlak Hiperotofloresan Aktif Hat / Siyah Atrofik Merkez"
            },
            {
                "card_title": "3. İndosiyanin Yeşili Anjiyografisi (ICG)",
                "lead": "Derin Koroidal Hasarın Sınırları",
                "items": [
                    "ICG erken ve geç fazlarda hem aktif hem inaktif lezyon alanlarında tam hipofloresans (karanlık) verir [s.236].",
                    "ICG'deki lezyon sınırları fundus muayenesindeki klinik görünümden belirgin olarak daha geniştir.",
                    "Bu durum koroidal vasküler hasarın oftalmoskopik RPE hasarından önce başladığını kanıtlar.",
                    "ICG koryokapillaris hipoperfüzyonunu haritalamada altın standarttır."
                ],
                "footer": "Kalıcı Hipofloresans / Klinik Sınırlardan Geniş Lezyon"
            }
        ]
    )

    # Slayt 7.3.5.4: Serpinöz Tedavi Karar Ağacı: Steroid vs Antitüberküloz
    builder.add_decision_tree_slide(
        title="SERPİNÖZ KOROYDİT TEDAVİ VE TRİYAJ PROTOKOLÜ",
        category="BÖLÜM 7.3.5: KARAR AĞACI",
        subtitle="Yılankavi Lezyon Saptanan Hastada Tüberküloz Ayrımı ve İmmünsüpresif Triyajı",
        root_label="OPTİK DİSKTEN ÇEVREYE YILANKAVİ UZANAN AKTİF KORYORETİNAL LEZYON",
        branches=[
            {
                "label": "1. Tüberküloz Testleri Pozitif / Vitrit Var",
                "criteria": "Quantiferon (+), PPD >15 mm, vitrit mevcut, multifokal başlangıç [s.209].",
                "action": "TB Serpinöz-Benzeri Koroidit (SLC): 4'lü Antitüberküloz (HRZE 2 ay + HR 7 ay) + Eşzamanlı Sistemik Steroid."
            },
            {
                "label": "2. Klasik Otoimmün Serpinöz (TB Negatif)",
                "criteria": "Diskten başlar, vitrit yok, tüm tüberküloz testleri negatif, fovea tehdidi var [s.236].",
                "action": "Agresif İmmünsüpresyon: Oral Prednizolon (1 mg/kg) + Mikofenolat Mofetil veya Azatioprin / Anti-TNF (İnfliksimab)."
            },
            {
                "label": "3. Atrofik Skar Sınırında Taze Kanama / KNV",
                "criteria": "Skar kenarında ani metamorfopsi, subretinal sıvı ve neovasküler membran [s.236].",
                "action": "Sekonder KNV Tedavisi: İntravitreal Anti-VEGF (Ranibizumab/Aflibercept) + Sistemik İmmünsüpresif İdamesi."
            }
        ],
        bottom_rule="Türkiye gibi tüberkülozun endemik olduğu coğrafyalarda serpinöz görüldüğünde tüberküloz testleri negatif çıkmadıkça tek başına yüksek doz immünsüpresif vermek ölümcül bir hata olabilir [s.210]."
    )

    # Slayt 7.3.5.5: Aktif Hatırlama & Board Sınavı Vakası: 42 Yaş Serpinöz Olgusu
    builder.add_active_recall_case_slide(
        title="BOARD SINAVI VE KLİNİK AKIL YÜRÜTME VAKASI: SERPİNÖZ",
        category="BÖLÜM 7.3.5: AKTİF HATIRLAMA",
        subtitle="42 Yaşında Erkekte Optik Diskten Foveaya Doğru Yılankavi İlerleyen Yıkım Dalgası",
        vignette="42 yaşında erkek hasta, sağ gözünde son 2 haftadır santral görmenin hızla karardığını belirterek başvuruyor. Sağ görme keskinliği 0.1'e düşmüş, sol görme 1.0 tam. Ön kamara ve vitreus muayenesinde hücre izlenmiyor (vitrit yok). Sağ fundus muayenesinde optik diskin temporal sınırından başlayarak foveolaya doğru uzanan, sınırları yılankavi ve yalancı ayaklar (psödopod) oluşturan geniş coğrafi atrofi alanı izleniyor. Bu lezyonun foveaya komşu öncü kenarı kabarık, sarımsı-gri ve aktif görünümde; lezyonun optik disk çevresindeki merkezinde ise retina ve koroid tamamen silinmiş, alttaki parlak beyaz sklera çıplak olarak izleniyor. FAF çekildiğinde öncü sınırda parlak hiperotofloresan aktif hat, merkezde ise simsiyah atrofi izleniyor. Quantiferon-TB testi negatif, toraks BT normaldir.",
        differentials=[
            "Klasik Otoimmün Serpinöz Koryoretinopati (Peripapiller başlangıç, yılankavi psödopodlar, aktif öncü kenar, vitrit yokluğu ve TB negatifliği).",
            "Tüberküloz Serpinöz-Benzeri Koroidit (Vitrit beklenir ve TB testleri pozitiftir; bu hastada elenir).",
            "APMPPE (Plakoid lezyonlar optik diskten çıkmaz, fokal ve multifokaldir, kendiliğinden iyileşir).",
            "Coğrafi Atrofi (Kuru YBMD - İleri yaşta görülür, drusen zemininde gelişir, psödopod yapmaz)."
        ],
        decision="1. Klinik Teşhis: Sağ Foveayı Tehdit Eden Klasik Otoimmün Serpinöz Koryoretinopati.\n2. Acil Tedavi: Öncü sınır foveayı yutmak üzere olduğundan acil yüksek doz tedavi şarttır. İntravenöz Pulse Metilprednizolon (1000 mg/gün, 3 gün) ardından Oral Prednizolon (1 mg/kg/gün) başlanmalıdır.\n3. İmmünomodülasyon: Hastalık remisyona girmediği için derhal steroid koruyucu ajan (Mikofenolat Mofetil 2 g/gün veya Siklosporin A) eklenmelidir; dirençli olgularda Anti-TNF (İnfliksimab) düşünülmelidir.",
        board_trap="Bu hastada 'foveada atrofi var, geçmiş olsun' diyerek tedaviyi geciktirmek aktif öncü kenarın kalan son foveal fotoreseptörleri de eritmesine ve hastanın kalıcı kör kalmasına neden olur; aktif kenar acil steroidle durdurulmalıdır [s.236]."
    )

    # =========================================================================
    # 7.3.6: BEYAZ NOKTA SENDROMLARI BÜYÜK KARŞILAŞTIRMA MATRİSİ (6 Slayt)
    # =========================================================================

    # Slayt 7.3.6.1: Altı Beyaz Nokta Hastalığının FFA, ICG ve FAF Matrisi
    builder.add_study_card_slide(
        title="BEYAZ NOKTA SENDROMLARININ BÜYÜK GÖRÜNTÜLEME MATRİSİ",
        category="BÖLÜM 7.3.6: MASTER MATRİS",
        subtitle="MEWDS, APMPPE, Birdshot, MFC, PIC ve Serpinözün FFA, ICG ve FAF Karşılaştırması",
        cards=[
            {
                "card_title": "1. MEWDS & APMPPE",
                "lead": "Selim Çiçekler vs İskemik Plaklar",
                "items": [
                    "MEWDS: FAF'ta parlak hiperotofloresan çiçekler; ICG'de hipofloresan benekler; Foveal granülarite (+); Tam spontan iyileşme [s.218].",
                    "APMPPE: FFA'da patognomonik 'Block Early, Stain Late' (Erken blokaj, geç boyanma); ICG'de derin hipofloresan plaklar; Serebral vaskülit riski [s.222]."
                ],
                "footer": "MEWDS (FAF Çiçekleri) / APMPPE (Block Early Stain Late)"
            },
            {
                "card_title": "2. Birdshot & Serpinöz",
                "lead": "Saçma Taneleri vs Yılankavi Yıkım",
                "items": [
                    "Birdshot: HLA-A29 (%99); ICG'de tüm fundusa yayılan hipofloresan saçma taneleri; ERG 30 Hz flicker latansında uzama (>32 ms) [s.227].",
                    "Serpinöz: Optik disk peripapiller kenarından yılankavi psödopodlar; FAF'ta aktif öncü kenar hiperotofloresan, merkez siyah atrofik [s.236]."
                ],
                "footer": "Birdshot (HLA-A29 / ERG) / Serpinöz (Yılankavi Öncü Kenar)"
            },
            {
                "card_title": "3. MFC vs PIC",
                "lead": "Panüveitli vs Vitritsiz Zımba Delikleri",
                "items": [
                    "Multifokal Koroidit (MFC): Belirgin VİTRİT (+); Arka kutup ve periferde 150-500 μm zımba delikleri; Yüksek KNV riski [s.230].",
                    "Punktat İç Koryopati (PIC): VİTRİT KESİNLİKLE YOKTUR; Saf arka kutupta küçük 100-200 μm punktat lezyonlar; %40 subfoveal KNV riski [s.231]."
                ],
                "footer": "MFC (Vitrit +) / PIC (Vitrit Kesinlikle Yoktur / KNV %40)"
            }
        ]
    )

    # Slayt 7.3.6.2: HLA Birliktelikleri ve Epidemiyolojik Profil Tablosu
    builder.add_study_card_slide(
        title="BEYAZ NOKTA VE ÜVEİTLERDE HLA GENETİK BİRLİKTELİKLERİ",
        category="BÖLÜM 7.3.6: GENETİK TRİYAJ",
        subtitle="HLA-A29, HLA-B51, HLA-B7, HLA-DR4 ve HLA-B27 Pozitifliklerinin Klinik Anlamı",
        cards=[
            {
                "card_title": "1. HLA-A29 & HLA-B51",
                "lead": "En Güçlü İki Dernekleşme",
                "items": [
                    "HLA-A29: Birdshot Koryoretinopatisi (%99 birliktelik; negatifse tanı neredeyse dışlanır) [s.226].",
                    "HLA-B51: Behçet Hastalığı (İpek yolu popülasyonlarında 6 kat artmış risk; oklüzif vaskülit ve hipopiyon) [s.210].",
                    "Bu iki antijen kesin klinik şüphede istenmesi gereken en değerli immünogenetik belirteçlerdir."
                ],
                "footer": "HLA-A29 (Birdshot %99) / HLA-B51 (Behçet)"
            },
            {
                "card_title": "2. HLA-B7, HLA-DR2 & HLA-DR4",
                "lead": "Plakoid, Serpinöz ve VKH Belirteçleri",
                "items": [
                    "HLA-B7 ve HLA-DR2: APMPPE ve klasik otoimmün Serpinöz koryoretinopati ile güçlü ilişki [s.221].",
                    "HLA-DR4 / HLA-DRB1*0405: Vogt-Koyanagi-Harada (VKH) sendromu ve sempatik oftalmi ilişkisi [s.213].",
                    "Melanosit antijenlerine karşı CD4+ T-hücre yanıtını tetikleyen immünogenetik zemini oluştururlar."
                ],
                "footer": "HLA-B7 (APMPPE/Serpinöz) / HLA-DR4 (VKH)"
            },
            {
                "card_title": "3. HLA-B27",
                "lead": "Ön Üveitin En Sık Nedeni",
                "items": [
                    "Ankilozan spondilit, reaktif artrit, psöriyazis ve inflamatuar bağırsak hastalıkları [s.210].",
                    "Akut, ani başlangıçlı, tek taraflı, şiddetli fibrinöz ön üveit yapar.",
                    "Arka segment tutulumu son derece nadirdir; beyaz nokta lezyonları veya retinal vaskülit yapmaz.",
                    "Beyaz nokta sendromu şüphesinde HLA-B27'nin tanısal değeri yoktur."
                ],
                "footer": "HLA-B27 (Ön Üveit / Beyaz Noktada Yeri Yoktur)"
            }
        ]
    )

    # Slayt 7.3.6.3: Atlas Görseli: Beyaz Nokta Sendromları Multimodal Karşılaştırması
    p240_img = builder.get_image_for_page(240)
    builder.add_atlas_image_slide(
        title="KLİNİK ATLAS: BEYAZ NOKTA SENDROMLARI LEZYON MORFOLOJİLERİ",
        category="BÖLÜM 7.3.6: ATLAS",
        subtitle="MEWDS Foveal Granülaritesi, APMPPE Plakları, Birdshot Saçmaları ve Serpinöz Haritası",
        image_path=p240_img if p240_img else None,
        caption="Şekil 7.1: Beyaz nokta sendromlarının multimodal fundus ve anjiyografi görünümlerinin karşılaştırmalı atlası [Kitap s.240].",
        key_findings=[
            "Panel A (MEWDS): FAF'ta peripapiller hiperotofloresan noktalanma ve foveal turuncu granülarite.",
            "Panel B (APMPPE): Arka kutupta geniş krem rengi plaklar; erken evrede karanlık, geç evrede boyanan alanlar.",
            "Panel C (Birdshot): Optik diski çevreleyen pigmentsiz oval saçma tanesi koroid lezyonları.",
            "Panel D (Serpinöz): Peripapiller alandan foveaya doğru parmak benzeri uzanan harita tarzı atrofi."
        ],
        differentials=[
            "MEWDS: Tek taraflı, selim, FAF hiperotofloresan, kör nokta geniş.",
            "APMPPE: İki taraflı, plakoid, serebral vaskülit riski (+).",
            "Birdshot: HLA-A29 (+), kronik progresif, ERG latansı uzamış."
        ],
        clinical_pearl="Beyaz nokta sendromlarında doğru tanı lezyonun rengine değil; FAF paterni, vitrit varlığı/yokluğu ve anjiyografik blokaj dinamiklerine bakılarak konulur [s.240]."
    )

    # Slayt 7.3.6.4: İnflamatuar vs Enfeksiyöz Beyaz Lezyon Triyaj Algoritması
    builder.add_decision_tree_slide(
        title="RETİNADA BEYAZ LEZYON YÖNETİM PROTOKOLÜ VE TRİYAJ",
        category="BÖLÜM 7.3.6: ALGORİTMA",
        subtitle="Fundusunda Beyaz İnfiltrat veya Lezyon Saptanan Hastada Adım Adım Karar Ağacı",
        root_label="RETİNADA VEYA KOROİDDE AKUT BEYAZ LEZYON / İNFİLTRAT SAPTANDI",
        branches=[
            {
                "label": "1. Hızla İlerleyen Periferik Nekroz (Saatler/Günler)",
                "criteria": "Oklüzif arterit, yoğun vitrit (ARN) veya CD4 <50 vitritsiz derin nekroz (PORN) [s.202].",
                "action": "Viral Retinit Acili: PCR al, sonuç beklemeden İV Asiklovir/Gansiklovir başla, 48 saat sonra steroid."
            },
            {
                "label": "2. Eski Pigmente Skar Kenarında Taze Odak",
                "criteria": "Sis içinde far manzarası, tek taraflı vitrit, fokal kabarık nekroz [s.206].",
                "action": "Oküler Toksoplazmozis: TMP-SMX + 48 saat sonra Oral Steroid (Tek başına steroid KONTRENDİKE!)."
            },
            {
                "label": "3. Multifokal Zımba Deliği / Plakoid Lezyonlar",
                "criteria": "Vitrit yoksa PIC veya APMPPE; vitrit varsa MFC veya Birdshot (HLA-A29) [s.230].",
                "action": "Beyaz Nokta Spektrumu: FAF/FFA çek, nörolojik semptom sor (APMPPE ise MRA), KNV varsa Anti-VEGF + Steroid."
            }
        ],
        bottom_rule="Retinadaki beyaz lezyonun enfeksiyöz (viral/paraziter) mi yoksa otoimmün (beyaz nokta/Behçet) mi olduğu kesinleşmeden asla intraoküler veya sistemik yüksek doz steroid verilmemelidir [s.207]."
    )

    # Slayt 7.3.6.5: Beyaz Nokta Sendromlarında Görme Prognozu ve Landmark Veriler
    builder.add_trials_kpi_slide(
        title="BEYAZ NOKTA VE ENFEKSİYÖZ RETİNİTLERDE LANDMARK VERİLER",
        category="BÖLÜM 7.3.6: KANIT DÜZEYİ",
        subtitle="MEWDS Doğal Seyri, Birdshot İmmünsüpresyonu ve ARN Profilaksi Başarısı",
        kpis=[
            {"val": "%95+", "label": "MEWDS'te Spontan Görme İyileşmesi (1.0)"},
            {"val": "%99", "label": "Birdshot'ta HLA-A29 Pozitiflik Oranı"},
            {"val": "%70 -> %25", "label": "ARN'de Lazerle Dekolman Azalması"},
            {"val": "%40", "label": "PIC Olgularında İnflamatuar KNV Riski"}
        ],
        trials_table=[
            {
                "trial": "International Uveitis Study Group (IUSG) Beyaz Nokta Kılavuzu",
                "design": "Multimodal Görüntüleme ve Tedavi Konsensüsü (2020) [s.240]",
                "result": "MEWDS'in tedavisiz izlenmesi; APMPPE'de nörolojik tarama; Birdshot'ta ilk basamakta MMF/Siklosporin başlanması Sınıf 1 öneri kabul edilmiştir."
            },
            {
                "trial": "VISUAL 1 & VISUAL 2 Landmark Çalışmaları",
                "design": "Aktif ve İnaktif Non-İnfeksiyöz İntermediate/Posterior/Panüveitlerde Adalimumab Faz 3 RCT",
                "result": "Adalimumab (anti-TNF), üveit alevlenme riskini %50'den fazla azaltmış ve kistik makula ödemini anlamlı derecede kurutmuştur."
            },
            {
                "trial": "Toxoplasmosis Treatment Landmark Study",
                "design": "Klasik Dörtlü Rejim vs TMP-SMX Karşılaştırmalı Prospektif Klinik Çalışma [s.207]",
                "result": "TMP-SMX (Bactrim) rejiminin lezyon gerileme hızı ve görme keskinliği artışında klasik rejim kadar etkili ve çok daha az toksik olduğu kanıtlanmıştır."
            }
        ],
        bottom_evidence="Landmark çalışmalar üveit ve retinitlerde erken hedefe yönelik tedavinin anatomik ve görsel prognozu belirleyen en kritik faktör olduğunu doğrulamaktadır [s.240]."
    )

    # Slayt 7.3.6.6: Aktif Hatırlama & Board Sınavı Vakası: Master Beyaz Nokta Sınavı
    builder.add_active_recall_case_slide(
        title="MASTER BOARD SINAVI VAKASI: BEYAZ NOKTA AYIRICI TANISI",
        category="BÖLÜM 7.3.6: AKTİF HATIRLAMA",
        subtitle="Üç Farklı Genç Kadın Hastada Üç Farklı Beyaz Lezyon Tablosunun Yönetimi",
        vignette="Polikliniğe aynı gün başvuran üç genç kadın hasta:\n1. Hasta (22 yaş): Sağ gözde fotopsi, foveal turuncu granülarite, FAF'ta parlak hiperotofloresan çiçekler, vitrit yok, görme 0.5.\n2. Hasta (27 yaş, -4.50 D miyop): Sol fovea çevresinde zımba deliği pigmente skarlar, sol fovea kenarında taze KNV ve kanama, vitrit yok, görme 0.2.\n3. Hasta (31 yaş): Her iki gözde 1-2 DD boyutunda sarı-krem plakoid lezyonlar, FFA'da 'block early, stain late', şiddetli baş ağrısı (+), görme bilateral 0.2.",
        differentials=[
            "1. Hasta = MEWDS (Tedavi verilmez, spontan iyileşir).\n2. Hasta = PIC zemininde İnflamatuar KNV (Anti-VEGF + Oral Steroid şarttır).\n3. Hasta = APMPPE ve Serebral Vaskülit Şüphesi (Acil Kranial MRA + İV Pulse Steroid gerekir).",
            "Hepsine ortak steroid tedavisi verilmesi (Hatalı yaklaşım; 1. hasta tedavisiz izlenir, 2. hastaya anti-VEGF eklenmelidir).",
            "Hepsine enfeksiyon tedavisi başlanması (Üçü de enfeksiyöz değil non-enfeksiyöz beyaz nokta sendromudur)."
        ],
        decision="1. Hasta (MEWDS): Hiçbir ilaç verilmez, hasta teskin edilir, 4 hafta sonra görmesi 1.0 tam olarak toparlar.\n2. Hasta (PIC + KNV): Sol göze derhal İntravitreal Anti-VEGF enjekte edilir ve oral 60 mg prednizolon başlanır, ardından MMF ile idameye geçilir.\n3. Hasta (APMPPE): Derhal nörolojiye yatırılır, kranial MRA çekilir ve inme riskini önlemek için İV Pulse Metilprednizolon (1000 mg/gün, 3 gün) başlanır.",
        board_trap="Her beyaz nokta lezyonuna ezbere aynı reçeteyi (örneğin standart oral steroid) yazmak MEWDS'li hastaya gereksiz ilaç yükler, PIC'li hastanın KNV'sini tedavi edemez ve APMPPE'li hastanın serebral inme riskini atlayabilir; üç antitenin yönetimi tamamen farklıdır [s.240]."
    )

    print(f" -> Bölüm 7 (Enfeksiyöz ve İnflamatuar Retina Hastalıkları) Tamamlandı: 62 Slayt Eklendi.")
