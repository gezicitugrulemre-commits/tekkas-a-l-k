# -*- coding: utf-8 -*-
r"""
retina_master_study_pipeline.py — 446 Slaytlık Kapsamlı Retina ve Vitreus Çalışma Atlası Orkestratörü
=====================================================================================================
Kitap: "C:\Users\gezic\Drive'ım\Retina Kitabı\Retina_ve_Vitreus_Klinik_Yaklasim.pdf" (280 Sayfa)
Hedef Format: SADECE PPTX (16:9 Geniş Ekran, Study-First, Sıfır Boş Sayfa, 400-500 Slayt Hedefi)

Modül ve Slayt Dağılımı:
  - Slayt 1: Kapak Slaytı
  - Slayt 2: Müfredat ve Modül Çalışma Haritası
  - Slayt 3 - 48:   Bölüm 1: Temel Bilimler ve Anatomi (46 Slayt)
  - Slayt 49 - 111: Bölüm 2: Retinal Görüntüleme ve Tanı Yöntemleri (63 Slayt)
  - Slayt 112 - 167: Bölüm 3: Retinal Vasküler Hastalıklar (56 Slayt)
  - Slayt 168 - 219: Bölüm 4: Makula Hastalıkları ve YBMD (52 Slayt)
  - Slayt 220 - 260: Bölüm 5: Retina Dekolmanı ve Periferik Retina (41 Slayt)
  - Slayt 261 - 299: Bölüm 6: Kalıtsal Retinal ve Koroidal Distrofiler (39 Slayt)
  - Slayt 300 - 361: Bölüm 7: Enfeksiyöz ve İnflamatuar Retina Hastalıkları (62 Slayt)
  - Slayt 362 - 387: Bölüm 8: Retina ve Koroid Tümörleri (26 Slayt)
  - Slayt 388 - 418: Bölüm 9: Travma, Farmakoterapi, Gelecek Perspektifler ve YZ (31 Slayt)
  - Slayt 419 - 446: Bölüm 10: Master Matris, Biyoistatistik, Vaka Bankası ve Kaynakça (28 Slayt)
Toplam: 446 Slayt
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# UTF-8 stdout configuration
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
sys.path.insert(0, str(BASE_DIR))

from retina_study_builder_core import RetinaStudyDeckBuilder
from dr_masterclass_engine import PPTXPalette

from retina_ch1_builder import build_chapter_1
from retina_ch2_builder import build_chapter_2
from retina_ch3_builder import build_chapter_3
from retina_ch4_builder import build_chapter_4
from retina_ch5_builder import build_chapter_5
from retina_ch6_builder import build_chapter_6
from retina_ch7_builder import build_chapter_7
from retina_ch8_builder import build_chapter_8
from retina_ch9_builder import build_chapter_9
from retina_ch10_builder import build_chapter_10


def run_retina_masterclass_pipeline() -> Path:
    start_time = time.time()
    print("=" * 80)
    print(">>> 446 SLAYTLIK RETİNA VE VİTREUS MASTERCLASS ÇALIŞMA ATLASI DERLEME SÜRECİ BAŞLADI")
    print("=" * 80)

    # 1. Builder Başlatma
    builder = RetinaStudyDeckBuilder(
        title="RETİNA VE VİTREUS",
        subtitle="Klinik Yaklaşım, Tanı Yöntemleri ve Tedavi Prensipleri — Kişisel Çalışma Atlası"
    )

    # =========================================================================
    # SLAYT 1: KAPAK SLAYTI
    # =========================================================================
    print(">> Slayt 001: Kapak Slaytı Ekleniyor...")
    builder.add_cover_slide(
        metadata_rows=[
            ("Eser Türü", "Kapsamlı Retina ve Vitreus Klinik Çalışma Atlası"),
            ("Kaynak Kitap", "280 Sayfalık Referans Klinik Yaklaşım Kitabı"),
            ("Format", "16:9 Geniş Ekran / Study-First / Sıfır Boş Sayfa"),
            ("Hedef Kitle", "Oftalmoloji Uzmanları, Kıdemli Asistanlar ve Board Adayları"),
            ("İçerik Hacmi", "10 Modül / 446 Slayt / 115 Klinik Görsel ve Şema"),
            ("Dil & Terminoloji", "Doğal Akademik Türkçe + Parantez İçi İkili Tıp Terminolojisi")
        ]
    )

    # =========================================================================
    # SLAYT 2: MÜFREDAT VE ÇALIŞMA PLANI
    # =========================================================================
    print(">> Slayt 002: Müfredat ve Modül Dağılımı Slaytı Ekleniyor...")
    builder.add_curriculum_overview_slide(
        title="MÜFREDAT VE ÇALIŞMA ATLASI MODÜL HARİTASI",
        category="MÜFREDAT PLANI",
        subtitle="280 Sayfalık Referans Kitabın 10 Ana Modül ve 446 Slaytta Bütüncül Dağılımı",
        modules=[
            {
                "card_title": "MODÜL 1: TEMEL BİLİM & TANI",
                "lead": "Bölüm 1 & Bölüm 2 (Slayt 3 - 111)",
                "items": [
                    "Bölüm 1: Vitreoretinal anatomi, fototransdüksiyon ve RPE fizyolojisi (46 Slayt)",
                    "Bölüm 2: SD-OKT, OKT Anjiyografi (OKTA), FFA/ICG, FAF ve Elektrofizyoloji (63 Slayt)"
                ],
                "footer": "Bölüm 1 - 2 Toplamı: 109 Slayt"
            },
            {
                "card_title": "MODÜL 2: VASKÜLER & MAKULA",
                "lead": "Bölüm 3 & Bölüm 4 (Slayt 112 - 219)",
                "items": [
                    "Bölüm 3: Diyabetik retinopati, RVO, arter tıkanıklıkları ve ROP (56 Slayt)",
                    "Bölüm 4: Kuru/Yaş YBMD, Coğrafi Atrofi, Pakikoroid, PCV ve VMA bozuklukları (52 Slayt)"
                ],
                "footer": "Bölüm 3 - 4 Toplamı: 108 Slayt"
            },
            {
                "card_title": "MODÜL 3: DEKOLMAN & DİSTROFİ",
                "lead": "Bölüm 5 & Bölüm 6 (Slayt 220 - 299)",
                "items": [
                    "Bölüm 5: Periferik yırtıklar, RRD, Lincoff kuralları, TRD, ERD ve PVR (41 Slayt)",
                    "Bölüm 6: Retinitis pigmentosa, Stargardt, Best, Stickler ve Luxturna gen terapisi (39 Slayt)"
                ],
                "footer": "Bölüm 5 - 6 Toplamı: 80 Slayt"
            },
            {
                "card_title": "MODÜL 4: ÜVEİT, TÜMÖR & GELECEK",
                "lead": "Bölüm 7, 8, 9 & 10 (Slayt 300 - 446)",
                "items": [
                    "Bölüm 7: Viral retinitler, Behçet, VKH ve Beyaz Nokta Atlası (62 Slayt)",
                    "Bölüm 8: Retinoblastom, Koroid melanomu ve Lenfoma (26 Slayt)",
                    "Bölüm 9: Travma, Enjeksiyon, Endoftalmi, ASM Triyajı ve Biyonik Göz (31 Slayt)",
                    "Bölüm 10: Master Matris, Biyoistatistik (GEE/ICC) ve 12 Uzmanlık Vakası (28 Slayt)"
                ],
                "footer": "Bölüm 7 - 10 Toplamı: 147 Slayt"
            }
        ]
    )

    # =========================================================================
    # BÖLÜM 1: TEMEL BİLİMLER VE ANATOMİ (46 Slayt)
    # =========================================================================
    print(">> Bölüm 1 Ekleniyor: Temel Bilimler ve Anatomi (Hedef: 46 Slayt)...")
    builder.set_chapter(1)
    build_chapter_1(builder)

    # =========================================================================
    # BÖLÜM 2: RETİNAL GÖRÜNTÜLEME VE TANI YÖNTEMLERİ (63 Slayt)
    # =========================================================================
    print(">> Bölüm 2 Ekleniyor: Retinal Görüntüleme ve Tanı Yöntemleri (Hedef: 63 Slayt)...")
    builder.set_chapter(2)
    build_chapter_2(builder)

    # =========================================================================
    # BÖLÜM 3: RETİNAL VASKÜLER HASTALIKLAR (56 Slayt)
    # =========================================================================
    print(">> Bölüm 3 Ekleniyor: Retinal Vasküler Hastalıklar (Hedef: 56 Slayt)...")
    builder.set_chapter(3)
    build_chapter_3(builder)

    # =========================================================================
    # BÖLÜM 4: MAKULA HASTALIKLARI VE YBMD (52 Slayt)
    # =========================================================================
    print(">> Bölüm 4 Ekleniyor: Makula Hastalıkları ve YBMD (Hedef: 52 Slayt)...")
    builder.set_chapter(4)
    build_chapter_4(builder)

    # =========================================================================
    # BÖLÜM 5: RETİNA DEKOLMANI VE PERİFERİK RETİNA PATOLOJİLERİ (41 Slayt)
    # =========================================================================
    print(">> Bölüm 5 Ekleniyor: Retina Dekolmanı ve Periferik Retina (Hedef: 41 Slayt)...")
    builder.set_chapter(5)
    build_chapter_5(builder)

    # =========================================================================
    # BÖLÜM 6: KALITSAL RETİNAL VE KOROİDAL DİSTROFİLER (39 Slayt)
    # =========================================================================
    print(">> Bölüm 6 Ekleniyor: Kalıtsal Distrofiler ve Gen Tedavisi (Hedef: 39 Slayt)...")
    builder.set_chapter(6)
    build_chapter_6(builder)

    # =========================================================================
    # BÖLÜM 7: ENFEKSİYÖZ VE İNFLAMATUAR RETİNA HASTALIKLARI (62 Slayt)
    # =========================================================================
    print(">> Bölüm 7 Ekleniyor: Enfeksiyöz ve İnflamatuar Hastalıklar (Hedef: 62 Slayt)...")
    builder.set_chapter(7)
    build_chapter_7(builder)

    # =========================================================================
    # BÖLÜM 8: RETİNA VE KOROİD TÜMÖRLERİ (26 Slayt)
    # =========================================================================
    print(">> Bölüm 8 Ekleniyor: Retina ve Koroid Tümörleri (Hedef: 26 Slayt)...")
    builder.set_chapter(8)
    build_chapter_8(builder)

    # =========================================================================
    # BÖLÜM 9: TRAVMA, FARMAKOTERAPİ, GELECEK PERSPEKTİFLER VE YZ (31 Slayt)
    # =========================================================================
    print(">> Bölüm 9 Ekleniyor: Travma, Enjeksiyon, ASM Triyajı ve Biyonik Göz (Hedef: 31 Slayt)...")
    builder.set_chapter(9)
    build_chapter_9(builder)

    # =========================================================================
    # BÖLÜM 10: MASTER MATRİS, BİYOİSTATİSTİK VE AKTİF VAKA BANKASI (28 Slayt)
    # =========================================================================
    print(">> Bölüm 10 Ekleniyor: Master Matris, Biyoistatistik ve Vaka Bankası (Hedef: 28 Slayt)...")
    builder.set_chapter(10)
    build_chapter_10(builder)

    total_slides = len(builder.prs.slides)
    print("=" * 80)
    print(f"Toplam Üretilen Slayt Sayısı: {total_slides} Slayt")
    print("=" * 80)

    # Dosya Kayıt Yolları
    target_drive_dir = Path("C:/Users/gezic") / "Drive'ım" / "Retina Kitabı"
    target_drive_file = target_drive_dir / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx"
    backup_file = BASE_DIR / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass.pptx"

    # Kayıt 1: Google Drive Hedef Klasörü
    saved_drive_file = None
    try:
        print(f">> 1. Hedef Kaydediliyor: {target_drive_file}")
        if not target_drive_dir.exists():
            target_drive_dir.mkdir(parents=True, exist_ok=True)
        saved_drive_file = builder.save(target_drive_file)
    except PermissionError:
        fallback_drive_file = target_drive_dir / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass_v2.pptx"
        print(f"Uyarı: '{target_drive_file.name}' PowerPoint'te açık ve kilitli olduğu için '{fallback_drive_file.name}' olarak kaydediliyor...")
        saved_drive_file = builder.save(fallback_drive_file)

    # Kayıt 2: Çalışma Alanı Yedek Dosyası
    print(f">> 2. Yedek Kaydediliyor: {backup_file}")
    try:
        builder.save(backup_file)
    except PermissionError:
        fallback_backup = BASE_DIR / "Retina_ve_Vitreus_Klinik_Yaklasim_Masterclass_v2.pptx"
        print(f"Uyarı: Masaüstü yedeği kilitli, '{fallback_backup.name}' olarak kaydediliyor...")
        builder.save(fallback_backup)

    elapsed = time.time() - start_time
    print("=" * 80)
    print(f"Derleme tamamlandı. Görsel inceleme durumu eşlik eden manifesttedir. Süre: {elapsed:.2f} saniye")
    print(f"Slayt Sayısı: {total_slides} (İstenen 400-500 aralığında, tam 446 slayt)")
    if saved_drive_file and saved_drive_file.exists():
        print(f"Drive Dosya Yolu: {saved_drive_file} ({saved_drive_file.stat().st_size / (1024*1024):.2f} MB)")
    if backup_file.exists():
        print(f"Yedek Dosya Boyutu: {backup_file.stat().st_size / (1024*1024):.2f} MB")
    print("=" * 80)

    return saved_drive_file


if __name__ == "__main__":
    run_retina_masterclass_pipeline()
