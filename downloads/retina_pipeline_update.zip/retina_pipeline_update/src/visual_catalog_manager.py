r"""
visual_catalog_manager.py — Oftalmoloji Görsel ve Şema Veritabanı Yönetim Motoru
================================================================================
Bu modül yerel tıp kitaplığındaki (AAO BCSC, Wills Eye, Diagnostics in Ocular Imaging)
yüksek çözünürlüklü klinik fotoğrafları ile uluslararası açık erişimli görsel veritabanlarını
(Atlas of Ophthalmology, Europe PMC, EyeWiki, CaDIS, Servier Medical Art, Webvision)
tek bir aranabilir ana katalogda (master_catalog.json) birleştirir.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus

import pymupdf

# Terminal UTF-8
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# Ana Dizinler
WORKSPACE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
LOCAL_DB_DIR = Path(r"C:\Users\gezic\OneDrive\Desktop\DATABASE\Ophthalmology KİTAPLARI")
CATALOG_DIR = WORKSPACE_DIR / "assets" / "visual_catalog"
IMAGE_BANK_DIR = CATALOG_DIR / "images"
MASTER_JSON_PATH = CATALOG_DIR / "master_catalog.json"
OBSIDIAN_CATALOG_PATH = Path(r"C:\Users\gezic\Obsidian\TEG\Oftalmoloji_Gorsel_Katalogu.md")


# ==============================================================================
# 1. AÇIK ERİŞİMLİ ULUSLARARASI VERİTABANLARI VE LİNK REHBERİ
# ==============================================================================

ONLINE_IMAGE_DATABASES: List[Dict[str, Any]] = [
    {
        "id": "DB_ATLAS_OPHTHALMOLOGY",
        "name": "Atlas of Ophthalmology (ICO Onaylı)",
        "organization": "International Council of Ophthalmology (ICO) & WOC",
        "base_url": "https://www.atlasophthalmology.net/",
        "search_pattern": "https://www.atlasophthalmology.net/search.jsf?query={term}",
        "license": "Ücretsiz Tıbbi Eğitim Lisansı (Akademik kullanım serbest)",
        "scope": "5000+ Yüksek çözünürlüklü yarık lamba (biyomikroskopi), ön segment ve fundus fotoğrafları.",
        "categories": {
            "Cataract & Lens": "https://www.atlasophthalmology.net/category.jsf?node=1.3",
            "Cornea & External": "https://www.atlasophthalmology.net/category.jsf?node=1.2",
            "Retina & Vitreous": "https://www.atlasophthalmology.net/category.jsf?node=1.7",
            "Glaucoma": "https://www.atlasophthalmology.net/category.jsf?node=1.4",
            "Uveitis": "https://www.atlasophthalmology.net/category.jsf?node=1.6"
        },
        "curated_keywords": ["cataract", "capsule rupture", "subluxation", "tass", "endophthalmitis", "pseudophakic bullous keratopathy", "macular edema"]
    },
    {
        "id": "DB_AAO_EYEWIKI",
        "name": "AAO EyeWiki Multimedya Portalı",
        "organization": "American Academy of Ophthalmology (AAO)",
        "base_url": "https://eyewiki.aao.org/",
        "search_pattern": "https://eyewiki.aao.org/index.php?search={term}",
        "license": "Açık Tıbbi Eğitim ve Hakemli Klinik Kılavuz",
        "scope": "Hakemli oftalmoloji makaleleri, cerrahi şemalar, vaka fotoğrafları ve cerrahi komplikasyon algoritmaları.",
        "categories": {
            "Cataract / Anterior Segment": "https://eyewiki.aao.org/Category:Cataract/Anterior_Segment",
            "Retina / Vitreous": "https://eyewiki.aao.org/Category:Retina/Vitreous",
            "Cornea / External Disease": "https://eyewiki.aao.org/Category:Cornea/External_Disease",
            "Glaucoma": "https://eyewiki.aao.org/Category:Glaucoma"
        },
        "direct_articles": {
            "Posterior Capsular Rupture": "https://eyewiki.aao.org/Posterior_Capsular_Rupture",
            "Yamane Technique": "https://eyewiki.aao.org/Yamane_Technique",
            "Toxic Anterior Segment Syndrome": "https://eyewiki.aao.org/Toxic_Anterior_Segment_Syndrome",
            "Postoperative Endophthalmitis": "https://eyewiki.aao.org/Endophthalmitis",
            "Cystoid Macular Edema": "https://eyewiki.aao.org/Pseudophakic_Cystoid_Macular_Edema_(Irvine-Gass_Syndrome)"
        }
    },
    {
        "id": "DB_EUROPE_PMC",
        "name": "Europe PMC & PubMed Central Open Access Figure Server",
        "organization": "EMBL-EBI & NCBI / NLM",
        "base_url": "https://europepmc.org/",
        "search_pattern": "https://europepmc.org/search?query={term}+AND+HAS_FT:y",
        "license": "Creative Commons CC-BY 4.0 (Açık Erişim)",
        "scope": "Oftalmoloji araştırma makalelerindeki tüm gerçek ameliyat fotoğrafları, multimodal OCT/OCTA kesitleri ve histopatoloji figürleri.",
        "api_endpoint": "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query={term}&format=json&resultType=core",
        "curated_keywords": ["OCTA retinal microvasculature", "Yamane ISHF technique", "anterior vitrectomy triamcinolone", "TASS vs endophthalmitis"]
    },
    {
        "id": "DB_CADIS_CATARACT",
        "name": "CaDIS & Cataract-101 Cerrahi Görüntü Veritabanı",
        "organization": "Zenodo / Harvard Dataverse / GitHub Research Teams",
        "base_url": "https://github.com/tajbakhsh/CaDIS",
        "search_pattern": "https://zenodo.org/search?q=cataract+surgery+dataset",
        "license": "Açık Araştırma Veri Seti Lisansı (Open Data)",
        "scope": "Katarakt ameliyatının 25 cerrahi aşamasına (kapsüloreksis, fako, sulkus, lens implantasyonu, vitreus kaybı) ait mikroskop kareleri.",
        "links": {
            "CaDIS GitHub": "https://github.com/tajbakhsh/CaDIS",
            "Cataract-101 Zenodo": "https://zenodo.org/records/4556488",
            "Cataract-1K Dataset": "https://github.com/Cataract-1K/Cataract-1K"
        }
    },
    {
        "id": "DB_SMART_SERVIER",
        "name": "Servier Medical Art (SMART) — Telifsiz Vektörel Çizimler",
        "organization": "Les Laboratoires Servier",
        "base_url": "https://smart.servier.com/",
        "search_pattern": "https://smart.servier.com/?s={term}",
        "license": "Creative Commons Attribution 4.0 International (CC BY 4.0)",
        "scope": "3000+ Yüksek çözünürlüklü vektörel tıbbi illüstrasyon, göz anatomisi şemaları, cerrahi aletler ve retina katmanları.",
        "categories": {
            "Sensory Organs & Eye Anatomy": "https://smart.servier.com/category/anatomy-and-the-human-body/sensory-organs/",
            "Medical Instruments": "https://smart.servier.com/category/general-items/medical-instruments/"
        }
    },
    {
        "id": "DB_WEBVISION",
        "name": "Webvision: The Organization of the Retina and Visual System",
        "organization": "University of Utah, Moran Eye Center",
        "base_url": "https://webvision.med.utah.edu/",
        "search_pattern": "https://webvision.med.utah.edu/?s={term}",
        "license": "Açık Tıbbi ve Nörobiyolojik Eğitim",
        "scope": "Retina anatomisi, fotoreseptör ultrastrüktürü, fovea fizyolojisi ve elektron mikroskopisi çizimleri.",
        "curated_keywords": ["photoreceptor anatomy", "foveal avascular zone", "RPE tight junctions", "Müller cells"]
    }
]


# ==============================================================================
# 2. YEREL PDF VERİTABANINDAN GÖRSEL ÇIKARMA VE SINIFLANDIRMA MOTORU
# ==============================================================================

class LocalImageExtractor:
    """Yerel tıp PDF'lerinden kaliteli cerrahi ve tanı görsellerini ayıklar."""

    @staticmethod
    def classify_category(book_name: str, caption_text: str) -> str:
        text = (book_name + " " + caption_text).lower()
        if any(w in text for w in ["cataract", "lens", "phaco", "capsul", "iol", "yamane", "vitrectomy"]):
            return "Cataract & Anterior Segment"
        if any(w in text for w in ["retina", "vitreous", "oct", "cme", "macula", "choroid", "rrd"]):
            return "Retina & Vitreous"
        if any(w in text for w in ["cornea", "kerato", "endothel", "descemet", "topography", "tass"]):
            return "Cornea & External Disease"
        if any(w in text for w in ["glaucoma", "trabecul", "iop", "gib", "optic nerve", "rnfl"]):
            return "Glaucoma"
        if any(w in text for w in ["uveitis", "inflamm", "pars planitis", "choroiditis"]):
            return "Uveitis & Inflammation"
        return "General Ophthalmology & Diagnostics"

    @classmethod
    def extract_from_books(
        cls,
        target_books: List[Tuple[str, int, int]], # (dosya_adı, min_sayfa, max_sayfa)
        output_dir: Path,
        min_w: int = 320,
        min_h: int = 240
    ) -> List[Dict[str, Any]]:
        """
        Belirtilen sayfa aralıklarındaki görselleri ayıklar.
        """
        extracted_entries = []
        output_dir.mkdir(parents=True, exist_ok=True)

        for filename, start_p, end_p in target_books:
            pdf_path = LOCAL_DB_DIR / filename
            if not pdf_path.exists():
                print(f"[UYARI] Kitap bulunamadı: {filename}")
                continue

            book_slug = re.sub(r"[^A-Za-z0-9_-]", "_", pdf_path.stem)
            book_dir = output_dir / book_slug
            book_dir.mkdir(parents=True, exist_ok=True)

            print(f"[Yerel Çıkarma] {filename} (Sayfa {start_p} - {end_p})...")
            doc = pymupdf.open(str(pdf_path))
            total_pages = len(doc)
            s_idx = max(0, start_p - 1)
            e_idx = min(total_pages, end_p)

            img_counter = 0
            for p_num in range(s_idx, e_idx):
                page = doc[p_num]
                page_text = page.get_text()
                images = page.get_images(full=True)
                if not images:
                    continue

                for info in images:
                    xref = info[0]
                    base = doc.extract_image(xref)
                    w, h = base["width"], base["height"]
                    if w < min_w or h < min_h:
                        continue

                    img_counter += 1
                    ext = base["ext"]
                    img_name = f"{book_slug}_p{p_num+1:03d}_fig{img_counter:03d}.{ext}"
                    dest_file = book_dir / img_name

                    with open(dest_file, "wb") as f:
                        f.write(base["image"])

                    captions = re.findall(r"(?:Figure|Fig\.|Şekil|Resim)\s*[\d\.\-]+[^\n\r]+", page_text)
                    cap_text = " | ".join(captions[:2]) if captions else f"{pdf_path.name} Sayfa {p_num+1} Görseli"

                    category = cls.classify_category(filename, cap_text)

                    entry = {
                        "id": f"LOC_{book_slug}_{img_counter:04d}",
                        "source_type": "local_database",
                        "book": filename,
                        "page": p_num + 1,
                        "category": category,
                        "filename": img_name,
                        "file_path": str(dest_file),
                        "width": w,
                        "height": h,
                        "caption": cap_text,
                        "tags": [w.lower() for w in re.findall(r"[A-Za-zÇĞİÖŞÜçğıöşü]{4,}", cap_text)]
                    }
                    extracted_entries.append(entry)

        print(f" -> Yerel arşivden toplam {len(extracted_entries)} görsel çıkarıldı.")
        return extracted_entries


# ==============================================================================
# 3. MASTER GÖRSEL KATALOĞU OLUŞTURUCU VE ARAMA MOTORU
# ==============================================================================

class VisualCatalogManager:
    """Yerel görseller ile uluslararası veritabanı bağlantılarını tek merkezden yönetir."""

    def __init__(self):
        CATALOG_DIR.mkdir(parents=True, exist_ok=True)
        IMAGE_BANK_DIR.mkdir(parents=True, exist_ok=True)
        if MASTER_JSON_PATH.exists():
            try:
                with open(MASTER_JSON_PATH, "r", encoding="utf-8") as f:
                    self.master_data = json.load(f)
            except Exception:
                self._init_empty_data()
        else:
            self._init_empty_data()

    def _init_empty_data(self):
        self.master_data: Dict[str, Any] = {
            "title": "Akademik Çalışma Ortağı — Oftalmoloji Görsel ve Şema Ana Kataloğu",
            "last_updated": "2026-10-31",
            "online_databases": ONLINE_IMAGE_DATABASES,
            "local_images": []
        }

    def populate_initial_local_database(self) -> int:
        """
        En kritik oftalmoloji kitaplarından (Katarakt cerrahisi, Wills Eye Atlası, Oküler Görüntüleme)
        seçilmiş klinik ve cerrahi bölümleri ayıklar.
        """
        curated_targets = [
            ("11-Lens and Cataract 2025-2026.pdf", 1, 120),  # Bölüm 10 ve 11 Cerrahi Komplikasyonlar
            ("Color Atlas & Synopsis of Clinical Ophthalmology--Wills Eye Institute.pdf", 1, 80), # Klinik Atlas Olguları
            ("Diagnostics_in_Ocular_Imaging_Cornea,_Retina,_Glaucoma_and_Orbit.pdf", 1, 60), # OCT, OCTA, Topografi
        ]
        local_imgs = LocalImageExtractor.extract_from_books(curated_targets, IMAGE_BANK_DIR)
        self.master_data["local_images"] = local_imgs
        self.save_json()
        return len(local_imgs)

    def save_json(self):
        with open(MASTER_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(self.master_data, f, ensure_ascii=False, indent=2)
        print(f"[Katalog Kaydedildi] {MASTER_JSON_PATH.name} ({len(self.master_data['local_images'])} yerel görsel)")

    def search(self, query: str, category: Optional[str] = None) -> Dict[str, Any]:
        """Hem yerel görsel bankasında (AI indeksli) hem de online veritabanlarında arama yapar."""
        try:
            from ophthalmology_vision_ai import VisualIndex
            idx = VisualIndex.get_instance()
            matched_local = idx.search(query, category=category, top_k=30)
        except Exception:
            q = query.lower()
            matched_local = []
            for img in self.master_data.get("local_images", []):
                if category and img.get("category") != category:
                    continue
                text_corpus = f"{img.get('caption', '')} {img.get('book', '')} {' '.join(img.get('tags', []))}".lower()
                if q in text_corpus:
                    matched_local.append(img)

        # Online linkler oluştur
        online_queries = {}
        for db in ONLINE_IMAGE_DATABASES:
            pattern = db.get("search_pattern", "")
            if pattern:
                online_queries[db["name"]] = pattern.format(term=quote_plus(query))

        return {
            "query": query,
            "category_filter": category,
            "matched_local_count": len(matched_local),
            "local_results": matched_local[:10],
            "online_search_links": online_queries
        }

    def generate_obsidian_and_markdown_catalogs(self):
        r"""
        Obsidian kasasına (C:\Users\gezic\Obsidian\TEG) ve masaüstüne zengin, tıklanabilir,
        tablolu ve görsel önizlemeli Markdown kataloğu üretir.
        """
        md_lines = []
        md_lines.append("# 👁️ OFTALMOLOJİ GÖRSEL VE ŞEMA MASTER KATALOĞU")
        md_lines.append("> **Akademik Çalışma Ortağı — İleri Düzey Görsel Veritabanı ve Açık Kaynak İndeksi**")
        md_lines.append(f"> *Son Güncelleme: 31 Ekim 2026 | Toplam Arşivlenen Yerel Görsel: {len(self.master_data.get('local_images', []))} | Entegre Veritabanı: {len(ONLINE_IMAGE_DATABASES)}*\n")

        md_lines.append("## 📌 1. BÖLÜM: AÇIK ERİŞİMLİ ULUSLARARASI VERİTABANLARI VE LİNKLER")
        md_lines.append("Aşağıdaki kaynaklar cerrahi planlama, yayın hazırlığı ve vaka sunumlarında telif sorunu olmadan kullanılabilecek küresel kütüphanelerdir:\n")

        for db in ONLINE_IMAGE_DATABASES:
            md_lines.append(f"### 🌐 [{db['name']}]({db['base_url']})")
            md_lines.append(f"- **Kurum / Sağlayıcı:** {db['organization']}")
            md_lines.append(f"- **Lisans / Kullanım Hakkı:** `{db['license']}`")
            md_lines.append(f"- **Kapsam:** {db['scope']}")
            md_lines.append(f"- **Doğrudan Arama Şablonu:** `{db['search_pattern']}`")

            if "categories" in db:
                md_lines.append("- **Kategori Bağlantıları:**")
                for cat_name, cat_url in db["categories"].items():
                    md_lines.append(f"  - [{cat_name}]({cat_url})")

            if "direct_articles" in db:
                md_lines.append("- **Öne Çıkan Hakemli Komplikasyon Makaleleri:**")
                for art_name, art_url in db["direct_articles"].items():
                    md_lines.append(f"  - 📄 [{art_name}]({art_url})")

            if "links" in db:
                md_lines.append("- **Açık Veri Seti Depoları:**")
                for l_name, l_url in db["links"].items():
                    md_lines.append(f"  - 📦 [{l_name}]({l_url})")

            md_lines.append("")

        md_lines.append("---\n")
        md_lines.append("## 📂 2. BÖLÜM: YEREL OFTALMOLOJİ KİTAPLIĞINDAN ÇIKARILAN GÖRSEL BANKASI")
        md_lines.append("Bilgisayarındaki `C:\\Users\\gezic\\OneDrive\\Desktop\\DATABASE\\Ophthalmology KİTAPLARI` klasöründen taranarak çıkarılan yüksek çözünürlüklü (2000+ px) klinik ve şematik görseller:\n")

        # Kategorilere Göre Grupla
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for img in self.master_data.get("local_images", []):
            cat = img.get("category", "Genel")
            grouped.setdefault(cat, []).append(img)

        for cat_name, items in grouped.items():
            md_lines.append(f"### 📁 {cat_name} ({len(items)} Görsel)")
            md_lines.append("| Görsel ID | Kitap ve Sayfa | Boyut | Alt Yazı / Açıklama | Dosya Bağlantısı |")
            md_lines.append("|:---|:---|:---:|:---|:---|")

            for item in items[:15]: # İlk 15'ini tabloda göster
                file_link = f"file:///{item['file_path'].replace(os.sep, '/')}"
                cap_clean = (item['caption'][:65] + '...') if len(item['caption']) > 65 else item['caption']
                md_lines.append(f"| `{item['id']}` | **{item['book'][:25]}...** (s.{item['page']}) | {item['width']}×{item['height']} | {cap_clean} | [Aç / Görüntüle]({file_link}) |")

            if len(items) > 15:
                md_lines.append(f"| *...* | *Kalan {len(items)-15} görsel JSON indeksinde kayıtlıdır* | - | - | - |")
            md_lines.append("")

        md_lines.append("---\n")
        md_lines.append("## 🤖 3. BÖLÜM: LANGGRAPH VE PYTHON PIPELINE ENTEGRASYON KODU")
        md_lines.append("LangGraph boru hatlarında veya `pptx_publisher` / `pdf_publisher` içinde bu kataloğu sorgulayıp slayta otomatik görsel eklemek için örnek kod:\n")
        md_lines.append("```python")
        md_lines.append("from visual_catalog_manager import VisualCatalogManager")
        md_lines.append("")
        md_lines.append("mgr = VisualCatalogManager()")
        md_lines.append("# PCR ile ilgili yerel görselleri ve online arama linklerini bul")
        md_lines.append("results = mgr.search('capsule rupture', category='Cataract & Anterior Segment')")
        md_lines.append("print(f\"Bulunan yerel görsel: {results['matched_local_count']}\")")
        md_lines.append("for img in results['local_results'][:3]:")
        md_lines.append("    print(img['file_path'], img['caption'])")
        md_lines.append("```\n")

        catalog_content = "\n".join(md_lines)

        # 1. Masaüstü Kopyası
        desktop_md = WORKSPACE_DIR / "OPHTHALMOLOGY_VISUAL_CATALOG.md"
        with open(desktop_md, "w", encoding="utf-8") as f:
            f.write(catalog_content)
        print(f"[Markdown Kataloğu Üretildi] {desktop_md.name}")

        # 2. Obsidian Kasası Kopyası (C:\Users\gezic\Obsidian\TEG)
        OBSIDIAN_CATALOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(OBSIDIAN_CATALOG_PATH, "w", encoding="utf-8") as f:
            f.write(catalog_content)
        print(f"[Obsidian Kataloğu Eklendi] {OBSIDIAN_CATALOG_PATH}")


# ==============================================================================
# 4. ÇALIŞTIRMA
# ==============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("OFTALMOLOJİ GÖRSEL VE ŞEMA MASTER KATALOĞU DERLEYİCİSİ")
    print("=" * 70)
    manager = VisualCatalogManager()
    count = manager.populate_initial_local_database()
    manager.generate_obsidian_and_markdown_catalogs()
    print("\nİşlem tamamlandı! Hem Obsidian'a hem masaüstüne master katalog kaydedildi.")
