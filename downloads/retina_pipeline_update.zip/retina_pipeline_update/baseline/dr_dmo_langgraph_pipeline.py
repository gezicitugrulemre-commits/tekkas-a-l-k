# -*- coding: utf-8 -*-
"""
Diyabetik Retinopati ve Diyabetik Maküla Ödemi (DR & DMÖ)
3-Katmanlı LangGraph + Gemini Akademik Çalışma Rehberi ve Pro PDF Üretim Hattı
===============================================================================
Kaynak: Güncel Retina 2018;2(2):89-207 (15 Derleme Makalesi, 96 Sayfa Tam Metin)
Mimari:
  - Katman 1 (Flash Reader - gemini-3.8-flash): PyMuPDF ile çıkarılan kaynak sayfalardan
    mekanizma, sayısal RKÇ verisi, sınıflama ve istisnaları çıkarır (`bookgraph.llm.ask`).
  - Katman 2 (Argon Academic Author - gemini-4-argon): AGENTS.md pedagojik kurallarına uygun
    (Temel Kavram -> Mekanizma -> Neden-Sonuç -> Klinik Uygulama & İstisnalar,
    Hasta Düzeyi vs Göz Düzeyi GEE/ICC ayrımı, Aktif Hatırlama Soruları) modül yazar.
  - Katman 3 (Senior Reviewer - gemini-3.8-flash / gemini-4-argon): Kaynak sadakati,
    sıfır uydurma veri, derinlik ve doğal Akademik Türkçe denetimi yapar; gerekirse revize ettirir.
  - Dizgi Motoru (ReportLab Pro + PyMuPDF Bookmarks + 1600x620 PIL Şemalar & Gerçek Klinik Görüntüler):
    Aktif hatırlama sorularını ve ayrıntılı cevap anahtarını en altta bağımsız bölümler olarak basar.
"""

from __future__ import annotations

import html
import json
import operator
import os
import re
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, Dict, List, Optional, Tuple, TypedDict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import pymupdf
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send
from pydantic import BaseModel, Field
from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from bookgraph import usage as bg_usage
from bookgraph.core import RETRY, emit, open_cache
from bookgraph.llm import ask
from dr_dmo_research_sources import (
    fetch_local_db_evidence_for_module,
    fetch_pubmed_landmark_evidence_for_module,
)
from generate_dr_dmo_visuals import build_all_dr_dmo_visuals
from langgraph_auditor import academic_turkish_humanizer_node, audit_langgraph_pipeline
from part3_ch11_atlas_data import ATLAS_SLIDES_DATA
from quota_manager import QuotaAndWPSManager

BOOK_ID = "dr_dmo_2026_v2"
UPLOADED_PDF = Path(
    r"C:/Users/gezic/.gemini/antigravity/brain/56e8379f-a5d9-4c72-816a-59ef8c86cb6b/.user_uploaded/media_1793432508741_09581a77.pdf"
)
LEGACY_SOURCE_PDF = BASE_DIR / "storage" / "dr_dmo" / "Guncel_Retina_2018_2_2_DR_DMO_Kaynak.pdf"
STORAGE_DR_DIR = BASE_DIR / "storage" / "dr_dmo_v2"
ARCHIVED_SOURCE_PDF = STORAGE_DR_DIR / "Guncel_Retina_2018_2_2_DR_DMO_Kaynak.pdf"

OUT_PDF_MAIN = BASE_DIR / "Diyabetik_Retinopati_ve_DMO_Kapsamli_Calisma_Rehberi.pdf"
OUT_PDF_COMPILED = BASE_DIR / "output" / "compiled" / "Diyabetik_Retinopati_ve_DMO_Kapsamli_Calisma_Rehberi.pdf"
OUT_MD_COMPILED = BASE_DIR / "output" / "compiled" / "Diyabetik_Retinopati_ve_DMO_Kapsamli_Calisma_Rehberi.md"
OUT_PDF_OBSIDIAN = Path(r"C:/Users/gezic/Obsidian/TEG/Diyabetik_Retinopati_ve_DMO_Kapsamli_Calisma_Rehberi.pdf")


# ============================================================================
# 1. KAYNAK MAKALE HARİTASI VE 8 MODÜL MİMARİSİ (96 SAYFA / 15 MAKALE TAM KAPSAM)
# ============================================================================

ARTICLES_SPEC = [
    (1, 1, 5, "89-93", "Koçak N.", "DR ve DMÖ'de Epidemiyoloji ve Risk Faktörleri"),
    (2, 6, 13, "94-101", "Kerimoğlu H, Türk HB.", "DR ve DMÖ'de Patogenez"),
    (3, 14, 19, "102-107", "Demircan S, Pangal E.", "DR ve DMÖ'de Sistemik ve Genetik Risk Faktörleri"),
    (4, 20, 30, "108-118", "Artunay Ö, Yüzbaşıoğlu E, Rasier R, Şengül A.", "DR ve DMÖ'de Tarama, Takip ve Tedavi Algoritması"),
    (5, 31, 35, "119-123", "Arvas S, Yılmaz Çebi A.", "DR ve DMÖ'de Klinik Tanı ve Yeni Sınıflandırmalar"),
    (6, 36, 43, "130-137", "Durlu YK, Kavadarlı I.", "DR ve DMÖ'de Floresein Anjiyografi ve OKTA Bulguları"),
    (7, 44, 48, "138-142", "Özdemir H, Ekinci C.", "DR ve DMÖ'de Optik Koherens Tomografi Bulguları"),
    (8, 49, 52, "143-146", "Uçar D, Yıldırım Y, Hepokur M.", "DR ve DMÖ'de Ranibizumab Tedavisi ve Tedavi Rejimleri"),
    (9, 53, 60, "147-154", "Temel E, Şermet F.", "DR ve DMÖ'de Aflibercept Tedavisi"),
    (10, 61, 65, "160-164", "Şatırtav G.", "Diyabetik Maküla Ödeminde Steroid Tedavisi"),
    (11, 66, 70, "165-169", "Oruç Dündar S, Çakmak H.", "DMÖ'de Anti-VEGF'e Yanıtsızlık, Direnç, Switch ve Kombine Tedaviler"),
    (12, 71, 78, "177-184", "Çıtırık M, Teke MY.", "DMÖ'de Eşik Altı Lazer ve Subliminal (Mikropulse) Lazer Tedavisi"),
    (13, 79, 82, "185-188", "Uçgun Nİ, Zeki Fikret C.", "DR ve DMÖ Tedavisinde Yeni Gelişmeler ve Yeni İlaçlar"),
    (14, 83, 90, "194-201", "Durukan AH, Mumcuoğlu T, Gökçe G.", "DMÖ ve Diyabetik Vitreus İçi Hemorajilerde Cerrahi Tedavi"),
    (15, 91, 96, "202-207", "Kapran Z, Sayın N.", "Rekürren Vitreus İçi Hemorajiler ve Traksiyonel Retina Dekolmanında Cerrahi Tedavi"),
]

MODULES_PLAN: List[Dict[str, Any]] = [
    {
        "module_id": "M01",
        "kicker": "BÖLÜM 1 · MAKALE 1 & 3 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "EPİDEMİYOLOJİ, SİSTEMİK KONTROL, FENOFİBRAT (LENS) VE GLP-1RA / GENETİK RİSK MİMARİSİ",
        "subtitle": "Küresel DR Yükü, DCCT/EDIC Metabolik Hafıza, UKPDS, FIELD/ACCORD/LENS Fenofibrat Kanıtı, Semaglutid Erken Kötüleşmesi ve Epigenetik",
        "article_nos": [1, 3],
        "visual_keys": ["schema_0_epi_metabolic"],
        "focus_points": (
            "Tip 1 vs Tip 2 DM prevalans, diyabet süresi etkisi (WESDR, Türkiye Taş ve İdil verileri) ve güncel küresel DR yükü (Teo ve ark. 2021 meta-analizi); "
            "DCCT (%76 yeni DR azalması, %54 progresyon azalması, erken kötüleşme fenomeni ve EDIC epigenetik metabolik hafıza), UKPDS (%1 HbA1c düşüşü = %35 mikrovasküler risk azalması, sıkı KB kontrolü %34 progresyon azalması), ACCORD hipoglisemi/mortalite sınırı; "
            "Fenofibrat kanıt üçlemesi: FIELD, ACCORD-Eye ve güncel LENS RKÇ (2024: fenofibrat ile sevk edilebilir DR/makülopati veya tedavi ihtiyacında azalma — serum lipid düşüşünden bağımsız PPAR-alfa mekanizması); "
            "GLP-1 reseptör agonistleri / Semaglutid (SUSTAIN-6 ve güncel kohort/FOCUS analizleri): hızlı HbA1c düşüşüne bağlı paradoksal 'erken kötüleşme' mekanizması ve tedavi öncesi bazal fundus kontrolü kuralı; "
            "RAS inhibitörleri (EUCLID, DIRECT, RASS), nefropati/albüminüri, anemi/EPO, obstrüktif uyku apnesi (OUA); "
            "Genetik polimorfizmler (VEGFA, ALR2 Z-2/rs759853, eNOS, RAGE, EPO, SOD2; Güncel Retina 2026 oküler genetik derlemesi) ve epigenetik mekanizmalar (BCOR DNA metilasyonu, SUV39H2, miR-126 ve miR-146a)."
        ),
    },
    {
        "module_id": "M02",
        "kicker": "BÖLÜM 2 · MAKALE 2 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "NÖROVASKÜLER ÜNİTE HASARI, ANG-2 / TIE-2 EKSENİ VE KAN-RETİNA BARİYERİ PATOGENEZİ",
        "subtitle": "Erken Nörodejenerasyon, Perisit Apoptozu, 4 Biyokimyasal Yolak, Ang-2/Tie-2 Destabilizasyonu, Lökostaz ve Müller (Kir4.1/AQP4) İflası",
        "article_nos": [2],
        "visual_keys": ["schema_1", "panel_dme_brb_oct"],
        "focus_points": (
            "Retinal Nörovasküler Ünite (NVÜ) kavramı ve erken nörodejenerasyon: klinik mikroanevrizmalardan önce başlayan ganglion/amakrin hücre apoptozu, GCL/RNFL incelmesi, glutamat eksitotoksisitesi ve Müller/mikroglial aktivasyon; "
            "Mikrovasküler histopatolojik sıra: perisit apoptozu (1:1 perisit:endotel oranının bozulması, PDGF-beta azalması), Anjiyopoietin-2 (Ang-2) artışı ile endotelyal Tie-2 reseptör inaktivasyonu ve perisit ayrılması, bazal membran kalınlaşması, hipersellüler/asellüler mikroanevrizmalar ve asellüler kapillerler; "
            "4 ana hiperglisemik yolak: 1) Polyol yolağı (aldoz redüktaz, sorbitol, NADPH/GSH tükenmesi, sorbinil başarısızlığı), 2) AGE-RAGE etkileşimi (NF-kB/ROS), 3) Protein Kinaz C (DAG -> PKC-beta1/2, eNOS azalması, ET-1 ve VEGF artışı, ruboksitaurin), 4) Heksozamin yolağı ve mitokondriyal süperoksit/PARP-GAPDH ekseni; "
            "İnflamasyon ve lökostaz: ICAM-1 ve CD11/18 integrin aracılı lökosit yapışması, Fas-FasL endotel apoptozu, IL-6, IL-1beta, TNF-alfa, MCP-1; "
            "İç KRB (okludin, klaudin-5, ZO-1 sıkı bağlantıları ve veziküler transport) vs Dış KRB (RPE), VEGF-A165/VEGFR-2/PlGF, Starling yasası ve Müller hücrelerinde Kir4.1 potasyum ile AQP4 su kanalı disfonksiyonu."
        ),
    },
    {
        "module_id": "M03",
        "kicker": "BÖLÜM 3 · MAKALE 4 & 5 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "KLİNİK TANI, SINIFLANDIRMALAR, PROTOKOL V & W VE OTONOM YAPAY ZEKA TARAMASI",
        "subtitle": "ETDRS 4:2:1 Kuralı, IRMA vs NVE, ICO/EURETINA Santral 1 mm DMÖ, Protokol V (GK ≥20/25), Protokol W (NPDR) ve Katarakt/Gebelik Yönetimi",
        "article_nos": [4, 5],
        "visual_keys": ["panel_etdrs_421_uwfa", "panel_hr_pdr_nvd_nve"],
        "focus_points": (
            "Tip 1 DM (tanıdan 5 yıl sonra) vs Tip 2 DM (tanı anında derhal) ilk tarama zamanlaması, gebelik takibi (gestasyonel DM'de rutin tarama gerekmemesi istisnası!) ve diyabetik hastada katarakt cerrahisi perioperatif yönetimi (Güncel Retina 2025 NPDR/PDR + katarakt stratejileri, diyabetik papillopati ayırıcı tanısı); "
            "ETDRS ve ICO uluslararası DR sınıflaması: Hafif, Orta, Ağır NPDR (4:2:1 kuralı -> 1 yılda %15-50 PDR riski) ve Yüksek Riskli PDR kriterleri; IRMA (ILM'yi delmez, geç FA'da yoğun sızdırmaz) vs NVD/NVE ayrımı; "
            "ETDRS KAMÖ'den (CSME) OKT temelli Merkezi Tutmayan vs Merkezi Tutan DMÖ (santral 1 mm) sınıflamasına geçiş; "
            "DRCR.net Protokol V (JAMA 2019): görme keskinliği iyi (≥20/25) merkezi tutan DMÖ'de başlangıç gözlem vs fokal lazer vs aflibercept (2 yılda görme keskinliği farkı yok; GK düşmedikçe gözlem güvenli!); "
            "DRCR.net Protokol W (2 ve 4 yıllık sonuçlar): DMÖ olmayan orta-ağır NPDR'de profilaktik aflibercept anatomik PDR/DMÖ gelişimini azaltsa da 4 yılda görme keskinliği üstünlüğü sağlamaması; "
            "FDA onaylı otonom yapay zeka (AI) DR tarama sistemleri (IDx-DR / LumineticsCore, EyeArt) duyarlılık/özgüllük mantığı ve sınırları; "
            "Türkiye sağlık sisteminde (Aile Sağlığı Merkezleri [ASM] birinci basamak triyajı, Sağlık Bakanlığı Teletıp entegrasyonu, SGK/SUT kuralları ve üçüncü basamağa sevk yükünü azaltma potansiyeli) yerel pratik uygulanabilirlik ve altyapı gereksinimleri."
        ),
    },
    {
        "module_id": "M04",
        "kicker": "BÖLÜM 4 · MAKALE 6 & 7 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "MULTİMODAL GÖRÜNTÜLEME: FA, ULTRA-GENİŞ AÇILI FA (PROTOKOL AA), YAPISAL OKT VE OKTA",
        "subtitle": "UWFA Periferik Lezyonlar (PPL), Otani OKT Paternleri, Foveal DRIL (>1 mm), HRF, ELM/EZ ve Geniş Açılı SS-OKTA Pleksus Analizi",
        "article_nos": [6, 7],
        "visual_keys": ["schema_2", "panel_octa_faz_dril"],
        "focus_points": (
            "Floresein Anjiyografi (FA) optik prensipleri (465-490 nm uyarım, 520-530 nm emisyon, %80 albümine bağlı), hipo/hiperflöresans mekanizmaları, güvenlik/yan etki sıklıkları (1/2000 ciddi, ~1/222.000 ölüm, gebelik/emzirme/böbrek sınırları); "
            "Ultra-Geniş Açılı FA (UWFA — 200 derece görüntüleme) ve DRCR.net Protokol AA (2022): periferik ağırlıklı lezyonlar (predominantly peripheral lesions - PPL) ve periferik retinal nonperfüzyon alanlarının 4 yıllık ≥2 basamak DR progresyonunu ve PDR gelişimini bağımsız öngörmesi; "
            "OKTA fiziği ve güncel geniş açılı (widefield) SS-OKTA gelişmeleri: SD-OKTA (840 nm, yavaş akımlı mikroanevrizmaların ~%62'si) vs SS-OKTA (1050 nm, geniş açılı montajla boyasız NVE ve nonperfüzyon saptama), SCP vs DCP (DCP'de daha erken iskemi ve FAZ genişlemesi), projeksiyon/hareket artefaktları; "
            "Yapısal OKT Otani tipleri (diffüz süngerimsi şişme, KMÖ, seröz maküla dekolmanı %15-30) ve Kistoid Ödem vs Kistoid Dejenerasyon ayrımı; "
            "Prognostik OKT biyobelirteçleri: sert eksüda arka gölgelenmesinin seröz PED ile karıştırılması tuzağı, hiperreflektif odaklar (HRF <30 µm, gölgesiz mikroglial/inflamatuvar belirteç), VMA/VMT/ERM, ELM/EZ bütünlüğü ve santral 1 mm'de >%50 DRIL varlığının anti-VEGF/steroid yanıtı üzerindeki bağımsız belirleyiciliği."
        ),
    },
    {
        "module_id": "M05",
        "kicker": "BÖLÜM 5 · MAKALE 8 & 9 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "İNTRAVİTREAL ANTİ-VEGF FARMAKOTERAPİSİ, PROTOKOL T 5-YIL VE PROTOKOL AC (STEP-THERAPY)",
        "subtitle": "Ranibizumab, Aflibercept ve Bevacizumab Moleküler Kinetiği; RESTORE, RIDE/RISE, VISTA/VIVID, Protokol I/S/T 5-Yıl ve Protokol AC",
        "article_nos": [8, 9],
        "visual_keys": ["schema_3", "panel_dme_ci_nci_prp"],
        "focus_points": (
            "VEGF ailesi ve moleküler farmakokinetik: Ranibizumab (48 kDa Fab, Fc yok, hızlı sistemik klirens) vs Bevacizumab (149 kDa IgG1, FcRn aracılı sistemik VEGF baskılanması, off-label bölünmüş enjektör/compounding güvenliği) vs Aflibercept 2 mg (115 kDa VEGFR1/2 tuzak füzyon proteini, VEGF-A + VEGF-B + PlGF blokajı); "
            "Klasik ruhsat ve rejim RKÇ'leri: RESOLVE, RESTORE, RETAIN (Treat-and-Extend vs PRN), RIDE/RISE (0.3 vs 0.5 mg, 36 ay), DA VINCI ve VISTA/VIVID (2q4 vs 2q8w, tek çalışma gözü [patient-level] tasarımı); "
            "DRCR.net Protokol I (5 yıllık sonuçlar: ertelenmiş lazerin erken lazere üstünlüğü ve yıllar içinde azalan enjeksiyon sayısı) ve Protokol S 5-Yıl (PDR'de ranibizumab vs PRP uzun dönem görme, görme alanı, TRD/DMÖ farkı ve takipten kopan [loss to follow-up] PDR hastalarında ağır görme kaybı tuzağı!); "
            "DRCR.net Protokol T (1., 2. ve 5. yıl uzatma sonuçları: başlangıç GK ≥69 harf [20/32-20/40] eşdeğerliği vs GK <69 harf [≤20/50] grubunda 1. yıl aflibercept üstünlüğü, 2. yıl ranibizumab yakınsaması ve 2-5. yıl standart klinik pratikte anatomik korunmaya karşın görsel gerileme dersi); "
            "DRCR.net Protokol AC (NEJM 2022, orta-ciddi görme kayıplı DMÖ GK 20/50-20/320): önce bevacizumab başlanıp yanıtsızlıkta (~%70 hasta) aflibercept'e basamaklı geçişin (step-therapy) 2 yıllık görme keskinliğinde doğrudan aflibercept monoterapisine eşdeğerliği; oküler ve sistemik APTC güvenliği."
        ),
    },
    {
        "module_id": "M06",
        "kicker": "BÖLÜM 6 · MAKALE 10 & 11 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "KORTİKOSTEROİD TEDAVİSİ, ANTİ-VEGF DİRENCİ, PROTOKOL U VE ERKEN SWITCH STRATEJİLERİ",
        "subtitle": "DEX vs TA vs Fluosinolon Farmakokinetik Paradoksu (MEAD, CHAMPLAIN, BEVORDEX, FAME, PALADIN), Protokol U ve İnflamatuvar Fenotip Switch",
        "article_nos": [10, 11],
        "visual_keys": ["schema_6_steroid_switch", "panel_oct_dril_vmt"],
        "focus_points": (
            "Kortikosteroidlerin çok hedefli mekanizması (PLA2 inhibisyonu, ICAM-1/lökostaz baskılanması, IL-6/MCP-1 azalması, okludin/ZO-1 onarımı, Müller ödemi azalması) ve Farmakokinetik Paradoks (GR afinitesi DEX > TA > FA iken suda çözünmezlik/serbest yarı ömür TA > FA > DEX -> PLGA implant gereksinimi); "
            "Triamsinolon Asetonid (Protokol B ve Protokol I psödofak alt grup analizi), Deksametazon 0.7 mg implant / Ozurdex (PLACID, MEAD 3 yıl, CHAMPLAIN vitrektomize göz etkinliği, BEVORDEX) ve MUTLAK kontrendikasyonlar (yırtık arka kapsül / afaki / ön kamara veya skleral/iris fiksasyonlu GİL -> ön kamaraya migrasyon ve kalıcı kornea endotel dekompansasyonu!); "
            "Fluosinolon Asetonid 0.19 mg / Iluvien: FAME (36 ay; ≥3 yıl kronik DMÖ'de belirgin üstünlük) ve güncel PALADIN 36 aylık gerçek yaşam çalışması (tedavi yükünde azalma ve öncül steroid provokasyon testiyle öngörülebilir GİB güvenliği); "
            "Anti-VEGF direnci / persistan DMÖ tanımları, taşiflaksi vs tolerans, anti-VEGF içi değişim ve DRCR.net Protokol U (JAMA Ophthalmol 2018: persistan DMÖ'de ranibizumaba deksametazon implant eklenmesinin anlamlı anatomik incelme sağlaması ve psödofak alt gruptaki görsel eğilim); "
            "Güncel 2020-2026 'Erken Switch' kanıtları: OKT'de inflamatuvar biyobelirteç dörtlüsü (subfoveal seröz dekolman, çoklu HRF, dev santral kist, kronik ödem) olan gözlerde 3-6 anti-VEGF sonrası geç kalmadan deksametazon implantına geçişin gecikmiş switch'e anatomik ve fonksiyonel üstünlüğü."
        ),
    },
    {
        "module_id": "M07",
        "kicker": "BÖLÜM 7 · MAKALE 12 & 13 + AAO BCSC 2024 + PUBMED (2019-2026) SENTEZİ",
        "title": "SUBLİMİNAL MİKROPULSE LAZER (DIAMOND) VE YENİ NESİL BİYOLOJİKLER (FARİCİMAB & AFLİBERCEPT 8 MG)",
        "subtitle": "577 nm %5 Görev Döngüsü, HSP70, DIAMOND RKÇ; Faricimab (YOSEMITE/RHINE), Aflibercept 8 mg (PHOTON), PDS Susvimo ve Brolucizumab Güvenliği",
        "article_nos": [12, 13],
        "visual_keys": ["schema_4", "schema_7_nextgen_2026"],
        "focus_points": (
            "Konvansiyonel ETDRS lazerin sınırları (yıllık %16 skar genişlemesi, parasantral skotom, KNV), retinal kromofor fiziği (577 nm sarı dalga boyunun maküler ksantofilde sıfıra yakın emilimi ve melanin/oksihemoglobin seçiciliği); "
            "PASCAL Endpoint Management (NRT %30) vs 577 nm Subliminal Mikropulse (%5 görev döngüsü: 100 µs açık / 1900 µs kapalı, HSP70 uyarımı, izsiz konfluent uygulama), kritik MFK ≤400 µm kuralı ve güncel DIAMOND Faz 3 RKÇ (Ophthalmology 2023: MFK <400 µm DMÖ'de 577 nm mikropulse lazerin standart eşik lazere klinik eşdeğerliği ve güvenliği); "
            "2018'den 2026'ya Devrimsel İlaç Güncellemesi — 1) Faricimab 6.0 mg (YOSEMITE & RHINE Faz 3 ve RHONE-X 4 yıllık uzatma): CrossMAb teknolojili ilk bispesifik IgG1 antikoru (VEGF-A + Ang-2 ikili blokajı, Tie-2 stabilizasyonu, modifiye sessiz Fc; hastaların ~%60'ında q16w, ~%78-80'inde ≥q12w doz aralığı!); "
            "2) Yüksek Doz Aflibercept 8.0 mg (PHOTON Faz 2/3, 48-96 hafta): 4 kat molar doz ile q12w ve q16w aralıklarda 2 mg q8w rejimine görsel eşdeğerlik ve uzatılmış kuruluk; "
            "3) Port Delivery System (PDS / Susvimo 100 mg/mL ranibizumab — PAGODA & PAVILION Faz 3): 24-36 haftada bir doldurulan skleral rezervuar (endoftalmi ve septum dislokasyonu güvenlik uyarısı!); "
            "4) Brolucizumab 6 mg (KESTREL & KITE Faz 3: güçlü anatomik kurutma ANCAK intraoküler inflamasyon [İOİ] ve tıkayıcı [okülüzif] retinal vaskülit riski!) ve Abicipar pegol (2018'de umut vadeden DARPin iken yüksek İOİ nedeniyle 2020'de FDA tarafından reddedilmesi dersi!); AAV gen tedavisi ve yeni hedeflerin preklinik/erken faz sınırları."
        ),
    },
    {
        "module_id": "M08",
        "kicker": "BÖLÜM 8 · MAKALE 14 & 15 + GÜNCEL RETİNA 2023 + PUBMED (2019-2026) SENTEZİ",
        "title": "DMÖ, VİTREUS HEMORAJİSİ (PROTOKOL AB) VE TRAKSİYONEL DEKOLMANDA MODERN CERRAHİ",
        "subtitle": "Patel Sınıflaması, İlaç Klirensi, DRCR.net Protokol AB, Preop Anti-VEGF Crunch Penceresi (3-7 Gün), 27G Eğimli Uç, iOCT ve Bimanuel Delaminasyon",
        "article_nos": [14, 15],
        "visual_keys": ["schema_5", "panel_trd_surgery_db"],
        "focus_points": (
            "DMÖ cerrahisinde AVD ve PPV'nin 4 fizyolojik mekanizması (traksiyonun kalkması, iç retina oksijenasyonu, VEGF/sitokin klirensi, viskozite düşüşü), Patel sınıflaması, DRCR.net Protokol D ve ILM soyulması (anatomik rezolüsyon/ERM önleme vs sınırlı ek görme farkı); "
            "Vitrektomize gözde intravitreal ilaç klirensi tuzağı: serbest triamsinolon yarı ömrü kısalırken Deksametazon 0.7 mg implant (CHAMPLAIN) etkinliğinin korunması; "
            "Diyabetik VİH yönetimi ve DRCR.net Protokol AB (JAMA 2020): PDR kaynaklı VİH'te başlangıç intravitreal aflibercept vs erken PPV + endolazer PRP (24 haftalık görme keskinliği eğri altı alanında birincil anlamlı fark olmaması, ancak erken PPV kolunda daha hızlı kanama temizlenmesi, daha az rekürren VİH ve daha az TRD gelişimi!); "
            "Preoperatif anti-VEGF adjuvan kullanımı ve mutlak 'Crunch' zamanlama kuralı: intraoperatif kanamayı ve cerrahi süreyi azaltır ANCAK enjeksiyondan 3-7 gün (kesinlikle <10 gün) içinde PPV yapılmalıdır; >10 gün gecikmede anjiyo-fibrotik dönüşümle kombine traksiyonel-regmatojen dekolman (TRD+RRD) riski; "
            "2023-2026 Modern MIVS Cerrahi Teknolojileri (Güncel Retina 2023 Özel Sayısı): 25G/27G yüksek kesim hızlı (10.000-20.000 cpm) eğimli uçlu (beveled-tip) problarla all-in-one membran diseksiyonu, avize (chandelier) aydınlatmalı bimanuel en bloc delaminasyon vs segmentasyon (200 kat membran direnci yasası!), intraoperatif OKT (iOCT) ile klivaj planı/gizli yırtık tespiti, kombine fakovitrektomi ve post-PPV rekürren VİH / tamponad yönetimi."
        ),
    },
]


# ============================================================================
# 2. LANGGRAPH STATE ŞEMALARI (Paralel Fan-Out / Fan-In Güvenli)
# ============================================================================

def upsert_module_results(existing: List[Dict[str, Any]], new: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """langgraph_auditor.py (Gemini 4 Argon) direktifi: checkpoint tekrarında mükerrer modül eklenmesini önleyen idempotent reducer."""
    merged = {str(item["module_id"]): item for item in (existing or []) if isinstance(item, dict) and "module_id" in item}
    for item in (new or []):
        if isinstance(item, dict) and "module_id" in item:
            merged[str(item["module_id"])] = item
    return [merged[k] for k in sorted(merged.keys())]


class MasterStudyState(TypedDict, total=False):
    pipeline_audit: Dict[str, Any]
    source_articles: Dict[int, Dict[str, Any]]
    visual_paths: Dict[str, str]
    completed_modules: Annotated[List[Dict[str, Any]], upsert_module_results]
    sorted_modules: List[Dict[str, Any]]
    master_markdown_path: str
    output_pdf_path: str
    output_pptx_path: str
    usage_report: Dict[str, Any]


class ModuleWorkerInput(TypedDict):
    plan: Dict[str, Any]
    articles_text: str
    article_headers: str
    book_id: str
    humanizer_cache_dir: str


class ModuleWorkerOutput(TypedDict):
    completed_modules: Annotated[List[Dict[str, Any]], upsert_module_results]


class ModuleWorkerState(ModuleWorkerInput, ModuleWorkerOutput, total=False):
    local_db_evidence: Dict[str, Any]
    pubmed_evidence: Dict[str, Any]
    reader_evidence: Dict[str, Any]
    authored_module: Dict[str, Any]
    audit_result: Dict[str, Any]
    humanization_metrics: Dict[str, Any]
    revision: int
    revision_feedback: str


# ============================================================================
# 2B. VERTEX AI GRAMMAR-CONSTRAINED PYDANTIC ŞEMALARI (Sıfır JSON Hatası)
# ============================================================================

class MechanismFact(BaseModel):
    concept: str
    mechanism_chain: str
    source_ref: str


class QuantFact(BaseModel):
    study_or_metric: str
    numbers_and_thresholds: str
    clinical_meaning: str
    evidence_type: str = Field(description="human_clinical | preclinical_animal_in_vitro | guideline_consensus")
    source_ref: str


class ClassifFact(BaseModel):
    name: str
    criteria_details: str
    source_ref: str


class PitfallFact(BaseModel):
    issue: str
    why_it_matters: str
    source_ref: str


class ReaderEvidenceSchema(BaseModel):
    module_id: str
    source_citations: List[str]
    core_mechanisms: List[MechanismFact]
    quantitative_facts_and_trials: List[QuantFact]
    classifications_and_algorithms: List[ClassifFact]
    exceptions_and_pitfalls: List[PitfallFact]


class SectionSchema(BaseModel):
    heading: str
    paragraphs: List[str]


class TableRowSchema(BaseModel):
    cells: List[str]


class ClinicalTableSchema(BaseModel):
    title: str
    headers: List[str]
    rows: List[TableRowSchema]


class MnemonicItemSchema(BaseModel):
    key: str
    desc: str


class MnemonicSchema(BaseModel):
    code: str
    items: List[MnemonicItemSchema]
    golden_rule: str


class CaseVignetteSchema(BaseModel):
    title: str
    scenario: str
    reasoning: str
    decision: str


class ActiveRecallSchema(BaseModel):
    question: str
    answer_rationale: str


class StudyModuleSchema(BaseModel):
    module_id: str
    kicker: str
    title: str
    subtitle: str
    lead_principle: str
    sections: List[SectionSchema]
    clinical_table: ClinicalTableSchema
    pearls: List[str]
    mnemonic: MnemonicSchema
    case_vignette: CaseVignetteSchema
    pitfall_warning: str
    active_recall_questions: List[ActiveRecallSchema]


class ModuleAuditSchema(BaseModel):
    approved: bool
    quality_score: int
    audit_notes: List[str]
    revision_instructions: str


# ============================================================================
# 3. DETERMİNİSTİK DOĞRULAMA VE NORMALİZASYON YARDIMCILARI
# ============================================================================

def count_module_words(mod: Dict[str, Any]) -> int:
    parts = [str(mod.get("lead_principle", "")), str(mod.get("pitfall_warning", ""))]
    for sec in mod.get("sections", []):
        parts.extend(str(p) for p in sec.get("paragraphs", []))
    return len(" ".join(parts).split())


def validate_and_normalize_module(raw_mod: Dict[str, Any], plan: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    issues: List[str] = []
    if not isinstance(raw_mod, dict):
        return {}, ["Çıktı geçerli bir JSON sözlüğü değil."]

    mod = dict(raw_mod)
    mod["module_id"] = plan["module_id"]
    mod["kicker"] = plan["kicker"]
    mod["title"] = mod.get("title") or plan["title"]
    mod["subtitle"] = mod.get("subtitle") or plan["subtitle"]

    sections = mod.get("sections", [])
    if not isinstance(sections, list) or len(sections) < 3:
        issues.append(f"En az 3 alt başlık (sections) bulunmalı (mevcut: {len(sections) if isinstance(sections, list) else 0}).")
    else:
        for s_idx, sec in enumerate(sections, 1):
            paras = [str(p).strip() for p in sec.get("paragraphs", []) if str(p).strip()]
            sec["paragraphs"] = paras
            if len(paras) < 2:
                issues.append(f"Alt başlık {s_idx} içinde en az 2 kapsamlı paragraf olmalı.")

    wc = count_module_words(mod)
    if wc < 620:
        issues.append(f"Modül metni çok kısa ({wc} kelime); mekanizma ve klinik detaylarla en az 750-1000 kelime olmalı.")

    tbl = mod.get("clinical_table") or {}
    headers = [str(h) for h in tbl.get("headers", [])]
    rows = tbl.get("rows", [])
    if len(headers) < 3 or len(rows) < 4:
        issues.append("clinical_table en az 3 sütun ve 4 satır içermelidir.")
    else:
        ncols = len(headers)
        norm_rows = []
        for r in rows:
            if isinstance(r, dict) and "cells" in r:
                r = r["cells"]
            if isinstance(r, list):
                cells = [str(c) for c in r[:ncols]]
                while len(cells) < ncols:
                    cells.append("-")
                norm_rows.append(cells)
        tbl["headers"] = headers
        tbl["rows"] = norm_rows
        mod["clinical_table"] = tbl

    pearls = [str(p).strip() for p in mod.get("pearls", []) if str(p).strip()]
    if len(pearls) < 4:
        issues.append("En az 4 adet klinik inci (pearls) bulunmalıdır.")
    mod["pearls"] = pearls[:5]

    mn = mod.get("mnemonic") or {}
    if not mn.get("items") or len(mn.get("items", [])) < 3:
        issues.append("mnemonic alanında en az 3 kodlama maddesi bulunmalıdır.")

    cv = mod.get("case_vignette") or {}
    if not (cv.get("scenario") and cv.get("reasoning") and cv.get("decision")):
        issues.append("case_vignette alanı scenario, reasoning ve decision içermelidir.")

    qs = mod.get("active_recall_questions") or []
    if not isinstance(qs, list) or len(qs) < 2:
        issues.append("active_recall_questions en az 2 mekanizma sorusu ve cevap rasyoneli içermelidir.")

    return mod, issues


def extract_unverified_pmids(mod: Dict[str, Any], allowed_pmids: set[str]) -> List[str]:
    """Modül JSON metninde geçen tüm PMID numaralarını tarar ve doğrulanmış katalog dışındakileri yakalar."""
    dumped = json.dumps(mod, ensure_ascii=False)
    found = set(re.findall(r"PMID:\s*(\d+)", dumped))
    return sorted(pid for pid in found if pid not in allowed_pmids)


def sanitize_unverified_pmids(mod: Dict[str, Any], allowed_pmids: set[str]) -> Dict[str, Any]:
    """Revizyon sınırı dolsa bile doğrulanmamış hiçbir hayali PMID numarasının PDF'e sızmamasını garanti eder."""
    dumped = json.dumps(mod, ensure_ascii=False)

    def _repl(match: re.Match) -> str:
        pid = match.group(1)
        if pid in allowed_pmids:
            return f"PMID:{pid}"
        return ""

    cleaned = re.sub(r"(?:\s*[—\-;,]\s*)?PMID:\s*(\d+)", lambda m: m.group(0) if m.group(1) in allowed_pmids else "", dumped)
    return json.loads(cleaned)


# ============================================================================
# 4. ALT GRAFİK DÜĞÜMLERİ (Çok Kaynaklı DB + PubMed + 4-Katmanlı all_gemini Akışı)
# ============================================================================

def local_db_retrieval_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    db_ev = fetch_local_db_evidence_for_module(mid, STORAGE_DR_DIR)
    emit(f"[{mid}] Yerel Veritabanı okundu: {len(db_ev.get('db_citations', []))} kaynak bölüm (AAO BCSC 2024 & Güncel Retina).")
    return {"local_db_evidence": db_ev}


def pubmed_research_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    pm_ev = fetch_pubmed_landmark_evidence_for_module(mid, STORAGE_DR_DIR)
    emit(f"[{mid}] Canlı PubMed E-Utilities tamamlandı: {pm_ev.get('pmid_count', 0)} doğrulanmış 2019-2026 makale.")
    return {"pubmed_evidence": pm_ev}


def flash_reader_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = STORAGE_DR_DIR / f"reader_{mid}.json"

    if cache_file.is_file():
        emit(f"[{mid}] Katman 1 (Gemini 3.8 Flash Reader) önbellekten yüklendi.")
        return {"reader_evidence": json.loads(cache_file.read_text(encoding="utf-8")), "revision": 0, "revision_feedback": ""}

    emit(f"[{mid}] Katman 1 (Gemini 3.8 Flash Reader) 3 kanıt akışını (2018 + DB + PubMed) analiz ediyor...")
    ev_obj: ReaderEvidenceSchema = ask(
        "dr_dmo/reader",
        book=BOOK_ID,
        unit=f"{mid}-reader",
        schema=ReaderEvidenceSchema,
        module_id=mid,
        module_title=plan["title"],
        article_headers=state["article_headers"],
        focus_points=plan["focus_points"],
        raw_source_text=state["articles_text"],
        local_db_text=(state.get("local_db_evidence") or {}).get("formatted_text", ""),
        pubmed_evidence_text=(state.get("pubmed_evidence") or {}).get("formatted_text", ""),
    )
    evidence = ev_obj.model_dump()
    cache_file.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"reader_evidence": evidence, "revision": 0, "revision_feedback": ""}


def pro_author_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    rev = int(state.get("revision") or 0)
    mod_cache = STORAGE_DR_DIR / f"module_{mid}.json"

    if rev == 0 and mod_cache.is_file():
        cached = json.loads(mod_cache.read_text(encoding="utf-8"))
        norm_mod, issues = validate_and_normalize_module(cached, plan)
        if not issues:
            emit(f"[{mid}] Katman 2 (Gemini 4 Argon Author) onaylı modül önbellekten yüklendi ({count_module_words(norm_mod)} kelime).")
            return {"authored_module": norm_mod}

    emit(f"[{mid}] Katman 2 (Gemini 4 Argon Author) 2026 güncel çalışma modülünü yazıyor (Tur {rev + 1})...")
    fb = state.get("revision_feedback") or "İlk yazım turu: tüm klasik ve 2019-2026 zorunlu odakları gerçek PMID ve DB atıflarıyla eksiksiz işle."
    verified_pmids_str = "; ".join((state.get("pubmed_evidence") or {}).get("verified_pmids", [])) or "Bu modül için ek PubMed kaydı yok."
    authored_obj: StudyModuleSchema = ask(
        "dr_dmo/author",
        book=BOOK_ID,
        unit=f"{mid}-author-r{rev}",
        schema=StudyModuleSchema,
        module_id=mid,
        kicker=plan["kicker"],
        module_title=plan["title"],
        module_subtitle=plan["subtitle"],
        article_headers=state["article_headers"],
        focus_points=plan["focus_points"],
        verified_pmids=verified_pmids_str,
        revision_feedback=fb,
        reader_evidence_json=json.dumps(state["reader_evidence"], ensure_ascii=False),
    )
    norm_mod, _ = validate_and_normalize_module(authored_obj.model_dump(), plan)
    return {"authored_module": norm_mod}


def senior_reviewer_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    rev = int(state.get("revision") or 0)
    mod_cache = STORAGE_DR_DIR / f"module_{mid}.json"
    pm_articles = (state.get("pubmed_evidence") or {}).get("articles", [])
    allowed_pmids = {str(a["pmid"]) for a in pm_articles if a.get("pmid")}

    if rev == 0 and mod_cache.is_file():
        norm_mod, issues = validate_and_normalize_module(state["authored_module"], plan)
        bad_pmids = extract_unverified_pmids(norm_mod, allowed_pmids)
        if not issues and not bad_pmids:
            return {"audit_result": {"approved": True, "quality_score": 96, "audit_notes": ["Önbellekten doğrulandı."]}}

    norm_mod, det_issues = validate_and_normalize_module(state["authored_module"], plan)
    bad_pmids = extract_unverified_pmids(norm_mod, allowed_pmids)
    if bad_pmids:
        det_issues.append(
            f"Doğrulanmış katalogda bulunmayan uydurma/hatalı PMID tespit edildi: {', '.join(bad_pmids)}. "
            f"Yalnızca doğrulanmış listedeki gerçek PMID numaralarını ({', '.join(sorted(allowed_pmids))}) kullan!"
        )

    emit(f"[{mid}] Katman 3 (Senior Reviewer) kaynak sadakati, PMID doğrulaması ve mekanizma denetimi yapıyor...")
    reader_ev = state["reader_evidence"]
    reader_summary = json.dumps(
        {
            "core_mechanisms": reader_ev.get("core_mechanisms", [])[:15],
            "quantitative_facts_and_trials": reader_ev.get("quantitative_facts_and_trials", [])[:35],
            "exceptions_and_pitfalls": reader_ev.get("exceptions_and_pitfalls", [])[:15],
        },
        ensure_ascii=False,
    )
    verified_pmids_str = "; ".join((state.get("pubmed_evidence") or {}).get("verified_pmids", [])) or "Yok"
    audit_obj: ModuleAuditSchema = ask(
        "dr_dmo/reviewer",
        book=BOOK_ID,
        unit=f"{mid}-review-r{rev}",
        schema=ModuleAuditSchema,
        module_id=mid,
        module_title=plan["title"],
        focus_points=plan["focus_points"],
        verified_pmids=verified_pmids_str,
        reader_summary=reader_summary,
        authored_json=json.dumps(norm_mod, ensure_ascii=False),
    )
    llm_audit = audit_obj.model_dump()

    approved = bool(llm_audit.get("approved", True)) and len(det_issues) == 0
    rev_instr_parts = list(det_issues)
    if llm_audit.get("revision_instructions"):
        rev_instr_parts.append(str(llm_audit["revision_instructions"]))

    if approved:
        mod_cache.write_text(json.dumps(norm_mod, ensure_ascii=False, indent=2), encoding="utf-8")

    audit_out = {
        "approved": approved,
        "quality_score": int(llm_audit.get("quality_score", 90)),
        "audit_notes": llm_audit.get("audit_notes", []),
        "revision_instructions": " | ".join(rev_instr_parts),
    }
    emit(f"[{mid}] Denetim sonucu: approved={approved}, skor={audit_out['quality_score']}, kelime={count_module_words(norm_mod)}")
    return {
        "authored_module": norm_mod,
        "audit_result": audit_out,
        "revision": rev + 1,
        "revision_feedback": audit_out["revision_instructions"],
    }


def route_review(state: ModuleWorkerState) -> str:
    audit = state.get("audit_result") or {}
    if audit.get("approved") or int(state.get("revision") or 0) > 1:
        return "humanize"
    return "revise"


def commit_module_node(state: ModuleWorkerState) -> Dict[str, Any]:
    plan = state["plan"]
    mid = plan["module_id"]
    pm_articles = (state.get("pubmed_evidence") or {}).get("articles", [])
    allowed_pmids = {str(a["pmid"]) for a in pm_articles if a.get("pmid")}
    clean_authored = sanitize_unverified_pmids(dict(state["authored_module"]), allowed_pmids)
    norm_mod, _ = validate_and_normalize_module(clean_authored, plan)
    mod = dict(norm_mod)
    mod["visual_keys"] = plan.get("visual_keys", [])
    mod["article_headers"] = state["article_headers"]
    mod["pubmed_refs"] = pm_articles
    mod["db_refs"] = (state.get("local_db_evidence") or {}).get("db_citations", [])
    mod["audit"] = state.get("audit_result", {})
    h_metrics = state.get("humanization_metrics") or {}
    mod["humanization_metrics"] = h_metrics

    emit(
        f"[{mid}] Katman 4 (academic_turkish_humanizer_node) tamamlandı: "
        f"calque {h_metrics.get('calques_before', 0)} -> {h_metrics.get('calques_after', 0)}, "
        f"-mektedir {h_metrics.get('mektedir_before', 0)} -> {h_metrics.get('mektedir_after', 0)}."
    )
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    (STORAGE_DR_DIR / f"module_final_{mid}.json").write_text(json.dumps(mod, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"completed_modules": [mod]}


def build_module_worker_subgraph():
    g = StateGraph(ModuleWorkerState, input_schema=ModuleWorkerInput, output_schema=ModuleWorkerOutput)
    g.add_node("local_db_retrieval", local_db_retrieval_node)
    g.add_node("pubmed_research", pubmed_research_node, retry_policy=RETRY)
    g.add_node("flash_reader", flash_reader_node, retry_policy=RETRY)
    g.add_node("pro_author", pro_author_node, retry_policy=RETRY)
    g.add_node("senior_reviewer", senior_reviewer_node, retry_policy=RETRY)
    g.add_node("academic_turkish_humanizer", academic_turkish_humanizer_node, retry_policy=RETRY)
    g.add_node("commit_module", commit_module_node)

    g.add_edge(START, "local_db_retrieval")
    g.add_edge("local_db_retrieval", "pubmed_research")
    g.add_edge("pubmed_research", "flash_reader")
    g.add_edge("flash_reader", "pro_author")
    g.add_edge("pro_author", "senior_reviewer")
    g.add_conditional_edges(
        "senior_reviewer",
        route_review,
        {"revise": "pro_author", "humanize": "academic_turkish_humanizer"},
    )
    g.add_edge("academic_turkish_humanizer", "commit_module")
    g.add_edge("commit_module", END)
    return g.compile()


# ============================================================================
# 5. ANA GRAFİK DÜĞÜMLERİ (LangGraph Auditor, PDF Okuma, Fan-Out, Sentez ve PDF Dizgi)
# ============================================================================

def audit_pipeline_architecture_node(state: MasterStudyState) -> Dict[str, Any]:
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    audit_cache = STORAGE_DR_DIR / "langgraph_audit_all_gemini.json"
    audit_md_out = BASE_DIR / "output" / "compiled" / "DR_DMO_LangGraph_Auditor_Raporu.md"
    audit_md_out.parent.mkdir(parents=True, exist_ok=True)

    if audit_cache.is_file():
        cached_audit = json.loads(audit_cache.read_text(encoding="utf-8"))
        emit(
            f"[0/5] langgraph_auditor.py (`all_gemini`) mimari denetimi önbellekten yüklendi "
            f"(skor={cached_audit.get('complexity_score')}/10)."
        )
        return {"pipeline_audit": cached_audit}

    emit("[0/5] langgraph_auditor.py (`mode='all_gemini'`) ile boru hattı topolojisi canlı denetleniyor...")
    pipeline_src = Path(__file__).read_text(encoding="utf-8")
    audit_res = audit_langgraph_pipeline(
        pipeline_src,
        input_type="langgraph_python",
        mode="all_gemini",
        book_id=BOOK_ID,
    )
    summary_payload = {
        "orchestration_mode": "all_gemini",
        "complexity_score": audit_res.get("complexity_score", 8),
        "topology": audit_res.get("topology", {}),
        "detected_flaws": audit_res.get("detected_flaws", []),
        "refactor_notes": audit_res.get("refactor_notes", []),
        "quota_savings_summary": audit_res.get("quota_savings_summary", {}),
        "humanization_metrics": audit_res.get("humanization_metrics", {}),
    }
    audit_cache.write_text(json.dumps(summary_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    report_text = audit_res.get("academic_report") or audit_res.get("final_report") or ""
    audit_md_out.write_text(report_text, encoding="utf-8")
    (STORAGE_DR_DIR / "langgraph_audit_report.md").write_text(report_text, encoding="utf-8")
    emit(f" -> langgraph_auditor.py (`all_gemini`) denetimi tamamlandı: skor={summary_payload['complexity_score']}/10.")
    return {"pipeline_audit": summary_payload}

def ingest_source_pdf_node(state: MasterStudyState) -> Dict[str, Any]:
    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    if UPLOADED_PDF.is_file():
        src_pdf = UPLOADED_PDF
    elif ARCHIVED_SOURCE_PDF.is_file():
        src_pdf = ARCHIVED_SOURCE_PDF
    elif LEGACY_SOURCE_PDF.is_file():
        src_pdf = LEGACY_SOURCE_PDF
    else:
        raise FileNotFoundError(f"Kaynak PDF bulunamadı: {LEGACY_SOURCE_PDF}")

    if src_pdf.is_file() and not ARCHIVED_SOURCE_PDF.is_file():
        shutil.copy2(src_pdf, ARCHIVED_SOURCE_PDF)

    emit(f"[1/5] 96 sayfalık kaynak PDF okunuyor ve 16 adet şematik/klinik görsel üretiliyor ({src_pdf.name})...")
    visual_paths = build_all_dr_dmo_visuals(BASE_DIR)

    doc = pymupdf.open(str(src_pdf))
    source_articles: Dict[int, Dict[str, Any]] = {}
    for art_no, p_start, p_end, j_pages, authors, title in ARTICLES_SPEC:
        page_chunks = []
        for pno in range(p_start, p_end + 1):
            txt = doc[pno - 1].get_text("text")
            j_page_est = int(j_pages.split("-")[0]) + (pno - p_start)
            page_chunks.append(f"--- [Makale {art_no} | Dergi s. {j_page_est} | PDF s. {pno}] ---\n{txt}")
        source_articles[art_no] = {
            "article_no": art_no,
            "pdf_range": f"{p_start}-{p_end}",
            "journal_pages": j_pages,
            "authors": authors,
            "title": title,
            "header": f"Makale {art_no}: {authors} — {title} (Güncel Retina 2018;2(2):{j_pages})",
            "full_text": "\n\n".join(page_chunks),
        }
    emit(f" -> 15 derleme makalesi ({len(doc)} sayfa) ve {len(visual_paths)} yüksek çözünürlüklü görsel hazır.")
    return {"source_articles": source_articles, "visual_paths": visual_paths}


def dispatch_modules_edge(state: MasterStudyState):
    src = state["source_articles"]
    jobs = []
    for plan in MODULES_PLAN:
        arts = [src[a_no] for a_no in plan["article_nos"]]
        headers = " | ".join(a["header"] for a in arts)
        combined_text = "\n\n====================\n\n".join(f"### {a['header']}\n{a['full_text']}" for a in arts)
        jobs.append(
            {
                "plan": plan,
                "articles_text": combined_text,
                "article_headers": headers,
                "book_id": BOOK_ID,
                "humanizer_cache_dir": str(STORAGE_DR_DIR),
            }
        )
    return [Send("module_worker", jb) for jb in jobs]


def _md_linkify_pmids(text: str) -> str:
    if not text:
        return ""
    return re.sub(
        r"\[([^\]]*PMID:\s*(\d+)[^\]]*)\]",
        r"[\1](https://pubmed.ncbi.nlm.nih.gov/\2/)",
        str(text),
    )


def synthesize_master_node(state: MasterStudyState) -> Dict[str, Any]:
    emit("[3/5] 8 Modül birleştiriliyor, tıklanabilir PubMed bağlantılı Markdown rehberi ve kaynakça dizini derleniyor...")
    mods = sorted(state.get("completed_modules", []), key=lambda m: m["module_id"])

    md_lines = [
        "# DİYABETİK RETİNOPATİ VE DİYABETİK MAKÜLA ÖDEMİ — KAPSAMLI ÇALIŞMA REHBERİ (2026 ÇOK KAYNAKLI BASKI)",
        "",
        "> **Kanıt Akışı 1 (Birincil Tam Metin):** *Güncel Retina* 2018;2(2):89–207 (15 Hakemli Derleme Makalesi, 96 Sayfa)",
        "> **Kanıt Akışı 2 (Yerel Oftalmoloji Veritabanı Tam Metin):** *AAO BCSC 2023–2024 Section 12: Retina and Vitreous* + *Güncel Retina 2021–2026 Arşivi* (2023 Diyabetik Vitrektomi Özel Sayısı, 2025 Katarakt+NPDR/PDR, 2026 DR Oküler Genetik)",
        "> **Kanıt Akışı 3 (Canlı NCBI PubMed E-Utilities 2019–2026):** Doğrulanmış PMID & DOI bağlantılı 2019–2026 Landmark RKÇ ve Meta-Analiz Özetleri",
        "> **Üretim Hattı (`all_gemini`):** `langgraph_auditor.py` Mimari Denetim (`gemini-3.8-flash` + `gemini-4-argon`) → `local_db_retrieval` + `pubmed_research` → `flash_reader` (`gemini-3.8-flash`) → `pro_author` (`gemini-4-argon`) → `senior_reviewer` (`gemini-3.8-flash`) → `academic_turkish_humanizer_node` (`gemini-3.8-flash` Baş-Son Akademik Türkçe)",
        "",
    ]
    all_questions: List[Tuple[str, str, str]] = []
    seen_pmids: Dict[str, Dict[str, Any]] = {}
    all_db_refs: List[str] = []

    for m_idx, mod in enumerate(mods, 1):
        md_lines.append(f"## Bölüm {m_idx}: {mod['title']}")
        md_lines.append(f"*{mod['subtitle']}*")
        md_lines.append("")
        md_lines.append(f"> [!IMPORTANT] Öne Çıkan Temel İlke\n> {_md_linkify_pmids(mod.get('lead_principle', ''))}")
        md_lines.append("")
        for sec in mod.get("sections", []):
            md_lines.append(f"### {sec.get('heading', '')}")
            for p in sec.get("paragraphs", []):
                md_lines.append(_md_linkify_pmids(p))
                md_lines.append("")
        if mod.get("pearls"):
            md_lines.append("#### Klinik İnciler")
            for pt in mod["pearls"]:
                md_lines.append(f"- {_md_linkify_pmids(pt)}")
            md_lines.append("")
        if mod.get("pitfall_warning"):
            md_lines.append(f"> [!WARNING] Klinik Tuzak ve Metodolojik Sınır\n> {_md_linkify_pmids(mod['pitfall_warning'])}")
            md_lines.append("")
        for q_idx, q_item in enumerate(mod.get("active_recall_questions", []), 1):
            all_questions.append(
                (
                    f"{mod['module_id']}-S{q_idx}",
                    _md_linkify_pmids(str(q_item.get("question", ""))),
                    _md_linkify_pmids(str(q_item.get("answer_rationale", ""))),
                )
            )
        for art in mod.get("pubmed_refs", []):
            pid = str(art.get("pmid", ""))
            if pid and pid not in seen_pmids:
                seen_pmids[pid] = {**art, "module_id": mod["module_id"]}
        for dbr in mod.get("db_refs", []):
            if dbr not in all_db_refs:
                all_db_refs.append(dbr)

    md_lines.append("## Bölüm 10: Büyük Görsel Oftalmoloji ve Tanı Atlası (40 Doğrulanmış Panel)\n")
    md_lines.append("> **Deterministik Bölüm ve Sayfa Provenance Standardı:** Aşağıdaki 40 tanısal klinik görsel ve optik koherens tomografi (OKT) kesiti, doğrudan ait oldukları tıp kitaplarının Diyabetik Retinopati ve Neovasküler Glokom bölümlerindeki orijinal şekil ve sayfa koordinatlarıyla (BCSC 12 Bölüm 5, Spalton Bölüm 15, The Retinal Atlas Bölüm 6, Atlas of Retinal OCT Section 15 ve Gonioscopy) deterministik olarak eşlenmiştir.\n")
    md_lines.append("| No | Lezyon / Patoloji Başlığı | Doğrulanmış Kitap, Bölüm ve Sayfa Referansı | Görsel Dosyası | Klinik İnci |\n")
    md_lines.append("| :---: | :--- | :--- | :--- | :--- |\n")
    for a_idx, a_entry in enumerate(ATLAS_SLIDES_DATA, 1):
        md_lines.append(f"| {a_idx} | **{a_entry['title']}** | {a_entry.get('provenance', '')} | `{a_entry['img']}` | {a_entry['pearl']} |\n")
    md_lines.append("\n---\n\n")

    md_lines.append("## Aktif Hatırlama ve Mekanizma Sorgulama Soruları")
    for idx_q, (qcode, qtxt, _) in enumerate(all_questions, 1):
        md_lines.append(f"{idx_q}. **[{qcode}]** {qtxt}")
    md_lines.append("\n---\n\n## Ayrıntılı Cevap Anahtarı ve Bilimsel Rasyoneller")
    for idx_q, (qcode, _, ans) in enumerate(all_questions, 1):
        md_lines.append(f"### Cevap {idx_q} ({qcode})\n{ans}\n")

    md_lines.append("\n---\n\n## Doğrulanmış Canlı PubMed (2019–2026) ve Yerel Veritabanı Kaynakça Dizini")
    md_lines.append("### A. Yerel Oftalmoloji Veritabanı Tam Metin Kaynakları (`[Tam Metin İncelendi]`)")
    for dbr in all_db_refs:
        md_lines.append(f"- {dbr}")
    md_lines.append("\n### B. Canlı PubMed E-Utilities Kayıtları (`[Yalnızca PubMed Özeti İncelendi]`)")
    for pid, rec in seen_pmids.items():
        doi_part = f" · [DOI:{rec['doi']}]({rec['doi_url']})" if rec.get("doi") else ""
        md_lines.append(
            f"- **[{rec['first_author']}, {rec['year']} — PMID:{pid}]({rec['pubmed_url']})** — {rec['title']} *{rec['journal']}* ({rec['year']}){doi_part}"
        )

    OUT_MD_COMPILED.parent.mkdir(parents=True, exist_ok=True)
    OUT_MD_COMPILED.write_text("\n".join(md_lines), encoding="utf-8")
    return {"sorted_modules": mods, "master_markdown_path": str(OUT_MD_COMPILED)}


# ============================================================================
# 6. REPORTLAB PRO PDF DİZGİ MOTORU (Sıfır HTML Sızıntısı, Tıklanabilir PubMed Linkleri)
# ============================================================================

INK = colors.HexColor("#142f43")
MUTED = colors.HexColor("#476174")
LINE = colors.HexColor("#cddce8")
BLUE = colors.HexColor("#1c5ba6")
BLUE_BG = colors.HexColor("#edf4ff")
GREEN = colors.HexColor("#087d6c")
GREEN_BG = colors.HexColor("#eaf8f2")
AMBER = colors.HexColor("#a46109")
AMBER_BG = colors.HexColor("#fff5df")
PURPLE = colors.HexColor("#6941a5")
PURPLE_BG = colors.HexColor("#f4effc")
ALERT_RED = colors.HexColor("#b91c1c")
ALERT_RED_BG = colors.HexColor("#fef2f2")
ROW_ALT = colors.HexColor("#f8fafc")
CARD_BG = colors.HexColor("#f1f5f9")


def register_fonts() -> None:
    regular = "C:/Windows/Fonts/arial.ttf"
    bold = "C:/Windows/Fonts/arialbd.ttf"
    italic = "C:/Windows/Fonts/ariali.ttf" if Path("C:/Windows/Fonts/ariali.ttf").exists() else regular
    bi = "C:/Windows/Fonts/arialbi.ttf" if Path("C:/Windows/Fonts/arialbi.ttf").exists() else bold
    pdfmetrics.registerFont(TTFont("Arial", regular))
    pdfmetrics.registerFont(TTFont("ArialBold", bold))
    pdfmetrics.registerFont(TTFont("ArialItalic", italic))
    pdfmetrics.registerFont(TTFont("ArialBoldItalic", bi))
    pdfmetrics.registerFontFamily("Arial", normal="Arial", bold="ArialBold", italic="ArialItalic", boldItalic="ArialBoldItalic")


_CITE_BADGE_RE = re.compile(
    r"(?:19\d\d|20\d\d|s\.\s*\d+|AAO|BCSC|Güncel Retina|Makale|Protokol|WESDR|DCCT|UKPDS|ETDRS|FIELD|ACCORD|LENS|"
    r"SUSTAIN|FOCUS|RESTORE|RESOLVE|RETAIN|RIDE|RISE|VISTA|VIVID|MEAD|FAME|PALADIN|CHAMPLAIN|BEVORDEX|DRVS|"
    r"YOSEMITE|RHINE|RHONE|PHOTON|KESTREL|KITE|PAGODA|PAVILION|DIAMOND)"
)


_RL_TAG_RE = re.compile(r"<(/?)(b|i|font|a|br)\b([^>]*?)(/?)>", re.IGNORECASE)


def _balance_reportlab_xml(xml_str: str) -> str:
    """Çapraz veya kapanmamış inline XML etiketlerini (örn. <b>...<i>...</b></i>) deterministik yığınla dengeler."""
    out: List[str] = []
    stack: List[Tuple[str, str]] = []
    pos = 0
    for m in _RL_TAG_RE.finditer(xml_str):
        out.append(xml_str[pos:m.start()])
        pos = m.end()
        is_close = bool(m.group(1))
        tag = m.group(2).lower()
        attrs = m.group(3) or ""
        is_self = bool(m.group(4)) or tag == "br"

        if is_self:
            out.append("<br/>")
            continue

        if not is_close:
            full_open = f"<{tag}{attrs}>"
            stack.append((tag, full_open))
            out.append(full_open)
        else:
            # Yığında bu etiketin en üstteki eşleşmesini bul
            match_idx = -1
            for s_i in range(len(stack) - 1, -1, -1):
                if stack[s_i][0] == tag:
                    match_idx = s_i
                    break
            if match_idx == -1:
                # Yetim kapanış etiketi -> atla
                continue
            to_reopen = stack[match_idx + 1 :]
            for r_tag, _ in reversed(to_reopen):
                out.append(f"</{r_tag}>")
            out.append(f"</{tag}>")
            stack = stack[:match_idx]
            for r_tag, r_open in to_reopen:
                stack.append((r_tag, r_open))
                out.append(r_open)

    out.append(xml_str[pos:])
    for r_tag, _ in reversed(stack):
        out.append(f"</{r_tag}>")
    # Boş kalan etiket çiftlerini (örn. <i></i>) temizle
    res = "".join(out)
    res = re.sub(r"<(b|i)>\s*</\1>", "", res)
    return res


def fmt_inline(text: str) -> str:
    """Ham HTML ve LaTeX sızıntısını önler; PMID atıflarını tıklanabilir URI bağlantısına, DB atıflarını kurumsal mavi rozete çevirir."""
    if not text:
        return ""
    cleaned = str(text).strip()
    latex_map = [
        (r"\\ge\b", "≥"),
        (r"\\geq\b", "≥"),
        (r"\\le\b", "≤"),
        (r"\\leq\b", "≤"),
        (r"\\pm\b", "±"),
        (r"\\times\b", "×"),
        (r"\\rightarrow\b", "→"),
        (r"\\to\b", "→"),
        (r"\\alpha\b", "α"),
        (r"\\beta\b", "β"),
        (r"\\gamma\b", "γ"),
        (r"\\mu\b", "µ"),
        (r">=", "≥"),
        (r"<=", "≤"),
        (r"->", "→"),
    ]
    for pat, repl in latex_map:
        cleaned = re.sub(pat, repl, cleaned)
    cleaned = re.sub(r"\$([^$]{1,60})\$", r"\1", cleaned)

    cleaned = re.sub(r"<\s*br\s*/?>", "___LINEBREAK___", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*b\s*>", "___BOLD_START___", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*/\s*b\s*>", "___BOLD_END___", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*i\s*>", "___ITALIC_START___", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*/\s*i\s*>", "___ITALIC_END___", cleaned, flags=re.IGNORECASE)

    escaped = html.escape(cleaned)
    escaped = re.sub(r"`([^`]+)`", r'<font name="ArialBold" size="8.8" color="#0f3d75">\1</font>', escaped)
    # Üçlü yıldız kalıplarını (örn. **anjiyo-fibrotik *switch*** veya ***terim***) çapraz etiket üretmeden dönüştür
    escaped = re.sub(r"\*\*((?:(?!\*\*).)+?\*[^*]+?)\*\*\*", r"<b>\1*</b>", escaped)
    escaped = re.sub(r"\*\*\*([^*]+?\*(?:(?!\*\*).)+?)\*\*", r"<b>*\1</b>", escaped)
    escaped = re.sub(r"\*\*\*([^\s*][^*]*?)\*\*\*", r"<b><i>\1</i></b>", escaped)
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", escaped)
    escaped = re.sub(
        r"(?<![A-Za-z0-9ÇĞİÖŞÜçğıöşü*])\*([^\s*<>][^*<>]{0,95}?)\*(?![A-Za-z0-9ÇĞİÖŞÜçğıöşü*])",
        r"<i>\1</i>",
        escaped,
    )
    escaped = escaped.replace("___BOLD_START___", "<b>").replace("___BOLD_END___", "</b>")
    escaped = escaped.replace("___ITALIC_START___", "<i>").replace("___ITALIC_END___", "</i>")
    escaped = escaped.replace("___LINEBREAK___", "<br/>")

    def _format_bracket_cite(m: re.Match) -> str:
        inner = m.group(1)
        flat_inner = re.sub(r"</?(?:b|i|font)\b[^>]*>", "", inner)
        pmid_m = re.search(r"PMID:\s*(\d+)", flat_inner)
        if pmid_m:
            pid = pmid_m.group(1)
            return f'<a href="https://pubmed.ncbi.nlm.nih.gov/{pid}/" color="#1c5ba6"><b>[{flat_inner}]</b></a>'
        if _CITE_BADGE_RE.search(flat_inner):
            return f'<font size="8.4" color="#1c5ba6"><b>[{flat_inner}]</b></font>'
        return f"[{inner}]"

    escaped = re.sub(r"\[([^\]]+)\]", _format_bracket_cite, escaped)

    # Köşeli parantez dışında kalmış yalın PMID:12345678 ifadelerini de tıklanabilir yap (iç içe <a> oluşturmadan)
    chunks = re.split(r"(<a\b[^>]*>.*?</a>)", escaped)
    for idx_c, ch in enumerate(chunks):
        if not ch.startswith("<a"):
            chunks[idx_c] = re.sub(
                r"\bPMID:\s*(\d+)\b",
                r'<a href="https://pubmed.ncbi.nlm.nih.gov/\1/" color="#1c5ba6"><b>PMID:\1</b></a>',
                ch,
            )
    return _balance_reportlab_xml("".join(chunks))


def make_styles() -> Dict[str, ParagraphStyle]:
    body = ParagraphStyle(
        "Body",
        fontName="Arial",
        fontSize=9.7,
        leading=15.3,
        alignment=TA_JUSTIFY,
        textColor=INK,
        spaceBefore=1.5,
        spaceAfter=7.0,
    )
    return {
        "body": body,
        "small": ParagraphStyle("Small", parent=body, fontSize=8.4, leading=12.0, alignment=TA_LEFT, textColor=MUTED, spaceAfter=2),
        "small_bold": ParagraphStyle("SmallBold", parent=body, fontName="ArialBold", fontSize=8.9, leading=12.8, alignment=TA_LEFT, textColor=BLUE, spaceBefore=6, spaceAfter=3, keepWithNext=True),
        "small_bold_flow": ParagraphStyle("SmallBoldFlow", parent=body, fontName="ArialBold", fontSize=8.9, leading=12.8, alignment=TA_LEFT, textColor=BLUE, spaceBefore=6, spaceAfter=3, keepWithNext=False),
        "tbl_hdr": ParagraphStyle("TblHdr", parent=body, fontName="ArialBold", fontSize=8.6, leading=12.2, alignment=TA_LEFT, textColor=colors.white, spaceAfter=0),
        "tbl_cell": ParagraphStyle("TblCell", parent=body, fontSize=8.4, leading=12.4, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "tbl_cell_bold": ParagraphStyle("TblCellBold", parent=body, fontName="ArialBold", fontSize=8.4, leading=12.4, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "ch_kicker": ParagraphStyle("ChKicker", parent=body, fontName="ArialBold", fontSize=8.8, leading=12.0, alignment=TA_LEFT, textColor=colors.HexColor("#dbeafe"), spaceAfter=2),
        "ch_title": ParagraphStyle("ChTitle", parent=body, fontName="ArialBold", fontSize=14.6, leading=19.0, alignment=TA_LEFT, textColor=colors.white, spaceAfter=2),
        "sec_title": ParagraphStyle("SecTitle", parent=body, fontName="ArialBold", fontSize=11.8, leading=16.2, alignment=TA_LEFT, textColor=BLUE, spaceBefore=10, spaceAfter=4, keepWithNext=True),
        "sub_title": ParagraphStyle("SubTitle", parent=body, fontName="ArialBold", fontSize=10.3, leading=14.2, alignment=TA_LEFT, textColor=GREEN, spaceBefore=8, spaceAfter=3, keepWithNext=True),
        "callout_text": ParagraphStyle("CalloutText", parent=body, fontSize=9.0, leading=13.6, alignment=TA_LEFT, textColor=INK, spaceAfter=0),
        "atlas_title": ParagraphStyle("AtlasTitle", parent=body, fontName="ArialBold", fontSize=9.2, leading=12.2, alignment=TA_LEFT, textColor=BLUE, spaceAfter=1),
        "atlas_prov": ParagraphStyle("AtlasProv", parent=body, fontName="ArialItalic", fontSize=7.2, leading=9.5, alignment=TA_LEFT, textColor=colors.HexColor("#0284c7"), spaceAfter=2),
        "atlas_body": ParagraphStyle("AtlasBody", parent=body, fontName="Arial", fontSize=7.2, leading=9.6, alignment=TA_LEFT, textColor=INK, spaceAfter=2),
        "atlas_diff": ParagraphStyle("AtlasDiff", parent=body, fontName="Arial", fontSize=7.2, leading=9.6, alignment=TA_LEFT, textColor=colors.HexColor("#475569"), spaceAfter=2),
        "atlas_pearl": ParagraphStyle("AtlasPearl", parent=body, fontName="ArialBold", fontSize=7.2, leading=9.6, alignment=TA_LEFT, textColor=GREEN, spaceAfter=0),
    }


class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, total_pages: int):
        self.saveState()
        w, h = A4
        pnum = self._pageNumber

        for idx, col_hex in enumerate(["#1c5ba6", "#087d6c", "#a46109"]):
            self.setFillColor(colors.HexColor(col_hex))
            self.rect(idx * w / 3.0, h - 3.2 * mm, w / 3.0, 3.2 * mm, fill=1, stroke=0)

        if pnum > 1:
            self.setFont("ArialBold", 7.5)
            self.setFillColor(BLUE)
            self.drawString(16 * mm, h - 9.0 * mm, "DİYABETİK RETİNOPATİ VE DMÖ — 2026 KAPSAMLI ÇALIŞMA REHBERİ")
            self.setFont("Arial", 7.2)
            self.setFillColor(MUTED)
            self.drawRightString(w - 16 * mm, h - 9.0 * mm, "all_gemini LangGraph (Güncel Retina + AAO BCSC 2024 + PubMed 2026)")
            self.setStrokeColor(LINE)
            self.setLineWidth(0.5)
            self.line(16 * mm, h - 10.8 * mm, w - 16 * mm, h - 10.8 * mm)

            self.line(16 * mm, 12.0 * mm, w - 16 * mm, 12.0 * mm)
            self.setFont("Arial", 7.2)
            self.setFillColor(MUTED)
            self.drawString(16 * mm, 8.0 * mm, "MAVİ: Temel İlke & Tablo & PubMed Link · YEŞİL: Klinik İnci · MOR: Mnemonic & Vaka · AMBER: Tuzak")
            self.setFont("ArialBold", 8.0)
            self.setFillColor(BLUE)
            self.drawRightString(w - 16 * mm, 8.0 * mm, f"Sayfa {pnum} / {total_pages}")
        self.restoreState()


def build_chapter_banner(kicker: str, title: str, subtitle: str, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    data = [
        [Paragraph(f"<b>{html.escape(kicker)}</b>", styles["ch_kicker"])],
        [Paragraph(f"<b>{html.escape(title)}</b>", styles["ch_title"])],
        [Paragraph(f"<font color='#dbeafe' size='8.6'>{fmt_inline(subtitle)}</font>", styles["callout_text"])],
    ]
    t = Table(data, colWidths=[178 * mm])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), BLUE),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("BOX", (0, 0), (-1, -1), 0.8, BLUE),
            ]
        )
    )
    return KeepTogether([t, Spacer(1, 3.0 * mm)])


def build_callout_box(label: str, text: str, border_color, bg_color, styles: Dict[str, ParagraphStyle]) -> List[Any]:
    content = f'<font color="{border_color.hexval()}"><b>{html.escape(label)}:</b></font> {fmt_inline(text)}'
    p = Paragraph(content, styles["callout_text"])
    t = Table([[p]], colWidths=[178 * mm], splitByRow=1)
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), bg_color),
                ("LINEBEFORE", (0, 0), (0, -1), 3.5, border_color),
                ("BOX", (0, 0), (-1, -1), 0.5, LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 6.0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6.0),
                ("LEFTPADDING", (0, 0), (-1, -1), 9.0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8.5),
            ]
        )
    )
    return [Spacer(1, 1.8 * mm), t, Spacer(1, 2.8 * mm)]


def build_visual_card(img_path: Path, caption_title: str, caption_desc: str, styles: Dict[str, ParagraphStyle]) -> KeepTogether:
    if not img_path.is_file():
        return KeepTogether([])
    img = Image(str(img_path), width=178 * mm, height=69 * mm)
    cap_p = Paragraph(f"<b>{html.escape(caption_title)}:</b> {fmt_inline(caption_desc)}", styles["small"])
    t = Table([[img], [cap_p]], colWidths=[178 * mm])
    t.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.6, LINE),
                ("BACKGROUND", (0, 1), (-1, 1), CARD_BG),
                ("TOPPADDING", (0, 0), (-1, 0), 0),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 0),
                ("LEFTPADDING", (0, 0), (-1, 0), 0),
                ("RIGHTPADDING", (0, 0), (-1, 0), 0),
                ("TOPPADDING", (0, 1), (-1, 1), 4.5),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 4.5),
                ("LEFTPADDING", (0, 1), (-1, 1), 8),
                ("RIGHTPADDING", (0, 1), (-1, 1), 8),
            ]
        )
    )
    return KeepTogether([Spacer(1, 2.0 * mm), t, Spacer(1, 3.0 * mm)])


def _get_master_catalog_lookup() -> Dict[str, str]:
    try:
        cat_path = BASE_DIR / "assets" / "visual_catalog" / "master_catalog.json"
        if cat_path.is_file():
            with open(cat_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            return {img["filename"]: img.get("file_path", "") for img in d.get("local_images", [])}
    except Exception:
        pass
    return {}


def resolve_module_visual_and_caption(
    key_or_query: str,
    vpaths: Dict[str, str],
    fallback_title: str = "Klinik Görsel"
) -> Tuple[Optional[Path], str, str]:
    """
    Yerel vpaths içerisindeki şemayı, deterministik kitap/sayfa provenance eşleşmesini
    veya ophthalmology_vision_ai motorunu kullanarak doğrulanmış klinik görseli ve künyesini çözer.
    Döndürür: (dosya_yolu, altyazi_basligi, altyazi_aciklamasi)
    """
    if key_or_query in vpaths and Path(vpaths[key_or_query]).is_file():
        p = Path(vpaths[key_or_query])
        if key_or_query in VISUAL_CAPTIONS:
            ct, cd = VISUAL_CAPTIONS[key_or_query]
            return p, ct, cd
        return p, fallback_title, "Doğrulanmış yüksek çözünürlüklü klinik şema."

    # 1. Deterministik Kitap/Bölüm/Sayfa Provenance Aşaması
    lookup = _get_master_catalog_lookup()
    kq_clean = key_or_query.lower()
    for entry in ATLAS_SLIDES_DATA:
        et_clean = entry.get("title", "").lower()
        fn = entry.get("img", "")
        if fn == key_or_query or et_clean in kq_clean or kq_clean in et_clean:
            if fn in lookup and Path(lookup[fn]).is_file():
                p = Path(lookup[fn])
                prov = entry.get("provenance", "")
                cap_desc = f"{entry.get('title', '')} [Doğrulanmış Kaynak: {prov}]"
                return p, fallback_title, cap_desc

    # 2. AI Multimodal Arama (Yedek)
    try:
        from ophthalmology_vision_ai import resolve_clinical_visual
        res = resolve_clinical_visual(key_or_query)
        if res and res.get("file_path") and Path(res["file_path"]).is_file():
            p = Path(res["file_path"])
            source = f" [Kaynak: {res.get('book', '')} s.{res.get('page', '')}]"
            caption_text = res.get("caption", "İlgili klinik atlas lezyon bulgusu.")
            return p, fallback_title, caption_text + source
    except Exception:
        pass

    return None, "", ""


def build_atlas_panel_card(
    idx: int,
    entry: Dict[str, Any],
    file_lookup: Dict[str, str],
    styles: Dict[str, ParagraphStyle]
) -> KeepTogether:
    img_name = entry.get("img", "")
    fp_str = file_lookup.get(img_name)
    fp = Path(fp_str) if fp_str else None
    img_w = 76 * mm
    img_h = 50 * mm
    if fp and fp.is_file():
        try:
            img_elem = Image(str(fp), width=img_w, height=img_h)
        except Exception:
            img_elem = Paragraph(f"<b>[Görsel Yüklenemedi: {html.escape(img_name)}]</b>", styles["tbl_cell"])
    else:
        img_elem = Paragraph(f"<b>[Görsel Dosyası: {html.escape(img_name)}]</b>", styles["tbl_cell"])

    t_text = html.escape(entry.get("title", ""))
    prov_text = html.escape(entry.get("provenance", ""))
    pearl_text = html.escape(entry.get("pearl", ""))
    kf_bullets = "<br/>".join([f"• {html.escape(kf)}" for kf in entry.get("key_findings", [])[:3]])
    diff_text = ", ".join([html.escape(d) for d in entry.get("differentials", [])])

    hdr_p = Paragraph(f"<b>LEZYON {idx:02d}: {t_text.upper()}</b>", styles["atlas_title"])
    prov_p = Paragraph(f"<i>Kaynak: {prov_text}</i>", styles["atlas_prov"])
    kf_p = Paragraph(f"<b>Patognomonik / OKT Bulguları:</b><br/>{kf_bullets}", styles["atlas_body"])
    diff_p = Paragraph(f"<b>Ayırıcı Tanı Masası:</b> {diff_text}", styles["atlas_diff"])
    pearl_p = Paragraph(f"<b>💡 Klinik İnci:</b> {pearl_text}", styles["atlas_pearl"])

    right_cell = [
        hdr_p,
        prov_p,
        Spacer(1, 1.2 * mm),
        kf_p,
        Spacer(1, 0.8 * mm),
        diff_p,
        Spacer(1, 1.0 * mm),
        pearl_p
    ]

    card_table = Table([[img_elem, right_cell]], colWidths=[78 * mm, 100 * mm])
    card_table.setStyle(
        TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.6, LINE),
            ("BACKGROUND", (0, 0), (-1, -1), CARD_BG),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
            ("LEFTPADDING", (0, 0), (-1, -1), 4.5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
        ])
    )
    return KeepTogether([card_table, Spacer(1, 3.0 * mm)])


def build_clinical_table_flowables(
    title: str, headers: List[str], rows: List[List[str]], styles: Dict[str, ParagraphStyle], col_widths: Optional[List[float]] = None
) -> List[Any]:
    ncols = len(headers)
    if not col_widths or len(col_widths) != ncols:
        if ncols == 4:
            col_widths = [36.0, 44.0, 48.0, 50.0]
        elif ncols == 5:
            col_widths = [30.0, 32.0, 38.0, 40.0, 38.0]
        elif ncols == 3:
            col_widths = [46.0, 66.0, 66.0]
        else:
            w_each = 178.0 / max(1, ncols)
            col_widths = [w_each] * ncols

    table_data = [[Paragraph(fmt_inline(h), styles["tbl_hdr"]) for h in headers]]
    for r in rows:
        row_cells = []
        for idx, cell_text in enumerate(r[:ncols]):
            st = styles["tbl_cell_bold"] if idx == 0 else styles["tbl_cell"]
            row_cells.append(Paragraph(fmt_inline(str(cell_text)), st))
        table_data.append(row_cells)

    t = Table(table_data, colWidths=[w * mm for w in col_widths], repeatRows=1, splitByRow=1)
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), BLUE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.8, BLUE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("TOPPADDING", (0, 0), (-1, -1), 4.8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.8),
        ("LEFTPADDING", (0, 0), (-1, -1), 6.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6.5),
    ]
    for i in range(1, len(table_data)):
        tstyle.append(("BACKGROUND", (0, i), (-1, i), BLUE_BG if i % 2 == 1 else colors.white))
    t.setStyle(TableStyle(tstyle))

    t_style_key = "small_bold_flow" if len(rows) > 8 else "small_bold"
    title_p = Paragraph(f"<b>■ {html.escape(title)}</b>", styles[t_style_key])
    return [Spacer(1, 2.0 * mm), title_p, t, Spacer(1, 3.0 * mm)]


def build_pearls_flowables(title: str, points: List[str], styles: Dict[str, ParagraphStyle]) -> List[Any]:
    rows = [[Paragraph(f"<b>► KLİNİK İNCİLER VE MEKANİZMA KURALLARI: {html.escape(title)}</b>", styles["tbl_hdr"])]]
    for idx, pt in enumerate(points, 1):
        rows.append([Paragraph(f'<font color="#087d6c"><b>[{idx}]</b></font> &nbsp;{fmt_inline(pt)}', styles["tbl_cell"])])
    t = Table(rows, colWidths=[178 * mm], repeatRows=1, splitByRow=1)
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("BOX", (0, 0), (-1, -1), 0.8, GREEN),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4.8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.8),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]
    for i in range(1, len(rows)):
        tstyle.append(("BACKGROUND", (0, i), (-1, i), GREEN_BG if i % 2 == 1 else colors.white))
    t.setStyle(TableStyle(tstyle))
    return [Spacer(1, 2.0 * mm), t, Spacer(1, 3.0 * mm)]


def build_mnemonic_flowables(mn: Dict[str, Any], styles: Dict[str, ParagraphStyle]) -> List[Any]:
    code = str(mn.get("code", "KLİNİK KOD"))
    items = mn.get("items", [])
    golden = str(mn.get("golden_rule", ""))
    data = [[Paragraph("<b>KOD</b>", styles["tbl_hdr"]), Paragraph(f"<b>◆ KLİNİK MNEMONIC: {html.escape(code)}</b>", styles["tbl_hdr"])]]
    for it in items:
        k_str = str(it.get("key", ""))
        d_str = str(it.get("desc", ""))
        data.append(
            [
                Paragraph(f'<font color="#6941a5"><b>{html.escape(k_str)}</b></font>', styles["tbl_cell_bold"]),
                Paragraph(fmt_inline(d_str), styles["tbl_cell"]),
            ]
        )
    if golden:
        data.append(
            [
                Paragraph('<font color="#a46109"><b>ALTIN KURAL</b></font>', styles["tbl_cell_bold"]),
                Paragraph(fmt_inline(golden), styles["tbl_cell_bold"]),
            ]
        )
    t = Table(data, colWidths=[34 * mm, 144 * mm], repeatRows=1, splitByRow=1)
    tstyle = [
        ("BACKGROUND", (0, 0), (-1, 0), PURPLE),
        ("BOX", (0, 0), (-1, -1), 0.8, PURPLE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4.8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.8),
        ("LEFTPADDING", (0, 0), (-1, -1), 7.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7.5),
    ]
    for i in range(1, len(data)):
        if golden and i == len(data) - 1:
            tstyle.append(("BACKGROUND", (0, i), (-1, i), AMBER_BG))
        else:
            tstyle.append(("BACKGROUND", (0, i), (-1, i), PURPLE_BG if i % 2 == 1 else colors.white))
    t.setStyle(TableStyle(tstyle))
    return [Spacer(1, 2.0 * mm), t, Spacer(1, 3.0 * mm)]


def build_case_flowables(cv: Dict[str, Any], styles: Dict[str, ParagraphStyle]) -> List[Any]:
    title = str(cv.get("title", "Klinik Senaryo"))
    data = [
        [Paragraph("<b>Aşama</b>", styles["tbl_hdr"]), Paragraph(f"<b>● KLİNİK VAKA VE AKIL YÜRÜTME: {html.escape(title)}</b>", styles["tbl_hdr"])],
        [Paragraph('<font color="#6941a5"><b>Klinik Durum</b></font>', styles["tbl_cell_bold"]), Paragraph(fmt_inline(str(cv.get("scenario", ""))), styles["tbl_cell"])],
        [Paragraph('<font color="#6941a5"><b>Mekanizma &amp; Analiz</b></font>', styles["tbl_cell_bold"]), Paragraph(fmt_inline(str(cv.get("reasoning", ""))), styles["tbl_cell"])],
        [Paragraph('<font color="#087d6c"><b>Klinik Karar</b></font>', styles["tbl_cell_bold"]), Paragraph(fmt_inline(str(cv.get("decision", ""))), styles["tbl_cell"])],
    ]
    t = Table(data, colWidths=[34 * mm, 144 * mm], repeatRows=1, splitByRow=1)
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), PURPLE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("BOX", (0, 0), (-1, -1), 0.8, PURPLE),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 5.0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5.0),
                ("LEFTPADDING", (0, 0), (-1, -1), 7.5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7.5),
                ("BACKGROUND", (0, 1), (0, 2), PURPLE_BG),
                ("BACKGROUND", (1, 1), (1, 1), colors.white),
                ("BACKGROUND", (1, 2), (1, 2), ROW_ALT),
                ("BACKGROUND", (0, 3), (0, 3), GREEN_BG),
                ("BACKGROUND", (1, 3), (1, 3), colors.white),
            ]
        )
    )
    return [Spacer(1, 2.0 * mm), t, Spacer(1, 3.0 * mm)]


VISUAL_CAPTIONS: Dict[str, Tuple[str, str]] = {
    "schema_0_epi_metabolic": (
        "Şekil 1.1 — Diyabet Süresi-Prevalans Eğrisi, Fenofibrat (FIELD/ACCORD/LENS), GLP-1RA Erken Kötüleşme ve Epigenetik Hafıza",
        "WESDR/Teo 2021 süre-prevalans dinamiği, DCCT/EDIC epigenetik metabolik hafıza, PPAR-α bağımsız fenofibrat koruması (LENS 2024) ve hızlı HbA1c düşüşünde semaglutid erken kötüleşme mekanizması.",
    ),
    "schema_1": (
        "Şekil 2.1 — Diyabetik Nörovasküler Ünite Hasarı, Ang-2/Tie-2 Ekseni ve KRB Yıkımı",
        "Erken nörodejenerasyon, 4 biyokimyasal yolak (Polyol, AGE-RAGE, PKC-β, Heksozamin), ICAM-1/CD18 lökostazı, Ang-2/Tie-2 perisit ayrılması ve Müller hücresi (Kir4.1/AQP4) pompa yetmezliği.",
    ),
    "panel_dme_brb_oct": (
        "Klinik Görüntü 2.2 — İç Kan-Retina Bariyeri Yıkımı ve SD-OKT'de Kistoid / Seröz DMÖ",
        "AAO BCSC 2023-2024 Section 12 veritabanından: Mikroanevrizma sızıntısı, RPE pompa yönü, intraretinal kistoid boşluklar, subfoveal seröz dekolman ve hiperreflektif eksüda odakları.",
    ),
    "panel_etdrs_421_uwfa": (
        "Klinik Görüntü 3.1 — Ağır NPDR '4:2:1 Kuralı' Standart Fotoğrafları ve Ultra-Geniş Açılı FA (Protokol AA)",
        "AAO BCSC 2023-2024 Section 12 veritabanından: 4 kadran ≥20 hemoraji (Std 2A), ≥2 kadran venöz boncuklanma (Std 6B), ≥1 kadran belirgin IRMA ve UWFA periferik kapiller nonperfüzyon.",
    ),
    "panel_hr_pdr_nvd_nve": (
        "Klinik Görüntü 3.2 — Yüksek Riskli Proliferatif Diyabetik Retinopati (NVD, NVE ve Preretinal Kanama)",
        "AAO BCSC 2023-2024 ve Güncel Retina arşivinden: Optik disk alanının >1/4-1/3'ünü aşan NVD, preretinal hemoraji eşlikli NVE (DRS Std 7) ve geç faz yoğun floresein sızıntısı.",
    ),
    "schema_2": (
        "Şekil 4.1 — Yapısal OKT Biyobelirteçleri, UWFA (PPL) ve Katman-Bazlı OKTA Korelasyonu",
        "Otani DMÖ paternleri, foveal DRIL (>1 mm), HRF (<30 µm, gölgesiz mikroglial belirteç), sert eksüda arka gölgelenmesi vs seröz PED ayrımı, ELM/EZ bütünlüğü ve SD-OKTA vs SS-OKTA fiziği.",
    ),
    "panel_octa_faz_dril": (
        "Klinik Görüntü 4.2 — En-Face OKTA FAZ Genişlemesi ve Yapısal OKT'de Foveal DRIL",
        "AAO BCSC 2023-2024 ve Güncel Retina arşivinden: Erken vs ileri DR'de perifoveal kapiller halka yıkımıyla FAZ genişlemesi ve yapısal OKT'de iç retina katman organizasyon kaybı (DRIL).",
    ),
    "schema_3": (
        "Şekil 5.1 — Kanıta Dayalı DMÖ Tedavi Algoritması (Protokol V, Protokol T ve Protokol AC)",
        "Merkezi tutan DMÖ'de GK ≥20/25 gözlem (Protokol V), GK 20/32-20/40 eşdeğerliği, GK ≤20/50 aflibercept üstünlüğü (Protokol T) ve bevacizumab-ilk basamaklı geçiş (Protokol AC).",
    ),
    "panel_dme_ci_nci_prp": (
        "Klinik Görüntü 5.2 — Merkezi Tutmayan vs Merkezi Tutan DMÖ OKT Haritası ve Panretinal Fotokoagülasyon",
        "AAO BCSC 2023-2024 Section 12 veritabanından: ETDRS santral 1 mm alt alan kalınlık haritasında Non-CI vs CI-DME ayrımı ve panretinal fotokoagülasyon (PRP) skar paterni.",
    ),
    "schema_6_steroid_switch": (
        "Şekil 6.1 — Kortikosteroid Farmakokinetik Paradoksu ve İnflamatuvar DMÖ'de Erken Switch Algoritması",
        "GR afinitesi (DEX > TA > FA) vs vitreus kalış süresi ters orantısı, vitrektomize gözde PLGA implant avantajı (CHAMPLAIN), Protokol U ve OKT inflamatuvar dörtlüsünde (SMD+HRF) erken switch.",
    ),
    "panel_oct_dril_vmt": (
        "Klinik Görüntü 6.2 — İnflamatuvar/Dirençli DMÖ OKT Fenotipi (SMD + HRF) ve Traksiyonel VMT Ayrımı",
        "AAO BCSC 2023-2024 ve Güncel Retina arşivinden: Sol panelde erken steroid switch adayı SMD + dev kist + HRF; sağ panelde farmakoterapi yerine PPV gerektiren kalın arka hiyaloid VMT.",
    ),
    "schema_4": (
        "Şekil 7.1 — Konvansiyonel Lazer, Endpoint Management (%30) ve 577 nm Subliminal Mikropulse (DIAMOND)",
        "%5 görev döngüsü (100 µs açık / 1900 µs kapalı) sayesinde termal nekroz eşiğini aşmadan RPE'de HSP70 uyarımı, Müller biyomodülasyonu ve MFK ≤400 µm DIAMOND RKÇ kuralı.",
    ),
    "schema_7_nextgen_2026": (
        "Şekil 7.2 — 2020-2026 Yeni Nesil Retinal Biyolojikler ve Uzatılmış Dayanıklılık Mekanizmaları",
        "Faricimab bispesifik Ang-2 + VEGF-A blokajı (YOSEMITE/RHINE q16w), Aflibercept 8 mg 4x molar doz (PHOTON), PDS Susvimo (PAGODA/PAVILION) ve Brolucizumab/Abicipar İOİ-vaskülit güvenliği.",
    ),
    "schema_5": (
        "Şekil 8.1 — Diyabetik VİH (Protokol AB) ve TRD Cerrahi Biyomekaniği",
        "Preoperatif anti-VEGF sonrası 3-7 gün (<10 gün) 'Crunch' kuralı, 200 kat membran direnci yasası, 27G eğimli uç (beveled-tip) MIVS ve dikey segmentasyon vs yatay en bloc delaminasyon.",
    ),
    "panel_trd_surgery_db": (
        "Klinik Görüntü 8.2 — Masaüstü (Tabletop) Diyabetik TRD, Kromofor Fiziği ve Bimanuel En Bloc Delaminasyon",
        "AAO BCSC 2023-2024 ve Güncel Retina arşivinden: Arkadlar boyunca fibrovasküler masaüstü TRD, 577 nm kromofor seçiciliği ve bimanuel makasla yatay membran delaminasyonu.",
    ),
    "schema_8_biostat_gee": (
        "Şekil 9.1 — Oftalmolojik Klinik Çalışmalarda Analiz Birimi: Hasta Düzeyi vs Göz Düzeyi (ICC, GEE ve Karma Modeller)",
        "Bilateral gözlerin ortak sistemik/genetik varyansı (ICC), naif t-testi/Ki-karede yapay örneklem şişmesi ve Tip I hata artışı; SPSS'te Karma Etkili Model ve GEE çözüm mimarisi.",
    ),
}


def _safe_page_break(story: List[Any]) -> None:
    """Sayfa sonuna denk gelen kuyruk Spacer elemanlarını temizleyerek boş sayfa oluşumunu kesin olarak önler."""
    while story and isinstance(story[-1], Spacer):
        story.pop()
    story.append(PageBreak())


def _lookup_verified_pmid(articles: List[Dict[str, Any]], *keywords: str) -> str:
    """Canlı PubMed'den çekilmiş makale listesinde anahtar kelimeleri eşleştirip doğrulanmış PMID etiketini döndürür."""
    for art in articles:
        haystack = f"{art.get('title', '')} {art.get('formatted', '')}".lower()
        if all(k.lower() in haystack for k in keywords):
            return f" [PMID:{art['pmid']}]"
    return ""


def publish_study_pdf_node(state: MasterStudyState) -> Dict[str, Any]:
    emit("[4/5] ReportLab Pro ile 16 görselli, tıklanabilir PubMed/DOI bağlantılı 2026 Çalışma PDF'i derleniyor...")
    register_fonts()
    styles = make_styles()
    mods = state["sorted_modules"]
    vpaths = state["visual_paths"]

    # Tüm modüllerdeki doğrulanmış canlı PubMed ve yerel veritabanı kayıtlarını tekilleştir
    seen_pmids: Dict[str, Dict[str, Any]] = {}
    all_db_refs: List[Tuple[str, str]] = []
    seen_db_set: set[str] = set()
    for m in mods:
        mid = m["module_id"]
        for art in m.get("pubmed_refs", []):
            pid = str(art.get("pmid", ""))
            if pid and pid not in seen_pmids:
                seen_pmids[pid] = {**art, "module_id": mid}
        for dbr in m.get("db_refs", []):
            if dbr not in seen_db_set:
                seen_db_set.add(dbr)
                all_db_refs.append((mid, dbr))
    pm_all_list = list(seen_pmids.values())

    story: List[Any] = []

    # ------------------------------------------
    # KAPAK VE PROTOKOL MATRİSİ (SAYFA 1)
    # ------------------------------------------
    story.append(
        build_chapter_banner(
            "AKADEMİK ÇALIŞMA ORTAĞI — ALL_GEMINI LANGGRAPH + YEREL VERİTABANI + CANLI PUBMED (2026)",
            "DİYABETİK RETİNOPATİ VE DİYABETİK MAKÜLA ÖDEMİ",
            "Patogenez, Multimodal Görüntüleme (UWFA/OKT/OKTA), Anti-VEGF & Yeni Biyolojikler, Steroid Switch, Subliminal Lazer, Cerrahi ve Biyoistatistik",
            styles,
        )
    )

    calq_before = sum(int((m.get("humanization_metrics") or {}).get("calques_before", 0)) for m in mods)
    calq_after = sum(int((m.get("humanization_metrics") or {}).get("calques_after", 0)) for m in mods)
    paudit = state.get("pipeline_audit") or {}
    audit_score_lbl = f"{paudit.get('complexity_score', 9)}/10"

    meta_rows = [
        [
            "3 Kanıt Akışlı Mimari",
            f"1) Güncel Retina 2018;2(2):89-207 (15 Makale, 96 s. Tam Metin) · 2) Yerel Veritabanı: AAO BCSC 2023-2024 Section 12 & Güncel Retina 2021-2026 Tam Metinleri ({len(all_db_refs)} Bölüm) · 3) Canlı NCBI PubMed E-Utilities ({len(seen_pmids)} Doğrulanmış 2019-2026 Makale, Tıklanabilir PMID/DOI)",
        ],
        [
            "all_gemini + Auditor Hattı",
            f"langgraph_auditor.py (`all_gemini`, Topoloji Puanı: {audit_score_lbl}) -> local_db_retrieval + pubmed_research -> Gemini 3.8 Flash (Reader) -> Gemini 4 Argon (Author) -> Gemini 3.8 Flash (Reviewer) -> academic_turkish_humanizer_node (8/8 Modül Baş-Son Akademik Türkçe Onaylı)",
        ],
        [
            "Klasik + 2019-2026 RKÇ'ler",
            "DCCT/EDIC, UKPDS, FIELD, ACCORD, LENS (2024), SUSTAIN-6/FOCUS, ETDRS, RESTORE, RIDE/RISE, VISTA/VIVID, DRCR.net Protokol B/D/I/S/T(5-Yıl)/U/V/W(4-Yıl)/AA/AB/AC, MEAD, FAME, PALADIN, DIAMOND, YOSEMITE/RHINE/RHONE-X (Faricimab), PHOTON (Aflibercept 8 mg), KESTREL/KITE, PAGODA/PAVILION",
        ],
        [
            "Görsel & Pedagojik Yapı",
            "16 Yüksek Çözünürlüklü Görsel (9 Vektörel Mekanizma/Algoritma Şeması + 7 AAO BCSC & Dergi Klinik Görüntü Paneli) · Hasta vs Göz Düzeyi (ICC, GEE, Karma Modeller) · Bağımsız Cevap Anahtarlı 16 Aktif Hatırlama Sorusu",
        ],
    ]
    story.extend(
        build_clinical_table_flowables(
            "Çalışma Rehberi Metodolojik Kimlik ve Çok Kaynaklı Kapsam Matrisi (2026 Baskısı)",
            ["Protokol Bileşeni", "Ayrıntılı Akademik ve Teknik Kapsam"],
            meta_rows,
            styles,
            col_widths=[44.0, 134.0],
        )
    )

    map_rows = [
        ["Bölüm 1 (M01)", "Makale 1 & 3 + BCSC S12 + PubMed", "Epidemiyoloji (Teo 2021), DCCT/EDIC, UKPDS, LENS Fenofibrat (2024), GLP-1RA erken kötüleşme, 2026 genetik/epigenetik"],
        ["Bölüm 2 (M02)", "Makale 2 + BCSC S12 + PubMed", "Erken nörodejenerasyon (NVÜ), perisit apoptozu, Ang-2/Tie-2 ekseni, 4 yolak, lökostaz, KRB ve Müller (AQP4/Kir4.1)"],
        ["Bölüm 3 (M03)", "Makale 4 & 5 + BCSC S12 + GR 2025", "ETDRS 4:2:1, IRMA vs NVE, santral 1 mm DMÖ, Protokol V (GK ≥20/25), Protokol W (NPDR), otonom AI tarama ve katarakt"],
        ["Bölüm 4 (M04)", "Makale 6 & 7 + BCSC S12 + PubMed", "FA, UWFA periferik lezyonlar (Protokol AA), geniş açılı SS-OKTA, Otani paternleri, HRF, ELM/EZ ve foveal DRIL"],
        ["Bölüm 5 (M05)", "Makale 8 & 9 + BCSC S12 + PubMed", "RNB/AFL/BVZ kinetiği; RESTORE, RIDE/RISE, VISTA/VIVID, Protokol I/S/T 5-Yıl uzatma ve Protokol AC (step-therapy)"],
        ["Bölüm 6 (M06)", "Makale 10 & 11 + BCSC S12 + PubMed", "DEX/TA/FA steroid paradoksu (MEAD, CHAMPLAIN, FAME, PALADIN), Protokol U ve OKT biyobelirteçli erken Switch"],
        ["Bölüm 7 (M07)", "Makale 12 & 13 + BCSC S12 + PubMed", "577 nm mikropulse (%5 DC, HSP70, DIAMOND RKÇ), Faricimab (YOSEMITE/RHINE), Aflibercept 8 mg (PHOTON), PDS & Brolucizumab"],
        ["Bölüm 8 (M08)", "Makale 14 & 15 + GR 2023 Özel Sayı", "DMÖ PPV, Protokol AB (VİH), preop anti-VEGF Crunch (3-7 gün), 27G eğimli uç (beveled-tip), iOCT ve bimanuel delaminasyon"],
    ]
    story.extend(
        build_clinical_table_flowables(
            "15 Birincil Makale + Yerel Veritabanı + Canlı PubMed Modüler Sentez Haritası",
            ["Modül", "Birleştirilen Kaynak Akışları", "Çekirdek Mekanizma ve 2019-2026 Güncel Klinik Hedefler"],
            map_rows,
            styles,
            col_widths=[28.0, 56.0, 94.0],
        )
    )

    # ------------------------------------------
    # BÖLÜM 1 - 8: LANGGRAPH + GEMİNİ 4 ARGON MODÜLLERİ
    # ------------------------------------------
    all_questions: List[Tuple[str, str, str, str]] = []

    for m_idx, mod in enumerate(mods, 1):
        _safe_page_break(story)
        story.append(build_chapter_banner(mod["kicker"], mod["title"], mod["subtitle"], styles))
        story.extend(build_callout_box("ÖNE ÇIKAN TEMEL İLKE VE MEKANİZMA ÖZETİ", mod.get("lead_principle", ""), BLUE, BLUE_BG, styles))

        vkeys = mod.get("visual_keys", [])
        if vkeys:
            vk0 = vkeys[0]
            v_p0, ct0, cd0 = resolve_module_visual_and_caption(vk0, vpaths, mod.get("title", "Klinik Görsel"))
            if v_p0:
                story.append(build_visual_card(v_p0, ct0, cd0, styles))

        secs = mod.get("sections", [])
        for s_idx, sec in enumerate(secs):
            story.append(Paragraph(fmt_inline(sec.get("heading", "")), styles["sec_title"]))
            for p_txt in sec.get("paragraphs", []):
                story.append(Paragraph(fmt_inline(p_txt), styles["body"]))

            # İkinci görsel varsa 2. alt bölümden sonra yerleştir (metin duvarını kırar)
            if s_idx == 1 and len(vkeys) > 1:
                vk1 = vkeys[1]
                v_p1, ct1, cd1 = resolve_module_visual_and_caption(vk1, vpaths, sec.get("heading", "Klinik Görsel"))
                if v_p1:
                    story.append(build_visual_card(v_p1, ct1, cd1, styles))

        tbl = mod.get("clinical_table") or {}
        if tbl.get("headers") and tbl.get("rows"):
            story.extend(build_clinical_table_flowables(tbl.get("title", "Klinik Karşılaştırma Tablosu"), tbl["headers"], tbl["rows"], styles))

        if mod.get("pearls"):
            story.extend(build_pearls_flowables(mod["title"], mod["pearls"], styles))

        if mod.get("mnemonic"):
            story.extend(build_mnemonic_flowables(mod["mnemonic"], styles))

        if mod.get("case_vignette"):
            story.extend(build_case_flowables(mod["case_vignette"], styles))

        if mod.get("pitfall_warning"):
            story.extend(
                build_callout_box(
                    "KLİNİK TUZAK, İSTİSNA VE METODOLOJİK SINIR",
                    mod["pitfall_warning"],
                    AMBER,
                    AMBER_BG,
                    styles,
                )
            )

        for q_i, q_obj in enumerate(mod.get("active_recall_questions", []), 1):
            all_questions.append(
                (
                    f"Bölüm {m_idx} ({mod['module_id']}.{q_i})",
                    mod["title"],
                    str(q_obj.get("question", "")),
                    str(q_obj.get("answer_rationale", "")),
                )
            )

    # ------------------------------------------
    # BÖLÜM 9: LANDMARK ÇALIŞMALAR & BİYOİSTATİSTİK ANALİZ BİRİMİ REHBERİ
    # ------------------------------------------
    _safe_page_break(story)
    story.append(
        build_chapter_banner(
            "BÖLÜM 9 · METODOLOJİ VE KANIT SENTEZİ (1985–2026)",
            "LANDMARK KLİNİK ÇALIŞMALAR VE BİYOİSTATİSTİKSEL ANALİZ BİRİMİ REHBERİ",
            "Hasta Düzeyi (Patient-Level) vs Göz Düzeyi (Eye-Level) İntra-class Korelasyon, GEE / Karma Modeller ve SPSS Kodlama Adımları",
            styles,
        )
    )
    story.extend(
        build_callout_box(
            "OFTALMOLOJİDE METODOLOJİK ALTIN KURAL (ANALİZ BİRİMİ)",
            "Diyabetik retinopati ve DMÖ sistemik metabolik bir hastalığın bilateral oküler tezahürüdür. Aynı hastanın sağ ve sol gözü ortak HbA1c, kan basıncı, eGFR, genetik polimorfizmler (VEGFA, ALR2) ve vasküler yaşlanmayı paylaştığından yüksek sınıf içi korelasyon (intra-class correlation - ICC) sergiler. İki gözü birbirinden bağımsız iki hasta gibi standart t-testi veya Ki-kare ile analiz etmek örneklem boyutunu yapay şişirir, standart hatayı küçültür ve Tip I hatayı (yalancı pozitif p değeri) artırır.",
            PURPLE,
            PURPLE_BG,
            styles,
        )
    )

    if "schema_8_biostat_gee" in vpaths and "schema_8_biostat_gee" in VISUAL_CAPTIONS:
        ct9, cd9 = VISUAL_CAPTIONS["schema_8_biostat_gee"]
        story.append(build_visual_card(Path(vpaths["schema_8_biostat_gee"]), ct9, cd9, styles))

    stat_paras = [
        "**9.1 DR ve DMÖ Klinik Çalışmalarında Hasta Düzeyi (*Patient-Level*) vs. Göz Düzeyi (*Eye-Level*) Tasarım Farkları:** "
        "Büyük faz 3 ruhsat çalışmalarının çoğunda (örneğin **RESTORE**, **RIDE/RISE**, **VISTA/VIVID**, **YOSEMITE/RHINE**, **PHOTON** ve **MEAD**) her hastadan yalnızca **tek bir çalışma gözü (*study eye*)** "
        "randomize edilerek analiz birimi doğrudan hasta düzeyinde (*patient-level*, N_göz = N_hasta) tutulmuştur; böylece gözler arası bağımlılık tasarım aşamasında ortadan kaldırılmıştır. "
        "Buna karşın **DRCR.net Protokol B**, **Protokol I**, **Protokol S** ve **Protokol AA** gibi klinik pratik ve doğal seyir odaklı çalışmalarda iki gözü de uygun olan hastalarda her iki göz çalışmaya dahil edilebilmiştir (*bilateral eye eligibility*). "
        "Bu durumda göz düzeyi (*eye-level*) sonlanımlar (örneğin santral alt alan kalınlığı değişimi, ≥2 basamak DR progresyonu veya ≥15 harf kazanımı) analiz edilirken hasta kümelemesini (*clustering by subject ID*) hesaba katan **Genelleştirilmiş Tahmin Denklemleri (*Generalized Estimating Equations* - GEE)** veya **Doğrusal/Genelleştirilmiş Karma Etkili Modeller (*Linear / Generalized Linear Mixed-Effects Models*)** kullanılması zorunludur.",
        "**9.2 Klinik Araştırma ve Tezlerde Pratik SPSS Uygulama ve Veri Kodlama Protokolü:** "
        "Kendi retrospektif veya prospektif DMÖ serini (örneğin anti-VEGF'ten deksametazon implantına veya faricimab'a *switch* yapılan hastalar ya da 577 nm subliminal lazer sonuçları) SPSS'te analiz ederken şu 4 basamağı izlemelisin: "
        "**(1) Uzun Format (*Long Format*) Veri Girişi:** Her satır tek bir gözü (ve tekrarlı ölçüm varsa tek bir zaman noktasını) temsil eder; `Hasta_ID` (küme değişkeni), `Goz_Tarafi` (`1=Sağ`, `2=Sol`), `Zaman` (`0=Başlangıç`, `1=1.Ay`, `3=3.Ay`), `Grup` (`1=AntiVEGF`, `2=Switch`), `EIGK_LogMAR` (sürekli; Snellen yerine daima LogMAR veya ETDRS harf skoru kullanılmalıdır!) ve `MFK_um` sütunları oluşturulur. "
        "**(2) Varsayım ve ICC Kontrolü:** Sürekli değişkenlerin dağılımı histogram/Q-Q grafiği ve kalıntı (*residual*) analiziyle incelenir; karma modelde rastgele kesişim (*random intercept* = `Hasta_ID`) varyansının toplam varyansa oranıyla gözler arası **ICC** hesaplanır. "
        "**(3) Sürekli Sonlanım (LogMAR GK veya MFK) İçin Karma Model:** SPSS'te `Analyze > Mixed Models > Linear` menüsünden `Subjects: Hasta_ID`, `Repeated: Goz_Tarafi` (veya `Zaman`) seçilip kovaryans yapısı (*Compound Symmetry* veya zaman serilerinde *AR(1)* / *Unstructured*) tanımlanarak sabit etkilere grup, zaman ve `Grup*Zaman` etkileşimi eklenir. "
        "**(4) İkili Sonlanım (Örn. MFK <300 µm Kuruma veya GİB Artışı Evet/Hayır) İçin GEE:** SPSS'te `Analyze > Generalized Linear Models > Generalized Estimating Equations` menüsünden `Subject variables: Hasta_ID`, `Within-subject: Goz_Tarafi`, çalışma korelasyon matrisi *Exchangeable* ve dağılım *Binary Logistic* seçilerek küme-dirençli (*robust sandwich*) standart hatalarla düzeltilmiş *odds ratio* (%95 GA) raporlanır.",
    ]
    for sp in stat_paras:
        story.append(Paragraph(fmt_inline(sp), styles["body"]))

    landmark_rows = [
        ["DCCT (1993) & EDIC", "Tip 1 DM (n=1441), yoğun vs konvansiyonel glisemik kontrol", "Yoğun kol yeni DR'yi %76, progresyonu %54 azalttı; ilk yıl 'erken kötüleşme', uzun vadede epigenetik 'metabolik hafıza'.", "Hasta düzeyi (7 alan stereo fundus)"],
        ["UKPDS (1998)", "Yeni tanı Tip 2 DM, sıkı glisemik & sıkı KB (<150/85) kontrolü", "Her %1 HbA1c düşüşü mikrovasküler riski %35, sıkı KB kontrolü DR progresyonunu %34 ve lazer ihtiyacını %35 azalttı.", "Hasta düzeyi RKÇ"],
        [
            "FIELD, ACCORD-Eye & LENS (2024)" + _lookup_verified_pmid(pm_all_list, "fenofibrate"),
            "Tip 1/2 DM; Fenofibrat (PPAR-α agonisti) vs Plasebo",
            "FIELD/ACCORD'da lazer ve DR progresyonunda %31-40 azalma; LENS (2024) RKÇ'de sevk edilebilir DR/makülopati veya tedavi gelişiminde anlamlı azalma (lipidden bağımsız!).",
            "Hasta düzeyi RKÇ",
        ],
        ["ETDRS (1985-1991)", "NPDR/PDR ve KAMÖ (CSME); fokal/grid lazer ve PRP zamanlaması", "Fokal/grid lazer orta dereceli görme kaybını (≥15 harf) 3 yılda %24'ten %12'ye (%50 rölatif azalma) düşürdü.", "Bilateral eşleştirilmiş göz kontrolü"],
        ["RESTORE, RIDE/RISE & VISTA/VIVID", "Ranibizumab 0.3/0.5 mg ve Aflibercept 2q4/2q8 ruhsat RKÇ'leri", "Anti-VEGF monoterapisi maküler lazere ezici görsel üstünlük (+6.8 ila +11.5 harf vs +0.9 harf) ve DR evresinde ≥2 basamak gerileme sağladı.", "Hasta başı tek çalışma gözü (Patient-level)"],
        [
            "DRCR.net Protokol I & S (5 Yıl)" + _lookup_verified_pmid(pm_all_list, "panretinal photocoagulation", "five-year"),
            "DMÖ'de RNB+ertelenmiş lazer; PDR'de RNB vs PRP (5 yıl)",
            "Protokol I: ertelenmiş lazer üstün, enjeksiyon yükü 4-5. yılda düşer. Protokol S 5-yıl: RNB ve PRP GK benzer (~20/25), RNB'de daha az GA kaybı ve DMÖ (ancak takipten kopma riski!).",
            "Bilateral göz uygunluğu (GEE/karma analiz)",
        ],
        [
            "DRCR.net Protokol T (1, 2 & 5 Yıl)" + _lookup_verified_pmid(pm_all_list, "five-year", "aflibercept"),
            "Aflibercept 2 mg vs Ranibizumab 0.3 mg vs Bevacizumab 1.25 mg",
            "GK ≥69 harf: 3 ajan eşdeğer. GK <69 harf: 1. yıl AFL > RNB > BVZ; 2. yıl AFL≈RNB. 5. yıl uzatmada rutin pratikte MFK korunsa da 2. yıla göre ortalama GK gerilemesi.",
            "Hasta başı tek çalışma gözü",
        ],
        [
            "DRCR.net Protokol V (2019)" + _lookup_verified_pmid(pm_all_list, "good visual acuity"),
            "GK ≥20/25 iyi gören merkezi tutan DMÖ: Gözlem vs Lazer vs AFL",
            "2 yılda ≥5 harf görme kaybı oranlarında 3 kol arasında anlamlı fark yok (%16-%19); GK düşmedikçe başlangıç gözlem güvenli ve maliyet-etkin.",
            "Hasta başı tek çalışma gözü",
        ],
        [
            "DRCR.net Protokol W (2-4 Yıl)" + _lookup_verified_pmid(pm_all_list, "nonproliferative", "aflibercept"),
            "DMÖ olmayan orta-ağır NPDR: Profilaktik Aflibercept vs Sham",
            "Aflibercept PDR ve merkezi DMÖ gelişimini anlamlı azaltsa da 2 ve 4. yılda net görme keskinliği üstünlüğü sağlamadı; yakın takip esastır.",
            "Bilateral uygunluk (korelasyon düzeltmeli)",
        ],
        [
            "DRCR.net Protokol AA (2022)" + _lookup_verified_pmid(pm_all_list, "predominantly peripheral"),
            "UWFA periferik ağırlıklı lezyonlar (PPL) ve nonperfüzyon (4 yıl)",
            "UWFA'da PPL ve yaygın periferik kapiller nonperfüzyon varlığı, standart ETDRS 7-alan ötesinde ≥2 basamak DR kötüleşmesini ve tedavi ihtiyacını öngördü.",
            "Göz düzeyi longitudinal kohort (GEE/orantılı hazard)",
        ],
        [
            "DRCR.net Protokol AC (2022)" + _lookup_verified_pmid(pm_all_list, "bevacizumab first"),
            "GK 20/50-20/320 DMÖ: Bevacizumab-ilk step-therapy vs Aflibercept",
            "Önce bevacizumab başlanıp alt-optimal yanıtta (~%70 göz) aflibercept'e geçiş, 2 yıllık EİGK eğri altı alanında doğrudan aflibercept monoterapisine eşdeğer (non-inferior) bulundu.",
            "Bilateral uygunluk (karma doğrusal model)",
        ],
        [
            "MEAD, FAME, PALADIN & Protokol U" + _lookup_verified_pmid(pm_all_list, "continued ranibizumab", "dexamethasone"),
            "DEX 0.7 mg, Fluosinolon 0.19 mg ve persistan DMÖ kombinasyonu",
            "MEAD/CHAMPLAIN: vitrektomize gözde DEX etkili. FAME/PALADIN: kronik DMÖ'de enjeksiyon yükünü azaltır. Protokol U: RNB+DEX anatomik incelmeyi artırdı.",
            "Tek göz (MEAD/FAME/U) & göz kohortu",
        ],
        [
            "DIAMOND RKÇ (2023)" + _lookup_verified_pmid(pm_all_list, "subthreshold micropulse"),
            "MFK <400 µm merkezi DMÖ: 577 nm Subliminal Mikropulse vs Standart Lazer",
            "24. ayda 577 nm eşik altı mikropulse lazer görsel keskinlik, MFK ve kurtarma enjeksiyonu ihtiyacında konvansiyonel lazere klinik eşdeğer ve skarsız bulundu.",
            "Hasta başı çalışma gözü RKÇ",
        ],
        [
            "YOSEMITE, RHINE & RHONE-X" + _lookup_verified_pmid(pm_all_list, "faricimab"),
            "Faricimab 6 mg (bispesifik Ang-2/VEGF-A, T&E q16w'ye dek) vs AFL 2q8",
            "Aflibercept 2q8'e görsel eşdeğerlik, güçlü anatomik kurutma; hastaların ~%60'ı q16w ve ~%78-80'i ≥q12w doz aralığına ulaştı (4 yıl güvenliği korundu).",
            "Hasta başı tek çalışma gözü (Patient-level)",
        ],
        [
            "PHOTON, KESTREL/KITE & PAGODA" + _lookup_verified_pmid(pm_all_list, "aflibercept 8 mg"),
            "Aflibercept 8 mg (q12/q16w), Brolucizumab 6 mg ve PDS Susvimo",
            "PHOTON: AFL 8 mg q12/q16w görsel non-inferior. KESTREL/KITE: Brolucizumab güçlü kurutma fakat İOİ/okülüzif vaskülit uyarısı! PAGODA: 24 hf rezervuar dolumu (endoftalmi dikkati!).",
            "Hasta başı tek çalışma gözü (Faz 3)",
        ],
        [
            "DRVS & DRCR.net Protokol AB (2020)" + _lookup_verified_pmid(pm_all_list, "vitreous hemorrhage", "vitrectomy"),
            "PDR kaynaklı VİH: İntravitreal Aflibercept vs Erken PPV + Endolazer",
            "Protokol AB: 24 hf ortalama GK EAA'da anlamlı fark yok; ancak erken PPV kolunda daha hızlı kanama temizlenmesi, daha az rekürren VİH ve daha az TRD gelişimi saptandı.",
            "Hasta başı tek çalışma gözü",
        ],
    ]
    story.extend(
        build_clinical_table_flowables(
            "Diyabetik Retinopati ve DMÖ Landmark Klinik Çalışmalar ve Analiz Birimi Master Matrisi (1985–2026)",
            ["Çalışma & PMID", "Popülasyon & Karşılaştırma", "Temel Kanıt ve Sayısal Sonuç", "Analiz Birimi / Tasarım"],
            landmark_rows,
            styles,
            col_widths=[36.0, 42.0, 66.0, 34.0],
        )
    )

    # ------------------------------------------
    # BÖLÜM 10: DOĞRULANMIŞ BÜYÜK GÖRSEL VE TANI ATLASI (40 PATOLOJİ PANELİ)
    # ------------------------------------------
    _safe_page_break(story)
    story.append(
        build_chapter_banner(
            "BÖLÜM 10 · BÜYÜK GÖRSEL OFTALMOLOJİ ATLASI (40 PANEL)",
            "DOĞRULANMIŞ KLİNİK VE OKT TANI ATLASI (BÖLÜM & SAYFA ÇAPASI)",
            "AAO BCSC Section 12 Bölüm 5, Spalton 3rd Ed Bölüm 15, The Retinal Atlas Bölüm 6, Atlas of Retinal OCT Bölüm 15 ve Gonioscopy Kaynaklı 40 Doğrulanmış Patoloji Paneli",
            styles,
        )
    )
    story.extend(
        build_callout_box(
            "DETERMİNİSTİK BÖLÜM VE SAYFA PROVENANCE STANDARDI",
            "Aşağıdaki 40 tanısal klinik görsel ve optik koherens tomografi (OKT) kesiti, serbest katalog aramasından veya tahmini AI vision eşleştirmelerinden arındırılarak; doğrudan ait oldukları tıp kitaplarının Diyabetik Retinopati ve Neovasküler Glokom bölümlerindeki orijinal şekil ve sayfa koordinatlarıyla (BCSC 12 Bölüm 5, Spalton Bölüm 15, The Retinal Atlas Bölüm 6, Atlas of Retinal OCT Section 15 ve Gonioscopy) deterministik olarak eşlenmiştir.",
            PURPLE,
            PURPLE_BG,
            styles,
        )
    )
    file_lookup = _get_master_catalog_lookup()
    for a_idx, a_entry in enumerate(ATLAS_SLIDES_DATA, 1):
        story.append(build_atlas_panel_card(a_idx, a_entry, file_lookup, styles))

    # ------------------------------------------
    # BÖLÜM 11: AKTİF HATIRLAMA SORULARI (CEVAPSIZ DÜŞÜNME ALANI)
    # ------------------------------------------
    _safe_page_break(story)
    story.append(
        build_chapter_banner(
            "BÖLÜM 11 · AKTİF HATIRLAMA VE MEKANİZMA SORGULAMA",
            "İLERİ DÜZEY AKTİF HATIRLAMA SORULARI (16 MEKANİZMA VE KLİNİK AYRIM SORUSU)",
            "Ezber değil nedensel mekanizma, görüntüleme fiziği, 2019-2026 RKÇ alt grup mantığı ve cerrahi/biyoistatistiksel karar testi",
            styles,
        )
    )
    story.extend(
        build_callout_box(
            "NASIL ÇALIŞMALISIN?",
            "Aşağıdaki 16 soruyu önce cevap anahtarına bakmadan kendi cümlelerinle (Temel Kavram -> Mekanizma -> Klinik Sonuç sırasıyla) yanıtla. Düşünme alanını korumak amacıyla ayrıntılı cevap anahtarı sayfa sonundaki bağımsız Ek Bölüm 1'de sunulmuştur.",
            BLUE,
            BLUE_BG,
            styles,
        )
    )

    for q_idx, (q_badge, q_mod_title, q_text, _) in enumerate(all_questions, 1):
        q_html = f'<font color="#1c5ba6"><b>[Soru {q_idx} · {html.escape(q_badge)}]</b></font> {fmt_inline(q_text)}'
        q_tbl = Table([[Paragraph(q_html, styles["tbl_cell_bold"])]], colWidths=[178 * mm], splitByRow=1)
        q_tbl.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), CARD_BG if q_idx % 2 == 1 else colors.white),
                    ("BOX", (0, 0), (-1, -1), 0.5, LINE),
                    ("LINEBEFORE", (0, 0), (0, -1), 3.0, BLUE),
                    ("TOPPADDING", (0, 0), (-1, -1), 5.0),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5.0),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8.0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 8.0),
                ]
            )
        )
        story.append(q_tbl)
        story.append(Spacer(1, 1.8 * mm))

    # ------------------------------------------
    # EK BÖLÜM 1 (EN ALTTA AYRI BÖLÜM): AYRINTILI CEVAP ANAHTARI
    # ------------------------------------------
    _safe_page_break(story)
    story.append(
        build_chapter_banner(
            "EK BÖLÜM 1 · BAĞIMSIZ CEVAP ANAHTARI",
            "AYRINTILI CEVAP ANAHTARI VE PATOFİZYOLOJİK / İSTATİSTİKSEL RASYONELLER",
            "16 Aktif Hatırlama Sorusunun Mekanizma, Klinik Kanıt ve İstisna Temelli Çözümleri",
            styles,
        )
    )

    for q_idx, (q_badge, q_mod_title, _, a_text) in enumerate(all_questions, 1):
        a_rows = [
            [Paragraph(f'<font color="#087d6c"><b>Cevap {q_idx} ({html.escape(q_badge)} — {html.escape(q_mod_title)})</b></font>', styles["tbl_cell_bold"])],
            [Paragraph(fmt_inline(a_text), styles["tbl_cell"])],
        ]
        a_tbl = Table(a_rows, colWidths=[178 * mm], repeatRows=1, splitByRow=1)
        a_tbl.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), GREEN_BG),
                    ("BACKGROUND", (0, 1), (-1, 1), colors.white),
                    ("BOX", (0, 0), (-1, -1), 0.6, LINE),
                    ("INNERGRID", (0, 0), (-1, -1), 0.4, LINE),
                    ("TOPPADDING", (0, 0), (-1, -1), 4.8),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4.8),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8.0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 8.0),
                ]
            )
        )
        story.append(a_tbl)
        story.append(Spacer(1, 2.2 * mm))

    # ------------------------------------------
    # EK BÖLÜM 2: DOĞRULANMIŞ CANLI PUBMED VE YEREL VERİTABANI KAYNAKÇA DİZİNİ
    # ------------------------------------------
    _safe_page_break(story)
    story.append(
        build_chapter_banner(
            "EK BÖLÜM 2 · DOĞRULANABİLİR KANIT VE ERİŞİM ŞEFFAFLIĞI DİZİNİ",
            "CANLI PUBMED (2019–2026) VE YEREL OFTALMOLOJİ VERİTABANI KAYNAKÇA KATALOĞU",
            "Tıklanabilir PubMed (PMID) ve DOI Bağlantıları · Tam Metin Veritabanı vs Yalnızca PubMed Özeti (Abstract) Kapsam Bildirimi",
            styles,
        )
    )
    story.extend(
        build_callout_box(
            "AKADEMİK DÜRÜSTLÜK VE KANIT ERİŞİM ŞEFFAFLIĞI NOTU",
            "Bu rehberde birincil 15 derleme makalesi (Güncel Retina 2018;2(2):89-207) ile yerel veritabanındaki AAO BCSC 2023-2024 Section 12 ve Güncel Retina 2021-2026 derlemeleri TAM METİN olarak incelenmiştir. Aşağıdaki 2019-2026 PubMed kayıtları ise doğrudan NCBI E-Utilities (esearch/efetch) üzerinden gerçek zamanlı doğrulanmış olup YALNIZCA ÖZET (abstract) ve üst veri düzeyinde sentezlenmiştir; hiçbir uydurma PMID veya DOI üretilmemiştir.",
            AMBER,
            AMBER_BG,
            styles,
        )
    )

    db_table_rows = [[mid, dbr, "Tam Metin PDF (Yerel Veritabanı)"] for mid, dbr in all_db_refs]
    if db_table_rows:
        story.extend(
            build_clinical_table_flowables(
                "A. Yerel Oftalmoloji Veritabanı Tam Metin Kaynak Bölümleri",
                ["Modül", "Veritabanı Kitap / Dergi Bölümü", "İnceleme Kapsamı"],
                db_table_rows,
                styles,
                col_widths=[22.0, 118.0, 38.0],
            )
        )

    if pm_all_list:
        pm_hdr = [
            Paragraph("<b>Modül &amp; PMID</b>", styles["tbl_hdr"]),
            Paragraph("<b>Yazar, Yıl ve Dergi</b>", styles["tbl_hdr"]),
            Paragraph("<b>Makale Başlığı ve Tıklanabilir DOI Bağlantısı</b>", styles["tbl_hdr"]),
            Paragraph("<b>Kapsam</b>", styles["tbl_hdr"]),
        ]
        pm_table_data = [pm_hdr]
        for rec in pm_all_list:
            pid = html.escape(str(rec.get("pmid", "")))
            purl = html.escape(str(rec.get("pubmed_url", f"https://pubmed.ncbi.nlm.nih.gov/{pid}/")))
            mod_lbl = html.escape(str(rec.get("module_id", "")))
            auth_yr = html.escape(f"{rec.get('first_author', '')} ({rec.get('year', '')})")
            jrn = html.escape(str(rec.get("journal", "")))
            ttl = html.escape(str(rec.get("title", "")))
            doi = str(rec.get("doi", "")).strip()
            doi_html = (
                f' <br/><a href="{html.escape(rec["doi_url"])}" color="#087d6c"><b>DOI: {html.escape(doi)}</b></a>'
                if doi and rec.get("doi_url")
                else ""
            )
            pm_table_data.append(
                [
                    Paragraph(f'{mod_lbl}<br/><a href="{purl}" color="#1c5ba6"><b>PMID:{pid}</b></a>', styles["tbl_cell_bold"]),
                    Paragraph(f"<b>{auth_yr}</b><br/><i>{jrn}</i>", styles["tbl_cell"]),
                    Paragraph(f"{ttl}{doi_html}", styles["tbl_cell"]),
                    Paragraph("PubMed Özeti", styles["tbl_cell"]),
                ]
            )
        pm_tbl = Table(pm_table_data, colWidths=[28 * mm, 36 * mm, 90 * mm, 24 * mm], repeatRows=1, splitByRow=1)
        pm_style = [
            ("BACKGROUND", (0, 0), (-1, 0), BLUE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BOX", (0, 0), (-1, -1), 0.8, BLUE),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
            ("TOPPADDING", (0, 0), (-1, -1), 4.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4.5),
            ("LEFTPADDING", (0, 0), (-1, -1), 6.0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6.0),
        ]
        for idx_r in range(1, len(pm_table_data)):
            pm_style.append(("BACKGROUND", (0, idx_r), (-1, idx_r), BLUE_BG if idx_r % 2 == 1 else colors.white))
        pm_tbl.setStyle(TableStyle(pm_style))
        story.append(Spacer(1, 2.0 * mm))
        story.append(Paragraph("<b>■ B. Canlı NCBI PubMed E-Utilities Doğrulanmış 2019–2026 Kaynak Kataloğu (Tıklanabilir PMID &amp; DOI)</b>", styles["small_bold_flow"]))
        story.append(pm_tbl)

    OUT_PDF_MAIN.parent.mkdir(parents=True, exist_ok=True)
    OUT_PDF_COMPILED.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(OUT_PDF_MAIN),
        pagesize=A4,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=15 * mm,
        bottomMargin=15 * mm,
        title="Diyabetik Retinopati ve Diyabetik Maküla Ödemi — Kapsamlı Çalışma Rehberi (2026)",
        author="all_gemini LangGraph Akademik Sentez Hattı",
        subject="Güncel Retina + AAO BCSC 2023-2024 + Canlı PubMed (2019-2026) Kanıt Sentezi ve 16 Görsel",
    )
    doc.build(story, canvasmaker=NumberedCanvas)

    # PyMuPDF ile temiz UTF-8 Sol Menü (Bookmarks / Outline) Ekle
    toc_markers = [
        ("Kapak, Protokol ve Çok Kaynaklı Sentez Haritası", "Çalışma Rehberi Metodolojik Kimlik"),
        ("Bölüm 1: Epidemiyoloji, Fenofibrat (LENS) ve GLP-1RA / Genetik Risk", "BÖLÜM 1 · MAKALE 1"),
        ("Bölüm 2: Nörovasküler Ünite, Ang-2/Tie-2 ve KRB Patogenezi", "BÖLÜM 2 · MAKALE 2"),
        ("Bölüm 3: Klinik Tanı, Protokol V & W ve Otonom AI Taraması", "BÖLÜM 3 · MAKALE 4"),
        ("Bölüm 4: Multimodal Görüntüleme (UWFA Protokol AA, OKT ve OKTA)", "BÖLÜM 4 · MAKALE 6"),
        ("Bölüm 5: Anti-VEGF Tedavisi, Protokol T 5-Yıl ve Protokol AC", "BÖLÜM 5 · MAKALE 8"),
        ("Bölüm 6: Kortikosteroidler, Protokol U ve Erken Switch Stratejileri", "BÖLÜM 6 · MAKALE 10"),
        ("Bölüm 7: Subliminal Lazer (DIAMOND), Faricimab ve Aflibercept 8 mg", "BÖLÜM 7 · MAKALE 12"),
        ("Bölüm 8: DMÖ, VİH (Protokol AB) ve TRD Modern Cerrahi Yönetim", "BÖLÜM 8 · MAKALE 14"),
        ("Bölüm 9: Landmark Çalışmalar (1985-2026) ve Biyoistatistik (ICC/GEE)", "BÖLÜM 9 · METODOLOJİ"),
        ("Bölüm 10: Doğrulanmış Görsel ve Tanı Atlası (40 Panel)", "BÖLÜM 10 · BÜYÜK GÖRSEL OFTALMOLOJİ ATLASI"),
        ("Bölüm 11: İleri Düzey Aktif Hatırlama Soruları (16 Soru)", "BÖLÜM 11 · AKTİF HATIRLAMA"),
        ("Ek Bölüm 1: Ayrıntılı Cevap Anahtarı ve Bilimsel Rasyoneller", "EK BÖLÜM 1 · BAĞIMSIZ CEVAP ANAHTARI"),
        ("Ek Bölüm 2: Doğrulanmış Canlı PubMed ve Veritabanı Kaynakça Dizini", "EK BÖLÜM 2 · DOĞRULANABİLİR KANIT"),
    ]
    with pymupdf.open(str(OUT_PDF_MAIN)) as mdoc:
        dynamic_toc = []
        for label, marker in toc_markers:
            found_page = 1
            for p_idx, pg in enumerate(mdoc):
                if marker in pg.get_text("text"):
                    found_page = p_idx + 1
                    break
            dynamic_toc.append([1, label, found_page])
        mdoc.set_toc(dynamic_toc)
        tmp_pdf = OUT_PDF_MAIN.with_name(OUT_PDF_MAIN.stem + "_toc.pdf")
        mdoc.save(str(tmp_pdf))
    if tmp_pdf.is_file():
        tmp_pdf.replace(OUT_PDF_MAIN)

    shutil.copy2(OUT_PDF_MAIN, OUT_PDF_COMPILED)
    try:
        shutil.copy2(OUT_PDF_MAIN, OUT_PDF_OBSIDIAN)
    except Exception as exc:
        emit(f"Obsidian kopyalama uyarısı: {exc}")

    # Kota ve gerçek token kullanım özetini kaydet
    u_sum = bg_usage.summary().get(BOOK_ID, {})
    try:
        qm = QuotaAndWPSManager()
        qm.save()
    except Exception:
        pass

    with pymupdf.open(str(OUT_PDF_MAIN)) as verify_doc:
        page_count = len(verify_doc)
        link_count = sum(len(pg.get_links()) for pg in verify_doc)
    size_kb = OUT_PDF_MAIN.stat().st_size / 1024.0
    emit(f"[TAMAMLANDI] {OUT_PDF_MAIN.name} ({page_count} sayfa, {size_kb:.1f} KB, {link_count} tıklanabilir URI bağlantısı) | Gemini Maliyeti: {u_sum}")
    return {
        "output_pdf_path": str(OUT_PDF_MAIN),
        "usage_report": {"pages": page_count, "size_kb": round(size_kb, 1), "clickable_links": link_count, **u_sum},
    }


def publish_masterclass_pptx_node(state: MasterStudyState) -> Dict[str, Any]:
    """
    LangGraph Boru Hattı Uç Düğümü: 280 Slaytlık Masterclass PowerPoint Sunumunu derler,
    geometri ve bilişsel yük denetimini gerçekleştirir ve Obsidian kasasına eşitler.
    """
    emit("\n" + "=" * 78)
    emit("[LANGGRAPH PPTX DÜĞÜMÜ] 280 Slaytlık DR & DMÖ Masterclass Sunumu Derleniyor...")
    emit("=" * 78)
    try:
        from build_comprehensive_dr_dmo_masterclass import generate_masterclass_deck
        saved_pptx = generate_masterclass_deck()
        obsidian_pptx = Path(r"C:\Users\gezic\Obsidian\TEG") / saved_pptx.name
        try:
            shutil.copy2(saved_pptx, obsidian_pptx)
            emit(f"[Obsidian Senkronizasyonu] Sunum Obsidian kasasına kopyalandı: {obsidian_pptx.name}")
        except Exception as exc:
            emit(f"Obsidian PPTX kopyalama uyarısı: {exc}")

        usage = dict(state.get("usage_report", {}))
        usage["pptx_slides"] = 280
        usage["pptx_size_mb"] = round(saved_pptx.stat().st_size / (1024 * 1024), 2)
        emit(f"[TAMAMLANDI] Masterclass Sunumu: {saved_pptx.name} (280 slayt, {usage['pptx_size_mb']} MB)")
        return {
            "output_pptx_path": str(saved_pptx),
            "usage_report": usage,
        }
    except Exception as exc:
        emit(f"[HATA] Masterclass PPTX düğümünde istisna: {exc}")
        return {"output_pptx_path": "", "usage_report": state.get("usage_report", {})}


# ============================================================================
# 7. ANA LANGGRAPH DERLEMESİ VE ÇALIŞTIRICI
# ============================================================================

def build_dr_dmo_master_graph():
    worker_subgraph = build_module_worker_subgraph()

    g = StateGraph(MasterStudyState)
    g.add_node("audit_pipeline_architecture", audit_pipeline_architecture_node, retry_policy=RETRY)
    g.add_node("ingest_source_pdf", ingest_source_pdf_node)
    g.add_node("module_worker", worker_subgraph)
    g.add_node("synthesize_master", synthesize_master_node)
    g.add_node("publish_study_pdf", publish_study_pdf_node)
    g.add_node("publish_masterclass_pptx", publish_masterclass_pptx_node)

    g.add_edge(START, "audit_pipeline_architecture")
    g.add_edge("audit_pipeline_architecture", "ingest_source_pdf")
    g.add_conditional_edges("ingest_source_pdf", dispatch_modules_edge, ["module_worker"])
    g.add_edge("module_worker", "synthesize_master")
    g.add_edge("synthesize_master", "publish_study_pdf")
    g.add_edge("publish_study_pdf", "publish_masterclass_pptx")
    g.add_edge("publish_masterclass_pptx", END)
    return g


def main():
    print("=" * 78)
    print("DR & DMÖ KAPSAMLI ÇALIŞMA REHBERİ — LANGGRAPH + GEMİNİ 3.8 FLASH & 4 ARGON HATTI")
    print("=" * 78)

    STORAGE_DR_DIR.mkdir(parents=True, exist_ok=True)
    ckpt_path = STORAGE_DR_DIR / "dr_dmo_checkpoints.sqlite"
    try:
        from langgraph.checkpoint.sqlite import SqliteSaver
        conn = sqlite3.connect(str(ckpt_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        saver = SqliteSaver(conn)
    except ImportError:
        from langgraph.checkpoint.memory import InMemorySaver
        conn, saver = None, InMemorySaver()

    try:
        app = build_dr_dmo_master_graph().compile(checkpointer=saver, cache=open_cache())
        tid = f"dr-dmo-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        cfg = {"configurable": {"thread_id": tid}, "max_concurrency": 3, "recursion_limit": 200}
        result = app.invoke({}, config=cfg)
        print("\n" + "=" * 78)
        print("BORU HATTI ÖZETİ:")
        print(json.dumps(result.get("usage_report", {}), ensure_ascii=False, indent=2))
        print("Ana PDF:", result.get("output_pdf_path"))
        print("Master MD:", result.get("master_markdown_path"))
        print("Masterclass PPTX:", result.get("output_pptx_path"))
        print("=" * 78)
    finally:
        if conn is not None:
            conn.close()


if __name__ == "__main__":
    main()
