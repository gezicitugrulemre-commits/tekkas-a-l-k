# -*- coding: utf-8 -*-
r"""
retina_study_builder_core.py — Retina ve Vitreus 446 Slaytlık Kişisel Çalışma Atlası Motoru
========================================================================================
Özellikler:
  - 16:9 Geniş Ekran (13.333 x 7.5 inç)
  - Kişisel çalışma/etüt odaklı yüksek bilgi yoğunluğu (Study-first)
  - Konuşmacı notuna ihtiyaç bırakmayan, slayt yüzeyinde tam içerik sunumu
  - Sıfır boş/geçiş sayfası: Bölüm başları zengin 4 kartlı çalışma yol haritalarıdır
  - ≥ %70 Yüksek Çözünürlüklü Klinik Görsel Standardı:
    Her didaktik çalışma slaytında, karşılaştırma slaytında ve board vaka slaytında
    konuyla tam eşleşen SD-OKT, OKTA, FFA, ICG, Renkli Fundus veya USG görseli
  - Tamamen Akademik Türkçe + parantez içi ikili tıp terminolojisi
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from PIL import Image

# UTF-8 stdout configuration
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
sys.path.insert(0, str(BASE_DIR))

from dr_masterclass_engine import MasterclassPublisher, PPTXPalette, resolve_verified_image, ensure_rgb_cached_image
from retina_visual_resolver import RetinaVisualResolver


class RetinaStudyDeckBuilder:
    """446 Slaytlık Kapsamlı Retina ve Vitreus Kişisel Çalışma Atlası Derleyicisi."""

    def __init__(self, title: str, subtitle: str):
        self.publisher = MasterclassPublisher(title=title, subtitle=subtitle)
        self.prs = self.publisher.prs
        self.blank_layout = self.publisher.blank_layout
        self.extracted_img_dir = BASE_DIR / "extracted_figures" / "retina_vitreus_kitap"
        self.current_chapter: int = 1
        self.resolver = RetinaVisualResolver.get_instance()
        
        # Load catalog if available
        self.catalog: List[Dict[str, Any]] = []
        cat_file = self.extracted_img_dir / "catalog.json"
        if cat_file.exists():
            import json
            try:
                with open(cat_file, "r", encoding="utf-8") as f:
                    self.catalog = json.load(f)
            except Exception as e:
                print(f"Catalog load warning: {e}")

    def set_chapter(self, ch_num: int):
        """Aktif bölüm numarasını günceller."""
        self.current_chapter = ch_num

    def get_image_for_page(self, page_num: int) -> Optional[Path]:
        """Kitap sayfa numarasına en uygun çıkarılmış klinik görseli bulur."""
        if not self.catalog:
            return None
        # Yalnızca sayfa numarası birebir eşleşen, banner/şerit olmayan gerçek klinik figürleri kabul et
        exact = [
            x for x in self.catalog
            if x.get("page") == page_num and "xref_3" not in x.get("name", "") and x.get("size", 0) > 30000
        ]
        if exact:
            p = Path(exact[0].get("path", ""))
            if p.exists():
                return p
        # En yakın sayfa aramasını kapatarak alakasız figür yüklenmesini önle
        return None

    def add_cover_slide(self, metadata_rows: List[Tuple[str, str]]):
        """Kapsamlı Başvuru ve Çalışma Atlası Kapak Slaytı."""
        self.publisher.add_cover_slide(metadata_rows=metadata_rows, notes="")

    def add_curriculum_overview_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        modules: List[Dict[str, Any]]
    ):
        """Tüm Müfredatın Çalışma Haritası ve Modül Dağılımı Slaytı."""
        self.publisher.add_lecture_card_slide(
            title=title,
            category=category,
            subtitle=subtitle,
            cards=modules,
            notes=""
        )

    def add_chapter_study_roadmap(
        self,
        part_num: int,
        title: str,
        page_range: str,
        subtitle: str,
        cards: List[Dict[str, Any]]
    ):
        """
        Bölüm Giriş ve Çekirdek Çalışma Yol Haritası Slaytı (KESİNLİKLE BOŞ DEĞİLDİR).
        4 derin tematik çalışma kartı içerir (Patogenez, Görüntüleme, Tedavi, Board İpuçları).
        """
        self.current_chapter = part_num
        slide = self.prs.slides.add_slide(self.blank_layout)
        
        # Tam ekran kurumsal lacivert zemin
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = PPTXPalette.NAVY
        bg.line.fill.background()

        # Üst Rozet
        badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(0.55), Inches(3.4), Inches(0.42))
        badge.fill.solid()
        badge.fill.fore_color.rgb = PPTXPalette.BLUE
        badge.line.fill.background()
        tf_b = badge.text_frame
        p_b = tf_b.paragraphs[0]
        p_b.text = f"BÖLÜM {part_num:02d} ÇALIŞMA YOL HARİTASI"
        p_b.font.name = "Arial"
        p_b.font.size = Pt(11)
        p_b.font.bold = True
        p_b.font.color.rgb = PPTXPalette.WHITE
        p_b.alignment = PP_ALIGN.CENTER

        # Sağ Sayfa Aralığı Rozeti
        p_badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(10.2), Inches(0.55), Inches(2.333), Inches(0.42))
        p_badge.fill.solid()
        p_badge.fill.fore_color.rgb = RGBColor(30, 58, 88)
        p_badge.line.fill.background()
        tf_pb = p_badge.text_frame
        p_pb = tf_pb.paragraphs[0]
        p_pb.text = f"📖 {page_range}"
        p_pb.font.name = "Arial"
        p_pb.font.size = Pt(11)
        p_pb.font.bold = True
        p_pb.font.color.rgb = RGBColor(191, 219, 254)
        p_pb.alignment = PP_ALIGN.CENTER

        # Bölüm Başlığı
        t_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.05), Inches(11.733), Inches(0.55))
        tf_t = t_box.text_frame
        tf_t.word_wrap = True
        p_t = tf_t.paragraphs[0]
        p_t.text = title.upper()
        p_t.font.name = "Arial"
        p_t.font.size = Pt(22)
        p_t.font.bold = True
        p_t.font.color.rgb = PPTXPalette.WHITE

        # Alt Başlık
        s_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(11.733), Inches(0.4))
        tf_s = s_box.text_frame
        tf_s.word_wrap = True
        p_s = tf_s.paragraphs[0]
        p_s.text = subtitle
        p_s.font.name = "Arial"
        p_s.font.size = Pt(12)
        p_s.font.color.rgb = RGBColor(191, 219, 254)

        # 4 Adet Detaylı Çalışma Kartı
        num_cards = len(cards)
        total_w = 11.733
        gap = 0.22
        card_w = (total_w - ((num_cards - 1) * gap)) / num_cards
        card_h = 5.0
        top_y = Inches(2.1)

        for i, c in enumerate(cards):
            x = Inches(0.8 + i * (card_w + gap))
            
            # Kart Arka Planı (Koyu Şık Kart)
            card_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
            card_shape.fill.solid()
            card_shape.fill.fore_color.rgb = RGBColor(15, 33, 55)
            card_shape.line.color.rgb = PPTXPalette.BLUE
            card_shape.line.width = Pt(1.5)

            # Kart Başlık Bandı
            b_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(0.52))
            b_shape.fill.solid()
            b_shape.fill.fore_color.rgb = c.get("color", PPTXPalette.BLUE)
            b_shape.line.fill.background()

            tf_cb = b_shape.text_frame
            tf_cb.word_wrap = True
            pcb = tf_cb.paragraphs[0]
            pcb.text = c.get("title", "KONU").upper()
            pcb.font.name = "Arial"
            pcb.font.size = Pt(10)
            pcb.font.bold = True
            pcb.font.color.rgb = PPTXPalette.WHITE
            pcb.alignment = PP_ALIGN.CENTER

            # İçerik Kutusu
            tf_content = slide.shapes.add_textbox(x + Inches(0.12), top_y + Inches(0.58), Inches(card_w - 0.24), Inches(card_h - 1.15)).text_frame
            tf_content.word_wrap = True

            lead = c.get("lead", "")
            if lead:
                p_lead = tf_content.paragraphs[0]
                p_lead.text = lead
                p_lead.font.name = "Arial"
                p_lead.font.size = Pt(9.5)
                p_lead.font.bold = True
                p_lead.font.color.rgb = RGBColor(254, 240, 138)  # Light yellow
                p_lead.space_after = Pt(4)

            for idx, item in enumerate(c.get("items", [])):
                p_it = tf_content.add_paragraph() if (lead or idx > 0) else tf_content.paragraphs[0]
                p_it.text = f"• {item}"
                p_it.font.name = "Arial"
                p_it.font.size = Pt(9.0)
                p_it.font.color.rgb = RGBColor(241, 245, 249)  # Soft white
                p_it.space_after = Pt(3)

            # Kart Altı Vurgu Bandı
            footer = c.get("footer", "")
            if footer:
                ft_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x + Inches(0.1), top_y + Inches(card_h - 0.5), Inches(card_w - 0.2), Inches(0.4))
                ft_box.fill.solid()
                ft_box.fill.fore_color.rgb = RGBColor(23, 49, 80)
                ft_box.line.color.rgb = PPTXPalette.BLUE
                ft_box.line.width = Pt(1.0)
                tf_ft = ft_box.text_frame
                tf_ft.word_wrap = True
                p_ft = tf_ft.paragraphs[0]
                p_ft.text = f"📌 {footer}"
                p_ft.font.name = "Arial"
                p_ft.font.size = Pt(8.5)
                p_ft.font.bold = True
                p_ft.font.color.rgb = RGBColor(147, 197, 253)
                p_ft.alignment = PP_ALIGN.CENTER

    def add_study_card_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        cards: List[Dict[str, Any]],
        image_path: Optional[Union[Path, str]] = None,
        image_caption: str = ""
    ):
        """
        Didaktik klinik çalışma slaytı.
        Eğer görsel belirtilmemişse, otomatik olarak konuyla eşleşen yüksek çözünürlüklü
        klinik figürü (OCT, FFA, OKTA, Renkli Fundus vb.) sağ panelde entegre eder.
        """
        # Görseli çözümle
        img_resolved, resolved_caption = self.resolver.resolve_visual(
            chapter_num=self.current_chapter,
            title=title,
            category=category,
            explicit_path=image_path,
            explicit_caption=image_caption
        )

        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        top_y = Inches(1.9)
        card_h = 4.85

        if img_resolved and img_resolved.exists():
            # =================================================================
            # ENTEGRE GÖRSEL DÜZENİ: Sol Panel (Kartlar) + Sağ Panel (Klinik Görsel)
            # =================================================================
            left_total_w = 7.35
            num_cards = len(cards)
            gap = 0.16
            card_w = (left_total_w - ((num_cards - 1) * gap)) / num_cards

            for i, c in enumerate(cards):
                x = Inches(0.8 + i * (card_w + gap))
                
                bg_col = PPTXPalette.WHITE
                line_col = PPTXPalette.LINE
                accent_col = PPTXPalette.BLUE

                if c.get("theme") == "danger":
                    line_col = PPTXPalette.RED
                    accent_col = PPTXPalette.RED
                elif c.get("theme") == "success":
                    line_col = PPTXPalette.GREEN
                    accent_col = PPTXPalette.GREEN
                elif c.get("theme") == "warning":
                    line_col = PPTXPalette.AMBER
                    accent_col = PPTXPalette.AMBER

                card_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
                card_shape.fill.solid()
                card_shape.fill.fore_color.rgb = bg_col
                card_shape.line.color.rgb = line_col
                card_shape.line.width = Pt(1.5)

                # Başlık Bandı
                b_shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(0.48))
                b_shape.fill.solid()
                b_shape.fill.fore_color.rgb = accent_col
                b_shape.line.fill.background()

                tf_b = b_shape.text_frame
                tf_b.word_wrap = True
                pb = tf_b.paragraphs[0]
                pb.text = c.get("card_title", "BAŞLIK").upper()
                pb.font.name = "Arial"
                pb.font.size = Pt(9.5)
                pb.font.bold = True
                pb.font.color.rgb = PPTXPalette.WHITE
                pb.alignment = PP_ALIGN.CENTER

                # İçerik
                tf_c = slide.shapes.add_textbox(x + Inches(0.1), top_y + Inches(0.52), Inches(card_w - 0.2), Inches(card_h - 0.95)).text_frame
                tf_c.word_wrap = True

                lead = c.get("lead", "")
                if lead:
                    p_lead = tf_c.paragraphs[0]
                    p_lead.text = lead
                    p_lead.font.name = "Arial"
                    p_lead.font.size = Pt(8.8)
                    p_lead.font.bold = True
                    p_lead.font.color.rgb = PPTXPalette.NAVY
                    p_lead.space_after = Pt(4)

                for idx, item in enumerate(c.get("items", [])):
                    p = tf_c.paragraphs[0] if (not lead and idx == 0) else tf_c.add_paragraph()
                    p.text = f"• {item}"
                    p.font.name = "Arial"
                    p.font.size = Pt(8.0)
                    p.font.color.rgb = PPTXPalette.TEXT_MAIN
                    p.space_after = Pt(3)

                footer_tag = c.get("footer", "")
                if footer_tag:
                    ft_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x + Inches(0.08), top_y + Inches(card_h - 0.42), Inches(card_w - 0.16), Inches(0.35))
                    ft_box.fill.solid()
                    ft_box.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
                    ft_box.line.color.rgb = accent_col
                    ft_box.line.width = Pt(0.8)
                    tf_ft = ft_box.text_frame
                    tf_ft.word_wrap = True
                    p_f = tf_ft.paragraphs[0]
                    p_f.text = f"★ {footer_tag}"
                    p_f.font.name = "Arial"
                    p_f.font.size = Pt(7.8)
                    p_f.font.bold = True
                    p_f.font.color.rgb = accent_col
                    p_f.alignment = PP_ALIGN.CENTER

            # Sağ Görsel Paneli
            right_x = Inches(0.8 + left_total_w + 0.22)
            right_w = Inches(4.16)
            
            panel_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, top_y, right_w, Inches(card_h))
            panel_card.fill.solid()
            panel_card.fill.fore_color.rgb = PPTXPalette.WHITE
            panel_card.line.color.rgb = PPTXPalette.BLUE
            panel_card.line.width = Pt(1.5)

            # Panel Üst Bandı
            panel_banner = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, top_y, right_w, Inches(0.42))
            panel_banner.fill.solid()
            panel_banner.fill.fore_color.rgb = PPTXPalette.NAVY
            panel_banner.line.fill.background()
            tf_pb = panel_banner.text_frame
            tf_pb.word_wrap = True
            ppb = tf_pb.paragraphs[0]
            ppb.text = "🔬 MULTİMODAL RETİNA VE VİTREUS ATLASI"
            ppb.font.name = "Arial"
            ppb.font.size = Pt(9.0)
            ppb.font.bold = True
            ppb.font.color.rgb = PPTXPalette.WHITE
            ppb.alignment = PP_ALIGN.CENTER

            # Görseli Yerleştir (Aspect Ratio Korunarak)
            max_img_w = right_w - Inches(0.24)
            max_img_h = Inches(3.55)
            img_area_y = top_y + Inches(0.48)

            try:
                im = Image.open(img_resolved)
                orig_w, orig_h = im.size
                scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
                disp_w = Inches(orig_w / 96.0) * scale
                disp_h = Inches(orig_h / 96.0) * scale
                img_x = right_x + (right_w - disp_w) / 2
                img_y = img_area_y + (max_img_h - disp_h) / 2
                slide.shapes.add_picture(str(img_resolved), img_x, img_y, width=disp_w, height=disp_h)
            except Exception as e:
                print(f"Görsel yerleştirme hatası ({img_resolved.name}): {e}")

            # Görsel Altı Klinik Açıklama Bandı
            cap_y = top_y + Inches(card_h - 0.72)
            cap_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x + Inches(0.1), cap_y, right_w - Inches(0.2), Inches(0.66))
            cap_box.fill.solid()
            cap_box.fill.fore_color.rgb = RGBColor(241, 245, 249)
            cap_box.line.color.rgb = PPTXPalette.BLUE
            cap_box.line.width = Pt(0.8)

            tf_cap = cap_box.text_frame
            tf_cap.word_wrap = True
            p_cap = tf_cap.paragraphs[0]
            p_cap.text = resolved_caption
            p_cap.font.name = "Arial"
            p_cap.font.size = Pt(7.8)
            p_cap.font.bold = True
            p_cap.font.color.rgb = PPTXPalette.NAVY

        else:
            # Görsel bulunamazsa tam genişlik kart düzeni
            self.publisher.add_lecture_card_slide(
                title=title,
                category=category,
                subtitle=subtitle,
                cards=cards,
                notes=""
            )

    def add_split_comparison_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        left_entity: Dict[str, Any],
        right_entity: Dict[str, Any],
        bottom_takeaway: str,
        image_path: Optional[Union[Path, str]] = None,
        image_caption: str = ""
    ):
        """
        Yan yana iki antiteyi karşılaştıran ve sağda klinik karşılaştırma görseli sunan slayt.
        """
        img_resolved, resolved_caption = self.resolver.resolve_visual(
            chapter_num=self.current_chapter,
            title=title,
            category=category,
            explicit_path=image_path,
            explicit_caption=image_caption
        )

        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        top_y = Inches(1.9)
        card_h = 4.25

        if img_resolved and img_resolved.exists():
            # 1. Sol Kart (3.55 in)
            card_l = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(3.55), Inches(card_h))
            card_l.fill.solid()
            card_l.fill.fore_color.rgb = PPTXPalette.WHITE
            card_l.line.color.rgb = PPTXPalette.BLUE
            card_l.line.width = Pt(1.5)

            banner_l = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(3.55), Inches(0.48))
            banner_l.fill.solid()
            banner_l.fill.fore_color.rgb = PPTXPalette.BLUE
            banner_l.line.fill.background()
            pl = banner_l.text_frame.paragraphs[0]
            pl.text = left_entity.get("name", "TABLO A").upper()
            pl.font.name = "Arial"
            pl.font.size = Pt(9.5)
            pl.font.bold = True
            pl.font.color.rgb = PPTXPalette.WHITE
            pl.alignment = PP_ALIGN.CENTER

            tf_l = slide.shapes.add_textbox(Inches(0.92), top_y + Inches(0.52), Inches(3.31), Inches(card_h - 0.60)).text_frame
            tf_l.word_wrap = True
            for idx, (label, val) in enumerate(left_entity.get("features", [])):
                p = tf_l.paragraphs[0] if idx == 0 else tf_l.add_paragraph()
                p.text = f"• {label}: {val}"
                p.font.name = "Arial"
                p.font.size = Pt(8.2)
                p.font.color.rgb = PPTXPalette.TEXT_MAIN
                p.space_after = Pt(3)

            # 2. Orta Kart (Sağ Varlık) (3.55 in)
            mid_x = Inches(0.8 + 3.55 + 0.18)
            card_r = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, mid_x, top_y, Inches(3.55), Inches(card_h))
            card_r.fill.solid()
            card_r.fill.fore_color.rgb = PPTXPalette.WHITE
            card_r.line.color.rgb = PPTXPalette.RED
            card_r.line.width = Pt(1.5)

            banner_r = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, mid_x, top_y, Inches(3.55), Inches(0.48))
            banner_r.fill.solid()
            banner_r.fill.fore_color.rgb = PPTXPalette.RED
            banner_r.line.fill.background()
            pr = banner_r.text_frame.paragraphs[0]
            pr.text = right_entity.get("name", "TABLO B").upper()
            pr.font.name = "Arial"
            pr.font.size = Pt(9.5)
            pr.font.bold = True
            pr.font.color.rgb = PPTXPalette.WHITE
            pr.alignment = PP_ALIGN.CENTER

            tf_r = slide.shapes.add_textbox(mid_x + Inches(0.12), top_y + Inches(0.52), Inches(3.31), Inches(card_h - 0.60)).text_frame
            tf_r.word_wrap = True
            for idx, (label, val) in enumerate(right_entity.get("features", [])):
                p = tf_r.paragraphs[0] if idx == 0 else tf_r.add_paragraph()
                p.text = f"• {label}: {val}"
                p.font.name = "Arial"
                p.font.size = Pt(8.2)
                p.font.color.rgb = PPTXPalette.TEXT_MAIN
                p.space_after = Pt(3)

            # 3. Sağ Klinik Görsel Paneli (4.27 in)
            vis_x = Inches(0.8 + 3.55 + 0.18 + 3.55 + 0.18)
            vis_w = Inches(4.27)
            card_v = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x, top_y, vis_w, Inches(card_h))
            card_v.fill.solid()
            card_v.fill.fore_color.rgb = PPTXPalette.WHITE
            card_v.line.color.rgb = PPTXPalette.GREEN
            card_v.line.width = Pt(1.5)

            banner_v = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x, top_y, vis_w, Inches(0.48))
            banner_v.fill.solid()
            banner_v.fill.fore_color.rgb = PPTXPalette.NAVY
            banner_v.line.fill.background()
            pv = banner_v.text_frame.paragraphs[0]
            pv.text = "⚡ KLİNİK AYIRICI GÖRÜNTÜLEME"
            pv.font.name = "Arial"
            pv.font.size = Pt(9.5)
            pv.font.bold = True
            pv.font.color.rgb = PPTXPalette.WHITE
            pv.alignment = PP_ALIGN.CENTER

            max_img_w = vis_w - Inches(0.24)
            max_img_h = Inches(3.0)
            img_y_start = top_y + Inches(0.52)

            try:
                im = Image.open(img_resolved)
                orig_w, orig_h = im.size
                scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
                disp_w = Inches(orig_w / 96.0) * scale
                disp_h = Inches(orig_h / 96.0) * scale
                img_x = vis_x + (vis_w - disp_w) / 2
                img_y = img_y_start + (max_img_h - disp_h) / 2
                slide.shapes.add_picture(str(img_resolved), img_x, img_y, width=disp_w, height=disp_h)
            except Exception as e:
                print(f"Görsel ekleme hatası: {e}")

            # Görsel Altı Başlık
            cap_y = top_y + Inches(card_h - 0.65)
            cap_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x + Inches(0.08), cap_y, vis_w - Inches(0.16), Inches(0.58))
            cap_box.fill.solid()
            cap_box.fill.fore_color.rgb = RGBColor(241, 245, 249)
            cap_box.line.color.rgb = PPTXPalette.GREEN
            cap_box.line.width = Pt(0.8)
            tf_cap = cap_box.text_frame
            tf_cap.word_wrap = True
            p_cap = tf_cap.paragraphs[0]
            p_cap.text = resolved_caption
            p_cap.font.name = "Arial"
            p_cap.font.size = Pt(7.6)
            p_cap.font.bold = True
            p_cap.font.color.rgb = PPTXPalette.NAVY

            # Alt Özet Bandı (Tüm Genişlik)
            bot_y = Inches(6.25)
            bot = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), bot_y, Inches(11.733), Inches(0.55))
            bot.fill.solid()
            bot.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
            bot.line.color.rgb = PPTXPalette.BLUE
            bot.line.width = Pt(1.2)
            pb = bot.text_frame.paragraphs[0]
            pb.text = f"⚡ AYIRICI TANI KRİTERİ: {bottom_takeaway}"
            pb.font.name = "Arial"
            pb.font.size = Pt(9.5)
            pb.font.bold = True
            pb.font.color.rgb = PPTXPalette.NAVY

        else:
            self.publisher.add_split_comparison_slide(
                title=title,
                category=category,
                subtitle=subtitle,
                left_entity=left_entity,
                right_entity=right_entity,
                bottom_takeaway=bottom_takeaway,
                notes=""
            )

    def add_active_recall_case_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        vignette: str,
        differentials: List[str],
        decision: str,
        board_trap: str,
        image_path: Optional[Union[Path, str]] = None,
        image_caption: str = ""
    ):
        """Tüm Bilgiyi Slayt Yüzeyinde Sunan ve Hasta Klinik Görseli İçeren Aktif Hatırlama Slaytı."""
        img_resolved, resolved_caption = self.resolver.resolve_visual(
            chapter_num=self.current_chapter,
            title=title,
            category=category,
            explicit_path=image_path,
            explicit_caption=image_caption
        )

        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        top_y = Inches(1.9)
        left_w = 7.35

        if img_resolved and img_resolved.exists():
            # 1. Sol Üst: Vaka Senaryosu
            v_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(left_w), Inches(1.50))
            v_card.fill.solid()
            v_card.fill.fore_color.rgb = PPTXPalette.WHITE
            v_card.line.color.rgb = PPTXPalette.BLUE
            v_card.line.width = Pt(1.5)

            v_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(left_w), Inches(0.38))
            v_head.fill.solid()
            v_head.fill.fore_color.rgb = PPTXPalette.NAVY
            v_head.line.fill.background()
            tf_vh = v_head.text_frame
            p_vh = tf_vh.paragraphs[0]
            p_vh.text = "📋 VAKA SENARYOSU VE KLİNİK BAŞVURU"
            p_vh.font.name = "Arial"
            p_vh.font.size = Pt(9.5)
            p_vh.font.bold = True
            p_vh.font.color.rgb = PPTXPalette.WHITE

            tf_vc = slide.shapes.add_textbox(Inches(0.92), top_y + Inches(0.42), Inches(left_w - 0.24), Inches(1.0)).text_frame
            tf_vc.word_wrap = True
            p_vc = tf_vc.paragraphs[0]
            p_vc.text = vignette
            p_vc.font.name = "Arial"
            p_vc.font.size = Pt(8.8)
            p_vc.font.color.rgb = PPTXPalette.TEXT_MAIN

            # 2. Sol Orta: Yan Yana Ayırıcı Tanılar & Kesin Karar
            mid_y = top_y + Inches(1.60)
            col_w = (left_w - 0.20) / 2
            col_h = Inches(2.40)

            # Ayırıcı Tanılar
            d_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), mid_y, Inches(col_w), col_h)
            d_card.fill.solid()
            d_card.fill.fore_color.rgb = PPTXPalette.WHITE
            d_card.line.color.rgb = PPTXPalette.AMBER
            d_card.line.width = Pt(1.5)

            d_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), mid_y, Inches(col_w), Inches(0.38))
            d_head.fill.solid()
            d_head.fill.fore_color.rgb = PPTXPalette.AMBER
            d_head.line.fill.background()
            tf_dh = d_head.text_frame
            p_dh = tf_dh.paragraphs[0]
            p_dh.text = "⚡ DÜŞÜNÜLECEK AYIRICI TANILAR"
            p_dh.font.name = "Arial"
            p_dh.font.size = Pt(9.0)
            p_dh.font.bold = True
            p_dh.font.color.rgb = PPTXPalette.WHITE
            p_dh.alignment = PP_ALIGN.CENTER

            tf_dc = slide.shapes.add_textbox(Inches(0.92), mid_y + Inches(0.42), Inches(col_w - 0.24), Inches(1.9)).text_frame
            tf_dc.word_wrap = True
            for idx, diff in enumerate(differentials):
                p = tf_dc.paragraphs[0] if idx == 0 else tf_dc.add_paragraph()
                p.text = f"• {diff}"
                p.font.name = "Arial"
                p.font.size = Pt(8.0)
                p.font.color.rgb = PPTXPalette.TEXT_MAIN
                p.space_after = Pt(2.5)

            # Kesin Karar
            right_col_x = Inches(0.8 + col_w + 0.20)
            m_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_col_x, mid_y, Inches(col_w), col_h)
            m_card.fill.solid()
            m_card.fill.fore_color.rgb = PPTXPalette.WHITE
            m_card.line.color.rgb = PPTXPalette.GREEN
            m_card.line.width = Pt(1.5)

            m_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_col_x, mid_y, Inches(col_w), Inches(0.38))
            m_head.fill.solid()
            m_head.fill.fore_color.rgb = PPTXPalette.GREEN
            m_head.line.fill.background()
            tf_mh = m_head.text_frame
            p_mh = tf_mh.paragraphs[0]
            p_mh.text = "🎯 KESİN KARAR & TEDAVİ PROTOKOLÜ"
            p_mh.font.name = "Arial"
            p_mh.font.size = Pt(9.0)
            p_mh.font.bold = True
            p_mh.font.color.rgb = PPTXPalette.WHITE
            p_mh.alignment = PP_ALIGN.CENTER

            tf_mc = slide.shapes.add_textbox(right_col_x + Inches(0.12), mid_y + Inches(0.42), Inches(col_w - 0.24), Inches(1.9)).text_frame
            tf_mc.word_wrap = True
            p_mc = tf_mc.paragraphs[0]
            p_mc.text = decision
            p_mc.font.name = "Arial"
            p_mc.font.size = Pt(8.2)
            p_mc.font.color.rgb = PPTXPalette.NAVY

            # 3. Sol En Alt: Board Tuzağı
            bot_y = mid_y + col_h + Inches(0.10)
            bot_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), bot_y, Inches(left_w), Inches(0.68))
            bot_card.fill.solid()
            bot_card.fill.fore_color.rgb = PPTXPalette.LIGHT_RED
            bot_card.line.color.rgb = PPTXPalette.RED
            bot_card.line.width = Pt(1.2)

            tf_bc = bot_card.text_frame
            tf_bc.word_wrap = True
            p_bt = tf_bc.paragraphs[0]
            p_bt.text = f"⚠️ BOARD SINAVI VE KLİNİK PRATİK TUZAĞI: {board_trap}"
            p_bt.font.name = "Arial"
            p_bt.font.size = Pt(8.5)
            p_bt.font.bold = True
            p_bt.font.color.rgb = PPTXPalette.RED

            # 4. Sağ Panel: Vaka Görüntüleme Paneli (4.16 in)
            vis_x = Inches(0.8 + left_w + 0.22)
            vis_w = Inches(4.16)
            vis_h = Inches(4.85)

            p_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x, top_y, vis_w, vis_h)
            p_box.fill.solid()
            p_box.fill.fore_color.rgb = PPTXPalette.WHITE
            p_box.line.color.rgb = PPTXPalette.AMBER
            p_box.line.width = Pt(1.5)

            p_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x, top_y, vis_w, Inches(0.42))
            p_head.fill.solid()
            p_head.fill.fore_color.rgb = PPTXPalette.NAVY
            p_head.line.fill.background()
            tf_ph = p_head.text_frame
            pph = tf_ph.paragraphs[0]
            pph.text = "📸 HASTA KLİNİK GÖRÜNTÜLEME ATLASI"
            pph.font.name = "Arial"
            pph.font.size = Pt(9.0)
            pph.font.bold = True
            pph.font.color.rgb = PPTXPalette.WHITE
            pph.alignment = PP_ALIGN.CENTER

            max_img_w = vis_w - Inches(0.24)
            max_img_h = Inches(3.55)
            img_start_y = top_y + Inches(0.48)

            try:
                im = Image.open(img_resolved)
                orig_w, orig_h = im.size
                scale = min((max_img_w / Inches(orig_w / 96.0)), (max_img_h / Inches(orig_h / 96.0)))
                disp_w = Inches(orig_w / 96.0) * scale
                disp_h = Inches(orig_h / 96.0) * scale
                img_x = vis_x + (vis_w - disp_w) / 2
                img_y = img_start_y + (max_img_h - disp_h) / 2
                slide.shapes.add_picture(str(img_resolved), img_x, img_y, width=disp_w, height=disp_h)
            except Exception as e:
                print(f"Vaka görseli ekleme hatası: {e}")

            cap_y = top_y + Inches(4.85 - 0.72)
            c_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, vis_x + Inches(0.1), cap_y, vis_w - Inches(0.2), Inches(0.66))
            c_box.fill.solid()
            c_box.fill.fore_color.rgb = RGBColor(241, 245, 249)
            c_box.line.color.rgb = PPTXPalette.AMBER
            c_box.line.width = Pt(0.8)
            tf_c = c_box.text_frame
            tf_c.word_wrap = True
            pc = tf_c.paragraphs[0]
            pc.text = resolved_caption
            pc.font.name = "Arial"
            pc.font.size = Pt(7.8)
            pc.font.bold = True
            pc.font.color.rgb = PPTXPalette.NAVY

        else:
            # Görselsiz fallback
            canvas_w = 11.733
            v_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(canvas_w), Inches(1.55))
            v_card.fill.solid()
            v_card.fill.fore_color.rgb = PPTXPalette.WHITE
            v_card.line.color.rgb = PPTXPalette.BLUE
            v_card.line.width = Pt(1.5)

            v_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), top_y, Inches(canvas_w), Inches(0.4))
            v_head.fill.solid()
            v_head.fill.fore_color.rgb = PPTXPalette.NAVY
            v_head.line.fill.background()
            tf_vh = v_head.text_frame
            p_vh = tf_vh.paragraphs[0]
            p_vh.text = "📋 VAKA SENARYOSU VE KLİNİK BULGULAR"
            p_vh.font.name = "Arial"
            p_vh.font.size = Pt(9.5)
            p_vh.font.bold = True
            p_vh.font.color.rgb = PPTXPalette.WHITE

            tf_vc = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.45), Inches(canvas_w - 0.3), Inches(1.0)).text_frame
            tf_vc.word_wrap = True
            p_vc = tf_vc.paragraphs[0]
            p_vc.text = vignette
            p_vc.font.name = "Arial"
            p_vc.font.size = Pt(9.5)
            p_vc.font.color.rgb = PPTXPalette.TEXT_MAIN

            mid_y = top_y + Inches(1.68)
            col_w = (canvas_w - 0.25) / 2
            col_h = Inches(2.35)

            d_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), mid_y, Inches(col_w), col_h)
            d_card.fill.solid()
            d_card.fill.fore_color.rgb = PPTXPalette.WHITE
            d_card.line.color.rgb = PPTXPalette.AMBER
            d_card.line.width = Pt(1.5)

            d_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), mid_y, Inches(col_w), Inches(0.4))
            d_head.fill.solid()
            d_head.fill.fore_color.rgb = PPTXPalette.AMBER
            d_head.line.fill.background()
            tf_dh = d_head.text_frame
            p_dh = tf_dh.paragraphs[0]
            p_dh.text = "⚡ DÜŞÜNÜLECEK AYIRICI TANILAR & İPUÇLARI"
            p_dh.font.name = "Arial"
            p_dh.font.size = Pt(9.5)
            p_dh.font.bold = True
            p_dh.font.color.rgb = PPTXPalette.WHITE
            p_dh.alignment = PP_ALIGN.CENTER

            tf_dc = slide.shapes.add_textbox(Inches(0.95), mid_y + Inches(0.45), Inches(col_w - 0.3), Inches(1.8)).text_frame
            tf_dc.word_wrap = True
            for idx, diff in enumerate(differentials):
                p = tf_dc.paragraphs[0] if idx == 0 else tf_dc.add_paragraph()
                p.text = f"• {diff}"
                p.font.name = "Arial"
                p.font.size = Pt(9.0)
                p.font.color.rgb = PPTXPalette.TEXT_MAIN
                p.space_after = Pt(3)

            right_x = Inches(0.8 + col_w + 0.25)
            m_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, mid_y, Inches(col_w), col_h)
            m_card.fill.solid()
            m_card.fill.fore_color.rgb = PPTXPalette.WHITE
            m_card.line.color.rgb = PPTXPalette.GREEN
            m_card.line.width = Pt(1.5)

            m_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, right_x, mid_y, Inches(col_w), Inches(0.4))
            m_head.fill.solid()
            m_head.fill.fore_color.rgb = PPTXPalette.GREEN
            m_head.line.fill.background()
            tf_mh = m_head.text_frame
            p_mh = tf_mh.paragraphs[0]
            p_mh.text = "🎯 KESİN KLİNİK KARAR VE YÖNETİM"
            p_mh.font.name = "Arial"
            p_mh.font.size = Pt(9.5)
            p_mh.font.bold = True
            p_mh.font.color.rgb = PPTXPalette.WHITE
            p_mh.alignment = PP_ALIGN.CENTER

            tf_mc = slide.shapes.add_textbox(right_x + Inches(0.15), mid_y + Inches(0.45), Inches(col_w - 0.3), Inches(1.8)).text_frame
            tf_mc.word_wrap = True
            p_mc = tf_mc.paragraphs[0]
            p_mc.text = decision
            p_mc.font.name = "Arial"
            p_mc.font.size = Pt(9.0)
            p_mc.font.color.rgb = PPTXPalette.NAVY

            bot_y = mid_y + col_h + Inches(0.12)
            bot_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), bot_y, Inches(canvas_w), Inches(0.65))
            bot_card.fill.solid()
            bot_card.fill.fore_color.rgb = PPTXPalette.LIGHT_RED
            bot_card.line.color.rgb = PPTXPalette.RED
            bot_card.line.width = Pt(1.2)

            tf_bc = bot_card.text_frame
            tf_bc.word_wrap = True
            p_bt = tf_bc.paragraphs[0]
            p_bt.text = f"⚠️ BOARD SINAVI & KLİNİK PRATİK TUZAĞI: {board_trap}"
            p_bt.font.name = "Arial"
            p_bt.font.size = Pt(9.0)
            p_bt.font.bold = True
            p_bt.font.color.rgb = PPTXPalette.RED

    def add_atlas_image_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        image_path: Union[Path, str],
        caption: str,
        key_findings: List[str],
        differentials: List[str],
        clinical_pearl: str
    ):
        """Sol tarafta yüksek çözünürlüklü klinik atlas görseli, sağ tarafta patoloji ve ayırıcı tanı analizi."""
        # Eğer image_path bir dr_schema, banner şeridi (xref_3 vb.) ise veya diskte yoksa:
        # Doğrudan konuya özel doğrulanmış klinik görseli çözümle!
        str_path = str(image_path).lower() if image_path else ""
        needs_resolve = (
            not image_path or
            str_path.endswith(".json") or
            "catalog.json" in str_path or
            "dr_schema" in str_path or
            "xref_3" in str_path or
            "page_001" in str_path or
            "page_038" in str_path or
            "page_190" in str_path or
            not Path(str(image_path)).exists()
        )

        if needs_resolve:
            resolved_p, resolved_cap = self.resolver.resolve_visual(
                chapter_num=self.current_chapter,
                title=title,
                category=category
            )
            p_to_use = resolved_p or image_path
            raw_cap = resolved_cap if resolved_cap else caption
        else:
            p_to_use = self.resolver.ensure_rgb_cached(image_path) or image_path
            raw_cap = caption

        # Çift kamera ikonlarını temizle
        import re
        cap_to_use = re.sub(r"^(?:📷\s*)+", "📷 ", raw_cap.strip()) if raw_cap else ""

        self.publisher.add_atlas_image_slide(
            title=title,
            category=category,
            subtitle=subtitle,
            image_path=p_to_use,
            caption=cap_to_use,
            key_findings=key_findings,
            differentials=differentials,
            clinical_pearl=clinical_pearl,
            notes=""
        )

    def add_horizontal_flowchart_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        steps: List[Dict[str, Any]],
        bottom_takeaway: str = ""
    ):
        """Adım adım klinik ve cerrahi karar akış şeması (Study-Deck Uyumlu)."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        num_steps = len(steps)
        canvas_width = 11.733
        gap = 0.22
        card_w = (canvas_width - ((num_steps - 1) * gap)) / num_steps
        card_h = 4.2 if bottom_takeaway else 4.9
        top_y = Inches(1.9)

        for i, step in enumerate(steps):
            x = Inches(0.8 + i * (card_w + gap))
            
            # Kart gövdesi
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), Inches(card_h))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.LINE
            card.line.width = Pt(1.5)

            # Üst Şerit
            badge_h = Inches(0.55)
            badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(card_w), badge_h)
            badge.fill.solid()
            st = step.get("status", "info")
            if st == "danger":
                badge_col = PPTXPalette.RED
            elif st == "warning":
                badge_col = PPTXPalette.AMBER
            elif st == "success":
                badge_col = PPTXPalette.GREEN
            else:
                badge_col = PPTXPalette.BLUE
            badge.fill.fore_color.rgb = badge_col
            badge.line.fill.background()

            tf_b = badge.text_frame
            tf_b.word_wrap = True
            pb = tf_b.paragraphs[0]
            num_str = step.get("num", str(i + 1))
            pb.text = f"ADIM {num_str}"
            pb.font.name = "Arial"
            pb.font.size = Pt(10)
            pb.font.bold = True
            pb.font.color.rgb = PPTXPalette.WHITE
            pb.alignment = PP_ALIGN.CENTER

            # İçerik
            tf_c = slide.shapes.add_textbox(x + Inches(0.1), top_y + Inches(0.62), Inches(card_w - 0.2), Inches(card_h - 0.72)).text_frame
            tf_c.word_wrap = True

            p_t = tf_c.paragraphs[0]
            p_t.text = step.get("title", "")
            p_t.font.name = "Arial"
            p_t.font.size = Pt(10.5)
            p_t.font.bold = True
            p_t.font.color.rgb = PPTXPalette.NAVY
            p_t.space_after = Pt(4)

            p_d = tf_c.add_paragraph()
            p_d.text = step.get("desc", "")
            p_d.font.name = "Arial"
            p_d.font.size = Pt(9.0)
            p_d.font.color.rgb = PPTXPalette.TEXT_MAIN

        # Alt Vurgu Bandı
        if bottom_takeaway:
            box_y = top_y + Inches(card_h + 0.15)
            box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), box_y, Inches(canvas_width), Inches(0.55))
            box.fill.solid()
            box.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
            box.line.color.rgb = PPTXPalette.BLUE
            box.line.width = Pt(1.2)
            tf_box = box.text_frame
            tf_box.word_wrap = True
            p_box = tf_box.paragraphs[0]
            p_box.text = f"💡 KLİNİK İLKE: {bottom_takeaway}"
            p_box.font.name = "Arial"
            p_box.font.size = Pt(9.5)
            p_box.font.bold = True
            p_box.font.color.rgb = PPTXPalette.NAVY

    def add_decision_tree_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        root_label: str,
        branches: List[Dict[str, Any]],
        bottom_rule: str = ""
    ):
        """Klinik karar ağacı ve triyaj slaytı (Study-Deck Uyumlu)."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # Üst Tetikleyici / Kök Kart
        root_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.9), Inches(11.733), Inches(0.65))
        root_box.fill.solid()
        root_box.fill.fore_color.rgb = PPTXPalette.NAVY
        root_box.line.fill.background()
        tf_r = root_box.text_frame
        tf_r.word_wrap = True
        pr = tf_r.paragraphs[0]
        pr.text = f"🔍 KLİNİK TETİKLEYİCİ / BAŞVURU: {root_label}"
        pr.font.name = "Arial"
        pr.font.size = Pt(11)
        pr.font.bold = True
        pr.font.color.rgb = PPTXPalette.WHITE
        pr.alignment = PP_ALIGN.CENTER

        # Dallar (2 veya 3 Kol)
        num_b = len(branches)
        total_w = 11.733
        gap = 0.25
        bw = (total_w - ((num_b - 1) * gap)) / num_b
        bh = 3.6 if bottom_rule else 4.2
        top_y = Inches(2.7)

        for i, b in enumerate(branches):
            x = Inches(0.8 + i * (bw + gap))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(bw), Inches(bh))
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.BLUE
            card.line.width = Pt(1.5)

            # Dal Başlığı
            b_head = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(bw), Inches(0.5))
            b_head.fill.solid()
            b_head.fill.fore_color.rgb = PPTXPalette.BLUE
            b_head.line.fill.background()
            tf_bh = b_head.text_frame
            tf_bh.word_wrap = True
            pbh = tf_bh.paragraphs[0]
            pbh.text = b.get("label", f"KOL {i+1}").upper()
            pbh.font.name = "Arial"
            pbh.font.size = Pt(10)
            pbh.font.bold = True
            pbh.font.color.rgb = PPTXPalette.WHITE
            pbh.alignment = PP_ALIGN.CENTER

            # Dal İçeriği
            tf_bc = slide.shapes.add_textbox(x + Inches(0.1), top_y + Inches(0.55), Inches(bw - 0.2), Inches(bh - 0.65)).text_frame
            tf_bc.word_wrap = True

            crit = b.get("criteria", "")
            if crit:
                p_c = tf_bc.paragraphs[0]
                p_c.text = f"• Kriterler: {crit}"
                p_c.font.name = "Arial"
                p_c.font.size = Pt(9.5)
                p_c.font.bold = True
                p_c.font.color.rgb = PPTXPalette.NAVY
                p_c.space_after = Pt(4)

            act = b.get("action", "")
            if act:
                p_a = tf_bc.add_paragraph() if crit else tf_bc.paragraphs[0]
                p_a.text = f"• Eylem/Protokol: {act}"
                p_a.font.name = "Arial"
                p_a.font.size = Pt(9.0)
                p_a.font.color.rgb = PPTXPalette.TEXT_MAIN

        # Alt Altın Kural
        if bottom_rule:
            box_y = top_y + Inches(bh + 0.15)
            box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), box_y, Inches(total_w), Inches(0.55))
            box.fill.solid()
            box.fill.fore_color.rgb = PPTXPalette.LIGHT_AMBER
            box.line.color.rgb = PPTXPalette.AMBER
            box.line.width = Pt(1.2)
            tf_box = box.text_frame
            tf_box.word_wrap = True
            p_box = tf_box.paragraphs[0]
            p_box.text = f"⭐ ALTIN KURAL: {bottom_rule}"
            p_box.font.name = "Arial"
            p_box.font.size = Pt(9.5)
            p_box.font.bold = True
            p_box.font.color.rgb = PPTXPalette.NAVY

    def add_trials_kpi_slide(
        self,
        title: str,
        category: str,
        subtitle: str,
        kpis: List[Dict[str, Any]],
        trials_table: List[Dict[str, Any]],
        bottom_evidence: str = ""
    ):
        """Landmark klinik çalışmalar ve KPI kanıt slaytı (Study-Deck Uyumlu)."""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self.publisher._apply_slide_background(slide)
        self.publisher._add_slide_header(slide, title, category=category, subtitle=subtitle)

        # Üst KPI Kartları (3 veya 4 adet)
        num_kpi = len(kpis)
        canvas_w = 11.733
        gap = 0.22
        kw = (canvas_w - ((num_kpi - 1) * gap)) / num_kpi
        kh = Inches(1.2)
        top_y = Inches(1.9)

        for i, kp in enumerate(kpis):
            x = Inches(0.8 + i * (kw + gap))
            card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, top_y, Inches(kw), kh)
            card.fill.solid()
            card.fill.fore_color.rgb = PPTXPalette.WHITE
            card.line.color.rgb = PPTXPalette.BLUE
            card.line.width = Pt(1.5)

            tf_k = card.text_frame
            tf_k.word_wrap = True
            p_num = tf_k.paragraphs[0]
            p_num.text = kp.get("val", "0")
            p_num.font.name = "Arial"
            p_num.font.size = Pt(18)
            p_num.font.bold = True
            p_num.font.color.rgb = PPTXPalette.BLUE
            p_num.alignment = PP_ALIGN.CENTER

            p_lbl = tf_k.add_paragraph()
            p_lbl.text = kp.get("label", "")
            p_lbl.font.name = "Arial"
            p_lbl.font.size = Pt(8.5)
            p_lbl.font.bold = True
            p_lbl.font.color.rgb = PPTXPalette.MUTED
            p_lbl.alignment = PP_ALIGN.CENTER

        # Alt Çalışmalar Tablosu
        table_y = Inches(3.25)
        table_h = 3.3 if bottom_evidence else 3.8
        t_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), table_y, Inches(canvas_w), Inches(table_h))
        t_card.fill.solid()
        t_card.fill.fore_color.rgb = PPTXPalette.WHITE
        t_card.line.color.rgb = PPTXPalette.LINE
        t_card.line.width = Pt(1.2)

        tf_t = slide.shapes.add_textbox(Inches(0.95), table_y + Inches(0.1), Inches(canvas_w - 0.3), Inches(table_h - 0.2)).text_frame
        tf_t.word_wrap = True

        for idx, row in enumerate(trials_table):
            p = tf_t.paragraphs[0] if idx == 0 else tf_t.add_paragraph()
            t_name = row.get("trial", f"Çalışma {idx+1}")
            t_design = row.get("design", "")
            t_res = row.get("result", "")
            p.text = f"📊 {t_name}: {t_design} — Sonuç: {t_res}"
            p.font.name = "Arial"
            p.font.size = Pt(9.5)
            p.font.color.rgb = PPTXPalette.TEXT_MAIN
            p.space_after = Pt(4)

        # En Alt Kanıt Çıkarımı
        if bottom_evidence:
            by = table_y + Inches(table_h + 0.1)
            b_box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), by, Inches(canvas_w), Inches(0.48))
            b_box.fill.solid()
            b_box.fill.fore_color.rgb = PPTXPalette.LIGHT_BLUE
            b_box.line.color.rgb = PPTXPalette.BLUE
            b_box.line.width = Pt(1.0)
            tf_b = b_box.text_frame
            tf_b.word_wrap = True
            pb = tf_b.paragraphs[0]
            pb.text = f"📌 KANIT DÜZEYİ & LİTERATÜR SENTEZİ: {bottom_evidence}"
            pb.font.name = "Arial"
            pb.font.size = Pt(9.0)
            pb.font.bold = True
            pb.font.color.rgb = PPTXPalette.NAVY

    def save(self, output_path: Union[Path, str]) -> Path:
        """Sunum dosyasını kaydeder."""
        return self.publisher.save(output_path)
