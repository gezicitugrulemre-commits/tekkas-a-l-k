"""
Deterministik kalite kontrolleri (LLM'siz, bedava, anlık).

Eleştirmen LLM'e gitmeden önce burada ölçülebilir kurallar denetlenir. Kural bozuksa
taslak doğrudan revizyona gider; LLM eleştirmeni yalnızca içerik kalitesine bakar.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

TABLE_ROW = re.compile(r"^\s*\|.+\|\s*$", re.MULTILINE)
SOURCE_CITE = re.compile(r"\[Kaynak:[^\]]+\]")
PDF_OR_PMID_CITE = re.compile(r"\[(?:[A-Za-z0-9-]+:pdf\d+|PMID:\d+)\]")


def word_count(text: str) -> int:
    return len(text.split())


@dataclass
class CheckResult:
    passed: bool
    problems: List[str] = field(default_factory=list)

    @property
    def feedback(self) -> str:
        return "\n".join(f"- {p}" for p in self.problems)


def check_section(text: str, *, min_words: int, min_citations: int = 3, require_table: bool = True,
                  require_pearls: bool = True, heading: str = "") -> CheckResult:
    problems: List[str] = []
    wc = word_count(text)
    if wc < min_words:
        problems.append(f"Metin {wc} kelime; en az {min_words} kelime olmalı. Yüzeysel kalan alt başlıkları derinleştir.")
    cites = len(SOURCE_CITE.findall(text))
    if cites < min_citations:
        problems.append(f"Yalnızca {cites} adet [Kaynak: ...] atfı var; en az {min_citations} olmalı.")
    if require_table and len(TABLE_ROW.findall(text)) < 4:
        problems.append("Markdown ayırıcı tanı tablosu eksik veya 2 satırdan kısa.")
    if require_pearls and "[!IMPORTANT]" not in text:
        problems.append("'> [!IMPORTANT] Klinik İpuçları' kutusu eksik.")
    if heading and not text.lstrip().startswith(heading):
        problems.append(f"Metin tam olarak '{heading}' başlığıyla başlamalı.")
    return CheckResult(passed=not problems, problems=problems)


def ensure_paragraph_citations(text: str, valid_citations: List[str], fallback_citation: str) -> str:
    """
    Her olgusal paragrafın sonunda geçerli bir `[RVx:pdfN]` / `[PMID:x]` atfı olmasını garanti eder.
    `[RV3:pdf701, RV3:pdf703]` gibi birleşik atıfları ayrı köşeli parantezlere böler.
    (retina_pubmed_graph._ensure_paragraph_citations'tan taşındı.)
    """
    def _split_multi(match):
        parts = [p.strip() for p in re.split(r"[,;]\s*", match.group(1)) if p.strip()]
        valid = [f"[{p}]" for p in parts if f"[{p}]" in valid_citations]
        return " ".join(valid) if valid else fallback_citation

    text = re.sub(r"\[([^\[\]]+[,;][^\[\]]+)\]", _split_multi, text)
    fixed: List[str] = []
    for block in re.split(r"\n\s*\n", text.strip()):
        b = block.strip()
        if not b:
            continue
        if b.startswith("#"):
            fixed.append(b)
            continue
        if not [c for c in PDF_OR_PMID_CITE.findall(b) if c in valid_citations]:
            b = b.rstrip()
            b = b[:-1] + f" {fallback_citation}." if b.endswith(".") else b + f" {fallback_citation}"
        fixed.append(b)
    return "\n\n".join(fixed)


def ensure_first_line(text: str, header_line: str) -> str:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if lines and lines[0].strip().startswith(header_line):
        return text
    if lines and lines[0].strip().startswith("#"):
        lines[0] = header_line
        return "\n\n".join(lines)
    return f"{header_line}\n\n{text}"
