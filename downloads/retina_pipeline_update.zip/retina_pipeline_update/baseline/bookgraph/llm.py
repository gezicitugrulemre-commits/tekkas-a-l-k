"""
Model katmanı: Tek fonksiyonla prompt dosyası -> LLM -> (metin | JSON | Pydantic) + maliyet kaydı.

    from bookgraph.llm import ask
    text = ask("section/write", book="kitap", unit="P01-C01-S01", title=..., ...)

* Zincir: prompt dosyasındaki `models:` veya `role:` -> settings.MODELS.<role>
  İlk model birincil; hata/kota (429) durumunda LangChain `with_fallbacks` sıradakine geçer.
* Bütçe: harcama ECONOMY_THRESHOLD'u geçerse `writer` rolü otomatik `fast` zincirine düşer.
* Maliyet: yanıtın `usage_metadata` değeri (gerçek token) usage.py defterine yazılır.
* Retry: Burada bilerek elle retry DÖNGÜSÜ YOK. Geçici hataları LangGraph düğümündeki
  `RetryPolicy` yakalar (bkz. core.py -> RETRY).
"""

from __future__ import annotations

import json
import logging
import re
from functools import lru_cache
from typing import Any, List, Optional, Type

from pydantic import BaseModel

from . import usage
from .prompting import Prompt, load_prompt
from .settings import MODELS

log = logging.getLogger("bookgraph.llm")


# ---------------------------------------------------------------------------
# Tek model oluşturma
# ---------------------------------------------------------------------------

def _build(spec: str, temperature: float, max_tokens: int, json_mode: bool):
    provider, _, model = spec.partition(":")
    if not model:
        provider, model = "google", provider

    if provider == "google":
        import os
        from langchain_google_genai import ChatGoogleGenerativeAI
        kwargs = dict(model=model, temperature=temperature, max_output_tokens=max_tokens, max_retries=2)
        if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").strip().lower() in ("1", "true", "yes"):
            if model.startswith(("gemini-3", "gemini-4")):
                kwargs["location"] = "global"
        if json_mode:
            kwargs["response_mime_type"] = "application/json"
        return ChatGoogleGenerativeAI(**kwargs)

    if provider == "vertex":
        if "claude" in model.lower():
            from langchain_google_vertexai.model_garden import ChatAnthropicVertex
            return ChatAnthropicVertex(model_name=model, project=MODELS.gcp_project, location=MODELS.gcp_location,
                                       temperature=temperature, max_output_tokens=max_tokens, max_retries=2)
        from langchain_google_vertexai import ChatVertexAI
        return ChatVertexAI(model_name=model, project=MODELS.gcp_project, location=MODELS.gcp_location,
                            temperature=temperature, max_output_tokens=max_tokens, max_retries=2)

    if provider == "bedrock":
        from langchain_aws import ChatBedrockConverse
        return ChatBedrockConverse(model=model, region_name=MODELS.aws_region,
                                   credentials_profile_name=MODELS.aws_profile or None,
                                   temperature=temperature, max_tokens=max_tokens)

    if provider == "wps":
        if not (MODELS.wps_base_url and MODELS.wps_api_key):
            raise RuntimeError("wps sağlayıcısı için WPS_API_BASE_URL ve WPS_API_KEY gerekli")
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=model, base_url=MODELS.wps_base_url, api_key=MODELS.wps_api_key,
                          temperature=temperature, max_tokens=max_tokens, max_retries=2)

    raise ValueError(f"Bilinmeyen sağlayıcı: '{provider}' (google | vertex | bedrock | wps)")


def resolve_chain(prompt: Prompt) -> List[str]:
    if prompt.models:
        return list(prompt.models)
    role = prompt.role
    if role == "writer" and usage.economy_mode():
        log.warning("Bütçe eşiği aşıldı -> writer rolü ekonomik (fast) zincire düşürüldü")
        role = "fast"
    return list(getattr(MODELS, role, MODELS.fast))


@lru_cache(maxsize=64)
def _chain(specs: tuple, temperature: float, max_tokens: int, json_mode: bool, schema: Optional[Type[BaseModel]]):
    runnables = []
    for spec in specs:
        try:
            m = _build(spec, temperature, max_tokens, json_mode)
        except Exception as exc:  # paket yok / anahtar yok -> zincirden çıkar
            log.warning("Model atlandı (%s): %s", spec, exc)
            continue
        if schema is not None:
            m = m.with_structured_output(schema, include_raw=True)
        runnables.append(m)
    if not runnables:
        raise RuntimeError(f"Kullanılabilir model yok: {specs}")
    head, *rest = runnables
    return head.with_fallbacks(rest) if rest else head


# ---------------------------------------------------------------------------
# JSON yardımcıları
# ---------------------------------------------------------------------------

def extract_json(raw_text: str) -> Any:
    text = raw_text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", text)
        if m:
            return json.loads(m.group(1))
        raise


def _content_text(msg) -> str:
    c = getattr(msg, "content", msg)
    if isinstance(c, list):
        return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in c)
    return str(c)


def _log_usage(msg, specs: List[str], book: str, unit: str, prompt_name: str) -> None:
    meta = getattr(msg, "usage_metadata", None) or {}
    model = (getattr(msg, "response_metadata", None) or {}).get("model_name") or specs[0]
    usage.record(book, unit, prompt_name, model, int(meta.get("input_tokens", 0)), int(meta.get("output_tokens", 0)))


# ---------------------------------------------------------------------------
# Ana API
# ---------------------------------------------------------------------------

def ask(prompt_name: str, *, book: str = "default", unit: str = "", schema: Optional[Type[BaseModel]] = None,
        **variables: Any) -> Any:
    """
    Prompt dosyasını doldurur, modeli çağırır, maliyeti kaydeder.
      - schema verilirse  -> Pydantic nesnesi
      - output: json ise  -> dict / list
      - aksi halde        -> str
    """
    prompt = load_prompt(prompt_name)
    messages = prompt.render(**variables)
    specs = resolve_chain(prompt)
    json_mode = prompt.output == "json" and schema is None
    runnable = _chain(tuple(specs), prompt.temperature, prompt.max_tokens, json_mode, schema)

    result = runnable.invoke(messages)

    if schema is not None:
        _log_usage(result.get("raw"), specs, book, unit, prompt_name)
        if result.get("parsed") is None:
            raise ValueError(f"[{prompt_name}] yapılandırılmış çıktı ayrıştırılamadı: {result.get('parsing_error')}")
        return result["parsed"]

    _log_usage(result, specs, book, unit, prompt_name)
    text = _content_text(result).strip()
    return extract_json(text) if prompt.output == "json" else text
