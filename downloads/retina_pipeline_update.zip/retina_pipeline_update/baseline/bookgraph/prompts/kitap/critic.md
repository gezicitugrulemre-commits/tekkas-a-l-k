---
description: Baş editör — içerik kalitesini denetler, küresel bellek için özet ve terim çıkarır
role: reviewer
temperature: 0.0
---
## user
Aşağıdaki akademik kitap alt-bölüm taslağını Baş Editör gözüyle denetle.
(Kelime sayısı, tablo ve atıf sayısı gibi ölçülebilir kurallar kod tarafından zaten doğrulandı:
{{ deterministic_report }})

Alt-Bölüm Başlığı: {{ title }}
Klinik Odak: {{ clinical_focus }}

DENETİM KRİTERLERİ:
1. Klinik doğruluk, derinlik ve güncellik yeterli mi? Yüzeysel veya hatalı kısım varsa `is_approved=False`
   yap ve hangi alt başlıkların düzeltilmesi gerektiğini `revision_instructions` içine madde madde yaz.
2. Daha önce işlenen kavramlar gereksiz yere tekrar edilmiş mi? Terminoloji sözlükle tutarlı mı?
3. `section_summary` alanına bu alt-bölümde nelerin anlatıldığını özetleyen 2-3 cümle yaz
   (sonraki bölümlerde tekrar edilmemesi için).
4. `extracted_terms` alanına bu bölümde geçen en önemli 3-5 İngilizce->Türkçe tıbbi terim eşleşmesini çıkar.
5. `key_concepts` alanına bu bölümde DETAYLI işlenen 2-5 kavram/hastalık adını yaz.

TASLAK METİN:
{{ draft }}
