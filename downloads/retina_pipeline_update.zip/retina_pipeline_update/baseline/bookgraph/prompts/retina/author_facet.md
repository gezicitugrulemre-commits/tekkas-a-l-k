---
description: Retina kitabı — bir konunun tek bir yönünü (temeller / kanıt / uygulama) DB sayfaları + PubMed ile yazar
models: google:gemini-4-argon, google:gemini-3.8-flash, google:gemini-2.5-pro, bedrock:deepseek.v3.2
temperature: 0.15
max_tokens: 4000
# Konu başına sırayla yazılan yönler. Yeni yön eklemek / sırayı değiştirmek için burayı düzenleyin.
facets:
  - key: temeller
    header: "### {tid} {title}"
    focus: Veritabanı kaynak sayfalarında ve PubMed literatüründe yer alan temel anatomi, patofizyoloji, sınıflama ve multimodal görüntüleme/mekanizma ilkelerini ayrıntılı olarak açıkla.
  - key: kanıt
    header: "#### Kanıt"
    focus: Veritabanı sayfalarındaki ve PubMed makalelerindeki somut klinik çalışma bulgularını, epidemiyolojik verileri, görüntüleme biyobelirteçlerini, duyarlılık/özgüllük nüanslarını ve kanıt sınırlılıklarını sentezle. Veritabanında eksik kalan klinik kanıtları PubMed özetleriyle ([PMID:...]) tamamla.
  - key: uygulama
    header: "#### Uygulama"
    focus: Veritabanı ve PubMed kaynaklarında yer alan tanısal yaklaşım, ayırıcı tanı kriterleri, medikal/farmakolojik yönetim algoritmaları ve izlem prensiplerini anlat. Cerrahi operasyon tekniği öğretme; çalışma sorusu veya çoktan seçmeli test ekleme.
min_words: 200   # bunun altındaki yanıt reddedilir ve düğüm RetryPolicy ile tekrar denenir
---
## user
Uzman düzeyinde Türkçe akademik retina başvuru kitabı ("{{ book_title }}") için yalnız aşağıdaki başlığı ve alt odağı yaz:

BAŞLIK: {{ tid }} {{ title }}
ALT BÖLÜM BAŞLIĞI (İlk satır tam olarak bu olmalı): {{ header_line }}
ODAK: {{ focus }}

ZORUNLU YAZIM VE ATIF KURALLARI:
1. İlk satır tam olarak `{{ header_line }}` olmalıdır.
2. Uzunluk: 420 - 650 kelime arasında, derinlikli, akıcı, akademik Türkçe düz yazı (4 ila 6 doyurucu paragraf).
3. Veritabanı PDF sayfalarındaki bilgileri `{{ db_citations }}` etiketleriyle; veritabanında eksik kalan güncel klinik/araştırma verilerini ise PubMed makalelerinden `{{ pm_citations }}` etiketleriyle destekle.
4. HER olgusal paragrafın sonunda mutlaka geçerli bir kaynak etiketi (Örn: `{{ example_citation }}`) bulunmalıdır. Birden fazla atıf kullanacaksan ayrı köşeli parantezlerle yaz (Örn: `[RV3:pdf701] [PMID:12345678]`).
5. Asla "sağlanan kaynaklarda yeterli kanıt bulunmamaktadır" gibi boşluk/reddiye paragrafı yazma; kitap sayfalarında eksik olan veriyi aşağıda verilen PUBMED LİTERATÜR KANITLARI ile eksiksiz tamamla.
6. Çalışma sorusu, quiz, cevap anahtarı veya cerrahi ameliyat tekniği kesinlikle yazma. Düz metin paragrafları kullan (madde işaretli liste yerine akademik paragraf tercih et).

=== VERİTABANI KİTAP SAYFALARI ({{ db_citations }}) ===
{{ db_context }}

=== PUBMED LİTERATÜR KANITLARI ({{ pm_citations }}) ===
{{ pubmed_context }}
