"""
Gerçek token kullanımına dayalı maliyet defteri (SQLite, thread-safe).

Eski `quota_manager.py` maliyeti kelime sayısından TAHMİN ediyordu. Burada her LLM
çağrısının `usage_metadata` değeri (gerçek input/output token) kaydedilir.
Paralel dallar aynı anda yazabilir; SQLite + kilit ile çakışma olmaz.
"""

from __future__ import annotations

import sqlite3
import threading
from datetime import datetime
from typing import Dict, Optional

from .settings import MODELS, PATHS

# Milyon token başına yaklaşık USD fiyatları. Bilinmeyen model -> "default".
PRICING: Dict[str, Dict[str, float]] = {
    "gemini-4-argon": {"input": 2.00, "output": 10.00},
    "gemini-3.8-flash": {"input": 0.75, "output": 3.75},
    "gemini-2.5-flash": {"input": 0.30, "output": 2.50},
    "gemini-2.5-pro": {"input": 1.25, "output": 10.00},
    "claude-sonnet-4@20250514": {"input": 3.00, "output": 15.00},
    "deepseek.v3.2": {"input": 0.60, "output": 1.70},
    "moonshotai.kimi-k2.5": {"input": 0.60, "output": 2.50},
    "default": {"input": 1.00, "output": 5.00},
}

_lock = threading.Lock()
_conn: Optional[sqlite3.Connection] = None


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        PATHS.ensure()
        _conn = sqlite3.connect(str(PATHS.usage_db), check_same_thread=False)
        _conn.execute(
            """CREATE TABLE IF NOT EXISTS usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT, book TEXT, unit TEXT, prompt TEXT, model TEXT,
                input_tokens INTEGER, output_tokens INTEGER, usd REAL)"""
        )
        _conn.commit()
    return _conn


def price(model: str, input_tokens: int, output_tokens: int) -> float:
    rates = PRICING.get(model.split(":")[-1], PRICING["default"])
    return round(input_tokens / 1e6 * rates["input"] + output_tokens / 1e6 * rates["output"], 6)


def record(book: str, unit: str, prompt: str, model: str, input_tokens: int, output_tokens: int) -> float:
    usd = price(model, input_tokens, output_tokens)
    with _lock:
        db = _db()
        db.execute(
            "INSERT INTO usage (ts, book, unit, prompt, model, input_tokens, output_tokens, usd) VALUES (?,?,?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), book, unit, prompt, model, input_tokens, output_tokens, usd),
        )
        db.commit()
    return usd


def spent(book: Optional[str] = None) -> float:
    with _lock:
        q = "SELECT COALESCE(SUM(usd),0) FROM usage" + (" WHERE book=?" if book else "")
        return float(_db().execute(q, (book,) if book else ()).fetchone()[0])


def summary() -> Dict[str, Dict[str, float]]:
    with _lock:
        rows = _db().execute(
            "SELECT book, COUNT(*), SUM(input_tokens), SUM(output_tokens), SUM(usd) FROM usage GROUP BY book"
        ).fetchall()
    return {r[0]: {"calls": r[1], "input_tokens": r[2], "output_tokens": r[3], "usd": round(r[4], 4)} for r in rows}


def remaining_budget() -> float:
    return max(0.0, MODELS.budget_usd - spent())


def economy_mode() -> bool:
    """Bütçenin ECONOMY_THRESHOLD (varsayılan %88) kadarı harcandıysa yazar rolü hızlı modele düşer."""
    return MODELS.budget_usd > 0 and spent() / MODELS.budget_usd >= MODELS.economy_threshold
