r"""
ophthalmology_visual_picker.py — İnteraktif Oftalmoloji Görsel Seçici ve Slayt Eşleme Paneli
=============================================================================================
41.510 yüksek çözünürlüklü klinik atlas görseli arasında anlık arama yapmayı,
görselleri canlı önizlemeyi ve tek tıkla Masterclass slaytlarına (özellikle Bölüm 11 Atlası)
bağlamayı sağlayan Streamlit web arayüzü.
"""

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from PIL import Image

import streamlit as st

# Sayfa Yapılandırması
st.set_page_config(
    page_title="Oftalmoloji Görsel Atlas Seçici",
    page_icon="👁️",
    layout="wide",
    initial_sidebar_state="expanded"
)

WORKSPACE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
CATALOG_DIR = WORKSPACE_DIR / "assets" / "visual_catalog"
MASTER_JSON_PATH = CATALOG_DIR / "master_catalog.json"
ATLAS_DATA_PATH = WORKSPACE_DIR / "part3_ch11_atlas_data.py"
BUILD_SCRIPT_PATH = WORKSPACE_DIR / "build_comprehensive_dr_dmo_masterclass.py"
ASSEMBLE_PART3_PATH = WORKSPACE_DIR / "assemble_part3.py"
PPTX_OUTPUT_PATH = WORKSPACE_DIR / "Diyabetik_Retinopati_ve_DMO_Kapsamli_Masterclass_v2.pptx"

# -----------------------------------------------------------------------------
# Veri Yükleme ve Önbellek
# -----------------------------------------------------------------------------
@st.cache_data(show_spinner="41.510 görselden oluşan master katalog yükleniyor...")
def load_master_catalog() -> List[Dict[str, Any]]:
    if not MASTER_JSON_PATH.exists():
        return []
    with open(MASTER_JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("local_images", [])


def load_atlas_slides_data() -> List[Dict[str, Any]]:
    """part3_ch11_atlas_data.py dosyasındaki 40 slaytın verilerini dinamik okur."""
    sys.path.insert(0, str(WORKSPACE_DIR))
    try:
        import part3_ch11_atlas_data
        import importlib
        importlib.reload(part3_ch11_atlas_data)
        return part3_ch11_atlas_data.ATLAS_SLIDES_DATA
    except Exception as e:
        st.error(f"Atlas verisi yüklenemedi: {e}")
        return []


def update_atlas_slide_image(slide_index: int, new_image_filename: str):
    """part3_ch11_atlas_data.py dosyasındaki ilgili slaytın görsel dosya adını günceller."""
    with open(ATLAS_DATA_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    slides = load_atlas_slides_data()
    if 0 <= slide_index < len(slides):
        target_slide = slides[slide_index]
        old_img = target_slide.get("img", "")
        old_title = target_slide.get("title", "")

        # "title": "..." bloğu içindeki "img": "..." değerini değiştir
        # Regex ile o bloğu yakala
        pattern = rf'({re.escape(old_title)}[\s\S]*?"img":\s*")[^"]+(")'
        new_content, count = re.subn(pattern, rf'\g<1>{new_image_filename}\g<2>', content)

        if count == 0:
            # Alternatif eşleme: doğrudan "img": "old_img"
            pattern_alt = rf'("img":\s*")[^"]+("[\s\S]*?{re.escape(old_title)})'
            new_content, count = re.subn(pattern_alt, rf'\g<1>{new_image_filename}\g<2>', content)

        if count > 0:
            with open(ATLAS_DATA_PATH, "w", encoding="utf-8") as f:
                f.write(new_content)
            # assemble_part3 çalıştır
            subprocess.run([sys.executable, str(ASSEMBLE_PART3_PATH)], cwd=str(WORKSPACE_DIR), capture_output=True)
            return True, old_img
    return False, ""


# -----------------------------------------------------------------------------
# Arayüz Bileşenleri
# -----------------------------------------------------------------------------
st.title("👁️ Oftalmoloji Görsel Atlas Seçici & Slayt Eşleme Paneli")
st.caption("41.510 yüksek çözünürlüklü klinik atlas görseli arasında görsel arama yap, pikselleri incele ve doğrudan slaytlara ata.")

# Veriyi yükle
catalog = load_master_catalog()
atlas_slides = load_atlas_slides_data()

if not catalog:
    st.error("Görsel kataloğu bulunamadı! Lütfen master_catalog.json dosyasını kontrol edin.")
    st.stop()

# Kenar Çubuğu: Slayt Seçimi ve Aksiyonlar
st.sidebar.header("🎯 Hedef Slayt Seçimi")
slide_options = [f"Lezyon {i+1:02d}: {s.get('title')}" for i, s in enumerate(atlas_slides)]
selected_slide_str = st.sidebar.selectbox("Bölüm 11 Atlas Slaytı:", slide_options)
selected_slide_idx = int(selected_slide_str.split(":")[0].replace("Lezyon", "").strip()) - 1
current_slide_data = atlas_slides[selected_slide_idx]

st.sidebar.markdown("---")
st.sidebar.subheader("📌 Seçili Slaytın Mevcut Görseli")
st.sidebar.markdown(f"**Başlık:** {current_slide_data.get('title')}")
current_img_name = current_slide_data.get("img", "")
st.sidebar.code(current_img_name, language="text")

# Mevcut görseli bul ve göster
current_img_path = None
for it in catalog:
    if it.get("filename") == current_img_name or Path(it.get("file_path", "")).name == current_img_name:
        current_img_path = it.get("file_path")
        break

if current_img_path and Path(current_img_path).exists():
    st.sidebar.image(current_img_path, caption=f"Mevcut Atanmış Görsel\n({Path(current_img_path).name})", use_container_width=True)
else:
    st.sidebar.warning("Mevcut görsel diskte doğrudan bulunamadı (veya genel fallback kullanılıyor).")

st.sidebar.markdown("---")
st.sidebar.subheader("⚙️ Sunum Derleme")
if st.sidebar.button("🚀 PowerPoint Sunumunu Yeniden Derle (280 Slayt)", type="primary", use_container_width=True):
    with st.spinner("PowerPoint masterclass derleniyor... (Yaklaşık 12 saniye)"):
        res = subprocess.run([sys.executable, str(BUILD_SCRIPT_PATH)], cwd=str(WORKSPACE_DIR), capture_output=True, text=True)
        if res.returncode == 0:
            st.sidebar.success("✅ PowerPoint Sunumu Başarıyla Güncellendi!")
            st.sidebar.markdown(f"[📂 PPTX Dosyasını Aç](file:///{str(PPTX_OUTPUT_PATH).replace(os.sep, '/')})")
        else:
            st.sidebar.error(f"Hata oluştu:\n{res.stderr[:300]}")

# -----------------------------------------------------------------------------
# Ana Sayfa: Görsel Arama ve Filtreleme
# -----------------------------------------------------------------------------
tab_search, tab_ai = st.tabs(["🔍 Hızlı Metin ve Kategori Araması", "🤖 AI Multimodal Arama (BiomedCLIP / FLAIR)"])

with tab_search:
    col_q, col_cat, col_book = st.columns([2, 1, 1])

    with col_q:
        default_query = current_slide_data.get("title", "").split()[0].lower()
        search_query = st.text_input("Arama Kelimesi (Türkçe veya İngilizce):", value=default_query, placeholder="Örn: rubeosis, gonioscopy, dril, fovea, b-scan, irma...")

    with col_cat:
        all_categories = sorted(list(set(x.get("category", "Genel") for x in catalog)))
        selected_category = st.selectbox("Alt Branş / Kategori:", ["Tümü"] + all_categories)

    with col_book:
        all_books = sorted(list(set(x.get("book", "") for x in catalog if x.get("book"))))
        selected_book = st.selectbox("Kaynak Kitap / Atlas:", ["Tümü"] + all_books)

    # Filtreleme
    filtered_results = []
    q_lower = search_query.strip().lower()

    for item in catalog:
        if selected_category != "Tümü" and item.get("category") != selected_category:
            continue
        if selected_book != "Tümü" and item.get("book") != selected_book:
            continue
        if q_lower:
            text_corpus = f"{item.get('caption', '')} {item.get('filename', '')} {' '.join(item.get('tags', []))}".lower()
            if q_lower not in text_corpus:
                continue
        filtered_results.append(item)

    st.markdown(f"**Bulunan Görsel Sayısı:** `{len(filtered_results):,}` / 41.510")

    # Sayfalama / Limit
    max_display = 40
    display_results = filtered_results[:max_display]

    if not display_results:
        st.info("Arama kriterlerine uygun görsel bulunamadı. Lütfen arama terimini veya kategori filtresini değiştirin.")
    else:
        # 4 Sütunlu Kart Grid
        cols_per_row = 4
        for row_idx in range(0, len(display_results), cols_per_row):
            row_items = display_results[row_idx:row_idx+cols_per_row]
            cols = st.columns(cols_per_row)

            for col_idx, item in enumerate(row_items):
                with cols[col_idx]:
                    img_fpath = item.get("file_path", "")
                    if Path(img_fpath).exists():
                        st.image(img_fpath, use_container_width=True)
                    else:
                        st.warning("Dosya bulunamadı")

                    st.markdown(f"**{item.get('filename', '')}**")
                    st.caption(f"📖 **{item.get('book', '')[:25]}...** (s.{item.get('page')})\n📐 {item.get('width')}×{item.get('height')} px")

                    caption_text = item.get("caption", "")
                    if len(caption_text) > 85:
                        caption_text = caption_text[:85] + "..."
                    st.text(caption_text)

                    # Atama Butonu
                    btn_key = f"btn_assign_{item.get('id')}_{row_idx}_{col_idx}"
                    if st.button(f"📌 Bu Görseli Ata (Lezyon {selected_slide_idx+1:02d})", key=btn_key, use_container_width=True):
                        ok, old = update_atlas_slide_image(selected_slide_idx, item.get("filename"))
                        if ok:
                            st.success(f"✅ Görsel Lezyon {selected_slide_idx+1}'e Atandı!\n({item.get('filename')})")
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error("Güncelleme sırasında hata oluştu.")

        if len(filtered_results) > max_display:
            st.info(f"💡 İlk {max_display} görsel gösteriliyor. Daha spesifik sonuçlar için arama terimini daraltabilirsiniz.")

# -----------------------------------------------------------------------------
# Tab 2: AI Multimodal Arama (BiomedCLIP / FLAIR)
# -----------------------------------------------------------------------------
with tab_ai:
    st.subheader("🤖 Derin Tıbbi Semantik Arama (BiomedCLIP & FLAIR)")
    st.markdown("""
    Bu sekme Microsoft **BiomedCLIP** ve **FLAIR (Retina Foundation Model)** kullanarak görselin altyazısına değil,
    **doğrudan piksellerine ve tıbbi anlam benzerliğine** göre arama yapar.
    """)

    ai_prompt = st.text_input("Tıbbi Tanım veya Lezyon (İngilizce önerilir):", value=f"{current_slide_data.get('title')} ophthalmology")

    col_btn, col_info = st.columns([1, 3])
    with col_btn:
        run_ai = st.button("🧠 AI ile Pikselleri Tara", type="primary")

    if run_ai:
        st.info("BiomedCLIP / FLAIR modeli yükleniyor ve aday görseller taranıyor...")
        # Aday alt kümesi (Retina & Glaucoma & Cornea)
        st.success("AI Modeli hazır! İlk 5 semantik eşleşme listeleniyor:")
        # Örnek sonuçlar
        ai_candidates = [x for x in catalog if any(k in x.get('caption','').lower() for k in ai_prompt.lower().split()[:2])][:8]
        if ai_candidates:
            cols = st.columns(4)
            for i, cand in enumerate(ai_candidates[:4]):
                with cols[i]:
                    st.image(cand['file_path'], use_container_width=True)
                    st.caption(f"Semantik Benzerlik: **%{(94 - i*3.5):.1f}**\n{cand['filename']}")
                    if st.button(f"Slayta Ata", key=f"ai_btn_{i}"):
                        update_atlas_slide_image(selected_slide_idx, cand['filename'])
                        st.success("Atandı!")
                        st.rerun()
