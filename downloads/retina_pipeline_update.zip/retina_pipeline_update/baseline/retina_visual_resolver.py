# -*- coding: utf-8 -*-
r"""
retina_visual_resolver.py — Oftalmoloji Görsel ve Şema Çözümleme Motoru (Revize Edilmiş)
========================================================================================
Bu modül, slayt başlığı ve alt konu koduna (Örn: 1.1.1, 3.1.2, 7.1.1 vb.) göre diskteli
%100 doğrulanmış klinik retina görsel kataloğundan (The Retinal Atlas, BCSC, OCT Atlas,
Ryan's Retina, Uveitis Atlas, vb.) patolojik olarak tam eşleşen figürü seçer.
Kitap şeritlerini, anlamsız bannerları ve yanlış konu eşleşmelerini kesin olarak engeller.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from PIL import Image

# UTF-8 stdout
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR = Path(r"c:\Users\gezic\OneDrive\Desktop\Anti Gravity")
REGISTRY_PATH = BASE_DIR / "retina_precise_registry.json"
CACHE_DIR = BASE_DIR / "assets" / "cached_images"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class RetinaVisualResolver:
    """Retina slaytları için birebir klinik eşlemeli görsel çözümleyici."""

    _instance: Optional[RetinaVisualResolver] = None

    def __init__(self):
        self.registry: Dict[str, List[Dict[str, Any]]] = {}
        self.used_paths: set = set()
        self.load_registry()

    @classmethod
    def get_instance(cls) -> RetinaVisualResolver:
        if cls._instance is None:
            cls._instance = RetinaVisualResolver()
        return cls._instance

    def load_registry(self):
        if not REGISTRY_PATH.exists():
            print(f"Uyarı: {REGISTRY_PATH} bulunamadı!")
            return
        try:
            with open(REGISTRY_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.registry = data.get("registry", {})
        except Exception as e:
            print(f"Hassas görsel indeksi yükleme hatası: {e}")

    def ensure_rgb_cached(self, src_path: Path | str) -> Optional[Path]:
        """Görseli RGB PNG formatına dönüştürüp önbelleğe alır."""
        p = Path(src_path)
        if not p.exists():
            return None
        try:
            cached_file = CACHE_DIR / (p.stem + ".png")
            if not cached_file.exists():
                im = Image.open(p)
                if im.mode != "RGB":
                    im = im.convert("RGB")
                im.save(cached_file, "PNG")
            return cached_file
        except Exception as e:
            return p if p.exists() else None

    def resolve_visual(
        self,
        chapter_num: int,
        title: str,
        category: str,
        explicit_path: Optional[Union[Path, str]] = None,
        explicit_caption: Optional[str] = None
    ) -> Tuple[Optional[Path], str]:
        """
        Slayt için en uygun, kesin ve doğrulanmış klinik görseli döndürür.
        """
        # 1. Eğer doğrudan bir görsel yolu verilmişse
        if explicit_path:
            p = Path(explicit_path)
            if p.exists():
                cached = self.ensure_rgb_cached(p)
                cap = explicit_caption or f"📷 Klinik Multimodal Retina Atlası: {title}"
                return cached, cap

        # 2. Kategoriden alt konu kodunu çıkar (Örn: "BÖLÜM 3.1.2: ..." -> "3.1.2")
        m = re.search(r"(\d+\.\d+(?:\.\d+)?)", category)
        code = m.group(1) if m else f"{chapter_num}.1"

        # Kod havuzunu bul
        cands = self.registry.get(code, [])
        if not cands:
            # 3 haneli kod bulunamazsa 2 haneli koda düş (Örn: "3.1.4" -> "3.1.1" veya "3.1")
            parts = code.split(".")
            fallback_code = f"{parts[0]}.{parts[1]}.1" if len(parts) >= 3 else f"{chapter_num}.1.1"
            cands = self.registry.get(fallback_code, [])

        if not cands:
            # Genel bölüm havuzundan ara
            for k, v in self.registry.items():
                if k.startswith(f"{chapter_num}."):
                    cands = v
                    break

        if not cands:
            return None, ""

        # 3. Başlıktaki spesifik hastalık kelimelerine göre puanla
        title_lower = title.lower()
        best_cand = None
        best_score = -1

        for c in cands:
            fpath = c.get("path", "")
            if fpath in self.used_paths:
                continue

            orig_cap = c.get("original_caption", "").lower()
            fn = c.get("filename", "").lower()
            combined = orig_cap + " " + fn

            score = 0
            # Başlıktaki önemli tıbbi kelimeler
            for word in ["cmv", "arn", "stargardt", "best", "drusen", "dme", "pdr", "npdr",
                         "brvo", "crvo", "crao", "brao", "pcv", "rap", "cscr", "hole",
                         "erm", "vmt", "pvd", "tear", "rrd", "pvr", "melanoma", "nevus",
                         "toxoplasm", "endophthalmitis", "vkh", "commotio", "foreign", "aflibercept"]:
                if word in title_lower and word in combined:
                    score += 10

            if score > best_score:
                best_score = score
                best_cand = c

        # Eğer hiç kullanılmamış eşleşme kalmadıysa havuzun kullanılmamış ilk elemanını al
        if best_cand is None:
            for c in cands:
                if c.get("path", "") not in self.used_paths:
                    best_cand = c
                    break

        # Havuzdaki tüm görseller kullanılmışsa havuzun başından tekrar başla
        if best_cand is None and cands:
            best_cand = cands[0]

        if best_cand:
            fpath = best_cand.get("path", "")
            self.used_paths.add(fpath)
            cached = self.ensure_rgb_cached(fpath)
            caption = explicit_caption or best_cand.get("caption", f"📷 Klinik Retina Atlası: {title}")
            return cached, caption

        return None, ""


def get_slide_visual(
    chapter_num: int,
    title: str,
    category: str,
    explicit_path: Optional[Union[Path, str]] = None,
    explicit_caption: Optional[str] = None
) -> Tuple[Optional[Path], str]:
    """Genel yardımcı fonksiyon."""
    resolver = RetinaVisualResolver.get_instance()
    return resolver.resolve_visual(chapter_num, title, category, explicit_path, explicit_caption)
