"""Guarded update: refuses to overwrite files changed since the uploaded snapshot."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def text_hash(data):
    return hashlib.sha256(data.decode('utf-8-sig').replace('\r\n','\n').encode('utf-8')).hexdigest()


def apply(package, target, *, commit=False):
    package, target = Path(package).resolve(), Path(target).resolve()
    if not (target/'bookgraph').is_dir():
        raise ValueError('Hedef, bookgraph klasörünü içeren proje kökü olmalı.')
    manifest=json.loads((package/'manifest.json').read_text(encoding='utf-8'))
    planned=[];conflicts=[]
    for entry in manifest['files']:
        relative=Path(entry['path'])
        destination=target/relative
        source=package/'updated'/relative
        if not destination.resolve().is_relative_to(target) or not source.resolve().is_relative_to(package/'updated'):
            raise ValueError('Unsafe update path')
        payload=source.read_bytes()
        if text_hash(payload)!=entry['updated_hash']:
            raise ValueError('Paket içeriği hash kontrolünden geçmedi: '+str(relative))
        current=text_hash(destination.read_bytes()) if destination.is_file() else None
        if current==entry['updated_hash']:
            continue
        if current!=entry['baseline_hash']:
            conflicts.append(str(relative));continue
        planned.append((source,destination))
    if conflicts:
        raise ValueError('Yerel değişiklikler korunuyor; hiçbir dosya yazılmadı. Üç yönlü birleştirme gerekli: '+', '.join(conflicts))
    if not commit or not planned:
        return {'status':'dry_run' if not commit else 'already_applied','files':len(planned)}
    backup=target/'.retina-update-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup.mkdir(parents=True,exist_ok=False)
    originals={}
    # Back up every existing destination before the first write.
    for source,destination in planned:
        relative=destination.relative_to(target)
        originals[destination]=destination.is_file()
        if destination.is_file():
            saved=backup/relative;saved.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(destination,saved)
    written=[]
    try:
        for source,destination in planned:
            destination.parent.mkdir(parents=True,exist_ok=True)
            fd,name=tempfile.mkstemp(prefix=destination.name+'.',suffix='.tmp',dir=destination.parent)
            try:
                with os.fdopen(fd,'wb') as stream:
                    stream.write(source.read_bytes());stream.flush();os.fsync(stream.fileno())
                if destination.is_file():shutil.copymode(destination,name)
                os.replace(name,destination)
                written.append(destination)
            finally:
                if os.path.exists(name):os.unlink(name)
    except Exception:
        for destination in reversed(written):
            if originals[destination]:shutil.copy2(backup/destination.relative_to(target),destination)
            else:destination.unlink()
        raise
    return {'status':'applied','files':len(planned),'backup':str(backup)}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project',type=Path)
    parser.add_argument('--apply',action='store_true',help='Varsayılan ön kontrolden sonra değişiklikleri uygula')
    args=parser.parse_args()
    try:
        print(json.dumps(apply(Path(__file__).parent,args.project,commit=args.apply),ensure_ascii=False,indent=2))
    except (ValueError,OSError) as error:
        parser.exit(1,str(error)+'\n')
