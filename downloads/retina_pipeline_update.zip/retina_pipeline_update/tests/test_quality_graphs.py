from types import SimpleNamespace
import pytest
from bookgraph import quality, safety
from bookgraph.books import kitap, octa, retina
from langgraph.checkpoint.memory import InMemorySaver

def test_no_fabricated_fallback_citation():
    with pytest.raises(ValueError):quality.ensure_paragraph_citations('Unsupported claim.', ['[RV3:pdf1]'],'[RV3:pdf1]')

def test_unknown_citation_even_with_valid_one():
    with pytest.raises(ValueError):quality.ensure_paragraph_citations('Claim [RV3:pdf1] [PMID:999].',['[RV3:pdf1]'])

def test_citation_normalization_preserves_all_known_ids():
    text=quality.ensure_paragraph_citations('Claim [RV3:pdf1, PMID:123].',['[RV3:pdf1]','[PMID:123]'])
    assert text=='Claim [RV3:pdf1] [PMID:123].'

def test_heading_does_not_hide_uncited_body():
    with pytest.raises(ValueError):quality.ensure_paragraph_citations('# Heading\nUncited body.',['[RV3:pdf1]'])

@pytest.mark.parametrize('after',[{'text':'Give 20 mg [RV3:pdf1]'}, {'text':'Give 10 mg [RV3:pdf2]'}, {'text':'Asla give 10 mg [RV3:pdf1]'}])
def test_humanizer_critical_changes_rejected(after):
    with pytest.raises(ValueError):safety.assert_clinical_invariants({'text':'Give 10 mg [RV3:pdf1]'},after)

def test_humanizer_style_edit_allowed():
    safety.assert_clinical_invariants({'text':'Dose is 10 mg [RV3:pdf1]'}, {'text':'Doz 10 mg [RV3:pdf1]'})

def test_no_retrieval_no_writing(monkeypatch):
    monkeypatch.setattr(kitap,'_retriever',lambda: (_ for _ in ()).throw(RuntimeError('index missing')))
    with pytest.raises(RuntimeError):kitap.node_retrieve({'subsection':{}})
    with pytest.raises(ValueError):kitap.node_synthesize({'chunks':[]})

def setup_section(monkeypatch, approved):
    draft=' '.join(['evidence']*30)+'\n\n| A | B |\n|---|---|\n| a | b |\n| c | d |\n[Kaynak: X] [Kaynak: Y] [Kaynak: Z]\n[!IMPORTANT]'
    monkeypatch.setattr(kitap,'load_recipe',lambda _: {'field':'Medical','book_title':'Test','scale':{'min_words':10,'target_words':50,'max_revisions':2}})
    monkeypatch.setattr(kitap,'node_load_context',lambda _: {'previous_summaries':'','covered_concepts':'','glossary':'','revision':0})
    monkeypatch.setattr(kitap,'node_queries',lambda _: {'queries':['x']})
    monkeypatch.setattr(kitap,'node_retrieve',lambda _: {'chunks':[{'content':'Evidence','source_book':'X','page_number':1}]})
    monkeypatch.setattr(kitap,'node_synthesize',lambda _: {'evidence':'Evidence'})
    def ask(name,**kwargs):
        if name=='kitap/write':return draft
        return kitap.CriticReview(is_approved=approved,revision_instructions='' if approved else 'unsupported')
    monkeypatch.setattr(kitap,'ask',ask)
    committed=[]
    monkeypatch.setattr(kitap,'node_commit',lambda state: committed.append(state) or {'completed':['T']})
    return committed

def job():
    return {'recipe':'test','book_id':'b','subsection':{'subsection_id':'T','title':'Test'},'part_title':'P','chapter_title':'C','chapter_id':'C','human_review':False}

def test_real_section_graph_does_not_force_approval(monkeypatch):
    committed=setup_section(monkeypatch,False)
    graph=kitap.build_section().compile()
    with pytest.raises(ValueError,match='kalite reddi'):graph.invoke(job())
    assert not committed

def test_real_section_graph_approved_and_checkpointed(monkeypatch):
    committed=setup_section(monkeypatch,True)
    graph=kitap.build_section().compile(checkpointer=InMemorySaver())
    config={'configurable':{'thread_id':'test'}}
    assert graph.invoke(job(),config)['completed']==['T']
    assert not graph.get_state(config).next
    assert len(committed)==1

def test_zero_score_octa_not_approved(monkeypatch):
    monkeypatch.setattr(octa,'_plan',lambda s:{'title':'T'})
    monkeypatch.setattr(octa,'_subset_ev',lambda s:{'E':{'text':'evidence'}})
    monkeypatch.setattr(octa,'ask',lambda *a,**k:{'clinical_quality_score':0})
    monkeypatch.setattr(octa,'load_prompt',lambda _:SimpleNamespace(meta={'min_score':85}))
    with pytest.raises(ValueError):octa.node_review({'cid':'c','authored':{'sections':[],'disagreements':[]},'questions':[],'human_review':False})

@pytest.mark.parametrize('module,fn,state',[(kitap,'node_commit',{}),(octa,'node_save',{}),(retina,'node_commit',{})])
def test_direct_commit_requires_approval(module,fn,state):
    with pytest.raises(ValueError):getattr(module,fn)(state)

def test_retry_excludes_configuration_and_validation():
    from bookgraph.core import _retryable
    assert not _retryable(ValueError('bad config'))
    assert not _retryable(SimpleStatusError(403))
    assert _retryable(SimpleStatusError(429))
    assert _retryable(TimeoutError())

class SimpleStatusError(Exception):
    def __init__(self,status):self.status_code=status

def test_retina_review_gets_sources_and_blocks_commit(tmp_path,monkeypatch):
    monkeypatch.setattr(retina,'PATHS',SimpleNamespace(storage=tmp_path))
    calls=[]
    def ask(name,**kwargs):
        calls.append(kwargs)
        return retina.TopicReview(approved=False,unsupported_claims=['wrong claim'])
    monkeypatch.setattr(retina,'ask',ask)
    with pytest.raises(ValueError):retina.node_review({'tid':'1','draft':'text','db_pages':[{'text':'source'}]})
    assert calls[0]['db_pages']==[{'text':'source'}]
    assert (tmp_path/'review_required/1.json').exists()


def test_humanizer_cannot_change_unit():
    with pytest.raises(ValueError):safety.assert_clinical_invariants({'dose':'10 mg'}, {'dose':'10 g'})

def test_humanizer_cannot_swap_dose_units():
    with pytest.raises(ValueError):safety.assert_clinical_invariants({'dose':'10 mg 20 ml'}, {'dose':'20 mg 10 ml'})


@pytest.mark.parametrize('name',['dr_dmo_pptx_pipeline.py','retina_vitreus_master_pptx_pipeline.py','retina_compendium_langgraph_pipeline.py','cataract_complications_langgraph_pipeline.py'])
def test_legacy_mock_supervisor_cannot_approve(name):
    import ast, bookgraph
    from pathlib import Path
    p=Path(bookgraph.__file__).resolve().parent.parent/name
    tree=ast.parse(p.read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='argon4_supervisor_audit_node')
    future=ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)
    ns={}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[future,fn],type_ignores=[])),str(p),'exec'),ns)
    with pytest.raises(RuntimeError,match='gerçek model'):ns['argon4_supervisor_audit_node']({})
