import ast
import importlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image
from bookgraph import safety
from retina_visual_resolver import RetinaVisualResolver


def record(image, disease='stargardt', caption='Stargardt disease fundus photograph.'):
    return {'path':str(image),'disease_ids':[disease],'original_caption':caption,
            'review_status':'approved','reviewer':'expert-review-01','source_id':'BOOK1',
            'page':5,'figure_id':'5.1','panel_id':'A','modality':'fundus',
            'bbox':[0,0,10,10],'image_sha256':safety.file_hash(image)}


def resolver(tmp_path,records):
    index=tmp_path/'registry.json';index.write_text(json.dumps({'registry':records}))
    return RetinaVisualResolver(index,tmp_path/'cache')


def test_legacy_zero_match_cannot_be_inserted(tmp_path):
    image=tmp_path/'tox.png';Image.new('RGB',(8,8)).save(image)
    r=resolver(tmp_path,{'7.1.1':[{'path':str(image),'original_caption':'Toxoplasmosis'}]})
    assert r.resolve_visual(7,'Akut retinal nekroz ARN','BÖLÜM 7.1.1')[0] is None
    assert r.decisions[-1]['status']=='review_required'


def test_topic_identity_independent_of_section_code(tmp_path):
    image=tmp_path/'correct.png';Image.new('RGB',(8,8)).save(image)
    r=resolver(tmp_path,{'6.1.2':[record(image)]})
    first=r.resolve_visual(6,'STARGARDT ABCA4','BÖLÜM 6.1.3')[0]
    assert first is not None
    assert first==r.resolve_visual(6,'STARGARDT ABCA4','BÖLÜM 6.1.3')[0]


def test_compound_disease_not_pure_crao(tmp_path):
    image=tmp_path/'combined.png';Image.new('RGB',(8,8)).save(image)
    rec=record(image,'crao','Combined CRVO and CRAO.')
    r=resolver(tmp_path,{'x':[rec]})
    assert r.resolve_visual(3,'CRAO','3.2.2')[0] is None


def test_explicit_path_does_not_bypass_review(tmp_path):
    image=tmp_path/'unverified.png';Image.new('RGB',(8,8)).save(image)
    r=resolver(tmp_path,{})
    assert r.resolve_visual(6,'Stargardt','6',explicit_path=image)[0] is None


def test_changed_image_invalidates_approval(tmp_path):
    image=tmp_path/'image.png';Image.new('RGB',(8,8),'red').save(image)
    rec=record(image)
    Image.new('RGB',(8,8),'blue').save(image)
    r=resolver(tmp_path,{'x':[rec]})
    assert r.resolve_visual(6,'Stargardt','6')[0] is None


def test_same_filename_different_content_has_separate_cache(tmp_path):
    a=tmp_path/'a';b=tmp_path/'b';a.mkdir();b.mkdir()
    Image.new('RGB',(8,8),'red').save(a/'same.png')
    Image.new('RGB',(8,8),'blue').save(b/'same.png')
    r=resolver(tmp_path,{})
    assert r.ensure_rgb_cached(a/'same.png') != r.ensure_rgb_cached(b/'same.png')


def test_manifest_exposes_unresolved_visuals(tmp_path):
    r=resolver(tmp_path,{})
    r.resolve_visual(1,'Unknown topic','1.1')
    r.write_manifest(tmp_path/'manifest.json')
    assert json.loads((tmp_path/'manifest.json').read_text())['review_required']==1


def test_cache_fingerprint_changes_with_source(tmp_path):
    p=tmp_path/'source';p.write_text('old')
    before=safety.fingerprint(safety.file_hash(p),'prompt')
    p.write_text('new source')
    assert before!=safety.fingerprint(safety.file_hash(p),'prompt')


def test_atomic_json_roundtrip(tmp_path):
    p=tmp_path/'state.json'
    safety.atomic_json(p,{'value':1});safety.atomic_json(p,{'value':2})
    assert json.loads(p.read_text())=={'value':2}
    assert not list(tmp_path.glob('*.tmp'))


def load_helpers(monkeypatch):
    fake=SimpleNamespace(norm=lambda x:' '.join(str(x).split()),question_minimum=lambda x:1,
        validate_module=lambda *a:None,validate_notes=lambda *a:None,
        validate_questions=lambda *a:None,validate_support=lambda *a:None)
    monkeypatch.setitem(sys.modules,'production_worker',fake)
    sys.modules.pop('bookgraph.books.octa_helpers',None)
    return importlib.import_module('bookgraph.books.octa_helpers')


def test_octa_does_not_replace_invented_quote(monkeypatch):
    h=load_helpers(monkeypatch)
    ev={'E':{'text':'An authentic source sentence about retinal vessels.'}}
    with pytest.raises(ValueError):h.align_support([{'id':'E','quote':'Made up statement about something else.'}],ev)
    with pytest.raises(ValueError):h.align_support([],ev,[{'id':'E','quote':ev['E']['text']}])
    assert h.align_support([{'id':'E','quote':ev['E']['text']}],ev)[0]['id']=='E'


def test_octa_normalizer_does_not_pad_words_or_invent_table(monkeypatch):
    h=load_helpers(monkeypatch)
    text='Actual source sentence.'
    data={'sections':[{'id':'s','title':'T','paragraphs':[{'text':'short','support':[{'id':'E','quote':text}]}],
                       'table_rows':[],'cases':[]}]}
    result=h.normalize_authored_module(data,{'headings':[{'id':'s'}]},{'E':{'text':text}})
    assert result['sections'][0]['paragraphs'][0]['text']=='short'
    assert len(result['sections'][0]['paragraphs'])==1
    assert result['sections'][0]['table_rows']==[]


def test_dr_review_limit_does_not_bypass_rejection():
    # Importing this legacy module needs external publishers. Execute its original router only.
    import bookgraph
    p=Path(bookgraph.__file__).resolve().parent.parent/'dr_dmo_langgraph_pipeline.py'
    tree=ast.parse(p.read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='route_review')
    ns={'ModuleWorkerState':dict}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(p),'exec'),ns)
    with pytest.raises(ValueError):ns['route_review']({'audit_result':{'approved':False},'revision':2})
