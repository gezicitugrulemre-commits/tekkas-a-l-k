import os
import sys
from pathlib import Path
import pytest

SRC = next((candidate for ancestor in Path(__file__).resolve().parents
            for candidate in (ancestor/'src', ancestor)
            if (candidate/'bookgraph').is_dir()), None)
if SRC is None:
    raise RuntimeError('bookgraph kaynak dizini bulunamadı')
sys.path.insert(0, str(SRC))
os.environ['LANGSMITH_TRACING'] = 'false'

@pytest.fixture
def ledger(tmp_path, monkeypatch):
    from bookgraph import usage
    from types import SimpleNamespace
    if usage._conn is not None:
        usage._conn.close()
    usage._conn = None
    monkeypatch.setattr(usage, 'PATHS', SimpleNamespace(usage_db=tmp_path/'usage.sqlite', ensure=lambda: None))
    yield usage
    if usage._conn is not None:
        usage._conn.close()
    usage._conn = None
