import sqlite3
from types import SimpleNamespace
import pytest
from bookgraph import llm

def response(model='gemini-4-argon', **meta):
    return SimpleNamespace(content='ok', response_metadata={'model_version': model, **meta} if model else meta,
                           usage_metadata={'input_tokens':10,'output_tokens':2},id='lc_run--local')

def prompt(models):
    return SimpleNamespace(models=models, role='writer',temperature=0,max_tokens=50,output='text',render=lambda **k: [('user','hello')])

class Model:
    def __init__(self, result): self.result=result
    def invoke(self, messages):
        if isinstance(self.result, Exception): raise self.result
        return self.result
    def with_structured_output(self,*a,**k): return self

def configure(monkeypatch, models, responses):
    calls=[]
    monkeypatch.setattr(llm,'load_prompt',lambda _:prompt(models))
    def build(spec,*args):
        calls.append(spec)
        return Model(responses[spec])
    monkeypatch.setattr(llm,'_build',build)
    return calls

def test_argon_success(ledger,monkeypatch):
    configure(monkeypatch,['google:gemini-4-argon'],{'google:gemini-4-argon':response(response_id='google-id')})
    assert llm.ask('test')=='ok'
    row=ledger._db().execute('SELECT actual_model,provider_response_id,langchain_run_id FROM usage').fetchone()
    assert row==('gemini-4-argon','google-id','lc_run--local')

def test_argon_no_silent_fallback(ledger,monkeypatch):
    calls=configure(monkeypatch,['google:gemini-4-argon','google:gemini-3.8-flash'],{
        'google:gemini-4-argon':TimeoutError('network'),'google:gemini-3.8-flash':response('gemini-3.8-flash')})
    with pytest.raises(RuntimeError):llm.ask('test')
    assert calls==['google:gemini-4-argon']
    assert ledger._db().execute('SELECT status FROM usage').fetchone()[0]=='FAILED'

def test_missing_identity_not_requested_model(ledger,monkeypatch):
    configure(monkeypatch,['google:gemini-4-argon'],{'google:gemini-4-argon':response(None)})
    with pytest.raises(ValueError):llm.ask('test')
    assert ledger._db().execute('SELECT actual_model,status FROM usage').fetchone()==('unknown','MODEL_UNVERIFIED')

def test_lc_id_is_never_provider_id(ledger):
    llm._log_usage(response(response_id='lc_run--bad'),['google:gemini-4-argon'],'b','u','p')
    assert ledger._db().execute('SELECT provider_response_id FROM usage').fetchone()[0] is None

def test_explicit_fallback_logged(ledger,monkeypatch):
    calls=configure(monkeypatch,['google:broken','google:gemini-3.8-flash'],{
        'google:broken':TimeoutError('possibly-sensitive-text'),
        'google:gemini-3.8-flash':response('gemini-3.8-flash')})
    assert llm.ask('test')=='ok'
    assert len(calls)==2
    assert ledger._db().execute('SELECT from_model,to_model,error_type FROM fallback_events').fetchone()==(
        'google:broken','google:gemini-3.8-flash','TimeoutError')
    rows=ledger._db().execute('SELECT actual_model,run_id FROM usage ORDER BY id').fetchall()
    assert [r[0] for r in rows]==['unknown','gemini-3.8-flash']
    assert rows[0][1]==rows[1][1]

def test_no_fallback_option(ledger,monkeypatch):
    calls=configure(monkeypatch,['google:broken','google:flash'],{'google:broken':TimeoutError()})
    with pytest.raises(RuntimeError):llm.ask('test',no_fallback=True)
    assert len(calls)==1

def test_old_ledger_migration_preserves_history(ledger):
    conn=sqlite3.connect(ledger.PATHS.usage_db)
    conn.execute('CREATE TABLE usage (id INTEGER PRIMARY KEY,ts TEXT,book TEXT,unit TEXT,prompt TEXT,model TEXT,input_tokens INTEGER,output_tokens INTEGER,usd REAL)')
    conn.execute("INSERT INTO usage VALUES (1,'old','b','u','p','gemini-4-argon',3,2,0.1)")
    conn.commit();conn.close()
    db=ledger._db()
    assert db.execute('SELECT model,actual_model,status FROM usage').fetchone()==('gemini-4-argon',None,'LEGACY_UNVERIFIED')
    ledger.record('b','u','p','requested',None,None,status='FAILED')
    assert db.execute('SELECT input_tokens,usd FROM usage WHERE id=2').fetchone()==(None,None)

def test_unknown_price_not_invented(ledger):
    assert ledger.price('unknown',100,100) is None
    assert ledger.price('gemini-4-argon',None,10) is None

def test_argon_does_not_enter_economy(monkeypatch):
    monkeypatch.setattr(llm.usage,'economy_mode',lambda:True)
    assert 'gemini-4-argon' in llm.resolve_chain(prompt(['google:gemini-4-argon']))[0]


def test_provider_reports_flash_for_strict_argon_is_rejected(ledger,monkeypatch):
    configure(monkeypatch,['google:gemini-4-argon'],{'google:gemini-4-argon':response('gemini-3.8-flash')})
    with pytest.raises(ValueError):llm.ask('test')
    assert ledger._db().execute('SELECT status,actual_model FROM usage').fetchone()==('MODEL_MISMATCH','gemini-3.8-flash')
