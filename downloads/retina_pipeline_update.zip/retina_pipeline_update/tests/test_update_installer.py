import importlib.util
import json
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'apply_update.py'
# Installer tests run in the delivery package; installed application tests do not need it.
pytestmark=pytest.mark.skipif(not SCRIPT.is_file(),reason='Installer only exists in the update package')

def load_installer():
    spec=importlib.util.spec_from_file_location('guarded_installer',SCRIPT)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def package(tmp_path):
    mod=load_installer();p=tmp_path/'package';t=tmp_path/'target'
    (p/'updated/bookgraph').mkdir(parents=True);(t/'bookgraph').mkdir(parents=True)
    (p/'updated/bookgraph/a.py').write_text('new\n')
    (t/'bookgraph/a.py').write_text('old\n')
    manifest={'files':[{'path':'bookgraph/a.py','baseline_hash':mod.text_hash(b'old\n'),'updated_hash':mod.text_hash(b'new\n')}]}
    (p/'manifest.json').write_text(json.dumps(manifest))
    return mod,p,t

def test_dry_run_does_not_write(tmp_path):
    mod,p,t=package(tmp_path)
    assert mod.apply(p,t)['status']=='dry_run'
    assert (t/'bookgraph/a.py').read_text()=='old\n'

def test_changed_windows_file_is_preserved(tmp_path):
    mod,p,t=package(tmp_path)
    (t/'bookgraph/a.py').write_text('user changes\n')
    with pytest.raises(ValueError,match='hiçbir dosya'):mod.apply(p,t,commit=True)
    assert (t/'bookgraph/a.py').read_text()=='user changes\n'

def test_apply_backup_and_idempotence(tmp_path):
    mod,p,t=package(tmp_path)
    result=mod.apply(p,t,commit=True)
    assert (t/'bookgraph/a.py').read_text()=='new\n'
    assert (Path(result['backup'])/'bookgraph/a.py').read_text()=='old\n'
    assert mod.apply(p,t,commit=True)['status']=='already_applied'
