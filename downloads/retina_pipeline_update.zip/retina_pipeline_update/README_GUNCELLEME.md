# Retina / LangGraph kod güncellemesi

Bu paket yüklediğiniz `retina_pptx_audit_package.zip` kaynakları üzerinden hazırlandı. Windows makinenize uygulanmadı. Sonradan agentınızın değiştirdiği dosyaları içermez; onların üzerine körlemesine yazılmaz. Yeni model/sağlayıcı/abonelik seçilmedi. Testlerde ücretli API çağrısı yapılmadı.

## Değişiklikler

- Kitap, OCTA, retina ve DR/DMÖ yollarında kalite reddinin otomatik onaya çevrilmesi engellendi. Editör onayı açık karar gerektirir. Onaysız commit reddedilir.
- RAG arızasında veya kanıt yokluğunda kaynaklı içerik üretilmiş gibi devam edilmez. Eksik paragrafa yedek kaynak eklenmez. Bu referans kontrolüdür; tek başına klinik doğruluk ispatı değildir.
- Reviewer'a gerçek kaynak pasajları sağlanır. Retina author -> reviewer -> commit sırası eklendi. OCTA'ya bütün sorular/bölümler ve kaynaklar verilir.
- OCTA normalizasyonunda uydurma destek pasajı, otomatik paragraf uzatma ve eksik tablo/olguyu hazır klinik metinle doldurma kaldırıldı.
- Argon-first işler varsayılan olarak katıdır: Flash'a sessiz geçmez. Provider kimliği Argon'u doğrulamazsa çıktı kabul edilmez. `ask(..., argon_mandatory=True, no_fallback=True, disable_economy=True)` parametreleri desteklenir.
- Usage SQLite şeması ek sütunlarla yükseltilir; eski satırlar silinmez veya doğrulanmış ilan edilmez. requested/actual model ayrılır; bilinmeyen model/token unknown/NULL olur. Google yanıt kimliği ile LangChain lc_run kimliği ayrı tutulur. Fallback olayları ortak run_id ile bağlanır. Yerel USD tahmini Cloud faturası veya Antigravity kotası değildir.
- Humanizer sonrasında sayı, birim, atıf, karşılaştırma ve belirli olumsuzluk işaretlerindeki değişiklikler reddedilir. Bu anlamsal eşdeğerliğin tam ispatı değildir.
- Retina/OCTA ve DR/DMÖ modül önbellekleri içerik/prompt sürümüne bağlandı; eski onaysız çıktı kabul edilmiş sayılmaz. PubMed node cache süresiz değil 1 saat. Yeniden üretim gerekebilir; güncelleme kendisi üretim başlatmaz.
- Aktif görsel çözümleyicide bölüm kodu hastalık kimliği olarak kullanılmaz. Birden çok/eksik hastalık, birleşik patoloji veya onaysız kayıt incelemeye ayrılır. Görsel tekrarını önleme klinik uygunluğun önüne geçmez. Önbellek dosya adı yerine içerik hash'i kullanır.
- Eski sabit APPROVED gözetmenler açık hatayla durur. Yardımcı arayüzdeki yapay benzerlik yüzdeleri kaldırıldı.

## Görsel onayı ve taslak davranışı

Mevcut katalog panel/altyazı ilişkisinde hatalar taşıyor. Kod bu eski kayıtları otomatik olarak klinik doğrulanmış ilan etmez. Otomatik ekleme için registry kaydı aşağıdaki alanları içermelidir:

```
path, disease_ids, original_caption, review_status="approved", reviewer,
source_id, page (PDF sayfası), figure_id, panel_id, modality,
bbox=[x0,y0,x1,y1], image_sha256
```

`disease_ids` klinik konu kimlikleridir (`arn`, `cmv`, `toxoplasmosis`, `stargardt`, `best`, `crao`, `crvo`, `brao`, `brvo`, `npdr`, `pdr`, `dme`, `rp`). Bu sınırlı sözlük evrensel tanı sistemi değildir. Bilinmeyen veya karşılaştırmalı konularda `resolve_visual(..., topic_id=..., modality=...)` ile açık kimlik verilmeli; kayıt ayrıca gözden geçirilmiş olmalı. `reviewer` alanını veya `approved` değerini katalog genelinde topluca doldurmayın. Klinik onayı gerçek inceleme gerektirir.

Onaysız görseller otomatik eklenmez; ilgili içerik metin olarak korunur. Bu nedenle eski katalogla sunumda daha az görsel olabilir. Görsel incelemesi eksik sunum `.review-required.pptx` adıyla saklanır; yanında `.visual-review.json` karar manifesti bulunur. Bu dosya final klinik onay belgesi değildir. Her slaytın görsel/layout kontrolünü otomatik çözen bir VLM veya OCR servisi bu pakette kurulmadı.

## Güvenli uygulama

ZIP'i ayrı bir klasöre açın; `updated/` içeriğini projenin üzerine kopyalamayın.

Ön kontrol (dosya değiştirmez):

```powershell
python apply_update.py "C:\Users\gezic\OneDrive\Desktop\Anti Gravity"
```

Kaynaklar yüklenen sürümle aynıysa uygulama:

```powershell
python apply_update.py "C:\Users\gezic\OneDrive\Desktop\Anti Gravity" --apply
```

Araç önce bütün dosyaları kontrol eder. Herhangi bir dosya sonradan değişmişse hiçbir dosyaya dokunmadan çatışma listesini verir. Özellikle son Argon güncellemesindeki `bookgraph/llm.py` ve `usage.py` için bu beklenebilir. Agentınız `baseline/` (yüklenen sürüm), Windows'taki güncel sürüm ve `updated/` (bu paketin sürümü) arasında üç yönlü birleştirme yapmalı; yeni provenance değişikliklerini korumalıdır. `changes.patch` inceleme içindir. Araca zorla üzerine yaz seçeneği eklenmedi.

Uygulama öncesi değişecek dosyalar `.retina-update-backups/` altında yedeklenir. Veritabanları, PDF'ler, PPTX'ler, kullanıcı görselleri ve `.env` dosyaları güncelleme aracı tarafından taşınmaz/silinmez. Usage şeması yalnız kod çalıştırıldığında ek sütunlarla yükseltilir.

## Doğrulama

İzole test ortamında Python 3.12 ile:

```powershell
python -m venv .venv-update-test
.venv-update-test\Scripts\python -m pip install -r requirements-test.txt
.venv-update-test\Scripts\python -m pytest -q tests
```

Teslimat paketi testleri `tests/` içinde; güvenli kurulum aracı bunları projede `tests/retina_safety_update/` içine yerleştirir. Projeye uygulandıktan sonra aynı bağımlılıklar bulunan ortamda:

```powershell
python -m pytest -q tests/retina_safety_update
```

Paket düzeyinde 48 test geçti. Üç kurulum-aracı testi uygulama projesinde araç bulunmadığından atlanır; kalan 45 test çalışır. Gerçek LangGraph alt akışları, checkpoint durumu, kaynak reddi, katı Argon seçimi, fallback kayıtları, eski SQLite şeması, hash/önbellek değişimi ve güncelleme çakışmaları kapsandı. LLM/provider yanıtları kontrollü taklitlerle sağlandı; gerçek Cloud faturası, tıbbi doğruluk, tam medikal arşiv ve tüm 446 slaytın render doğrulaması yapılmadı. Dış `ingest`, `pubmed_client`, `production_worker` ve publisher bağımlılıkları mevcut projenizde bulunmalı.

Bu paket API kredisi veya abonelik kullanımı hakkında yeni bir varsayım yapmaz. Testlerden sonra ücretli gerçek üretimi başlatmak ayrı bir işlemdir.
