# Hermes oftalmoloji skill taslağı

Hazırlanan paket: `ophthalmology-study-pipeline/SKILL.md`, kaynak/indeks ve model planları, rapor şablonu, ayrı bir Hermes yapılandırma örneği. Gerçek arşiv, Hermes ve model hesabı bu makinede bulunmadığı için arşiv indeksleme, canlı model çağrısı ve tıbbi doğruluk pilotu çalıştırılmadı. Bu bir skill taslağıdır; çalışır RAG uygulaması veya hazır indeks değildir.

## Kurulum

Hermes kurulu makinede `hermes --help`, `hermes skills --help`, `hermes model` ve `hermes portal info` ile sürüm, model kataloğu ve mevcut oturumu kontrol et. Yeni Portal kurulumu gerekiyorsa resmi belgelerdeki `hermes setup --portal` akışını kullan; mevcut kurulumu gereksiz yeniden yapılandırma. Nous hesabı araç gateway erişimi veriyorsa arama/görsel araçları için ayrıca anahtar toplamadan önce o yolu dene.

Skill klasörünü etkin Hermes profilinin `skills/ophthalmology-study-pipeline/` klasörüne kopyala. Varsayılan profil: `~/.hermes/skills/`. Aynı isimde bir skill varsa üzerine yazma; önce karşılaştır ve ayrı sürüm olarak kaydet. `references/` ve `templates/` klasörlerini de kopyala. Hermes'te yeni oturum aç ve şu örnekle başlat:

```text
/ophthalmology-study-pipeline Diabetik maküler ödem; yerel arşivim /GERCEK/ARSIV/YOLU. Türkçe, asistanlık düzeyi, 8 görsel öğe, 4 tablo, 20 soru, 25 Anki kartı. Son 5 yıl yayınlarını temel textbook bilgisiyle karşılaştır. İlk çalışmada arşivden 20 belgeyle pilot yap.
```

Arşiv yolunu gerçek yol ile değiştir. Tüm 6 GB'ı modele ek olarak gönderme. Veri hassassa veya uzak model kullanımına izin yoksa yerel OCR/embedding ve gerektiğinde yerel üretim modeli seç.

`hermes-config.example.yaml` yalnız yapılandırma örneğidir. İçindeki model kimlikleri yer tutucudur; ekran görüntüsündeki büyük harfli etiketleri doğrulamadan model slug'ı olarak kopyalama. Mevcut config'in ilgili anahtarlarına birleştir; dosyanın tamamını ezme. Gizli değer içermez. Kimi incelemesi otomatik kurulmuş değildir; ayrı oturumda seçilebilir.

## Hazır skill kaynakları

Resmi Hermes belgelerinden doğrulanan keşif yolları:

- [Hermes Skills Hub](https://hermes-agent.nousresearch.com/skills) ve [Skills belgeleri](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills).
- [NousResearch/hermes-agent skills](https://github.com/NousResearch/hermes-agent/tree/main/skills): paketlenmiş skill'ler.
- [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills): bilimsel literatür, görselleştirme ve yazım iş akışları. Eski `claude-scientific-skills` adı hâlâ karşına çıkabilir. Güncel klasör ve gereksinimleri incele; belirli skill isimlerinin her sürümde var olduğunu varsayma.
- [Anthropic skills](https://github.com/anthropics/skills): PDF, PPTX, XLSX, DOCX gibi belge becerileri; bilimsel koleksiyonun hepsini içerdiğini varsayma.
- [skills.sh](https://skills.sh/): geniş katalog, Hermes doğrudan arayabilir.
- [ClawHub](https://clawhub.ai/): topluluk kataloğu; Hermes kaynak adaptörü resmi belgelerde listeleniyor.

```bash
hermes skills browse
hermes skills search pubmed
hermes skills search literature
hermes skills search scientific
hermes skills search pdf --source skills-sh
```

Sonuçtaki gerçek identifier için önce `hermes skills inspect IDENTIFIER`, ardından `hermes skills install IDENTIFIER`. Skill'in istediği API'leri, lisansı, dosya erişimini ve gönderdiği verileri oku; varsayılan güvenlik taramasını koru. Uyumlu SKILL.md bulunması dış araçların da otomatik kurulması demek değildir. Güncel CLI sürümün bir kaynak/komutu desteklemiyorsa kendi `--help` çıktısını esas al.

## Doküman doğrulaması ve durum

Hermes'in resmi GitHub README'si, skill biçimi, Nous Portal, provider ve configuration belgeleri okundu. Ortak alt görev yönlendirmesi ayrıca `tools/delegate_tool.py` ile karşılaştırıldı. K-Dense'ın güncel README'si okundu. Skills Hub/skills.sh/ClawHub katalog sonuçları, promosyonların canlı geçerliliği ve aday modellerin klinik performansı test edilmedi.

İlgili belgeler:

- https://hermes-agent.nousresearch.com/docs/integrations/nous-portal
- https://hermes-agent.nousresearch.com/docs/user-guide/configuration
- https://github.com/NousResearch/hermes-agent/blob/main/tools/delegate_tool.py

Bulut onboarding kontrolünde `/workspace/tekkas-a-l-k` ve GitHub origin erişilebilir bulundu; `git ls-remote origin` başarılı olup hiç ref döndürmedi, `HEAD`/`main` sorgusu eşleşme bulamadı. Depo boş; kurulacak uygulama, bağımlılık manifesti veya test yok. Tracked dosyalar değiştirilmedi. Bulut install_script/start_skill alanlarına taslak kaydedilmedi: bu skill paketi Hermes kurulumunun test edilmiş talimatı değildir. Bu klasör depodan ayrı hazırlanmıştır; kullanıcıya teslim edilen dosyaların yeni bulut görevinde otomatik korunacağı garanti edilmez.
