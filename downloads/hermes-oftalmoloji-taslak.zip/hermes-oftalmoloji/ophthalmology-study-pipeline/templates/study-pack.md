# {{Konu}} — görsel çalışma paketi

Tarih: {{arama_tarihi}} · Düzey: {{düzey}} · Süre: {{süre}}

**Kaynak durumu:** Yerel arşiv {{kullanıldı/kullanılmadı}}; internet {{taranabildi/taranamadı}}; tam metin {{sayı}}; yalnız özet {{sayı}}. İkinci model incelemesi {{yapıldı/yapılmadı}}.

## Öğrenme hedefleri ve kavram haritası

{{5–8 somut kazanım ve kaynaklı Mermaid/SVG harita}}

## Temel bilgi ve görsel atlas

{{Patofizyoloji → bulgu → klinik anlam bağlantısı; önemli iddialarda [S01 s.123] veya [P03 PMID:...] kaynakları}}

Her görsel: modalite/panel, kaynak ve sayfa, gerçek görüntü/öğretici şema etiketi, alt metin, “nereye bakmalı”, “sık hata”, lisans/erişim durumu.

## Karşılaştırma tabloları

| Tanı | Ayırt edici bulgu | Görüntüleme | Sık karıştığı durum | Kaynak |
|---|---|---|---|---|
| {{tanı}} | {{bulgu}} | {{bulgu}} | {{durum}} | {{kaynak}} |

| Tedavi | Hangi popülasyon/endikasyon | Sonlanım ve süre | Sınırlılık/güvenlilik | Kaynak |
|---|---|---|---|---|
| {{tedavi}} | {{popülasyon}} | {{veri veya belirtilmemiş}} | {{sınırlılık}} | {{kaynak}} |

| Çalışma | Tasarım / N | Karşılaştırma | Ana sonuç | Okunan erişim | Sınırlılık | DOI/PMID |
|---|---|---|---|---|---|---|
| {{çalışma}} | {{tasarım}} | {{kollar}} | {{birim ve takip}} | {{tam metin/özet}} | {{sınırlılık}} | {{kimlik}} |

## Klinik karar akışı ve belirsizlikler

{{Kaynaklı eğitim algoritması, textbook–güncel yayın farkları ve açıklanmamış çelişkiler}}

## Çalışma soruları

{{20 soru; cevapları burada gösterme; görsel sorusunda görseli ekle}}

## Cevap anahtarı

{{Cevap + neden + diğer seçeneklerin neden uygun olmadığı + kaynak}}

## Anki ve tekrar

{{Kart sayısı, dosya ve varsa medya manifesti; gün 1/3/7/14/30 önerisi}}

## Kaynaklar, arama ve kontrol kaydı

{{Sorgular, erişim tarihi, filtreler, kaynak künyeleri, sayfalar, DOI/PMID, erişim ve lisans; beş iddianın özgün kaynak kontrolü; görsel/soru/HTML kontrol sonucu}}

**Açık eksikler:** {{Erişilmeyen tam metin, eksik görseller, tamamlanmamış model kontrolü. Eksik varsa yokmuş gibi paket tamamlandı deme.}}
