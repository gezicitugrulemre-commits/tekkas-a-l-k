# 6 GB arşiv için önerilen altyapı

Bu dosya bir uygulama planıdır; aşağıdaki bileşenler kurulmuş değildir. Arşiv paylaşılmadığı için belge sayısı, tarama oranı ve indeks kapasitesi bilinmiyor. Dosya boyutu doğrudan token veya RAM ihtiyacını vermez. İlk pilotta 20–30 temsilî belge seç: metin PDF, taranmış textbook, tablo ağırlıklı makale, çok sütunlu sayfa, görsel ağırlıklı bölüm ve Türkçe/İngilizce içerik.

## Yerleşim ve bileşenler

- `library/`: kullanıcının özgün dosyaları, salt okunur.
- `index/`: belge manifesti, çıkarılmış metin, FTS indeksi, embedding indeksi.
- `cache/figures/`: özgün sayfa/görsel koordinatına bağlı çıkarımlar; haklar ve açıklamalar kayıtlı.
- `outputs/<konu>-<tarih>/`: rapor ve çalışma çıktıları; mevcut çıktıyı ezmeden yeni çalışma klasörü.

Başlangıç araç adayları: PyMuPDF ile metin/görsel çıkarımı (lisans koşullarını kontrol et), zor sayfa düzenlerinde Docling; yalnız taranmış veya düşük kaliteli sayfalarda OCRmyPDF/Tesseract (`eng+tur`). OCR özgün PDF üzerine yazmamalı; yeni bir türev üretmeli. OCR dil paketlerini doğrula.

Önce SQLite FTS5 ile anahtar kelime araması. Sonra Türkçe/İngilizce için `intfloat/multilingual-e5-base` embedding adayı; E5'in `query:` ve `passage:` öneklerini model kartına uygun kullan. FAISS veya Qdrant ile vektör araması; tek kullanıcıda yerel indeks yeterli olabilir. İki aramayı Reciprocal Rank Fusion ile birleştir. İhtiyaç varsa `BAAI/bge-reranker-v2-m3` ile ilk 30–50 adayı yeniden sıralayarak 12–20 parçaya indir. Bunlar promosyon chat modellerinden farklı modellerdir; yerel donanım, indirme ve gecikme ayrıca değerlendirilir.

## İndeks kuralları

1. Dosyaları SHA-256 ile tanı; işlem durumunu manifestte tut. Değişmeyen dosyayı tekrar OCR/embedding yapma. İş kesilince devam edebil; hatalı belgeyi karantinaya al ve sayısını raporla.
2. Belge–bölüm–sayfa sınırlarına bağlı yaklaşık 600–1000 token parça, 80–150 token örtüşme ile başla. Tablo/şekil açıklamasını bölme; uygun olduğunda komşu sayfayı çek.
3. Metadata: `doc_id`, `chunk_id`, dosya yolu, başlık, yazar, yıl, kitap baskısı, bölüm, **basılı sayfa** ve **PDF sayfa indeksi**, DOI/PMID, şekil/tablo numarası, OCR durumu, lisans, extraction sürümü. Sayfa indeksi ile basılı sayfayı karıştırma.
4. Textbook kavramlarını ve makale sonuçlarını ayrı etiketle. OCR'den çıkan tabloları sayfa görseliyle kontrol et; başlık/birim/panel kaybolmuşsa analize sokma.
5. Görüntüleri ve altyazıları birlikte indeksle. Görsel aramada yalnız altyazı eşleşmesini “görsel tanı” diye sunma; seçilen görüntü ayrıca görsel modelle veya kullanıcıyla incelenir.
6. Ağ için gereksinimler: `eutils.ncbi.nlm.nih.gov`, `www.ncbi.nlm.nih.gov`, `pmc.ncbi.nlm.nih.gov`, `www.ebi.ac.uk`, `europepmc.org`, `api.crossref.org`; kılavuzlarda `aao.org` ve `euretina.org`. Açık tam metin ve model dosyalarının ek alan adlarını gerçek bağlantılardan belirle. Ağ izni mevcutsa ayrıca değiştirme; bilinmeyen izin listesini topluca değiştirme.
7. PubMed/Europe PMC'de normal düşük hacimli okumayı önce mevcut erişimle dene; API anahtarını gereksiz ön koşul yapma. Servislerin güncel hız sınırlarını uygula, önbellek ve geri çekilme kullan. Tam metin yokluğu ile internet bağlantısı yokluğunu ayır.

## Pilot kabul ölçütleri

- 10 örnek konu sorusunda beklenen kaynak sayfa/bölümün ilk 10 sonuçta bulunup bulunmadığını kaydet; asistanla hedef en az 8/10, sonuçlar kötü ise parça sınırları ve sıralamayı değiştir.
- En az 5 tabloda başlık, satır/kolon ve ölçü birimlerini özgün sayfayla karşılaştır. Kritik OCR hatası varsa düzeltmeden o tabloyu kullanma.
- Bir OCT/fundus görselinde özgün sayfa, şekil numarası, panel ve altyazıya geri dönüşü göster.
- Bir taramayı kesip devam et; aynı dosyaların tekrar işlenmediğini göster. Bu testler çalıştırılmadıkça indeks “hazır” değildir.
- Kaynak testleri yalnız yazılmış rapora bakarak geçmez; gerçek dosya/tam metin gerektirir.
