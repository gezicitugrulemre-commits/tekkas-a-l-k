# Modeller ve maliyet planı

Fiyatlar kullanıcının Nous promosyon ekran görüntüsünden okunmuştur: dolar / 1 milyon token. Canlı fiyat, aktif promosyon, hesap uygunluğu, context limiti, araç/görsel desteği ve model slug'ları doğrulanmış değildir. Önce `hermes model` veya `/model` kataloğundan gerçek kimliği seç. Bir modele ucuz olduğu veya adında belirli bir aile geçtiği için doğrulanmamış yetenek atama.

| Görev | Denenecek aday | Girdi / çıktı | Kullanım şartı |
|---|---|---:|---|
| Ana ajan, kaynaklı sentez, tablo ve soru üretimi | DeepSeek V4 Pro 0813 | $0.25 / $0.75 | Gerçek araç çağrısı ve kaynak takibi pilotu geçmeli |
| Dar metin görevleri: terimler, kaynak adayları, veri şeması | Qwen3.8 27B | $0.02 / $0.50 | Sıkı JSON ve kanıt sadakati testi; klinik sonuçların tek denetçisi değil |
| Çok basit metin etiketleme; alternatif | Mistral Nemo | $0.02 / $0.02 | Ucuz çıkarım adayı; zor sentez veya görüntü analizi için seçilmez |
| Seçilmiş klinik görsel ve karmaşık tablo okuma | Gemini 3.8 Flash | $0.75 / $3.75 | Portal endpoint'inin görüntü kabulü ve yeterli çözünürlük test edilmeli |
| İsteğe bağlı ikinci model incelemesi | Kimi K2.6 | $0.43 / $1.82 | Taslakla birlikte gerçek kanıtı incelemeli; klinik performansı ölçülmüş değil |
| Sadece zor vakalar için alternatif inceleme | Kimi K3 | $0.73 / $10.00 | Çıktısı pahalı; rutin uzun rapor için başlangıç tercihi değil |

Qwen3.5-35B-A3B ($0.08 / $0.75), Solar Pro 4 ($0.09 / $0.36) ve Gemma 4 26B A4B ($0.04 / $0.22) alternatif metin adaylarıdır. Listedeki isimler ekran görüntüsünün etiketleridir; model yetenekleri veya gerçek slug olarak garanti edilmez. Mercury 2.5 düşük maliyetli görünse de bu çalışma için araç/kaynak sadakati pilotu olmadan öncelik vermiyorum. Ekranın altındaki fiyatı tam görünmeyen modeller için maliyet tahmini yapılmadı.

## İlk uygulama: üç model yolu

Ana model: DeepSeek adayı. Ortak alt görev modeli: Qwen adayı. Görsel yardımcı: Gemini adayı. İlk sürümde her aşama için farklı model yönlendirme sistemi kurmak gerekmez. Mevcut resmi Hermes belgelerine göre `delegation.provider/model` ortak alt görev yolunu; `auxiliary.vision` görsel analiz yolunu ayarlar. `SKILL.md` bunları kendi başına kuramaz ve mevcut `delegate_task` şemasına görev başına `model` alanı eklenmemelidir.

İkinci model incelemesi için ayrı Hermes oturumunda modeli seç ve yalnız raporla ilgili kanıt dosyalarını ver. Tam otomatik, her aşaması ayrı modelli yönlendirme istenirse ek bir runner/entegrasyon gerekir; bu pakette böyle bir uygulama yoktur. `auxiliary.vision` ayarı native görüntü kullanan ana modelin bütün görüntü trafiğini otomatik olarak başka modele yönlendirdiği anlamına gelmez.

## Küçük ama gerçek pilot

10 kaynaklı soru, 3 özgün OCT/fundus örneği, 2 ilaç karşılaştırma tablosu ve 20 çoktan seçmeli soru oluştur. Kaynak doğruluğu, görsel hata, seçenek belirsizliği, araç çağrısı başarısı, Türkçe terimler, token ve gecikmeyi ayrı ölç. Klinik açıdan kritik hatada maliyet avantajına bakmadan görevi daha güçlü bir yola taşı veya insan incelemesine bırak. Model ailesi adı tek başına bu pilotun yerine geçmez.

## Maliyet hesabı

`USD = input_tokens / 1_000_000 × input_price + output_tokens / 1_000_000 × output_price`.

Örnek sadece metin akışı: Qwen 100k girdi + 10k çıktı ≈ $0.007; DeepSeek 150k girdi + 15k çıktı ≈ $0.04875; Kimi K2.6 40k girdi + 5k çıktı ≈ $0.0263. Toplam ≈ **$0.08205**. Bu bir görev maliyeti vaadi değildir: düşünme token'ları, tekrarlanan context, görsel token'ları, tool gateway, arama, OCR, embedding ve render ücretleri dahil değildir. İndirim biterse yeniden hesapla. Gerçek fiyat/usage verisi yoksa tahmini gerçek fatura diye sunma.
