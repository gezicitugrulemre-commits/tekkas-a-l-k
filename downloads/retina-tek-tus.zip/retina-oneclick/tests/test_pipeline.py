from __future__ import annotations

import csv
import io
import json
import re
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import fitz

from retina_backend import PdfDocument, PipelineConfig, PipelineError, run_pipeline


MODELS = ["qwen/qwen3.8-27b", "google/gemini-3.8-flash", "deepseek/deepseek-v4-pro-0813", "moonshotai/kimi-k2.6"]


def make_pdf(name="test-retina.pdf", marker="Retina study") -> PdfDocument:
    doc = fitz.open()
    page = doc.new_page()
    page.insert_textbox(fitz.Rect(40, 40, 520, 700),
        f"{marker}. Figure 1: OCT page. This is a synthetic test document.\n"
        "Study design: randomized trial. Number of participants: 20.\n"
        "Follow-up: 12 months. The study reports an illustrative visual outcome.\n"
        "Source identifiers must remain linked to this exact page.")
    data = doc.tobytes()
    doc.close()
    return PdfDocument(name, data)


class FakeModels(BaseHTTPRequestHandler):
    requests: list[dict] = []
    fail_vision = False
    invalid_citation = False
    fail_document = None
    wrong_document_citation = None

    def log_message(self, *_):
        pass

    def respond(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/v1/models":
            self.respond(200, {"data": [{"id": model} for model in MODELS]})
        else:
            self.respond(404, {})

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        type(self).requests.append(payload)
        model = payload["model"]
        content = payload["messages"][1]["content"]
        prompt = content if isinstance(content, str) else "\n".join(part.get("text", "") for part in content)
        source_ids = re.findall(r"--- \[(D\d+) PDF s\.\d+\]", prompt)
        if not source_ids:
            source_ids = re.findall(r"\[(D\d+) PDF s\.\d+\]", prompt)
        source_id = source_ids[-1] if source_ids else "D1"
        cite = f"[{source_id} PDF s.1]"
        if source_id == type(self).fail_document:
            self.respond(502, {"error": "test upstream failure"})
            return
        if model == MODELS[1] and type(self).fail_vision:
            self.respond(400, {"error": "image input unsupported"})
            return
        if model == MODELS[0]:
            answer = "# Makale haritası\nTest retina makalesi, 20 katılımcı. " + cite
        elif model == MODELS[1]:
            answer = "Gerçek PDF sayfa görüntüsü incelendi; test şekli klinik örnek değildir. " + cite
        elif model == MODELS[3]:
            answer = "Test kaynağına göre katılımcı sayısı 20. " + cite
        else:
            if type(self).invalid_citation:
                cite = f"[{source_id} PDF s.999]"
            if source_id == type(self).wrong_document_citation:
                cite = "[D1 PDF s.1]"
            answer = json.dumps({
                "report_md": "# Retina\nKaynakta 20 katılımcı var. " + cite,
                "anki_cards": [{"front": "Katılımcı sayısı?", "back": "20", "tags": "retina test", "source": cite}],
            }, ensure_ascii=False)
        self.respond(200, {"model": model, "choices": [{"message": {"content": answer}, "finish_reason": "stop"}],
                           "usage": {"prompt_tokens": 100, "completion_tokens": 20}})


class PipelineIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), FakeModels)
        cls.worker = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}/v1"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.worker.join(timeout=5)

    def setUp(self):
        FakeModels.requests = []
        FakeModels.fail_vision = False
        FakeModels.invalid_citation = False
        FakeModels.fail_document = None
        FakeModels.wrong_document_citation = None

    def config(self, *, vision=True, review=True):
        return PipelineConfig(self.url, MODELS[0], MODELS[1] if vision else "", MODELS[2], MODELS[3] if review else None)

    def test_real_pdf_routes_each_model_and_exports_sources(self):
        result = run_pipeline([make_pdf()], self.config())
        requests = FakeModels.requests
        self.assertEqual([item["model"] for item in requests], [MODELS[0], MODELS[1], MODELS[2], MODELS[3], MODELS[2]])
        image_content = requests[1]["messages"][1]["content"]
        self.assertTrue(any(part.get("type") == "image_url" and part["image_url"]["url"].startswith("data:image/png;base64,") for part in image_content))
        for request in (requests[2], requests[3], requests[4]):
            self.assertIn("Number of participants: 20", request["messages"][1]["content"])
        cards = list(csv.DictReader(io.StringIO(result["anki_csv"])))
        self.assertEqual(cards[0]["Source"], "[D1 PDF s.1]")
        manifest = json.loads(result["manifest_json"])
        self.assertEqual(len(manifest["model_calls"]), 5)
        self.assertEqual(manifest["documents"][0]["included_pages"], [1])
        self.assertEqual(manifest["model_calls"][1]["returned_model"], MODELS[1])
        figures = result["figure_images"]
        self.assertEqual(len(figures), 1)
        self.assertTrue(figures[0]["data"].startswith(b"\x89PNG"))

    def test_text_only_does_not_claim_image_or_review_calls(self):
        result = run_pipeline([make_pdf()], self.config(vision=False, review=False))
        self.assertEqual([item["model"] for item in FakeModels.requests], [MODELS[0], MODELS[2]])
        manifest = json.loads(result["manifest_json"])
        self.assertFalse(manifest["vision_enabled"])
        self.assertEqual(manifest["images"], [])
        self.assertEqual(result["figure_images"], [])

    def test_unavailable_model_aborts_before_paid_calls(self):
        config = self.config()
        config.qwen_model = "missing-model"
        with self.assertRaisesRegex(PipelineError, "katalogda bulunamadı"):
            run_pipeline([make_pdf()], config)
        self.assertEqual(FakeModels.requests, [])

    def test_unsupported_image_route_does_not_fallback(self):
        FakeModels.fail_vision = True
        with self.assertRaisesRegex(PipelineError, "HTTP 400"):
            run_pipeline([make_pdf()], self.config())
        self.assertEqual([item["model"] for item in FakeModels.requests], [MODELS[0], MODELS[1]])

    def test_missing_source_page_blocks_export(self):
        FakeModels.invalid_citation = True
        with self.assertRaisesRegex(PipelineError, "gönderilmemiş"):
            run_pipeline([make_pdf()], self.config(vision=False, review=False))

    def test_scanned_document_does_not_claim_full_reading(self):
        doc = fitz.open()
        doc.new_page()
        source = PdfDocument("scan.pdf", doc.tobytes())
        doc.close()
        with self.assertRaisesRegex(PipelineError, "OCR gerekir"):
            run_pipeline([source], self.config())
        self.assertEqual(FakeModels.requests, [])

    def test_seven_documents_each_get_report_cards_and_unique_images(self):
        documents = [make_pdf(f"paper-{n}.pdf", f"Study topic {n}") for n in range(1, 8)]
        config = self.config(vision=True, review=False)
        config.expected_documents = 7
        result = run_pipeline(documents, config)
        manifest = json.loads(result["manifest_json"])
        coverage = manifest["coverage"]
        self.assertEqual(coverage["completed_count"], 7)
        self.assertTrue(coverage["all_completed"])
        self.assertEqual(len(result["document_reports"]), 7)
        self.assertEqual(len(FakeModels.requests), 21)
        for n, article in enumerate(result["document_reports"], 1):
            self.assertEqual(article["source_id"], f"D{n}")
            self.assertIn(f"[D{n} PDF s.1]", article["report_md"])
            self.assertIn(f"paper-{n}.pdf", result["report_md"])
            for request in FakeModels.requests[(n-1)*3:n*3]:
                self.assertEqual(request["max_tokens"], 32000)
        cards = list(csv.DictReader(io.StringIO(result["anki_csv"])))
        self.assertEqual({card["Source"] for card in cards}, {f"[D{n} PDF s.1]" for n in range(1, 8)})
        self.assertEqual(len({image["name"] for image in result["figure_images"]}), 7)

    def test_expected_seven_but_one_selected_stops_before_calls(self):
        config = self.config(vision=False, review=False)
        config.expected_documents = 7
        with self.assertRaises(PipelineError):
            run_pipeline([make_pdf()], config)
        self.assertEqual(FakeModels.requests, [])

    def test_seventh_document_failure_preserves_six_and_marks_incomplete(self):
        FakeModels.fail_document = "D7"
        config = self.config(vision=False, review=False)
        config.expected_documents = 7
        with self.assertRaises(PipelineError) as raised:
            run_pipeline([make_pdf(f"paper-{n}.pdf") for n in range(1, 8)], config)
        partial = raised.exception.partial_result
        coverage = json.loads(partial["manifest_json"])["coverage"]
        self.assertFalse(coverage["all_completed"])
        self.assertEqual(coverage["completed_count"], 6)
        self.assertEqual(coverage["documents"][-1]["status"], "failed")
        self.assertEqual(len(partial["document_reports"]), 6)

    def test_wrong_d1_citation_in_second_document_cannot_pass(self):
        FakeModels.wrong_document_citation = "D2"
        with self.assertRaises(PipelineError) as raised:
            run_pipeline([make_pdf("first.pdf"), make_pdf("second.pdf")], self.config(vision=False, review=False))
        coverage = json.loads(raised.exception.partial_result["manifest_json"])["coverage"]
        self.assertFalse(coverage["all_completed"])
        self.assertEqual(coverage["completed_count"], 1)

    def test_scanned_seventh_document_preflight_avoids_paid_calls(self):
        doc = fitz.open()
        doc.new_page()
        scanned = PdfDocument("seventh-scanned.pdf", doc.tobytes())
        doc.close()
        config = self.config(vision=False, review=False)
        config.expected_documents = 7
        with self.assertRaises(PipelineError):
            run_pipeline([make_pdf(f"paper-{n}.pdf") for n in range(1, 7)] + [scanned], config)
        self.assertEqual(FakeModels.requests, [])


if __name__ == "__main__":
    unittest.main()
