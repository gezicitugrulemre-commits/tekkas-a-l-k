from __future__ import annotations

import csv
import io
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import fitz

from retina_backend import PdfDocument, PipelineConfig, PipelineError, run_pipeline


MODELS = ["qwen/qwen3.8-27b", "google/gemini-3.8-flash", "deepseek/deepseek-v4-pro-0813", "moonshotai/kimi-k2.6"]


def make_pdf() -> PdfDocument:
    doc = fitz.open()
    page = doc.new_page()
    page.insert_textbox(fitz.Rect(40, 40, 520, 700),
        "Retina study. Figure 1: OCT page. This is a synthetic test document.\n"
        "Study design: randomized trial. Number of participants: 20.\n"
        "Follow-up: 12 months. The study reports an illustrative visual outcome.\n"
        "Source identifiers must remain linked to this exact page.")
    data = doc.tobytes()
    doc.close()
    return PdfDocument("test-retina.pdf", data)


class FakeModels(BaseHTTPRequestHandler):
    requests: list[dict] = []
    fail_vision = False
    invalid_citation = False

    def log_message(self, *_):
        pass

    def respond(self, status: int, data: dict):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/v1/models":
            self.respond(200, {"data": [{"id": model} for model in MODELS]})
        else:
            self.respond(404, {})

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        type(self).requests.append(payload)
        model = payload["model"]
        if model == MODELS[1] and type(self).fail_vision:
            self.respond(400, {"error": "image input unsupported"})
            return
        if model == MODELS[0]:
            answer = "# Makale haritası\nTest retina makalesi, 20 katılımcı. [D1 PDF s.1]"
        elif model == MODELS[1]:
            answer = "Gerçek PDF sayfa görüntüsü incelendi; test şekli klinik örnek değildir. [D1 PDF s.1]"
        elif model == MODELS[3]:
            answer = "Test kaynağına göre katılımcı sayısı 20. [D1 PDF s.1]"
        else:
            cite = "[D1 PDF s.999]" if type(self).invalid_citation else "[D1 PDF s.1]"
            answer = json.dumps({
                "report_md": "# Retina\nKaynakta 20 katılımcı var. " + cite,
                "anki_cards": [{"front": "Katılımcı sayısı?", "back": "20", "tags": "retina test", "source": cite}],
            }, ensure_ascii=False)
        self.respond(200, {"model": model, "choices": [{"message": {"content": answer}, "finish_reason": "stop"}],
                           "usage": {"prompt_tokens": 100, "completion_tokens": 20}})


class PipelineIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), FakeModels)
        cls.worker = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}/v1"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.worker.join(timeout=5)

    def setUp(self):
        FakeModels.requests = []
        FakeModels.fail_vision = False
        FakeModels.invalid_citation = False

    def config(self, *, vision=True, review=True):
        return PipelineConfig(self.url, MODELS[0], MODELS[1] if vision else "", MODELS[2], MODELS[3] if review else None)

    def test_real_pdf_routes_each_model_and_exports_sources(self):
        result = run_pipeline([make_pdf()], self.config())
        requests = FakeModels.requests
        self.assertEqual([item["model"] for item in requests], [MODELS[0], MODELS[1], MODELS[2], MODELS[3], MODELS[2]])
        image_content = requests[1]["messages"][1]["content"]
        self.assertTrue(any(part.get("type") == "image_url" and part["image_url"]["url"].startswith("data:image/png;base64,") for part in image_content))
        for request in (requests[2], requests[3], requests[4]):
            self.assertIn("Number of participants: 20", request["messages"][1]["content"])
        cards = list(csv.DictReader(io.StringIO(result["anki_csv"])))
        self.assertEqual(cards[0]["Source"], "[D1 PDF s.1]")
        manifest = json.loads(result["manifest_json"])
        self.assertEqual(len(manifest["model_calls"]), 5)
        self.assertEqual(manifest["documents"][0]["included_pages"], [1])
        self.assertEqual(manifest["model_calls"][1]["returned_model"], MODELS[1])
        figures = result["figure_images"]
        self.assertEqual(len(figures), 1)
        self.assertTrue(figures[0]["data"].startswith(b"\x89PNG"))

    def test_text_only_does_not_claim_image_or_review_calls(self):
        result = run_pipeline([make_pdf()], self.config(vision=False, review=False))
        self.assertEqual([item["model"] for item in FakeModels.requests], [MODELS[0], MODELS[2]])
        manifest = json.loads(result["manifest_json"])
        self.assertFalse(manifest["vision_enabled"])
        self.assertEqual(manifest["images"], [])
        self.assertEqual(result["figure_images"], [])

    def test_unavailable_model_aborts_before_paid_calls(self):
        config = self.config()
        config.qwen_model = "missing-model"
        with self.assertRaisesRegex(PipelineError, "katalogda bulunamadı"):
            run_pipeline([make_pdf()], config)
        self.assertEqual(FakeModels.requests, [])

    def test_unsupported_image_route_does_not_fallback(self):
        FakeModels.fail_vision = True
        with self.assertRaisesRegex(PipelineError, "HTTP 400"):
            run_pipeline([make_pdf()], self.config())
        self.assertEqual([item["model"] for item in FakeModels.requests], [MODELS[0], MODELS[1]])

    def test_missing_source_page_blocks_export(self):
        FakeModels.invalid_citation = True
        with self.assertRaisesRegex(PipelineError, "gönderilmemiş"):
            run_pipeline([make_pdf()], self.config(vision=False, review=False))

    def test_scanned_document_does_not_claim_full_reading(self):
        doc = fitz.open()
        doc.new_page()
        source = PdfDocument("scan.pdf", doc.tobytes())
        doc.close()
        with self.assertRaisesRegex(PipelineError, "OCR gerekir"):
            run_pipeline([source], self.config())
        self.assertEqual(FakeModels.requests, [])


if __name__ == "__main__":
    unittest.main()
