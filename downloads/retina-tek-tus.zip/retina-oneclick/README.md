# Retina Çalışması — tek düğmeli küçük makale akışı

Kullanıcı PDF'leri seçer ve **Çalışmayı başlat** düğmesine basar. Arka planda Qwen kaynak haritası, isteğe bağlı Gemini görsel incelemesi, DeepSeek çalışma paketi ve isteğe bağlı Kimi kontrolü yürütülür. Model kimlikleri canlı katalogdan seçilir; promosyon etiketi API kimliği yerine kullanılmaz.

## Gereken ortam

- Python 3.11 veya üstü.
- Aynı çalışma ortamında Hermes Agent ve giriş yapılmış Nous hesabı.
- Hermes'in resmi subscription proxy özelliği veya bu uygulamayla uyumlu desteklenen model bağlantısı.
- Cloud'da kullanılıyorsa uygulama ekranına erişim sağlayan platform mekanizması. Bir Portal sohbeti açılmış olması bu koşulları tek başına sağlamaz.

## Kurulum (cloud ortamında çalıştıran agent için)

Bu komutlar hazırlanmış paketi kurar; bu dosyanın okunması komutları çalıştırmaz.

```bash
cd /PAKETIN/GERCEK/KONUMU/retina-oneclick
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Mevcut Nous oturumunu önce `hermes portal info` / `hermes proxy status` ile kontrol et. Oturum yoksa resmi giriş yolu `hermes portal`; varsa mevcut oturumu kullan. Proxy henüz çalışmıyorsa ayrı süreçte:

```bash
hermes proxy start
```

Uygulama, aynı makinedeki proxy'yi kullanır. Cloud konteynerleri ayrıysa adresi gerçek desteklenen iç servis adresiyle ayarla; rastgele dış adres seçme.

Cloud'daki mevcut Güncel Retina klasörü için `RETINA_SOURCE_DIR` ortam değişkenini gerçek klasör yoluna ayarla. Uygulama bu klasördeki PDF'leri seçili listeler; başka dizinleri taramaz. Ayar yoksa kullanıcı PDF yükleyebilir.

```bash
.venv/bin/python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
```

Yukarıdaki komut yerel arayüzü başlatır. Cloud'un web yayınlama/erişim mekanizması ayrıca gerekir; bu paket kendiliğinden herkese açık site yayınlamaz. Model proxy'si loopback'te kalmalıdır. Varsayılan Streamlit XSRF/CORS korumalarını devre dışı bırakma. Cloud platformu farklı bind adresi gerektiriyorsa kendi desteklenen, erişim kontrollü yöntemini uygula.

## Kullanım

1. İlk kurulumda Qwen ve DeepSeek model kimliklerini seç. Görseller için Gemini seç ve görsel incelemeyi aç. Kimi ikinci kontrolü isteğe bağlıdır.
2. Güncel Retina klasöründeki en fazla 10 PDF'yi yükle.
3. Çalışmayı başlat düğmesine bas.
4. Raporu incele; ZIP veya Anki CSV indir.

## Birden çok makale

Makale sayısını doğru ayarla (bu çalışma için varsayılan 7). Seçilen PDF sayısı beklenen sayıyla eşleşmedikçe çalışma başlamaz. Cloud kurulumunda `RETINA_EXPECTED_DOCUMENTS` ile sayı belirtilebilir.

Her makale ayrı kaynak okuma ve model akışından geçer. Sonuçlar ortak raporda ve ZIP'in `articles/D1/`, `articles/D2/` … klasörlerinde ayrı bölümler halinde bulunur. Makale başına metin payı kullanılır; yedi belgeyi tek model çağrısında sıkıştırarak ilk makaleye indirgeme yapılmaz. Manifest hangi makalelerin tamamlandığını gösterir. Bir makale başarısız olursa kalanlar tamamlanmış gibi gösterilmez; üretilmiş kısmi çıktı açıkça işaretlenir.

Görsel ve isteğe bağlı inceleme adımları makale başına uygulanır. Bu nedenle süre ve çağrı sayısı tek-makale pilotuna göre artar. Internet seçeneği açılırsa en fazla üç PubMed özeti **makale başına** okunabilir. PDF sayfa metni bütçesi aşılırsa bölümlere ayırma gerekir; eksik metinle tamamlanmış rapor verilmez. Kullanıcı dosyaları değiştirilmez.

Mevcut sürüm küçük makale grubu içindir. Metin çıkarılamayan taranmış PDF'ler için ayrıca OCR gerekir. Bütün 6 GB arşiv için hazır indeks değildir. İnternet seçeneği yalnız sınırlı PubMed özet taramasıdır; tam metin veya sistematik derleme iddiası yoktur.

## Doğrulama sınırları

Bu pakette gerçek Nous oturumu veya kullanıcı makaleleri bulunmaz. On bir entegrasyon testi üretilmiş test PDF'leri ve yerel model test sunucusuyla geçti: model sırası, gerçek PNG girdisi, kaynak sayfaları, CSV çıktısı, yedi makalenin ayrı işlenmesi, eksik dosyada çağrıların başlamaması ve son makale başarısızken önceki altı raporun korunması kontrol edildi. Başlangıç, tamamlanmış yedi-makale raporu ve kısmi sonuç ekranı Streamlit test runner'ında açıldı. Gerçek abonelik, model erişimi, görsel yetenek, çıktı kalitesi ve cloud'daki erişilebilir ekran ayrıca pilotla doğrulanmalıdır. Model çıktılarını insan ve kaynak kontrolü olmadan tıbbi doğrulama sayma.

Test komutu: `.venv/bin/python -m unittest discover -s tests -v`.

Resmi bağlantı sözleşmesi: https://hermes-agent.nousresearch.com/docs/user-guide/features/subscription-proxy

Cloud agent'ına verilecek kısa kurulum isteği: `CLOUD-KURULUM-PROMPTU.txt`.
