"""Retina study UI. Run beside an authenticated Hermes subscription proxy."""
from __future__ import annotations

import io
import json
import os
import re
import zipfile
from pathlib import Path

import streamlit as st

from retina_backend import PdfDocument, PipelineConfig, list_models, run_pipeline


st.set_page_config(page_title="Retina Çalışması", page_icon="📚", layout="wide")
st.title("Retina Çalışması")
st.write("Güncel Retina makalelerini seç. Kaynaklı anlatım, tablolar, sorular ve Anki kartları birlikte hazırlansın.")

with st.sidebar:
    st.subheader("Modeller")
    with st.expander("Bağlantı ayarları"):
        base_url = st.text_input(
            "Cloud ortamındaki model bağlantısı",
            value=os.environ.get("RETINA_PROXY_URL", "http://127.0.0.1:8645/v1"),
            help="Kurulumu yapan kişinin ayarladığı Hermes model bağlantısı. Portal web adresi değildir.",
        ).rstrip("/")
    refresh = st.button("Bağlantıyı yeniden kontrol et")


@st.cache_data(ttl=45, show_spinner=False)
def get_models(url: str) -> list[str]:
    return list_models(url)


if refresh:
    get_models.clear()

try:
    available = get_models(base_url)
    if not available:
        raise ValueError("Bağlantı yanıt verdi fakat kullanılabilir model listesi boş.")
except Exception as exc:
    st.error("Nous model bağlantısı henüz hazır değil.")
    st.write("Kurulumu yapan Hermes'in cloud ortamında bağlantıyı başlatıp model listesini doğrulaması gerekiyor.")
    with st.expander("Kurulum için hata bilgisi"):
        st.code(str(exc), language=None)
    st.stop()


def choose_model(label: str, needles: tuple[str, ...], key: str, optional: bool = False) -> str:
    def normalize(value: str) -> str:
        return re.sub(r"[^a-z0-9]", "", value.lower())
    candidates = [item for item in available if all(normalize(word) in normalize(item) for word in needles)]
    options = ["Seçiniz"] + (["Kapalı"] if optional else []) + available
    if optional:
        initial = options.index("Kapalı")
    elif len(candidates) == 1:
        initial = options.index(candidates[0])
    else:
        initial = 0
    picked = st.sidebar.selectbox(label, options, index=initial, key=key)
    return "" if picked in {"Seçiniz", "Kapalı"} else picked


qwen = choose_model("Kaynak haritası — Qwen3.8 27B", ("qwen", "3.8", "27b"), "qwen")
deepseek = choose_model("Çalışma paketi — DeepSeek V4 Pro", ("deepseek", "v4", "pro", "0813"), "deepseek")
with_images = st.sidebar.checkbox("PDF sayfalarındaki görselleri de incele", value=True)
gemini = choose_model("Görsel inceleme — Gemini 3.8 Flash", ("gemini", "3.8", "flash"), "gemini") if with_images else ""
with_review = st.sidebar.checkbox("Kimi ile ikinci kontrol ekle", value=False)
kimi = choose_model("İkinci kontrol — Kimi K2.6", ("kimi", "k2.6"), "kimi") if with_review else ""
online = st.sidebar.checkbox("En fazla 3 PubMed özetiyle tamamla", value=False)
expected_count = st.sidebar.number_input("Bu çalışmadaki makale sayısı", min_value=1, max_value=10,
    value=max(1, min(10, int(os.environ.get("RETINA_EXPECTED_DOCUMENTS", "7")))), step=1)
st.sidebar.caption("Listede promosyon modeli yoksa başka bir model kendiliğinden seçilmez. Model tercihlerinin ilk kurulumda yapılması gerekir.")

source_dir = os.environ.get("RETINA_SOURCE_DIR", "")
local_paths = []
if source_dir and Path(source_dir).is_dir():
    folder = Path(source_dir)
    candidates = sorted(p for p in folder.iterdir() if p.is_file() and not p.is_symlink() and p.suffix.lower() == ".pdf")
    selected_names = st.multiselect("Güncel Retina klasöründeki makaleler", [p.name for p in candidates], default=[p.name for p in candidates])
    local_paths = [p for p in candidates if p.name in selected_names]
    source_mode = st.radio("Kaynak", ["Cloud klasöründeki makaleler", "Yeni PDF seç"], horizontal=True)
else:
    source_mode = "Yeni PDF seç"
files = st.file_uploader("Güncel Retina klasöründeki PDF’leri seç", type=["pdf"], accept_multiple_files=True) if source_mode == "Yeni PDF seç" else []
use_local = source_mode == "Cloud klasöründeki makaleler"
source_count = len(local_paths) if use_local else len(files)
source_bytes = sum(p.stat().st_size for p in local_paths) if use_local else sum(file.size for file in files)
st.caption("Varsayılan küçük makale grubudur. En fazla 10 PDF ve toplam 50 MB. Özgün dosyalar çıktılara eklenmez.")
if source_count:
    st.write(f"{source_count} PDF seçildi.")
if source_count and source_count != expected_count:
    st.warning(f"Beklenen {expected_count} makale, seçilen {source_count}. Eksik veya fazla seçimi düzelttikten sonra başlat.")

models_ready = bool(qwen and deepseek and (not with_images or gemini) and (not with_review or kimi))
if not models_ready:
    st.info("Başlamadan önce soldaki gerekli model seçimlerini tamamla.")

if st.button("Çalışmayı başlat", type="primary", disabled=not source_count or not models_ready or source_count != expected_count):
    st.session_state.pop("retina_result", None)
    if source_count > 10 or source_bytes > 50 * 1024 * 1024:
        st.error("Bu sürüm küçük makale grubu için hazırlandı: en fazla 10 PDF ve toplam 50 MB seç.")
    else:
        config = PipelineConfig(
            base_url=base_url,
            qwen_model=qwen,
            vision_model=gemini,
            deepseek_model=deepseek,
            review_model=kimi or None,
            online_search=online,
            expected_documents=int(expected_count),
        )
        with st.status("Çalışma hazırlanıyor…", expanded=True) as status:
            def update(stage: str, detail: str = "") -> None:
                status.write(f"{stage}: {detail}" if detail else stage)
            try:
                documents = [PdfDocument(p.name, p.read_bytes()) for p in local_paths] if use_local else [PdfDocument(file.name, file.getvalue()) for file in files]
                result = run_pipeline(documents, config, update)
            except Exception as exc:
                status.update(label="Çalışma tamamlanamadı", state="error", expanded=True)
                st.error(str(exc))
                if getattr(exc, "partial_result", None):
                    st.session_state["retina_result"] = exc.partial_result
            else:
                st.session_state["retina_result"] = result
                status.update(label="Çalışma paketi hazır", state="complete", expanded=False)

result = st.session_state.get("retina_result")
if result:
    manifest = json.loads(result["manifest_json"])
    coverage = manifest.get("coverage", {})
    completed = coverage.get("completed_count", len(manifest.get("documents", [])))
    requested = coverage.get("requested_count", len(manifest.get("documents", [])))
    if coverage.get("all_completed", True):
        if any(item.get("status") == "completed_with_limits" for item in coverage.get("documents", [])):
            st.warning(f"{completed}/{requested} makale işlendi; bazı sayfalar okunamadı. Sayfa eksiklerini makale durumunda ve kaynak kaydında incele.")
        else:
            st.success(f"{completed}/{requested} makale işlendi.")
    else:
        st.warning(f"Kısmi çalışma: {completed}/{requested} makale tamamlandı. Başarısız veya bekleyen makaleler aşağıda.")
    if requested != expected_count or source_count != requested:
        st.info("Gösterilen sonuç önceki çalışmaya ait. Yeni dosya seçimi henüz bu rapora yansımadı.")
    if coverage.get("documents"):
        st.dataframe(coverage["documents"], hide_index=True, width="stretch")
    tabs = st.tabs(["Çalışma paketi", "Kaynaklar", "Görseller", "İkinci kontrol", "Çağrı kaydı", "Makale bölümleri"])
    with tabs[0]:
        st.markdown(result["report_md"])
    with tabs[1]:
        st.markdown(result["article_map_md"])
        st.markdown(result["sources_md"])
    with tabs[2]:
        st.markdown(result["visual_notes_md"])
        for figure in result.get("figure_images", []):
            st.image(figure["data"], caption=figure["source"], width="stretch")
    with tabs[3]:
        st.markdown(result["review_md"] or "İkinci model kontrolü seçilmedi.")
    with tabs[4]:
        st.json(manifest)
    with tabs[5]:
        for article in result.get("document_reports", []):
            with st.expander(f"{article['source_id']} — {article['filename']}"):
                st.markdown(article["report_md"])
    output = io.BytesIO()
    filenames = {
        "report.md": "report_md", "article-map.md": "article_map_md",
        "visual-notes.md": "visual_notes_md", "review.md": "review_md",
        "sources.md": "sources_md", "anki.csv": "anki_csv", "manifest.json": "manifest_json",
    }
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename, key in filenames.items():
            archive.writestr(filename, result[key])
        for figure in result.get("figure_images", []):
            archive.writestr("figures/" + figure["name"], figure["data"])
        for index, article in enumerate(result.get("document_reports", []), 1):
            source_id = article.get("source_id", f"D{index}")
            if not re.fullmatch(r"D\d+", source_id):
                raise ValueError("Geçersiz kaynak kimliği")
            for filename, key in filenames.items():
                if key in article:
                    archive.writestr(f"articles/{source_id}/{filename}", article[key])
    st.download_button("Tüm çıktıları indir", output.getvalue(), "retina-calisma-paketi.zip", "application/zip")
    st.download_button("Anki kartlarını indir", result["anki_csv"].encode("utf-8-sig"), "anki.csv", "text/csv")
